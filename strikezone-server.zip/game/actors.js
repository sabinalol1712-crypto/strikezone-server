'use strict';
/* Персонажи: игрок и боты, модели, стрельба, броня, ИИ */
(function (G) {
  const V3 = THREE.Vector3;
  G.TEAMS = [
    { name: 'Спецназ', short: 'СН', color: '#4aa8ff', uniform: '#33415a', vest: '#222a36', helm: '#3d4c63', pants: '#2b3546', skin: '#c99b78', sleeve: '#33415a' },
    { name: 'Налётчики', short: 'НЛ', color: '#ff7a3d', uniform: '#6f5d3e', vest: '#463a27', helm: '#8f3123', pants: '#574830', skin: '#b8875f', sleeve: '#6f5d3e' }
  ];
  G.BOT_NAMES = ['Волк', 'Призрак', 'Медведь', 'Тень', 'Гром', 'Шторм', 'Ястреб', 'Барс', 'Рысь', 'Скиф', 'Варяг', 'Ворон',
    'Дюна', 'Кедр', 'Шакал', 'Беркут', 'Фантом', 'Сапсан', 'Корсар', 'Север', 'Зубр', 'Филин'];

  G.DIFF = {
    easy: { react: 0.85, turn: 2.4, err0: 1.3, errMin: 0.5, settle: 1.0, headChance: 0.06, fovCos: Math.cos(0.95), sight: 42, burst: [0.15, 0.35], pause: [0.55, 1.1], stopChance: 0.2, dmgMul: 0.7 },
    normal: { react: 0.55, turn: 4.0, err0: 0.85, errMin: 0.3, settle: 1.7, headChance: 0.18, fovCos: Math.cos(1.1), sight: 58, burst: [0.2, 0.5], pause: [0.35, 0.75], stopChance: 0.45, dmgMul: 0.85 },
    hard: { react: 0.28, turn: 7, err0: 0.5, errMin: 0.11, settle: 3, headChance: 0.4, fovCos: Math.cos(1.25), sight: 75, burst: [0.3, 0.8], pause: [0.15, 0.4], stopChance: 0.7, dmgMul: 1 }
  };

  function rayAABB(ox, oy, oz, dx, dy, dz, x0, y0, z0, x1, y1, z1, maxT) {
    let tmin = 0, tmax = maxT, t1, t2;
    if (Math.abs(dx) < 1e-9) { if (ox < x0 || ox > x1) return null; }
    else { t1 = (x0 - ox) / dx; t2 = (x1 - ox) / dx; if (t1 > t2) { const t = t1; t1 = t2; t2 = t; } if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2; if (tmin > tmax) return null; }
    if (Math.abs(dy) < 1e-9) { if (oy < y0 || oy > y1) return null; }
    else { t1 = (y0 - oy) / dy; t2 = (y1 - oy) / dy; if (t1 > t2) { const t = t1; t1 = t2; t2 = t; } if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2; if (tmin > tmax) return null; }
    if (Math.abs(dz) < 1e-9) { if (oz < z0 || oz > z1) return null; }
    else { t1 = (z0 - oz) / dz; t2 = (z1 - oz) / dz; if (t1 > t2) { const t = t1; t1 = t2; t2 = t; } if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2; if (tmin > tmax) return null; }
    return tmin;
  }
  G.rayAABB = rayAABB;

  // ---------- базовый персонаж ----------
  class Actor {
    constructor(name, team, isPlayer) {
      this.name = name; this.team = team; this.isPlayer = !!isPlayer;
      this.pos = new V3(); this.vel = new V3();
      this.yaw = 0; this.pitch = 0; this.recoilPitch = 0; this.recoilYaw = 0;
      this.radius = 0.32; this.height = 1.8; this.crouch = false; this.crouchT = 0;
      this.hp = 100; this.alive = false; this.onGround = true;
      this.kills = 0; this.deaths = 0; this.hs = 0; this.streak = 0; this.shots = 0; this.hits = 0;
      this.protect = 0; this.deadT = 0; this.spottedUntil = 0; this.lastAttacker = null;
      this.slots = { primary: null, secondary: null, melee: null }; this.cur = 'secondary'; this.primaryId = null;
      this.scoped = false; this.fireFlash = 0; this.moving = 0; this.stepDist = 0;
      this.armor = 0; this.helmet = false; this.money = 800; this.kit = false; this.using = false; this.roundKills = 0;
      this.nades = { he: 0, flash: 0, smoke: 0 }; this.blindT = 0; this.afterThrow = 0; this.throwAnimT = 0;
    }
    get w() { return this.slots[this.cur] || this.slots.secondary || this.slots.melee; }
    // полный набор: основное (может быть null), пистолет, нож
    loadout(primaryId, opts) {
      opts = opts || {};
      this.primaryId = primaryId;
      // сетевой игрок: скины берём из его профиля, присланного при входе
      const sk = (id) => this.skinFor ? this.skinFor(id) : this.isPlayer ? G.equippedSkin(id) : null;
      const wr = (id) => this.wearFor ? this.wearFor(id) : this.isPlayer ? G.equippedWear(id) : 0;
      const kn = this.knifeFor ? this.knifeFor() : this.isPlayer ? G.equippedKnife() : { id: 'knife', skin: null, wear: 0 };
      const sec = opts.secondary || (this.team === 0 ? 'usp' : 'pistol');
      this.slots = {
        primary: primaryId ? G.newWeaponState(primaryId, sk(primaryId), wr(primaryId)) : null,
        secondary: G.newWeaponState(sec, sk(sec), wr(sec)),
        melee: G.newWeaponState(kn.id, kn.skin, kn.wear),
        nade: null
      };
      this.nades = { he: 0, flash: 0, smoke: 0 }; this.afterThrow = 0; this.throwAnimT = 0;
      this.cur = primaryId ? 'primary' : 'secondary';
      this.w.drawT = G.anim ? G.anim.dur('gun_draw') : 0.3;
    }
    give(id) {
      const d = G.WEAPONS[id];
      if (d.nade) { this.nades[id] = 1; this.syncNade(); return; }
      const st = G.newWeaponState(id, this.skinFor ? this.skinFor(id) : this.isPlayer ? G.equippedSkin(id) : null, this.wearFor ? this.wearFor(id) : this.isPlayer ? G.equippedWear(id) : 0);
      this.slots[d.slot] = st;
      if (d.slot === 'primary') this.primaryId = id;
      this.cur = d.slot; st.drawT = 0.4; this.scoped = false;
    }
    // выбранная граната: текущий тип, если остался, иначе первый имеющийся
    syncNade(next) {
      const T = G.NADE_TYPES, cur = this.slots.nade && this.slots.nade.id;
      let pick = null;
      if (next && cur) { const i = T.indexOf(cur); for (let k = 1; k <= T.length; k++) { const t = T[(i + k) % T.length]; if (this.nades[t] > 0) { pick = t; break; } } }
      else if (cur && this.nades[cur] > 0) return;
      else pick = T.find(t => this.nades[t] > 0) || null;
      if (pick && pick === cur && !next) return;
      this.slots.nade = pick ? G.newWeaponState(pick) : null;
    }
    nadeCount() { return (this.nades.he || 0) + (this.nades.flash || 0) + (this.nades.smoke || 0); }
    eyeH() { return this.isPlayer ? (1.62 - 0.47 * this.crouchT) : 1.55; }
    headY() { return 1.62 - 0.47 * this.crouchT; }
    bodyTop() { return 1.48 - 0.45 * this.crouchT; }
    isEnemy(o) { return G.game.isEnemy(this, o); }
    damage(amount, attacker, wid, head, dir) {
      if (!this.alive || this.protect > 0) return false;
      // броня поглощает часть урона (в голову — только со шлемом)
      if (this.armor > 0 && (!head || this.helmet)) {
        const d = G.WEAPONS[wid];
        const pen = d && d.pen ? d.pen : (wid === 'bomb' ? 0.6 : 0.85);
        const absorbed = amount * (1 - pen);
        amount *= pen;
        this.armor = Math.max(0, this.armor - absorbed * 1.6);
      }
      const wasHigh = this.hp >= 35;
      this.hp -= amount;
      this.lastAttacker = attacker; this.lastHitT = G.game.time;
      if (wasHigh && this.hp > 0 && this.hp < 35 && !this.isPlayer) G.chat.event('lowhp', { a: this });
      if (this.onHurt) this.onHurt(attacker, amount, dir);
      G.emit('hurt', { v: this, by: attacker, amt: amount, head: !!head, wid });
      if (this.hp <= 0) { this.hp = 0; G.game.onKill(attacker, this, wid, head, dir); return true; }
      return false;
    }
  }
  G.Actor = Actor;

  // ---------- стрельба ----------
  const _dir = new V3(), _eye = new V3(), _mz = new V3();
  const C = G.combat = {
    dir(yaw, pitch, out) {
      const cp = Math.cos(pitch);
      return out.set(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);
    },
    spread(a, st) {
      const d = st.def;
      if (d.melee) return 0;
      let s = (d.scope && !a.scoped) ? d.spreadNoScope : d.spread;
      const hs = Math.hypot(a.vel.x, a.vel.z);
      s += d.spreadMove * G.clamp((hs - 0.6) / 4.4, 0, 1);
      if (!a.onGround) s += d.spreadJump;
      if (a.crouch) s *= 0.75;
      s += st.heat;
      return Math.min(s, d.spreadMax + d.spread + (d.spreadNoScope || 0));
    },
    trace(shooter, ox, oy, oz, dx, dy, dz, range) {
      const mh = G.map.ray(ox, oy, oz, dx, dy, dz, range);
      let best = mh ? mh.t : range, actor = null, part = null;
      const acts = G.game.actors;
      for (let i = 0; i < acts.length; i++) {
        const a = acts[i];
        if (!a.alive || a === shooter || !G.game.isEnemy(shooter, a)) continue;
        const px = a.pos.x, py = a.pos.y, pz = a.pos.z;
        const qx = px - ox, qz = pz - oz, along = qx * dx + qz * dz;
        if (along < -1) continue;
        const hy = py + a.headY(), hs = 0.19;
        let t = rayAABB(ox, oy, oz, dx, dy, dz, px - hs, hy - hs, pz - hs, px + hs, hy + hs, pz + hs, best);
        if (t !== null && t < best) { best = t; actor = a; part = 'head'; }
        const bt = a.bodyTop(), r = 0.34;
        t = rayAABB(ox, oy, oz, dx, dy, dz, px - r, py, pz - r, px + r, py + bt, pz + r, best);
        if (t !== null && t < best) {
          best = t; actor = a;
          part = (oy + dy * t - py) < bt * 0.55 ? 'legs' : 'body';
        }
      }
      return { t: best, actor, part, map: actor ? null : mh };
    },
    muzzleWorld(a, out) {
      if (a.isPlayer && G.game.vm && G.game.camera && !G.game.spectating) {
        out.set(0.14, -0.13, -0.6);
        return G.game.camera.localToWorld(out);
      }
      const cy = Math.cos(a.yaw), sy = Math.sin(a.yaw);
      return out.set(a.pos.x + cy * 0.14 - sy * 0.75, a.pos.y + 1.28 + Math.sin(a.pitch) * 0.7, a.pos.z - sy * 0.14 - cy * 0.75);
    },
    fire(a, st) {
      const d = st.def, game = G.game;
      _eye.set(a.pos.x, a.pos.y + a.eyeH(), a.pos.z);
      const spread = C.spread(a, st);
      const by = a.yaw + a.recoilYaw, bp = a.pitch + a.recoilPitch;
      const res = { hit: false, head: false, kill: false };
      C.muzzleWorld(a, _mz);
      const pel = d.pellets || 1, ends = [];
      for (let i = 0; i < pel; i++) {
        const ang = Math.random() * Math.PI * 2, r = spread * Math.sqrt(Math.random());
        const pp = bp + Math.sin(ang) * r, yy = by + Math.cos(ang) * r / Math.max(0.3, Math.cos(bp));
        C.dir(yy, pp, _dir);
        const h = C.trace(a, _eye.x, _eye.y, _eye.z, _dir.x, _dir.y, _dir.z, d.range);
        const hx = _eye.x + _dir.x * h.t, hy = _eye.y + _dir.y * h.t, hz = _eye.z + _dir.z * h.t;
        if (h.actor) {
          const mul = h.part === 'head' ? d.head : h.part === 'legs' ? 0.75 : 1;
          const fall = Math.max(0.45, 1 - d.falloff * h.t);
          let dmg = d.dmg * mul * fall;
          if (!a.isPlayer && h.actor.isPlayer) dmg *= a.diffP ? a.diffP.dmgMul : 1;
          G.fx.blood(hx, hy, hz, _dir.x, _dir.y, _dir.z, h.part === 'head');
          const killed = h.actor.damage(dmg, a, d.id, h.part === 'head', _dir.clone());
          res.hit = true; if (h.part === 'head') res.head = true; if (killed) res.kill = true;
          if (a.isPlayer) G.audio.flesh(h.actor.pos);
        } else if (h.map) {
          G.fx.impact(hx, hy, hz, h.map.nx, h.map.ny, h.map.nz);
          if (i === 0) G.audio.ricochet({ x: hx, z: hz });
        }
        if (i === 0 || Math.random() < 0.35) {
          if (a.isPlayer || Math.random() < 0.7) G.fx.tracer(_mz.x, _mz.y, _mz.z, hx, hy, hz);
        }
        if (ends.length < 9) ends.push(+hx.toFixed(2), +hy.toFixed(2), +hz.toFixed(2), h.actor ? 1 : 0);
      }
      G.emit('shot', { a, w: d.id, mz: [+_mz.x.toFixed(2), +_mz.y.toFixed(2), +_mz.z.toFixed(2)], ends });
      st.heat += d.spreadShot;
      a.shots++; if (res.hit) a.hits++;
      a.fireFlash = 0.06;
      if (a.protect > 0) a.protect = 0;
      game.onNoise(a, a.pos.x, a.pos.z, d.silenced ? 16 : 38);
      return res;
    },
    melee(a, st) {
      const d = st.def, game = G.game;
      _eye.set(a.pos.x, a.pos.y + a.eyeH(), a.pos.z);
      C.dir(a.yaw, a.pitch, _dir);
      let best = null, bd = 1e9;
      for (const o of game.actors) {
        if (!o.alive || o === a || !game.isEnemy(a, o)) continue;
        const dx = o.pos.x - _eye.x, dz = o.pos.z - _eye.z, dist = Math.hypot(dx, dz);
        if (dist > d.range + 0.3) continue;
        const cos = (dx * _dir.x + dz * _dir.z) / (dist * Math.hypot(_dir.x, _dir.z) + 1e-6);
        if (cos < 0.75 || Math.abs(o.pos.y - a.pos.y) > 1.2) continue;
        if (!G.map.clear(_eye.x, _eye.y, _eye.z, o.pos.x, o.pos.y + 1.1, o.pos.z)) continue;
        if (dist < bd) { bd = dist; best = o; }
      }
      const res = { hit: false, head: false, kill: false };
      a.fireFlash = 0;
      G.emit('melee', { a, w: d.id });
      if (best) {
        const fx = -Math.sin(best.yaw), fz = -Math.cos(best.yaw);
        const back = (_dir.x * fx + _dir.z * fz) > 0.5;
        const head = a.pitch > 0.05 && bd < 1.6;
        const dmg = d.dmg * (back ? 2 : 1) * (head ? 1.3 : 1);
        G.fx.blood(best.pos.x, best.pos.y + 1.2, best.pos.z, _dir.x, 0.2, _dir.z, false);
        res.kill = best.damage(dmg, a, d.id, head, _dir.clone());
        res.hit = true; res.head = head;
        G.audio.flesh(best.pos);
      } else {
        const h = G.map.ray(_eye.x, _eye.y, _eye.z, _dir.x, _dir.y, _dir.z, d.range);
        if (h) G.fx.impact(_eye.x + _dir.x * h.t, _eye.y + _dir.y * h.t, _eye.z + _dir.z * h.t, h.nx, h.ny, h.nz);
      }
      if (a.protect > 0) a.protect = 0;
      return res;
    },
    startReload(a, st) {
      const d = st.def;
      if (d.melee || d.nade || st.reloadT > 0 || st.mag >= d.mag) return false;
      if (a.isPlayer && st.reserve <= 0) return false;
      st.reloadT = d.reload;
      if (a.isPlayer) { a.scoped = false; G.audio.reload(d.id); if (G.net && G.net.active && a === G.game.player) G.net.send({ t: 'rl', s: a.cur }); }
      return true;
    },
    tick(a, st, dt, wantFire) {
      const d = st.def;
      st.cd -= dt; st.drawT -= dt;
      if (d.nade) {
        // замах, затем граната вылетает из руки
        if (st.throwT > 0) {
          st.throwT -= dt;
          if (st.throwT <= 0) { G.nades.throwFrom(a, d.nade); a.nades[d.nade] = Math.max(0, (a.nades[d.nade] || 0) - 1); a.afterThrow = 0.45; G.game.onNoise(a, a.pos.x, a.pos.z, 10); }
          return null;
        }
        if (!wantFire || st.cd > 0 || st.drawT > 0 || a.afterThrow > 0 || !(a.nades[d.nade] > 0)) return null;
        st.throwT = 0.3; st.cd = 1; a.throwAnimT = G.anim.dur('nade_throw');
        if (a.protect > 0) a.protect = 0;
        return { nade: true };
      }
      st.heat *= Math.exp(-dt * 5.5);
      if (st.reloadT > 0) {
        st.reloadT -= dt;
        if (st.reloadT <= 0) {
          st.reloadT = 0;
          if (a.isPlayer) { const take = Math.min(d.mag - st.mag, st.reserve); st.mag += take; st.reserve -= take; }
          else st.mag = d.mag;
        }
        return null;
      }
      if (!wantFire || st.cd > 0 || st.drawT > 0) return null;
      const online = G.net && G.net.active && a === G.game.player;
      if (d.melee) { st.cd = d.rate; G.audio.shot('knife', a.isPlayer ? null : a.pos); if (!a.isPlayer) a.swingT = 0.35; return online ? G.net.melee(a, st) : C.melee(a, st); }
      if (st.mag <= 0) {
        if (!C.startReload(a, st) && a.isPlayer) { G.audio.click(); st.cd = 0.3; }
        return null;
      }
      st.mag--; st.cd = d.rate;
      G.audio.shot(d.sound, a.isPlayer ? null : a.pos);
      const r = online ? G.net.fire(a, st) : C.fire(a, st);
      a.recoilPitch = Math.min(0.14, a.recoilPitch + d.recoil * (0.8 + Math.random() * 0.4));
      // горизонтальный увод — плавная «змейка» вместо случайных рывков
      a.sprayN = a.recoilPitch < 0.006 ? 0 : (a.sprayN || 0) + 1;
      a.recoilYaw += (Math.sin(a.sprayN * 0.85 + (a.sprayS || 0)) * 0.75 + (Math.random() - 0.5) * 0.5) * d.recoilYaw;
      if (a.sprayN === 0) a.sprayS = Math.random() * 6.28;
      if (st.mag === 0 && (!a.isPlayer || st.reserve > 0)) { a.autoReload = 0.25; }
      return r;
    }
  };

  // ---------- модели ботов: человек в бронежилете, суставы, снаряжение команды ----------
  const geoCache = {};
  function botGeos(team, wid) {
    const key = team + '_' + wid;
    if (geoCache[key]) return geoCache[key];
    const T = G.TEAMS[team], box = G.geo.box, { bone, blob, ring } = G.mk;
    const HP = Math.PI / 2, DARK = '#1c1e21', GLOVE = '#26292d', BOOT = '#2a2522';
    let cache = geoCache['body' + team];
    if (!cache) {
      const P = [];
      // торс: силуэт спереди с широкими плечами (профиль, повёрнутый боком к камере)
      P.push({ shape: true, pts: [[-0.17, 0.9], [0.17, 0.9], [0.19, 1.05], [0.23, 1.28], [0.26, 1.4], ['q', 0.24, 1.47, 0.1, 1.48], [-0.1, 1.48], ['q', -0.24, 1.47, -0.26, 1.4], [-0.23, 1.28], [-0.19, 1.05]], d: 0.25, bevel: 0.03, bseg: 2, ry: -HP, color: T.uniform });
      // бронежилет, подсумки, рация, ремень
      P.push({ shape: true, pts: [[-0.205, 0.98], [0.205, 0.98], [0.24, 1.25], [0.205, 1.42], [0.1, 1.45], [-0.1, 1.45], [-0.205, 1.42], [-0.24, 1.25]], d: 0.31, bevel: 0.02, ry: -HP, color: T.vest });
      for (const x of [-0.1, 0, 0.1]) P.push(box(0.085, 0.11, 0.05, x, 1.08, -0.18, T.vest), box(0.088, 0.03, 0.054, x, 1.14, -0.182, DARK));
      P.push(box(0.15, 0.08, 0.04, -0.06, 1.3, -0.178, T.vest), box(0.06, 0.13, 0.08, 0.245, 1.14, 0.0, DARK), { cyl: true, r: 0.006, h: 0.12, x: 0.25, y: 1.25, z: 0.02, color: DARK, seg: 6 });
      P.push(box(0.2, 0.26, 0.05, 0, 1.18, 0.18, T.vest), box(0.4, 0.05, 0.28, 0, 0.93, 0, DARK), box(0.05, 0.04, 0.02, 0, 0.93, -0.145, '#8a8a7a'));
      P.push(box(0.38, 0.18, 0.26, 0, 0.85, 0, T.pants));
      // шея и голова
      P.push({ cyl: true, r: 0.055, h: 0.1, x: 0, y: 1.51, z: 0, color: T.skin, seg: 10 });
      blob(P, [0, 1.62, 0], [1, 0, 0], [0, 1, 0], 0.108, 0.125, 0.115, T.skin, { seg: 14 });
      blob(P, [0, 1.59, -0.1], [1, 0, 0], [0, 1, 0], 0.022, 0.03, 0.02, T.skin, { seg: 8 }); // нос
      if (team === 0) {
        // шлем с ободом, очки на ремешке, балаклава
        P.push({ sph: true, r: 0.138, sy: 0.82, x: 0, y: 1.672, z: 0.005, color: T.helm, seg: 16 });
        ring(P, [0, 1.63, 0.005], [0, 1, 0], 0.132, 0.012, T.helm);
        ring(P, [0, 1.66, 0.0], [0, 1, 0], 0.122, 0.009, DARK);
        P.push(box(0.16, 0.045, 0.03, 0, 1.645, -0.112, '#121417'), box(0.06, 0.032, 0.01, -0.038, 1.645, -0.128, '#3a6e9e'), box(0.06, 0.032, 0.01, 0.038, 1.645, -0.128, '#3a6e9e'));
        blob(P, [0, 1.565, -0.03], [1, 0, 0], [0, 1, 0], 0.1, 0.075, 0.09, '#2c3036', { seg: 12 });
        P.push(box(0.04, 0.16, 0.02, 0.17, 1.28, -0.16, '#4aa8ff'));
      } else {
        // шапка, платок на лице, тёмные очки
        P.push({ sph: true, r: 0.122, sy: 0.66, x: 0, y: 1.692, z: 0.005, color: T.helm, seg: 14 });
        ring(P, [0, 1.665, 0.005], [0, 1, 0], 0.116, 0.014, T.helm);
        blob(P, [0, 1.565, -0.02], [1, 0, 0], [0, 1, 0], 0.104, 0.075, 0.098, '#a8925f', { seg: 12 });
        P.push(box(0.17, 0.028, 0.02, 0, 1.633, -0.11, '#0e0e0e'));
        P.push(box(0.04, 0.16, 0.02, 0.17, 1.28, -0.16, '#ff7a3d'));
      }
      // нога от бедра: бедро + наколенник (голень — отдельная деталь для сгиба колена)
      const thigh = [], shin = [];
      bone(thigh, [0, 0.03, 0], [0, -0.42, -0.01], 0.104, 0.082, T.pants);
      blob(thigh, [0, -0.42, -0.07], [1, 0, 0], [0, 1, 0], 0.068, 0.07, 0.038, DARK);
      thigh.push(box(0.075, 0.1, 0.045, -0.1, -0.18, -0.01, T.vest)); // набедренный подсумок
      bone(shin, [0, 0, 0], [0, -0.37, 0.015], 0.08, 0.066, T.pants);
      shin.push(box(0.145, 0.13, 0.28, 0, -0.415, -0.04, BOOT), box(0.15, 0.03, 0.29, 0, -0.475, -0.04, '#151312'));
      cache = geoCache['body' + team] = { body: G.geo.build(P), thigh: G.geo.build(thigh), shin: G.geo.build(shin) };
    }
    // руки с оружием (группа прицеливания на высоте плеч)
    const gp = G.gunParts(wid);
    const gx = 0.1, gy = -0.17, gz = -0.34;
    const arms = [];
    const src = gp.body.concat(gp.mag, gp.slide || [], gp.pump || []).filter(p => !p.em);
    for (const p of src) { const q = Object.assign({}, p); q.x = (p.x || 0) + gx; q.y = (p.y || 0) + gy; q.z = (p.z || 0) + gz; arms.push(q); }
    const rh = [gx + gp.rh[0] + 0.02, gy + gp.rh[1], gz + gp.rh[2]];
    const lh = gp.lh ? [gx + gp.lh[0] - 0.02, gy + gp.lh[1] - 0.02, gz + gp.lh[2]] : [-0.08, -0.22, -0.2];
    const shR = [0.235, 0.02, 0.0], shL = [-0.235, 0.02, 0.0];
    const elR = [0.27, -0.23, -0.1], elL = [-0.21, -0.22, -0.22];
    bone(arms, shR, elR, 0.074, 0.064, T.uniform); bone(arms, elR, rh, 0.06, 0.05, T.uniform);
    bone(arms, shL, elL, 0.074, 0.064, T.uniform); bone(arms, elL, lh, 0.06, 0.05, T.uniform);
    arms.push({ sph: true, r: 0.075, sy: 0.8, x: shR[0], y: shR[1] + 0.02, z: 0, color: T.vest, seg: 10 }, { sph: true, r: 0.075, sy: 0.8, x: shL[0], y: shL[1] + 0.02, z: 0, color: T.vest, seg: 10 });
    arms.push({ sph: true, r: 0.056, x: rh[0], y: rh[1], z: rh[2], color: GLOVE, seg: 10 }, { sph: true, r: 0.056, x: lh[0], y: lh[1], z: lh[2], color: GLOVE, seg: 10 });
    const res = { body: cache.body, thigh: cache.thigh, shin: cache.shin, arms: G.geo.build(arms), muzzle: [gx + gp.muzzle[0], gy + gp.muzzle[1], gz + gp.muzzle[2]] };
    geoCache[key] = res;
    return res;
  }

  let blobMat = null, flashMat = null, packGeo = null;
  class Bot extends Actor {
    constructor(name, team, scene) {
      super(name, team, false);
      this.scene = scene;
      this.root = new THREE.Group();
      this.root.rotation.order = 'YXZ';
      this.root.visible = false;
      if (scene) scene.add(this.root);
      this.diffP = G.DIFF[G.settings.difficulty] || G.DIFF.normal;
      this.resetAI();
    }
    buildModel(wid) {
      if (G.HEADLESS) { this.modelW = wid; this.modelTeam = this.team; return; }
      const r = this.root;
      while (r.children.length) r.remove(r.children[0]);
      const g = botGeos(this.visTeam != null ? this.visTeam : this.team, wid), mat = G.getVCMat();
      this.bodyMesh = new THREE.Mesh(g.body, mat);
      this.legL = new THREE.Group(); this.legR = new THREE.Group();
      this.legL.position.set(-0.095, 0.88, 0); this.legR.position.set(0.095, 0.88, 0);
      for (const leg of [this.legL, this.legR]) {
        leg.add(new THREE.Mesh(g.thigh, mat));
        const shin = new THREE.Group(); shin.position.set(0, -0.42, -0.01); shin.add(new THREE.Mesh(g.shin, mat));
        leg.add(shin); leg.userData.shin = shin;
      }
      this.aim = new THREE.Group(); this.aim.position.set(0, 1.4, 0);
      this.aim.add(new THREE.Mesh(g.arms, mat));
      if (!flashMat) flashMat = new THREE.SpriteMaterial({ map: G.tex('flare'), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, fog: false });
      this.flash = new THREE.Sprite(flashMat);
      this.flash.position.set(g.muzzle[0], g.muzzle[1], g.muzzle[2] - 0.05);
      this.flash.scale.set(0.45, 0.45, 1); this.flash.visible = false;
      this.aim.add(this.flash);
      this.body = new THREE.Group();
      this.body.add(this.bodyMesh, this.legL, this.legR, this.aim);
      // ранец с бомбой
      if (!packGeo) packGeo = G.geo.build([G.geo.box(0.3, 0.2, 0.1, 0, 1.2, 0.29, '#3a3f2a'), G.geo.box(0.12, 0.05, 0.02, 0, 1.25, 0.345, '#b8392a')]);
      this.pack = new THREE.Mesh(packGeo, mat); this.pack.visible = !!this.hasBomb;
      this.body.add(this.pack);
      r.add(this.body);
      if (!blobMat) blobMat = new THREE.MeshBasicMaterial({ map: G.tex('blob'), transparent: true, depthWrite: false });
      const blob = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.1), blobMat);
      blob.rotation.x = -Math.PI / 2; blob.position.y = 0.03; blob.renderOrder = 1;
      r.add(blob);
      if (this.label) r.add(this.label);
      this.modelW = wid; this.modelTeam = this.team;
    }
    setLabel(show) {
      if (G.HEADLESS) return;
      if (show && !this.label) {
        const t = G.T.label(this.name, '#9fd2ff');
        this.label = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: true, transparent: true, fog: false, sizeAttenuation: false }));
        this.label.scale.set(0.16, 0.04, 1); this.label.position.y = 2.2;
        this.root.add(this.label);
      } else if (!show && this.label) { this.root.remove(this.label); this.label = null; }
    }
    resetAI() {
      this.path = null; this.pi = 0; this.goal = null; this.target = null; this.tVisible = false;
      this.react = 0; this.lastSeen = -99; this.seenPos = new V3(); this.alertPos = null; this.alertT = -99;
      this.perceiveT = Math.random() * 0.2; this.strafeDir = 1; this.strafeT = 0; this.burstT = 0; this.pauseT = 0;
      this.err = new V3(1, 0, 0); this.errMag = 1; this.stuckT = 0; this.lastPos = new V3(); this.repathT = 0;
      this.waitT = 0; this.wantFire = false; this.aimHead = false; this.stopToShoot = false; this.walkPhase = 0;
      this.lookOffT = 0; this.lookOff = 0; this.swingT = 0; this.visYaw = this.yaw; this.calloutT = 0; this.turnTo = null;
      this.using = false; this.obj = null;
    }
    onHurt(attacker) {
      if (!attacker || attacker === this) return;
      if (!this.tVisible) {
        this.alertPos = attacker.pos.clone(); this.alertT = G.game.time;
        this.turnTo = Math.atan2(-(attacker.pos.x - this.pos.x), -(attacker.pos.z - this.pos.z));
        this.react = Math.min(this.react, this.diffP.react * 0.6);
      }
    }
    hear(x, z) {
      if (this.tVisible) return;
      if (G.game.time - this.alertT < 1.5) return;
      this.alertPos = new V3(x + G.rand(-3, 3), 0, z + G.rand(-3, 3)); this.alertT = G.game.time;
      this.path = null;
    }
    perceive() {
      const P = this.diffP, game = G.game;
      if (this.blindT > 0.25) { this.tVisible = false; return; }
      let best = null, bd = 1e9;
      const ex = this.pos.x, ey = this.pos.y + this.eyeH(), ez = this.pos.z;
      const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
      for (const o of game.actors) {
        if (!o.alive || !game.isEnemy(this, o)) continue;
        const dx = o.pos.x - ex, dz = o.pos.z - ez, d = Math.hypot(dx, dz);
        if (d > P.sight) continue;
        const current = (o === this.target && this.tVisible);
        if (d > 3.5 && !current && (dx * fx + dz * fz) / d < P.fovCos) continue;
        const vis = G.map.clear(ex, ey, ez, o.pos.x, o.pos.y + o.headY(), o.pos.z) ||
          G.map.clear(ex, ey, ez, o.pos.x, o.pos.y + 0.95, o.pos.z);
        if (!vis || G.nades.blocks(ex, ey, ez, o.pos.x, o.pos.y + 1.2, o.pos.z)) continue;
        const score = d - (o === this.target ? 6 : 0) - (o.isPlayer ? 2 : 0);
        if (score < bd) { bd = score; best = o; }
      }
      if (best) {
        if (best !== this.target || !this.tVisible) {
          const recent = best === this.target && game.time - this.lastSeen < 1.5;
          this.react = P.react * G.rand(0.75, 1.3) * (recent ? 0.35 : 1);
          this.errMag = P.err0 * G.rand(0.8, 1.25);
          this.err.set(G.rand(-1, 1), G.rand(-0.7, 0.7), G.rand(-1, 1)).normalize();
          this.aimHead = Math.random() < P.headChance;
          this.burstT = 0; this.pauseT = 0;
        }
        this.target = best; this.tVisible = true; this.lastSeen = game.time; this.seenPos.copy(best.pos);
        best.spottedUntil = game.time + 1.2;
        best.spottedBy = this.team;
        if (game.mode === 'bomb') G.bombMode.spotted(this, best);
        if (game.mode !== 'ffa' && game.time > this.calloutT) {
          this.calloutT = game.time + 3;
          for (const m of game.actors) {
            if (m === this || m.isPlayer || !m.alive || m.team !== this.team || m.tVisible || m.using) continue;
            if (m.pos.distanceTo(this.pos) < 28 && Math.random() < 0.5) { m.alertPos = best.pos.clone(); m.alertT = game.time; m.path = null; }
          }
        }
      } else this.tVisible = false;
    }
    // когда и куда бросать гранаты
    thinkNade() {
      const g = G.game, n = this.nades, t = this.target, N = G.nades;
      if (!n || !(n.he || n.flash || n.smoke)) return;
      const dist = (p) => Math.hypot(p.x - this.pos.x, p.z - this.pos.z);
      // осколочная: противник спрятался за укрытием — выкурить его
      if (n.he > 0 && t && t.alive && !this.tVisible && g.time - this.lastSeen > 0.5 && g.time - this.lastSeen < 5) {
        const d = dist(this.seenPos);
        if (d > 6 && d < 30 && Math.random() < 0.55 && N.throwAt(this, 'he', this.seenPos.x, 0.2, this.seenPos.z)) return;
      }
      if (n.he > 0 && this.tVisible && t && Math.random() < 0.06) {
        const d = dist(t.pos);
        if (d > 12 && d < 28 && N.throwAt(this, 'he', t.pos.x, 0.2, t.pos.z)) return;
      }
      // ослепляющая — перед тем как зайти туда, где был враг или шум
      if (n.flash > 0 && !this.tVisible) {
        const tp = (t && g.time - this.lastSeen < 6) ? this.seenPos : (this.alertPos && g.time - this.alertT < 6 ? this.alertPos : null);
        if (tp) { const d = dist(tp); if (d > 7 && d < 26 && Math.random() < 0.4 && N.throwAt(this, 'flash', tp.x, 1.6, tp.z)) return; }
      }
      // режим бомбы: дым и вспышка при заходе на точку, гранаты при отбитии точки
      if (g.mode === 'bomb') {
        const sp = n.smoke > 0 ? G.bombMode.smokeSpot(this) : null;
        if (sp) { const d = dist(sp); if (d > 7 && d < 30 && N.throwAt(this, 'smoke', sp.x, 0.1, sp.z)) { sp.used = true; return; } }
        const ns = G.bombMode.nadeSpot(this);
        if (ns && n[ns.type] > 0) { const d = dist(ns); if (d > 8 && d < 28 && N.throwAt(this, ns.type, ns.x, ns.y, ns.z)) { this.entryNade = true; return; } }
      }
    }
    pickGoal() {
      const game = G.game;
      let f = null;
      if (game.mode === 'tdm') {
        const r = Math.random(), enemyZ = this.team === 0 ? -1 : 1;
        if (r < 0.55) f = (x, z) => Math.abs(z) < 13;
        else if (r < 0.85) f = (x, z) => z * enemyZ > 14;
        else f = (x, z) => z * enemyZ < -14;
      }
      const p = G.nav.randomPoint(f);
      this.goal = new V3(p.x, 0, p.z);
      this.path = null;
    }
    followPath(gx, gz) {
      if (!this.path || this.repathT <= 0 || !this.pathGoal || Math.abs(this.pathGoal.x - gx) + Math.abs(this.pathGoal.z - gz) > 3) {
        this.path = G.nav.findPath(this.pos.x, this.pos.z, gx, gz);
        this.pi = 0; this.repathT = 3; this.pathGoal = { x: gx, z: gz };
        if (!this.path) return null;
      }
      while (this.pi < this.path.length) {
        const wp = this.path[this.pi];
        const dx = wp.x - this.pos.x, dz = wp.z - this.pos.z, d = Math.hypot(dx, dz);
        if (d < 0.55) { this.pi++; continue; }
        return [dx / d, dz / d];
      }
      this.path = null;
      return null;
    }
    turnToward(yaw, pitch, rate, dt) {
      const dy = G.angleDiff(this.yaw, yaw), mx = rate * dt;
      this.yaw += G.clamp(dy, -mx, mx);
      if (pitch != null) this.pitch += G.clamp(pitch - this.pitch, -mx, mx);
    }
    update(dt) {
      const game = G.game, P = this.diffP;
      // сетевой персонаж: положение уже выставил модуль сети — только анимация
      if (this.puppet) {
        if (!this.alive) { this.updateDead(dt); return; }
        this.protect = 0;
        if (this.swingT > 0) this.swingT -= dt;
        this.stepDist += Math.hypot(this.vel.x, this.vel.z) * dt;
        if (this.stepDist > 2.1) { this.stepDist = 0; if (Math.hypot(this.vel.x, this.vel.z) > 2.5) G.audio.step(this.pos, 0.45); }
        this.animate(dt);
        return;
      }
      if (!this.alive) { this.updateDead(dt); return; }
      if (this.dummy) { this.protect = Math.max(0, this.protect - dt); this.vel.y -= 22 * dt; G.map.move(this, 0, this.vel.y * dt, 0); this.moving = 0; this.animate(dt); return; }
      const frozen = game.frozen;
      this.protect = Math.max(0, this.protect - dt);
      this.repathT -= dt;
      this.perceiveT -= dt;
      if (this.blindT > 0) this.blindT -= dt;
      if (this.perceiveT <= 0) { this.perceiveT = 0.12 + Math.random() * 0.06; this.perceive(); }
      this.nadeT = (this.nadeT || 0) - dt;
      if (this.nadeT <= 0 && !frozen && !this.using && this.blindT <= 0) { this.nadeT = 0.6 + Math.random() * 0.4; this.thinkNade(); }
      if (this.target && !this.target.alive) { this.target = null; this.tVisible = false; }
      let mx = 0, mz = 0, spd = 0;
      this.wantFire = false;
      const st = this.w;
      // задача режима (закладка / разминирование / удержание точки)
      const obj = game.mode === 'bomb' ? G.bombMode.botGoal(this) : null;
      // почти разминировали — не отвлекаемся
      const committed = this.using && obj && obj.act === 'defuse' && G.bombMode.defuseLeft() < 1.6;
      if (this.tVisible && this.target && !committed && !frozen) {
        this.using = false;
        const t = this.target;
        this.errMag = Math.max(P.errMin, this.errMag * Math.exp(-P.settle * dt));
        if (Math.random() < dt * 0.8) this.err.set(G.rand(-1, 1), G.rand(-0.7, 0.7), G.rand(-1, 1)).normalize();
        const tv = Math.hypot(t.vel.x, t.vel.z);
        const em = this.errMag + tv * 0.045 + this.moving * 0.05;
        const ay = this.aimHead ? t.pos.y + t.headY() : t.pos.y + t.bodyTop() * 0.7;
        const ax = t.pos.x + this.err.x * em, az = t.pos.z + this.err.z * em, ayy = ay + this.err.y * em * 0.6;
        const dx = ax - this.pos.x, dz = az - this.pos.z, dyy = ayy - (this.pos.y + this.eyeH()), dh = Math.hypot(dx, dz);
        const wy = Math.atan2(-dx, -dz), wp = Math.atan2(dyy, dh);
        this.turnToward(wy, wp, P.turn, dt);
        this.react -= dt;
        const off = Math.abs(G.angleDiff(this.yaw, wy)) + Math.abs(wp - this.pitch);
        if (this.react <= 0 && off < 0.14) {
          if (st.def.id === 'sniper' || st.def.id === 'magnum') this.wantFire = true;
          else if (this.burstT > 0) { this.wantFire = true; this.burstT -= dt; if (this.burstT <= 0) this.pauseT = G.rand(P.pause[0], P.pause[1]); }
          else if (this.pauseT > 0) { this.pauseT -= dt; if (this.pauseT <= 0) this.burstT = G.rand(P.burst[0], P.burst[1]); }
          else this.burstT = G.rand(P.burst[0], P.burst[1]);
        }
        this.strafeT -= dt;
        if (this.strafeT <= 0) { this.strafeT = G.rand(0.35, 1.3); this.strafeDir = Math.random() < 0.5 ? -1 : 1; this.stopToShoot = Math.random() < P.stopChance; }
        const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw), fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        mx = rx * this.strafeDir; mz = rz * this.strafeDir;
        const id = st.def.id, pref = id === 'shotgun' ? 5 : id === 'smg' ? 11 : id === 'sniper' ? 28 : (st.def.slot === 'secondary' ? 12 : 16);
        if (dh > pref + 8) { mx += fx * 1.3; mz += fz * 1.3; } else if (dh < pref * 0.4) { mx -= fx * 0.7; mz -= fz * 0.7; }
        spd = (this.wantFire && this.stopToShoot) ? 0 : 0.62;
        if (st.reloadT > 0) { spd = 0.8; mx -= fx * 0.6; mz -= fz * 0.6; }
        this.path = null; this.turnTo = null;
      } else if (frozen) {
        // заморозка в начале раунда: стоим, оглядываемся
        this.turnToward(this.yaw, 0, 1, dt);
      } else {
        let gx = null, gz = null, hold = false, look = null;
        if (obj) {
          gx = obj.x; gz = obj.z; hold = !!obj.hold; look = obj.look;
          // недавний шум рядом важнее удержания позиции
          if (this.alertPos && game.time - this.alertT < 4 && obj.act == null && this.pos.distanceTo(this.alertPos) < 16 && !obj.urgent) {
            gx = this.alertPos.x; gz = this.alertPos.z; hold = false;
          }
        } else if (this.target && game.time - this.lastSeen < 7) { gx = this.seenPos.x; gz = this.seenPos.z; }
        else if (this.alertPos && game.time - this.alertT < 9) { gx = this.alertPos.x; gz = this.alertPos.z; }
        else {
          this.target = null; this.alertPos = null;
          if (!this.goal) this.pickGoal();
          gx = this.goal.x; gz = this.goal.z;
        }
        const distGoal = Math.hypot(gx - this.pos.x, gz - this.pos.z);
        if (obj && obj.act && distGoal < (obj.act === 'defuse' ? 1.1 : 0.9)) {
          this.using = true; spd = 0; // закладываем / разминируем
          if (obj.look != null) this.turnToward(obj.look, -0.5, P.turn, dt);
        } else {
          this.using = false;
          if (this.waitT > 0) { this.waitT -= dt; }
          else if (hold && distGoal < 1.2) { /* стоим на позиции */ }
          else {
            const dir = this.followPath(gx, gz);
            if (dir) { mx = dir[0]; mz = dir[1]; spd = (obj && obj.walk) ? 0.55 : 0.9; }
            else if (!obj) {
              if (this.target && game.time - this.lastSeen < 7) this.lastSeen = -99;
              else if (this.alertPos) this.alertPos = null;
              else { this.goal = null; this.waitT = G.rand(0.3, 1.6); }
            } else if (this.alertPos && gx === this.alertPos.x) this.alertPos = null;
          }
        }
        if (!this.using) {
          let ly;
          if (this.turnTo != null) { ly = this.turnTo; if (Math.abs(G.angleDiff(this.yaw, ly)) < 0.1) this.turnTo = null; }
          else if (spd > 0) ly = Math.atan2(-mx, -mz);
          else {
            this.lookOffT -= dt;
            if (this.lookOffT <= 0) { this.lookOffT = G.rand(0.8, 2); this.lookOff = (look != null ? look : this.yaw) + G.rand(-0.9, 0.9); }
            ly = this.lookOff;
          }
          if (spd > 0 && this.alertPos && game.time - this.alertT < 9) {
            const ax = this.alertPos.x - this.pos.x, az = this.alertPos.z - this.pos.z;
            if (Math.hypot(ax, az) < 14) ly = Math.atan2(-ax, -az);
          }
          this.turnToward(ly, 0, this.turnTo != null ? P.turn * 1.4 : P.turn * 0.55, dt);
        }
        this.stuckT += dt;
        if (this.stuckT > 1.5) {
          if (spd > 0 && this.lastPos.distanceTo(this.pos) < 0.5) { this.path = null; this.goal = null; this.alertPos = null; this.waitT = 0; }
          this.lastPos.copy(this.pos); this.stuckT = 0;
        }
      }
      const len = Math.hypot(mx, mz);
      if (len > 1) { mx /= len; mz /= len; }
      const speed = frozen ? 0 : st.def.speed * 0.9 * spd;
      const k = G.damp(this.onGround ? 10 : 2, dt);
      this.vel.x += (mx * speed - this.vel.x) * k;
      this.vel.z += (mz * speed - this.vel.z) * k;
      this.vel.y -= 22 * dt;
      G.map.move(this, this.vel.x * dt, this.vel.y * dt, this.vel.z * dt);
      const hs = Math.hypot(this.vel.x, this.vel.z);
      this.moving = G.clamp(hs / 4, 0, 1);
      this.stepDist += hs * dt;
      if (this.stepDist > 2.1) {
        this.stepDist = 0;
        if (game.player && hs > 2.5) G.audio.step(this.pos, 0.45);
      }
      if (this.autoReload > 0) { this.autoReload -= dt; if (this.autoReload <= 0) G.combat.startReload(this, st); }
      if (st.mag <= 0 && st.reloadT <= 0) G.combat.startReload(this, st);
      G.combat.tick(this, st, dt, this.wantFire && !frozen && !this.using && this.blindT <= 0.25);
      this.recoilPitch *= Math.exp(-dt * 10); this.recoilYaw *= Math.exp(-dt * 10);
      this.animate(dt);
    }
    animate(dt) {
      if (G.HEADLESS) { this.fireFlash -= dt; return; }
      const r = this.root;
      r.position.copy(this.pos);
      this.visYaw += G.angleDiff(this.visYaw, this.yaw) * G.damp(18, dt);
      r.rotation.set(0, this.visYaw, 0);
      this.aim.rotation.x = this.using ? -0.7 : this.pitch;
      this.walkPhase += Math.hypot(this.vel.x, this.vel.z) * dt * 2.3;
      const ph = this.walkPhase, mv = this.moving;
      const sw = Math.sin(ph) * 0.6 * mv;
      this.legL.rotation.x = sw; this.legR.rotation.x = -sw;
      // колено сгибается, когда нога уходит назад
      this.legL.userData.shin.rotation.x = -Math.max(0, Math.sin(ph - 1.3)) * 0.85 * mv - (this.using ? 1.4 : 0);
      this.legR.userData.shin.rotation.x = -Math.max(0, Math.sin(ph + Math.PI - 1.3)) * 0.85 * mv - (this.using ? 1.4 : 0);
      if (this.using) { this.legL.rotation.x = 0.75; this.legR.rotation.x = 0.75; }
      this.body.position.y = Math.abs(Math.cos(ph)) * 0.035 * mv - (this.using ? 0.36 : 0);
      this.body.rotation.y = Math.sin(ph) * 0.06 * mv;
      const st = this.w, rl = st && st.reloadT > 0;
      this.aim.position.z = rl ? 0.05 : 0;
      this.aim.rotation.z = rl ? 0.35 : 0;
      this.fireFlash -= dt;
      this.flash.visible = this.fireFlash > 0;
      if (this.flash.visible) this.flash.material.rotation = Math.random() * 6;
      this.pack.visible = !!this.hasBomb;
      this.body.visible = this.protect > 0 ? (Math.floor(G.game.time * 10) % 2 === 0) : true;
    }
    updateDead(dt) {
      this.deadT += dt;
      const r = this.root;
      if (G.HEADLESS) { if (this.deadT > 3.5 && G.game.canRespawn(this)) G.game.respawn(this); return; }
      if (r.visible && this.body) this.deadPose();
      if (this.puppet) return; // сетевой персонаж: возрождает сервер
      if (this.deadT > 3.5) { if (this.dummy) G.tutorial.respawnDummy(this); else if (G.game.canRespawn(this)) G.game.respawn(this); }
    }
    deadPose() {
      const r = this.root, t = this.deadT, buckle = Math.min(1, t / 0.22), k = G.clamp((t - 0.12) / 0.45, 0, 1), e = k * k * (3 - 2 * k);
      this.legL.rotation.x = this.legR.rotation.x = 0.9 * buckle * (1 - e * 0.6);
      this.legL.userData.shin.rotation.x = this.legR.userData.shin.rotation.x = -1.5 * buckle * (1 - e * 0.7);
      this.body.position.y = -0.32 * buckle * (1 - e * 0.5);
      this.aim.rotation.x = -0.4 - 0.8 * e; this.aim.rotation.z = this.fallSide * 0.6 * e;
      r.rotation.x = this.fallDir * (Math.PI / 2) * e;
      r.rotation.z = this.fallSide * 0.35 * e;
      this.flash.visible = false;
      if (this.deadT > 2.6) r.position.y = this.pos.y - (this.deadT - 2.6) * 0.8;
      if (this.deadT > 3.4) r.visible = false;
    }
    die(dir) {
      this.alive = false; this.deadT = 0; this.using = false;
      if (dir) {
        const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        this.fallDir = (dir.x * fx + dir.z * fz) > 0 ? -1 : 1;
      } else this.fallDir = 1;
      this.fallSide = Math.random() < 0.5 ? -1 : 1;
      if (G.HEADLESS || !this.body) return;
      this.body.visible = true; this.body.rotation.y = 0;
      this.legL.rotation.x = 0; this.legR.rotation.x = 0;
      if (this.label) this.label.visible = false;
    }
    spawned() {
      this.resetAI();
      this.visYaw = this.yaw;
      this.root.visible = true;
      this.root.rotation.set(0, this.yaw, 0);
      this.root.position.copy(this.pos);
      if (this.body) { this.body.position.y = 0; this.body.rotation.y = 0; this.aim.rotation.z = 0; }
      if (this.legL) for (const l of [this.legL, this.legR]) { l.rotation.x = 0; l.userData.shin.rotation.x = 0; }
      if (this.label) this.label.visible = true;
    }
    dispose() { if (this.scene) this.scene.remove(this.root); }
  }
  G.Bot = Bot;
})(window.G);
