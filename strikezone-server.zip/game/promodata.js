'use strict';
/* 2.3: таблица промокодов — только хеши (h53, seed 1712), открытого текста кодов нигде нет.
   Общая для игры и сервера (сервер грузит файл без DOM: G.HEADLESS). Игра проверяет коды сама только у гостей;
   у аккаунта на сервере 2.3 код проверяет и выдаёт сервер ({t:'promo', code}).
   Запись: { title, coins?, tokens?: {кейс: n}, cases?: [кейс] (открыть сразу), knife? (случайный нож), all? (все предметы), owner? (код владельца) } */
(function (G) {
  const h53 = (str, seed) => {
    let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for (let i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  };
  // как игрок ни ввёл код — пробелы, дефисы, подчёркивания и регистр не важны
  G.promoNorm = (s) => String(s || '').toUpperCase().replace(/[\s\-_]+/g, '');
  // хеш кода (ключ G.PROMO_CODES); пустой код → 0
  G.promoHash = (code) => { const c = G.promoNorm(code); return c ? h53(c, 1712) : 0; };
  // 2.0 (релиз): все публичные промокоды прошлых версий отключены — действуют только личные коды владельца
  // (в игре хранятся лишь хеши; новые коды добавляются сюда и попадают на сервер через sync.sh)
  G.PROMO_CODES = {
    5686790251344381: { title: 'Владелец: все предметы игры', all: true, owner: true, coins: 1000000 },
    6030179944799048: { title: 'Владелец: всё в игре', all: true, owner: true, coins: 1000000 }
  };
})(typeof window !== 'undefined' && window.G ? window.G : (typeof G !== 'undefined' ? G : (globalThis.G = globalThis.G || {})));
