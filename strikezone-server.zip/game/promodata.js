'use strict';
/* 2.3: таблица промокодов — только хеши (h53, seed 1712), открытого текста кодов нигде нет.
   Общая для игры и сервера (сервер грузит файл без DOM: G.HEADLESS). Игра проверяет коды сама только у гостей;
   у аккаунта на сервере 2.3 код проверяет и выдаёт сервер ({t:'promo', code}).
   Запись: { title, coins?, tokens?: {кейс: n}, cases?: [кейс] (открыть сразу), knife? (случайный нож), all? (все предметы), owner? (код владельца) } */
(function (G) {
  const h53 = (str, seed) => {
    let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for (let i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  };
  // как игрок ни ввёл код — пробелы, дефисы, подчёркивания и регистр не важны
  G.promoNorm = (s) => String(s || '').toUpperCase().replace(/[\s\-_]+/g, '');
  // хеш кода (ключ G.PROMO_CODES); пустой код → 0
  G.promoHash = (code) => { const c = G.promoNorm(code); return c ? h53(c, 1712) : 0; };
  G.PROMO_CODES = {
    6158073387622083: { title: 'Подарок от Prodigy Strike', coins: 1000 },
    4871512691167591: { title: 'Релиз игры', coins: 2500 },
    4808058248842470: { title: 'Кейс «Prodigy» бесплатно', cases: ['prodigy'] },
    7603968185536445: { title: 'Случайный нож', knife: true },
    5686790251344381: { title: 'Владелец: все предметы игры', all: true, coins: 1000000 },
    1194581502102374: { title: 'PRODIGY: 7500 монет и кейс', coins: 7500, tokens: { prodigy: 1 } },
    6030179944799048: { title: 'Владелец: всё в игре', all: true, owner: true, coins: 1000000 },
    // 11.3: десять промокодов для канала
    2766067172082103: { title: 'STRIKE: 1500 монет', coins: 1500 },
    263389415553341: { title: 'HEADSHOT: 2500 монет', coins: 2500 },
    6550908092601142: { title: 'CLUTCH: 4000 монет', coins: 4000 },
    656777691916578: { title: 'ACE: 2 кейса «Prodigy»', tokens: { prodigy: 2 } },
    748498993683862: { title: 'M4A1S: кейс «Prodigy» и 1000 монет', coins: 1000, tokens: { prodigy: 1 } },
    3946424784691911: { title: 'GLOVES: кейс «Перчатки»', tokens: { gloves: 1 } },
    4438379321375575: { title: 'SAKURA: кейс «Prodigy» и 1000 монет', coins: 1000, tokens: { prodigy: 1 } },
    2534815897796893: { title: 'HARBOR: 3 кейса «Prodigy»', tokens: { prodigy: 3 } },
    3242272351678456: { title: 'LEGENDA: случайный нож', knife: true },
    3125871565705341: { title: 'PS2026: 2026 монет и кейс «Prodigy»', coins: 2026, tokens: { prodigy: 1 } },
    // 11.9: новые коды
    8046918832307760: { title: 'ARSENAL: 2 кейса «Арсенал»', tokens: { arsenal: 2 } },
    5814090343946036: { title: 'GALIL: 2000 монет', coins: 2000 },
    1058243537841966: { title: 'FAMAS: 2000 монет', coins: 2000 },
    6928756931832679: { title: 'NEON: 3000 монет', coins: 3000 },
    4096630237195687: { title: 'SCOUT: кейс «Арсенал» и 1000 монет', coins: 1000, tokens: { arsenal: 1 } },
    8630139026495399: { title: 'PERRON: 2500 монет', coins: 2500 },
    2201678119242591: { title: 'RELOAD: 1500 монет и кейс «Prodigy»', coins: 1500, tokens: { prodigy: 1 } },
    8762671834933375: { title: 'UPDATE: 3500 монет', coins: 3500 },
    // 2.0
    5374120055221468: { title: 'PRODIGY20: 1500 монет и кейс «Prodigy»', coins: 1500, tokens: { prodigy: 1 } },
    8064640602634199: { title: 'RANKED: 1000 монет', coins: 1000 },
    5746588790007965: { title: 'LAGUNA: кейс «Prodigy» и 500 монет', coins: 500, tokens: { prodigy: 1 } },
    1568647379990296: { title: 'SAKURA20: кейс «Prodigy» и 500 монет', coins: 500, tokens: { prodigy: 1 } },
    3800234983573049: { title: 'DUST20: кейс «Prodigy» и 500 монет', coins: 500, tokens: { prodigy: 1 } },
    850055853732805: { title: 'KNIVES: кейс «Арсенал» и 750 монет', coins: 750, tokens: { arsenal: 1 } },
    5044459862115982: { title: 'SOLDIER: 1200 монет', coins: 1200 },
    6649944455412324: { title: 'GLOBAL2: кейс «Prodigy» и 1000 монет', coins: 1000, tokens: { prodigy: 1 } }
  };
})(typeof window !== 'undefined' && window.G ? window.G : (typeof G !== 'undefined' ? G : (globalThis.G = globalThis.G || {})));
