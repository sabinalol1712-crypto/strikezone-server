'use strict';
/* Боевой пропуск «Цветение»: 75 заданий, каждый день открываются 8 новых. Каждое выполненное задание — уровень пропуска и награда */
(function (G) {
  const DAY = 86400000, PER_DAY = 8, TOTAL = 75;
  const CLS = {
    rifle: ['ar', 'ar2', 'm4s', 'galil', 'famas'], pistol: ['pistol', 'usp', 'magnum', 'fiveseven', 'tec9', 'duals'], smg: ['smg'], shotgun: ['shotgun'], sniper: ['sniper', 'ssg'],
    knife: ['knife', 'm9', 'butterfly', 'karambit', 'tanto'], he: ['he']
  };
  const CLS_NAME = { rifle: 'из винтовки', pistol: 'из пистолета', smg: 'из ПП «Оса»', shotgun: 'из дробовика', sniper: 'из снайперки', knife: 'ножом', he: 'гранатой' };
  const MAP_NAME = { dust: '«Пыльный квартал»', harbor: '«Порт»', sakura: '«Сакура»', villa: '«Перрон»', winter: '«Неоновая крыша»', lagoon: '«Лагуна»', caldera: '«Кальдера»' };
  const MODE_NAME = { bomb: '«Закладка бомбы»', tdm: '«Командный бой»', ffa: '«Бой насмерть»' };
  const plural = (n, a, b, c) => { const m = n % 10, h = n % 100; return m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 10 || h >= 20) ? b : c; };

  // задания: t — тип, n — сколько, остальные поля — условия
  const K = (n, o) => Object.assign({ t: 'kill', n }, o || {});
  const TASKS = [
    // день 1
    { t: 'tutorial', n: 1 }, { t: 'match', n: 1 }, K(5), K(2, { head: true }), K(3, { cls: 'pistol' }), { t: 'win', n: 1 }, { t: 'nade', n: 3 }, { t: 'match', n: 1, map: 'sakura' },
    // день 2
    K(15), K(5, { cls: 'rifle' }), { t: 'plant', n: 1 }, K(5, { head: true }), { t: 'round', n: 5 }, K(1, { cls: 'knife' }), { t: 'match', n: 2, mode: 'bomb' }, { t: 'case', n: 1 },
    // день 3
    K(20), K(8, { cls: 'smg' }), { t: 'blind', n: 3 }, { t: 'win', n: 2 }, K(10, { map: 'villa' }), { t: 'streak', n: 3 }, K(6, { cls: 'shotgun' }), { t: 'match', n: 2, mode: 'tdm' },
    // день 4
    K(25), K(8, { head: true }), K(3, { cls: 'sniper' }), { t: 'defuse', n: 1 }, { t: 'round', n: 10 }, K(12, { map: 'harbor' }), { t: 'nade', n: 8 }, K(2, { cls: 'he' }),
    // день 5
    K(30), K(10, { cls: 'pistol' }), { t: 'win', n: 3 }, { t: 'plant', n: 3 }, K(15, { map: 'sakura' }), { t: 'streak', n: 4 }, K(3, { cls: 'knife' }), { t: 'match', n: 2, mode: 'ffa' },
    // день 6
    K(40), K(12, { head: true }), K(15, { cls: 'rifle' }), { t: 'blind', n: 6 }, { t: 'round', n: 15 }, K(8, { cls: 'sniper' }), { t: 'win', n: 2, mode: 'bomb' }, { t: 'case', n: 2 },
    // день 7
    K(50), K(15, { cls: 'smg' }), { t: 'defuse', n: 2 }, K(20, { map: 'harbor' }), { t: 'streak', n: 5 }, K(10, { cls: 'shotgun' }), { t: 'nade', n: 15 }, { t: 'match', n: 5 },
    // день 8
    K(60), K(20, { head: true }), K(5, { cls: 'he' }), { t: 'win', n: 4 }, { t: 'plant', n: 5 }, K(20, { map: 'harbor' }), K(5, { cls: 'knife' }), { t: 'round', n: 20 },
    // день 9
    K(75), K(25, { cls: 'rifle' }), K(25, { map: 'sakura' }), K(15, { cls: 'pistol' }), { t: 'streak', n: 6 }, { t: 'blind', n: 10 }, { t: 'win', n: 3, mode: 'bomb' }, K(12, { cls: 'sniper' }),
    // день 10 — финал
    K(100), K(30, { head: true }), { t: 'win', n: 5 }
  ];
  const desc = (q) => {
    const n = q.n;
    switch (q.t) {
      case 'tutorial': return 'Пройдите обучение на полигоне';
      case 'match': return `Сыграйте ${n} ${plural(n, 'матч', 'матча', 'матчей')}${q.mode ? ' в режиме ' + MODE_NAME[q.mode] : ''}${q.map ? ' на карте ' + MAP_NAME[q.map] : ''}`;
      case 'win': return `Победите в ${n} ${plural(n, 'матче', 'матчах', 'матчах')}${q.mode ? ' в режиме ' + MODE_NAME[q.mode] : ''}`;
      case 'kill': return `${q.head ? 'Убейте' : 'Убейте'} ${n} ${plural(n, 'противника', 'противников', 'противников')}${q.head ? ' выстрелом в голову' : ''}${q.cls ? ' ' + CLS_NAME[q.cls] : ''}${q.map ? ' на карте ' + MAP_NAME[q.map] : ''}`;
      case 'plant': return `Заложите бомбу ${n} ${plural(n, 'раз', 'раза', 'раз')}`;
      case 'defuse': return `Обезвредьте бомбу ${n} ${plural(n, 'раз', 'раза', 'раз')}`;
      case 'round': return `Выиграйте ${n} ${plural(n, 'раунд', 'раунда', 'раундов')} в режиме «Закладка бомбы»`;
      case 'nade': return `Бросьте ${n} ${plural(n, 'гранату', 'гранаты', 'гранат')}`;
      case 'blind': return `Ослепите ${n} ${plural(n, 'противника', 'противников', 'противников')} светошумовой`;
      case 'streak': return `Сделайте серию из ${n} убийств за одну жизнь`;
      case 'case': return `Откройте ${n} ${plural(n, 'кейс', 'кейса', 'кейсов')}`;
    }
    return '';
  };

  // ---------- две дорожки наград — бесплатная и премиум (750 монет за сезон) ----------
  // поля награды: c — монеты, k — бесплатное открытие кейса (id), kn — сколько, s — скин, x — опыт профиля, op — оперативник, big — крупная, final — финал.
  // 2.2: халявы намного меньше. На обеих дорожках вместе — ровно ОДИН нож (финал премиума) и ОДИН кейс «Перчатки» (премиум, ур. 50),
  // плюс два элитных оперативника (премиум, ур. 30 и 60), немного простых скинов, мелкие монеты и опыт; других ножей, перчаток и кейсов нет.
  // Монет: бесплатная ~240 за сезон, премиум 130 — намного меньше цены премиума (750). Уже полученные награды остаются у игроков
  const PREMIUM_PRICE = 750, SEASON_ID = 's1';
  const F_SKIN = { 10: 'galil_desert', 26: 'famas_forest', 44: 'tec9_graffiti', 62: 'm4s_urban' };
  const F_COIN = { 1: 20, 8: 15, 16: 15, 24: 20, 34: 20, 40: 20, 50: 25, 56: 25, 70: 30 };
  const P_SKIN = { 5: 'smg_koi', 13: 'pistol_sakura', 21: 'usp_sakura', 38: 'ar_sakura', 45: 'shotgun_koi', 55: 'sniper_koi', 68: 'ar2_sakura' };
  const P_COIN = { 3: 15, 18: 20, 33: 25, 48: 30, 63: 40 };
  const P_CASE = { 50: 'prodigy' }; // 2.3: кейс «Перчатки» убран — кейс «Prodigy» (перчатки в его золотом слоте)
  const P_OP = { 30: 'ct_elite', 60: 't_elite' };
  const F = [], P = [];
  for (let lv = 1; lv <= TOTAL; lv++) {
    const f = F_SKIN[lv] && G.SKINS[F_SKIN[lv]] ? { s: F_SKIN[lv] } : F_COIN[lv] ? { c: F_COIN[lv] } : { x: 100 };
    const p = P_OP[lv] ? { op: P_OP[lv], big: true } : P_SKIN[lv] && G.SKINS[P_SKIN[lv]] ? { s: P_SKIN[lv] } : P_CASE[lv] ? { k: P_CASE[lv], big: true }
      : P_COIN[lv] ? { c: P_COIN[lv] } : { x: 150 };
    if (p.s && G.SKINS[p.s].r >= 5) p.big = true;
    F[lv] = f; P[lv] = p;
  }
  F[TOTAL] = { c: 50, x: 300, big: true, final: true };
  P[TOTAL] = { s: 'tanto_emperor', big: true, final: true }; // единственный нож пропуска
  const R = F; // совместимость: B.R — бесплатная дорожка

  const caseName = (id) => { const c = G.caseOf ? G.caseOf(id) : G.CASES.find(x => x.id === id); return c ? c.name : 'Кейс'; };
  const opName = (id) => { const o = G.opsInv && G.opsInv.get(id); return 'Оперативник «' + (o ? o.name : id) + '»'; };
  const rewardText = (r) => {
    const out = [];
    if (!r) return '';
    if (r.op) out.push(opName(r.op));
    if (r.s) out.push(G.skinLabel(r.s));
    if (r.k) out.push(caseName(r.k) + (r.kn > 1 ? ' ×' + r.kn : ''));
    if (r.c) out.push(r.c.toLocaleString('ru-RU') + ' монет');
    if (r.x) out.push('+' + r.x + ' опыта');
    return out.join(' + ');
  };

  // ---------- 2.2: за матч — только опыт (уровень профиля), монет нет ----------
  // Ни бои с ботами, ни онлайн (обычный и рейтинговый), ни победы монет больше не дают — бонус «первая победа дня» убран.
  // Монеты остаются только у пропуска (немного), за ранги рейтинга (сервер), в промокодах, подарках и магазине «+».
  // Опыт: время в бою + убийства + исход + раунды; онлайн ×1,5, сложность ботов меняет множитель, короткий матч — малый бонус за исход
  const EC = {
    PER_MIN: 8, MIN_CAP: 80, KILL: 10, KILL_CAP: 40, WIN: 100, DRAW: 50, LOSE: 25, TOP3: 50, ROUND: 5, ONLINE: 1.5,
    DIFF: { easy: 0.75, normal: 1, hard: 1.25 }, DIFF_NAME: { easy: 'новички', normal: 'бойцы', hard: 'ветераны' },
    FULL: { tdm: 4, ffa: 4, bomb: 8, duel: 2.5 } // минут до полного бонуса за исход
  };
  const fmtK = (v) => String(v).replace('.', ',');
  const lvlOf = (xp) => { const lvl = Math.floor(Math.sqrt(Math.max(0, xp) / 120)) + 1, cur = (lvl - 1) * (lvl - 1) * 120, next = lvl * lvl * 120; return { lvl, frac: (xp - cur) / (next - cur), cur, next }; };
  G.econ = {
    EC, lvlOf,
    // o: { mode, online, diff, secs, kills, roundsWon, result: 'win' | 'draw' | 'lose', place (бой насмерть) }
    // → { lines, xp, total: 0 } — total (монеты) всегда 0: старые вызовы `coins += rw.total` ничего не начисляют
    match(o) {
      const lines = [], min = Math.max(0, o.secs || 0) / 60;
      const part = Math.min(1, Math.max(0.2, min / (EC.FULL[o.mode] || 4)));
      const base = Math.min(EC.MIN_CAP, Math.max(5, Math.round(EC.PER_MIN * min)));
      lines.push({ t: 'Матч · ' + Math.max(1, Math.round(min)) + ' мин', v: base });
      const k = Math.min(EC.KILL_CAP, Math.max(0, o.kills | 0));
      if (k) lines.push({ t: 'Убийства ' + EC.KILL + '×' + k, v: EC.KILL * k });
      let w = 0, wt = '';
      if (o.mode === 'ffa') { if (o.place === 1) { w = EC.WIN; wt = '1-е место'; } else if (o.place && o.place <= 3) { w = EC.TOP3; wt = o.place + '-е место'; } else { w = EC.LOSE; wt = 'Участие'; } }
      else if (o.result === 'win') { w = EC.WIN; wt = 'Победа'; } else if (o.result === 'draw') { w = EC.DRAW; wt = 'Ничья'; } else { w = EC.LOSE; wt = 'Участие'; }
      w = Math.max(1, Math.round(w * part)); lines.push({ t: wt + (part < 1 ? ' · короткий матч' : ''), v: w, win: o.result === 'win' || (o.mode === 'ffa' && o.place === 1) });
      const rw = o.mode === 'bomb' || o.mode === 'duel' ? Math.max(0, o.roundsWon | 0) : 0;
      if (rw) lines.push({ t: 'Раунды ' + EC.ROUND + '×' + rw, v: EC.ROUND * rw });
      let sum = 0; for (const l of lines) sum += l.v;
      const mul = o.online ? EC.ONLINE : (EC.DIFF[o.diff] || 1);
      if (mul !== 1) lines.push({ t: o.online ? 'Онлайн' : 'Боты: ' + (EC.DIFF_NAME[o.diff] || ''), m: '×' + fmtK(mul) });
      const xp = Math.round(sum * mul);
      const xp0 = (G.stats && G.stats.xp) || 0;
      return { lines, xp, total: 0, xp0, xp1: xp0 + xp };
    },
    // начислить опыт за матч (вызывает game.js endMatch); монеты не трогаем
    apply(rw) {
      if (!rw || !G.stats) return rw;
      if (G.game && G.game.specMode) { rw.spec = true; rw.xp = 0; return rw; } // 2.2: наблюдатель (caster.js) опыта не получает
      rw.xp0 = G.stats.xp || 0; G.stats.xp = rw.xp0 + rw.xp; rw.xp1 = G.stats.xp;
      if (lvlOf(rw.xp1).lvl > lvlOf(rw.xp0).lvl) { rw.up = true; setTimeout(() => { try { G.audio && G.audio.levelUp && G.audio.levelUp(); } catch (e) { } }, 900); }
      return rw;
    },
    // разбивка опыта для экрана итогов + полоса уровня (заполняется от старого значения к новому, при новом уровне — вспышка)
    html(rw) {
      if (rw.spec) return '';
      const it = rw.lines.map(l => `<span class="rw-i${l.m ? ' rw-m' : ''}${l.win ? ' rw-fw' : ''}"><small>${G.esc(l.t)}</small><b class="num">${l.m || '+' + l.v}</b></span>`).join('');
      const a = lvlOf(rw.xp0 != null ? rw.xp0 : 0), b = lvlOf(rw.xp1 != null ? rw.xp1 : rw.xp);
      const up = b.lvl > a.lvl, f0 = a.frac, f1 = b.frac;
      const rank = G.rankName ? G.rankName(b.lvl) : '';
      const bar = `<div class="xpl${up ? ' up' : ''}" style="--f0:${(f0 * 100).toFixed(1)}%;--f1:${(Math.max(0.01, f1) * 100).toFixed(1)}%">`
        + `<span class="xpl-l"><em class="num">${b.lvl}</em><small>УР.</small></span>`
        + `<span class="xpl-m"><span class="xpl-t"><span>${up ? `<b>НОВЫЙ УРОВЕНЬ ${b.lvl}!</b> ${G.esc(rank)}` : `<b>${G.esc(rank)}</b> · уровень ${b.lvl}`}</span><i class="num">${(rw.xp1 - b.cur).toLocaleString('ru-RU')} / ${(b.next - b.cur).toLocaleString('ru-RU')}</i></span><span class="xpl-b"><i></i></span></span></div>`;
      return `<div class="rwd rwx"><span class="rw-h">ОПЫТ<br>ЗА МАТЧ</span>${it}<span class="rw-t num">+${rw.xp}<small>XP</small></span></div>${bar}`;
    }
  };

  const B = G.bp = {
    TASKS, R, F, P, TOTAL, PER_DAY, PREMIUM_PRICE, desc, rewardText, caseName,
    SEASON_ID, // 2.3: id сезона — для облачного инвентаря (bp.season) и сервера
    season: 'Сезон 1 · Цветение',
    OFFLINE_NOTE: 'Задания пропуска засчитываются только в онлайне за живых игроков',
    load() {
      const key = 'bp_' + (G.profiles && G.profiles.active || 'x');
      this.key = key;
      const d = new Date(); d.setHours(0, 0, 0, 0);
      this.st = Object.assign({ start: d.getTime(), prog: {}, done: {}, level: 0, seen: 0 }, G.store.get(key, {}));
      const st = this.st;
      st.cf = st.cf || {}; st.cp = st.cp || {};
      // 2.1: до этой версии награды уровней выдавались сразу — уже пройденные уровни бесплатной дорожки считаем полученными
      if (!st.v21) { for (let L = 1; L <= st.level; L++) st.cf[L] = 1; st.v21 = 1; this.save(); }
      // 2.5: сброс инвентаря — премиум и полученные награды обнуляются (уровни и задания остаются), награды можно забрать заново
      if (!st.v25) { st.cf = {}; st.cp = {}; delete st.prem; delete st.premT; st.v25 = 1; this.save(); }
      if (G.stats && G.stats.tutorialDone && !st.done[0]) st.prog[0] = 1; // обучение пройдено раньше
      this.check(true);
    },
    save() { G.store.set(this.key, this.st); },
    day() { const d = new Date(); d.setHours(0, 0, 0, 0); return Math.max(1, Math.floor((d.getTime() - this.st.start) / DAY + 0.5) + 1); },
    unlocked() { return Math.min(TOTAL, this.day() * PER_DAY); },
    days() { return Math.ceil(TOTAL / PER_DAY); },
    nextUnlockMs() { const d = new Date(); d.setHours(24, 0, 0, 0); return d.getTime() - Date.now(); },
    isDone(i) { return !!this.st.done[i]; },
    prog(i) { return Math.min(TASKS[i].n, this.st.prog[i] || 0); },
    // ---------- 2.1: прогресс — только в онлайне и только когда в матче есть другие живые игроки ----------
    // forMatch: итог матча засчитывается, если живой игрок был в комнате хотя бы раз за этот матч (кто-то мог выйти перед концом)
    live(forMatch) {
      const N = G.net, g = G.game;
      if (!N || !N.active || !g || !g.online || g.mode === 'tutorial') return false;
      if (N.wu && !forMatch) return false; // разминка — без наград
      const p = g.player; let h = 0;
      if (N.actors && N.actors.values) for (const a of N.actors.values()) if (a && a !== p && a.human) h++;
      if (h && p) this.seenP = p;
      return h > 0 || (!!forMatch && !!p && this.seenP === p);
    },
    // событие матча: e — тип, o — подробности (у убийства o.human — убит живой игрок)
    ev(e, o) {
      if (!this.st) return;
      o = o || {};
      if (e === 'match') { const on = this.live(true); this.lastLive = on; if (G.pvp) G.pvp.match(on, !!o.win); if (!on) return; }
      else if (e !== 'case' && e !== 'tutorial') { // кейсы и обучение — не бой, считаются везде
        if (!this.live(false)) return;
        if (e === 'kill' && !o.human) return; // боты не в счёт, даже в онлайн-комнате
      }
      const n = this.unlocked();
      let changed = false;
      for (let i = 0; i < n; i++) {
        if (this.st.done[i]) continue;
        const q = TASKS[i];
        let add = 0;
        if (q.t === 'kill' && e === 'kill') {
          if (q.head && !o.head) continue;
          if (q.cls && !(CLS[q.cls] || []).includes(o.wid)) continue;
          if (q.map && q.map !== o.map) continue;
          add = 1;
        } else if (q.t === 'streak' && e === 'kill') {
          if ((o.streak || 0) > (this.st.prog[i] || 0)) { this.st.prog[i] = o.streak; changed = true; }
          continue;
        } else if ((q.t === 'match' || q.t === 'win') && e === 'match') {
          if (q.mode && q.mode !== o.mode) continue;
          if (q.map && q.map !== o.map) continue;
          if (q.t === 'win' && !o.win) continue;
          add = 1;
        } else if (q.t === e) add = o.n || 1;
        if (add) { this.st.prog[i] = (this.st.prog[i] || 0) + add; changed = true; }
      }
      if (changed) { this.check(); this.save(); }
    },
    // выполненные задания → уровни; награды забирает игрок (страница пропуска, «Забрать всё»)
    check(silent) {
      const n = this.unlocked(), gained = [];
      for (let i = 0; i < n; i++) {
        if (this.st.done[i] || (this.st.prog[i] || 0) < TASKS[i].n) continue;
        this.st.done[i] = true;
        if (this.st.level < TOTAL) {
          this.st.level++;
          gained.push({ task: i, level: this.st.level, r: F[this.st.level], p: P[this.st.level] });
        }
      }
      if (gained.length) {
        this.save();
        if (!silent) for (const g of gained) this.toast(g);
        else this.pending = (this.pending || []).concat(gained);
      }
      return gained;
    },
    // ---------- 2.1: премиум и получение наград ----------
    isPrem() { return !!(this.st && this.st.prem === SEASON_ID); },
    canClaim(L, tr) { const st = this.st; if (!st || L < 1 || L > Math.min(TOTAL, st.level)) return false; return tr === 'p' ? this.isPrem() && !st.cp[L] : !st.cf[L]; },
    claimed(L, tr) { return !!(this.st && (tr === 'p' ? this.st.cp : this.st.cf)[L]); },
    claimCount() { let n = 0; if (!this.st) return 0; for (let L = 1; L <= Math.min(TOTAL, this.st.level); L++) { if (this.canClaim(L, 'f')) n++; if (this.canClaim(L, 'p')) n++; } return n; },
    claim(L, tr, quiet) {
      if (!this.canClaim(L, tr)) return null;
      const r = (tr === 'p' ? P : F)[L];
      (tr === 'p' ? this.st.cp : this.st.cf)[L] = 1;
      this.grant(r);
      if (!quiet) { this.save(); G.saveInv && G.saveInv(); G.saveStats && G.saveStats(); }
      return r;
    },
    claimAll() {
      const got = [];
      if (!this.st) return got;
      for (let L = 1; L <= Math.min(TOTAL, this.st.level); L++) for (const tr of ['f', 'p']) { const r = this.claim(L, tr, true); if (r) got.push({ L, tr, r }); }
      if (got.length) { this.save(); G.saveInv && G.saveInv(); G.saveStats && G.saveStats(); }
      return got;
    },
    // покупка премиума: один раз за сезон, 750 монет. После покупки премиум-награды всех пройденных уровней можно забрать
    buyPremium() {
      if (!this.st) return { err: 'nost' };
      if (this.isPrem()) return { err: 'owned' };
      if (G.inv.coins < PREMIUM_PRICE) return { err: 'coins', need: PREMIUM_PRICE - G.inv.coins };
      G.inv.coins -= PREMIUM_PRICE;
      this.st.prem = SEASON_ID; this.st.premT = Date.now();
      G.saveInv(); this.save();
      return { ok: true, ready: this.claimCount() };
    },
    grant(r) {
      if (!r) return;
      if (r.c) G.inv.coins += r.c;
      if (r.k) { const k = G.caseId ? G.caseId(r.k) : r.k; G.inv.tokens = G.inv.tokens || {}; G.inv.tokens[k] = (G.inv.tokens[k] || 0) + (r.kn || 1); }
      if (r.s) G.invAddQuiet(r.s, 0);
      if (r.x && G.stats) G.stats.xp = (G.stats.xp || 0) + r.x;
      if (r.op && G.opsInv) G.opsInv.unlock(r.op);
    },
    // строка «Пропуск» на экране итогов матча (+ пометка, если матч не засчитан)
    endHtml(gain) {
      const st = this.st || { level: 0 };
      return `<span class="bpgain">Пропуск: <b>${st.level}</b>/${TOTAL}${gain > 0 ? ` <em>+${gain}</em>` : ''}</span>`
        + (this.lastLive ? '' : `<span class="bp-offnote"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 3.8 5.8 3.8 9s-1.2 6.2-3.8 9c-2.6-2.8-3.8-5.8-3.8-9S9.4 5.8 12 3z"/></svg>${G.esc(this.OFFLINE_NOTE)}</span>`);
    },
    // всплывающее уведомление (в бою и в меню)
    toast(g) {
      const el = document.getElementById('bptoast'); if (!el) return;
      const q = TASKS[g.task];
      const rw = rewardText(g.r) + (this.isPrem() ? ' · ' + rewardText(g.p) : '');
      this.queue = this.queue || [];
      this.queue.push(`<div class="bpt${g.r.big || (this.isPrem() && g.p.big) ? ' big' : ''}"><div class="bpt-h">ЗАДАНИЕ ВЫПОЛНЕНО · УРОВЕНЬ ${g.level}</div><div class="bpt-t">${G.esc(desc(q))}</div><div class="bpt-r">${G.esc(rw)} — заберите в пропуске</div></div>`);
      if (!this.showing) this.next();
      if (G.audio) (G.audio.levelUp ? G.audio.levelUp() : G.audio.go()); // 2.1 звук: свой сигнал награды пропуска
    },
    next() {
      const el = document.getElementById('bptoast');
      const h = this.queue.shift();
      if (!h) { this.showing = false; el.innerHTML = ''; return; }
      this.showing = true;
      el.innerHTML = h;
      setTimeout(() => this.next(), 3200);
    },
    // счётчики для меню
    readyCount() { let c = 0; for (let i = 0; i < this.unlocked(); i++) if (!this.st.done[i]) c++; return c; }
  };
})(window.G);
