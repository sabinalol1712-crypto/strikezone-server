'use strict';
/* Режим «Закладка бомбы»: раунды, экономика, магазин, бомба, задачи ботов */
(function (G) {
  const V3 = THREE.Vector3;
  G.SHOP = [
    { cat: 'Пистолеты', items: ['usp', 'pistol', 'fiveseven', 'tec9', 'magnum'] },
    { cat: 'ПП и дробовики', items: ['smg', 'shotgun'] },
    { cat: 'Винтовки', items: ['galil', 'famas', 'ar', 'ar2', 'm4s', 'ssg', 'sniper'] },
    { cat: 'Гранаты', items: ['he', 'flash', 'smoke'] },
    { cat: 'Снаряжение', items: ['armor', 'helmet', 'kit'] }
  ];
  G.EQUIP = {
    armor: { name: 'Бронежилет', cls: 'Броня 100', price: 650 },
    helmet: { name: 'Броня + шлем', cls: 'Защищает голову', price: 1000 },
    kit: { name: 'Набор сапёра', cls: 'Разминирование быстрее', price: 400, team: 0 }
  };
  const REASON = { elim: 'Все противники уничтожены', time: 'Время вышло', bomb: 'Бомба взорвана', defuse: 'Бомба обезврежена' };

  const B = G.bombMode = {
    ROUND: 115, FREEZE: 7, BOMB: 40, PLANT: 3.2, DEFUSE: 8, KIT: 4.5, END: 5, BUY: 22, WIN: 7, HALF: 6, MAX: 12,

    setup(g, n) {
      this.g = g;
      const names = g.botNames();
      const p = g.player;
      // сторона в первой половине — по выбору игрока (налётчики закладывают, спецназ обезвреживает)
      const pt = p.team === 0 || p.team === 1 ? p.team : 1;
      p.team = pt;
      for (let i = 0; i < n - 1; i++) g.actors.push(new G.Bot(names.pop(), pt, g.scene));
      for (let i = 0; i < n; i++) g.actors.push(new G.Bot(names.pop(), 1 - pt, g.scene));
      for (const a of g.actors) { a.money = 800; a.alive = false; }
      this.round = 0; this.score = [0, 0]; this.loss = [0, 0]; this.over = false; this.matchOver = false;
      this.alert = null; this.spectate = null;
      if (!this.bombMesh) this.makeBombMesh(g.scene);
      this.startRound();
    },
    makeBombMesh(scene) {
      if (G.HEADLESS || !scene) { this.bombMesh = { visible: false, position: new V3(), rotation: { y: 0 } }; this.bombLight = { visible: false }; return; }
      const grp = new THREE.Group();
      const body = new THREE.Mesh(G.geo.build([G.geo.box(0.3, 0.1, 0.2, 0, 0.05, 0, '#3a3f2a'), G.geo.box(0.12, 0.03, 0.08, -0.06, 0.115, 0, '#2a2d22'),
        G.geo.cyl(0.02, 0.28, 0.0, 0.05, 0.12, '#8a2d22', 0, 0, Math.PI / 2), G.geo.cyl(0.02, 0.28, 0.0, 0.05, -0.12, '#2d5a8a', 0, 0, Math.PI / 2)]), G.getVCMat());
      const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.1), new THREE.MeshBasicMaterial({ map: G.tex('bombTex') }));
      screen.rotation.x = -Math.PI / 2; screen.position.set(0.07, 0.102, 0);
      const light = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('dot'), color: 0xff3020, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      light.scale.set(0.35, 0.35, 1); light.position.set(-0.06, 0.16, 0);
      grp.add(body, screen, light);
      grp.visible = false;
      scene.add(grp);
      this.bombMesh = grp; this.bombLight = light;
    },
    teamAlive(t) { return this.g.actors.filter(a => a.alive && a.team === t).length; },
    spawnAll() {
      const g = this.g;
      for (const a of g.actors) a.alive = false;
      for (const a of g.actors) {
        const sp = g.spawnPoint(a);
        a.pos.set(sp.x, 0, sp.z); a.yaw = sp.yaw;
        a.alive = true;
      }
    },
    startRound() {
      const g = this.g;
      this.round++;
      const pistol = this.round === 1 || this.round === this.HALF + 1;
      this.pistol = pistol;
      this.phase = 'freeze'; this.t = this.FREEZE; this.buyT = this.BUY; g.frozen = true;
      this.assign = new Map(); this.alert = null; this.plantT = 0; this.defuseT = 0; this.defuser = null; this.planter = null;
      for (const a of g.actors) {
        // выживший оставляет оружие; пистолет он мог выбросить — тогда держится за основное
        const keep = a.alive && !pistol && a.slots && (a.slots.secondary || a.slots.primary);
        if (!keep) { a.loadout(null); a.armor = 0; a.helmet = false; a.kit = false; }
        else {
          for (const k of ['primary', 'secondary']) { const st = a.slots[k]; if (st) { st.mag = st.def.mag; st.reserve = st.def.reserve; st.reloadT = 0; } }
          a.cur = a.slots.primary ? 'primary' : 'secondary';
        }
        a.hp = 100; a.deadT = 0; a.protect = 0; a.vel.set(0, 0, 0); a.using = false; a.hasBomb = false; a.scoped = false;
        a.afterThrow = 0; a.throwAnimT = 0; a.blindT = 0; a.smokeUsed = false; a.entryNade = false; if (a.slots.nade) a.slots.nade.throwT = 0;
        a.recoilPitch = 0; a.recoilYaw = 0; a.crouch = false; a.crouchT = 0; a.height = 1.8; a.pitch = 0; a.autoReload = 0; a.roundKills = 0;
      }
      this.spawnAll();
      for (const a of g.actors) if (!a.isPlayer) this.botBuy(a);
      for (const a of g.actors) {
        if (a.isPlayer) continue;
        const wid = a.w.id;
        if (a.modelW !== wid || a.modelTeam !== a.team || !a.bodyMesh) a.buildModel(wid);
        a.setLabel(g.player && a.team === g.player.team);
        a.spawned();
      }
      // бомба
      const ts = g.actors.filter(a => a.team === 1);
      let carrier = G.pick(ts.filter(a => !a.isPlayer));
      const pl = g.player;
      if (pl && pl.team === 1 && Math.random() < 0.35) carrier = pl;
      // сетевая игра: бомба у случайного бойца атаки, люди тоже участвуют
      if (g.net) { const hum = ts.filter(a => a.net), bots = ts.filter(a => !a.net); carrier = hum.length && (Math.random() < 0.5 || !bots.length) ? G.pick(hum) : G.pick(bots); }
      this.bomb = { state: 'carried', carrier, pos: new V3() };
      carrier.hasBomb = true;
      this.bombMesh.visible = false;
      // план атаки
      const sites = Object.keys(G.map.sites);
      this.plan = { site: G.pick(sites) };
      const s = G.map.sites[this.plan.site];
      this.plan.spot = G.nav.randomInRect(s.x0 + 2, s.x1 - 2, s.z0 + 1.5, s.z1 - 1.5);
      // точка сбора атаки: на полпути к точке; ждём там, потом заходим вместе
      const tz = G.map.spawnZones[1], path = G.nav.findPath((tz.x0 + tz.x1) / 2, (tz.z0 + tz.z1) / 2, (s.x0 + s.x1) / 2, (s.z0 + s.z1) / 2);
      let stage = { x: (tz.x0 + tz.x1) / 2, z: (tz.z0 + tz.z1) / 2 };
      if (path && path.length) {
        let total = 0, prev = stage; const seg = [];
        for (const q of path) { const d = Math.hypot(q.x - prev.x, q.z - prev.z); seg.push([prev, q, d]); total += d; prev = q; }
        let need = total * G.rand(0.5, 0.62);
        for (const [a, b2, d] of seg) { if (need <= d) { const t = d ? need / d : 0; stage = { x: a.x + (b2.x - a.x) * t, z: a.z + (b2.z - a.z) * t }; break; } need -= d; }
      }
      // карта с одной точкой и несколькими маршрутами к ней: точка сбора — на случайном маршруте
      const stg = G.map.def && G.map.def.stages;
      if (stg && stg.length && Math.random() < 0.85) { const q = G.pick(stg), k = G.map.def.scale || 1; stage = { x: q[0] * k, z: q[1] * k, r: 3.5 }; }
      this.plan.stage = stage; this.plan.wait = G.rand(14, 26); this.plan.go = false;
      g.onRoundStart();
      G.emit('roundStart', { round: this.round, pistol, half: this.round === this.HALF + 1 });
      if (pl) {
        const sub = pistol ? 'Пистолетный раунд' : (pl.team === 1 ? 'Атака: заложите бомбу на точке ' + sites.join(' или ') : 'Защита: не дайте заложить бомбу');
        G.hud.banner(this.round === this.HALF + 1 ? 'СМЕНА СТОРОН' : 'РАУНД ' + this.round, sub, pl.team === 1 ? 't1' : 't0');
        if (pl.hasBomb) setTimeout(() => G.hud.message('БОМБА У ВАС', 'head'), 2600);
      }
      G.chat.reset(); setTimeout(() => G.chat.event('round'), 2200);
    },
    // ---------- магазин ----------
    canBuy(a) {
      if (!a || !a.alive || this.buyT <= 0) return false;
      const z = G.map.spawnZones[a.team];
      return a.pos.x > z.x0 - 8 && a.pos.x < z.x1 + 8 && a.pos.z > z.z0 - 8 && a.pos.z < z.z1 + 8;
    },
    price(a, id) {
      if (id === 'helmet') return (a.armor >= 100 && !a.helmet) ? 350 : 1000;
      return (G.EQUIP[id] || G.WEAPONS[id]).price;
    },
    owned(a, id) {
      if (id === 'armor') return a.armor >= 100;
      if (id === 'helmet') return a.armor >= 100 && a.helmet;
      if (id === 'kit') return a.kit;
      const d = G.WEAPONS[id];
      if (d.nade) return (a.nades[id] || 0) >= 1;
      return !!(a.slots[d.slot] && a.slots[d.slot].id === id);
    },
    buy(a, id) {
      if (!this.canBuy(a)) return false;
      const eq = G.EQUIP[id];
      if (eq && eq.team != null && eq.team !== a.team) return false;
      const wd = G.WEAPONS[id];
      if (wd && wd.team != null && wd.team !== a.team) return false;
      if (this.owned(a, id)) return false;
      const price = this.price(a, id);
      if (a.money < price) return false;
      a.money -= price;
      if (id === 'armor') a.armor = 100;
      else if (id === 'helmet') { a.armor = 100; a.helmet = true; }
      else if (id === 'kit') a.kit = true;
      else a.give(id);
      if (a.isPlayer) G.audio.buy();
      return true;
    },
    botBuy(b) {
      const m = () => b.money;
      // 11.9: у каждой стороны свой дешёвый пистолет за $500 (Five-SeveN у спецназа, Tec-9 у налётчиков)
      const side = b.team === 1 ? 'tec9' : 'fiveseven';
      if (this.pistol) {
        if (Math.random() < 0.45 && m() >= 650) this.buy(b, 'armor');
        else if (Math.random() < 0.35 && m() >= 700) this.buy(b, 'magnum');
        else if (Math.random() < 0.4 && m() >= 500) this.buy(b, side);
        return;
      }
      if (b.slots.primary) { if (b.armor < 100 && m() >= 650) this.buy(b, 'armor'); return; }
      // пистолет покупается раньше основного: после покупки в руках остаётся то, что взяли последним
      if (m() >= 3000 && Math.random() < 0.18) this.buy(b, side);
      let rifle = b.team === 1 ? (Math.random() < 0.36 ? 'galil' : 'ar') : (() => { const r = Math.random(); return r < 0.28 ? 'famas' : r < 0.55 ? 'm4s' : 'ar2'; })();
      // не хватает на дорогую винтовку — чаще берут дешёвую (Galil / FAMAS) вместо ПП
      const cheap = b.team === 1 ? 'galil' : 'famas';
      if (m() < G.WEAPONS[rifle].price + 650 && m() >= G.WEAPONS[cheap].price + 650 && Math.random() < 0.8) rifle = cheap;
      if (m() >= 4750 + 1000 && Math.random() < 0.18) { this.buy(b, 'sniper'); this.buy(b, 'helmet'); }
      else if (m() >= G.WEAPONS.ssg.price + 650 && Math.random() < (m() >= 4000 ? 0.07 : 0.13)) { this.buy(b, 'ssg'); if (m() >= 1000) this.buy(b, 'helmet'); else this.buy(b, 'armor'); }
      else if (m() >= G.WEAPONS[rifle].price + 650) { this.buy(b, rifle); if (m() >= 1000) this.buy(b, 'helmet'); else this.buy(b, 'armor'); }
      else if (m() >= 2000 || this.round >= this.MAX - 1) { this.buy(b, Math.random() < 0.6 ? 'smg' : 'shotgun'); if (m() >= 650) this.buy(b, 'armor'); }
      else if (Math.random() < 0.3 && m() >= 700) this.buy(b, 'magnum');
      else if (Math.random() < 0.4 && m() >= 500) this.buy(b, side);
      if (b.slots.primary) b.cur = 'primary';
      if (b.team === 0 && m() >= 400 && Math.random() < 0.5) this.buy(b, 'kit');
      // гранаты на остаток денег
      const pref = b.team === 1 ? [['smoke', 0.55], ['flash', 0.5], ['he', 0.45]] : [['he', 0.45], ['flash', 0.45], ['smoke', 0.25]];
      for (const [id, ch] of pref) if (m() >= G.WEAPONS[id].price && Math.random() < ch + 0.2) this.buy(b, id);
    },
    // вспышка/осколочная на точку: атака (налётчики) или отбитие заложенной бомбы (спецназ) — раз за раунд
    nadeSpot(b) {
      if (b.entryNade || this.phase === 'freeze') return null;
      if (b.team === 1 && this.plan && this.plan.go && this.phase === 'live') {
        const s = G.map.sites[this.plan.site];
        return { type: b.nades.flash > 0 ? 'flash' : 'he', x: (s.x0 + s.x1) / 2, y: 1.8, z: (s.z0 + s.z1) / 2 };
      }
      if (b.team === 0 && this.phase === 'planted' && this.bomb && this.bomb.state === 'planted') {
        const bp = this.bomb.pos;
        return { type: b.nades.flash > 0 ? 'flash' : 'he', x: bp.x, y: 1.6, z: bp.z };
      }
      return null;
    },
    // точка для дымовой: между точкой атаки и спавном спецназа, один бросок за раунд
    smokeSpot(b) {
      if (b.team !== 1 || b.smokeUsed || !this.plan || !this.plan.go || this.phase !== 'live') return null;
      const s = G.map.sites[this.plan.site], cz = G.map.spawnZones[0];
      const sx = (s.x0 + s.x1) / 2, sz = (s.z0 + s.z1) / 2, dx = (cz.x0 + cz.x1) / 2 - sx, dz = (cz.z0 + cz.z1) / 2 - sz, d = Math.hypot(dx, dz) || 1;
      const k = Math.min(9, d * 0.45);
      const p = { x: sx + dx / d * k, z: sz + dz / d * k };
      const self = this;
      return { x: p.x, z: p.z, set used(v) { b.smokeUsed = true; void self; } };
    },
    // ---------- цикл ----------
    update(dt) {
      const g = this.g;
      this.buyT -= dt;
      if (this.phase === 'freeze') {
        this.t -= dt;
        if (this.t <= 0) { this.phase = 'live'; this.t = this.ROUND; g.frozen = false; G.audio.go(); G.hud.message('В БОЙ!', 'head'); G.emit('live', {}); }
        return;
      }
      if (this.phase === 'end') {
        this.t -= dt;
        if (this.t <= 0) {
          if (this.matchOver) { g.endMatch(); return; }
          if (this.round === this.HALF) this.halftime();
          this.startRound();
        }
        this.tickBomb(dt);
        return;
      }
      this.t -= dt;
      this.tickBomb(dt);
      if (this.phase === 'live' && this.t <= 0) { this.endRound(0, 'time'); return; }
      if (this.phase === 'planted' && this.t <= 0) { this.explode(); return; }
      const ct = this.teamAlive(0), t = this.teamAlive(1);
      if (ct === 0) this.endRound(1, 'elim');
      else if (t === 0 && this.phase === 'live') this.endRound(0, 'elim');
    },
    useHeld(a) { if (a.net) return !!a.netUse && !this.g.frozen; return a.isPlayer ? G.input.useHeld && !this.g.frozen : a.using; },
    tickBomb(dt) {
      const g = this.g, bomb = this.bomb;
      if (!bomb) return;
      if (bomb.state === 'carried') {
        const c = bomb.carrier;
        bomb.pos.copy(c.pos);
        if (this.phase === 'live' && c.alive) {
          const site = G.map.inSite(c.pos.x, c.pos.z);
          const still = Math.hypot(c.vel.x, c.vel.z) < 1.2 && c.onGround;
          if (site && still && this.useHeld(c)) {
            if (this.planter !== c) { this.planter = c; this.plantT = 0; if (c.isPlayer) G.audio.click(); }
            this.plantT += dt;
            if (Math.floor((this.plantT - dt) * 4) !== Math.floor(this.plantT * 4)) G.audio.plantTick(c.pos);
            if (this.plantT >= this.PLANT) this.plant(c, site);
          } else if (this.planter === c) { this.planter = null; this.plantT = 0; }
        }
      } else if (bomb.state === 'dropped') {
        for (const a of g.actors) {
          if (!a.alive || a.team !== 1) continue;
          if (Math.hypot(a.pos.x - bomb.pos.x, a.pos.z - bomb.pos.z) < 1.1) {
            bomb.state = 'carried'; bomb.carrier = a; a.hasBomb = true; this.bombMesh.visible = false;
            G.emit('bombPick', { a });
            if (a.isPlayer) { G.hud.message('ВЫ ПОДОБРАЛИ БОМБУ', 'head'); G.audio.click(); }
            break;
          }
        }
      } else if (bomb.state === 'planted') {
        // мигание и писк
        bomb.beepT -= dt;
        if (bomb.beepT <= 0 && this.phase === 'planted') {
          const k = Math.max(0, this.t / this.BOMB);
          bomb.beepT = Math.max(0.11, 1.0 * k + 0.05);
          G.audio.beep(bomb.pos, 1 - k); this.blink = 0.08;
        }
        this.blink = (this.blink || 0) - dt;
        this.bombLight.visible = this.blink > 0;
        if (this.phase !== 'planted') return;
        // разминирование
        let def = null;
        for (const a of g.actors) {
          if (!a.alive || a.team !== 0) continue;
          if (Math.hypot(a.pos.x - bomb.pos.x, a.pos.z - bomb.pos.z) < 1.5 && Math.hypot(a.vel.x, a.vel.z) < 1.2 && this.useHeld(a)) { def = a; break; }
        }
        if (def) {
          if (this.defuser !== def) { this.defuser = def; this.defuseT = 0; G.audio.defuseStart(bomb.pos); }
          this.defuseT += dt;
          if (this.defuseT >= this.defuseNeed(def)) {
            bomb.state = 'defused'; def.money = Math.min(16000, def.money + 300);
            G.audio.defused(bomb.pos);
            G.emit('defused', { a: def });
            G.chat.event('defused', { a: def });
            if (def.isPlayer) G.bp.ev('defuse');
            this.endRound(0, 'defuse');
          }
        } else { this.defuser = null; this.defuseT = 0; }
      }
    },
    defuseNeed(a) { return a && a.kit ? this.KIT : this.DEFUSE; },
    defuseLeft() { return this.defuser ? this.defuseNeed(this.defuser) - this.defuseT : 99; },
    plant(a, site) {
      const bomb = this.bomb;
      bomb.state = 'planted'; bomb.site = site; bomb.carrier = null; bomb.beepT = 0.5;
      a.hasBomb = false; a.using = false;
      bomb.pos.set(a.pos.x, 0, a.pos.z);
      this.bombMesh.position.copy(bomb.pos); this.bombMesh.rotation.y = a.yaw; this.bombMesh.visible = true;
      this.phase = 'planted'; this.t = this.BOMB;
      this.planter = null; this.plantT = 0;
      a.money = Math.min(16000, a.money + 300);
      this.assign = new Map();
      G.audio.planted();
      G.emit('planted', { a, site, x: bomb.pos.x, z: bomb.pos.z, yaw: a.yaw });
      G.hud.banner('БОМБА ЗАЛОЖЕНА', 'Точка ' + site, 'warn', 2.2);
      G.chat.event('planted', { s: site });
      if (a.isPlayer) G.bp.ev('plant');
      for (const b of this.g.actors) if (!b.isPlayer && b.team === 0 && b.alive) { b.alertPos = bomb.pos.clone(); b.alertT = this.g.time; b.path = null; }
    },
    explode() {
      const g = this.g, bomb = this.bomb;
      bomb.state = 'exploded';
      this.bombMesh.visible = false;
      G.emit('exploded', { x: bomb.pos.x, z: bomb.pos.z });
      G.fx.explosion(bomb.pos.x, 0.4, bomb.pos.z);
      G.audio.explosion(bomb.pos);
      for (const a of g.actors) {
        if (!a.alive) continue;
        const d = a.pos.distanceTo(bomb.pos);
        if (d < 22) a.damage(420 * Math.pow(1 - d / 22, 2.2), null, 'bomb', false, a.pos.clone().sub(bomb.pos).normalize());
      }
      if (g.player) {
        const d = g.player.pos.distanceTo(bomb.pos);
        g.shake = Math.max(g.shake || 0, G.clamp(1.4 - d / 40, 0.2, 1.2));
      }
      this.endRound(1, 'bomb');
    },
    dropBomb(a) {
      const bomb = this.bomb;
      if (!bomb || bomb.carrier !== a || bomb.state !== 'carried') return;
      a.hasBomb = false;
      bomb.state = 'dropped'; bomb.carrier = null;
      bomb.pos.set(a.pos.x, 0, a.pos.z);
      this.bombMesh.position.copy(bomb.pos); this.bombMesh.visible = true; this.bombLight.visible = false;
    },
    endRound(win, reason) {
      if (this.phase === 'end') return;
      const g = this.g;
      this.phase = 'end'; this.t = this.END; g.frozen = false;
      this.score[win]++;
      G.emit('roundEnd', { win, reason });
      const lose = 1 - win;
      (this.log = this.log || []).push(this.round + ':' + (win ? 'T' : 'CT') + ':' + reason);
      const winMoney = reason === 'bomb' || reason === 'defuse' ? 3500 : 3250;
      const loseMoney = 1400 + 500 * Math.min(this.loss[lose], 4) + (lose === 1 && this.bomb && (this.bomb.state === 'planted' || this.bomb.state === 'defused') ? 800 : 0);
      this.loss[win] = 0; this.loss[lose]++;
      for (const a of g.actors) a.money = Math.min(16000, a.money + (a.team === win ? winMoney : loseMoney));
      const pl = g.player;
      const mine = pl && pl.team === win;
      G.hud.banner(win === 0 ? 'СПЕЦНАЗ ПОБЕДИЛ' : 'НАЛЁТЧИКИ ПОБЕДИЛИ', REASON[reason], mine ? 'win' : 'lose', 4.5);
      G.audio.roundEnd(mine);
      G.chat.event('roundEnd', { win });
      if (this.g.player && this.g.player.team === win) G.bp.ev('round');
      if (mine && G.stats) G.stats.xp = (G.stats.xp || 0) + 10;
      const half = this.HALF;
      if (this.score[0] >= this.WIN || this.score[1] >= this.WIN || this.round >= this.MAX) this.matchOver = true;
      // ничья невозможна до конца; после 12 раундов — по счёту
      void half;
    },
    halftime() {
      const g = this.g;
      for (const a of g.actors) {
        a.team = 1 - a.team; a.money = 800; a.alive = false; a.armor = 0; a.helmet = false; a.kit = false; a.hasBomb = false;
        a.slots = { primary: null, secondary: null, melee: null, nade: null }; a.nades = { he: 0, flash: 0, smoke: 0 };
      }
      this.score = [this.score[1], this.score[0]];
      this.loss = [0, 0];
      if (g.clearVM) g.clearVM(true); else { g.vmCache = {}; g.vm = null; }
      G.emit('halftime', {});
    },
    // ---------- задачи ботов ----------
    point(b, key, gen) {
      let p = this.assign.get(b);
      if (!p || p.key !== key) { p = Object.assign({ key }, gen()); this.assign.set(b, p); }
      return p;
    },
    lookTo(x, z, tx, tz) { return Math.atan2(-(tx - x), -(tz - z)); },
    nearestBot(team, pos, exclude) {
      let best = null, bd = 1e9;
      for (const a of this.g.actors) {
        if (!a.alive || a.team !== team || a.isPlayer || a === exclude) continue;
        const d = a.pos.distanceTo(pos);
        if (d < bd) { bd = d; best = a; }
      }
      return best;
    },
    botGoal(b) {
      if (this.phase === 'freeze') return null;
      const bomb = this.bomb, g = this.g;
      const ctZone = G.map.spawnZones[0], tZone = G.map.spawnZones[1];
      const ctC = { x: (ctZone.x0 + ctZone.x1) / 2, z: (ctZone.z0 + ctZone.z1) / 2 }, tC = { x: (tZone.x0 + tZone.x1) / 2, z: (tZone.z0 + tZone.z1) / 2 };
      const near = (cx, cz, r) => { const p = G.nav.randomPoint((x, z) => Math.hypot(x - cx, z - cz) < r && Math.hypot(x - cx, z - cz) > 2); return p; };
      if (b.team === 1) {
        if (bomb.state === 'planted' || bomb.state === 'defused' || bomb.state === 'exploded') {
          const p = this.point(b, 'guard', () => near(bomb.pos.x, bomb.pos.z, 10));
          return { x: p.x, z: p.z, hold: true, look: this.lookTo(p.x, p.z, ctC.x, ctC.z) };
        }
        if (bomb.state === 'dropped') {
          const pl = g.player;
          const fetcher = this.nearestBot(1, bomb.pos);
          const plCloser = pl && pl.alive && pl.team === 1 && fetcher && pl.pos.distanceTo(bomb.pos) < fetcher.pos.distanceTo(bomb.pos);
          if (b === fetcher && !plCloser) return { x: bomb.pos.x, z: bomb.pos.z, urgent: true };
        }
        // сбор перед атакой: до сигнала ждём на точке сбора (сигнал — время, контакт с врагом или мало своих)
        if (!this.plan.go && this.phase === 'live') {
          const ts = g.actors.filter(a => a.alive && a.team === 1);
          if (this.ROUND - this.t > this.plan.wait || ts.length <= 1 || ts.some(a => a.tVisible || (g.time - (a.lastHitT || -99) < 1))) this.plan.go = true;
        }
        if (!this.plan.go) {
          const st = this.plan.stage, sc = G.map.sites[this.plan.site];
          const p = this.point(b, 'stage', () => near(st.x, st.z, st.r || 7) || st);
          return { x: p.x, z: p.z, hold: true, walk: b.hasBomb, look: this.lookTo(p.x, p.z, (sc.x0 + sc.x1) / 2, (sc.z0 + sc.z1) / 2) };
        }
        if (b.hasBomb) {
          // уже на любой точке — закладываем прямо здесь
          if (this.phase === 'live' && G.map.inSite(b.pos.x, b.pos.z)) return { x: b.pos.x, z: b.pos.z, act: 'plant', urgent: true, look: this.lookTo(b.pos.x, b.pos.z, ctC.x, ctC.z) };
          const sp = this.plan.spot, s = G.map.sites[this.plan.site];
          // идём позади своих, пока они не зайдут на точку
          const mates = g.actors.filter(a => a.alive && a.team === 1 && a !== b);
          const inSite = mates.some(a => a.pos.x > s.x0 && a.pos.x < s.x1 && a.pos.z > s.z0 && a.pos.z < s.z1);
          const ahead = mates.some(a => a.pos.distanceTo(b.pos) < 14);
          return { x: sp.x, z: sp.z, act: 'plant', urgent: true, walk: !inSite && ahead && this.t > 50, look: this.lookTo(sp.x, sp.z, ctC.x, ctC.z) };
        }
        const s = G.map.sites[this.plan.site];
        const p = this.point(b, 'site' + this.plan.site, () => G.nav.randomInRect(s.x0, s.x1, s.z0, s.z1));
        return { x: p.x, z: p.z, hold: true, look: this.lookTo(p.x, p.z, ctC.x, ctC.z) };
      }
      // спецназ
      if (bomb.state === 'planted') {
        const pl = g.player;
        const def = this.nearestBot(0, bomb.pos);
        const plDef = pl && pl.alive && pl.team === 0 && def && pl.pos.distanceTo(bomb.pos) < 2;
        if (b === def && !plDef) return { x: bomb.pos.x, z: bomb.pos.z, act: 'defuse', urgent: true };
        const p = this.point(b, 'cover', () => near(bomb.pos.x, bomb.pos.z, 9));
        return { x: p.x, z: p.z, hold: true, look: this.lookTo(p.x, p.z, tC.x, tC.z), urgent: true };
      }
      if (this.alert && g.time - this.alert.t < 14) {
        const s = G.map.sites[this.alert.site];
        const p = this.point(b, 'rot' + this.alert.site, () => G.nav.randomInRect(s.x0, s.x1, s.z0, s.z1));
        return { x: p.x, z: p.z, hold: true, look: this.lookTo(p.x, p.z, tC.x, tC.z) };
      }
      const keys = Object.keys(G.map.sites);
      const idx = g.actors.filter(a => a.team === 0 && !a.isPlayer).indexOf(b);
      const site = keys[idx % keys.length];
      const s = G.map.sites[site];
      const p = this.point(b, 'hold' + site, () => G.nav.randomInRect(s.x0 + 1, s.x1 - 1, s.z0 + 1, s.z1 - 1));
      return { x: p.x, z: p.z, hold: true, look: this.lookTo(p.x, p.z, tC.x, tC.z) };
    },
    spotted(bot, enemy) {
      if (bot.team !== 0 || this.phase !== 'live') return;
      for (const k in G.map.sites) {
        const s = G.map.sites[k];
        const dx = Math.max(s.x0 - enemy.pos.x, 0, enemy.pos.x - s.x1), dz = Math.max(s.z0 - enemy.pos.z, 0, enemy.pos.z - s.z1);
        if (Math.hypot(dx, dz) < 12) { if (!this.alert || this.alert.site !== k) this.alert = { site: k, t: this.g.time }; else this.alert.t = this.g.time; }
      }
    },
    onKill(killer, victim, wid) {
      if (victim.hasBomb) this.dropBomb(victim);
      if (victim.using) victim.using = false;
      if (killer && killer !== victim && killer.team !== victim.team) {
        const d = G.WEAPONS[wid];
        killer.money = Math.min(16000, killer.money + (d && d.reward ? d.reward : 300));
        killer.roundKills = (killer.roundKills || 0) + 1;
      }
    }
  };

  G.MODE_NAMES = { bomb: 'Закладка бомбы', tdm: 'Командный бой', ffa: 'Бой насмерть', duel: 'Дуэль 1 на 1', tutorial: 'Обучение' };
  // ===================== Дуэль 1 на 1 =====================
  // короткие раунды до первого убийства: оба на своих концах карты, полная броня, без гранат; до 7 побед
  G.duelMode = {
    WIN: 7, PAUSE: 2.6, FREEZE: 2.2, MATCH: 420, ROUND: 60,
    phase: 'none', round: 0, t: 0,
    setup(g) {
      this.g = g; this.round = 0; this.phase = 'none'; this.t = 0;
      g.killLimit = this.WIN; g.timeLeft = this.MATCH; g.scores = [0, 0];
      this.nextRound(g);
    },
    // 11.9: в дуэли нет снайперских винтовок — AWM и SSG 08 не выдаются и не выбираются (любое оружие с оптикой)
    allowed(id) { const d = G.WEAPONS[id]; return !!d && d.slot === 'primary' && !d.scope; },
    // что получит боец вместо запрещённого ствола: своя штурмовая винтовка стороны
    pick(id, team) { return this.allowed(id) ? id : team === 1 ? 'ar' : 'ar2'; },
    // случайное основное оружие бота-соперника без снайперок
    randomPrimary(team) {
      const L = team === 1 ? ['ar', 'ar', 'galil', 'smg', 'shotgun'] : ['ar2', 'm4s', 'famas', 'smg', 'shotgun'];
      return L[Math.floor(Math.random() * L.length)];
    },
    // броня и шлем каждому, гранат нет — чистая перестрелка
    prepare(a) {
      // страховка (в т.ч. для сервера): запрещённый ствол в слоте заменяется до начала раунда
      const pr = a.slots && a.slots.primary;
      if (pr && !this.allowed(pr.id)) {
        a.loadout(this.pick(pr.id, a.team));
        if (!G.HEADLESS && !a.isPlayer && a.buildModel) a.buildModel(a.w.id);
      }
      a.armor = 100; a.helmet = true; a.protect = 0;
      a.nades = { he: 0, flash: 0, smoke: 0 }; if (a.syncNade) a.syncNade();
      if (a.cur === 'nade') a.cur = a.slots.primary ? 'primary' : 'secondary';
    },
    nextRound(g) {
      this.round++;
      if (G.nades && G.nades.reset) G.nades.reset();
      for (const a of g.actors) { g.respawn(a); this.prepare(a); }
      this.phase = 'freeze'; this.t = this.FREEZE; g.frozen = true;
      if (g.onRoundStart && !G.HEADLESS) { /* клиент: камера/оружие уже сброшены в respawn */ }
      G.emit('duelRound', { round: this.round, sc: g.scores.slice() });
      if (!G.HEADLESS && g.player) {
        G.hud.banner('РАУНД ' + this.round, g.scores[0] + ' : ' + g.scores[1] + ' · до ' + this.WIN + ' побед', 't' + g.player.team);
      }
    },
    // кто-то погиб: раунд окончен, очко — убийце (или сопернику погибшего)
    onKill(g, killer, victim) {
      if (this.phase !== 'live' && this.phase !== 'freeze') return;
      if (killer && killer !== victim) g.scores[killer.team]++;
      else { const t = 1 - victim.team; if (t === 0 || t === 1) g.scores[t]++; }
      this.phase = 'end'; this.t = this.PAUSE;
      if (g.scores[0] >= this.WIN || g.scores[1] >= this.WIN) { g.endMatch(); return; }
      if (!G.HEADLESS && g.player) {
        const won = killer && killer !== victim ? killer.team === g.player.team : victim.team !== g.player.team;
        G.hud.message(won ? 'РАУНД ВАШ' : 'РАУНД ПРОИГРАН', won ? 'head' : '');
      }
    },
    update(g, dt) {
      if (g.over) return;
      if (this.phase === 'freeze') {
        this.t -= dt;
        if (this.t <= 0) { this.phase = 'live'; this.t = this.ROUND; g.frozen = false; G.emit('live', {}); if (!G.HEADLESS) { G.audio.go(); G.hud.message('В БОЙ!', 'head'); } }
      } else if (this.phase === 'live') {
        this.t -= dt;
        if (this.t <= 0) this.timeUp(g);
      } else if (this.phase === 'end') {
        this.t -= dt;
        if (this.t <= 0) this.nextRound(g);
      }
    },
    // время раунда вышло: очко тому, у кого больше здоровья (поровну — ничья)
    timeUp(g) {
      const hp = [0, 0];
      for (const a of g.actors) if (a.alive && (a.team === 0 || a.team === 1)) hp[a.team] += a.hp;
      const w = hp[0] > hp[1] ? 0 : hp[1] > hp[0] ? 1 : -1;
      if (w >= 0) g.scores[w]++;
      this.phase = 'end'; this.t = this.PAUSE;
      G.emit('duelTime', { w });
      if (g.scores[0] >= this.WIN || g.scores[1] >= this.WIN) { g.endMatch(); return; }
      if (!G.HEADLESS && g.player) this.timeMsg(w, g.player.team);
    },
    timeMsg(w, my) {
      G.hud.message(w < 0 ? 'ВРЕМЯ ВЫШЛО · НИЧЬЯ' : w === my ? 'ВРЕМЯ ВЫШЛО · РАУНД ВАШ' : 'ВРЕМЯ ВЫШЛО · РАУНД ПРОИГРАН', w === my ? 'head' : '');
    },
    // в комнату пришёл или ушёл человек: счёт заново, свежий раунд
    restart(g) { g.scores = [0, 0]; this.round = 0; g.timeLeft = this.MATCH; this.nextRound(g); }
  };
})(window.G);
