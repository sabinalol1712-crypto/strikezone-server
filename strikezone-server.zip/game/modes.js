'use strict';
/* Режим «Закладка бомбы»: раунды, экономика, магазин, бомба, задачи ботов */
(function (G) {
  const V3 = THREE.Vector3;
  G.SHOP = [
    { cat: 'Пистолеты', items: ['usp', 'pistol', 'duals', 'fiveseven', 'tec9', 'magnum'] },
    { cat: 'ПП и дробовики', items: ['smg', 'shotgun'] },
    { cat: 'Винтовки', items: ['galil', 'famas', 'ar', 'ar2', 'm4s', 'ssg', 'sniper'] },
    { cat: 'Гранаты', items: ['he', 'flash', 'smoke'] },
    { cat: 'Снаряжение', items: ['armor', 'helmet', 'kit'] }
  ];
  G.EQUIP = {
    armor: { name: 'Бронежилет', cls: 'Броня 100', price: 650 },
    helmet: { name: 'Броня + шлем', cls: 'Защищает голову', price: 1000 },
    kit: { name: 'Набор сапёра', cls: 'Разминирование быстрее', price: 400, team: 0 }
  };
  const REASON = { elim: 'Все противники уничтожены', time: 'Время вышло', bomb: 'Бомба взорвана', defuse: 'Бомба обезврежена' };

  const B = G.bombMode = {
    ROUND: 115, FREEZE: 7, BOMB: 40, PLANT: 3.2, DEFUSE: 8, KIT: 4.5, END: 5, BUY: 22, WIN: 7, HALF: 6, MAX: 12,
    DEF_RULES: { WIN: 7, HALF: 6, MAX: 12 },   // 2.10: для одиночной игры после онлайн-матча с другими правилами

    setup(g, n) {
      this.g = g;
      const names = g.botNames();
      const p = g.player;
      // сторона в первой половине — по выбору игрока (налётчики закладывают, спецназ обезвреживает)
      const pt = p.team === 0 || p.team === 1 ? p.team : 1;
      p.team = pt;
      for (let i = 0; i < n - 1; i++) g.actors.push(new G.Bot(names.pop(), pt, g.scene));
      for (let i = 0; i < n; i++) g.actors.push(new G.Bot(names.pop(), 1 - pt, g.scene));
      for (const a of g.actors) { a.money = 800; a.alive = false; }
      this.round = 0; this.score = [0, 0]; this.loss = [0, 0]; this.over = false; this.matchOver = false;
      this.alert = null; this.spectate = null;
      if (!this.bombMesh) this.makeBombMesh(g.scene);
      this.startRound();
    },
    makeBombMesh(scene) {
      if (G.HEADLESS || !scene) { this.bombMesh = { visible: false, position: new V3(), rotation: { y: 0 } }; this.bombLight = { visible: false }; return; }
      const grp = new THREE.Group();
      // 2.10: та же модель, что в руках (связка шашек с пультом), в полтора раза крупнее — заметна на полу
      const S = 1.5, D = G.C4DIM, parts = G.c4Parts().body;
      const inner = new THREE.Group();
      inner.add(new THREE.Mesh(G.geo.build(parts.filter(p => !p.em)), G.getVCMat()), new THREE.Mesh(G.geo.build(parts.filter(p => p.em)), G.emMat()));
      inner.scale.setScalar(S); inner.position.y = (D.hy + 0.0018) * S;
      const light = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('dot'), color: 0xff3020, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      // мигающий огонёк — над красным индикатором пульта
      const K = D.key;
      light.scale.set(0.3, 0.3, 1); light.position.set((K.x0 + 3 * K.px + 0.006) * S, (D.unit.y1 + 0.004 + D.hy + 0.0018) * S, -0.002 * S);
      grp.add(inner, light);
      grp.visible = false;
      scene.add(grp);
      this.bombMesh = grp; this.bombLight = light;
    },
    teamAlive(t) { const A = this.g.actors; let n = 0; for (let i = 0; i < A.length; i++) if (A[i].alive && A[i].team === t) n++; return n; }, // 2.3 perf: без временного массива (дважды за кадр)
    spawnAll() {
      const g = this.g;
      for (const a of g.actors) a.alive = false;
      for (const a of g.actors) {
        const sp = g.spawnPoint(a);
        a.pos.set(sp.x, 0, sp.z); a.yaw = sp.yaw;
        a.alive = true;
      }
    },
    startRound() {
      const g = this.g;
      if (g.beforeRound) g.beforeRound();   // 2.10: сервер — убрать лишнего бота за вернувшегося игрока (см. sgame.addHuman)
      this.round++;
      const pistol = this.round === 1 || this.round === this.HALF + 1;
      this.pistol = pistol;
      this.phase = 'freeze'; this.t = this.FREEZE; this.buyT = this.BUY; g.frozen = true;
      this.assign = new Map(); this.alert = null; this.plantT = 0; this.defuseT = 0; this.defuser = null; this.planter = null;
      for (const a of g.actors) {
        // выживший оставляет оружие; пистолет он мог выбросить — тогда держится за основное
        const keep = a.alive && !pistol && a.slots && (a.slots.secondary || a.slots.primary);
        if (!keep) { a.loadout(null); a.armor = 0; a.helmet = false; a.kit = false; }
        else {
          for (const k of ['primary', 'secondary']) { const st = a.slots[k]; if (st) { st.mag = st.def.mag; st.reserve = st.def.reserve; st.reloadT = 0; } }
          a.cur = a.slots.primary ? 'primary' : 'secondary';
        }
        a.hp = 100; a.deadT = 0; a.protect = 0; a.vel.set(0, 0, 0); a.using = false; a.hasBomb = false; a.scoped = false;
        a.afterThrow = 0; a.throwAnimT = 0; a.blindT = 0; a.smokeUsed = false; a.entryNade = false; if (a.slots.nade) a.slots.nade.throwT = 0;
        a.recoilPitch = 0; a.recoilYaw = 0; a.crouch = false; a.crouchT = 0; a.height = 1.8; a.pitch = 0; a.autoReload = 0; a.roundKills = 0;
        a.bought = []; a.req = null; a.reqN = 0; // 2.8: покупки раунда (для возврата) и запрос оружия у команды
      }
      this.spawnAll();
      for (const a of g.actors) if (!a.isPlayer && !a.net) this.botBuy(a);
      this.helpT = 0; this.asked = {};
      for (const a of g.actors) if (!a.isPlayer && !a.net) this.botAsk(a);
      for (const a of g.actors) {
        if (a.isPlayer) continue;
        const wid = a.w.id;
        if (a.modelW !== wid || a.modelTeam !== a.team || !a.bodyMesh) a.buildModel(wid);
        a.setLabel(g.player && a.team === g.player.team);
        a.spawned();
      }
      // бомба
      const ts = g.actors.filter(a => a.team === 1);
      let carrier = G.pick(ts.filter(a => !a.isPlayer));
      const pl = g.player;
      if (pl && pl.team === 1 && Math.random() < 0.35) carrier = pl;
      // сетевая игра: бомба у случайного бойца атаки, люди тоже участвуют
      // 2.9: не тому, чьё место ждёт его возвращения (обрыв связи); никого нет — любому из атаки
      if (g.net) { const hum = ts.filter(a => a.net && !a.away), bots = ts.filter(a => !a.net); carrier = (hum.length && (Math.random() < 0.5 || !bots.length) ? G.pick(hum) : G.pick(bots)) || G.pick(ts); }
      this.bomb = { state: 'carried', carrier, pos: new V3() };
      carrier.hasBomb = true;
      this.bombMesh.visible = false;
      // план атаки
      const sites = Object.keys(G.map.sites);
      this.plan = { site: G.pick(sites) };
      const s = G.map.sites[this.plan.site];
      this.plan.spot = G.nav.randomInRect(s.x0 + 2, s.x1 - 2, s.z0 + 1.5, s.z1 - 1.5);
      // точка сбора атаки: на полпути к точке; ждём там, потом заходим вместе
      const tz = G.map.spawnZones[1], path = G.nav.findPath((tz.x0 + tz.x1) / 2, (tz.z0 + tz.z1) / 2, (s.x0 + s.x1) / 2, (s.z0 + s.z1) / 2);
      let stage = { x: (tz.x0 + tz.x1) / 2, z: (tz.z0 + tz.z1) / 2 };
      if (path && path.length) {
        let total = 0, prev = stage; const seg = [];
        for (const q of path) { const d = Math.hypot(q.x - prev.x, q.z - prev.z); seg.push([prev, q, d]); total += d; prev = q; }
        let need = total * G.rand(0.5, 0.62);
        for (const [a, b2, d] of seg) { if (need <= d) { const t = d ? need / d : 0; stage = { x: a.x + (b2.x - a.x) * t, z: a.z + (b2.z - a.z) * t }; break; } need -= d; }
      }
      // карта с одной точкой и несколькими маршрутами к ней: точка сбора — на случайном маршруте
      const stg = G.map.def && G.map.def.stages;
      if (stg && stg.length && Math.random() < 0.85) { const q = G.pick(stg), k = G.map.def.scale || 1; stage = { x: q[0] * k, z: q[1] * k, r: 3.5 }; }
      const dw = G.map.def && G.map.def.stageWait;
      this.plan.stage = stage; this.plan.wait = dw ? G.rand(dw[0], dw[1]) : G.rand(14, 26); this.plan.go = false;
      // карта с заданными местами закладки: одно из двух ближайших к точке сбора (заход с того же маршрута, за укрытием)
      const pspots = G.map.def && G.map.def.plantSpots;
      if (pspots && pspots.length) {
        const k = G.map.def.scale || 1, near = pspots.map(q => ({ x: q[0] * k, z: q[1] * k })).sort((p, q) => Math.hypot(p.x - stage.x, p.z - stage.z) - Math.hypot(q.x - stage.x, q.z - stage.z));
        this.plan.spot = near[Math.random() < 0.7 ? 0 : Math.min(1, near.length - 1)];
      }
      g.onRoundStart();
      G.emit('roundStart', { round: this.round, pistol, half: this.round === this.HALF + 1 });
      if (pl) {
        const sub = pistol ? 'Пистолетный раунд' : (pl.team === 1 ? 'Атака: заложите бомбу на точке ' + sites.join(' или ') : 'Защита: не дайте заложить бомбу');
        G.hud.banner(this.round === this.HALF + 1 ? 'СМЕНА СТОРОН' : 'РАУНД ' + this.round, sub, pl.team === 1 ? 't1' : 't0');
        if (pl.hasBomb) setTimeout(() => G.hud.message('БОМБА У ВАС', 'head'), 2600);
      }
      G.chat.reset(); setTimeout(() => G.chat.event('round'), 2200);
    },
    // ---------- магазин ----------
    canBuy(a) {
      if (!a || !a.alive || this.buyT <= 0) return false;
      const z = G.map.spawnZones[a.team];
      return a.pos.x > z.x0 - 8 && a.pos.x < z.x1 + 8 && a.pos.z > z.z0 - 8 && a.pos.z < z.z1 + 8;
    },
    price(a, id) {
      if (id === 'helmet') return (a.armor >= 100 && !a.helmet) ? 350 : 1000;
      return (G.EQUIP[id] || G.WEAPONS[id]).price;
    },
    owned(a, id) {
      if (id === 'armor') return a.armor >= 100;
      if (id === 'helmet') return a.armor >= 100 && a.helmet;
      if (id === 'kit') return a.kit;
      const d = G.WEAPONS[id];
      if (d.nade) return (a.nades[id] || 0) >= 1;
      return !!(a.slots[d.slot] && a.slots[d.slot].id === id);
    },
    // предмет магазина, доступный стороне бойца
    shopOk(a, id) {
      if (typeof id !== 'string' || !G.SHOP.some(c => c.items.includes(id))) return false;
      const eq = G.EQUIP[id], wd = G.WEAPONS[id];
      if (!eq && !wd) return false;
      const tm = eq ? eq.team : wd.team;
      return !(tm != null && tm !== a.team);
    },
    buy(a, id) {
      if (!this.canBuy(a) || !this.shopOk(a, id)) return false;
      if (this.owned(a, id)) return false;
      const price = this.price(a, id);
      if (a.money < price) return false;
      a.money -= price;
      this.grant(a, id, a, price);
      if (a.isPlayer) G.audio.buy();
      return true;
    },
    // 2.8: выдать купленное и запомнить покупку раунда (для возврата): кто платил, что было в слоте до неё
    grant(t, id, payer, price) {
      const rec = { id, price, payer, round: this.round };
      if (id === 'armor') { rec.pa = t.armor; rec.ph = t.helmet; t.armor = 100; }
      else if (id === 'helmet') { rec.pa = t.armor; rec.ph = t.helmet; t.armor = 100; t.helmet = true; }
      else if (id === 'kit') t.kit = true;
      else {
        const d = G.WEAPONS[id];
        if (!d.nade) { rec.slot = d.slot; rec.prev = t.slots[d.slot] || null; }
        t.give(id);
        if (!d.nade) { rec.st = t.slots[d.slot]; rec.mag = rec.st.mag; rec.res = rec.st.reserve; }
        // бот с новым стволом: модель в руках обновится сразу (а не со следующим раундом)
        if (!t.isPlayer && !t.net && t.buildModel && !G.HEADLESS && t.w && t.modelW !== t.w.id) t.buildModel(t.w.id);
      }
      (t.bought || (t.bought = [])).push(rec);
      if (t.req && t.req.id === id) this.request(t, null, payer !== t ? payer : null);
      return rec;
    },
    // 2.8: купить тиммейту (он рядом с базой, время покупки идёт); вещь сразу у него в руках
    buyFor(a, t, id) {
      if (!a || !t || t === a || !t.alive || t.team !== a.team) return false;
      if (!this.canBuy(a) || !this.canBuy(t) || !this.shopOk(t, id) || this.owned(t, id)) return false;
      const price = this.price(t, id);
      if (a.money < price) return false;
      a.money -= price;
      this.grant(t, id, a, price);
      G.emit('bgift', { a, t, id });
      if (a.isPlayer) G.audio.buy();
      return true;
    },
    // 2.8: возврат: куплено в этом раунде, ещё в руках и не использовано, время покупки и база — деньги тому, кто платил
    refundable(a, id) {
      const L = a && a.bought;
      if (!L || !L.length || !this.canBuy(a)) return null;
      for (let i = L.length - 1; i >= 0; i--) {
        const r = L[i];
        if (r.id !== id) continue;
        if (r.round !== this.round) return null;
        if (id === 'armor' || id === 'helmet') {
          for (let j = i + 1; j < L.length; j++) if (L[j].id === 'armor' || L[j].id === 'helmet') return null; // сначала — последняя покупка брони
          return a.armor >= 100 && (id !== 'helmet' || a.helmet) ? r : null;
        }
        if (id === 'kit') return a.kit ? r : null;
        const d = G.WEAPONS[id];
        if (!d) return null;
        if (d.nade) return (a.nades[id] | 0) > 0 && !(a.slots.nade && a.slots.nade.id === id && (a.slots.nade.throwT > 0 || a.slots.nade.pinT > 0)) ? r : null;
        const st = a.slots[r.slot];
        return st && st === r.st && st.mag === r.mag && st.reserve === r.res && !(st.reloadT > 0) ? r : null;
      }
      return null;
    },
    refundList(a) {
      const out = [];
      if (!a || !a.bought || !a.bought.length || !this.canBuy(a)) return out;
      for (const r of a.bought) if (!out.includes(r.id) && this.refundable(a, r.id)) out.push(r.id);
      return out;
    },
    refund(a, id) {
      const r = this.refundable(a, id); if (!r) return false;
      a.bought.splice(a.bought.indexOf(r), 1);
      if (id === 'armor' || id === 'helmet') { a.armor = r.pa; a.helmet = r.ph; }
      else if (id === 'kit') a.kit = false;
      else {
        const d = G.WEAPONS[id];
        if (d.nade) {
          a.nades[id] = Math.max(0, (a.nades[id] | 0) - 1); a.syncNade();
          if (a.cur === 'nade' && !a.slots.nade) a.cur = a.slots.primary ? 'primary' : a.slots.secondary ? 'secondary' : 'melee';
        } else {
          a.slots[r.slot] = r.prev;
          if (r.slot === 'primary') a.primaryId = r.prev ? r.prev.id : null;
          if (a.cur === r.slot) {
            if (r.prev) r.prev.drawT = 0.3;
            else a.cur = a.slots.primary ? 'primary' : a.slots.secondary ? 'secondary' : 'melee';
            if (a.slots[a.cur]) a.slots[a.cur].drawT = 0.3;
          }
          a.scoped = false;
          if (!a.isPlayer && !a.net && a.buildModel && !G.HEADLESS && a.w && a.modelW !== a.w.id) a.buildModel(a.w.id);
        }
      }
      // деньги тому, кто платил (тиммейт, купивший вам, — если ещё в игре)
      const payer = r.payer && r.payer !== a && this.g.actors.includes(r.payer) && r.payer.team === a.team ? r.payer : a;
      payer.money = Math.min(16000, payer.money + r.price);
      G.emit('refund', { a, id, amt: r.price, payer });
      if (a.isPlayer) G.audio.buy();
      return true;
    },
    // 2.8: запрос оружия у команды (не хватает денег): id — что нужно, null — отменить; by — кто купил
    request(a, id, by) {
      if (!a) return false;
      // 2.9: запросы игрока по сети — не чаще раза в 0,6 с и не больше 10 за раунд (каждый — сигнал и строка в чате у команды)
      // 2.10: отмена запроса (id = null) — без ограничения: купил сам сразу после просьбы — запрос у команды гаснет
      if (a.net && !by && id != null) { const t = this.g.time; if (t - (a.reqT != null ? a.reqT : -9) < 0.6 || (a.reqN | 0) >= 10) return false; a.reqT = t; a.reqN = (a.reqN | 0) + 1; }
      if (id != null) {
        if (!a.alive || !this.canBuy(a) || !this.shopOk(a, id) || this.owned(a, id)) return false;
        if (a.req && a.req.id === id) return true;
        a.req = { id, t: this.g.time, wait: 0.8 + Math.random() * 1.6 };
      } else {
        if (!a.req) return false;
        a.req = null;
      }
      G.emit('breq', { a, id: id || null, by: by || null });
      return true;
    },
    // бот без основного оружия просит винтовку, если в команде есть люди
    botAsk(b) {
      if (this.pistol || !b.alive || b.slots.primary) return;
      const g = this.g, asked = this.asked || (this.asked = {});
      if (asked[b.team]) return; // не больше одного запроса бота на команду за раунд
      const want = b.team === 1 ? (Math.random() < 0.6 ? 'ar' : 'galil') : (Math.random() < 0.55 ? 'm4s' : 'famas');
      // просит, только если у кого-то из людей команды хватает с запасом
      const price = this.price(b, want);
      if (!g.actors.some(x => (x.isPlayer || x.net) && x.team === b.team && x.money >= price + 650)) return;
      if (Math.random() > 0.6) return;
      asked[b.team] = true;
      this.request(b, want);
    },
    // боты выполняют запросы людей своей команды (покупают тем, у кого есть деньги с запасом)
    botHelp(dt) {
      this.helpT = (this.helpT || 0) - dt;
      if (this.helpT > 0) return;
      this.helpT = 0.4;
      const g = this.g, now = g.time;
      for (const r of g.actors) {
        if (!r.req || !r.alive || (!r.isPlayer && !r.net)) continue;
        if (now - r.req.t < r.req.wait) continue;
        const id = r.req.id, price = this.price(r, id);
        let best = null;
        for (const b of g.actors) {
          if (b.isPlayer || b.net || !b.alive || b.team !== r.team || !this.canBuy(b)) continue;
          const left = b.money - price;
          if (left < 0 || (left < 800 && !b.slots.primary)) continue;
          if (!best || b.money > best.money) best = b;
        }
        if (best && this.buyFor(best, r, id)) {
          const d = G.WEAPONS[id] || G.EQUIP[id];
          if (G.chat && !G.HEADLESS && r.isPlayer) G.chat.say(best, ['Держи ' + d.name + '!', 'Лови ' + d.name, d.name + ' — твой', 'Купил, держи'][Math.random() * 4 | 0], false, true);
        }
      }
    },
    botBuy(b) {
      const m = () => b.money;
      // 11.9: у каждой стороны свой дешёвый пистолет за $500 (Five-SeveN у спецназа, Tec-9 у налётчиков)
      const side = b.team === 1 ? 'tec9' : 'fiveseven';
      if (this.pistol) {
        if (Math.random() < 0.45 && m() >= 650) this.buy(b, 'armor');
        else if (Math.random() < 0.35 && m() >= 700) this.buy(b, 'magnum');
        else if (Math.random() < 0.3 && m() >= 300) this.buy(b, 'duals'); // 2.5
        else if (Math.random() < 0.4 && m() >= 500) this.buy(b, side);
        return;
      }
      if (b.slots.primary) { if (b.armor < 100 && m() >= 650) this.buy(b, 'armor'); return; }
      // пистолет покупается раньше основного: после покупки в руках остаётся то, что взяли последним
      if (m() >= 3000 && Math.random() < 0.18) this.buy(b, side);
      let rifle = b.team === 1 ? (Math.random() < 0.36 ? 'galil' : 'ar') : (() => { const r = Math.random(); return r < 0.28 ? 'famas' : r < 0.55 ? 'm4s' : 'ar2'; })();
      // не хватает на дорогую винтовку — чаще берут дешёвую (Galil / FAMAS) вместо ПП
      const cheap = b.team === 1 ? 'galil' : 'famas';
      if (m() < G.WEAPONS[rifle].price + 650 && m() >= G.WEAPONS[cheap].price + 650 && Math.random() < 0.8) rifle = cheap;
      if (m() >= 4750 + 1000 && Math.random() < 0.18) { this.buy(b, 'sniper'); this.buy(b, 'helmet'); }
      else if (m() >= G.WEAPONS.ssg.price + 650 && Math.random() < (m() >= 4000 ? 0.07 : 0.13)) { this.buy(b, 'ssg'); if (m() >= 1000) this.buy(b, 'helmet'); else this.buy(b, 'armor'); }
      else if (m() >= G.WEAPONS[rifle].price + 650) { this.buy(b, rifle); if (m() >= 1000) this.buy(b, 'helmet'); else this.buy(b, 'armor'); }
      else if (m() >= 2000 || this.round >= this.MAX - 1) { this.buy(b, Math.random() < 0.6 ? 'smg' : 'shotgun'); if (m() >= 650) this.buy(b, 'armor'); }
      else if (Math.random() < 0.3 && m() >= 700) this.buy(b, 'magnum');
      else if (Math.random() < 0.2 && m() >= 300) this.buy(b, 'duals'); // 2.5
      else if (Math.random() < 0.4 && m() >= 500) this.buy(b, side);
      if (b.slots.primary) b.cur = 'primary';
      if (b.team === 0 && m() >= 400 && Math.random() < 0.5) this.buy(b, 'kit');
      // гранаты на остаток денег
      const pref = b.team === 1 ? [['smoke', 0.55], ['flash', 0.5], ['he', 0.45]] : [['he', 0.45], ['flash', 0.45], ['smoke', 0.25]];
      for (const [id, ch] of pref) if (m() >= G.WEAPONS[id].price && Math.random() < ch + 0.2) this.buy(b, id);
    },
    // вспышка/осколочная на точку: атака (налётчики) или отбитие заложенной бомбы (спецназ) — раз за раунд
    nadeSpot(b) {
      if (b.entryNade || this.phase === 'freeze') return null;
      if (b.team === 1 && this.plan && this.plan.go && this.phase === 'live') {
        const s = G.map.sites[this.plan.site];
        return { type: b.nades.flash > 0 ? 'flash' : 'he', x: (s.x0 + s.x1) / 2, y: 1.8, z: (s.z0 + s.z1) / 2 };
      }
      if (b.team === 0 && this.phase === 'planted' && this.bomb && this.bomb.state === 'planted') {
        const bp = this.bomb.pos;
        return { type: b.nades.flash > 0 ? 'flash' : 'he', x: bp.x, y: 1.6, z: bp.z };
      }
      return null;
    },
    // точка для дымовой: между точкой атаки и спавном спецназа, один бросок за раунд
    smokeSpot(b) {
      if (b.team !== 1 || b.smokeUsed || !this.plan || !this.plan.go || this.phase !== 'live') return null;
      const s = G.map.sites[this.plan.site], cz = G.map.spawnZones[0];
      const sx = (s.x0 + s.x1) / 2, sz = (s.z0 + s.z1) / 2, dx = (cz.x0 + cz.x1) / 2 - sx, dz = (cz.z0 + cz.z1) / 2 - sz, d = Math.hypot(dx, dz) || 1;
      const k = Math.min(9, d * 0.45);
      const p = { x: sx + dx / d * k, z: sz + dz / d * k };
      const self = this;
      return { x: p.x, z: p.z, set used(v) { b.smokeUsed = true; void self; } };
    },
    // ---------- цикл ----------
    update(dt) {
      const g = this.g;
      this.buyT -= dt;
      if (this.buyT > 0) this.botHelp(dt);
      if (this.phase === 'freeze') {
        this.t -= dt;
        if (this.t <= 0) { this.phase = 'live'; this.t = this.ROUND; g.frozen = false; G.audio.go(); G.hud.message('В БОЙ!', 'head'); G.emit('live', {}); }
        return;
      }
      if (this.phase === 'end') {
        this.t -= dt;
        if (this.t <= 0) {
          if (this.matchOver) { g.endMatch(); return; }
          if (this.round === this.HALF) this.halftime();
          this.startRound();
        }
        this.tickBomb(dt);
        return;
      }
      this.t -= dt;
      this.tickBomb(dt);
      if (this.phase === 'live' && this.t <= 0) { this.endRound(0, 'time'); return; }
      if (this.phase === 'planted' && this.t <= 0) { this.explode(); return; }
      const ct = this.teamAlive(0), t = this.teamAlive(1);
      if (ct === 0) this.endRound(1, 'elim');
      else if (t === 0 && this.phase === 'live') this.endRound(0, 'elim');
    },
    // 2.10: стоит на полу (луч вниз; над водой — да): сетевым закладчикам не верим на слово
    onFloor(a) { if (!G.drops || !G.drops.floorAt) return true; const fy = G.drops.floorAt(a.pos.x, a.pos.y, a.pos.z); return fy == null || a.pos.y - fy < 0.35; },
    // 2.10: можно ли этому бойцу обезвреживать бомбу отсюда — одна проверка для кнопки и для самого разминирования:
    // рядом по горизонтали и по высоте и бомба видна (не через стену)
    DEF_R: 1.5,
    canDefuse(a) {
      const b = this.bomb; if (!b || b.state !== 'planted' || !a || !a.alive || a.team !== 0) return false;
      // 2.1.1: бомба на ящике (выше ног) — дотянуться можно и снизу, с 2,4 м: боты на ящики не запрыгивают, и такую бомбу
      // раньше некому было обезвредить (налётчики выигрывали раунд закладкой на ящик)
      const dy = (b.pos.y || 0) - a.pos.y, R = dy > 0.3 ? 2.4 : this.DEF_R;
      if (Math.hypot(a.pos.x - b.pos.x, a.pos.z - b.pos.z) >= R || Math.abs(dy) >= 1.7) return false;
      return !G.map.clear || G.map.clear(a.pos.x, a.pos.y + 1.1, a.pos.z, b.pos.x, (b.pos.y || 0) + 0.15, b.pos.z);
    },
    useHeld(a) { if (a.net) return !!a.netUse && !this.g.frozen; return a.isPlayer ? (G.game.plantHeld ? G.game.plantHeld() : G.input.useHeld) && !this.g.frozen : a.using; },
    tickBomb(dt) {
      const g = this.g, bomb = this.bomb;
      if (!bomb) return;
      if (bomb.state === 'carried') {
        const c = bomb.carrier;
        bomb.pos.copy(c.pos);
        if (this.phase === 'live' && c.alive) {
          const site = G.map.inSite(c.pos.x, c.pos.z);
          // 2.10: сетевой закладчик должен стоять на полу (высоту и «на земле» присылает телефон — проверяем лучом вниз)
          const still = Math.hypot(c.vel.x, c.vel.z) < 1.2 && c.onGround && (!c.net || this.onFloor(c));
          if (site && still && this.useHeld(c)) {
            if (this.planter !== c) { this.planter = c; this.plantT = 0; if (c.isPlayer) G.audio.click(); }
            this.plantT += dt;
            if (Math.floor((this.plantT - dt) * 4) !== Math.floor(this.plantT * 4)) G.audio.plantTick(c.pos);
            if (this.plantT >= this.PLANT) this.plant(c, site);
          } else if (this.planter === c) { this.planter = null; this.plantT = 0; }
        }
      } else if (bomb.state === 'dropped') {
        for (const a of g.actors) {
          if (!a.alive || a.team !== 1) continue;
          if (a === bomb.noPick && this.g.time < bomb.noPickT) continue;   // 2.10: только что выбросил сам
          // 2.10: и по высоте (не сквозь пол); 2.1.1: бомба на ящике — и снизу, с 2,4 м, если её видно (иначе боты её не поднимали)
          const bdy = bomb.pos.y - a.pos.y, bd = Math.hypot(a.pos.x - bomb.pos.x, a.pos.z - bomb.pos.z);
          if (bdy > 0.3 ? bd < 2.4 && bdy < 1.7 && (!G.map.clear || G.map.clear(a.pos.x, a.pos.y + 1.1, a.pos.z, bomb.pos.x, bomb.pos.y + 0.15, bomb.pos.z)) : bd < 1.1 && Math.abs(bdy) < 1.2) {
            bomb.state = 'carried'; bomb.carrier = a; a.hasBomb = true; this.bombMesh.visible = false;
            G.emit('bombPick', { a });
            if (a.isPlayer) { G.hud.message('ВЫ ПОДОБРАЛИ БОМБУ', 'head'); G.audio.click(); }
            break;
          }
        }
      } else if (bomb.state === 'planted') {
        // мигание и писк (2.1: и после победы налётчиков по устранению — бомба дощёлкивает и взрывается, см. endRound)
        bomb.beepT -= dt;
        const fin = this.phase === 'end' && bomb.boomT != null;
        if (bomb.beepT <= 0 && (this.phase === 'planted' || fin)) {
          const k = fin ? 0 : Math.max(0, this.t / this.BOMB);
          bomb.beepT = Math.max(0.11, 1.0 * k + 0.05);
          G.audio.beep(bomb.pos, 1 - k); this.blink = 0.08;
        }
        this.blink = (this.blink || 0) - dt;
        this.bombLight.visible = this.blink > 0;
        if (fin) { bomb.boomT -= dt; if (bomb.boomT <= 0) this.explode(true); return; }
        if (this.phase !== 'planted') return;
        // разминирование
        let def = null;
        for (const a of g.actors) {
          if (!a.alive || a.team !== 0) continue;
          // (2.1: и по высоте — сквозь пол балкона над бомбой не обезвредить)
          if (this.canDefuse(a) && Math.hypot(a.vel.x, a.vel.z) < 1.2 && this.useHeld(a)) { def = a; break; }
        }
        if (def) {
          if (this.defuser !== def) { this.defuser = def; this.defuseT = 0; G.audio.defuseStart(bomb.pos); }
          this.defuseT += dt;
          if (Math.floor((this.defuseT - dt) * 2) !== Math.floor(this.defuseT * 2)) G.audio.defuseTick(bomb.pos, !!def.kit); // 2.6: разминирование слышно
          if (this.defuseT >= this.defuseNeed(def)) {
            bomb.state = 'defused'; def.money = Math.min(16000, def.money + 300);
            G.audio.defused(bomb.pos);
            G.emit('defused', { a: def });
            G.chat.event('defused', { a: def });
            if (def.isPlayer) G.bp.ev('defuse');
            this.endRound(0, 'defuse');
          }
        } else { this.defuser = null; this.defuseT = 0; }
      }
    },
    defuseNeed(a) { return a && a.kit ? this.KIT : this.DEFUSE; },
    defuseLeft() { return this.defuser ? this.defuseNeed(this.defuser) - this.defuseT : 99; },
    plant(a, site) {
      const bomb = this.bomb;
      bomb.state = 'planted'; bomb.site = site; bomb.carrier = null; bomb.beepT = 0.5;
      a.hasBomb = false; a.using = false;
      // 2.1: бомба лежит там, где стоит закладчик (на ящике — на ящике; раньше y = 0 — внутри ящика, её не было видно)
      // 2.10: и не выше пола под закладчиком (сервер не верит присланной высоте)
      const fy = G.drops && G.drops.floorAt ? G.drops.floorAt(a.pos.x, a.pos.y, a.pos.z) : null;
      bomb.pos.set(a.pos.x, Math.max(0, fy != null ? Math.min(a.pos.y, fy) : a.pos.y), a.pos.z); bomb.boomT = null;
      this.bombMesh.position.copy(bomb.pos); this.bombMesh.rotation.y = a.yaw; this.bombMesh.visible = true;
      this.phase = 'planted'; this.t = this.BOMB;
      this.planter = null; this.plantT = 0;
      a.money = Math.min(16000, a.money + 300);
      this.assign = new Map();
      G.audio.planted();
      G.emit('planted', { a, site, x: bomb.pos.x, y: bomb.pos.y, z: bomb.pos.z, yaw: a.yaw });
      G.hud.banner('БОМБА ЗАЛОЖЕНА', 'Точка ' + site, 'warn', 2.2);
      G.chat.event('planted', { s: site });
      if (a.isPlayer) G.bp.ev('plant');
      for (const b of this.g.actors) if (!b.isPlayer && b.team === 0 && b.alive) { b.alertPos = bomb.pos.clone(); b.alertT = this.g.time; b.path = null; }
    },
    // fin — раунд уже выигран налётчиками (спецназ уничтожен после закладки): только взрыв на экране, без урона и очков
    explode(fin) {
      const g = this.g, bomb = this.bomb;
      bomb.state = 'exploded'; bomb.boomT = null;
      this.bombMesh.visible = false; this.bombLight.visible = false;
      G.emit('exploded', { x: bomb.pos.x, y: bomb.pos.y, z: bomb.pos.z });
      G.fx.explosion(bomb.pos.x, bomb.pos.y + 0.4, bomb.pos.z);
      G.audio.explosion(bomb.pos);
      if (g.player) {
        const d = g.player.pos.distanceTo(bomb.pos);
        g.shake = Math.max(g.shake || 0, G.clamp(1.4 - d / 40, 0.2, 1.2));
      }
      if (fin) return;
      for (const a of g.actors) {
        if (!a.alive) continue;
        const d = a.pos.distanceTo(bomb.pos);
        if (d < 22) a.damage(420 * Math.pow(1 - d / 22, 2.2), null, 'bomb', false, a.pos.clone().sub(bomb.pos).normalize());
      }
      this.endRound(1, 'bomb');
    },
    dropBomb(a) {
      const bomb = this.bomb;
      if (!bomb || bomb.carrier !== a || bomb.state !== 'carried') return;
      a.hasBomb = false;
      bomb.state = 'dropped'; bomb.carrier = null; bomb.noPick = null;
      if (this.planter === a) { this.planter = null; this.plantT = 0; }   // 2.8: погиб/выронил во время закладки — полоса «ЗАКЛАДКА» не висит
      // 2.1: падает на пол/ящик под погибшим (как оружие), а не на высоту 0 внутрь ящика
      let fy = G.drops && G.drops.floorAt ? G.drops.floorAt(a.pos.x, Math.max(0, a.pos.y), a.pos.z) : 0;
      if (fy == null || !(fy >= 0)) fy = 0;
      bomb.pos.set(a.pos.x, fy, a.pos.z);
      this.bombMesh.position.copy(bomb.pos); this.bombMesh.visible = true; this.bombLight.visible = false;
    },
    // 2.10: выбросить бомбу вперёд (кнопка «Выбросить» с бомбой в руках): падает в 1,4 м перед носителем (не за стену),
    // сам выбросивший подберёт её снова только через 1,5 с
    tossBomb(a) {
      const bomb = this.bomb;
      if (!bomb || bomb.carrier !== a || bomb.state !== 'carried' || this.phase === 'end' || this.planter === a) return false;
      const fx = -Math.sin(a.yaw), fz = -Math.cos(a.yaw);
      let dist = 1.4;
      const h = G.map.ray(a.pos.x, a.pos.y + 0.9, a.pos.z, fx, 0, fz, 1.8);
      if (h) dist = Math.max(0, h.t - 0.4);
      // 2.1.1: падает только на тот же пол — не в воду канала, не на ящик и не вниз с уступа (туда потом не дотянуться);
      // иначе — под ноги
      if (dist > 0 && G.drops && G.drops.floorAt) {
        const f0 = G.drops.floorAt(a.pos.x, Math.max(0, a.pos.y), a.pos.z), f1 = G.drops.floorAt(a.pos.x + fx * dist, Math.max(0, a.pos.y), a.pos.z + fz * dist);
        if (f0 == null || f1 == null || Math.abs(f1 - f0) > 0.4) dist = 0;
      }
      const ox = a.pos.x, oz = a.pos.z;
      a.pos.x += fx * dist; a.pos.z += fz * dist;   // dropBomb кладёт под носителя — на миг сдвигаем точку
      try { this.dropBomb(a); } finally { a.pos.x = ox; a.pos.z = oz; }
      bomb.noPick = a; bomb.noPickT = this.g.time + 1.5;
      G.emit('bombToss', { a });
      return true;
    },
    endRound(win, reason) {
      if (this.phase === 'end') return;
      const g = this.g;
      this.phase = 'end'; this.t = this.END; g.frozen = false;
      // 2.10: закладка/разминирование оборвались концом раунда — полоса прогресса не висит, бомба не держится в руках
      this.planter = null; this.plantT = 0; this.defuser = null; this.defuseT = 0;
      // 2.1: спецназ уничтожен после закладки — победа налётчиков сразу, а бомба через пару секунд взрывается у всех на
      // глазах (раньше раунд просто кончался, и взрыв бомбы игроки почти не видели — «бомба никогда не взрывается»)
      if (reason === 'elim' && win === 1 && this.bomb && this.bomb.state === 'planted') { this.bomb.boomT = 2.3; this.bomb.beepT = 0; }
      this.score[win]++;
      G.emit('roundEnd', { win, reason });
      const lose = 1 - win;
      (this.log = this.log || []).push(this.round + ':' + (win ? 'T' : 'CT') + ':' + reason);
      const winMoney = reason === 'bomb' || reason === 'defuse' ? 3500 : 3250;
      const loseMoney = 1400 + 500 * Math.min(this.loss[lose], 4) + (lose === 1 && this.bomb && (this.bomb.state === 'planted' || this.bomb.state === 'defused') ? 800 : 0);
      this.loss[win] = 0; this.loss[lose]++;
      for (const a of g.actors) a.money = Math.min(16000, a.money + (a.team === win ? winMoney : loseMoney));
      const pl = g.player;
      const mine = pl && pl.team === win;
      G.hud.banner(win === 0 ? 'СПЕЦНАЗ ПОБЕДИЛ' : 'НАЛЁТЧИКИ ПОБЕДИЛИ', REASON[reason], mine ? 'win' : 'lose', 4.5, reason);
      G.audio.roundEnd(mine);
      G.chat.event('roundEnd', { win });
      if (this.g.player && this.g.player.team === win) G.bp.ev('round');
      if (mine && G.stats) G.stats.xp = (G.stats.xp || 0) + 10;
      const half = this.HALF;
      if (this.score[0] >= this.WIN || this.score[1] >= this.WIN || this.round >= this.MAX) this.matchOver = true;
      // ничья невозможна до конца; после 12 раундов — по счёту
      void half;
    },
    halftime() {
      const g = this.g;
      for (const a of g.actors) {
        a.team = 1 - a.team; a.money = 800; a.alive = false; a.armor = 0; a.helmet = false; a.kit = false; a.hasBomb = false;
        a.slots = { primary: null, secondary: null, melee: null, nade: null }; a.nades = { he: 0, flash: 0, smoke: 0 };
      }
      this.score = [this.score[1], this.score[0]];
      this.loss = [0, 0];
      if (g.clearVM) g.clearVM(true); else { g.vmCache = {}; g.vm = null; }
      G.emit('halftime', {});
    },
    // ---------- задачи ботов ----------
    point(b, key, gen) {
      let p = this.assign.get(b);
      if (!p || p.key !== key) { p = Object.assign({ key }, gen()); this.assign.set(b, p); }
      return p;
    },
    // 2.3 perf: точка уже назначена с этим ключом — без создания функции-генератора (botGoal зовётся каждый кадр)
    pointHas(b, key) { const p = this.assign.get(b); return p && p.key === key ? p : null; },
    // 2.3 perf: ключи вида 'site' + id без новой строки каждый кадр
    pkey(pre, id) { const m = this._pk || (this._pk = {}); const t = m[pre] || (m[pre] = {}); return t[id] || (t[id] = pre + id); },
    // 2.3 perf: ответ botGoal — один объект на бота, поля переписываются (раньше — новый объект каждый кадр на каждого бота).
    // Бот читает ответ сразу (actors.js update), дальше не хранит
    goal(b, x, z, hold, look, act, urgent, walk, tight) {
      const o = b._goal || (b._goal = { x: 0.5, z: 0.5, hold: false, look: null, act: null, urgent: false, walk: false, tight: false });
      o.x = x; o.z = z; o.hold = !!hold; o.look = look == null ? null : look; o.act = act || null; o.urgent = !!urgent; o.walk = !!walk; o.tight = !!tight;
      return o;
    },
    near(cx, cz, r) { return G.nav.randomPoint((x, z) => Math.hypot(x - cx, z - cz) < r && Math.hypot(x - cx, z - cz) > 2); },
    siteKeys() { const S = G.map.sites; if (!this._sk || this._sk.s !== S) this._sk = { s: S, k: Object.keys(S) }; return this._sk.k; },
    lookTo(x, z, tx, tz) { return Math.atan2(-(tx - x), -(tz - z)); },
    nearestBot(team, pos, exclude) {
      let best = null, bd = 1e9;
      for (const a of this.g.actors) {
        if (!a.alive || a.team !== team || a.isPlayer || a === exclude) continue;
        const d = a.pos.distanceTo(pos);
        if (d < bd) { bd = d; best = a; }
      }
      return best;
    },
    botGoal(b) {
      if (this.phase === 'freeze') return null;
      const bomb = this.bomb, g = this.g;
      // 2.0 QA perf: центры спавнов считаются один раз на карту (раньше — два объекта на бота каждый кадр)
      const SZ = G.map.spawnZones, cc = this._zc && this._zc.sz === SZ ? this._zc : (this._zc = {
        sz: SZ, ct: { x: (SZ[0].x0 + SZ[0].x1) / 2, z: (SZ[0].z0 + SZ[0].z1) / 2 }, t: { x: (SZ[1].x0 + SZ[1].x1) / 2, z: (SZ[1].z0 + SZ[1].z1) / 2 } });
      const ctC = cc.ct, tC = cc.t;
      if (b.team === 1) {
        if (bomb.state === 'planted' || bomb.state === 'defused' || bomb.state === 'exploded') {
          // 2.1: охрана заложенной бомбы. Раньше — случайная точка в 10 м, взгляд на спавн спецназа, а на любой шум
          // охранник уходил с позиции: спецназ заходил с другой стороны и спокойно разминировал («бомба почти
          // никогда не взрывается»). Теперь: позиция, откуда видно бомбу (с той стороны, откуда пришла атака),
          // взгляд — на бомбу, позицию не бросаем; разминирование, которого охранник не видит, — бежим мешать
          const bp = bomb.pos;
          if (bomb.state === 'planted' && this.phase === 'planted' && this.defuser && this.defuser.alive && !(b.tVisible && b.target === this.defuser) &&
            Math.hypot(b.pos.x - bp.x, b.pos.z - bp.z) < 30) return this.goal(b, bp.x, bp.z, false, this.lookTo(b.pos.x, b.pos.z, bp.x, bp.z), null, true);
          const p = this.pointHas(b, 'guard') || this.point(b, 'guard', () => this.guardSpot(b, ctC, tC) || this.near(bp.x, bp.z, 10));
          return this.goal(b, p.x, p.z, true, p.look != null ? p.look : this.lookTo(p.x, p.z, bp.x, bp.z), null, bomb.state === 'planted', false, bomb.state === 'planted');
        }
        if (bomb.state === 'dropped') {
          const pl = g.player;
          const fetcher = this.nearestBot(1, bomb.pos);
          // 2.10: игрок сам выбросил бомбу (кнопкой) — значит, отдаёт её: бот идёт за ней, даже если игрок ближе
          const plCloser = pl && pl.alive && pl.team === 1 && fetcher && bomb.noPick !== pl && pl.pos.distanceTo(bomb.pos) < fetcher.pos.distanceTo(bomb.pos);
          if (b === fetcher && !plCloser) return this.goal(b, bomb.pos.x, bomb.pos.z, false, null, null, true);
        }
        // сбор перед атакой: до сигнала ждём на точке сбора (сигнал — время, контакт с врагом или мало своих)
        if (!this.plan.go && this.phase === 'live') {
          // (без временных массивов: бот спрашивает это каждый кадр)
          let n = 0, contact = false;
          for (const a of g.actors) if (a.alive && a.team === 1) { n++; if (a.tVisible || (g.time - (a.lastHitT || -99) < 1)) contact = true; }
          if (this.ROUND - this.t > this.plan.wait || n <= 1 || contact) this.plan.go = true;
        }
        if (!this.plan.go) {
          const st = this.plan.stage, sc = G.map.sites[this.plan.site];
          const p = this.pointHas(b, 'stage') || this.point(b, 'stage', () => this.near(st.x, st.z, st.r || 7) || st);
          return this.goal(b, p.x, p.z, true, this.lookTo(p.x, p.z, (sc.x0 + sc.x1) / 2, (sc.z0 + sc.z1) / 2), null, false, b.hasBomb);
        }
        if (b.hasBomb) {
          // уже на любой точке — закладываем прямо здесь
          if (this.phase === 'live' && G.map.inSite(b.pos.x, b.pos.z)) return this.goal(b, b.pos.x, b.pos.z, false, this.lookTo(b.pos.x, b.pos.z, ctC.x, ctC.z), 'plant', true);
          const sp = this.plan.spot, s = G.map.sites[this.plan.site];
          // идём позади своих, пока они не зайдут на точку
          // (без временных массивов: тот же ответ, что у filter + some)
          let inSite = false, ahead = false;
          for (let i = 0; i < g.actors.length; i++) {
            const a = g.actors[i]; if (!a.alive || a.team !== 1 || a === b) continue;
            if (a.pos.x > s.x0 && a.pos.x < s.x1 && a.pos.z > s.z0 && a.pos.z < s.z1) inSite = true;
            if (a.pos.distanceTo(b.pos) < 14) ahead = true;
          }
          return this.goal(b, sp.x, sp.z, false, this.lookTo(sp.x, sp.z, ctC.x, ctC.z), 'plant', true, !inSite && ahead && this.t > 50);
        }
        const s = G.map.sites[this.plan.site], sk = this.pkey('site', this.plan.site);
        const p = this.pointHas(b, sk) || this.point(b, sk, () => G.nav.randomInRect(s.x0, s.x1, s.z0, s.z1));
        return this.goal(b, p.x, p.z, true, this.lookTo(p.x, p.z, ctC.x, ctC.z));
      }
      // спецназ
      if (bomb.state === 'planted') {
        const pl = g.player;
        // 2.1.1: начатое ботом разминирование не перехватывает тот, кто прошёл мимо ближе (раньше разминирующий уходил в укрытие,
        // а время разминирования начиналось заново)
        const cd = this.defuser;
        const def = cd && cd.alive && !cd.isPlayer && cd.team === 0 ? cd : this.nearestBot(0, bomb.pos);
        const plDef = pl && pl.alive && pl.team === 0 && def && pl.pos.distanceTo(bomb.pos) < 2;
        if (b === def && !plDef) return this.goal(b, bomb.pos.x, bomb.pos.z, false, null, 'defuse', true);
        const p = this.pointHas(b, 'cover') || this.point(b, 'cover', () => this.near(bomb.pos.x, bomb.pos.z, 9));
        return this.goal(b, p.x, p.z, true, this.lookTo(p.x, p.z, tC.x, tC.z), null, true);
      }
      // «Перрон»: дальний спецназовец (вид r) не бросает позицию на шум и тревогу — он возвращает точку после закладки
      const hl = G.map.def && G.map.def.holds, ha = hl && this.assign.get(b), far = ha && ha.key === 'hold' && hl[ha.i] && hl[ha.i][4] === 'r';
      if (far) return this.goal(b, ha.x, ha.z, true, ha.look, null, true);
      if (this.alert && g.time - this.alert.t < 14) {
        const s = G.map.sites[this.alert.site], rk = this.pkey('rot', this.alert.site);
        const p = this.pointHas(b, rk) || this.point(b, rk, () => G.nav.randomInRect(s.x0, s.x1, s.z0, s.z1));
        return this.goal(b, p.x, p.z, true, this.lookTo(p.x, p.z, tC.x, tC.z));
      }
      const keys = this.siteKeys();
      let idx = -1; for (let i = 0, k = 0; i < g.actors.length; i++) { const a = g.actors[i]; if (a.team === 0 && !a.isPlayer) { if (a === b) { idx = k; break; } k++; } }
      // карта с заданными позициями спецназа: первый бот — на точке, остальные — на точке или дальше (страхуют обход, возвращают точку)
      const holds = G.map.def && G.map.def.holds;
      if (holds && holds.length) {
        const p = this.pointHas(b, 'hold') || this.point(b, 'hold', () => {
          const used = new Set(); for (const [o, q] of this.assign) if (o !== b && q.key === 'hold') used.add(q.i);
          const want = (idx === 0 ? Math.random() < 0.75 : Math.random() < 0.2) ? 's' : 'r';
          let c = holds.map((h, i) => i).filter(i => !used.has(i) && holds[i][4] === want);
          if (!c.length) c = holds.map((h, i) => i).filter(i => !used.has(i));
          const i = G.pick(c), h = holds[i], k = G.map.def.scale || 1;
          return { x: h[0] * k, z: h[1] * k, i, look: this.lookTo(h[0] * k, h[1] * k, h[2] * k, h[3] * k) };
        });
        return this.goal(b, p.x, p.z, true, p.look);
      }
      const site = keys[idx % keys.length];
      const s = G.map.sites[site];
      const hk = this.pkey('hold', site);
      const p = this.pointHas(b, hk) || this.point(b, hk, () => G.nav.randomInRect(s.x0 + 1, s.x1 - 1, s.z0 + 1, s.z1 - 1));
      return this.goal(b, p.x, p.z, true, this.lookTo(p.x, p.z, tC.x, tC.z));
    },
    // 2.1: подходы спецназа к заложенной бомбе — точки на кратчайшем пути от бомбы к спавну спецназа в 9, 15 и 23 м
    // (считается один раз за раунд, при первом запросе охраны)
    entries(ctC) {
      const bomb = this.bomb;
      if (bomb.entries && bomb.entries.r === this.round) return bomb.entries;
      const bp = bomb.pos, path = G.nav.findPath(bp.x, bp.z, ctC.x, ctC.z), pts = [];
      if (path && path.length) {
        const want = [9, 15, 23]; let acc = 0, prev = { x: bp.x, z: bp.z }, w = 0;
        for (const q of path) {
          const d = Math.hypot(q.x - prev.x, q.z - prev.z);
          while (w < want.length && acc + d >= want[w]) { const t = d ? (want[w] - acc) / d : 0; pts.push({ x: prev.x + (q.x - prev.x) * t, z: prev.z + (q.z - prev.z) * t }); w++; }
          acc += d; prev = q;
        }
        if (!pts.length) pts.push({ x: prev.x, z: prev.z });
      } else pts.push({ x: ctC.x, z: ctC.z });
      return (bomb.entries = { r: this.round, pts });
    },
    // 2.1: позиция охраны заложенной бомбы для бота b: проходимая точка в 4–13 м, откуда видно бомбу (с глаз бота) —
    // разминирующего застрелят; по возможности НЕ видная с подходов спецназа издалека (иначе охрану снимают с 20–30 м,
    // пока она смотрит на бомбу), ближе к стороне налётчиков, подальше от других охранников (разные углы).
    // Взгляд — на ближний подход спецназа (бомба при этом обычно тоже в поле зрения). Один раз за раунд на бота
    guardSpot(b, ctC, tC) {
      const bp = this.bomb.pos, N = G.nav, M = G.map, E = this.entries(ctC).pts, e0 = E[0];
      const tx = tC.x - bp.x, tz = tC.z - bp.z, tl = Math.hypot(tx, tz) || 1;
      const taken = []; for (const [o, q] of this.assign) if (o !== b && q.key === 'guard') taken.push(q);
      let best = null, bs = -1e9;
      for (let k = 0; k < 30; k++) {
        const p = N.randomPoint((x, z) => { const d = Math.hypot(x - bp.x, z - bp.z); return d > 4 && d < 13; });
        const dx = p.x - bp.x, dz = p.z - bp.z, d = Math.hypot(dx, dz);
        if (d <= 4 || d >= 13) continue;
        if (!M.clear(p.x, 1.55, p.z, bp.x, bp.y + 0.3, bp.z)) continue;
        let s = -Math.abs(d - 8) * 0.3 + (dx * tx + dz * tz) / (d * tl) * 1.5 + Math.random() * 1.5;
        // виден с дальних подходов — плохо (с ближнего — нормально: это и есть перестрелка за бомбу)
        for (let i = 1; i < E.length; i++) if (M.clear(E[i].x, 1.6, E[i].z, p.x, 1.5, p.z)) s -= 2.5;
        // ближний подход тоже виден отсюда — хорошо: заходящего видно раньше, чем он дойдёт до бомбы
        if (M.clear(p.x, 1.55, p.z, e0.x, 1.2, e0.z)) s += 1;
        for (const q of taken) { const dd = Math.hypot(q.x - p.x, q.z - p.z); if (dd < 5) s -= (5 - dd) * 1.2; }
        if (s > bs) { bs = s; best = p; }
      }
      if (!best) return null;
      // смотрим между бомбой и ближним подходом: бомба и заходящий спецназ — оба в поле зрения
      const mx = (bp.x + e0.x) / 2, mz = (bp.z + e0.z) / 2;
      return { x: best.x, z: best.z, look: this.lookTo(best.x, best.z, mx, mz) };
    },
    spotted(bot, enemy) {
      if (bot.team !== 0 || this.phase !== 'live') return;
      for (const k in G.map.sites) {
        const s = G.map.sites[k];
        const dx = Math.max(s.x0 - enemy.pos.x, 0, enemy.pos.x - s.x1), dz = Math.max(s.z0 - enemy.pos.z, 0, enemy.pos.z - s.z1);
        if (Math.hypot(dx, dz) < 12) { if (!this.alert || this.alert.site !== k) this.alert = { site: k, t: this.g.time }; else this.alert.t = this.g.time; }
      }
    },
    onKill(killer, victim, wid) {
      if (victim.hasBomb) this.dropBomb(victim);
      if (victim.using) victim.using = false;
      if (killer && killer !== victim && killer.team !== victim.team) {
        const d = G.WEAPONS[wid];
        killer.money = Math.min(16000, killer.money + (d && d.reward ? d.reward : 300));
        killer.roundKills = (killer.roundKills || 0) + 1;
      }
    }
  };

  G.MODE_NAMES = { bomb: 'Закладка бомбы', tdm: 'Командный бой', ffa: 'Бой насмерть', duel: 'Дуэль 1 на 1', tutorial: 'Обучение', nades: 'Тренировка гранат' };
  // ===================== Дуэль 1 на 1 =====================
  // короткие раунды до первого убийства: оба на своих концах карты, полная броня, без гранат; до 7 побед
  G.duelMode = {
    WIN: 7, PAUSE: 2.6, FREEZE: 2.2, MATCH: 420, ROUND: 60,
    phase: 'none', round: 0, t: 0,
    setup(g) {
      this.g = g; this.round = 0; this.phase = 'none'; this.t = 0;
      g.killLimit = this.WIN; g.timeLeft = this.MATCH; g.scores = [0, 0];
      this.nextRound(g);
    },
    // 11.9: в дуэли нет снайперских винтовок — AWM и SSG 08 не выдаются и не выбираются (любое оружие с оптикой)
    allowed(id) { const d = G.WEAPONS[id]; return !!d && d.slot === 'primary' && !d.scope; },
    // что получит боец вместо запрещённого ствола: своя штурмовая винтовка стороны
    pick(id, team) { return this.allowed(id) ? id : team === 1 ? 'ar' : 'ar2'; },
    // случайное основное оружие бота-соперника без снайперок
    randomPrimary(team) {
      const L = team === 1 ? ['ar', 'ar', 'galil', 'smg', 'shotgun'] : ['ar2', 'm4s', 'famas', 'smg', 'shotgun'];
      return L[Math.floor(Math.random() * L.length)];
    },
    // броня и шлем каждому, гранат нет — чистая перестрелка
    prepare(a) {
      // страховка (в т.ч. для сервера): запрещённый ствол в слоте заменяется до начала раунда
      const pr = a.slots && a.slots.primary;
      if (pr && !this.allowed(pr.id)) {
        a.loadout(this.pick(pr.id, a.team));
        if (!G.HEADLESS && !a.isPlayer && a.buildModel) a.buildModel(a.w.id);
      }
      a.armor = 100; a.helmet = true; a.protect = 0;
      a.nades = { he: 0, flash: 0, smoke: 0 }; if (a.syncNade) a.syncNade();
      if (a.cur === 'nade') a.cur = a.slots.primary ? 'primary' : 'secondary';
    },
    nextRound(g) {
      this.round++;
      if (G.nades && G.nades.reset) G.nades.reset();
      for (const a of g.actors) { g.respawn(a); this.prepare(a); }
      this.phase = 'freeze'; this.t = this.FREEZE; g.frozen = true;
      if (g.onRoundStart && !G.HEADLESS) { /* клиент: камера/оружие уже сброшены в respawn */ }
      G.emit('duelRound', { round: this.round, sc: g.scores.slice() });
      if (!G.HEADLESS && g.player) {
        G.hud.banner('РАУНД ' + this.round, g.scores[0] + ' : ' + g.scores[1] + ' · до ' + this.WIN + ' побед', 't' + g.player.team);
      }
    },
    // кто-то погиб: раунд окончен, очко — убийце (или сопернику погибшего)
    onKill(g, killer, victim) {
      if (this.phase !== 'live' && this.phase !== 'freeze') return;
      if (killer && killer !== victim) g.scores[killer.team]++;
      else { const t = 1 - victim.team; if (t === 0 || t === 1) g.scores[t]++; }
      this.phase = 'end'; this.t = this.PAUSE;
      if (g.scores[0] >= this.WIN || g.scores[1] >= this.WIN) { g.endMatch(); return; }
      if (!G.HEADLESS && g.player) {
        const won = killer && killer !== victim ? killer.team === g.player.team : victim.team !== g.player.team;
        G.hud.message(won ? 'РАУНД ВАШ' : 'РАУНД ПРОИГРАН', won ? 'head' : '');
      }
    },
    update(g, dt) {
      if (g.over) return;
      if (this.phase === 'freeze') {
        this.t -= dt;
        if (this.t <= 0) { this.phase = 'live'; this.t = this.ROUND; g.frozen = false; G.emit('live', {}); if (!G.HEADLESS) { G.audio.go(); G.hud.message('В БОЙ!', 'head'); } }
      } else if (this.phase === 'live') {
        this.t -= dt;
        if (this.t <= 0) this.timeUp(g);
      } else if (this.phase === 'end') {
        this.t -= dt;
        if (this.t <= 0) this.nextRound(g);
      }
    },
    // время раунда вышло: очко тому, у кого больше здоровья (поровну — ничья)
    timeUp(g) {
      const hp = [0, 0];
      for (const a of g.actors) if (a.alive && (a.team === 0 || a.team === 1)) hp[a.team] += a.hp;
      const w = hp[0] > hp[1] ? 0 : hp[1] > hp[0] ? 1 : -1;
      if (w >= 0) g.scores[w]++;
      this.phase = 'end'; this.t = this.PAUSE;
      G.emit('duelTime', { w });
      if (g.scores[0] >= this.WIN || g.scores[1] >= this.WIN) { g.endMatch(); return; }
      if (!G.HEADLESS && g.player) this.timeMsg(w, g.player.team);
    },
    timeMsg(w, my) {
      G.hud.message(w < 0 ? 'ВРЕМЯ ВЫШЛО · НИЧЬЯ' : w === my ? 'ВРЕМЯ ВЫШЛО · РАУНД ВАШ' : 'ВРЕМЯ ВЫШЛО · РАУНД ПРОИГРАН', w === my ? 'head' : '');
    },
    // в комнату пришёл или ушёл человек: счёт заново, свежий раунд
    restart(g) { g.scores = [0, 0]; this.round = 0; g.timeLeft = this.MATCH; this.nextRound(g); }
  };
})(window.G);
