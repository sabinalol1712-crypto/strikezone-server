'use strict';
/* Навигационная сетка и поиск пути A* для ботов */
(function (G) {
  // 2.0 perf: соседи клетки — константы модуля (раньше массив массивов создавался на каждый поиск и разбирался деструктуризацией)
  const DI = [1, -1, 0, 0, 1, 1, -1, -1], DJ = [0, 0, 1, -1, 1, -1, 1, -1], DC = [1, 1, 1, 1, 1.4142, 1.4142, 1.4142, 1.4142];
  // 2.3 perf: куча A* и оценка расстояния — функции модуля (раньше три замыкания на каждый поиск пути); размер кучи — HS
  let HS = 0;
  function hcost(c, nx, ti, tj) {
    const dx = Math.abs((c % nx) - ti), dz = Math.abs(Math.floor(c / nx) - tj);
    return (dx + dz) + (1.4142 - 2) * Math.min(dx, dz);
  }
  function hpush(heap, f, c) {
    let i = HS++; heap[i] = c;
    while (i > 0) { const p = (i - 1) >> 1; if (f[heap[p]] <= f[heap[i]]) break; const tmp = heap[p]; heap[p] = heap[i]; heap[i] = tmp; i = p; }
  }
  function hpop(heap, f) {
    const top = heap[0]; heap[0] = heap[--HS]; let i = 0;
    for (;;) {
      const l = i * 2 + 1, r = l + 1; let m = i;
      if (l < HS && f[heap[l]] < f[heap[m]]) m = l;
      if (r < HS && f[heap[r]] < f[heap[m]]) m = r;
      if (m === i) break; const tmp = heap[m]; heap[m] = heap[i]; heap[i] = tmp; i = m;
    }
    return top;
  }
  const nav = G.nav = {
    step: 1, x0: 0, z0: 0, nx: 0, nz: 0, walk: null, list: [], cache: {}, rectCache: {},
    build() {
      const id = G.map.id;
      if (this.cache[id]) { Object.assign(this, this.cache[id]); return; }
      const bd = G.map.bounds;
      this.x0 = bd.x0 + 0.5; this.z0 = bd.z0 + 0.5;
      this.nx = Math.round(bd.x1 - bd.x0); this.nz = Math.round(bd.z1 - bd.z0);
      const n = this.nx * this.nz;
      this.walk = new Uint8Array(n);
      this.list = [];
      for (let j = 0; j < this.nz; j++) for (let i = 0; i < this.nx; i++) {
        const x = this.x0 + i * this.step, z = this.z0 + j * this.step;
        if (!G.map.blocked(x, z, 0.45)) { this.walk[j * this.nx + i] = 1; this.list.push(j * this.nx + i); }
      }
      // 2.1.1: связные области сетки (клетки, между которыми есть путь) — старт пути выбирается в той же области, что и цель
      this.comp = new Int32Array(n).fill(-1);
      { let cid = 0; const q = new Int32Array(n);
        for (const c0 of this.list) {
          if (this.comp[c0] >= 0) continue;
          let qh = 0, qt = 0; q[qt++] = c0; this.comp[c0] = cid;
          while (qh < qt) {
            const c = q[qh++], ci = c % this.nx, cj = Math.floor(c / this.nx);
            for (let d = 0; d < 8; d++) {
              const i = ci + DI[d], j = cj + DJ[d];
              if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) continue;
              const k = j * this.nx + i;
              if (!this.walk[k] || this.comp[k] >= 0) continue;
              if (DI[d] && DJ[d] && (!this.walk[cj * this.nx + i] || !this.walk[j * this.nx + ci])) continue;
              this.comp[k] = cid; q[qt++] = k;
            }
          }
          cid++;
        } }
      // 2.1.1: игровая область — связная область сетки, где зоны появления (большинство их клеток); без зон — самая большая.
      // Случайные точки (появление в «Каждый сам за себя», цели прогулки ботов) — только в ней: на «Руинах» пространство за
      // внешними стенами — отдельная большая область, и игроки с ботами появлялись за стенами, а боты выбирали там цели
      this.main = this.list;
      { const cnt = new Map(), zs = (G.map.spawnZones || []).filter(Boolean);
        for (const c of this.list) {
          const p = this.posOf(c);
          if (zs.length && !zs.some(zn => p.x >= zn.x0 && p.x <= zn.x1 && p.z >= zn.z0 && p.z <= zn.z1)) continue;
          cnt.set(this.comp[c], (cnt.get(this.comp[c]) || 0) + 1);
        }
        if (!cnt.size) for (const c of this.list) cnt.set(this.comp[c], (cnt.get(this.comp[c]) || 0) + 1);
        let mc = -1, bn = 0; for (const [k, v] of cnt) if (v > bn) { bn = v; mc = k; }
        if (mc >= 0) { const m = this.list.filter(c => this.comp[c] === mc); if (m.length) this.main = m; } }
      this.g = new Float32Array(n); this.f = new Float32Array(n);
      this.parent = new Int32Array(n); this.state = new Uint32Array(n); this.gen = this.gen || 0;
      this.heap = new Int32Array(n * 8);
      this.rectCache = {};
      this.cache[id] = { x0: this.x0, z0: this.z0, nx: this.nx, nz: this.nz, walk: this.walk, comp: this.comp, list: this.list, main: this.main, g: this.g, f: this.f, parent: this.parent, state: this.state, heap: this.heap, rectCache: this.rectCache };
    },
    cellOf(x, z) {
      const i = Math.round((x - this.x0) / this.step), j = Math.round((z - this.z0) / this.step);
      if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) return -1;
      return j * this.nx + i;
    },
    posOf(c) { return { x: this.x0 + (c % this.nx) * this.step, z: this.z0 + Math.floor(c / this.nx) * this.step }; },
    nearestWalkable(x, z) {
      const c = this.cellOf(G.clamp(x, this.x0, this.x0 + this.nx - 1), G.clamp(z, this.z0, this.z0 + this.nz - 1));
      if (c >= 0 && this.walk[c]) return c;
      const ci = c % this.nx, cj = Math.floor(c / this.nx);
      for (let r = 1; r < 6; r++) {
        let best = -1, bd = 1e9;
        for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
          if (Math.abs(di) !== r && Math.abs(dj) !== r) continue;
          const i = ci + di, j = cj + dj;
          if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) continue;
          const k = j * this.nx + i;
          if (!this.walk[k]) continue;
          const px = this.x0 + (k % this.nx) * this.step, pz = this.z0 + Math.floor(k / this.nx) * this.step, d = (px - x) ** 2 + (pz - z) ** 2; // = posOf(k), без объекта
          if (d < bd) { bd = d; best = k; }
        }
        if (best >= 0) return best;
      }
      return -1;
    },
    // 2.1.1: клетка старта пути — ближайшая проходимая, до которой можно дойти по прямой (раньше — просто ближайшая: бот в
    // «кармане» у стены получал первую точку пути за парапетом и бежал в стену весь раунд)
    nearestReach(x, z, wc, strict) {   // strict: -1, если по прямой не дойти ни до одной клетки (иначе — ближайшая)
      const c0 = this.nearestWalkable(x, z);
      if (c0 < 0) return c0;
      const ok = (k) => wc == null || !this.comp || this.comp[k] === wc;   // wc — область цели
      const p0 = this.posOf(c0);
      if (ok(c0) && this.segClear(x, z, p0.x, p0.z, 0.3)) return c0;
      const ci = Math.round((x - this.x0) / this.step), cj = Math.round((z - this.z0) / this.step);
      let best = -1, bd = 1e9;
      for (let dj = -3; dj <= 3; dj++) for (let di = -3; di <= 3; di++) {
        const i = ci + di, j = cj + dj;
        if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) continue;
        const k = j * this.nx + i;
        if (!this.walk[k] || !ok(k)) continue;
        const px = this.x0 + i * this.step, pz = this.z0 + j * this.step, d = (px - x) ** 2 + (pz - z) ** 2;
        if (d < bd && this.segClear(x, z, px, pz, 0.3)) { bd = d; best = k; }
      }
      return best >= 0 ? best : (strict ? -1 : c0);
    },
    // 2.1.1: выход из «кармана» вне сетки, когда по прямой не дойти ни до одной клетки (угол за ящиком, щель между колоннами —
    // нужен путь с поворотом): поиск в ширину по решётке 0,25 м в радиусе 2,5 м до точки, откуда по прямой видна проходимая
    // клетка области цели. Ответ — { pts: точки до этой точки, cell } или null. Бывает редко (бот вытолкнут с сетки), поэтому
    // обычный поиск пути не дорожает
    escape(x, z, wc) {
      const R = 10, W = 2 * R + 1, S = 0.25, N = W * W, c = R * W + R;
      const prev = this._escPrev || (this._escPrev = new Int16Array(N)), q = this._escQ || (this._escQ = new Int16Array(N));
      prev.fill(-2);   // -2 — не посещена, -3 — занята стеной/ящиком
      const ptX = (n) => x + ((n % W) - R) * S, ptZ = (n) => z + (Math.floor(n / W) - R) * S;
      const seeCell = (px, pz) => {
        const ci = Math.round((px - this.x0) / this.step), cj = Math.round((pz - this.z0) / this.step);
        let best = -1, bd = 1e9;
        for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
          const i = ci + di, j = cj + dj;
          if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) continue;
          const k = j * this.nx + i;
          if (!this.walk[k] || (wc != null && this.comp && this.comp[k] !== wc)) continue;
          const cx = this.x0 + i * this.step, cz = this.z0 + j * this.step, d = (cx - px) ** 2 + (cz - pz) ** 2;
          if (d < bd && this.segClear(px, pz, cx, cz, 0.3)) { bd = d; best = k; }
        }
        return best;
      };
      let qh = 0, qt = 0; q[qt++] = c; prev[c] = -1;
      while (qh < qt) {
        const n = q[qh++];
        if (n !== c) {
          const k = seeCell(ptX(n), ptZ(n));
          if (k >= 0) {
            const chain = []; for (let m = n; m !== c; m = prev[m]) chain.push(m);
            chain.reverse();
            // «натянуть нить» по цепочке: от текущей точки — к самой дальней видимой
            const pts = []; let ax = x, az = z, i = 0;
            while (i < chain.length) {
              let j = chain.length - 1;
              while (j > i && !this.segClear(ax, az, ptX(chain[j]), ptZ(chain[j]), 0.3)) j--;
              ax = ptX(chain[j]); az = ptZ(chain[j]); pts.push({ x: ax, z: az }); i = j + 1;
            }
            return { pts, cell: k };
          }
        }
        const ni = n % W, nj = Math.floor(n / W);
        for (let d = 0; d < 8; d++) {
          const i = ni + DI[d], j = nj + DJ[d];
          if (i < 0 || j < 0 || i >= W || j >= W) continue;
          const m = j * W + i;
          if (prev[m] !== -2) continue;
          if (G.map.blocked(ptX(m), ptZ(m), 0.33)) { prev[m] = -3; continue; }
          if (DI[d] && DJ[d] && (prev[nj * W + i] === -3 || prev[j * W + ni] === -3)) continue;   // по диагонали мимо угла — нет
          prev[m] = n; q[qt++] = m;
        }
      }
      return null;
    },
    randomInRect(x0, x1, z0, z1) {
      const key = [x0, x1, z0, z1].join(',');
      let l = this.rectCache[key];
      if (!l) {
        const inR = (c) => { const p = this.posOf(c); return p.x > x0 && p.x < x1 && p.z > z0 && p.z < z1; };
        l = (this.main || this.list).filter(inR);   // 2.1.1: в игровой области (нет там клеток — как раньше, любые в прямоугольнике)
        if (!l.length) l = this.list.filter(inR);
        this.rectCache[key] = l;
      }
      return this.posOf(l.length ? G.pick(l) : G.pick(this.main || this.list));
    },
    randomPoint(filter) {
      const L = this.main || this.list;   // 2.1.1: только игровая область
      for (let k = 0; k < 200; k++) {
        const c = G.pick(L), p = this.posOf(c);
        if (!filter || filter(p.x, p.z)) return p;
      }
      return this.posOf(G.pick(L));
    },
    // проверка, что отрезок проходим (для сглаживания пути)
    segClear(ax, az, bx, bz, r) {
      const dx = bx - ax, dz = bz - az, d = Math.hypot(dx, dz);
      const n = Math.ceil(d / 0.35);
      if (G.map.blockedSeg) return !G.map.blockedSeg(ax, az, dx, dz, n, r); // 2.0 perf: тот же ответ, сетка опрашивается реже
      for (let i = 1; i <= n; i++) {
        const t = i / n;
        if (G.map.blocked(ax + dx * t, az + dz * t, r)) return false;
      }
      return true;
    },
    // 2.0 perf: бюджет поисков пути на кадр (клиент) / тик (сервер) на всех ботов: в начале раунда все боты разом
    // искали путь в одном кадре — рывок. Кадр узнаём по G.game.time (растёт каждый кадр и на клиенте, и на сервере)
    BUDGET: 2, budT: -1, budN: 0,
    takeBudget() {
      const t = G.game ? G.game.time : 0;
      if (t !== this.budT) { this.budT = t; this.budN = 0; }
      if (this.budN >= this.BUDGET) return false;
      this.budN++;
      return true;
    },
    findPath(sx, sz, tx, tz) {
      const t = this.nearestWalkable(tx, tz);
      if (t < 0) return null;
      const wc = this.comp ? this.comp[t] : null;
      let s = this.nearestReach(sx, sz, wc, true), pre = null;
      // 2.1.1: по прямой ни до одной клетки не дойти — выход из «кармана» с поворотом; нет и его — как раньше, ближайшая клетка
      if (s < 0) { const e = this.escape(sx, sz, wc); if (e) { s = e.cell; pre = e.pts; } else s = this.nearestWalkable(sx, sz); }
      if (s < 0) return null;
      if (s === t) return pre ? pre.concat({ x: tx, z: tz }) : [{ x: tx, z: tz }];
      const nx = this.nx, g = this.g, f = this.f, par = this.parent, st = this.state, heap = this.heap;
      this.gen += 2; const OPEN = this.gen, CLOSED = this.gen + 1;
      const ti = t % nx, tj = Math.floor(t / nx);
      HS = 0;
      g[s] = 0; f[s] = hcost(s, nx, ti, tj); par[s] = -1; st[s] = OPEN; hpush(heap, f, s);
      const walk = this.walk, nz = this.nz;
      let found = false, iter = 0;
      while (HS > 0 && iter++ < this.nx * this.nz) {
        const c = hpop(heap, f);
        if (st[c] === CLOSED) continue;
        st[c] = CLOSED;
        if (c === t) { found = true; break; }
        const ci = c % nx, cj = Math.floor(c / nx);
        for (let d = 0; d < 8; d++) {
          const di = DI[d], dj = DJ[d], cost = DC[d];
          const i = ci + di, j = cj + dj;
          if (i < 0 || j < 0 || i >= nx || j >= nz) continue;
          const k = j * nx + i;
          if (!walk[k] || st[k] === CLOSED) continue;
          if (di && dj && (!walk[cj * nx + i] || !walk[j * nx + ci])) continue;
          const ng = g[c] + cost;
          if (st[k] !== OPEN || ng < g[k]) {
            g[k] = ng; f[k] = ng + hcost(k, nx, ti, tj); par[k] = c; st[k] = OPEN;
            if (HS < heap.length - 1) hpush(heap, f, k);
          }
        }
      }
      if (!found) return null;
      // 2.3 perf: клетки пути — в постоянном буфере, точки считаются по номеру клетки; объекты создаются только для
      // точек ответа (раньше — массив клеток, его копия и объект на КАЖДУЮ клетку пути). Точки те же, что у posOf
      const cb = this.cellBuf && this.cellBuf.length >= nx * nz ? this.cellBuf : (this.cellBuf = new Int32Array(nx * nz));
      let L = 0;
      for (let c = t; c !== -1; c = par[c]) cb[L++] = c;
      for (let i = 0, j = L - 1; i < j; i++, j--) { const tmp = cb[i]; cb[i] = cb[j]; cb[j] = tmp; }
      const x0 = this.x0, z0 = this.z0, step = this.step;
      // сглаживание «натягиванием нити»
      const out = [];
      let ax = sx, az = sz, i = 0;
      if (pre) for (const p of pre) { out.push(p); ax = p.x; az = p.z; }   // сначала — выход из «кармана»
      // 2.1.1: до второй клетки по прямой не дойти — сначала к первой (клетке старта)
      if (L > 1 && !this.segClear(ax, az, x0 + (cb[1] % nx) * step, z0 + Math.floor(cb[1] / nx) * step, 0.33)) { ax = x0 + (cb[0] % nx) * step; az = z0 + Math.floor(cb[0] / nx) * step; out.push({ x: ax, z: az }); }
      while (i < L - 1) {
        let j = Math.min(L - 1, i + 12);
        while (j > i + 1 && !this.segClear(ax, az, x0 + (cb[j] % nx) * step, z0 + Math.floor(cb[j] / nx) * step, 0.33)) j--;
        const px = x0 + (cb[j] % nx) * step, pz = z0 + Math.floor(cb[j] / nx) * step;
        out.push({ x: px, z: pz }); ax = px; az = pz; i = j;
      }
      if (!out.length) out.push({ x: x0 + (cb[L - 1] % nx) * step, z: z0 + Math.floor(cb[L - 1] / nx) * step });
      return out;
    }
  };
})(window.G);
