'use strict';
/* Навигационная сетка и поиск пути A* для ботов */
(function (G) {
  // 2.0 perf: соседи клетки — константы модуля (раньше массив массивов создавался на каждый поиск и разбирался деструктуризацией)
  const DI = [1, -1, 0, 0, 1, 1, -1, -1], DJ = [0, 0, 1, -1, 1, -1, 1, -1], DC = [1, 1, 1, 1, 1.4142, 1.4142, 1.4142, 1.4142];
  const nav = G.nav = {
    step: 1, x0: 0, z0: 0, nx: 0, nz: 0, walk: null, list: [], cache: {}, rectCache: {},
    build() {
      const id = G.map.id;
      if (this.cache[id]) { Object.assign(this, this.cache[id]); return; }
      const bd = G.map.bounds;
      this.x0 = bd.x0 + 0.5; this.z0 = bd.z0 + 0.5;
      this.nx = Math.round(bd.x1 - bd.x0); this.nz = Math.round(bd.z1 - bd.z0);
      const n = this.nx * this.nz;
      this.walk = new Uint8Array(n);
      this.list = [];
      for (let j = 0; j < this.nz; j++) for (let i = 0; i < this.nx; i++) {
        const x = this.x0 + i * this.step, z = this.z0 + j * this.step;
        if (!G.map.blocked(x, z, 0.45)) { this.walk[j * this.nx + i] = 1; this.list.push(j * this.nx + i); }
      }
      this.g = new Float32Array(n); this.f = new Float32Array(n);
      this.parent = new Int32Array(n); this.state = new Uint32Array(n); this.gen = this.gen || 0;
      this.heap = new Int32Array(n * 8);
      this.rectCache = {};
      this.cache[id] = { x0: this.x0, z0: this.z0, nx: this.nx, nz: this.nz, walk: this.walk, list: this.list, g: this.g, f: this.f, parent: this.parent, state: this.state, heap: this.heap, rectCache: this.rectCache };
    },
    cellOf(x, z) {
      const i = Math.round((x - this.x0) / this.step), j = Math.round((z - this.z0) / this.step);
      if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) return -1;
      return j * this.nx + i;
    },
    posOf(c) { return { x: this.x0 + (c % this.nx) * this.step, z: this.z0 + Math.floor(c / this.nx) * this.step }; },
    nearestWalkable(x, z) {
      const c = this.cellOf(G.clamp(x, this.x0, this.x0 + this.nx - 1), G.clamp(z, this.z0, this.z0 + this.nz - 1));
      if (c >= 0 && this.walk[c]) return c;
      const ci = c % this.nx, cj = Math.floor(c / this.nx);
      for (let r = 1; r < 6; r++) {
        let best = -1, bd = 1e9;
        for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
          if (Math.abs(di) !== r && Math.abs(dj) !== r) continue;
          const i = ci + di, j = cj + dj;
          if (i < 0 || j < 0 || i >= this.nx || j >= this.nz) continue;
          const k = j * this.nx + i;
          if (!this.walk[k]) continue;
          const p = this.posOf(k), d = (p.x - x) ** 2 + (p.z - z) ** 2;
          if (d < bd) { bd = d; best = k; }
        }
        if (best >= 0) return best;
      }
      return -1;
    },
    randomInRect(x0, x1, z0, z1) {
      const key = [x0, x1, z0, z1].join(',');
      let l = this.rectCache[key];
      if (!l) {
        l = this.rectCache[key] = this.list.filter(c => { const p = this.posOf(c); return p.x > x0 && p.x < x1 && p.z > z0 && p.z < z1; });
      }
      return this.posOf(l.length ? G.pick(l) : G.pick(this.list));
    },
    randomPoint(filter) {
      for (let k = 0; k < 200; k++) {
        const c = G.pick(this.list), p = this.posOf(c);
        if (!filter || filter(p.x, p.z)) return p;
      }
      return this.posOf(G.pick(this.list));
    },
    // проверка, что отрезок проходим (для сглаживания пути)
    segClear(ax, az, bx, bz, r) {
      const dx = bx - ax, dz = bz - az, d = Math.hypot(dx, dz);
      const n = Math.ceil(d / 0.35);
      if (G.map.blockedSeg) return !G.map.blockedSeg(ax, az, dx, dz, n, r); // 2.0 perf: тот же ответ, сетка опрашивается реже
      for (let i = 1; i <= n; i++) {
        const t = i / n;
        if (G.map.blocked(ax + dx * t, az + dz * t, r)) return false;
      }
      return true;
    },
    // 2.0 perf: бюджет поисков пути на кадр (клиент) / тик (сервер) на всех ботов: в начале раунда все боты разом
    // искали путь в одном кадре — рывок. Кадр узнаём по G.game.time (растёт каждый кадр и на клиенте, и на сервере)
    BUDGET: 2, budT: -1, budN: 0,
    takeBudget() {
      const t = G.game ? G.game.time : 0;
      if (t !== this.budT) { this.budT = t; this.budN = 0; }
      if (this.budN >= this.BUDGET) return false;
      this.budN++;
      return true;
    },
    findPath(sx, sz, tx, tz) {
      const s = this.nearestWalkable(sx, sz), t = this.nearestWalkable(tx, tz);
      if (s < 0 || t < 0) return null;
      if (s === t) return [{ x: tx, z: tz }];
      const nx = this.nx, g = this.g, f = this.f, par = this.parent, st = this.state, heap = this.heap;
      this.gen += 2; const OPEN = this.gen, CLOSED = this.gen + 1;
      const tp = this.posOf(t), ti = t % nx, tj = Math.floor(t / nx);
      const hfun = (c) => {
        const dx = Math.abs((c % nx) - ti), dz = Math.abs(Math.floor(c / nx) - tj);
        return (dx + dz) + (1.4142 - 2) * Math.min(dx, dz);
      };
      let hs = 0;
      const push = (c) => {
        let i = hs++; heap[i] = c;
        while (i > 0) { const p = (i - 1) >> 1; if (f[heap[p]] <= f[heap[i]]) break; const tmp = heap[p]; heap[p] = heap[i]; heap[i] = tmp; i = p; }
      };
      const pop = () => {
        const top = heap[0]; heap[0] = heap[--hs]; let i = 0;
        for (;;) {
          const l = i * 2 + 1, r = l + 1; let m = i;
          if (l < hs && f[heap[l]] < f[heap[m]]) m = l;
          if (r < hs && f[heap[r]] < f[heap[m]]) m = r;
          if (m === i) break; const tmp = heap[m]; heap[m] = heap[i]; heap[i] = tmp; i = m;
        }
        return top;
      };
      g[s] = 0; f[s] = hfun(s); par[s] = -1; st[s] = OPEN; push(s);
      const walk = this.walk, nz = this.nz;
      let found = false, iter = 0;
      while (hs > 0 && iter++ < this.nx * this.nz) {
        const c = pop();
        if (st[c] === CLOSED) continue;
        st[c] = CLOSED;
        if (c === t) { found = true; break; }
        const ci = c % nx, cj = Math.floor(c / nx);
        for (let d = 0; d < 8; d++) {
          const di = DI[d], dj = DJ[d], cost = DC[d];
          const i = ci + di, j = cj + dj;
          if (i < 0 || j < 0 || i >= nx || j >= nz) continue;
          const k = j * nx + i;
          if (!walk[k] || st[k] === CLOSED) continue;
          if (di && dj && (!walk[cj * nx + i] || !walk[j * nx + ci])) continue;
          const ng = g[c] + cost;
          if (st[k] !== OPEN || ng < g[k]) {
            g[k] = ng; f[k] = ng + hfun(k); par[k] = c; st[k] = OPEN;
            if (hs < heap.length - 1) push(k);
          }
        }
      }
      if (!found) return null;
      const cells = [];
      for (let c = t; c !== -1; c = par[c]) cells.push(c);
      cells.reverse();
      const pts = cells.map(c => this.posOf(c));
      pts[pts.length - 1] = { x: tp.x, z: tp.z };
      // сглаживание «натягиванием нити»
      const out = [];
      let a = { x: sx, z: sz }, i = 0;
      while (i < pts.length - 1) {
        let j = Math.min(pts.length - 1, i + 12);
        while (j > i + 1 && !this.segClear(a.x, a.z, pts[j].x, pts[j].z, 0.33)) j--;
        out.push(pts[j]); a = pts[j]; i = j;
      }
      if (!out.length) out.push(pts[pts.length - 1]);
      return out;
    }
  };
})(window.G);
