'use strict';
/* Оружие: характеристики и модели (профили + детали), руки от первого лица, ножи М9 и бабочка */
(function (G) {
  const W = G.WEAPONS = {
    pistol: {
      id: 'pistol', slot: 'secondary', name: 'Glock-18', cls: 'Пистолет', dmg: 26, rate: 0.15, auto: false, team: 1,
      mag: 20, reserve: 100, reload: 1.8, spread: 0.006, spreadMove: 0.03, spreadJump: 0.1, spreadShot: 0.02,
      spreadMax: 0.06, recoil: 0.026, recoilYaw: 0.006, range: 90, falloff: 0.006, speed: 5.6, head: 4, pellets: 1,
      sound: 'pistol', bars: [5, 5, 5, 8], price: 200, reward: 300, pen: 0.55
    },
    usp: {
      id: 'usp', slot: 'secondary', name: 'USP-S', cls: 'Пистолет с глушителем', dmg: 31, rate: 0.17, auto: false, team: 0,
      mag: 12, reserve: 24, reload: 2.2, spread: 0.0042, spreadMove: 0.028, spreadJump: 0.1, spreadShot: 0.018,
      spreadMax: 0.055, recoil: 0.021, recoilYaw: 0.005, range: 100, falloff: 0.005, speed: 5.6, head: 4, pellets: 1,
      sound: 'usp', bars: [6, 5, 8, 8], price: 200, reward: 300, pen: 0.55, silenced: true
    },
    magnum: {
      id: 'magnum', slot: 'secondary', name: 'Desert Eagle', cls: 'Тяжёлый пистолет', dmg: 52, rate: 0.34, auto: false,
      mag: 7, reserve: 35, reload: 2.1, spread: 0.007, spreadMove: 0.05, spreadJump: 0.14, spreadShot: 0.04,
      spreadMax: 0.08, recoil: 0.065, recoilYaw: 0.012, range: 110, falloff: 0.004, speed: 5.45, head: 3.6, pellets: 1,
      sound: 'magnum', bars: [8, 3, 6, 7], price: 700, reward: 300, pen: 0.93
    },
    smg: {
      id: 'smg', slot: 'primary', name: 'UMP-45', cls: 'Пистолет-пулемёт', dmg: 21, rate: 0.068, auto: true,
      mag: 32, reserve: 160, reload: 1.9, spread: 0.008, spreadMove: 0.018, spreadJump: 0.08, spreadShot: 0.006,
      spreadMax: 0.045, recoil: 0.009, recoilYaw: 0.007, range: 90, falloff: 0.009, speed: 5.6, head: 3.5, pellets: 1,
      sound: 'smg', bars: [5, 9, 7, 8], price: 1200, reward: 600, pen: 0.6
    },
    shotgun: {
      id: 'shotgun', slot: 'primary', name: 'M870', cls: 'Помповый дробовик', dmg: 17, rate: 0.85, auto: false,
      mag: 7, reserve: 35, reload: 2.6, spread: 0.06, spreadMove: 0.015, spreadJump: 0.03, spreadShot: 0,
      spreadMax: 0.09, recoil: 0.065, recoilYaw: 0.012, range: 45, falloff: 0.022, speed: 5.1, head: 2.5, pellets: 9,
      sound: 'shotgun', bars: [9, 3, 2, 6], price: 1100, reward: 900, pen: 0.6
    },
    ar: {
      id: 'ar', slot: 'primary', name: 'AK-47', cls: 'Штурмовая винтовка', dmg: 30, rate: 0.1, auto: true, team: 1,
      mag: 30, reserve: 120, reload: 2.3, spread: 0.004, spreadMove: 0.05, spreadJump: 0.14, spreadShot: 0.011,
      spreadMax: 0.06, recoil: 0.017, recoilYaw: 0.007, range: 140, falloff: 0.003, speed: 5.15, head: 4, pellets: 1,
      sound: 'ar', bars: [7, 7, 6, 5], price: 2700, reward: 300, pen: 0.77
    },
    ar2: {
      id: 'ar2', slot: 'primary', name: 'M4A4', cls: 'Штурмовая винтовка', dmg: 27, rate: 0.09, auto: true, team: 0,
      mag: 30, reserve: 90, reload: 2.5, spread: 0.0032, spreadMove: 0.045, spreadJump: 0.13, spreadShot: 0.009,
      spreadMax: 0.05, recoil: 0.0135, recoilYaw: 0.006, range: 140, falloff: 0.003, speed: 5.2, head: 4, pellets: 1,
      sound: 'ar2', bars: [6, 8, 8, 5], price: 3100, reward: 300, pen: 0.7
    },
    m4s: {
      id: 'm4s', slot: 'primary', name: 'M4A1-S', cls: 'Штурмовая винтовка с глушителем', dmg: 29, rate: 0.1, auto: true, team: 0,
      mag: 20, reserve: 80, reload: 2.5, spread: 0.0027, spreadMove: 0.043, spreadJump: 0.13, spreadShot: 0.0078,
      spreadMax: 0.045, recoil: 0.0118, recoilYaw: 0.005, range: 150, falloff: 0.0027, speed: 5.2, head: 4, pellets: 1,
      sound: 'm4s', bars: [7, 7, 9, 5], price: 2900, reward: 300, pen: 0.7, silenced: true
    },
    sniper: {
      id: 'sniper', slot: 'primary', name: 'AWM', cls: 'Снайперская винтовка', dmg: 115, rate: 1.3, auto: false,
      mag: 5, reserve: 25, reload: 3.0, spread: 0.0015, spreadNoScope: 0.09, spreadMove: 0.12, spreadJump: 0.25,
      spreadShot: 0, spreadMax: 0.3, recoil: 0.07, recoilYaw: 0.01, range: 220, falloff: 0, speed: 4.75, head: 4,
      pellets: 1, scope: true, sound: 'sniper', bars: [10, 2, 10, 3], price: 4750, reward: 100, pen: 0.97
    },
    knife: { id: 'knife', slot: 'melee', name: 'Тактический нож', cls: 'Нож', dmg: 55, rate: 0.55, auto: true, melee: true, range: 2.4, speed: 6.0, head: 1.6, sound: 'knife', reward: 1500 },
    m9: { id: 'm9', slot: 'melee', name: 'Штык-нож М9', cls: 'Нож', dmg: 55, rate: 0.55, auto: true, melee: true, range: 2.45, speed: 6.0, head: 1.6, sound: 'knife', reward: 1500 },
    karambit: { id: 'karambit', slot: 'melee', name: 'Керамбит', cls: 'Нож', dmg: 55, rate: 0.48, auto: true, melee: true, range: 2.3, speed: 6.1, head: 1.6, sound: 'knife', reward: 1500 },
    butterfly: { id: 'butterfly', slot: 'melee', name: 'Нож-бабочка', cls: 'Нож', dmg: 55, rate: 0.46, auto: true, melee: true, range: 2.3, speed: 6.1, head: 1.6, sound: 'knife', reward: 1500 },
    tanto: { id: 'tanto', slot: 'melee', name: 'Танто', cls: 'Японский нож', dmg: 55, rate: 0.5, auto: true, melee: true, range: 2.45, speed: 6.1, head: 1.6, sound: 'knife', reward: 1500 },
    // гранаты: отдельный слот, бросок кнопкой огня
    he: { id: 'he', slot: 'nade', nade: 'he', name: 'HE-граната', cls: 'Осколочная граната', rate: 1.0, speed: 5.6, range: 0, price: 300, reward: 300, pen: 0.57, sound: 'nade' },
    flash: { id: 'flash', slot: 'nade', nade: 'flash', name: 'Светошумовая', cls: 'Светошумовая граната', rate: 1.0, speed: 5.6, range: 0, price: 200, reward: 300, sound: 'nade' },
    smoke: { id: 'smoke', slot: 'nade', nade: 'smoke', name: 'Дымовая', cls: 'Дымовая граната', rate: 1.0, speed: 5.6, range: 0, price: 300, reward: 300, sound: 'nade' }
  };
  G.NADE_TYPES = ['he', 'flash', 'smoke'];
  // разброс и отдача тяжелее: стрельба на бегу и длинными очередями заметно хуже
  for (const k in W) {
    const d = W[k]; if (d.melee || d.nade) continue;
    d.spread *= 1.25; d.spreadMove *= 1.35; d.spreadJump *= 1.2; d.spreadShot *= 1.4; d.spreadMax *= 1.35; d.recoil *= 1.12; d.recoilYaw *= 1.15;
    if (d.spreadNoScope) d.spreadNoScope *= 1.2;
  }
  G.PRIMARIES = ['ar', 'ar2', 'm4s', 'smg', 'shotgun', 'sniper'];
  G.KNIVES = ['knife', 'm9', 'butterfly', 'karambit', 'tanto'];

  G.newWeaponState = (id, skin, wear) => {
    const d = W[id];
    return { id, def: d, skin: skin || null, wear: wear || 0, mag: d.mag || 0, reserve: d.reserve || 0, cd: 0, reloadT: 0, heat: 0, drawT: 0 };
  };

  // ---------- детали моделей ----------
  const MET = '#2b2e32', MET2 = '#3c4147', BLK = '#18191b', POLY = '#232427', STEEL = '#a7adb3', WOOD = '#7a4a24', OLIVE = '#4f5b3c', TAN = '#8a7a5a';
  const HP = Math.PI / 2;
  const box = (w, h, d, x, y, z, color, rx, ry, rz) => ({ w, h, d, x, y, z, color, rx, ry, rz });
  const mbox = (w, h, d, x, y, z, color, rx, ry, rz) => ({ w, h, d, x, y, z, color: color || MET, rx, ry, rz, m: true });
  // цилиндр вдоль ствола: от f0 до f1 (вперёд), на высоте y; металл по умолчанию
  const tube = (r, f0, f1, y, color, x, r2, seg, poly) => ({ cyl: true, r, r2, h: f1 - f0, x: x || 0, y, z: -(f0 + f1) / 2, rx: HP, color: color || MET, seg: seg || 12, m: !poly });
  // профиль: точки [вперёд, вверх] (+кривые), толщина d
  const prof = (pts, d, color, skin, opt) => Object.assign({ shape: true, pts, d, color, skin, bevel: 0.003 }, opt || {});
  const mprof = (pts, d, color, opt) => prof(pts, d, color || MET, null, Object.assign({ m: true }, opt || {}));
  const rail = (f0, f1, y, x, w) => { const out = [mbox(w || 0.03, 0.012, f1 - f0, x || 0, y, -(f0 + f1) / 2, BLK)]; for (let f = f0 + 0.006; f < f1; f += 0.013) out.push(mbox((w || 0.03) + 0.004, 0.006, 0.006, x || 0, y + 0.009, -f, BLK)); return out; };
  const loop = (outer, inner, d, color, skin, m) => prof(outer, d, color, skin, { holes: [inner], bevel: 0.0015, m });
  // ---------- руки: перчатки с фалангами, жёсткие накладки, манжеты, рукава ----------
  const VA = {
    add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
    sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
    mul: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
    mix: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t],
    dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
    cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
    norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
    len: (a) => Math.hypot(a[0], a[1], a[2])
  };
  // c + Σ (вектор, множитель)
  const comb = (c, ...vs) => { const o = c.slice(); for (let i = 0; i < vs.length; i += 2) { o[0] += vs[i][0] * vs[i + 1]; o[1] += vs[i][1] * vs[i + 1]; o[2] += vs[i][2] * vs[i + 1]; } return o; };
  const _yAx = new THREE.Vector3(0, 1, 0), _zAx = new THREE.Vector3(0, 0, 1), _dv = new THREE.Vector3(), _m4 = new THREE.Matrix4();
  const _bx = new THREE.Vector3(), _by = new THREE.Vector3(), _bz = new THREE.Vector3();
  // «кость»: конус от a (радиус ra) к b (rb) + шарик-сустав в b
  function bone(out, a, b, ra, rb, color, opt) {
    const d = VA.sub(b, a), len = VA.len(d) || 1e-4;
    _dv.set(d[0] / len, d[1] / len, d[2] / len);
    _q.setFromUnitVectors(_yAx, _dv); _e.setFromQuaternion(_q);
    out.push(Object.assign({ cyl: true, r: rb, r2: ra, h: len, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, rx: _e.x, ry: _e.y, rz: _e.z, color, seg: 12 }, opt || {}));
    if (!(opt && opt.noJoint)) out.push(Object.assign({ sph: true, r: rb, x: b[0], y: b[1], z: b[2], color, seg: 12 }, opt && opt.skin ? { skin: opt.skin } : {}));
  }
  // кольцо вокруг оси d в точке c
  function ring(out, c, d, r, tube, color, opt) {
    const n = VA.norm(d); _dv.set(n[0], n[1], n[2]);
    _q.setFromUnitVectors(_zAx, _dv); _e.setFromQuaternion(_q);
    out.push(Object.assign({ torus: true, r, tube, x: c[0], y: c[1], z: c[2], rx: _e.x, ry: _e.y, rz: _e.z, color, seg: 18 }, opt || {}));
  }
  // эллипсоид: полуось sx вдоль ax, sy вдоль ay, sz по нормали к ним
  function blob(out, c, ax, ay, sx, sy, sz, color, opt) {
    const Y = VA.norm(ay), Z = VA.norm(VA.cross(VA.norm(ax), Y)), X = VA.cross(Y, Z);
    _bx.set(X[0], X[1], X[2]); _by.set(Y[0], Y[1], Y[2]); _bz.set(Z[0], Z[1], Z[2]);
    _m4.makeBasis(_bx, _by, _bz); _e.setFromRotationMatrix(_m4);
    out.push(Object.assign({ sph: true, r: 1, sx, sy, sz, x: c[0], y: c[1], z: c[2], rx: _e.x, ry: _e.y, rz: _e.z, color, seg: 16 }, opt || {}));
  }
  G.mk = { bone, blob, ring, comb, VA };
  const GLV_DEF = { back: '#2d3136', shell: '#4b5159', finger: '#33373d', tip: '#2a2d32', pad: '#7a6a52', cuff: '#202327', strap: '#3d434a', stitch: '#5d646c' };
  let GLV = GLV_DEF;
  // палитра перчаток из каталога скинов: [тыл, накладки, пальцы, кончики, манжета, ремешок]
  const glovePal = (gid) => {
    const sk = gid && G.SKINS && G.SKINS[gid];
    if (!sk || !sk.gl) return GLV_DEF;
    const g = sk.gl;
    return { back: g[0], shell: g[1], finger: g[2], tip: g[3], pad: g[3], cuff: g[4], strap: g[5], stitch: g[5] };
  };
  // кисть, сжатая вокруг предмета
  // C — центр хвата, A — ось (от указательного к мизинцу), B — сторона костяшек, wrap — куда загибаются пальцы,
  // rb/rn — полуразмеры предмета по B и по направлению обхвата, fingers — [{s, t:[θ0..θ3], sc}], thumb — 4 точки, W — запястье
  function hand(out, h) {
    const A = VA.norm(h.A), B = VA.norm(h.B);
    let N = VA.norm(VA.cross(B, A)); if (VA.dot(N, h.wrap) < 0) N = VA.mul(N, -1);
    if (h.Wl) h.W = comb(h.C, A, h.Wl[0], B, h.Wl[1], N, h.Wl[2]);
    const fr = 0.0094;
    const P = (th, s, ex) => comb(h.C, A, s, B, Math.cos(th) * (h.rb + fr + (ex || 0)), N, Math.sin(th) * (h.rn + fr + (ex || 0)));
    const mcps = [];
    for (const f of h.fingers) {
      const sc = f.sc || 1, r0 = fr * sc;
      let pts;
      if (f.pts) pts = f.pts.map(q => comb(h.C, A, q[0], B, q[1], N, q[2]));
      else pts = [P(f.t[0], f.s, 0.007), P(f.t[1], f.s), P(f.t[2], f.s, -0.001), P(f.t[3], f.s, -0.003)];
      const [m, p1, p2, tip] = pts;
      mcps.push(m);
      out.push({ sph: true, r: r0 * 1.18, x: m[0], y: m[1], z: m[2], color: GLV.back, seg: 12 });
      bone(out, m, p1, r0 * 1.12, r0 * 1.02, GLV.finger);
      bone(out, p1, p2, r0 * 1.0, r0 * 0.94, GLV.finger);
      bone(out, p2, tip, r0 * 0.94, r0 * 0.84, GLV.tip);
      // резиновая накладка на основной фаланге
      const mid = VA.mix(m, p1, 0.5), ctr = comb(h.C, A, f.s || 0), ow = VA.norm(VA.sub(mid, ctr));
      blob(out, comb(mid, ow, r0 * 0.72), A, VA.sub(p1, m), r0 * 0.8, VA.len(VA.sub(p1, m)) * 0.36, r0 * 0.42, GLV.shell);
    }
    // тыльная сторона ладони и жёсткая накладка на костяшках
    const k0 = mcps[0], k1 = mcps[mcps.length - 1], km = VA.mix(k0, k1, 0.5);
    const along = VA.sub(h.W, km), L = VA.len(along);
    blob(out, comb(VA.mix(km, h.W, 0.46), B, 0.002), VA.sub(k1, k0), along, Math.max(0.036, VA.len(VA.sub(k1, k0)) * 0.62), L * 0.56, 0.019, GLV.back);
    const sh0 = comb(k0, B, 0.009, VA.norm(along), 0.004), sh1 = comb(k1, B, 0.009, VA.norm(along), 0.004);
    bone(out, sh0, VA.mix(sh0, sh1, 0.5), 0.0105, 0.0112, GLV.shell); bone(out, VA.mix(sh0, sh1, 0.5), sh1, 0.0112, 0.0102, GLV.shell);
    blob(out, comb(VA.mix(km, h.W, 0.42), B, 0.016), VA.sub(k1, k0), along, 0.018, L * 0.22, 0.006, GLV.shell);
    // большой палец
    if (h.thumb) {
      const t = h.thumb.map(q => Array.isArray(q[0]) ? q[0] : comb(h.C, A, q[0], B, q[1], N, q[2]));
      blob(out, VA.mix(t[0], h.W, 0.35), VA.sub(t[1], t[0]), VA.sub(h.W, t[0]), 0.016, VA.len(VA.sub(h.W, t[0])) * 0.45, 0.014, GLV.back);
      bone(out, t[0], t[1], 0.0135, 0.0122, GLV.finger);
      bone(out, t[1], t[2], 0.0122, 0.0108, GLV.finger);
      bone(out, t[2], t[3], 0.0108, 0.0094, GLV.tip);
    }
    return { W: h.W, km };
  }
  // предплечье: манжета перчатки с липучкой, рукав с отворотом и складками, плечо
  function forearm(glove, sleeve, W, E, Sh, opt) {
    const D = VA.norm(VA.sub(E, W)), FL = VA.len(VA.sub(E, W));
    bone(glove, comb(W, D, -0.012), comb(W, D, 0.06), 0.031, 0.035, GLV.cuff, { noJoint: true });
    ring(glove, comb(W, D, 0.03), D, 0.0355, 0.0055, GLV.strap);
    glove.push({ sph: true, r: 0.031, x: W[0] - D[0] * 0.012, y: W[1] - D[1] * 0.012, z: W[2] - D[2] * 0.012, color: GLV.cuff, seg: 12 });
    if (opt && opt.watch) {
      const up = VA.norm(VA.cross(D, [1, 0, 0])), wc = comb(W, D, 0.072, up, 0.036);
      ring(glove, comb(W, D, 0.072), D, 0.037, 0.006, '#151719');
      bone(glove, comb(wc, up, -0.004), comb(wc, up, 0.006), 0.014, 0.014, '#2a2e33', { noJoint: true });
      bone(glove, comb(wc, up, 0.006), comb(wc, up, 0.0068), 0.011, 0.011, '#0f2a24', { noJoint: true, g: true });
    }
    const s0 = comb(W, D, 0.055);
    bone(sleeve, s0, comb(s0, D, 0.04), 0.045, 0.046, '#ffffff', { skin: 'a', noJoint: true });
    ring(sleeve, comb(s0, D, 0.002), D, 0.043, 0.006, '#ffffff', { skin: 'a' });
    bone(sleeve, comb(s0, D, 0.03), E, 0.042, 0.05, '#ffffff', { skin: 'a' });
    // складки ткани: два слегка наклонённых валика
    for (const [t, tl] of [[0.36, 0.25], [0.62, -0.2]]) ring(sleeve, VA.mix(comb(s0, D, 0.03), E, t), VA.add(D, [tl, 0, tl * 0.5]), 0.0435 + t * 0.008, 0.0026, '#ffffff', { skin: 'a' });
    bone(sleeve, E, Sh, 0.05, 0.06, '#ffffff', { skin: 'a' });
  }

  const rivet = (x, y, z, c) => ({ cyl: true, r: 0.0028, h: 0.004, x, y, z, rz: HP, color: c || MET2, m: true, seg: 8 });
  const dot = (x, y, z, c, r) => ({ sph: true, r: r || 0.0018, x, y, z, color: c || '#f4f4ee', em: true, seg: 8 });
  // насечки поперёк детали (тёмные канавки), n штук от f0 с шагом step
  const ser = (n, f0, step, y, h, w, c) => Array.from({ length: n }, (_, i) => box(w, h, 0.0022, 0, y, -(f0 + i * step), c || '#0e0f11'));
  const trig = (f, y, c) => mprof([[f, y], [f + 0.008, y], ['q', f + 0.009, y - 0.021, f - 0.004, y - 0.032], [f - 0.009, y - 0.029], ['q', f + 0.002, y - 0.018, f, y]], 0.005, c || MET2);
  const swivel = (y, z) => ({ torus: true, r: 0.009, tube: 0.0022, x: 0, y, z, ry: HP, color: MET, m: true, seg: 12 });

  let gunParts = function (id) {
    switch (id) {
      case 'ar': {
        // АКМ: длинная плоская коробка, крышка ствольной коробки, деревянное цевьё с накладкой, рожок, косой компенсатор
        const groove = (f) => [box(0.002, 0.03, 0.004, 0.0275, -0.004, -f, '#3a1a0c'), box(0.002, 0.03, 0.004, -0.0275, -0.004, -f, '#3a1a0c')];
        return {
          body: [
            prof([[-0.135, -0.028], [0.12, -0.028], [0.155, -0.024], [0.165, -0.012], [0.165, 0.022], [-0.135, 0.022]], 0.044, MET, 'a', { bevel: 0.0025 }),
            prof([[-0.14, 0.02], [0.15, 0.02], [0.15, 0.036], ['q', 0.148, 0.046, 0.135, 0.047], [-0.115, 0.047], ['q', -0.14, 0.046, -0.14, 0.033]], 0.042, MET, 'a', { bevel: 0.002 }),
            ...[0.105, 0.09, 0.075].map(z => mbox(0.043, 0.003, 0.004, 0, 0.0475, z, '#1d1f22')), mbox(0.012, 0.012, 0.008, 0, 0.03, 0.146, MET2),
            mbox(0.003, 0.016, 0.07, 0.0225, 0.012, -0.055, '#0b0c0d'), mbox(0.002, 0.006, 0.07, 0.0226, 0.0235, -0.055, MET2),
            ...[[-0.12, 0.008], [-0.12, -0.017], [0.0, -0.018], [0.025, 0.009], [0.132, -0.016], [0.14, 0.009]].flatMap(([f, y]) => [rivet(0.0232, y, -f), rivet(-0.0232, y, -f)]),
            // переводчик огня справа
            mprof([[-0.085, 0.012], [0.105, 0.003], [0.105, -0.004], [-0.085, 0.004]], 0.003, MET2, { x: 0.0245 }), mbox(0.004, 0.016, 0.012, 0.0255, 0.0, -0.104, MET2),
            // целик
            mprof([[0.15, 0.02], [0.215, 0.022], [0.215, 0.036], [0.172, 0.052], [0.15, 0.052]], 0.03),
            mbox(0.02, 0.0035, 0.048, 0, 0.0545, -0.19, MET2, -0.05), mbox(0.005, 0.008, 0.006, 0.0075, 0.059, -0.168, MET2), mbox(0.005, 0.008, 0.006, -0.0075, 0.059, -0.168, MET2),
            // цевьё снизу с выемками под ладонь и накладка сверху
            prof([[0.17, -0.026], ['q', 0.2, -0.034, 0.25, -0.032], ['q', 0.29, -0.027, 0.33, -0.034], [0.372, -0.031], ['q', 0.388, -0.028, 0.388, -0.015], [0.388, 0.02], [0.17, 0.02]], 0.052, WOOD, 'b', { bevel: 0.007, cs: 8 }),
            ...[0.215, 0.235, 0.255].flatMap(groove),
            prof([[0.215, 0.026], [0.383, 0.026], [0.383, 0.04], ['q', 0.378, 0.054, 0.36, 0.054], [0.24, 0.054], ['q', 0.218, 0.052, 0.215, 0.04]], 0.036, WOOD, 'b', { bevel: 0.005, cs: 8 }),
            mbox(0.066, 0.008, 0.012, 0, -0.03, -0.168, MET2), mbox(0.064, 0.096, 0.012, 0, 0.004, -0.398, MET2), rivet(0.033, 0.01, -0.398, MET),
            // газовая трубка, газоотвод, ствол, шомпол
            tube(0.0088, 0.384, 0.434, 0.042), mprof([[0.428, -0.002], [0.464, -0.002], [0.464, 0.028], [0.448, 0.053], [0.428, 0.053]], 0.028, MET2),
            tube(0.0105, 0.39, 0.6, 0.008, MET, 0, 0.0094), tube(0.0028, 0.405, 0.588, -0.014, STEEL), { sph: true, r: 0.0042, x: 0, y: -0.014, z: -0.59, color: STEEL, m: true, seg: 8 },
            // мушка в «ушах», штык-упор
            mbox(0.026, 0.04, 0.044, 0, 0.004, -0.578, MET2), mprof([[0.566, 0.024], [0.592, 0.024], [0.586, 0.066], [0.572, 0.066]], 0.02, MET2),
            mbox(0.004, 0.03, 0.016, 0.0115, 0.058, -0.579, MET), mbox(0.004, 0.03, 0.016, -0.0115, 0.058, -0.579, MET), mbox(0.003, 0.018, 0.003, 0, 0.062, -0.579, STEEL),
            mbox(0.012, 0.016, 0.028, 0, -0.024, -0.575, MET2),
            // косой дульный тормоз
            tube(0.0132, 0.6, 0.652, 0.008, BLK, 0, null, 14), mbox(0.012, 0.004, 0.018, 0.006, 0.0215, -0.642, '#0a0b0c'), tube(0.0136, 0.6, 0.606, 0.008, MET2, 0, null, 14), tube(0.006, 0.651, 0.653, 0.008, '#050505'),
            // рукоять, спусковая скоба и крючок, защёлка магазина
            prof([[-0.062, -0.026], [-0.022, -0.026], ['q', -0.03, -0.07, -0.046, -0.135], [-0.088, -0.128], ['q', -0.074, -0.07, -0.062, -0.026]], 0.034, WOOD, 'b', { bevel: 0.005, cs: 8 }),
            ...[-0.06, -0.075, -0.09, -0.105].map(y => box(0.037, 0.003, 0.016, 0, y, 0.052 - (y + 0.06) * 0.42, '#3a1a0c')),
            loop([[-0.03, -0.027], [0.058, -0.027], ['q', 0.06, -0.064, 0.03, -0.068], [-0.02, -0.068], ['q', -0.03, -0.064, -0.03, -0.046]],
              [[-0.02, -0.034], [0.048, -0.034], ['q', 0.048, -0.058, 0.028, -0.06], [-0.014, -0.06], ['q', -0.02, -0.056, -0.02, -0.046]], 0.01, MET, null, true),
            trig(0.004, -0.028), mbox(0.012, 0.024, 0.008, 0, -0.04, -0.036, MET2),
            // приклад, хвостовик, затыльник
            mprof([[-0.165, 0.018], [-0.135, 0.018], [-0.135, -0.028], [-0.165, -0.036]], 0.046, MET2),
            prof([[-0.16, 0.019], ['q', -0.19, 0.017, -0.23, 0.008], [-0.44, -0.014], [-0.455, -0.016], [-0.455, -0.122], [-0.44, -0.125], [-0.2, -0.05], ['q', -0.165, -0.04, -0.16, -0.034]], 0.044, WOOD, 'b', { bevel: 0.006, cs: 8 }),
            mbox(0.05, 0.112, 0.01, 0, -0.068, 0.462, MET2), mbox(0.03, 0.05, 0.002, 0, -0.07, 0.467, '#2a2d30'), rivet(0, -0.03, 0.468, MET), rivet(0, -0.106, 0.468, MET),
            box(0.05, 0.009, 0.03, 0, -0.058, 0.39, '#1a1208'), swivel(-0.034, -0.4), swivel(-0.106, 0.3)
          ],
          slide: [mbox(0.004, 0.009, 0.05, 0.0245, 0.015, -0.08, STEEL), mbox(0.02, 0.006, 0.008, 0.034, 0.015, -0.104, MET2), { sph: true, r: 0.0075, x: 0.046, y: 0.015, z: -0.104, color: MET2, m: true, seg: 10 }],
          mag: [prof([[0.042, -0.026], [0.114, -0.026], ['q', 0.13, -0.12, 0.205, -0.205], [0.168, -0.232], ['q', 0.09, -0.13, 0.042, -0.026]], 0.028, MET2, null, { bevel: 0.003, m: true, cs: 10 }),
            prof([[0.062, -0.04], [0.074, -0.04], ['q', 0.09, -0.12, 0.168, -0.2], [0.158, -0.208], ['q', 0.078, -0.125, 0.062, -0.04]], 0.031, MET, null, { m: true, cs: 10 }),
            prof([[0.09, -0.032], [0.1, -0.032], ['q', 0.112, -0.11, 0.186, -0.188], [0.18, -0.196], ['q', 0.1, -0.115, 0.09, -0.032]], 0.0305, MET, null, { m: true, cs: 10 }),
            mprof([[0.168, -0.232], [0.205, -0.205], [0.212, -0.212], [0.175, -0.239]], 0.032, MET)],
          magPivot: [0, -0.026, -0.114], charge: [0.04, 0.02, -0.1],
          muzzle: [0, 0.008, -0.66], rh: [0, -0.078, 0.07], lh: [0, -0.03, -0.28]
        };
      }
      case 'ar2': return {
        body: [
          prof([[-0.16, 0.0], [0.14, 0.0], [0.14, 0.046], [-0.16, 0.046]], 0.05, BLK, 'a'),
          prof([[-0.14, -0.042], [0.1, -0.042], [0.1, 0.002], [-0.165, 0.002], ['q', -0.165, -0.04, -0.14, -0.042]], 0.046, BLK, 'a'),
          prof([[0.028, -0.09], [0.102, -0.09], [0.106, -0.04], [0.024, -0.04]], 0.044, BLK, 'a'),
          mbox(0.003, 0.018, 0.06, 0.026, 0.024, 0.04, '#0d0e10'), mbox(0.002, 0.004, 0.058, 0.0272, 0.012, 0.04, MET2),
          { cyl: true, r: 0.009, h: 0.03, x: 0.03, y: 0.03, z: 0.1, rx: HP, color: MET2, m: true }, { cyl: true, r: 0.0098, h: 0.006, x: 0.03, y: 0.03, z: 0.086, rx: HP, color: BLK, m: true },
          mprof([[-0.078, 0.03], [-0.06, 0.03], [-0.064, 0.046], [-0.074, 0.046]], 0.008, BLK, { x: 0.027 }),
          mbox(0.046, 0.008, 0.016, 0, 0.042, 0.168, BLK), mbox(0.012, 0.006, 0.03, 0, 0.042, 0.148, BLK),
          { cyl: true, r: 0.004, h: 0.054, x: 0, y: -0.018, z: 0.13, rz: HP, color: MET2, m: true }, { cyl: true, r: 0.004, h: 0.054, x: 0, y: 0.008, z: -0.128, rz: HP, color: MET2, m: true },
          mbox(0.003, 0.022, 0.012, -0.0255, -0.004, 0.03, BLK), { cyl: true, r: 0.0055, h: 0.005, x: 0.0255, y: -0.022, z: -0.03, rz: HP, color: MET2, m: true },
          { cyl: true, r: 0.0062, h: 0.004, x: 0.0255, y: -0.014, z: 0.06, rz: HP, color: MET2, m: true }, mbox(0.003, 0.004, 0.02, 0.0275, -0.014, 0.05, MET2),
          ...rail(-0.15, 0.14, 0.052),
          prof([[0.14, -0.012], [0.42, -0.012], ['q', 0.43, -0.012, 0.43, 0.0], [0.43, 0.044], ['q', 0.43, 0.056, 0.42, 0.056], [0.14, 0.056]], 0.06, POLY, 'b', { bevel: 0.007 }),
          ...[0.19, 0.25, 0.31, 0.37].flatMap(f => [box(0.002, 0.012, 0.03, 0.0335, 0.03, -f, '#0d0e10'), box(0.002, 0.012, 0.03, -0.0335, 0.03, -f, '#0d0e10'),
            box(0.002, 0.009, 0.022, 0.0335, 0.008, -f - 0.028, '#0d0e10'), box(0.002, 0.009, 0.022, -0.0335, 0.008, -f - 0.028, '#0d0e10')]),
          ...rail(0.15, 0.42, 0.062),
          tube(0.0105, 0.43, 0.62, 0.02), tube(0.013, 0.6, 0.665, 0.02, BLK), tube(0.0135, 0.66, 0.668, 0.02, MET2),
          ...[0.615, 0.635, 0.655].map(f => mbox(0.028, 0.004, 0.006, 0, 0.02, -f, '#0d0e10')),
          mprof([[0.395, 0.066], [0.42, 0.066], [0.416, 0.098], [0.407, 0.098]], 0.016, BLK), mbox(0.004, 0.022, 0.014, 0.011, 0.084, -0.41, BLK), mbox(0.004, 0.022, 0.014, -0.011, 0.084, -0.41, BLK),
          mprof([[-0.13, 0.064], [-0.09, 0.064], [-0.094, 0.09], [-0.12, 0.09]], 0.022, BLK), { torus: true, r: 0.004, tube: 0.0018, x: 0, y: 0.084, z: 0.105, color: BLK, m: true, seg: 10 },
          // коллиматор: корпус-трубка, линза, красная точка
          mbox(0.034, 0.012, 0.07, 0, 0.072, -0.02, BLK), { torus: true, r: 0.022, tube: 0.004, x: 0, y: 0.1, z: -0.04, color: BLK, m: true, seg: 18 },
          { torus: true, r: 0.022, tube: 0.004, x: 0, y: 0.1, z: -0.002, color: BLK, m: true, seg: 18 },
          mbox(0.006, 0.03, 0.05, 0.021, 0.09, -0.02, BLK), mbox(0.006, 0.03, 0.05, -0.021, 0.09, -0.02, BLK), mbox(0.036, 0.006, 0.042, 0, 0.123, -0.02, BLK),
          { cyl: true, r: 0.009, h: 0.012, x: 0.026, y: 0.104, z: -0.02, rz: HP, color: BLK, m: true },
          { cyl: true, r: 0.02, h: 0.003, x: 0, y: 0.1, z: -0.04, rx: HP, color: '#1a7f88', g: true, seg: 18 }, dot(0, 0.1, -0.0375, '#ff2a2a', 0.0017),
          prof([[-0.085, -0.038], [-0.045, -0.038], ['q', -0.05, -0.09, -0.06, -0.145], [-0.102, -0.135], ['q', -0.095, -0.08, -0.085, -0.038]], 0.034, POLY, 'b', { bevel: 0.005 }),
          ...[-0.06, -0.08, -0.1, -0.12].map(y => box(0.04, 0.003, 0.012, 0, y, 0.064 - (y + 0.06) * 0.3, '#121315')),
          loop([[-0.04, -0.04], [0.03, -0.04], [0.03, -0.072], [-0.035, -0.076]], [[-0.033, -0.046], [0.022, -0.046], [0.022, -0.066], [-0.028, -0.069]], 0.01, BLK),
          trig(-0.006, -0.042, BLK),
          tube(0.016, -0.32, -0.16, 0.012, BLK), tube(0.0195, -0.178, -0.165, 0.012, MET2),
          prof([[-0.26, 0.036], [-0.3, 0.044], [-0.43, 0.044], ['q', -0.442, 0.044, -0.442, 0.03], [-0.442, -0.075], [-0.425, -0.082], [-0.32, -0.03], [-0.26, -0.025]], 0.05, POLY, 'b', { bevel: 0.006 }),
          prof([[-0.33, 0.044], [-0.425, 0.044], [-0.425, 0.058], [-0.34, 0.056]], 0.034, POLY, 'b', { bevel: 0.004 }),
          box(0.054, 0.008, 0.026, 0, -0.04, 0.36, '#121315'), mbox(0.012, 0.03, 0.01, 0, -0.04, 0.29, BLK), swivel(-0.07, 0.43),
          mbox(0.04, 0.012, 0.025, 0, 0.05, 0.17, BLK)
        ],
        mag: [prof([[0.034, -0.08], [0.096, -0.08], ['q', 0.1, -0.15, 0.112, -0.228], [0.054, -0.234], ['q', 0.042, -0.155, 0.034, -0.08]], 0.03, MET2, null, { bevel: 0.004, m: true }),
          ...[0.12, 0.16, 0.2].map(dy => mbox(0.034, 0.004, 0.05, 0, -dy, -0.07 - (dy - 0.12) * 0.12, MET)),
          mprof([[0.052, -0.234], [0.114, -0.228], [0.116, -0.24], [0.05, -0.246]], 0.036, BLK)],
        muzzle: [0, 0.02, -0.67], rh: [0, -0.088, 0.07], lh: [0, -0.024, -0.29], charge: [-0.02, -0.03, -0.015]
      };
      case 'm4s': {
        // M4A1-S (как в CS2): верхняя коробка flat-top со ступенькой под планкой, окно экстракции с открытой крышкой,
        // досылатель и отражатель гильз; круглое цевьё с рядами вентиляционных окон и дельта-кольцом; длинный тонкий глушитель
        // с поясками и фаской на торце; откидные мушка и целик с диоптром; изогнутый STANAG с рёбрами; рукоять A2; приклад «крейн»
        const BY = 0.021; // ось канала ствола
        const AC = '#1e2124', PC = '#232528', SC = '#2e3135', GRV = '#0c0d0f', BR = '#b08a3e'; // цвета для мировой модели и прорезей
        const pic = (f0, f1, y, w) => { const o = [mbox(w, 0.0065, f1 - f0, 0, y, -(f0 + f1) / 2, BLK)]; for (let f = f0 + 0.005; f < f1 - 0.003; f += 0.0118) o.push(mbox(w + 0.003, 0.0042, 0.0046, 0, y + 0.0045, -f, BLK)); return o; };
        const cylZ = (r, f0, f1, color, o) => Object.assign({ cyl: true, r, h: f1 - f0, x: 0, y: BY, z: -(f0 + f1) / 2, rx: HP, color, seg: 12, m: true }, o || {});
        const pinX = (f, y, r, c) => ({ cyl: true, r, h: 0.0472, x: 0, y, z: -f, rz: HP, color: c || MET2, m: true, seg: 10 });
        // вентиляционное окно на круглом цевье: φ — угол от правого борта вверх
        const HR = 0.0268;
        const vent = (f, phi, len) => box(0.0024, 0.0062, len || 0.019, Math.cos(phi) * (HR - 0.0006), BY + Math.sin(phi) * (HR - 0.0006), -f, GRV, 0, 0, phi);
        const D2R = Math.PI / 180;
        const VA0 = [18, 162, -18, -162, -90].map(a => a * D2R);
        // короткие боковые планки у торца цевья
        const sideRail = (sx) => [mbox(0.005, 0.016, 0.05, sx * 0.027, BY, -0.359, BLK), ...[0.341, 0.352, 0.363, 0.374].map(f => box(0.004, 0.019, 0.0046, sx * 0.0296, BY, -f, BLK))];
        // откидной целик: основание, лист с диоптром, защитные «уши», барабанчик поправок
        const rs = 0.13; // z целика
        const rearSight = [
          mbox(0.025, 0.007, 0.03, 0, 0.0565, rs, BLK),
          mbox(0.0146, 0.012, 0.0036, 0, 0.065, rs + 0.0005, BLK),
          ...[1, -1].map(s => mprof([[-0.143, 0.059], [-0.12, 0.059], [-0.124, 0.07], [-0.132, 0.0835], [-0.138, 0.0835], [-0.141, 0.072]], 0.0034, BLK, { x: s * 0.0092, bevel: 0.0008, bseg: 1 })),
          { torus: true, r: 0.0036, tube: 0.0015, x: 0, y: 0.0745, z: rs + 0.0005, color: BLK, m: true, seg: 10 },
          { cyl: true, r: 0.0022, h: 0.0012, x: 0, y: 0.0745, z: rs + 0.001, rx: HP, color: '#050505', seg: 8 },
          { cyl: true, r: 0.0042, h: 0.005, x: 0.0148, y: 0.0618, z: rs, rz: HP, color: MET2, m: true, seg: 10 }
        ];
        // откидная мушка на передней планке: основание, «уши», мушка-штырёк
        const fs = -0.372;
        const frontSight = [
          mbox(0.024, 0.007, 0.026, 0, 0.0565, fs, BLK),
          mprof([[0.36, 0.059], [0.384, 0.059], [0.381, 0.067], [0.374, 0.067], ['q', 0.372, 0.083, 0.369, 0.083], [0.364, 0.083], [0.362, 0.068]], 0.0035, BLK, { x: 0.0078, bevel: 0.0008, bseg: 1 }),
          mprof([[0.36, 0.059], [0.384, 0.059], [0.381, 0.067], [0.374, 0.067], ['q', 0.372, 0.083, 0.369, 0.083], [0.364, 0.083], [0.362, 0.068]], 0.0035, BLK, { x: -0.0078, bevel: 0.0008, bseg: 1 }),
          mprof([[0.363, 0.059], [0.377, 0.059], [0.372, 0.066], [0.366, 0.066]], 0.012, BLK, { bevel: 0.001 }),
          mbox(0.0028, 0.016, 0.0028, 0, 0.073, fs + 0.0015, MET2)
        ];
        // изогнутый магазин STANAG: корпус, рёбра жёсткости вдоль изгиба, крышка, патрон сверху
        const magCurve = (a, b, y0, y1) => [[a, y0], [b, y0], ['q', b + 0.003, (y0 + y1) / 2 - 0.006, b + 0.021, y1], [a + 0.021 + (a > 0.045 ? 0.002 : 0), y1 - 0.004], ['q', a + 0.003, (y0 + y1) / 2 - 0.006, a, y0]];
        return {
          body: [
            // верхняя коробка: нижний широкий пояс и узкая верхняя часть со ступенькой под планкой
            prof([[-0.158, 0.004], [0.142, 0.004], [0.142, 0.034], [-0.158, 0.034]], 0.044, AC, 'a', { bevel: 0.003 }),
            prof([[-0.156, 0.03], [0.142, 0.03], [0.142, 0.0435], [-0.15, 0.0435], ['q', -0.156, 0.0435, -0.156, 0.038]], 0.034, AC, 'a', { bevel: 0.0025 }),
            ...pic(-0.152, 0.14, 0.0466, 0.024),
            // окно экстракции, открытая пылезащитная крышка на шарнире, отражатель гильз
            box(0.0012, 0.0165, 0.056, 0.0222, 0.0235, -0.03, '#08090a'),
            mbox(0.0016, 0.017, 0.058, 0.0258, 0.0076, -0.03, MET, 0, 0, 0.42), { cyl: true, r: 0.0016, h: 0.062, x: 0.0226, y: 0.015, z: -0.03, rx: HP, color: MET2, m: true, seg: 8 },
            mbox(0.002, 0.0024, 0.03, 0.0274, 0.0083, -0.03, MET2, 0, 0, 0.42),
            mprof([[-0.017, 0.022], [-0.002, 0.022], [-0.002, 0.041], ['q', -0.012, 0.041, -0.017, 0.031]], 0.007, BLK, { x: 0.0235, bevel: 0.0012, bseg: 1, cs: 3 }),
            // досылатель: прилив, корпус-цилиндр и кнопка с проточками
            mprof([[-0.112, 0.016], [-0.058, 0.016], ['q', -0.064, 0.04, -0.09, 0.04], [-0.112, 0.04]], 0.008, BLK, { x: 0.0225, bevel: 0.002, bseg: 1, cs: 3 }),
            { cyl: true, r: 0.0074, r2: 0.0068, h: 0.034, x: 0.0272, y: 0.0292, z: 0.094, rx: HP, color: BLK, m: true, seg: 12 },
            { cyl: true, r: 0.0063, h: 0.008, x: 0.0272, y: 0.0292, z: 0.114, rx: HP, color: MET2, m: true, seg: 12 },
            { cyl: true, r: 0.0065, h: 0.0012, x: 0.0272, y: 0.0292, z: 0.112, rx: HP, color: GRV, m: true, seg: 12, open: true },
            { cyl: true, r: 0.0065, h: 0.0012, x: 0.0272, y: 0.0292, z: 0.1155, rx: HP, color: GRV, m: true, seg: 12, open: true },
            // рукоять заряжания: шток, Т-образная ручка, защёлка слева
            mbox(0.014, 0.0065, 0.026, 0, 0.0395, 0.168, BLK),
            mprof([[-0.188, 0.034], [-0.176, 0.034], [-0.174, 0.043], [-0.186, 0.043]], 0.046, BLK, { bevel: 0.0015 }),
            mprof([[-0.19, 0.035], [-0.178, 0.035], [-0.176, 0.042], ['q', -0.188, 0.044, -0.191, 0.04]], 0.012, MET2, { x: -0.028, bevel: 0.0012, bseg: 1, cs: 3 }),
            // нижняя коробка: задний прилив, приёмник магазина с раструбом и защитным «забором» кнопки
            prof([[-0.162, 0.004], ['q', -0.166, -0.03, -0.14, -0.038], [-0.064, -0.038], [-0.05, -0.034], [0.1, -0.034], [0.106, -0.02], [0.106, 0.004]], 0.046, AC, 'a', { bevel: 0.003 }),
            prof([[0.022, -0.034], [0.106, -0.034], [0.11, -0.08], ['q', 0.118, -0.086, 0.116, -0.094], [0.03, -0.094], ['q', 0.022, -0.09, 0.026, -0.08]], 0.042, AC, 'a', { bevel: 0.003 }),
            mprof([[0.02, -0.024], [0.044, -0.024], [0.046, -0.012], [0.02, -0.006]], 0.05, BLK, { bevel: 0.0015 }),
            pinX(0.097, -0.006, 0.0036), pinX(-0.134, -0.008, 0.0036),
            // переводчик огня (слева, с осью справа), затворная задержка (слева), кнопка магазина (справа)
            mprof([[-0.064, -0.01], [-0.034, -0.016], [-0.032, -0.011], [-0.06, -0.004]], 0.003, MET2, { x: -0.0246, bevel: 0.0008 }),
            { cyl: true, r: 0.0055, h: 0.003, x: -0.0246, y: -0.0085, z: 0.062, rz: HP, color: MET2, m: true, seg: 10 },
            { cyl: true, r: 0.004, h: 0.003, x: 0.0246, y: -0.0085, z: 0.062, rz: HP, color: MET2, m: true, seg: 8 },
            mprof([[-0.004, -0.016], [0.017, -0.016], [0.017, -0.003], ['q', 0.002, -0.002, -0.004, -0.008]], 0.003, BLK, { x: -0.0244, bevel: 0.0008, bseg: 1, cs: 3 }),
            mbox(0.003, 0.0012, 0.012, -0.026, -0.009, -0.007, GRV),
            { cyl: true, r: 0.0052, h: 0.004, x: 0.0254, y: -0.019, z: -0.034, rz: HP, color: MET2, m: true, seg: 12 },
            // спусковая скоба, крючок
            Object.assign(loop([[-0.044, -0.034], [0.03, -0.034], [0.028, -0.07], [-0.036, -0.073], ['q', -0.046, -0.06, -0.044, -0.034]],
              [[-0.036, -0.041], [0.022, -0.041], [0.021, -0.064], [-0.031, -0.066], ['q', -0.037, -0.056, -0.036, -0.041]], 0.011, BLK, null, true), { bseg: 1 }),
            trig(-0.006, -0.036, MET2),
            // пистолетная рукоять A2: упор под средний палец, «хвост» сверху
            prof([[-0.088, -0.034], [-0.046, -0.034], ['q', -0.048, -0.056, -0.054, -0.07], ['q', -0.066, -0.08, -0.06, -0.092], ['q', -0.062, -0.122, -0.072, -0.146],
              ['q', -0.09, -0.152, -0.11, -0.142], ['q', -0.1, -0.09, -0.094, -0.052], ['q', -0.097, -0.04, -0.088, -0.034]], 0.033, PC, 'b', { bevel: 0.005, cs: 4, bseg: 1 }),
            box(0.0464, 0.0011, 0.262, 0, 0.0042, 0.027, GRV),
            // дельта-кольцо и гайка ствола
            cylZ(0.0288, 0.142, 0.156, BLK, { seg: 18 }),
            cylZ(0.0294, 0.1445, 0.147, MET2, { seg: 18 }),
            // круглое цевьё с вентиляционными окнами, торцевое кольцо
            cylZ(HR, 0.156, 0.392, PC, { seg: 16, m: false, skin: 'b', r2: 0.0262 }),
            cylZ(0.0272, 0.39, 0.398, BLK, { seg: 16 }),
            ...[0.19, 0.222, 0.254, 0.286].flatMap(f => VA0.map(a => vent(f, a, 0.022))),
            ...pic(0.158, 0.392, 0.0466, 0.022),
            ...sideRail(1), ...sideRail(-1),
            // ствол, пламегаситель-переходник и глушитель: муфта с насечкой, конус, корпус, пояски, торец с фаской
            cylZ(0.0094, 0.398, 0.44, MET), cylZ(0.0122, 0.412, 0.436, MET2, { seg: 8 }),
            cylZ(0.0168, 0.434, 0.452, MET2, { seg: 18 }),
            ...[0.438, 0.443, 0.448].map(f => cylZ(0.017, f, f + 0.0016, GRV, { seg: 18, open: true })),
            cylZ(0.0168, 0.452, 0.466, SC, { r2: 0.0192, seg: 20, m: false, skin: 'b' }),
            cylZ(0.0192, 0.466, 0.718, SC, { seg: 20, m: false, skin: 'b' }),
            ...[0.476, 0.484, 0.702].map(f => cylZ(0.0195, f, f + 0.0024, '#141518', { seg: 20, open: true })),
            cylZ(0.0192, 0.718, 0.726, MET2, { seg: 20 }), cylZ(0.0192, 0.726, 0.732, MET2, { r2: 0.0162, seg: 20 }),
            { cyl: true, r: 0.0085, h: 0.0012, x: 0, y: BY, z: -0.7322, rx: HP, color: '#1a1b1d', seg: 14 },
            { cyl: true, r: 0.0046, h: 0.0014, x: 0, y: BY, z: -0.7326, rx: HP, color: '#030303', seg: 10 },
            // откидные прицельные приспособления
            ...rearSight, ...frontSight,
            // буферная трубка с гайкой-«замком» и упорной пластиной
            tube(0.0152, -0.34, -0.16, 0.02, BLK, 0, null, 14), tube(0.0165, -0.174, -0.164, 0.02, MET2, 0, null, 12),
            ...[0, 1, 2, 3].map(i => { const a = i * HP + Math.PI / 4; return box(0.003, 0.003, 0.0102, Math.cos(a) * 0.0165, 0.02 + Math.sin(a) * 0.0165, 0.169, GRV, 0, 0, a); }),
            mprof([[-0.164, -0.004], [-0.16, -0.004], [-0.16, 0.042], [-0.164, 0.042]], 0.034, BLK, { bevel: 0.001 }),
            // приклад «крейн»: корпус с гребнем под щёку, боковые трубки, отверстие под ремень, затыльник с рёбрами
            prof([[-0.246, 0.034], ['q', -0.25, 0.048, -0.264, 0.048], [-0.372, 0.051], ['q', -0.388, 0.052, -0.388, 0.042], [-0.388, -0.058], ['q', -0.387, -0.066, -0.376, -0.065],
              [-0.3, -0.026], ['q', -0.268, -0.012, -0.254, -0.008], ['q', -0.246, -0.004, -0.246, 0.006]], 0.036, PC, 'b',
              { bevel: 0.0045, cs: 4, bseg: 1, holes: [[[-0.302, -0.012], [-0.358, -0.012], [-0.358, -0.044], ['q', -0.33, -0.034, -0.302, -0.02]]] }),
            ...[1, -1].map(s => Object.assign(tube(0.0098, -0.37, -0.258, 0.006, PC, s * 0.0152, null, 12, true), { skin: 'b' })),
            ...[1, -1].map(s => tube(0.0066, -0.375, -0.37, 0.006, BLK, s * 0.0152, 0.0098, 12, true)),
            prof([[-0.388, 0.05], [-0.4, 0.05], ['q', -0.402, 0.05, -0.402, 0.046], [-0.402, -0.062], ['q', -0.402, -0.07, -0.394, -0.07], [-0.388, -0.068]], 0.042, '#121315', null, { bevel: 0.003 }),
            ...[0.03, 0.012, -0.006, -0.024, -0.042].map(y => box(0.043, 0.0022, 0.0105, 0, y, 0.396, '#0a0b0c')),
            mprof([[-0.244, -0.002], [-0.264, -0.002], [-0.268, -0.011], [-0.25, -0.011]], 0.012, BLK, { bevel: 0.0015 }),
            Object.assign(swivel(-0.071, 0.384), { seg: 8 }), Object.assign(swivel(BY - 0.03, -0.36), { seg: 8 }), mbox(0.008, 0.006, 0.014, 0, BY - 0.0262, -0.36, BLK)
          ],
          // затворная рама в окне экстракции: дёргается при выстреле
          slide: [mbox(0.0016, 0.011, 0.032, 0.0226, 0.0235, -0.032, '#6b7178'), mbox(0.0012, 0.004, 0.012, 0.0232, 0.0235, -0.036, GRV)], slideK: 0.03,
          mag: [prof(magCurve(0.036, 0.1, -0.056, -0.176), 0.026, MET2, null, { bevel: 0.0025, bseg: 1, m: true, cs: 6 }),
            prof(magCurve(0.046, 0.058, -0.064, -0.17), 0.0285, MET, null, { bevel: 0, m: true, cs: 6 }),
            prof(magCurve(0.08, 0.09, -0.064, -0.17), 0.0285, MET, null, { bevel: 0, m: true, cs: 6 }),
            mprof([[0.054, -0.178], [0.124, -0.173], [0.126, -0.183], [0.054, -0.189]], 0.031, BLK, { bevel: 0.0015, bseg: 1 }),
            { cyl: true, r: 0.0046, h: 0.04, x: 0, y: -0.052, z: -0.072, rx: HP, color: BR, m: true, seg: 10 },
            { cyl: true, r: 0.0046, r2: 0.0012, h: 0.014, x: 0, y: -0.052, z: -0.099, rx: HP, color: '#a8683a', m: true, seg: 10 }],
          muzzle: [0, BY, -0.734], rh: [0, -0.088, 0.075], lh: [0, -0.008, -0.3], charge: [-0.02, -0.03, -0.015]
        };
      }
      case 'smg': return {
        body: [
          prof([[-0.14, -0.03], [0.12, -0.03], ['q', 0.162, -0.03, 0.166, 0.005], [0.166, 0.044], [-0.09, 0.052], ['q', -0.14, 0.05, -0.14, 0.02]], 0.056, BLK, 'a', { bevel: 0.005 }),
          ...rail(-0.09, 0.1, 0.057, 0, 0.028),
          mbox(0.006, 0.01, 0.12, 0.031, 0.01, -0.06, BLK), mbox(0.006, 0.01, 0.12, -0.031, 0.01, -0.06, BLK),
          mbox(0.003, 0.016, 0.05, 0.0295, 0.026, 0.0, '#0d0e10'), mbox(0.002, 0.008, 0.03, 0.0302, 0.026, 0.0, MET),
          mbox(0.03, 0.01, 0.016, 0, 0.048, 0.128, BLK), mbox(0.044, 0.008, 0.01, 0, 0.048, 0.134, BLK),
          { cyl: true, r: 0.007, h: 0.004, x: 0.031, y: 0.0, z: 0.03, rz: HP, color: MET2, m: true }, mbox(0.003, 0.004, 0.022, 0.0335, 0.0, 0.022, MET2),
          ...[[-0.1, 0.03], [-0.1, -0.015], [0.1, 0.03], [0.1, -0.015]].flatMap(([f, y]) => [rivet(0.0305, y, -f), rivet(-0.0305, y, -f)]),
          tube(0.018, 0.166, 0.235, 0.016, POLY, 0, null, 12, true), tube(0.009, 0.235, 0.262, 0.016), tube(0.015, 0.262, 0.31, 0.016, BLK, 0, 0.013),
          ...[0.27, 0.285, 0.3].map(f => mbox(0.03, 0.004, 0.005, 0, 0.026, -f, '#0d0e10')),
          prof([[0.09, -0.03], [0.125, -0.03], ['q', 0.126, -0.07, 0.12, -0.112], [0.098, -0.112], ['q', 0.092, -0.07, 0.09, -0.03]], 0.03, POLY, 'b', { bevel: 0.004 }),
          ...[-0.05, -0.068, -0.086].map(y => box(0.04, 0.004, 0.036, 0, y, -0.109, '#141517')),
          prof([[-0.07, -0.03], [-0.028, -0.03], ['q', -0.03, -0.08, -0.04, -0.135], [-0.084, -0.13], ['q', -0.078, -0.08, -0.07, -0.03]], 0.036, POLY, 'b', { bevel: 0.005 }),
          loop([[-0.03, -0.03], [0.03, -0.03], [0.028, -0.06], [-0.025, -0.064]], [[-0.024, -0.036], [0.022, -0.036], [0.02, -0.054], [-0.02, -0.057]], 0.01, BLK),
          trig(-0.006, -0.034, BLK),
          mbox(0.007, 0.012, 0.22, 0.022, -0.005, 0.24, MET2), mbox(0.007, 0.012, 0.22, -0.022, -0.005, 0.24, MET2),
          prof([[-0.37, -0.065], [-0.345, -0.065], [-0.345, 0.032], [-0.37, 0.032]], 0.06, POLY, 'b'), box(0.064, 0.09, 0.006, 0, -0.016, 0.372, '#141517'),
          mprof([[0.13, 0.057], [0.15, 0.057], [0.146, 0.082], [0.136, 0.082]], 0.014, BLK), { torus: true, r: 0.011, tube: 0.0022, x: 0, y: 0.078, z: -0.14, color: BLK, m: true, seg: 14 },
          mprof([[-0.08, 0.057], [-0.05, 0.057], [-0.054, 0.078], [-0.076, 0.078]], 0.02, BLK), { torus: true, r: 0.006, tube: 0.002, x: 0, y: 0.074, z: 0.065, color: BLK, m: true, seg: 12 },
          swivel(-0.02, 0.12)
        ],
        slide: [{ cyl: true, r: 0.007, h: 0.03, x: 0.034, y: 0.025, z: -0.05, rz: HP, color: MET2, m: true }],
        mag: [prof([[-0.064, -0.11], [-0.04, -0.11], [-0.038, -0.148], [-0.086, -0.142], [-0.084, -0.11]], 0.034, MET2, null, { m: true }),
          mbox(0.04, 0.009, 0.052, 0, -0.15, 0.062, BLK, 0.06), mbox(0.024, 0.04, 0.034, 0, -0.08, 0.062, MET2)],
        muzzle: [0, 0.016, -0.33], rh: [0, -0.08, 0.045], lh: [0, -0.035, -0.11], charge: [0.028, 0.03, -0.046]
      };
      case 'sniper': return {
        body: [
          prof([[-0.5, -0.115], ['q', -0.5, 0.0, -0.47, 0.034], [-0.16, 0.038], [0.05, 0.03], [0.38, 0.022], ['q', 0.39, 0.0, 0.38, -0.035], [0.05, -0.045], [-0.05, -0.062],
            ['q', -0.08, -0.1, -0.1, -0.128], [-0.168, -0.128], ['q', -0.2, -0.1, -0.225, -0.064], [-0.4, -0.076], ['q', -0.44, -0.1, -0.462, -0.125]], 0.06, OLIVE, 'a',
            { bevel: 0.006, holes: [[[-0.205, -0.032], [-0.13, -0.036], ['q', -0.112, -0.06, -0.122, -0.08], [-0.162, -0.1], ['q', -0.2, -0.09, -0.205, -0.032]]] }),
          prof([[-0.44, 0.03], [-0.25, 0.042], [-0.24, 0.06], [-0.43, 0.058]], 0.044, OLIVE, 'a', { bevel: 0.006 }),
          { cyl: true, r: 0.007, h: 0.012, x: 0.03, y: 0.045, z: 0.34, rz: HP, color: BLK, m: true },
          box(0.064, 0.136, 0.016, 0, -0.042, 0.49, BLK), ...[0.06, 0.03, 0.0, -0.03, -0.06, -0.09].map(y => box(0.066, 0.003, 0.003, 0, y, 0.499, '#2a2b2d')),
          ...ser(5, -0.33, 0.012, -0.03, 0.05, 0.062, '#3a4430'),
          tube(0.023, -0.12, 0.12, 0.045), tube(0.0135, 0.12, 0.8, 0.045, MET, 0, 0.011),
          ...[0, 1, 2, 3].map(i => mbox(0.003, 0.003, 0.5, Math.cos(i * HP + 0.78) * 0.0125, 0.045 + Math.sin(i * HP + 0.78) * 0.0125, -0.45, '#121314')),
          tube(0.02, 0.79, 0.87, 0.045, BLK, 0, 0.018), mbox(0.044, 0.008, 0.02, 0, 0.045, -0.81, '#0d0e10'), mbox(0.044, 0.008, 0.02, 0, 0.045, -0.845, '#0d0e10'), tube(0.0205, 0.865, 0.872, 0.045, MET2),
          // прицел: трубка, барабанчики с насечкой, наглазник, бленда
          tube(0.021, -0.1, 0.17, 0.112, BLK), tube(0.023, 0.17, 0.26, 0.112, BLK, 0, 0.034), tube(0.028, -0.18, -0.1, 0.112, BLK, 0, 0.021),
          tube(0.03, -0.205, -0.18, 0.112, '#121212', 0, null, 18, true), tube(0.0355, 0.26, 0.29, 0.112, BLK),
          { cyl: true, r: 0.0285, h: 0.004, x: 0, y: 0.112, z: -0.196, rx: HP, color: '#2a7fb0', g: true, seg: 18 },
          { cyl: true, r: 0.026, h: 0.003, x: 0, y: 0.112, z: 0.2915, rx: HP, color: '#3a8fc0', g: true, seg: 18 },
          { torus: true, r: 0.031, tube: 0.0045, x: 0, y: 0.112, z: 0.29, color: '#151617', seg: 18 },
          { cyl: true, r: 0.013, h: 0.03, x: 0, y: 0.142, z: -0.04, color: BLK, m: true }, { cyl: true, r: 0.012, h: 0.03, x: 0.032, y: 0.112, z: -0.04, rz: HP, color: BLK, m: true },
          ...[0.152, 0.138].map(y => ({ torus: true, r: 0.0132, tube: 0.0017, x: 0, y, z: -0.04, rx: HP, color: '#2a2c2f', m: true, seg: 14 })),
          ...[0.042, 0.028].map(x => ({ torus: true, r: 0.0122, tube: 0.0016, x, y: 0.112, z: -0.04, ry: HP, color: '#2a2c2f', m: true, seg: 14 })),
          { cyl: true, r: 0.009, h: 0.02, x: -0.03, y: 0.112, z: -0.01, rz: HP, color: BLK, m: true },
          ...[0.06, -0.14].flatMap(z => [{ torus: true, r: 0.024, tube: 0.005, x: 0, y: 0.112, z, color: BLK, m: true, seg: 14 }, mbox(0.016, 0.044, 0.02, 0, 0.078, z, BLK), rivet(0.013, 0.09, z, MET2), rivet(-0.013, 0.09, z, MET2)]),
          loop([[-0.12, -0.04], [-0.04, -0.044], [-0.045, -0.08], [-0.11, -0.08]], [[-0.11, -0.047], [-0.05, -0.05], [-0.054, -0.072], [-0.1, -0.072]], 0.01, BLK, null, true),
          trig(-0.07, -0.046, MET),
          tube(0.005, 0.15, 0.38, -0.045, BLK, 0.014), tube(0.005, 0.15, 0.38, -0.045, BLK, -0.014), mbox(0.042, 0.014, 0.026, 0, -0.046, -0.39, BLK),
          { sph: true, r: 0.007, x: 0.014, y: -0.045, z: -0.15, color: '#151515', seg: 8 }, { sph: true, r: 0.007, x: -0.014, y: -0.045, z: -0.15, color: '#151515', seg: 8 },
          swivel(-0.05, -0.33), swivel(-0.11, 0.42)
        ],
        bolt: [{ cyl: true, r: 0.005, h: 0.065, x: 0.045, y: 0.0, z: 0.0, rz: HP, color: MET2, m: true }, { sph: true, r: 0.012, x: 0.08, y: 0.0, z: 0.0, color: BLK, m: true }, tube(0.0125, -0.02, 0.04, 0, MET2)],
        boltPos: [0, 0.045, 0.06],
        mag: [mprof([[-0.02, -0.045], [0.06, -0.045], [0.06, -0.09], [-0.02, -0.09]], 0.04, MET2), mbox(0.046, 0.008, 0.084, 0, -0.093, -0.02, BLK)],
        muzzle: [0, 0.045, -0.88], rh: [0, -0.09, 0.145], lh: [0, -0.045, -0.26]
      };
      case 'shotgun': return {
        body: [
          prof([[-0.12, -0.04], [0.14, -0.04], [0.14, 0.036], ['q', 0.13, 0.048, 0.1, 0.048], [-0.1, 0.048], ['q', -0.12, 0.046, -0.12, 0.03]], 0.054, MET, 'a', { bevel: 0.004 }),
          mbox(0.003, 0.02, 0.07, 0.0275, 0.012, -0.05, '#0d0e10'), mbox(0.03, 0.003, 0.08, 0, -0.0405, -0.04, '#0d0e10'),
          ...[[-0.08, 0.03], [0.1, 0.03], [-0.08, -0.025], [0.1, -0.025]].flatMap(([f, y]) => [rivet(0.0285, y, -f), rivet(-0.0285, y, -f)]),
          // патронташ на левом борту
          mbox(0.004, 0.044, 0.12, -0.031, -0.004, -0.01, BLK),
          ...[-0.04, -0.013, 0.014, 0.041].flatMap(f => [{ cyl: true, r: 0.0105, h: 0.046, x: -0.042, y: -0.0, z: -f, color: '#b02a1e', seg: 12 },
            { cyl: true, r: 0.0108, h: 0.012, x: -0.042, y: -0.027, z: -f, color: '#c9a23a', m: true, seg: 12 }]),
          tube(0.015, 0.14, 0.68, 0.024), tube(0.013, 0.14, 0.6, -0.017, MET2), tube(0.015, 0.59, 0.612, -0.017), tube(0.0155, 0.612, 0.618, -0.017, MET2),
          // перфорированный кожух ствола
          mbox(0.034, 0.004, 0.36, 0, 0.044, -0.33, BLK), mbox(0.004, 0.014, 0.36, 0.016, 0.036, -0.33, BLK), mbox(0.004, 0.014, 0.36, -0.016, 0.036, -0.33, BLK),
          ...[0.19, 0.23, 0.27, 0.31, 0.35, 0.39, 0.43, 0.47].map(f => box(0.016, 0.005, 0.02, 0, 0.045, -f, '#08090a')),
          mbox(0.034, 0.054, 0.014, 0, 0.004, -0.6, MET2),
          { sph: true, r: 0.005, x: 0, y: 0.043, z: -0.67, color: STEEL, seg: 6, m: true },
          prof([[-0.12, 0.03], ['q', -0.15, 0.026, -0.19, -0.004], [-0.43, -0.03], [-0.45, -0.032], [-0.45, -0.112], [-0.43, -0.112], [-0.2, -0.07], ['q', -0.14, -0.06, -0.12, -0.042]], 0.048, WOOD, 'b', { bevel: 0.006 }),
          box(0.052, 0.086, 0.018, 0, -0.072, 0.458, BLK), ...[-0.04, -0.06, -0.08, -0.1].map(y => box(0.054, 0.003, 0.004, 0, y, 0.468, '#2a2b2d')),
          loop([[-0.07, -0.038], [0.0, -0.038], ['q', 0.0, -0.07, -0.02, -0.074], [-0.065, -0.074]], [[-0.062, -0.045], [-0.008, -0.045], ['q', -0.008, -0.064, -0.024, -0.066], [-0.058, -0.066]], 0.01, MET, null, true),
          trig(-0.03, -0.04), { cyl: true, r: 0.004, h: 0.062, x: 0, y: -0.036, z: 0.055, rz: HP, color: '#a8261c', seg: 8 },
          mbox(0.04, 0.008, 0.08, 0, 0.052, 0.0, MET2), swivel(-0.034, -0.6), swivel(-0.1, 0.36)
        ],
        pump: [prof([[0.24, -0.042], ['q', 0.24, -0.05, 0.25, -0.05], [0.41, -0.05], ['q', 0.42, -0.05, 0.42, -0.04], [0.42, 0.006], [0.24, 0.006]], 0.064, WOOD, 'b', { bevel: 0.008 }),
          ...[0.262, 0.284, 0.306, 0.328, 0.35, 0.372, 0.394].flatMap(f => [box(0.004, 0.044, 0.007, 0.034, -0.021, -f, '#3a2414'), box(0.004, 0.044, 0.007, -0.034, -0.021, -f, '#3a2414')])],
        shell: [{ cyl: true, r: 0.0105, h: 0.05, x: 0, y: 0, z: 0, rx: HP, color: '#b02a1e', seg: 12 }, { cyl: true, r: 0.0108, h: 0.012, x: 0, y: 0, z: 0.026, rx: HP, color: '#c9a23a', m: true, seg: 12 }],
        mag: [], muzzle: [0, 0.024, -0.7], rh: [0, -0.075, 0.15], lh: [0, -0.05, -0.33]
      };
      case 'pistol': return {
        body: [
          prof([[-0.065, -0.003], [0.1, -0.003], [0.1, -0.02], [0.06, -0.022], [0.02, -0.028], [-0.02, -0.028], [-0.05, -0.025]], 0.028, POLY, 'b'),
          ...[0.065, 0.078, 0.091].map(f => box(0.03, 0.004, 0.006, 0, -0.022, -f, '#101012')),
          loop([[-0.008, -0.02], [0.045, -0.02], ['q', 0.046, -0.052, 0.035, -0.052], [-0.012, -0.054]], [[-0.002, -0.026], [0.037, -0.026], ['q', 0.038, -0.046, 0.03, -0.046], [-0.006, -0.048]], 0.012, POLY, 'b'),
          prof([[-0.066, -0.02], [-0.022, -0.025], ['q', -0.03, -0.045, -0.024, -0.06], ['q', -0.034, -0.075, -0.028, -0.09], ['q', -0.04, -0.105, -0.034, -0.122], [-0.084, -0.116], ['q', -0.074, -0.06, -0.066, -0.02]], 0.03, POLY, 'b', { bevel: 0.004 }),
          // точечная фактура рукояти
          ...[0, 1, 2, 3, 4, 5].flatMap(i => [0, 1, 2, 3].flatMap(j => [1, -1].map(sx => box(0.0012, 0.0035, 0.0035, sx * 0.0186, -0.048 - i * 0.011, 0.04 + j * 0.0085 + i * 0.002, '#1c1d20')))),
          trig(0.012, -0.022, BLK), mbox(0.002, 0.012, 0.003, 0, -0.032, -0.006, MET2, 0.25),
          mbox(0.0035, 0.005, 0.022, -0.0158, -0.006, -0.022, MET2), mbox(0.0035, 0.008, 0.006, 0.0158, -0.012, -0.044, MET2), mbox(0.0035, 0.008, 0.006, -0.0158, -0.012, -0.044, MET2),
          { cyl: true, r: 0.0065, h: 0.02, x: 0, y: 0.018, z: -0.098, rx: HP, color: MET, m: true }
        ],
        slide: [
          prof([[-0.075, 0.0], [0.1, 0.0], ['q', 0.106, 0.0, 0.106, 0.008], [0.106, 0.03], ['q', 0.106, 0.036, 0.1, 0.036], [-0.068, 0.037], ['q', -0.075, 0.037, -0.075, 0.03]], 0.031, BLK, 'a', { bevel: 0.003 }),
          ...ser(5, -0.064, 0.008, 0.018, 0.026, 0.0325, '#0c0c0e'), ...ser(3, 0.072, 0.008, 0.02, 0.022, 0.0325, '#0c0c0e'),
          mbox(0.002, 0.008, 0.03, 0.0165, 0.03, -0.018, '#0a0a0b'), mbox(0.014, 0.002, 0.032, 0.004, 0.0385, -0.018, '#0d0e10'), mbox(0.012, 0.002, 0.028, 0.004, 0.0382, -0.018, '#b8a06a'),
          mbox(0.002, 0.004, 0.016, 0.0165, 0.03, -0.004, MET2),
          mbox(0.004, 0.009, 0.006, 0, 0.042, -0.092, MET2), dot(0, 0.044, -0.0885, '#e8ffe8'),
          mbox(0.022, 0.009, 0.008, 0, 0.042, 0.06, MET2), dot(0.0072, 0.0435, 0.0642, '#e8ffe8'), dot(-0.0072, 0.0435, 0.0642, '#e8ffe8')
        ],
        mag: [mbox(0.034, 0.008, 0.05, 0, -0.123, 0.06, BLK, -0.22), mbox(0.022, 0.085, 0.036, 0, -0.08, 0.053, MET2, -0.22)],
        muzzle: [0, 0.02, -0.115], rh: [0, -0.062, 0.05], lh: [-0.035, -0.078, 0.045]
      };
      case 'usp': return {
        body: [
          prof([[-0.07, -0.004], [0.1, -0.004], [0.1, -0.022], [0.06, -0.024], [0.02, -0.03], [-0.024, -0.03], [-0.056, -0.026]], 0.029, POLY, 'b'),
          mbox(0.024, 0.006, 0.034, 0, -0.026, -0.08, POLY), ...[0.07, 0.082, 0.094].map(f => box(0.026, 0.003, 0.004, 0, -0.03, -f, '#0f1012')),
          loop([[-0.008, -0.022], [0.052, -0.022], [0.056, -0.03], [0.05, -0.058], [-0.012, -0.058]], [[-0.002, -0.028], [0.044, -0.028], [0.043, -0.051], [-0.006, -0.052]], 0.012, POLY, 'b'),
          prof([[-0.07, -0.022], [-0.024, -0.028], ['q', -0.03, -0.07, -0.036, -0.124], [-0.088, -0.12], ['q', -0.08, -0.07, -0.07, -0.022]], 0.031, POLY, 'b', { bevel: 0.004 }),
          ...[1, -1].map(sx => box(0.002, 0.058, 0.03, sx * 0.0186, -0.076, 0.057, '#17181a', -0.2)),
          ...[0, 1, 2, 3].flatMap(i => [1, -1].map(sx => box(0.0024, 0.0016, 0.028, sx * 0.0188, -0.056 - i * 0.013, 0.053 + i * 0.0027, '#2a2c30', -0.2))),
          trig(0.012, -0.024, BLK),
          mprof([[-0.084, 0.0], [-0.072, 0.0], [-0.074, 0.022], ['q', -0.08, 0.026, -0.088, 0.02]], 0.008, BLK),
          mbox(0.004, 0.012, 0.022, -0.0172, 0.002, 0.058, MET2), mbox(0.004, 0.006, 0.01, -0.0172, 0.01, 0.07, MET2),
          mbox(0.0035, 0.005, 0.03, -0.0158, -0.008, -0.012, MET2),
          // ствол с резьбой и глушитель
          tube(0.0068, 0.1, 0.122, 0.018, MET), ...[0.104, 0.11, 0.116].map(f => ({ torus: true, r: 0.0068, tube: 0.0012, x: 0, y: 0.018, z: -f, color: MET2, m: true, seg: 10 })),
          tube(0.0148, 0.12, 0.272, 0.018, BLK, 0, null, 20), tube(0.0152, 0.12, 0.132, 0.018, MET2, 0, null, 20), tube(0.0152, 0.26, 0.274, 0.018, MET2, 0, null, 20),
          ...[0.14, 0.146, 0.152].map(f => ({ torus: true, r: 0.0149, tube: 0.0012, x: 0, y: 0.018, z: -f, color: '#26282b', m: true, seg: 18 })),
          { cyl: true, r: 0.0042, h: 0.004, x: 0, y: 0.018, z: -0.2745, rx: HP, color: '#050505', seg: 10 }
        ],
        slide: [
          prof([[-0.076, 0.0], [0.098, 0.0], ['q', 0.104, 0.0, 0.104, 0.008], [0.104, 0.026], ['q', 0.102, 0.036, 0.094, 0.037], [-0.07, 0.038], ['q', -0.076, 0.038, -0.076, 0.03]], 0.03, BLK, 'a', { bevel: 0.003 }),
          ...ser(7, -0.068, 0.006, 0.018, 0.026, 0.0315, '#0c0c0e'),
          mbox(0.0315, 0.006, 0.17, 0, 0.004, -0.014, '#16171a'),
          mbox(0.014, 0.002, 0.03, 0.004, 0.0392, -0.02, '#0d0e10'), mbox(0.012, 0.002, 0.026, 0.004, 0.0389, -0.02, '#b8a06a'), mbox(0.002, 0.004, 0.016, 0.0158, 0.03, -0.006, MET2),
          mbox(0.004, 0.012, 0.007, 0, 0.044, -0.088, MET2), dot(0, 0.047, -0.0845, '#e8ffe8'),
          mbox(0.022, 0.012, 0.009, 0, 0.044, 0.062, MET2), dot(0.0072, 0.0465, 0.0668, '#e8ffe8'), dot(-0.0072, 0.0465, 0.0668, '#e8ffe8')
        ],
        mag: [mbox(0.034, 0.009, 0.052, 0, -0.126, 0.062, BLK, -0.18), mbox(0.022, 0.085, 0.036, 0, -0.082, 0.055, MET2, -0.18)],
        muzzle: [0, 0.018, -0.278], rh: [0, -0.062, 0.05], lh: [-0.035, -0.078, 0.045]
      };
      case 'magnum': return {
        body: [
          prof([[-0.085, -0.004], [0.13, -0.004], [0.13, -0.026], [0.03, -0.034], [-0.02, -0.034], [-0.06, -0.03]], 0.034, MET, 'b'),
          loop([[-0.012, -0.024], [0.05, -0.024], ['q', 0.05, -0.06, 0.035, -0.06], [-0.016, -0.062]], [[-0.005, -0.03], [0.042, -0.03], ['q', 0.042, -0.054, 0.03, -0.054], [-0.01, -0.056]], 0.012, MET, 'b'),
          prof([[-0.084, -0.022], [-0.026, -0.03], ['q', -0.032, -0.08, -0.042, -0.135], [-0.1, -0.128], ['q', -0.09, -0.07, -0.084, -0.022]], 0.036, POLY, null, { bevel: 0.006 }),
          ...[-0.05, -0.07, -0.09, -0.11].map(y => box(0.038, 0.004, 0.03, 0, y, 0.062 - (y + 0.05) * 0.2, '#101012')),
          ...[1, -1].map(sx => rivet(sx * 0.0215, -0.06, 0.066, MET)), ...[1, -1].map(sx => rivet(sx * 0.0215, -0.11, 0.078, MET)),
          mbox(0.012, 0.022, 0.014, 0, 0.044, 0.088, BLK),
          trig(0.012, -0.026), mbox(0.004, 0.012, 0.018, -0.0185, 0.004, 0.07, MET2), mbox(0.004, 0.006, 0.02, 0.0185, -0.012, -0.03, MET2)
        ],
        slide: [
          prof([[-0.09, 0.0], [0.17, 0.0], [0.17, 0.046], [0.0, 0.05], [-0.082, 0.05], ['q', -0.09, 0.05, -0.09, 0.04]], 0.038, STEEL, 'a', { bevel: 0.004 }),
          prof([[0.0, 0.05], [0.17, 0.046], [0.17, 0.056], ['q', 0.08, 0.062, 0.0, 0.062]], 0.014, STEEL, 'a', { bevel: 0.002 }),
          ...ser(4, -0.075, 0.009, 0.024, 0.03, 0.04, '#1a1a1a'),
          mbox(0.006, 0.01, 0.006, 0, 0.068, -0.16, BLK), dot(0, 0.0705, -0.1565, '#ffb030'),
          mbox(0.026, 0.01, 0.008, 0, 0.058, 0.075, BLK), dot(0.008, 0.06, 0.0795, '#e8ffe8'), dot(-0.008, 0.06, 0.0795, '#e8ffe8'),
          mbox(0.042, 0.008, 0.03, 0, 0.03, -0.15, '#151515'), ...[0.12, 0.13, 0.14].map(f => mbox(0.042, 0.006, 0.004, 0, 0.042, -f, '#151515')),
          mbox(0.002, 0.009, 0.036, 0.0195, 0.036, -0.02, '#0a0a0b')
        ],
        mag: [mbox(0.04, 0.01, 0.06, 0, -0.137, 0.072, BLK, -0.2), mbox(0.026, 0.09, 0.044, 0, -0.088, 0.064, MET2, -0.2)],
        muzzle: [0, 0.026, -0.18], rh: [0, -0.068, 0.06], lh: [-0.038, -0.084, 0.055]
      };
      case 'knife': return {
        body: [
          prof([[0, -0.014], [0.14, -0.012], ['q', 0.19, -0.008, 0.215, 0.006], ['q', 0.2, 0.012, 0.185, 0.019], [0.0, 0.019]], 0.0055, STEEL, 'a', { bevel: 0.0014 }),
          box(0.0025, 0.005, 0.15, 0.003, 0.009, -0.08, '#6b7177'), box(0.0025, 0.005, 0.15, -0.003, 0.009, -0.08, '#6b7177'),
          mprof([[-0.008, -0.03], [0.004, -0.03], [0.004, 0.034], [-0.008, 0.034]], 0.03, MET2, { bevel: 0.003 }),
          ...[0, 1, 2, 3, 4, 5].map(i => ({ torus: true, r: 0.0145, tube: 0.0048, x: 0, y: 0.003, z: 0.02 + i * 0.017, color: i % 2 ? '#4a3626' : '#5c4430', seg: 12 })),
          tube(0.0165, -0.125, -0.01, 0.003, '#523c2a', 0, 0.0165, 12, true),
          mprof([[-0.148, -0.02], [-0.125, -0.022], [-0.125, 0.028], [-0.148, 0.026]], 0.028, MET, { bevel: 0.004 })
        ],
        mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.004, 0.07], lh: null
      };
      case 'm9': {
        const blade = [[0, -0.017], [0.12, -0.017], ['q', 0.17, -0.014, 0.205, 0.008], [0.16, 0.021], [0.142, 0.024]];
        for (let f = 0.135; f > 0.045; f -= 0.01) blade.push([f, 0.032], [f - 0.005, 0.024]);
        blade.push([0.03, 0.027], [0, 0.027]);
        const ridges = [];
        for (let i = 0; i < 7; i++) ridges.push({ torus: true, r: 0.0175, tube: 0.0026, x: 0, y: 0.004, z: 0.03 + i * 0.014, color: '#1e2420', seg: 12 });
        return {
          body: [
            prof(blade, 0.006, STEEL, 'a', { bevel: 0.0015, cs: 6 }),
            box(0.0025, 0.005, 0.085, 0.0035, 0.006, -0.07, '#5f656b'), box(0.0025, 0.005, 0.085, -0.0035, 0.006, -0.07, '#5f656b'),
            mprof([[-0.01, -0.034], [0.006, -0.034], [0.006, 0.04], [-0.01, 0.04]], 0.03, MET, { bevel: 0.003 }),
            { torus: true, r: 0.016, tube: 0.0042, x: 0, y: 0.056, z: 0.002, color: MET, seg: 16, m: true },
            tube(0.0165, -0.13, -0.01, 0.004, '#283028', 0, 0.018, 12, true), ...ridges,
            loop([[-0.148, -0.024], [-0.128, -0.024], [-0.128, 0.03], [-0.148, 0.03]], [[-0.144, 0.012], [-0.132, 0.012], [-0.132, 0.024], [-0.144, 0.024]], 0.022, MET, null, true)
          ],
          mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.002, 0.07], lh: null
        };
      }
      case 'butterfly': {
        // балисонг: клинок и две рукояти вращаются на общей оси шарнира (y = PY, z = PZ);
        // рукоять симметрична относительно оси, поэтому закрытые рукояти ровно обнимают клинок с двух сторон
        const PY = 0.003, PZ = 0.004, PF = -PZ;
        const slot = (a, b) => [[a, -0.0035], ['q', a + 0.0065, PY, a, 0.0095], [b, 0.0095], ['q', b - 0.0065, PY, b, -0.0035]];
        return {
          body: [
            // клинок: скруглённый хвостовик вокруг шарнира, кикер, рикассо с выемкой, скос обуха к острию
            prof([[PF, -0.0088], ['q', -0.0158, -0.0088, -0.0158, PY], ['q', -0.0158, 0.0148, PF, 0.0148], [0.108, 0.0142], ['q', 0.14, 0.0134, 0.159, 0.0042],
              ['q', 0.142, -0.0068, 0.106, -0.0092], [0.027, -0.0092], ['q', 0.0222, -0.0036, 0.0165, -0.0092], [0.0125, -0.0102], [0.002, -0.0102]], 0.005, STEEL, 'a', { bevel: 0.0011, cs: 8 }),
            // заточенная кромка (голая сталь на любом скине) и долы вдоль обуха
            mbox(0.0054, 0.0034, 0.078, 0, -0.0071, -0.067, '#c3c9cf'),
            box(0.0016, 0.0026, 0.09, 0.0026, 0.0102, -0.064, '#6b7177'), box(0.0016, 0.0026, 0.09, -0.0026, 0.0102, -0.064, '#6b7177'),
            // упорный штифт хвостовика
            { cyl: true, r: 0.0016, h: 0.0054, x: 0, y: 0.0112, z: -0.006, rz: HP, color: STEEL, m: true, seg: 8 }
          ],
          pivot: [0, PY, PZ],
          handle: (side) => {
            const out = [prof([[0.0105, PY], ['q', 0.0105, 0.0175, PF, 0.0175], ['q', -0.08, 0.0163, -0.15, 0.0172], ['q', -0.158, 0.0172, -0.158, 0.009], [-0.158, -0.003],
              ['q', -0.158, -0.0112, -0.15, -0.0112], ['q', -0.08, -0.0102, PF, -0.0115], ['q', 0.0105, -0.0115, 0.0105, PY]], 0.0072, '#4a4f55', 'b',
            { bevel: 0.0014, bseg: 1, holes: [slot(-0.026, -0.05), slot(-0.057, -0.081), slot(-0.088, -0.112), slot(-0.119, -0.141)], x: side * 0.0064, cs: 4 }),
            // винт шарнира и винт у торца
            { cyl: true, r: 0.0042, h: 0.0016, x: side * 0.0108, y: PY, z: PZ, rz: HP, color: MET2, m: true, seg: 12 },
            { cyl: true, r: 0.0017, h: 0.0019, x: side * 0.0109, y: PY, z: PZ, rz: HP, color: '#121314', seg: 6 },
            { cyl: true, r: 0.0024, h: 0.0012, x: side * 0.0106, y: PY, z: 0.15, rz: HP, color: MET2, m: true, seg: 8 }];
            // защёлка на торце «кусачей» рукояти
            if (side < 0) out.push(mbox(0.004, 0.0034, 0.024, side * 0.0064, -0.0128, 0.142, MET2));
            return out;
          },
          mag: [], muzzle: [0, 0, -0.22], rh: [0, PY, 0.07], lh: null
        };
      }
      case 'karambit': {
        // кольцо — в начале координат, клинок-коготь уходит вперёд и вниз
        const ox = 0.108, k = 1.3;
        const off = (pts, sc) => pts.map(p => typeof p[0] === 'string' ? [p[0], ...p.slice(1).map((v, i) => i % 2 === 0 ? v * sc + ox : v * sc)] : [p[0] * sc + ox, p[1] * sc]);
        return {
          body: [
            prof(off([[0, 0.012], ['q', 0.07, 0.028, 0.125, -0.006], ['q', 0.152, -0.03, 0.158, -0.07], ['q', 0.13, -0.04, 0.092, -0.024], ['q', 0.045, -0.012, 0, -0.014]], k), 0.0055, STEEL, 'a', { bevel: 0.0014, cs: 8 }),
            box(0.002, 0.004, 0.09, 0.003, 0.006, -(ox + 0.06), '#6b7177', 0.18), box(0.002, 0.004, 0.09, -0.003, 0.006, -(ox + 0.06), '#6b7177', 0.18),
            prof(off([[-0.092, -0.012], ['q', -0.05, -0.017, 0.0, -0.014], [0.0, 0.014], ['q', -0.05, 0.017, -0.092, 0.012]], 1), 0.021, '#1d1f1c', null, { bevel: 0.004 }),
            ...[0.02, 0.042, 0.064].map(f => box(0.023, 0.005, 0.006, 0, -0.016, -(ox - f), '#2b2e2a')),
            { torus: true, r: 0.017, tube: 0.005, x: 0, y: 0, z: 0, ry: HP, color: MET, seg: 18, m: true },
            mbox(0.016, 0.01, 0.014, 0, 0, -0.018, MET), mbox(0.026, 0.03, 0.006, 0, 0, -(ox + 0.002), MET)
          ],
          mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.004, -(ox - 0.055)], lh: null, ring: [0, 0, 0]
        };
      }
      case 'tanto': {
        // клинок с изломом у острия, хабаки, цуба, рукоять с оплёткой и кашира
        const ridges = [];
        for (let i = 0; i < 7; i++) {
          const z = 0.024 + i * 0.015;
          ridges.push(box(0.0365, 0.006, 0.006, 0, 0.003, z, '#1a1012', 0, 0, 0.75), box(0.0365, 0.006, 0.006, 0, 0.003, z + 0.0075, '#1a1012', 0, 0, -0.75));
          ridges.push({ sph: true, r: 0.0042, x: 0.0175, y: 0.003, z: z + 0.0037, color: '#e8dcc0', seg: 6 }, { sph: true, r: 0.0042, x: -0.0175, y: 0.003, z: z + 0.0037, color: '#e8dcc0', seg: 6 });
        }
        return {
          body: [
            prof([[0, -0.016], [0.172, -0.016], [0.212, 0.016], [0.214, 0.021], [0, 0.021]], 0.0062, STEEL, 'a', { bevel: 0.0014 }),
            box(0.0022, 0.004, 0.17, 0.0034, 0.011, -0.085, '#5f656b'), box(0.0022, 0.004, 0.17, -0.0034, 0.011, -0.085, '#5f656b'),
            box(0.0072, 0.033, 0.003, 0, 0.004, -0.172, '#7a8086', 0.95),
            mbox(0.012, 0.04, 0.016, 0, 0.0025, -0.004, '#c99a3a'),
            { cyl: true, r: 0.03, r2: 0.03, h: 0.007, x: 0, y: 0.003, z: 0.008, rx: HP, color: '#2a2420', seg: 18, m: true, sx: 1, sz: 0.78, skin: 'b' },
            { torus: true, r: 0.028, tube: 0.0022, x: 0, y: 0.003, z: 0.008, color: '#c99a3a', seg: 22, m: true, sy: 0.78 },
            tube(0.0168, -0.135, -0.012, 0.003, '#2a1c18', 0, 0.0158, 12, true),
            ...ridges,
            { cyl: true, r: 0.018, r2: 0.0175, h: 0.014, x: 0, y: 0.003, z: 0.142, rx: HP, color: '#c99a3a', seg: 14, m: true },
            { sph: true, r: 0.011, x: 0, y: 0.003, z: 0.151, sz: 0.5, color: '#b8862e', seg: 10, m: true }
          ],
          mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.002, 0.075], lh: null
        };
      }
      case 'he': case 'flash': case 'smoke': {
        // корпус вдоль оси Z (запал впереди), рычаг-«ложка» сверху, кольцо чеки сбоку
        const fz = id === 'he' ? -0.046 : -0.056, lever = '#7d8277';
        const fuse = [
          tube(0.0115, -fz - 0.006, -fz + 0.016, 0, '#6d7266', 0, null, 12), tube(0.014, -fz + 0.012, -fz + 0.018, 0, '#5a5f55', 0, null, 12),
          mbox(0.012, 0.004, 0.072, 0, id === 'he' ? 0.035 : 0.027, fz + 0.036, lever, id === 'he' ? -0.16 : -0.03), mbox(0.012, 0.014, 0.004, 0, 0.026, fz - 0.01, lever),
          { torus: true, r: 0.0115, tube: 0.0019, x: 0.024, y: 0.006, z: fz - 0.004, ry: HP, color: '#c5c8cb', m: true, seg: 14 },
          mbox(0.013, 0.0022, 0.0022, 0.013, 0.006, fz - 0.004, '#c5c8cb')
        ];
        let body;
        if (id === 'he') {
          body = [{ sph: true, r: 0.034, sz: 1.2, x: 0, y: 0, z: 0, color: '#56633a', seg: 16 },
            ...[-0.026, -0.009, 0.009, 0.026].map(z => ({ torus: true, r: Math.sqrt(Math.max(0, 0.0345 * 0.0345 - (z / 1.2) * (z / 1.2))), tube: 0.0021, x: 0, y: 0, z, color: '#3e4a2a', seg: 16 })),
            ...[0, 1, 2, 3, 4, 5].map(i => box(0.003, 0.003, 0.07, Math.cos(i * Math.PI / 3) * 0.033, Math.sin(i * Math.PI / 3) * 0.033, 0, '#3e4a2a', 0, 0, i * Math.PI / 3)),
            box(0.022, 0.01, 0.002, 0, -0.012, 0.041, '#d9c24a')];
        } else if (id === 'flash') {
          body = [tube(0.022, -0.05, 0.05, 0, '#727980', 0, null, 16, true), tube(0.0225, -0.05, -0.04, 0, '#3a4048', 0, null, 16, true), tube(0.0225, 0.04, 0.05, 0, '#3a4048', 0, null, 16, true),
            ...[0, 1, 2, 3, 4, 5, 6, 7].map(i => box(0.006, 0.004, 0.024, Math.cos(i * Math.PI / 4) * 0.0215, Math.sin(i * Math.PI / 4) * 0.0215, -0.012, '#1a1c1e', 0, 0, i * Math.PI / 4 + HP)),
            tube(0.0226, 0.012, 0.022, 0, '#3a6ea8', 0, null, 16, true)];
        } else {
          body = [tube(0.026, -0.055, 0.055, 0, '#4b5a49', 0, null, 16, true), tube(0.0265, -0.055, -0.046, 0, '#2f382e', 0, null, 16, true),
            tube(0.0266, -0.03, -0.012, 0, '#d8d6cc', 0, null, 16, true), tube(0.0262, 0.046, 0.055, 0, '#2f382e', 0, null, 16, true),
            ...[0, 1, 2, 3].map(i => ({ cyl: true, r: 0.004, h: 0.002, x: Math.cos(i * HP + 0.4) * 0.012, y: Math.sin(i * HP + 0.4) * 0.012, z: 0.056, rx: HP, color: '#141614', seg: 8 }))];
        }
        return { body: body.concat(fuse), mag: [], muzzle: [0, 0, -0.1], rh: [0, 0, 0], lh: null, nr: id === 'he' ? 0.031 : id === 'flash' ? 0.02 : 0.024 };
      }
    }
  }
  // параметры хвата: наклон рукояти, размеры рукояти и цевья (для рук)
  const HOLD = {
    ar: { grip: { rake: 0.28, rb: 0.017, rn: 0.02 }, fg: { c: [0, -0.004, -0.29], rb: 0.036, rn: 0.03 } },
    ar2: { grip: { rake: 0.16, rb: 0.017, rn: 0.02 }, fg: { c: [0, 0.022, -0.29], rb: 0.036, rn: 0.032 } },
    m4s: { grip: { rake: 0.2, rb: 0.017, rn: 0.02 }, fg: { c: [0, 0.021, -0.3], rb: 0.03, rn: 0.029 } },
    smg: { grip: { rake: 0.13, rb: 0.018, rn: 0.021 }, vg: [0, -0.072, -0.108] },
    sniper: { grip: { rake: 0.3, rb: 0.02, rn: 0.022 }, fg: { c: [0, -0.007, -0.26], rb: 0.036, rn: 0.032 } },
    shotgun: { grip: { rake: 0.45, rb: 0.022, rn: 0.022 }, fg: { c: [0, -0.022, -0.33], rb: 0.033, rn: 0.034 } },
    pistol: { grip: { rake: 0.16, rb: 0.015, rn: 0.022 } }, usp: { grip: { rake: 0.16, rb: 0.015, rn: 0.022 } },
    magnum: { grip: { rake: 0.15, rb: 0.018, rn: 0.026 } }
  };
  const gunParts0 = gunParts;
  gunParts = (id) => Object.assign(gunParts0(id), HOLD[id] || {});
  G.gunParts = gunParts;

  // «конечность» от точки a к точке b — коробка вдоль вектора
  const _q = new THREE.Quaternion(), _e = new THREE.Euler(), _up = new THREE.Vector3(0, 1, 0), _d = new THREE.Vector3();
  function limb(a, b, t, color) {
    _d.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const len = _d.length(); _d.normalize();
    _q.setFromUnitVectors(_up, _d); _e.setFromQuaternion(_q);
    return { w: t, h: len, d: t * 1.05, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, color, rx: _e.x, ry: _e.y, rz: _e.z };
  }
  G.limb = limb;

  const VM_POS = {
    ar: [0.15, -0.148, -0.42], ar2: [0.15, -0.15, -0.42], m4s: [0.15, -0.15, -0.42], smg: [0.14, -0.138, -0.38], sniper: [0.15, -0.15, -0.44],
    shotgun: [0.15, -0.152, -0.42], pistol: [0.096, -0.084, -0.36], usp: [0.096, -0.084, -0.36], magnum: [0.1, -0.086, -0.37],
    knife: [0.17, -0.095, -0.27], m9: [0.17, -0.095, -0.27], butterfly: [0.17, -0.095, -0.27], karambit: [0.17, -0.095, -0.23], tanto: [0.17, -0.095, -0.27],
    he: [0.165, -0.12, -0.33], flash: [0.165, -0.12, -0.33], smoke: [0.165, -0.12, -0.33]
  };
  G.VM_POS = VM_POS;
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

  // группа мешей: пластик / металл / стекло / скин a / скин b
  function skinnedGroup(parts, mats) {
    const sk = G.geo.buildSkinned(parts, mats.k);
    const g = new THREE.Group();
    if (sk.base) g.add(new THREE.Mesh(sk.base, mats.poly));
    if (sk.metal) g.add(new THREE.Mesh(sk.metal, mats.metal));
    if (sk.glass) g.add(new THREE.Mesh(sk.glass, mats.glass));
    if (sk.a) g.add(new THREE.Mesh(sk.a, mats.a));
    if (sk.b) g.add(new THREE.Mesh(sk.b, mats.b));
    if (sk.em) g.add(new THREE.Mesh(sk.em, G.emMat()));
    return g;
  }
  G.skinnedGroup = skinnedGroup;
  let emMat = null;
  G.emMat = () => emMat || (emMat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }));

  // модель от первого лица: оружие + руки с пальцами
  G.buildViewModel = (id, sleeveColor, skinId, wear, glOverride) => {
    // glOverride — перчатки другого игрока (наблюдение от первого лица); null — стандартные
    const gl = glOverride !== undefined ? glOverride : G.equippedGloves ? G.equippedGloves() : null;
    GLV = glovePal(gl && gl.id);
    try { return buildVM(id, sleeveColor, skinId, wear, gl); } finally { GLV = GLV_DEF; }
  };
  function buildVM(id, sleeveColor, skinId, wear, gl) {
    const gp = gunParts(id);
    const root = new THREE.Group();
    const gun = new THREE.Group();
    root.add(gun);
    const mats = G.skinMats(id, skinId, wear);
    const base = VM_POS[id];
    const L = (p) => sub(p, base);
    const nade = !!G.WEAPONS[id].nade, knife = G.WEAPONS[id].melee || nade, pist = G.WEAPONS[id].slot === 'secondary';
    const gR = [], sR = [], gL = [], sL = [];
    let lSh = null;
    const team = sleeveColor === 1 || sleeveColor === '1' ? 1 : 0;
    if (gp.rh) {
      const C = gp.rh;
      let cfg;
      if (id === 'karambit') {
        cfg = { C, A: [0, 0, -1], B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: 0.016, rn: 0.016,
          fingers: [{ s: -0.036, t: [-0.25, 0.75, 1.75, 2.65] }, { s: -0.016, t: [-0.25, 0.75, 1.75, 2.7] }, { s: 0.004, t: [-0.25, 0.75, 1.75, 2.65] }, { s: 0.023, sc: 0.88, t: [-0.2, 0.8, 1.75, 2.5] }],
          thumb: [[comb(C, [0, 0, 1], 0.03, [-1, 0, 0], 0.02, [0, -1, 0], 0.004)], [comb(C, [0, 0, 1], 0.03, [-1, 0, 0], 0.025, [0, 1, 0], 0.014)], [comb(C, [0, 0, 1], 0.04, [-1, 0, 0], 0.012, [0, 1, 0], 0.027)], [comb(C, [0, 0, 1], 0.05, [-1, 0, 0], 0.0, [0, 1, 0], 0.03)]],
          W: comb(C, [0, 0, 1], 0.07, [0, -1, 0], 0.016, [1, 0, 0], 0.012) };
      } else if (nade) {
        // граната в кулаке: пальцы обхватывают корпус, большой палец прижимает рычаг
        const R = gp.nr;
        cfg = { C, A: [0, 0, 1], B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: R, rn: R,
          fingers: [{ s: -0.028, t: [-0.2, 0.7, 1.6, 2.4] }, { s: -0.009, t: [-0.2, 0.7, 1.6, 2.45] }, { s: 0.01, t: [-0.2, 0.7, 1.6, 2.4] }, { s: 0.028, sc: 0.88, t: [-0.15, 0.75, 1.6, 2.3] }],
          thumb: [[comb(C, [0, 0, 1], 0.05, [-1, 0, 0], R + 0.004, [0, -1, 0], 0.004)], [comb(C, [0, 0, 1], 0.026, [-1, 0, 0], R + 0.006, [0, 1, 0], R * 0.45)],
            [comb(C, [0, 0, 1], 0.004, [-1, 0, 0], R * 0.55, [0, 1, 0], R + 0.008)], [comb(C, [0, 0, 1], -0.014, [-1, 0, 0], 0.004, [0, 1, 0], R + 0.012)]],
          W: comb(C, [0, 0, 1], 0.07 + R, [1, 0, 0], 0.014, [0, -1, 0], 0.014) };
      } else if (knife) {
        cfg = { C, A: [0, 0, 1], B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: 0.017, rn: 0.017,
          fingers: [{ s: -0.031, t: [-0.25, 0.75, 1.75, 2.65] }, { s: -0.011, t: [-0.25, 0.75, 1.75, 2.7] }, { s: 0.009, t: [-0.25, 0.75, 1.75, 2.65] }, { s: 0.028, sc: 0.88, t: [-0.2, 0.8, 1.75, 2.5] }],
          thumb: [[comb(C, [0, 0, 1], 0.036, [-1, 0, 0], 0.022, [0, -1, 0], 0.002)], [comb(C, [0, 0, 1], 0.012, [-1, 0, 0], 0.025, [0, 1, 0], 0.012)], [comb(C, [0, 0, 1], -0.012, [-1, 0, 0], 0.014, [0, 1, 0], 0.026)], [comb(C, [0, 0, 1], -0.026, [-1, 0, 0], 0.002, [0, 1, 0], 0.029)]],
          W: comb(C, [0, 0, 1], 0.085, [1, 0, 0], 0.012, [0, -1, 0], 0.012) };
      } else {
        const g = gp.grip || {}, rb = g.rb || 0.016, rn = g.rn || 0.021;
        cfg = { C, A: [0, -1, g.rake != null ? g.rake : 0.25], B: [1, 0, 0.25], wrap: [0, 0, -1], rb, rn,
          fingers: [
            { pts: [[-0.026, rb + 0.016, 0.002], [-0.036, rb + 0.013, rn + 0.018], [-0.04, rb + 0.004, rn + 0.04], [-0.036, 0.004, rn + 0.05]] },
            { s: -0.004, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.016, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.035, sc: 0.86, t: [-0.2, 0.8, 1.75, 2.4] }],
          thumb: [[0.028, -0.004, -(rn + 0.022)], [-0.004, -(rb + 0.012), -0.012], [-0.02, -(rb + 0.011), 0.012], [-0.028, -(rb + 0.008), 0.032]],
          Wl: [0.072, 0.012, -0.052] };
      }
      const r = hand(gR, cfg);
      const elbow = L(knife ? [0.3, -0.42, -0.04] : [0.33, -0.44, -0.07]), shoulder = L([0.44, -0.66, 0.12]);
      forearm(gR, sR, r.W, elbow, shoulder);
    }
    if (gp.lh) {
      let cfg;
      if (pist) {
        const g = gp.grip || {}, C = gp.rh;
        cfg = { C, A: [0, -1, g.rake != null ? g.rake : 0.25], B: [-1, 0, 0.2], wrap: [0, 0, -1], rb: 0.03, rn: 0.034,
          fingers: [{ s: 0.006, t: [-0.25, 0.55, 1.3, 1.85] }, { s: 0.024, t: [-0.25, 0.55, 1.3, 1.85] }, { s: 0.041, t: [-0.25, 0.55, 1.3, 1.8] }, { s: 0.056, sc: 0.85, t: [-0.2, 0.6, 1.3, 1.75] }],
          thumb: [[0.03, 0.012, -0.034], [0.004, 0.031, -0.006], [-0.012, 0.028, 0.016], [-0.018, 0.023, 0.036]],
          Wl: [0.07, 0.036, -0.036] };
      } else if (gp.vg) {
        const C = gp.vg;
        cfg = { C, A: [0, -1, 0.08], B: [-1, 0, 0.2], wrap: [0, 0, -1], rb: 0.015, rn: 0.018,
          fingers: [{ s: -0.024, t: [-0.25, 0.75, 1.75, 2.5] }, { s: -0.005, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.014, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.032, sc: 0.86, t: [-0.2, 0.8, 1.75, 2.4] }],
          thumb: [[0.024, 0.002, -0.04], [-0.006, -0.027, -0.01], [-0.022, -0.026, 0.012], [-0.03, -0.023, 0.03]],
          Wl: [0.07, 0.014, -0.05] };
      } else {
        const fg = gp.fg || {}, C = fg.c || add(gp.lh, [0, 0.03, 0]), rb = fg.rb || 0.034, rn = fg.rn || 0.034;
        const Z = [0, 0, 1], X = [-1, 0, 0], Dn = [0, -1, 0], Up = [0, 1, 0];
        cfg = { C, A: Z, B: [0.45, -0.9, 0], wrap: [1, 1, 0], rb, rn,
          fingers: [{ s: -0.034, t: [-0.15, 0.55, 1.3, 1.85] }, { s: -0.013, t: [-0.15, 0.58, 1.35, 1.95] }, { s: 0.008, t: [-0.15, 0.58, 1.35, 1.9] }, { s: 0.028, sc: 0.86, t: [-0.1, 0.6, 1.3, 1.8] }],
          thumb: [[comb(C, Z, 0.03, X, rb * 0.75, Dn, rn * 0.85)], [comb(C, Z, 0.004, X, rb + 0.012, Dn, rn * 0.3)], [comb(C, Z, -0.022, X, rb + 0.012, Up, 0.004)], [comb(C, Z, -0.042, X, rb + 0.008, Up, rn * 0.3)]],
          W: comb(C, Z, 0.085, X, 0.03, Dn, rn + 0.042) };
      }
      const r = hand(gL, cfg);
      const elbow = L(pist ? [0.02, -0.46, -0.16] : [-0.05, -0.47, -0.3]), shoulder = L([-0.2, -0.72, -0.12]);
      forearm(gL, sL, r.W, elbow, shoulder, { watch: true });
      lSh = shoulder;
    }
    const armMesh = new THREE.Group();
    const gMat = G.gloveMat(gl && gl.id, gl && gl.wear), sMat = G.sleeveMat(team);
    if (gR.length) armMesh.add(new THREE.Mesh(G.geo.buildUV(gR, 22), gMat), new THREE.Mesh(G.geo.buildUV(sR, 5), sMat));
    const lArm = new THREE.Group();
    if (gL.length) lArm.add(new THREE.Mesh(G.geo.buildUV(gL, 22), gMat), new THREE.Mesh(G.geo.buildUV(sL, 5), sMat));
    const knifeGroup = new THREE.Group();
    if (knife) gun.add(knifeGroup);
    const bodyG = skinnedGroup(gp.body, mats);
    let blade = null;
    if (gp.handle) {
      // бабочка: клинок в своей группе на оси шарнира — вращается независимо от рукоятей
      const pv = gp.pivot; blade = new THREE.Group(); blade.position.set(pv[0], pv[1], pv[2]);
      bodyG.position.set(-pv[0], -pv[1], -pv[2]); blade.add(bodyG); knifeGroup.add(blade);
    } else (knife ? knifeGroup : gun).add(bodyG);
    gun.add(armMesh, lArm);
    let magMesh = null, slide = null, pump = null, shell = null;
    if (gp.mag.length) {
      magMesh = skinnedGroup(gp.mag, mats);
      if (gp.magPivot) {
        // магазин качается вокруг переднего зацепа, как у калаша
        const mp = gp.magPivot, piv = new THREE.Group(); piv.position.set(mp[0], mp[1], mp[2]);
        magMesh.position.set(-mp[0], -mp[1], -mp[2]); piv.add(magMesh); gun.add(piv);
        magMesh = piv; magMesh.userData.rock = true;
      } else gun.add(magMesh);
    }
    if (gp.slide) { slide = skinnedGroup(gp.slide, mats); gun.add(slide); }
    if (gp.pump) { pump = skinnedGroup(gp.pump, mats); gun.add(pump); }
    // точки для анимаций перезарядки: где левая рука «дома», где она берёт магазин, куда выпадает магазин
    let home = null, grab = null, magDir = [0, -0.99, 0.15];
    if (gp.lh) {
      home = pist ? gp.rh : gp.vg ? gp.vg : (gp.fg && gp.fg.c) || add(gp.lh, [0, 0.03, 0]);
      if (magMesh) {
        magMesh.updateMatrixWorld(true);
        const bb = new THREE.Box3().setFromObject(magMesh), c = bb.getCenter(new THREE.Vector3());
        grab = pist ? [c.x - 0.012, bb.min.y - 0.006, c.z + 0.004] : [c.x - 0.022, c.y - 0.012, c.z];
      }
      if (id === 'shotgun') grab = [-0.016, -0.062, -0.03];
      if (pist) magDir = [0, -0.98, 0.2];
      if (id === 'sniper') magDir = [0, -1, 0];
    }
    if (gp.shell) { shell = skinnedGroup(gp.shell, mats); shell.visible = false; shell.position.set(home[0] - 0.004, home[1] - 0.048, home[2] + 0.012); lArm.add(shell); }
    let bolt = null;
    if (gp.bolt) {
      bolt = new THREE.Group(); bolt.position.set(gp.boltPos[0], gp.boltPos[1], gp.boltPos[2]);
      bolt.add(skinnedGroup(gp.bolt, mats)); gun.add(bolt);
    }
    let hA = null, hB = null;
    if (gp.handle) {
      // обе рукояти — на той же оси, что и клинок
      const pv = gp.pivot;
      hA = new THREE.Group(); hA.position.set(pv[0], pv[1], pv[2]);
      const ga = skinnedGroup(gp.handle(1), mats); ga.position.set(-pv[0], -pv[1], -pv[2]); hA.add(ga);
      hB = new THREE.Group(); hB.position.set(pv[0], pv[1], pv[2]);
      const gb = skinnedGroup(gp.handle(-1), mats); gb.position.set(-pv[0], -pv[1], -pv[2]); hB.add(gb);
      knifeGroup.add(hA, hB);
    }
    const flareMat = new THREE.MeshBasicMaterial({ map: G.tex('flare'), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
    const flash = new THREE.Group();
    const s = id === 'shotgun' || id === 'sniper' || id === 'magnum' ? 0.26 : id === 'pistol' ? 0.13 : id === 'usp' ? 0.07 : id === 'm4s' ? 0.075 : 0.19;
    const p1 = new THREE.Mesh(new THREE.PlaneGeometry(s, s), flareMat);
    const p2 = new THREE.Mesh(new THREE.PlaneGeometry(s * 0.6, s * 1.8), flareMat); p2.rotation.x = HP; p2.position.z = -s * 0.5;
    const p3 = new THREE.Mesh(new THREE.PlaneGeometry(s * 0.6, s * 1.8), flareMat); p3.rotation.set(HP, HP, 0); p3.position.z = -s * 0.5;
    flash.add(p1, p2, p3);
    flash.position.set(gp.muzzle[0], gp.muzzle[1], gp.muzzle[2]);
    flash.visible = false;
    gun.add(flash);
    // искры золотых скинов живут в той же группе, что и клинок/корпус (у бабочки клинок вращается отдельно)
    const sparkHost = blade ? bodyG : knife ? knifeGroup : gun;
    if (mats.shine) {
      const am = bodyG.children.find(c => c.material === mats.a);
      G.addSparkles(sparkHost, am, knife ? 7 : 12, knife ? 0.028 : 0.04);
    }
    let pivot = [0, 0, 0];
    if (knife) {
      // нож держится под углом; повороты анимаций идут вокруг запястья, а не вокруг гарды
      if (nade) gun.rotation.set(0.32, 0.38, -0.22); else gun.rotation.set(0.42, 0.45, -0.3);
      const w = new THREE.Vector3(0.01, -0.025, id === 'karambit' ? 0.09 : nade ? 0.1 : 0.15).applyEuler(gun.rotation);
      pivot = [w.x, w.y, w.z];
      gun.position.set(-w.x, -w.y, -w.z);
    }
    root.position.set(base[0] + pivot[0], base[1] + pivot[1], base[2] + pivot[2]);
    return { root, gun, mag: magMesh, slide, pump, shell, bolt, flash, base: [base[0] + pivot[0], base[1] + pivot[1], base[2] + pivot[2]], muzzle: gp.muzzle, id, knifeGroup, hA, hB, blade, sparkHost, skin: skinId, lArm, armMesh, home, grab, magDir, pist, charge: gp.charge || null, magBase: magMesh ? magMesh.position.toArray() : null, lSh, slideK: gp.slideK || 0 };
  }
  // материалы рук: перчатка (кожа с фактурой) и рукав (камуфляж команды)
  const handMats = {};
  G.gloveMat = (gid, wear) => {
    const sk = gid && G.SKINS[gid], pbr = G.pbrOn();
    const k = 'g' + (pbr ? 1 : 0) + '|' + (gid || '') + '|' + (wear || 0);
    if (!handMats[k]) {
      if (!sk) {
        handMats[k] = pbr
          ? new THREE.MeshStandardMaterial({ map: G.tex('glove'), vertexColors: true, metalness: 0, roughness: 0.72, normalMap: G.normalTex('glove'), normalScale: new THREE.Vector2(0.5, 0.5) })
          : new THREE.MeshPhongMaterial({ map: G.tex('glove'), vertexColors: true, shininess: 18, specular: 0x222222 });
      } else {
        // перчатки из каталога: узор скина + вершинная палитра
        const t = G.skinTex(sk.p, wear || 0), L = G.LOOK[sk.p] || [0.1, 0.6];
        let m;
        if (pbr) {
          const o = { map: t, vertexColors: true, metalness: L[0], roughness: G.clamp(L[1] + (wear || 0) * 0.08, 0, 1), envMapIntensity: L[0] < 0.5 ? 0.6 : 1 };
          if (L[2]) { o.emissiveMap = t; o.emissive = new THREE.Color(0xffffff); o.emissiveIntensity = L[2]; }
          if (L[4]) { o.bumpMap = t; o.bumpScale = L[4]; }
          m = new THREE.MeshStandardMaterial(Object.assign({ envMap: G.envTex || null }, o)); G.pbrMats.push(m);
        } else {
          m = new THREE.MeshPhongMaterial({ map: t, vertexColors: true, shininess: 20 + (1 - L[1]) * 80, specular: L[0] > 0.6 ? 0x666666 : 0x2a2a2a });
          if (L[2]) { m.emissiveMap = t; m.emissive = new THREE.Color(0xffffff); m.emissiveIntensity = L[2]; }
        }
        if (L[5] && G.addShineTo) G.addShineTo(m, L[5], sk.p);
        handMats[k] = m;
      }
    }
    return handMats[k];
  };
  // витрина перчаток: кулак правой руки с манжетой
  G.buildGloveShow = (gid, wear) => {
    GLV = glovePal(gid);
    const gR = [], sR = [];
    try {
      const C = [0, 0, 0];
      const cfg = { C, A: [0, 0, 1], B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: 0.02, rn: 0.019,
        fingers: [{ s: -0.031, t: [-0.25, 0.75, 1.75, 2.65] }, { s: -0.011, t: [-0.25, 0.75, 1.75, 2.7] }, { s: 0.009, t: [-0.25, 0.75, 1.75, 2.65] }, { s: 0.028, sc: 0.88, t: [-0.2, 0.8, 1.75, 2.5] }],
        thumb: [[comb(C, [0, 0, 1], 0.036, [-1, 0, 0], 0.022, [0, -1, 0], 0.002)], [comb(C, [0, 0, 1], 0.012, [-1, 0, 0], 0.025, [0, 1, 0], 0.012)], [comb(C, [0, 0, 1], -0.012, [-1, 0, 0], 0.014, [0, 1, 0], 0.026)], [comb(C, [0, 0, 1], -0.026, [-1, 0, 0], 0.002, [0, 1, 0], 0.029)]],
        W: comb(C, [0, 0, 1], 0.085, [1, 0, 0], 0.012, [0, -1, 0], 0.012) };
      const r = hand(gR, cfg);
      // короткий обрез рукава сразу за манжетой
      const W = r.W, D = VA.norm([0.012, -0.012, 0.085]);
      forearm(gR, sR, W, comb(W, D, 0.11), comb(W, D, 0.125));
    } finally { GLV = GLV_DEF; }
    const g = new THREE.Group();
    g.add(new THREE.Mesh(G.geo.buildUV(gR, 22), G.gloveMat(gid, wear)));
    // тыльная сторона кисти к зрителю, запястье внизу
    g.rotation.set(HP * 0.8, 0.15, 0.0);
    return g;
  };
  G.sleeveMat = (team) => {
    const k = 's' + team + (G.pbrOn() ? 1 : 0);
    if (!handMats[k]) {
      handMats[k] = G.pbrOn()
        ? new THREE.MeshStandardMaterial({ map: G.tex('sleeve', String(team)), vertexColors: true, metalness: 0, roughness: 0.9, normalMap: G.normalTex('sleeve', String(team)), normalScale: new THREE.Vector2(0.8, 0.8) })
        : new THREE.MeshLambertMaterial({ map: G.tex('sleeve', String(team)), vertexColors: true });
    }
    return handMats[k];
  };
  G.armMat = G.gloveMat;

  // модель для витрины (без рук)
  G.buildShowcase = (id, skinId, wear) => {
    if (id === 'gloves') return G.buildGloveShow(skinId, wear);
    const gp = gunParts(id);
    const mats = G.skinMats(id, skinId, wear);
    const g = new THREE.Group();
    g.add(skinnedGroup(gp.body, mats));
    if (gp.mag.length) g.add(skinnedGroup(gp.mag, mats));
    if (gp.slide) g.add(skinnedGroup(gp.slide, mats));
    if (gp.pump) g.add(skinnedGroup(gp.pump, mats));
    if (gp.bolt) { const b = skinnedGroup(gp.bolt, mats); b.position.set(gp.boltPos[0], gp.boltPos[1], gp.boltPos[2]); g.add(b); }
    if (gp.handle) g.add(skinnedGroup(gp.handle(1), mats), skinnedGroup(gp.handle(-1), mats));
    if (mats.shine) { const am = g.children[0].children.find(c => c.material === mats.a); G.addSparkles(g, am, 14, G.WEAPONS[id].melee ? 0.035 : 0.06); }
    return g;
  };

  // модель в руках бота (вершинные цвета, дёшево)
  G.buildWorldGun = (id) => {
    const gp = gunParts(id);
    const parts = gp.body.concat(gp.mag, gp.slide || [], gp.pump || []).filter(p => !p.em);
    if (gp.handle) parts.push(...gp.handle(1), ...gp.handle(-1));
    return { geo: G.geo.build(parts), muzzle: gp.muzzle };
  };
})(window.G);
