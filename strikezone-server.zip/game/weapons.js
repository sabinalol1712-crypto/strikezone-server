'use strict';
/* Оружие: характеристики и модели (профили + детали), руки от первого лица, ножи М9 и бабочка */
(function (G) {
  const W = G.WEAPONS = {
    pistol: {
      id: 'pistol', slot: 'secondary', name: 'Glock-18', cls: 'Пистолет', dmg: 26, rate: 0.15, auto: false, team: 1,
      mag: 20, reserve: 100, reload: 1.8, spread: 0.006, spreadMove: 0.03, spreadJump: 0.1, spreadShot: 0.02,
      spreadMax: 0.06, recoil: 0.026, recoilYaw: 0.006, range: 90, falloff: 0.006, speed: 5.6, head: 4, pellets: 1,
      sound: 'pistol', bars: [5, 5, 5, 8], price: 200, reward: 300, pen: 0.55
    },
    usp: {
      id: 'usp', slot: 'secondary', name: 'USP-S', cls: 'Пистолет с глушителем', dmg: 31, rate: 0.17, auto: false, team: 0,
      mag: 12, reserve: 24, reload: 2.2, spread: 0.0042, spreadMove: 0.028, spreadJump: 0.1, spreadShot: 0.018,
      spreadMax: 0.055, recoil: 0.021, recoilYaw: 0.005, range: 100, falloff: 0.005, speed: 5.6, head: 4, pellets: 1,
      sound: 'usp', bars: [6, 5, 8, 8], price: 200, reward: 300, pen: 0.55, silenced: true
    },
    magnum: {
      id: 'magnum', slot: 'secondary', name: 'Desert Eagle', cls: 'Тяжёлый пистолет', dmg: 52, rate: 0.34, auto: false,
      mag: 7, reserve: 35, reload: 2.1, spread: 0.007, spreadMove: 0.05, spreadJump: 0.14, spreadShot: 0.04,
      spreadMax: 0.08, recoil: 0.065, recoilYaw: 0.012, range: 110, falloff: 0.004, speed: 5.45, head: 3.6, pellets: 1,
      sound: 'magnum', bars: [8, 3, 6, 7], price: 700, reward: 300, pen: 0.93
    },
    fiveseven: {
      id: 'fiveseven', slot: 'secondary', name: 'Five-SeveN', cls: 'Пистолет', dmg: 29, rate: 0.15, auto: false, team: 0,
      mag: 20, reserve: 100, reload: 2.0, spread: 0.0045, spreadMove: 0.03, spreadJump: 0.1, spreadShot: 0.017,
      spreadMax: 0.055, recoil: 0.022, recoilYaw: 0.005, range: 105, falloff: 0.0055, speed: 5.6, head: 4, pellets: 1,
      sound: 'fiveseven', bars: [6, 5, 7, 8], price: 500, reward: 300, pen: 0.8
    },
    // 2.5: Dual Berettas — два Beretta 92 (обе стороны): быстрый темп и большой магазин, но разброс шире, перезарядка дольше
    duals: {
      id: 'duals', slot: 'secondary', name: 'Dual Berettas', cls: 'Парные пистолеты', dmg: 28, rate: 0.12, auto: false, dual: true,
      mag: 30, reserve: 120, reload: 3.3, spread: 0.0062, spreadMove: 0.032, spreadJump: 0.1, spreadShot: 0.024,
      spreadMax: 0.075, recoil: 0.021, recoilYaw: 0.009, range: 90, falloff: 0.0065, speed: 5.55, head: 4, pellets: 1,
      sound: 'duals', bars: [5, 8, 4, 8], price: 300, reward: 300, pen: 0.58
    },
    tec9: {
      id: 'tec9', slot: 'secondary', name: 'Tec-9', cls: 'Пистолет', dmg: 25, rate: 0.115, auto: false, team: 1,
      mag: 18, reserve: 90, reload: 2.1, spread: 0.0066, spreadMove: 0.026, spreadJump: 0.09, spreadShot: 0.026,
      spreadMax: 0.07, recoil: 0.02, recoilYaw: 0.008, range: 85, falloff: 0.0075, speed: 5.65, head: 4, pellets: 1,
      sound: 'tec9', bars: [5, 7, 5, 8], price: 500, reward: 300, pen: 0.8
    },
    smg: {
      id: 'smg', slot: 'primary', name: 'UMP-45', cls: 'Пистолет-пулемёт', dmg: 25, rate: 0.078, auto: true,
      mag: 32, reserve: 160, reload: 1.9, spread: 0.008, spreadMove: 0.018, spreadJump: 0.08, spreadShot: 0.006,
      spreadMax: 0.045, recoil: 0.009, recoilYaw: 0.007, range: 90, falloff: 0.009, speed: 5.6, head: 3.5, pellets: 1,
      sound: 'smg', bars: [6, 8, 7, 8], price: 1200, reward: 600, pen: 0.65
    },
    shotgun: {
      id: 'shotgun', slot: 'primary', name: 'M870', cls: 'Помповый дробовик', dmg: 17, rate: 0.85, auto: false,
      mag: 7, reserve: 35, reload: 2.6, spread: 0.06, spreadMove: 0.015, spreadJump: 0.03, spreadShot: 0,
      spreadMax: 0.09, recoil: 0.065, recoilYaw: 0.012, range: 45, falloff: 0.022, speed: 5.1, head: 2.5, pellets: 9,
      sound: 'shotgun', bars: [9, 3, 2, 6], price: 1100, reward: 900, pen: 0.6
    },
    ar: {
      id: 'ar', slot: 'primary', name: 'AK-47', cls: 'Штурмовая винтовка', dmg: 30, rate: 0.1, auto: true, team: 1,
      mag: 30, reserve: 120, reload: 2.3, spread: 0.004, spreadMove: 0.05, spreadJump: 0.14, spreadShot: 0.011,
      spreadMax: 0.06, recoil: 0.017, recoilYaw: 0.007, range: 140, falloff: 0.003, speed: 5.15, head: 4, pellets: 1,
      sound: 'ar', bars: [7, 7, 6, 5], price: 2700, reward: 300, pen: 0.77
    },
    ar2: {
      id: 'ar2', slot: 'primary', name: 'M4A4', cls: 'Штурмовая винтовка', dmg: 27, rate: 0.09, auto: true, team: 0,
      mag: 30, reserve: 90, reload: 2.5, spread: 0.0032, spreadMove: 0.045, spreadJump: 0.13, spreadShot: 0.009,
      spreadMax: 0.05, recoil: 0.0135, recoilYaw: 0.006, range: 140, falloff: 0.003, speed: 5.2, head: 4, pellets: 1,
      sound: 'ar2', bars: [6, 8, 8, 5], price: 3100, reward: 300, pen: 0.7
    },
    m4s: {
      id: 'm4s', slot: 'primary', name: 'M4A1-S', cls: 'Штурмовая винтовка с глушителем', dmg: 29, rate: 0.1, auto: true, team: 0,
      mag: 20, reserve: 80, reload: 2.5, spread: 0.0027, spreadMove: 0.043, spreadJump: 0.13, spreadShot: 0.0078,
      spreadMax: 0.045, recoil: 0.0118, recoilYaw: 0.005, range: 150, falloff: 0.0027, speed: 5.2, head: 4, pellets: 1,
      sound: 'm4s', bars: [7, 7, 9, 5], price: 2900, reward: 300, pen: 0.7, silenced: true
    },
    galil: {
      id: 'galil', slot: 'primary', name: 'Galil AR', cls: 'Штурмовая винтовка', dmg: 26, rate: 0.1, auto: true, team: 1,
      mag: 35, reserve: 105, reload: 2.6, spread: 0.0042, spreadMove: 0.05, spreadJump: 0.14, spreadShot: 0.0105,
      spreadMax: 0.06, recoil: 0.0132, recoilYaw: 0.006, range: 130, falloff: 0.0036, speed: 5.2, head: 4, pellets: 1,
      sound: 'galil', bars: [6, 6, 7, 5], price: 1800, reward: 300, pen: 0.72
    },
    famas: {
      id: 'famas', slot: 'primary', name: 'FAMAS', cls: 'Штурмовая винтовка', dmg: 25, rate: 0.084, auto: true, team: 0,
      mag: 25, reserve: 75, reload: 2.4, spread: 0.0034, spreadMove: 0.047, spreadJump: 0.13, spreadShot: 0.0095,
      spreadMax: 0.055, recoil: 0.0125, recoilYaw: 0.0055, range: 135, falloff: 0.0034, speed: 5.2, head: 4, pellets: 1,
      sound: 'famas', bars: [5, 8, 7, 5], price: 2050, reward: 300, pen: 0.68
    },
    sniper: {
      id: 'sniper', slot: 'primary', name: 'AWM', cls: 'Снайперская винтовка', dmg: 115, rate: 1.3, auto: false,
      mag: 5, reserve: 25, reload: 3.0, spread: 0.0015, spreadNoScope: 0.09, spreadMove: 0.12, spreadJump: 0.25,
      spreadShot: 0, spreadMax: 0.3, recoil: 0.07, recoilYaw: 0.01, range: 220, falloff: 0, speed: 4.75, head: 4,
      pellets: 1, scope: true, sound: 'sniper', bars: [10, 2, 10, 3], price: 4750, reward: 100, pen: 0.97
    },
    ssg: {
      id: 'ssg', slot: 'primary', name: 'SSG 08', cls: 'Снайперская винтовка', dmg: 74, rate: 1.0, auto: false,
      mag: 10, reserve: 30, reload: 2.6, spread: 0.0016, spreadNoScope: 0.08, spreadMove: 0.07, spreadJump: 0.2,
      spreadShot: 0, spreadMax: 0.26, recoil: 0.05, recoilYaw: 0.008, range: 210, falloff: 0, speed: 5.5, head: 4,
      pellets: 1, scope: true, sound: 'ssg', bars: [7, 3, 9, 6], price: 1700, reward: 300, pen: 0.85
    },
    knife: { id: 'knife', slot: 'melee', name: 'Тактический нож', cls: 'Нож', dmg: 55, rate: 0.55, auto: true, melee: true, range: 2.4, speed: 6.0, head: 1.6, sound: 'knife', reward: 1500 },
    m9: { id: 'm9', slot: 'melee', name: 'Штык-нож М9', cls: 'Нож', dmg: 55, rate: 0.55, auto: true, melee: true, range: 2.45, speed: 6.0, head: 1.6, sound: 'knife', reward: 1500 },
    karambit: { id: 'karambit', slot: 'melee', name: 'Керамбит', cls: 'Нож', dmg: 55, rate: 0.48, auto: true, melee: true, range: 2.3, speed: 6.1, head: 1.6, sound: 'knife', reward: 1500 },
    butterfly: { id: 'butterfly', slot: 'melee', name: 'Нож-бабочка', cls: 'Нож', dmg: 55, rate: 0.46, auto: true, melee: true, range: 2.3, speed: 6.1, head: 1.6, sound: 'knife', reward: 1500 },
    tanto: { id: 'tanto', slot: 'melee', name: 'Танто', cls: 'Японский нож', dmg: 55, rate: 0.5, auto: true, melee: true, range: 2.45, speed: 6.1, head: 1.6, sound: 'knife', reward: 1500 },
    // гранаты: отдельный слот, бросок кнопкой огня
    he: { id: 'he', slot: 'nade', nade: 'he', name: 'HE-граната', cls: 'Осколочная граната', rate: 1.0, speed: 5.6, range: 0, price: 300, reward: 300, pen: 0.57, sound: 'nade' },
    flash: { id: 'flash', slot: 'nade', nade: 'flash', name: 'Светошумовая', cls: 'Светошумовая граната', rate: 1.0, speed: 5.6, range: 0, price: 200, reward: 300, sound: 'nade' },
    smoke: { id: 'smoke', slot: 'nade', nade: 'smoke', name: 'Дымовая', cls: 'Дымовая граната', rate: 1.0, speed: 5.6, range: 0, price: 300, reward: 300, sound: 'nade' }
  };
  G.NADE_TYPES = ['he', 'flash', 'smoke'];
  // разброс и отдача тяжелее: стрельба на бегу и длинными очередями заметно хуже
  for (const k in W) {
    const d = W[k]; if (d.melee || d.nade) continue;
    d.spread *= 1.25; d.spreadMove *= 1.35; d.spreadJump *= 1.2; d.spreadShot *= 1.4; d.spreadMax *= 1.35; d.recoil *= 1.12; d.recoilYaw *= 1.15;
    if (d.spreadNoScope) d.spreadNoScope *= 1.2;
  }
  G.PRIMARIES = ['ar', 'ar2', 'm4s', 'galil', 'famas', 'smg', 'shotgun', 'sniper', 'ssg'];
  // пистолеты (слот secondary), порядок как в магазине
  G.PISTOLS = ['usp', 'pistol', 'duals', 'magnum', 'fiveseven', 'tec9'];
  G.KNIVES = ['knife', 'm9', 'butterfly', 'karambit', 'tanto'];

  G.newWeaponState = (id, skin, wear) => {
    const d = W[id];
    return { id, def: d, skin: skin || null, wear: wear || 0, mag: d.mag || 0, reserve: d.reserve || 0, cd: 0, reloadT: 0, heat: 0, drawT: 0 };
  };

  // ---------- детали моделей ----------
  const MET = '#2b2e32', MET2 = '#3c4147', BLK = '#18191b', POLY = '#232427', STEEL = '#a7adb3', WOOD = '#7a4a24', OLIVE = '#4f5b3c', TAN = '#8a7a5a';
  const HP = Math.PI / 2;
  const box = (w, h, d, x, y, z, color, rx, ry, rz) => ({ w, h, d, x, y, z, color, rx, ry, rz });
  const mbox = (w, h, d, x, y, z, color, rx, ry, rz) => ({ w, h, d, x, y, z, color: color || MET, rx, ry, rz, m: true });
  // цилиндр вдоль ствола: от f0 до f1 (вперёд), на высоте y; металл по умолчанию
  const tube = (r, f0, f1, y, color, x, r2, seg, poly) => ({ cyl: true, r, r2, h: f1 - f0, x: x || 0, y, z: -(f0 + f1) / 2, rx: HP, color: color || MET, seg: seg || 12, m: !poly });
  // профиль: точки [вперёд, вверх] (+кривые), толщина d
  const prof = (pts, d, color, skin, opt) => Object.assign({ shape: true, pts, d, color, skin, bevel: 0.003 }, opt || {});
  const mprof = (pts, d, color, opt) => prof(pts, d, color || MET, null, Object.assign({ m: true }, opt || {}));
  const rail = (f0, f1, y, x, w) => { const out = [mbox(w || 0.03, 0.012, f1 - f0, x || 0, y, -(f0 + f1) / 2, BLK)]; for (let f = f0 + 0.006; f < f1; f += 0.013) out.push(mbox((w || 0.03) + 0.004, 0.006, 0.006, x || 0, y + 0.009, -f, BLK)); return out; };
  const loop = (outer, inner, d, color, skin, m) => prof(outer, d, color, skin, { holes: [inner], bevel: 0.0015, m });
  // ---------- руки: перчатки с фалангами, жёсткие накладки, манжеты, рукава ----------
  const VA = {
    add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
    sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
    mul: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
    mix: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t],
    dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
    cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
    norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
    len: (a) => Math.hypot(a[0], a[1], a[2])
  };
  // c + Σ (вектор, множитель)
  const comb = (c, ...vs) => { const o = c.slice(); for (let i = 0; i < vs.length; i += 2) { o[0] += vs[i][0] * vs[i + 1]; o[1] += vs[i][1] * vs[i + 1]; o[2] += vs[i][2] * vs[i + 1]; } return o; };
  const _yAx = new THREE.Vector3(0, 1, 0), _zAx = new THREE.Vector3(0, 0, 1), _dv = new THREE.Vector3(), _m4 = new THREE.Matrix4();
  const _bx = new THREE.Vector3(), _by = new THREE.Vector3(), _bz = new THREE.Vector3();
  // «кость»: конус от a (радиус ra) к b (rb) + шарик-сустав в b
  function bone(out, a, b, ra, rb, color, opt) {
    const d = VA.sub(b, a), len = VA.len(d) || 1e-4;
    _dv.set(d[0] / len, d[1] / len, d[2] / len);
    _q.setFromUnitVectors(_yAx, _dv); _e.setFromQuaternion(_q);
    out.push(Object.assign({ cyl: true, r: rb, r2: ra, h: len, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, rx: _e.x, ry: _e.y, rz: _e.z, color, seg: 12 }, opt || {}));
    if (!(opt && opt.noJoint)) out.push(Object.assign({ sph: true, r: rb, x: b[0], y: b[1], z: b[2], color, seg: (opt && opt.jseg) || 12 }, opt && opt.skin ? { skin: opt.skin } : {}));
  }
  // кольцо вокруг оси d в точке c
  function ring(out, c, d, r, tube, color, opt) {
    const n = VA.norm(d); _dv.set(n[0], n[1], n[2]);
    _q.setFromUnitVectors(_zAx, _dv); _e.setFromQuaternion(_q);
    out.push(Object.assign({ torus: true, r, tube, x: c[0], y: c[1], z: c[2], rx: _e.x, ry: _e.y, rz: _e.z, color, seg: 18 }, opt || {}));
  }
  // эллипсоид: полуось sx вдоль ax, sy вдоль ay, sz по нормали к ним
  function blob(out, c, ax, ay, sx, sy, sz, color, opt) {
    const Y = VA.norm(ay), Z = VA.norm(VA.cross(VA.norm(ax), Y)), X = VA.cross(Y, Z);
    _bx.set(X[0], X[1], X[2]); _by.set(Y[0], Y[1], Y[2]); _bz.set(Z[0], Z[1], Z[2]);
    _m4.makeBasis(_bx, _by, _bz); _e.setFromRotationMatrix(_m4);
    out.push(Object.assign({ sph: true, r: 1, sx, sy, sz, x: c[0], y: c[1], z: c[2], rx: _e.x, ry: _e.y, rz: _e.z, color, seg: 16 }, opt || {}));
  }
  // ================= 2.4: руки от первого лица =================
  // Кисть, перчатка и рукав — гладкие «лофт»-сетки: эллиптические сечения (кольца) вдоль осей пальцев, ладони и предплечья,
  // аналитические нормали (без швов и «бусин» на суставах), развёртка вдоль/поперёк (узор скина перчаток идёт по пальцам),
  // вершинные цвета панелей перчатки и мягкое затенение (складки между пальцами, ладонь, сухожилия на тыльной стороне).
  // Пропорции по живой руке в перчатке: ладонь ~8.5 см по костяшкам, пальцы 2 см толщиной, фаланги 4.5/2.6/2.1 см.
  // Позы кистей для каждого оружия — в таблице G.HOLD (см. ниже), сетка строится одинаково для любого хвата.
  const GLV_DEF = { back: '#4d524c', shell: '#1d1f21', finger: '#565b55', tip: '#44483f', pad: '#7a6a52', cuff: '#2a2c2f', strap: '#4a4e52', stitch: '#8b9087', joint: '#3a3e39', cut: null };
  // 2.5: перчатки по умолчанию у сторон разные: Спецназ — тактические «койот» с чёрными накладками и тёмной ладонью,
  // Налётчики — чёрные кожаные без пальцев (видны пальцы с ногтями)
  const GLV_CT = { back: '#86745a', shell: '#5c5142', finger: '#8a7a5f', tip: '#6f604a', pad: '#4b443c', knk: '#25262a', cuff: '#2c2a27', strap: '#5b5140', stitch: '#b4a27e', joint: '#3b342a', cut: null, def: 'ct' };
  const GLV_T = { back: '#303235', shell: '#1b1c1f', finger: '#303235', tip: '#2a2b2e', pad: '#3a3532', cuff: '#16171a', strap: '#45484e', stitch: '#7d8188', joint: '#141518', cut: 'fingerless', def: 't' };
  let GLV = GLV_DEF;
  // палитра перчаток из каталога скинов: [тыл, накладки, пальцы, кончики, манжета, ремешок]; бинты — без кончиков пальцев
  const glovePal = (gid, team) => {
    const sk = gid && G.SKINS && G.SKINS[gid];
    if (!sk || !sk.gl) return team === 1 || team === '1' ? GLV_T : team === 0 || team === '0' ? GLV_CT : GLV_DEF;
    const g = sk.gl;
    return { back: g[0], shell: g[1], finger: g[2], tip: g[3], pad: g[3], cuff: g[4], strap: g[5], stitch: g[5], joint: g[3], cut: sk.p === 'wrap' ? 'wrap' : null, k: sk.k };
  };
  const TAU = Math.PI * 2;
  const SKIN_C = '#9b7969'; // 2.5: естественнее (раньше #c08f6c — под тёплым светом рук выходил оранжевым)
  const _hc = new THREE.Color(), hexRGB = {};
  const rgb = (h) => hexRGB[h] || (hexRGB[h] = (_hc.set(h), [_hc.r, _hc.g, _hc.b]));
  const newM = () => ({ p: [], n: [], c: [], uv: [], i: [] });
  // кадры вдоль ломаной: T — касательная, X — «вбок» (lat) или Y = up; правая тройка X×Y = T; Y смотрит в сторону up
  function frames(P, lat, up) {
    const out = [];
    for (let i = 0; i < P.length; i++) {
      const T = VA.norm(VA.sub(P[Math.min(i + 1, P.length - 1)], P[Math.max(i - 1, 0)]));
      const u = typeof up === 'function' ? up(P[i], i) : up;
      let X, Y;
      if (lat) {
        X = VA.norm(VA.sub(lat, VA.mul(T, VA.dot(lat, T)))); Y = VA.cross(T, X);
        if (u && VA.dot(Y, u) < 0) { X = VA.mul(X, -1); Y = VA.mul(Y, -1); }
      } else {
        Y = VA.norm(VA.sub(u, VA.mul(T, VA.dot(u, T)))); X = VA.cross(Y, T);
      }
      // без перекручивания: соседние кадры смотрят в одну сторону
      if (out.length && VA.dot(out[out.length - 1].Y, Y) < -0.2) { X = VA.mul(X, -1); Y = VA.mul(Y, -1); }
      out.push({ T, X, Y });
    }
    return out;
  }
  // лофт: R — кольца { c, T, X, Y, a (полуось по X), b (по Y), e (степень суперэллипса), col (тыл, +Y), col2 (ладонь, −Y), sh (затенение),
  // bump (выпуклость тыльной стороны), wob (складки) }. Шов развёртки — на ладонной стороне (θ = 0 → −Y)
  function loft(M, R, seg, o) {
    o = o || {};
    const k = o.k || 22, base = M.p.length / 3, n1 = seg + 1;
    let v = o.v0 || 0;
    for (let r = 0; r < R.length; r++) {
      const q = R[r], pr = R[Math.max(0, r - 1)], nx_ = R[Math.min(R.length - 1, r + 1)];
      if (r) v += VA.len(VA.sub(q.c, pr.c));
      // наклон нормали из-за сужения трубки
      const dl = VA.len(VA.sub(nx_.c, pr.c)) || 1, dr = ((nx_.a + nx_.b) - (pr.a + pr.b)) * 0.5 / dl;
      const e = q.e || 2, per = Math.PI * (q.pab || (q.a + q.b)) * (o.uS || 1);
      const cA = rgb(q.col), cB = rgb(q.col2 || q.col), sh0 = q.sh == null ? 1 : q.sh;
      for (let j = 0; j <= seg; j++) {
        const th = j / seg * TAU, s = Math.sin(th), cc = -Math.cos(th);
        const ps = Math.sign(s) * Math.pow(Math.abs(s), 2 / e), pc = Math.sign(cc) * Math.pow(Math.abs(cc), 2 / e);
        let a = q.a, b = q.b;
        if (q.bump && cc > 0) b += q.bump * cc * cc;
        if (q.pad && cc < 0) b += q.pad * cc * cc; // 2.5: подушечки фаланг с ладонной стороны
        if (q.wob) { const w = 1 + q.wob * (Math.sin(2 * th + q.ph) + 0.6 * Math.sin(3 * th + q.ph * 1.7)); a *= w; b *= w; }
        const x = ps * a, y = pc * b;
        M.p.push(q.c[0] + q.X[0] * x + q.Y[0] * y, q.c[1] + q.X[1] * x + q.Y[1] * y, q.c[2] + q.X[2] * x + q.Y[2] * y);
        let nx, ny, nz;
        if (a < 1e-5) { const ad = q.ad || 1; nx = q.T[0] * ad; ny = q.T[1] * ad; nz = q.T[2] * ad; }
        else {
          const gx = Math.sign(s) * Math.pow(Math.abs(ps), e - 1) / a, gy = Math.sign(cc) * Math.pow(Math.abs(pc), e - 1) / b, gl = Math.hypot(gx, gy) || 1;
          const ux = gx / gl, uy = gy / gl;
          nx = q.X[0] * ux + q.Y[0] * uy - q.T[0] * dr; ny = q.X[1] * ux + q.Y[1] * uy - q.T[1] * dr; nz = q.X[2] * ux + q.Y[2] * uy - q.T[2] * dr;
        }
        const nl = Math.hypot(nx, ny, nz) || 1; M.n.push(nx / nl, ny / nl, nz / nl);
        // тыл → ладонь: плавный переход панелей; затенение: ладонная сторона и бока (щели между пальцами) темнее
        const w = G.clamp((cc + 0.15) / 0.5, 0, 1), wb = w * w * (3 - 2 * w);
        let shade = sh0 * (o.side ? 1 - o.side * Math.pow(Math.abs(s), 3) : 1) * (cc < 0 ? 1 - (o.palmDk || 0.12) * -cc : 1);
        if (o.shade) shade *= o.shade(q, s, cc, r);
        // 2.5: складки суставов — ладонная сторона (cr) и морщинки на тыле над суставом (dcr)
        if (q.cr && cc < 0) shade *= 1 - q.cr * Math.min(1, -cc * 1.6);
        if (q.dcr && cc > 0.2) shade *= 1 - q.dcr * Math.min(1, (cc - 0.2) * 2);
        let cr_ = cB[0] + (cA[0] - cB[0]) * wb, cg_ = cB[1] + (cA[1] - cB[1]) * wb, cb_ = cB[2] + (cA[2] - cB[2]) * wb;
        if (q.nail && cc > q.nail[0]) { const nc = rgb(q.nail[1]), t = G.clamp((cc - q.nail[0]) / 0.16, 0, 1); cr_ += (nc[0] - cr_) * t; cg_ += (nc[1] - cg_) * t; cb_ += (nc[2] - cb_) * t; }
        M.c.push(cr_ * shade, cg_ * shade, cb_ * shade);
        M.uv.push(j / seg * per * k + (o.u0 || 0), v * k);
      }
    }
    for (let r = 0; r < R.length - 1; r++) for (let j = 0; j < seg; j++) {
      const a = base + r * n1 + j, b = a + n1;
      M.i.push(a, a + 1, b, a + 1, b + 1, b);
    }
  }
  // кольца трубки по осевой P с полуосями A/Bs (массивы или числа) и цветами; cap — скруглённый торец (end/start)
  function tubeRings(P, F, A, Bs, col, opt) {
    opt = opt || {};
    const R = P.map((c, i) => ({ c, T: F[i].T, X: F[i].X, Y: F[i].Y, a: Array.isArray(A) ? A[i] : A, b: Array.isArray(Bs) ? Bs[i] : Bs, e: opt.e, col: Array.isArray(col) ? col[i] : col, col2: opt.col2 ? (Array.isArray(opt.col2) ? opt.col2[i] : opt.col2) : null, sh: opt.sh ? opt.sh[i] : 1, bump: opt.bump ? opt.bump[i] : 0 }));
    const cap = (q, dir, len, rev) => {
      const out = [];
      for (let i = 1; i <= 2; i++) {
        const f = i / 3 * Math.PI / 2, cf = Math.cos(f);
        out.push(Object.assign({}, q, { c: comb(q.c, q.T, dir * Math.sin(f) * len), a: q.a * cf, b: q.b * cf, bump: (q.bump || 0) * cf, pab: q.a + q.b }));
      }
      out.push(Object.assign({}, q, { c: comb(q.c, q.T, dir * len), a: 0, b: 0, bump: 0, ad: dir, pab: q.a + q.b }));
      return rev ? out.reverse() : out;
    };
    let out = R;
    if (opt.capEnd) out = out.concat(cap(R[R.length - 1], 1, opt.capEnd));
    if (opt.capStart) out = cap(R[0], -1, opt.capStart, true).concat(out);
    return out;
  }
  function meshGeo(M) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(M.p, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(M.n, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(M.c, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(M.uv, 2));
    g.setIndex(M.i);
    g.computeBoundingSphere();
    return g;
  }

  // ---------- хват: суставы пальцев вокруг предмета ----------
  // pose: C — центр хвата, A — ось предмета (от указательного к мизинцу), B — сторона костяшек, wrap — куда загибаются пальцы,
  // rb/rn — полуразмеры предмета по B и по направлению обхвата, fingers — 4 × {s — сдвиг по A, t:[θ0..θ3] — углы вокруг оси
  // (пальцы обхватывают по длине дуги с настоящими длинами фаланг), sc — толщина, ls — длина, pts — явные суставы [a, b, n]
  // в системе (A, B, N)}, thumb — 4 точки [a, b, n] или [[x, y, z]] (абсолютные), W или Wl — запястье (абсолютно или в (A, B, N))
  const FLEN = [[0.043, 0.025, 0.02], [0.046, 0.028, 0.021], [0.044, 0.026, 0.02], [0.035, 0.02, 0.018]];
  function solveHand(h) {
    const A = VA.norm(h.A), B = VA.norm(h.B);
    let N = VA.norm(VA.cross(B, A)); if (VA.dot(N, h.wrap) < 0) N = VA.mul(N, -1);
    const W = h.Wl ? comb(h.C, A, h.Wl[0], B, h.Wl[1], N, h.Wl[2]) : h.W;
    const fr = 0.0086;
    const P = (th, s, ex) => comb(h.C, A, s, B, Math.cos(th) * (h.rb + fr + (ex || 0)), N, Math.sin(th) * (h.rn + fr + (ex || 0)));
    const fingers = h.fingers.map((f, fi) => {
      let pts;
      if (f.pts) pts = f.pts.map(q => Array.isArray(q[0]) ? q[0] : comb(h.C, A, q[0], B, q[1], N, q[2]));
      else {
        const L = FLEN[Math.min(3, fi)], ex = [0.007, 0, -0.001, -0.003];
        const rb = h.rb + fr, rn = h.rn + fr, lim = f.t[3] + 0.9;
        let th = f.t[0];
        pts = [P(th, f.s, ex[0])];
        for (let j = 0; j < 3; j++) {
          let rem = L[j] * (f.ls || 1);
          while (rem > 1e-5 && th < lim) { const d = Math.min(rem, 0.003); th += d / Math.max(0.006, Math.hypot(rb * Math.sin(th), rn * Math.cos(th))); rem -= d; }
          pts.push(P(Math.min(th, lim), f.s, ex[j + 1]));
        }
      }
      return { pts, sc: f.sc || (fi === 3 ? 0.86 : fi === 2 ? 0.96 : 1) };
    });
    const thumb = h.thumb ? h.thumb.map(q => Array.isArray(q[0]) ? q[0] : comb(h.C, A, q[0], B, q[1], N, q[2])) : null;
    return { A, B, N, C: h.C, W, fingers, thumb };
  }

  // ---------- сетка кисти ----------
  // Mg — перчатка, Ms — открытая кожа (бинты без кончиков пальцев). Возвращает кадр запястья для манжеты
  function handMesh(Mg, Ms, h) {
    const H = solveHand(h), { A, C, W } = H, k = GLV.k || 22;
    // «наружу» от оси предмета — тыльная сторона пальцев
    const outw = (p) => { const d = VA.sub(p, C), ax = VA.mul(A, VA.dot(d, A)); return VA.norm(VA.sub(d, ax)); };
    const mc = H.fingers.map(f => f.pts[0]);
    const k0 = mc[0], k1 = mc[mc.length - 1], km = VA.mix(k0, k1, 0.5), lat = VA.norm(VA.sub(k1, k0));
    const wid = VA.len(VA.sub(k1, k0));
    // ладонь: суперэллипс от запястья к костяшкам, тыл — по нормали «наружу» у костяшек. Ширина и сдвиг торца у костяшек —
    // по фактическому положению оснований пальцев (любая поза: торец ладони накрывает все костяшки)
    const up = outw(km), D = VA.norm(VA.sub(km, W));
    const PF0 = frames([W, km], null, up)[1];
    let x0 = 1, x1 = -1, Lp = 0;
    for (const p of mc) { const d = VA.sub(p, W), x = VA.dot(d, PF0.X); x0 = Math.min(x0, x); x1 = Math.max(x1, x); Lp = Math.max(Lp, VA.dot(d, D)); }
    const xc = (x0 + x1) / 2, wk = (x1 - x0) / 2;
    const palmT = [0, 0.3, 0.62, 0.88, 1.0];
    const hw = [0.0265, 0.031, wk + 0.0088, wk + 0.0098, wk + 0.0092];
    const ht = [0.0185, 0.016, 0.0138, 0.012, 0.011];
    const shift = [0, -0.0035, -0.0028, -0.001, 0];
    const PP = palmT.map((t, i) => comb(W, D, Lp * t, up, shift[i], PF0.X, xc * Math.min(1, t * 1.4)));
    const PF = frames(PP, null, up);
    // сухожилия/кости пясти — лёгкие тени на тыльной стороне, ближе к костяшкам
    // + панель тыла: центральная накладка светлее, по краю — шов (темнее), бока кисти — в тени
    const tend = (q, s, cc, r) => {
      if (cc < 0.3) return 1;
      let k = Math.abs(s) > 0.62 ? 0.84 : 1.05;
      if (r >= 2 && r <= 4) k *= 1 - 0.08 * (0.5 + 0.5 * Math.cos(s * Math.PI * 3));
      return k;
    };
    loft(Mg, tubeRings(PP, PF, hw, ht, GLV.back, { e: 2.25, col2: GLV.pad, capEnd: 0.008, bump: [0.001, 0.0028, 0.0032, 0.0024, 0.0016] }), 16, { k, side: 0.05, shade: tend });
    // накладка на костяшках: плоская «капсула» поперёк кисти по линии костяшек
    const KP = [comb(k0, lat, -0.005), VA.mix(k0, k1, 0.3), VA.mix(k0, k1, 0.7), comb(k1, lat, 0.003)].map(p => comb(p, up, 0.0114, D, -0.002));
    const KF = frames(KP, null, up);
    loft(Mg, tubeRings(KP, KF, 0.0082, [0.0032, 0.0046, 0.0044, 0.003], GLV.knk || GLV.shell, { e: 2.4, capEnd: 0.005, capStart: 0.005 }), 6, { k, palmDk: 0.3 });
    // 2.5: пальцы по анатомическому профилю (см. digit): фаланги сужаются к кончику, костяшки и подушечки, складки суставов,
    // панели перчатки с чёткой границей и швом; перчатки без пальцев и бинты — дальше открытая кожа с ногтями
    const cutF = GLV.cut === 'fingerless' ? [0, 0.6] : GLV.cut === 'wrap' ? [1, 0.5] : null;
    const cutT = GLV.cut === 'fingerless' ? [2, 0.5] : GLV.cut === 'wrap' ? [3, 0.05] : null;
    H.fingers.forEach((f, fi) => {
      const [m, p1, p2, tip] = f.pts, sc = f.sc;
      digit(Mg, Ms, [m, p1, p2, tip], FPROF, { ra: 0.0094 * sc, rb: 0.0082 * sc, lat: A, up: outw, cut: cutF, nail: 2, tipLen: 0.0072 * sc, seg: 12, side: 0.16, u0: fi * 0.37, k });
    });
    // большой палец: от возвышения у запястья (толстое основание растворяется в ладони) через три фаланги
    if (H.thumb) {
      const [t0, t1, t2, t3] = H.thumb;
      const b0 = comb(VA.mix(W, t0, 0.5), D, 0.004, up, -0.006);
      digit(Mg, Ms, [b0, t0, t1, t2, t3], TPROF, { ra: 0.0107, rb: 0.0095, lat: null, up: outw, cut: cutT, nail: 3, tipLen: 0.0078, seg: 12, side: 0.1, u0: 0.2, k });
    }
    return { W, lat, up, km, H };
  }
  // ---------- 2.5: палец по профилю ----------
  // s — [сегмент ломаной суставов, доля], a/b — множители полуосей (ширина/толщина), pad — подушечка с ладонной стороны (м),
  // bump — костяшка на тыле (м), cr / dcr — складка сустава на ладони / морщинки на тыле, z — панель перчатки
  // (back — тыл кисти, pad — мягкая накладка на основной фаланге, fin — палец, tip — усиленный кончик)
  const FPROF = [
    { s: [0, -0.24], a: 1.06, b: 1.0, z: 'back', sh: 0.88 },
    { s: [0, 0], a: 1.04, b: 0.99, bump: 0.0009, z: 'back', sh: 0.95 },
    { s: [0, 0.2], a: 0.99, b: 0.95, pad: 0.0004, cr: 0.16, z: 'pad' },
    { s: [0, 0.45], a: 0.96, b: 0.92, pad: 0.0011, z: 'pad' },
    { s: [0, 0.72], a: 0.94, b: 0.9, pad: 0.0009, z: 'pad' },
    { s: [0, 0.92], a: 0.925, b: 0.88, cr: 0.36, z: 'fin' },
    { s: [1, 0.04], a: 0.94, b: 0.895, bump: 0.0013, dcr: 0.12, z: 'fin' },
    { s: [1, 0.48], a: 0.88, b: 0.84, pad: 0.0009, z: 'fin' },
    { s: [1, 0.88], a: 0.855, b: 0.815, cr: 0.3, z: 'fin' },
    { s: [2, 0.04], a: 0.86, b: 0.815, bump: 0.0008, dcr: 0.08, z: 'tip' },
    { s: [2, 0.38], a: 0.845, b: 0.8, pad: 0.0012, z: 'tip' },
    { s: [2, 0.7], a: 0.815, b: 0.77, pad: 0.0014, z: 'tip' },
    { s: [2, 0.9], a: 0.76, b: 0.71, pad: 0.0011, z: 'tip' }
  ];
  // большой палец: [основание в ладони, возвышение, пястно-фаланговый, межфаланговый, кончик]
  const TPROF = [
    { s: [0, 0], a: 1.55, b: 1.42, z: 'back', sh: 0.9 },
    { s: [1, 0], a: 1.26, b: 1.22, z: 'back', sh: 0.95 },
    { s: [1, 0.5], a: 1.1, b: 1.08, z: 'back' },
    { s: [1, 0.94], a: 1.02, b: 1.0, bump: 0.0007, z: 'fin' },
    { s: [2, 0.12], a: 1.0, b: 0.97, bump: 0.0009, cr: 0.2, z: 'fin' },
    { s: [2, 0.5], a: 0.97, b: 0.93, pad: 0.0012, z: 'pad' },
    { s: [2, 0.9], a: 0.95, b: 0.9, cr: 0.32, z: 'fin' },
    { s: [3, 0.04], a: 0.96, b: 0.9, bump: 0.001, dcr: 0.1, z: 'tip' },
    { s: [3, 0.4], a: 0.93, b: 0.87, pad: 0.0014, z: 'tip' },
    { s: [3, 0.74], a: 0.88, b: 0.82, pad: 0.0014, z: 'tip' },
    { s: [3, 0.92], a: 0.8, b: 0.74, pad: 0.001, z: 'tip' }
  ];
  const SKIN_P = '#a8877a', SKIN_K = '#94695b', NAIL = '#b9998f', NAIL_E = '#cbb7ad';
  const ptAt = (pts, s) => { const i = Math.max(0, Math.min(pts.length - 2, s[0])); return comb(pts[i], VA.sub(pts[i + 1], pts[i]), s[1]); };
  const sAbs = (s) => s[0] + s[1];
  // промежуточное кольцо между двумя (t — доля)
  function ringMix(r0, r1, t) {
    const o = Object.assign({}, t < 0.5 ? r0 : r1);
    o.c = VA.mix(r0.c, r1.c, t); o.T = VA.norm(VA.mix(r0.T, r1.T, t)); o.X = VA.norm(VA.mix(r0.X, r1.X, t)); o.Y = VA.norm(VA.mix(r0.Y, r1.Y, t));
    for (const k of ['a', 'b', 'pad', 'bump', 'sh']) o[k] = (r0[k] || 0) + ((r1[k] || 0) - (r0[k] || 0)) * t;
    o.cr = 0; o.dcr = 0; o.sa = r0.sa + (r1.sa - r0.sa) * t;
    return o;
  }
  // скруглённый кончик: три кольца по четверти окружности вдоль T
  function capRings(q, len) {
    const out = [];
    for (let i = 1; i <= 3; i++) {
      const f = i / 3.4 * Math.PI / 2, cf = Math.cos(f), last = i === 3;
      out.push(Object.assign({}, q, { c: comb(q.c, q.T, Math.sin(f) * len), a: last ? 0 : q.a * Math.pow(cf, 0.8), b: last ? 0 : q.b * Math.pow(cf, 1.25), pad: (q.pad || 0) * cf, bump: 0, cr: 0, dcr: 0, ad: 1, pab: q.a + q.b, nail: i === 1 ? q.nail : null }));
    }
    out[2].c = comb(q.c, q.T, len);
    return out;
  }
  function digit(Mg, Ms, pts, prof, o) {
    const zc = { back: GLV.back, pad: GLV.shell, fin: GLV.finger, tip: GLV.tip };
    const P = prof.map(q => ptAt(pts, q.s)), F = frames(P, o.lat, (p) => o.up(p));
    const R = prof.map((q, i) => ({ c: P[i], T: F[i].T, X: F[i].X, Y: F[i].Y, a: o.ra * q.a, b: o.rb * q.b, e: 2.1, pad: q.pad || 0, bump: q.bump || 0,
      cr: q.cr || 0, dcr: q.dcr || 0, sh: q.sh == null ? 1 : q.sh, z: q.z, sa: sAbs(q.s), col: zc[q.z], col2: GLV.pad }));
    const side = { k: o.k, side: o.side, u0: o.u0 };
    // перчатка: на смене панели — шов (тёмное узкое кольцо с лёгкой канавкой) и чёткая граница цвета
    const glove = (rings) => {
      const out = [];
      rings.forEach((r, i) => {
        if (i && r.z !== rings[i - 1].z && r.col !== rings[i - 1].col) {
          const p = rings[i - 1], a = ringMix(p, r, 0.42), s = ringMix(p, r, 0.5), b = ringMix(p, r, 0.58);
          a.col = p.col; a.col2 = p.col2;
          s.col = s.col2 = GLV.joint || '#2a2c2a'; s.a *= 0.985; s.b *= 0.985; s.sh = 0.7;
          b.col = r.col; b.col2 = r.col2;
          out.push(a, s, b);
        }
        out.push(r);
      });
      return out;
    };
    // кожа: чуть тоньше перчатки, костяшки и кончики розовее, ноготь на тыле последней фаланги
    const skin = (r) => {
      const s = Object.assign({}, r, { a: r.a * 0.85, b: r.b * 0.84, pad: r.pad * 1.3, col: r.bump > 0.0007 ? SKIN_K : SKIN_C, col2: SKIN_P });
      const sg = Math.floor(r.sa + 1e-6), f = r.sa - sg;
      if (sg === o.nail && f > 0.25) { s.nail = [0.55, f > 0.86 ? NAIL_E : NAIL]; s.bump = Math.max(s.bump, 0.0004); }
      return s;
    };
    if (!o.cut) {
      const Rg = glove(R), last = Rg[Rg.length - 1];
      loft(Mg, Rg.concat(capRings(last, o.tipLen)), o.seg, side);
      return;
    }
    // без пальцев / бинты: перчатка до среза с подвёрнутым краем, дальше — палец из кожи (заходит под край)
    const cs = sAbs(o.cut);
    let j = R.findIndex(r => r.sa > cs); if (j < 1) j = 1;
    const t = (cs - R[j - 1].sa) / Math.max(1e-6, R[j].sa - R[j - 1].sa), rc = ringMix(R[j - 1], R[j], G.clamp(t, 0, 1));
    const hem = GLV.cuff || GLV.back, wrap = GLV.cut === 'wrap';
    const h0 = Object.assign({}, rc, { a: rc.a * (wrap ? 1.07 : 1.05), b: rc.b * (wrap ? 1.08 : 1.06), col: wrap ? rc.col : hem, col2: wrap ? rc.col2 : hem, pad: 0, bump: 0 });
    const h1 = Object.assign({}, h0, { c: comb(rc.c, rc.T, 0.0016), sh: 0.85 });
    const h2 = Object.assign({}, h0, { c: comb(rc.c, rc.T, 0.0021), a: rc.a * 0.86, b: rc.b * 0.86, sh: 0.55 });
    loft(Mg, glove(R.slice(0, j)).concat([Object.assign({}, rc, { cr: 0, dcr: 0 }), h0, h1, h2]), o.seg, side);
    const s0 = Object.assign({}, rc, { c: comb(rc.c, rc.T, -0.005), pad: 0, bump: 0, cr: 0, dcr: 0 });
    const Rs = [s0, rc].concat(R.slice(j)).map(skin);
    loft(Ms, Rs.concat(capRings(Rs[Rs.length - 1], o.tipLen * 0.95)), o.seg + 4, Object.assign({}, side, { palmDk: 0.06 }));
  }

  // ---------- манжета перчатки и рукав ----------
  // W — запястье, E — локоть, Sh — плечо; lat/up — оси ладони (сечение запястья шире, чем толще). Рукав кончается
  // на предплечье ровным обшлагом (манжета перчатки уходит под него), а не заполняет угол экрана
  function armParts(Mg, Ms, W, E, Sh, lat, up, opt) { // Ms — рукав
    opt = opt || {};
    const D = VA.norm(VA.sub(E, W)), FL = VA.len(VA.sub(E, W)), k = GLV.k || 22;
    // манжета: от ладони за запястье, ремешок с липучкой — ступенька наружу
    const cd = [-0.014, 0, 0.0165, 0.0175, 0.043, 0.044, 0.066];
    const ca = [0.0262, 0.0278, 0.0288, 0.0312, 0.0322, 0.0298, 0.0308];
    const cb = [0.0186, 0.0204, 0.0214, 0.0238, 0.0248, 0.0224, 0.0234];
    const ccol = [GLV.cuff, GLV.cuff, GLV.cuff, GLV.strap, GLV.strap, GLV.cuff, GLV.cuff];
    const CP = cd.map(d => comb(W, D, d)), CF = frames(CP, lat, up);
    loft(Mg, tubeRings(CP, CF, ca, cb, ccol, { e: 2.3, capEnd: opt.noSleeve ? 0.004 : 0 }), 12, { k, palmDk: 0.1 });
    // язычок липучки на ремешке (снаружи, сбоку от тыла)
    const tc = comb(W, D, 0.0302), tY = VA.norm(VA.add(CF[3].Y, VA.mul(CF[3].X, 0.55))), tX = VA.norm(VA.cross(D, tY));
    const tz = [comb(tc, tX, -0.009), comb(tc, tX, 0.009)].map(p => comb(p, tY, 0.0262 + 0.0014));
    loft(Mg, tubeRings(tz, frames(tz, null, tY), 0.0118, 0.0018, GLV.strap, { e: 3, capEnd: 0.003, capStart: 0.003, sh: [0.85, 0.85] }), 4, { k });
    if (opt.noSleeve || !Ms) return;
    // рукав: обшлаг (подрубленный край чуть темнее) → ткань с мягкими складками → локоть → плечо (за кадром)
    const sd = [0.054, 0.056, 0.06, 0.082, 0.085], sa = [0.0318, 0.0352, 0.0362, 0.0368, 0.0358], sb = [0.0262, 0.0296, 0.0306, 0.0312, 0.0302];
    const scol = ['#5a5a5a', '#9a9a9a', '#d0d0d0', '#d0d0d0', '#f0f0f0'];
    const n = 4;
    for (let i = 1; i <= n; i++) {
      const d = 0.085 + (FL - 0.085) * (i / n), t = i / n;
      sd.push(d); sa.push(0.0365 + 0.0085 * t); sb.push(0.031 + 0.008 * t); scol.push('#ffffff');
    }
    const SP = sd.map(d => comb(W, D, Math.min(d, FL)));
    SP.push(VA.mix(E, Sh, 0.5), Sh); sa.push(0.046, 0.05); sb.push(0.042, 0.047); scol.push('#ffffff', '#ffffff');
    const SF = frames(SP, lat, up);
    const R = tubeRings(SP, SF, sa, sb, scol, { e: 2.1 });
    // складки ткани: волна по окружности, сильнее у обшлага и у локтя; смещение фазы — чтобы складки «закручивались»
    R.forEach((q, i) => { if (i >= 4 && i < R.length - 2) { q.wob = 0.035 * (i % 2 ? 1 : -0.7); q.ph = i * 1.3; } });
    const fold = (q, s, cc, r) => (q.wob ? 1 - 0.06 * Math.max(0, Math.sin(r * 2.1 + s * 2.5)) : 1);
    loft(Ms, R, 12, { k: 5, palmDk: 0.16, shade: fold, uS: 1 });
  }
  // для совместимости: простые детали-примитивы (рукоятки, кольца) по-прежнему через bone/blob/ring
  G.mk = { bone, blob, ring, comb, VA, frames, loft, tubeRings, solveHand };

  const rivet = (x, y, z, c) => ({ cyl: true, r: 0.0028, h: 0.004, x, y, z, rz: HP, color: c || MET2, m: true, seg: 8 });
  const dot = (x, y, z, c, r) => ({ sph: true, r: r || 0.0018, x, y, z, color: c || '#f4f4ee', em: true, seg: 8 });
  // насечки поперёк детали (тёмные канавки), n штук от f0 с шагом step
  const ser = (n, f0, step, y, h, w, c) => Array.from({ length: n }, (_, i) => box(w, h, 0.0022, 0, y, -(f0 + i * step), c || '#0e0f11'));
  const trig = (f, y, c) => mprof([[f, y], [f + 0.008, y], ['q', f + 0.009, y - 0.021, f - 0.004, y - 0.032], [f - 0.009, y - 0.029], ['q', f + 0.002, y - 0.018, f, y]], 0.005, c || MET2);
  const swivel = (y, z) => ({ torus: true, r: 0.009, tube: 0.0022, x: 0, y, z, ry: HP, color: MET, m: true, seg: 12 });
  // ---------- 2.0.1: общие заготовки для стволов ----------
  // скруглённый прямоугольник (точки профиля или сечения)
  const rrect = (x0, y0, x1, y1, r) => [[x0 + r, y0], [x1 - r, y0], ['q', x1, y0, x1, y0 + r], [x1, y1 - r], ['q', x1, y1, x1 - r, y1], [x0 + r, y1], ['q', x0, y1, x0, y1 - r], [x0, y0 + r], ['q', x0, y0, x0 + r, y0]];
  // сечение (x, y), выдавленное вдоль ствола от f0 до f1 (фаска скругляет и торцы, и рёбра сечения)
  const xs = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
  // «арка»: плоский низ y0, вертикальные борта ±w до y1, скруглённый верх до y2
  const archS = (w, y0, y1, y2) => [[-w, y0], [w, y0], [w, y1], ['q', w, y2, 0, y2], ['q', -w, y2, -w, y1]];
  // цилиндр по оси ствола: r — у казённой части (f0), r2 — у дульной (f1)
  const cz = (r, f0, f1, y, color, o) => Object.assign({ cyl: true, r, h: f1 - f0, x: 0, y, z: -(f0 + f1) / 2, rx: HP, color: color || MET, seg: 12, m: true }, o || {});
  // поперечный штифт/заклёпки на обоих бортах (одна деталь насквозь)
  const pinT = (f, y, w, r, c) => ({ cyl: true, r: r || 0.0024, h: w, x: 0, y, z: -f, rz: HP, color: c || MET2, m: true, seg: 6 });
  // планка Пикатинни: основание и поперечные зубья
  const picL = (f0, f1, y, w, c) => { const o = [mbox(w, 0.0062, f1 - f0, 0, y, -(f0 + f1) / 2, c || BLK)]; for (let f = f0 + 0.005; f < f1 - 0.003; f += 0.0118) o.push(mbox(w + 0.003, 0.0042, 0.0046, 0, y + 0.0045, -f, c || BLK)); return o; };
  // боковая планка (на борту цевья): sx — сторона, y — центр
  const picS = (f0, f1, y, sx, x, c) => { const o = [mbox(0.0062, 0.02, f1 - f0, sx * x, y, -(f0 + f1) / 2, c || BLK)]; for (let f = f0 + 0.005; f < f1 - 0.003; f += 0.0118) o.push(mbox(0.0042, 0.023, 0.0046, sx * (x + 0.0045), y, -f, c || BLK)); return o; };
  // кольцо вокруг оси ствола
  const ringZ = (r, tube, f, y, c, seg) => ({ torus: true, r, tube, x: 0, y, z: -f, color: c || MET2, m: true, seg: seg || 14 });
  // оптический прицел вдоль оси y: окуляр (сзади, f0) — труба — объектив (спереди, f1); турели на середине
  // o: { rt — труба, ro — объектив, re — окуляр, tf — f турелей, len — длина колокола объектива, ring: [f…] — кольца крепления, base — y основания колец }
  function scopeParts(f0, f1, y, o) {
    const rt = o.rt, ro = o.ro, re = o.re, tf = o.tf, lo = o.len || 0.08, le = o.le || 0.07, C = o.c || BLK, sk = o.skin || null;
    const S = (p) => (sk ? Object.assign(p, { skin: sk, m: false }) : p);
    const out = [
      // окуляр: наглазник-резина, кольцо диоптрийки, колокол к трубе
      cz(re + 0.0025, f0 - 0.012, f0, y, '#111214', { seg: 18, m: false }),
      S(cz(re, f0, f0 + le * 0.45, y, C, { seg: 18 })), ringZ(re + 0.0004, 0.0014, f0 + le * 0.18, y, '#2a2c2f', 18),
      S(cz(re, f0 + le * 0.45, f0 + le, y, C, { r2: rt, seg: 18 })),
      // труба
      S(cz(rt, f0 + le, f1 - lo, y, C, { seg: 16 })),
      // колокол объектива и бленда
      S(cz(rt, f1 - lo, f1 - lo * 0.45, y, C, { r2: ro, seg: 20 })), S(cz(ro, f1 - lo * 0.45, f1, y, C, { seg: 20 })),
      ringZ(ro + 0.0003, 0.0015, f1 - 0.006, y, '#2a2c2f', 20),
      { cyl: true, r: ro - 0.002, h: 0.003, x: 0, y, z: -(f1 - 0.004), rx: HP, color: '#2a7fb0', g: true, seg: 20 },
      { cyl: true, r: re - 0.0015, h: 0.003, x: 0, y, z: -(f0 - 0.011), rx: HP, color: '#123247', g: true, seg: 18 },
      // седло турелей, вертикальная (сверху) и боковая (справа) турели с колпачками и рифлением, слева — параллакс
      S(cz(rt + 0.004, tf - 0.024, tf + 0.024, y, C, { seg: 16 })),
      { cyl: true, r: rt * 0.62, h: rt + 0.016, x: 0, y: y + (rt + 0.016) / 2, z: -tf, color: C, m: true, seg: 14 },
      { cyl: true, r: rt * 0.66, h: 0.009, x: 0, y: y + rt + 0.0115, z: -tf, color: '#2a2c2f', m: true, seg: 14 },
      { cyl: true, r: rt * 0.62, h: rt + 0.016, x: (rt + 0.016) / 2, y, z: -tf, rz: HP, color: C, m: true, seg: 14 },
      { cyl: true, r: rt * 0.66, h: 0.009, x: rt + 0.0115, y, z: -tf, rz: HP, color: '#2a2c2f', m: true, seg: 14 },
      { cyl: true, r: rt * 0.52, h: rt + 0.01, x: -(rt + 0.01) / 2, y, z: -tf, rz: HP, color: C, m: true, seg: 12 }
    ];
    // кольца крепления на планке: хомут вокруг трубы, стойка, винты
    for (const f of o.ring || []) {
      out.push(ringZ(rt + 0.003, 0.0034, f, y, BLK, 12),
        mprof([[f - 0.009, o.base], [f + 0.009, o.base], [f + 0.007, y - rt * 0.4], [f - 0.007, y - rt * 0.4]], rt * 1.5, BLK, { bevel: 0.0015, bseg: 1 }),
        pinT(f, o.base + 0.007, rt * 1.5 + 0.004, 0.0024, MET2));
    }
    return out;
  }

  // 2.5: сошки (как Harris) в сложенном виде под цевьём: колодка на планке, корпус шарнира с осью и пружинами, две ноги вперёд
  // вдоль ствола — верхняя труба, выдвижная часть с проточками, резиновые пятки. f0 — шарнир (вперёд от коробки), y — низ цевья,
  // w — полуколея, len — длина сложенной ноги
  function bipod(f0, y, w, len) {
    const L = len || 0.21, yl = y - 0.012;
    const out = [
      mbox(0.024, 0.009, 0.036, 0, y - 0.003, -(f0 - 0.014), BLK),
      mprof([[f0 - 0.008, y - 0.006], [f0 + 0.009, y - 0.006], [f0 + 0.008, yl - 0.006], [f0 - 0.006, yl - 0.006]], 2 * w + 0.008, '#1c1d20', { bevel: 0.0015, bseg: 1 }),
      { cyl: true, r: 0.0036, h: 2 * w + 0.014, x: 0, y: yl + 0.001, z: -f0, rz: HP, color: MET2, m: true, seg: 10 }
    ];
    for (const sx of [1, -1]) {
      const x = sx * w;
      out.push(tube(0.0058, f0, f0 + L * 0.6, yl, '#1d1f22', x, null, 12),
        tube(0.0064, f0 + L * 0.6 - 0.009, f0 + L * 0.6, yl, '#2a2d31', x, null, 12),
        tube(0.0041, f0 + L * 0.6, f0 + L * 0.95, yl, MET2, x, null, 10),
        ...[0.68, 0.74, 0.8, 0.86].map(t => ({ torus: true, r: 0.0041, tube: 0.0007, x, y: yl, z: -(f0 + L * t), color: '#0f1012', m: true, seg: 10 })),
        { sph: true, r: 0.0072, x, y: yl, z: -(f0 + L * 0.975), sz: 1.35, color: '#151617', seg: 10 },
        tube(0.0016, f0 - 0.034, f0 - 0.004, yl + 0.0045, '#3c4046', x * 0.55, null, 6));
    }
    return out;
  }
  // ---------- M4: общая платформа M4A1-S (sil) и M4A4 ----------
  function m4Parts(sil) {
      // M4A1-S (как в CS2): верхняя коробка flat-top со ступенькой под планкой, окно экстракции с открытой крышкой,
      // досылатель и отражатель гильз; круглое цевьё с рядами вентиляционных окон и дельта-кольцом; длинный тонкий глушитель
      // с поясками и фаской на торце; откидные мушка и целик с диоптром; изогнутый STANAG с рёбрами; рукоять A2; приклад «крейн»
      const BY = 0.021; // ось канала ствола
      const AC = '#1e2124', PC = '#232528', SC = '#2e3135', GRV = '#0c0d0f', BR = '#b08a3e'; // цвета для мировой модели и прорезей
      const pic = (f0, f1, y, w) => { const o = [mbox(w, 0.0065, f1 - f0, 0, y, -(f0 + f1) / 2, BLK)]; for (let f = f0 + 0.005; f < f1 - 0.003; f += 0.0118) o.push(mbox(w + 0.003, 0.0042, 0.0046, 0, y + 0.0045, -f, BLK)); return o; };
      const cylZ = (r, f0, f1, color, o) => Object.assign({ cyl: true, r, h: f1 - f0, x: 0, y: BY, z: -(f0 + f1) / 2, rx: HP, color, seg: 12, m: true }, o || {});
      const pinX = (f, y, r, c) => ({ cyl: true, r, h: 0.0472, x: 0, y, z: -f, rz: HP, color: c || MET2, m: true, seg: 10 });
      // вентиляционное окно на круглом цевье: φ — угол от правого борта вверх
      const HR = 0.0268;
      const vent = (f, phi, len) => box(0.0024, 0.0062, len || 0.019, Math.cos(phi) * (HR - 0.0006), BY + Math.sin(phi) * (HR - 0.0006), -f, GRV, 0, 0, phi);
      const D2R = Math.PI / 180;
      const VA0 = [18, 162, -18, -162, -90].map(a => a * D2R);
      // короткие боковые планки у торца цевья
      const sideRail = (sx) => [mbox(0.005, 0.016, 0.05, sx * 0.027, BY, -0.359, BLK), ...[0.341, 0.352, 0.363, 0.374].map(f => box(0.004, 0.019, 0.0046, sx * 0.0296, BY, -f, BLK))];
      // откидной целик: основание, лист с диоптром, защитные «уши», барабанчик поправок
      const rs = 0.13; // z целика
      const rearSight = [
        mbox(0.025, 0.007, 0.03, 0, 0.0565, rs, BLK),
        mbox(0.0146, 0.012, 0.0036, 0, 0.065, rs + 0.0005, BLK),
        ...[1, -1].map(s => mprof([[-0.143, 0.059], [-0.12, 0.059], [-0.124, 0.07], [-0.132, 0.0835], [-0.138, 0.0835], [-0.141, 0.072]], 0.0034, BLK, { x: s * 0.0092, bevel: 0.0008, bseg: 1 })),
        { torus: true, r: 0.0036, tube: 0.0015, x: 0, y: 0.0745, z: rs + 0.0005, color: BLK, m: true, seg: 10 },
        { cyl: true, r: 0.0022, h: 0.0012, x: 0, y: 0.0745, z: rs + 0.001, rx: HP, color: '#050505', seg: 8 },
        { cyl: true, r: 0.0042, h: 0.005, x: 0.0148, y: 0.0618, z: rs, rz: HP, color: MET2, m: true, seg: 10 }
      ];
      // откидная мушка на передней планке: основание, «уши», мушка-штырёк
      const fs = -0.372;
      const frontSight = [
        mbox(0.024, 0.007, 0.026, 0, 0.0565, fs, BLK),
        mprof([[0.36, 0.059], [0.384, 0.059], [0.381, 0.067], [0.374, 0.067], ['q', 0.372, 0.083, 0.369, 0.083], [0.364, 0.083], [0.362, 0.068]], 0.0035, BLK, { x: 0.0078, bevel: 0.0008, bseg: 1 }),
        mprof([[0.36, 0.059], [0.384, 0.059], [0.381, 0.067], [0.374, 0.067], ['q', 0.372, 0.083, 0.369, 0.083], [0.364, 0.083], [0.362, 0.068]], 0.0035, BLK, { x: -0.0078, bevel: 0.0008, bseg: 1 }),
        mprof([[0.363, 0.059], [0.377, 0.059], [0.372, 0.066], [0.366, 0.066]], 0.012, BLK, { bevel: 0.001 }),
        mbox(0.0028, 0.016, 0.0028, 0, 0.073, fs + 0.0015, MET2)
      ];
      // изогнутый магазин STANAG: корпус, рёбра жёсткости вдоль изгиба, крышка, патрон сверху
      const magCurve = (a, b, y0, y1) => [[a, y0], [b, y0], ['q', b + 0.003, (y0 + y1) / 2 - 0.006, b + 0.021, y1], [a + 0.021 + (a > 0.045 ? 0.002 : 0), y1 - 0.004], ['q', a + 0.003, (y0 + y1) / 2 - 0.006, a, y0]];
    const picS = (f0, f1, y, sx, x) => { const o = [mbox(0.0062, 0.02, f1 - f0, sx * x, y, -(f0 + f1) / 2, BLK)]; for (let f = f0 + 0.005; f < f1 - 0.003; f += 0.0118) o.push(mbox(0.0042, 0.023, 0.0046, sx * (x + 0.0045), y, -f, BLK)); return o; };
    // нижняя и верхняя коробки, органы управления, рукоять
    const c1 = [
          // верхняя коробка: нижний широкий пояс и узкая верхняя часть со ступенькой под планкой
          prof([[-0.158, 0.004], [0.142, 0.004], [0.142, 0.034], [-0.158, 0.034]], 0.044, AC, 'a', { bevel: 0.003 }),
          prof([[-0.156, 0.03], [0.142, 0.03], [0.142, 0.0435], [-0.15, 0.0435], ['q', -0.156, 0.0435, -0.156, 0.038]], 0.034, AC, 'a', { bevel: 0.0025 }),
          ...pic(-0.152, 0.14, 0.0466, 0.024),
          // окно экстракции, открытая пылезащитная крышка на шарнире, отражатель гильз
          box(0.0012, 0.0165, 0.056, 0.0222, 0.0235, -0.03, '#08090a'),
          mbox(0.0016, 0.017, 0.058, 0.0258, 0.0076, -0.03, MET, 0, 0, 0.42), { cyl: true, r: 0.0016, h: 0.062, x: 0.0226, y: 0.015, z: -0.03, rx: HP, color: MET2, m: true, seg: 8 },
          mbox(0.002, 0.0024, 0.03, 0.0274, 0.0083, -0.03, MET2, 0, 0, 0.42),
          mprof([[-0.017, 0.022], [-0.002, 0.022], [-0.002, 0.041], ['q', -0.012, 0.041, -0.017, 0.031]], 0.007, BLK, { x: 0.0235, bevel: 0.0012, bseg: 1, cs: 3 }),
          // досылатель: прилив, корпус-цилиндр и кнопка с проточками
          mprof([[-0.112, 0.016], [-0.058, 0.016], ['q', -0.064, 0.04, -0.09, 0.04], [-0.112, 0.04]], 0.008, BLK, { x: 0.0225, bevel: 0.002, bseg: 1, cs: 3 }),
          { cyl: true, r: 0.0074, r2: 0.0068, h: 0.034, x: 0.0272, y: 0.0292, z: 0.094, rx: HP, color: BLK, m: true, seg: 12 },
          { cyl: true, r: 0.0063, h: 0.008, x: 0.0272, y: 0.0292, z: 0.114, rx: HP, color: MET2, m: true, seg: 12 },
          { cyl: true, r: 0.0065, h: 0.0012, x: 0.0272, y: 0.0292, z: 0.112, rx: HP, color: GRV, m: true, seg: 12, open: true },
          { cyl: true, r: 0.0065, h: 0.0012, x: 0.0272, y: 0.0292, z: 0.1155, rx: HP, color: GRV, m: true, seg: 12, open: true },
          // рукоять заряжания: шток, Т-образная ручка, защёлка слева
          mbox(0.014, 0.0065, 0.026, 0, 0.0395, 0.168, BLK),
          mprof([[-0.188, 0.034], [-0.176, 0.034], [-0.174, 0.043], [-0.186, 0.043]], 0.046, BLK, { bevel: 0.0015 }),
          mprof([[-0.19, 0.035], [-0.178, 0.035], [-0.176, 0.042], ['q', -0.188, 0.044, -0.191, 0.04]], 0.012, MET2, { x: -0.028, bevel: 0.0012, bseg: 1, cs: 3 }),
          // нижняя коробка: задний прилив, приёмник магазина с раструбом и защитным «забором» кнопки
          prof([[-0.162, 0.004], ['q', -0.166, -0.03, -0.14, -0.038], [-0.064, -0.038], [-0.05, -0.034], [0.1, -0.034], [0.106, -0.02], [0.106, 0.004]], 0.046, AC, 'a', { bevel: 0.003 }),
          prof([[0.022, -0.034], [0.106, -0.034], [0.11, -0.08], ['q', 0.118, -0.086, 0.116, -0.094], [0.03, -0.094], ['q', 0.022, -0.09, 0.026, -0.08]], 0.042, AC, 'a', { bevel: 0.003 }),
          mprof([[0.02, -0.024], [0.044, -0.024], [0.046, -0.012], [0.02, -0.006]], 0.05, BLK, { bevel: 0.0015 }),
          pinX(0.097, -0.006, 0.0036), pinX(-0.134, -0.008, 0.0036),
          // переводчик огня (слева, с осью справа), затворная задержка (слева), кнопка магазина (справа)
          mprof([[-0.064, -0.01], [-0.034, -0.016], [-0.032, -0.011], [-0.06, -0.004]], 0.003, MET2, { x: -0.0246, bevel: 0.0008 }),
          { cyl: true, r: 0.0055, h: 0.003, x: -0.0246, y: -0.0085, z: 0.062, rz: HP, color: MET2, m: true, seg: 10 },
          { cyl: true, r: 0.004, h: 0.003, x: 0.0246, y: -0.0085, z: 0.062, rz: HP, color: MET2, m: true, seg: 8 },
          mprof([[-0.004, -0.016], [0.017, -0.016], [0.017, -0.003], ['q', 0.002, -0.002, -0.004, -0.008]], 0.003, BLK, { x: -0.0244, bevel: 0.0008, bseg: 1, cs: 3 }),
          mbox(0.003, 0.0012, 0.012, -0.026, -0.009, -0.007, GRV),
          { cyl: true, r: 0.0052, h: 0.004, x: 0.0254, y: -0.019, z: -0.034, rz: HP, color: MET2, m: true, seg: 12 },
          // спусковая скоба, крючок
          Object.assign(loop([[-0.044, -0.034], [0.03, -0.034], [0.028, -0.07], [-0.036, -0.073], ['q', -0.046, -0.06, -0.044, -0.034]],
            [[-0.036, -0.041], [0.022, -0.041], [0.021, -0.064], [-0.031, -0.066], ['q', -0.037, -0.056, -0.036, -0.041]], 0.011, BLK, null, true), { bseg: 1 }),
          trig(-0.006, -0.036, MET2),
          // пистолетная рукоять A2: упор под средний палец, «хвост» сверху
          prof([[-0.088, -0.034], [-0.046, -0.034], ['q', -0.048, -0.056, -0.054, -0.07], ['q', -0.066, -0.08, -0.06, -0.092], ['q', -0.062, -0.122, -0.072, -0.146],
            ['q', -0.09, -0.152, -0.11, -0.142], ['q', -0.1, -0.09, -0.094, -0.052], ['q', -0.097, -0.04, -0.088, -0.034]], 0.033, PC, 'b', { bevel: 0.005, cs: 4, bseg: 1 }),
          box(0.0464, 0.0011, 0.262, 0, 0.0042, 0.027, GRV),
          // дельта-кольцо и гайка ствола
          cylZ(0.0288, 0.142, 0.156, BLK, { seg: 18 }),
          cylZ(0.0294, 0.1445, 0.147, MET2, { seg: 18 })
    ];
    // буферная трубка, приклад
    const c2 = [
          // буферная трубка с гайкой-«замком» и упорной пластиной
          tube(0.0152, -0.34, -0.16, 0.02, BLK, 0, null, 14), tube(0.0165, -0.174, -0.164, 0.02, MET2, 0, null, 12),
          ...[0, 1, 2, 3].map(i => { const a = i * HP + Math.PI / 4; return box(0.003, 0.003, 0.0102, Math.cos(a) * 0.0165, 0.02 + Math.sin(a) * 0.0165, 0.169, GRV, 0, 0, a); }),
          mprof([[-0.164, -0.004], [-0.16, -0.004], [-0.16, 0.042], [-0.164, 0.042]], 0.034, BLK, { bevel: 0.001 }),
          // приклад «крейн»: корпус с гребнем под щёку, боковые трубки, отверстие под ремень, затыльник с рёбрами
          prof([[-0.246, 0.034], ['q', -0.25, 0.048, -0.264, 0.048], [-0.372, 0.051], ['q', -0.388, 0.052, -0.388, 0.042], [-0.388, -0.058], ['q', -0.387, -0.066, -0.376, -0.065],
            [-0.3, -0.026], ['q', -0.268, -0.012, -0.254, -0.008], ['q', -0.246, -0.004, -0.246, 0.006]], 0.036, PC, 'b',
            { bevel: 0.0045, cs: 4, bseg: 1, holes: [[[-0.302, -0.012], [-0.358, -0.012], [-0.358, -0.044], ['q', -0.33, -0.034, -0.302, -0.02]]] }),
          ...[1, -1].map(s => Object.assign(tube(0.0098, -0.37, -0.258, 0.006, PC, s * 0.0152, null, 12, true), { skin: 'b' })),
          ...[1, -1].map(s => tube(0.0066, -0.375, -0.37, 0.006, BLK, s * 0.0152, 0.0098, 12, true)),
          prof([[-0.388, 0.05], [-0.4, 0.05], ['q', -0.402, 0.05, -0.402, 0.046], [-0.402, -0.062], ['q', -0.402, -0.07, -0.394, -0.07], [-0.388, -0.068]], 0.042, '#121315', null, { bevel: 0.003 }),
          ...[0.03, 0.012, -0.006, -0.024, -0.042].map(y => box(0.043, 0.0022, 0.0105, 0, y, 0.396, '#0a0b0c')),
          mprof([[-0.244, -0.002], [-0.264, -0.002], [-0.268, -0.011], [-0.25, -0.011]], 0.012, BLK, { bevel: 0.0015 }),
          Object.assign(swivel(-0.071, 0.384), { seg: 8 })
    ];
    if (sil) {
      const f1 = [
            // круглое цевьё с вентиляционными окнами, торцевое кольцо
            cylZ(HR, 0.156, 0.392, PC, { seg: 16, m: false, skin: 'b', r2: 0.0262 }),
            cylZ(0.0272, 0.39, 0.398, BLK, { seg: 16 }),
            ...[0.19, 0.222, 0.254, 0.286].flatMap(f => VA0.map(a => vent(f, a, 0.022))),
            ...pic(0.158, 0.392, 0.0466, 0.022),
            ...sideRail(1), ...sideRail(-1),
            // ствол, пламегаситель-переходник и глушитель: муфта с насечкой, конус, корпус, пояски, торец с фаской
            cylZ(0.0094, 0.398, 0.44, MET), cylZ(0.0122, 0.412, 0.436, MET2, { seg: 8 }),
            cylZ(0.0168, 0.434, 0.452, MET2, { seg: 18 }),
            ...[0.438, 0.443, 0.448].map(f => cylZ(0.017, f, f + 0.0016, GRV, { seg: 18, open: true })),
            cylZ(0.0168, 0.452, 0.466, SC, { r2: 0.0192, seg: 20, m: false, skin: 'b' }),
            cylZ(0.0192, 0.466, 0.718, SC, { seg: 20, m: false, skin: 'b' }),
            ...[0.476, 0.484, 0.702].map(f => cylZ(0.0195, f, f + 0.0024, '#141518', { seg: 20, open: true })),
            cylZ(0.0192, 0.718, 0.726, MET2, { seg: 20 }), cylZ(0.0192, 0.726, 0.732, MET2, { r2: 0.0162, seg: 20 }),
            { cyl: true, r: 0.0085, h: 0.0012, x: 0, y: BY, z: -0.7322, rx: HP, color: '#1a1b1d', seg: 14 },
            { cyl: true, r: 0.0046, h: 0.0014, x: 0, y: BY, z: -0.7326, rx: HP, color: '#030303', seg: 10 }
      ];
      return {
        body: [...c1, ...f1, ...rearSight, ...frontSight, ...c2, Object.assign(swivel(BY - 0.03, -0.36), { seg: 8 }), mbox(0.008, 0.006, 0.014, 0, BY - 0.0262, -0.36, BLK)],
        // затворная рама в окне экстракции: дёргается при выстреле
        slide: [mbox(0.0016, 0.011, 0.032, 0.0226, 0.0235, -0.032, '#6b7178'), mbox(0.0012, 0.004, 0.012, 0.0232, 0.0235, -0.036, GRV)], slideK: 0.03,
        mag: [prof(magCurve(0.036, 0.1, -0.056, -0.176), 0.026, MET2, null, { bevel: 0.0025, bseg: 1, m: true, cs: 6 }),
          prof(magCurve(0.046, 0.058, -0.064, -0.17), 0.0285, MET, null, { bevel: 0, m: true, cs: 6 }),
          prof(magCurve(0.08, 0.09, -0.064, -0.17), 0.0285, MET, null, { bevel: 0, m: true, cs: 6 }),
          mprof([[0.054, -0.178], [0.124, -0.173], [0.126, -0.183], [0.054, -0.189]], 0.031, BLK, { bevel: 0.0015, bseg: 1 }),
          { cyl: true, r: 0.0046, h: 0.04, x: 0, y: -0.052, z: -0.072, rx: HP, color: BR, m: true, seg: 10 },
          { cyl: true, r: 0.0046, r2: 0.0012, h: 0.014, x: 0, y: -0.052, z: -0.099, rx: HP, color: '#a8683a', m: true, seg: 10 }],
        muzzle: [0, BY, -0.734], rh: [0, -0.088, 0.075], lh: [0, -0.008, -0.3], charge: [-0.02, -0.03, -0.015]
      };
    }
      // M4A4: четырёхпланочное цевьё RIS с накладками-«лесенками», мушка A2 в треугольном основании со штык-упором и антабкой,
      // открытый ствол и «птичья клетка», коллиматор на высоком кронштейне
      const QH = 0.021; // полуразмер цевья (без фаски)
      const ladder = (sx) => [prof(rrect(0.176, BY - 0.0118, 0.364, BY + 0.0118, 0.004), 0.0064, PC, 'b', { x: sx * 0.0262, bevel: 0.0016, bseg: 1, cs: 2 }),
        ...[0.212, 0.246, 0.28, 0.314].map(f => box(0.0012, 0.019, 0.0032, sx * 0.0306, BY, -f, GRV))];
      const front = [
        // корпус цевья: восьмигранное сечение, торцевые кольца
        xs([[-QH + 0.006, BY - QH], [QH - 0.006, BY - QH], [QH, BY - QH + 0.006], [QH, BY + QH - 0.006], [QH - 0.006, BY + QH], [-QH + 0.006, BY + QH], [-QH, BY + QH - 0.006], [-QH, BY - QH + 0.006]],
          0.158, 0.39, AC, 'a', { bevel: 0.0015, bseg: 1 }),
        cylZ(0.0262, 0.388, 0.398, BLK, { seg: 12 }),
        // верхняя планка во всю длину, боковые и нижняя — открыты по концам, посередине накладки
        ...pic(0.158, 0.392, 0.0466, 0.022),
        ...[1, -1].flatMap(s => [...picS(0.364, 0.388, BY, s, 0.0255), ...ladder(s)]),
        mbox(0.022, 0.0062, 0.03, 0, BY - 0.0255, -0.375, BLK),
        prof(rrect(-0.0118, BY - 0.0318, 0.0118, BY - 0.0248, 0.003), 0.186, PC, 'b', { ry: -HP, z: -0.269, bevel: 0.0016, bseg: 1, cs: 2 }),
        ...[0.212, 0.246, 0.28, 0.314].map(f => box(0.019, 0.0012, 0.0032, 0, BY - 0.0336, -f, GRV)),
        // ствол, основание мушки A2: хомут, треугольная стойка, «уши», мушка, штык-упор и антабка
        cylZ(0.0096, 0.392, 0.6, MET, { r2: 0.0088, seg: 12 }),
        xs(rrect(-0.0115, BY - 0.0118, 0.0115, BY + 0.0138, 0.0048), 0.404, 0.436, BLK, null, { bevel: 0.0016, bseg: 1, cs: 2, m: true }),
        mprof([[0.413, BY + 0.012], [0.437, BY + 0.012], [0.434, 0.058], [0.431, 0.066], [0.42, 0.066], ['q', 0.416, 0.058, 0.414, 0.048]], 0.0148, BLK, { bevel: 0.0014, bseg: 1, cs: 2 }),
        ...[1, -1].map(s => mprof([[0.418, 0.06], [0.435, 0.06], [0.434, 0.08], ['q', 0.432, 0.0845, 0.428, 0.0845], [0.425, 0.0845], ['q', 0.42, 0.0835, 0.419, 0.078]], 0.0028, BLK, { x: s * 0.0086, bevel: 0.0007, bseg: 1, cs: 2 })),
        { cyl: true, r: 0.0042, h: 0.008, x: 0, y: 0.067, z: -0.4265, color: MET2, m: true, seg: 8 }, mbox(0.0026, 0.012, 0.0026, 0, 0.076, -0.4265, MET2),
        mbox(0.0085, 0.012, 0.022, 0, BY - 0.018, -0.426, BLK), Object.assign(swivel(BY - 0.031, -0.414), { seg: 6 }),
        // «птичья клетка»: шайба, корпус с прорезями (низ закрыт), торец с каналом
        cylZ(0.0108, 0.598, 0.604, MET2, { seg: 12 }), cylZ(0.0118, 0.604, 0.666, BLK, { seg: 14 }),
        ...[0, 0.9, HP, Math.PI - 0.9, Math.PI].map(a => box(0.0018, 0.0034, 0.036, Math.cos(a) * 0.0116, BY + Math.sin(a) * 0.0116, -0.644, '#050506', 0, 0, a + HP)),
        { cyl: true, r: 0.0064, h: 0.0018, x: 0, y: BY, z: -0.6662, rx: HP, color: '#050505', seg: 10 },
        // коллиматор на высоком кронштейне: основание с винтом, стойка, корпус-труба, турели, линзы, точка
        mbox(0.03, 0.008, 0.046, 0, 0.0574, -0.014, BLK), { cyl: true, r: 0.0042, h: 0.006, x: 0.018, y: 0.0574, z: -0.014, rz: HP, color: MET2, m: true, seg: 8 },
        mprof([[-0.006, 0.0612], [0.034, 0.0612], [0.03, 0.068], [-0.002, 0.068]], 0.016, BLK, { bevel: 0.0012, bseg: 1 }),
        cylZ(0.0158, -0.018, 0.048, BLK, { y: 0.0835, seg: 14 }), cylZ(0.0172, 0.044, 0.056, BLK, { y: 0.0835, seg: 14 }), cylZ(0.0168, -0.024, -0.016, BLK, { y: 0.0835, seg: 14 }),
        { cyl: true, r: 0.0066, h: 0.008, x: 0, y: 0.0995, z: -0.014, color: BLK, m: true, seg: 10 }, { cyl: true, r: 0.0066, h: 0.008, x: 0.0158, y: 0.0835, z: -0.014, rz: HP, color: BLK, m: true, seg: 10 },
        { cyl: true, r: 0.0152, h: 0.002, x: 0, y: 0.0835, z: -0.055, rx: HP, color: '#1a7f88', g: true, seg: 14 },
        { cyl: true, r: 0.0148, h: 0.002, x: 0, y: 0.0835, z: 0.0225, rx: HP, color: '#0e2a33', g: true, seg: 14 }, dot(0, 0.0835, -0.054, '#ff2a2a', 0.0016)
      ];
      // магазин STANAG на 30: длиннее и изогнут сильнее
      const mc30 = (a, b, y0, y1, k) => [[a, y0], [b, y0], ['q', b + 0.004, (y0 + y1) / 2 - 0.004, b + k, y1], [a + k + 0.002, y1 - 0.005], ['q', a + 0.004, (y0 + y1) / 2 - 0.004, a, y0]];
      return {
        body: [...c1, ...front, ...rearSight, ...c2],
        slide: [mbox(0.0016, 0.011, 0.032, 0.0226, 0.0235, -0.032, '#6b7178'), mbox(0.0012, 0.004, 0.012, 0.0232, 0.0235, -0.036, GRV)], slideK: 0.03,
        mag: [prof(mc30(0.036, 0.1, -0.056, -0.21, 0.03), 0.026, MET2, null, { bevel: 0.0025, bseg: 1, m: true, cs: 6 }),
          prof(mc30(0.046, 0.058, -0.064, -0.204, 0.03), 0.0285, MET, null, { bevel: 0, m: true, cs: 6 }),
          prof(mc30(0.08, 0.09, -0.064, -0.204, 0.03), 0.0285, MET, null, { bevel: 0, m: true, cs: 6 }),
          mprof([[0.064, -0.212], [0.134, -0.206], [0.136, -0.216], [0.064, -0.223]], 0.031, BLK, { bevel: 0.0015, bseg: 1 }),
          { cyl: true, r: 0.0046, h: 0.04, x: 0, y: -0.052, z: -0.072, rx: HP, color: BR, m: true, seg: 10 },
          { cyl: true, r: 0.0046, r2: 0.0012, h: 0.014, x: 0, y: -0.052, z: -0.099, rx: HP, color: '#a8683a', m: true, seg: 10 }],
        muzzle: [0, BY, -0.672], rh: [0, -0.088, 0.075], lh: [0, -0.006, -0.29], charge: [-0.02, -0.03, -0.015]
      };
    }
  let gunParts = function (id) {
    switch (id) {
      case 'ar': {
        // АКМ (AK-47 в CS2): штампованная коробка с выштамповками над магазином и заклёпками вкладышей, крышка-«арка» с рёбрами
        // и кнопкой направляющей, секторный прицел на колодке, деревянные цевьё (с накладкой газовой трубки) и приклад со стальным
        // затыльником, рукоять с рёбрами, газовый блок 45°, мушка в «ушах» со штык-упором, шомпол, косой дульный компенсатор,
        // стальной магазин с рёбрами вдоль изгиба
        const BY = 0.008, RW = 0.044, GRV = '#0a0b0c', BOLT = '#8e959c', BR = '#b08a3e', WD = '#3a1a0c';
        return {
          body: [
            // коробка: плоские борта, скос к переднему вкладышу
            prof([[-0.135, -0.028], [0.118, -0.028], [0.15, -0.0265], ['q', 0.165, -0.025, 0.165, -0.012], [0.165, 0.02], [-0.135, 0.02]], RW, MET, 'a', { bevel: 0.0022, bseg: 1, cs: 3 }),
            // выштамповки-направляющие над магазином на обоих бортах
            ...[1, -1].map(s => prof(rrect(0.05, -0.021, 0.112, -0.006, 0.0068), 0.0016, MET, 'a', { x: s * 0.0222, bevel: 0.0006, bseg: 1, cs: 3 })),
            // крышка ствольной коробки: сечение-арка, поперечные рёбра жёсткости сзади, кнопка направляющей возвратной пружины
            xs(archS(0.0192, 0.0195, 0.031, 0.0455), -0.141, 0.149, MET, 'a', { bevel: 0.0018, bseg: 1, cs: 5 }),
            ...[-0.124, -0.11, -0.096, -0.082].map(f => xs(archS(0.0212, 0.026, 0.031, 0.0486), f - 0.002, f + 0.002, MET, 'a', { bevel: 0, cs: 4 })),
            mbox(0.011, 0.01, 0.008, 0, 0.033, 0.1452, MET2),
            // хвостовик коробки под приклад
            mprof([[-0.166, 0.017], [-0.134, 0.017], [-0.134, -0.028], [-0.166, -0.034]], 0.045, MET2, { bevel: 0.002, bseg: 1 }),
            // заклёпки заднего и переднего вкладышей, оси курка и спуска, заклёпка защёлки
            ...[[-0.126, 0.008], [-0.126, -0.018], [-0.108, -0.005], [-0.046, -0.015], [-0.022, -0.014], [0.03, -0.022], [0.134, 0.008], [0.146, -0.017], [0.155, 0.01]].map(([f, y]) => pinT(f, y, RW + 0.0016, 0.0026, '#3e444b')),
            // окно экстракции справа
            box(0.0012, 0.0152, 0.074, 0.0219, 0.0114, -0.036, GRV),
            // переводчик огня справа: ось сзади, длинный рычаг с лопаткой
            { cyl: true, r: 0.0062, h: 0.003, x: 0.0234, y: 0.012, z: 0.118, rz: HP, color: MET2, m: true, seg: 10 },
            mprof([[-0.124, 0.0175], [-0.006, 0.0128], ['q', 0.003, 0.0122, 0.0035, 0.004], [0.0025, -0.013], [-0.0065, -0.013], [-0.0075, 0.004], [-0.124, 0.0068]], 0.0026, MET2, { x: 0.0236, bevel: 0.0007, bseg: 1, cs: 3 }),
            // колодка прицела на переднем вкладыше, планка прицела с прорезью, хомутик с защёлками
            mprof([[0.148, 0.019], [0.219, 0.021], ['q', 0.222, 0.029, 0.215, 0.033], [0.18, 0.046], [0.148, 0.046]], 0.03, MET, { bevel: 0.0022, bseg: 1, cs: 3 }),
            mbox(0.019, 0.003, 0.052, 0, 0.0505, -0.186, MET2, -0.055),
            ...[1, -1].map(s => mbox(0.0048, 0.0062, 0.0055, s * 0.0062, 0.0548, -0.1625, MET2)),
            mbox(0.025, 0.0065, 0.011, 0, 0.0508, -0.197, MET), ...[1, -1].map(s => ({ cyl: true, r: 0.0032, h: 0.004, x: s * 0.0142, y: 0.0508, z: -0.197, rz: HP, color: MET2, m: true, seg: 8 })),
            // нижнее цевьё и накладка газовой трубки (дерево), обойма цевья, газовая трубка с флажком
            prof([[0.172, -0.022], ['q', 0.19, -0.03, 0.225, -0.031], [0.33, -0.031], ['q', 0.36, -0.0305, 0.372, -0.027], ['q', 0.378, -0.024, 0.378, -0.014], [0.378, 0.011], [0.172, 0.011]], 0.054, WOOD, 'b', { bevel: 0.007, bseg: 2, cs: 6 }),
            xs(archS(0.015, 0.02, 0.036, 0.051), 0.226, 0.38, WOOD, 'b', { bevel: 0.004, bseg: 2, cs: 6 }),
            xs(rrect(-0.0232, -0.034, 0.0232, 0.013, 0.011), 0.384, 0.395, MET2, null, { bevel: 0.0015, bseg: 1, cs: 3, m: true }),
            mprof([[0.38, -0.004], [0.393, -0.004], [0.392, -0.022], [0.384, -0.024]], 0.003, MET2, { x: 0.0262, bevel: 0.0006, bseg: 1 }),
            mprof([[0.214, 0.03], [0.228, 0.03], [0.228, 0.046], [0.214, 0.044]], 0.004, MET2, { x: 0.0165, bevel: 0.0008, bseg: 1 }),
            cz(0.0088, 0.38, 0.432, 0.036, MET, { seg: 12 }),
            mprof([[0.428, -0.005], [0.47, -0.005], ['q', 0.474, 0.003, 0.47, 0.011], [0.461, 0.046], ['q', 0.457, 0.05, 0.451, 0.05], [0.428, 0.05]], 0.026, MET2, { bevel: 0.0024, bseg: 1, cs: 3 }),
            // ствол, шомпол под стволом с головкой
            cz(0.0108, 0.39, 0.6, BY, MET, { r2: 0.0094, seg: 14 }),
            cz(0.0028, 0.386, 0.592, -0.0078, STEEL, { seg: 8 }), { sph: true, r: 0.0042, x: 0, y: -0.0078, z: -0.598, color: STEEL, m: true, seg: 8 },
            // основание мушки: хомут на стволе, «уши», мушка на барабане, штык-упор снизу
            xs(rrect(-0.0115, -0.012, 0.0115, 0.024, 0.006), 0.564, 0.594, MET2, null, { bevel: 0.002, bseg: 1, cs: 3, m: true }),
            ...[1, -1].map(s => mprof([[0.566, 0.022], [0.592, 0.022], [0.589, 0.058], ['q', 0.586, 0.064, 0.58, 0.064], [0.578, 0.064], ['q', 0.571, 0.064, 0.569, 0.058]], 0.0034, MET2, { x: s * 0.0112, bevel: 0.0008, bseg: 1, cs: 3 })),
            { cyl: true, r: 0.0062, h: 0.012, x: 0, y: 0.032, z: -0.579, color: MET, m: true, seg: 10 }, mbox(0.0028, 0.022, 0.0028, 0, 0.046, -0.579, STEEL),
            mbox(0.01, 0.014, 0.026, 0, -0.019, -0.577, MET2),
            // косой дульный компенсатор: корпус, поясок, нижняя «губа», канал
            cz(0.0126, 0.594, 0.642, BY, BLK, { seg: 14 }), ringZ(0.0127, 0.0012, 0.603, BY, MET2, 14),
            mprof([[0.642, BY - 0.0124], [0.656, BY - 0.0124], ['q', 0.657, BY - 0.008, 0.653, BY - 0.005], [0.642, BY + 0.0122]], 0.0204, BLK, { bevel: 0.0024, bseg: 2, cs: 3 }),
            { cyl: true, r: 0.0055, h: 0.0016, x: 0, y: BY, z: -0.6425, rx: HP, color: '#050505', seg: 10 },
            // пистолетная рукоять: передний упор, «бобровый» затылок, рёбра на щёчках
            prof([[-0.061, -0.027], [-0.023, -0.027], ['q', -0.031, -0.071, -0.046, -0.133], ['q', -0.066, -0.134, -0.086, -0.127], ['q', -0.073, -0.07, -0.061, -0.027]], 0.034, WOOD, 'b', { bevel: 0.006, bseg: 2, cs: 6 }),
            ...[-0.044, -0.053, -0.062].flatMap(f => [1, -1].map(s => box(0.0012, 0.058, 0.0026, s * 0.0171, -0.08, -f + 0.004, WD, -0.27))),
            // спусковая скоба (штампованная), крючок, защёлка магазина
            Object.assign(loop([[-0.03, -0.027], [0.058, -0.027], ['q', 0.06, -0.064, 0.03, -0.068], [-0.02, -0.068], ['q', -0.03, -0.064, -0.03, -0.046]],
              [[-0.02, -0.034], [0.048, -0.034], ['q', 0.048, -0.058, 0.028, -0.06], [-0.014, -0.06], ['q', -0.02, -0.056, -0.02, -0.046]], 0.01, MET, null, true), { bseg: 1, cs: 4 }),
            trig(0.004, -0.028),
            mprof([[0.029, -0.028], [0.04, -0.028], [0.041, -0.05], ['q', 0.04, -0.055, 0.035, -0.055], [0.029, -0.052]], 0.016, MET2, { bevel: 0.0012, bseg: 1, cs: 2 }),
            // приклад: прямая линия сверху, «шейка» к рукояти, стальной затыльник с лючком пенала
            prof([[-0.172, 0.012], ['q', -0.2, 0.011, -0.24, 0.004], [-0.44, -0.016], ['q', -0.446, -0.017, -0.446, -0.024], [-0.446, -0.114], ['q', -0.446, -0.12, -0.44, -0.12], [-0.21, -0.052], ['q', -0.176, -0.043, -0.172, -0.032]], 0.044, WOOD, 'b', { bevel: 0.008, bseg: 2, cs: 5 }),
            mprof([[-0.452, -0.011], [-0.458, -0.011], ['q', -0.462, -0.011, -0.462, -0.019], [-0.462, -0.122], ['q', -0.462, -0.129, -0.458, -0.129], [-0.452, -0.129]], 0.046, MET2, { bevel: 0.0018, bseg: 1, cs: 2 }),
            mbox(0.028, 0.05, 0.002, 0, -0.068, 0.4645, '#2a2d30'), rivet(0, -0.024, 0.465, MET), rivet(0, -0.118, 0.465, MET),
            swivel(-0.036, -0.4), swivel(-0.112, 0.3)
          ],
          // затворная рама в окне экстракции и рукоять заряжания
          slide: [mbox(0.0012, 0.009, 0.058, 0.0226, 0.0118, -0.036, BOLT),
            { cyl: true, r: 0.0042, h: 0.018, x: 0.031, y: 0.0145, z: -0.088, rz: HP, color: MET2, m: true, seg: 8 },
            { sph: true, r: 0.0074, x: 0.042, y: 0.0145, z: -0.09, sx: 0.85, sz: 1.15, color: MET2, m: true, seg: 10 }],
          // изогнутый стальной магазин: корпус, рёбра вдоль изгиба, крышка, патрон сверху
          mag: [prof([[0.044, -0.026], [0.112, -0.026], ['q', 0.128, -0.118, 0.198, -0.2], [0.165, -0.226], ['q', 0.092, -0.128, 0.044, -0.026]], 0.027, MET2, null, { bevel: 0.0028, bseg: 1, m: true, cs: 10 }),
            prof([[0.06, -0.042], [0.068, -0.042], ['q', 0.084, -0.12, 0.157, -0.194], [0.151, -0.2], ['q', 0.076, -0.124, 0.06, -0.042]], 0.0322, MET2, null, { bevel: 0, m: true, cs: 10 }),
            prof([[0.088, -0.034], [0.095, -0.034], ['q', 0.108, -0.112, 0.178, -0.184], [0.173, -0.19], ['q', 0.1, -0.115, 0.088, -0.034]], 0.0322, MET2, null, { bevel: 0, m: true, cs: 10 }),
            mprof([[0.162, -0.223], [0.2, -0.194], [0.2062, -0.2015], [0.1685, -0.2305]], 0.0315, MET, { bevel: 0.0014, bseg: 1 }),
            mbox(0.012, 0.008, 0.008, 0, -0.03, -0.116, MET),
            { cyl: true, r: 0.0048, h: 0.03, x: 0, y: -0.021, z: -0.076, rx: HP, color: BR, m: true, seg: 10 },
            { cyl: true, r: 0.0048, r2: 0.0014, h: 0.014, x: 0, y: -0.021, z: -0.098, rx: HP, color: '#a8683a', m: true, seg: 10 }],
          magPivot: [0, -0.026, -0.114], charge: [0.042, 0.02, -0.09],
          muzzle: [0, BY, -0.66], rh: [0, -0.078, 0.07], lh: [0, -0.03, -0.28]
        };
      }
      case 'ar2': return m4Parts(false);
      case 'm4s': return m4Parts(true);
      case 'smg': {
        // UMP-45: полимерная коробка с фасками по верху и низу (сечение-шестигранник), продольные рёбра и канавки цевья,
        // упор под ладонь спереди, шов между верхней коробкой и спусковой, планка Picatinny с барабанным диоптром
        // и мушкой в кольце, рукоять заряжания слева спереди, окно экстракции справа, короткий ствол с гайкой резьбы,
        // прямой магазин .45 на 25 патронов с рёбрами, складной вбок скелетный приклад
        const BY = 0.018, AC = '#141517', PC = '#161719', GRV = '#08090a', MG = '#141517', ST = '#5a6068';
        const pic = (f0, f1, y, w) => { const o = [mbox(w, 0.0062, f1 - f0, 0, y, -(f0 + f1) / 2, BLK)]; for (let f = f0 + 0.005; f < f1 - 0.003; f += 0.0118) o.push(mbox(w + 0.003, 0.0042, 0.0046, 0, y + 0.0045, -f, BLK)); return o; };
        const cylZ = (r, f0, f1, color, o) => Object.assign({ cyl: true, r, h: f1 - f0, x: 0, y: BY, z: -(f0 + f1) / 2, rx: HP, color, seg: 14, m: true }, o || {});
        const pinX = (f, y, w) => ({ cyl: true, r: 0.0034, h: w, x: 0, y, z: -f, rz: HP, color: ST, m: true, seg: 8 });
        const sk = (p, s) => Object.assign(p, { skin: s });
        // выдавливание сечения (x, y) вдоль ствола от f0 до f1
        const xsec = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
        // сбоку ушко под ремень (полукольцо торчит из борта)
        const loopS = (sx, f, y) => ({ torus: true, r: 0.0075, tube: 0.0019, x: sx * 0.0262, y, z: -f, rx: HP, color: BLK, m: true, seg: 10 });
        return {
          body: [
            // верхняя коробка: сечение с фасками сверху и снизу (снаружи ±0.025, от -0.016 до 0.047)
            xsec([[-0.0205, -0.014], [0.0205, -0.014], [0.023, -0.0115], [0.023, 0.0355], [0.0165, 0.045], [-0.0165, 0.045], [-0.023, 0.0355], [-0.023, -0.0115]],
              -0.152, 0.26, AC, 'a', { bevel: 0.002, bseg: 1 }),
            // упор под ладонь на носу цевья
            prof([[0.222, -0.012], [0.26, -0.012], [0.26, -0.019], ['q', 0.259, -0.031, 0.25, -0.031], [0.243, -0.031], ['q', 0.236, -0.03, 0.232, -0.019]], 0.046, AC, 'a', { bevel: 0.0025, bseg: 1, cs: 3 }),
            // продольные рёбра цевья и канавки между ними, поперечный шов
            ...[-0.006, 0.006, 0.018, 0.03].flatMap(y => [1, -1].map(s => sk(box(0.003, 0.0044, 0.104, s * 0.0255, y, -0.178, AC), 'a'))),
            ...[0.0, 0.012, 0.024].flatMap(y => [1, -1].map(s => box(0.0012, 0.0032, 0.1, s * 0.0252, y, -0.178, GRV))),
            ...[1, -1].map(s => box(0.0012, 0.05, 0.003, s * 0.0252, 0.014, -0.124, GRV)),
            // шов между верхней коробкой и спусковой
            box(0.0508, 0.0012, 0.19, 0, -0.0152, 0.058, GRV),
            // шахта магазина с раструбом
            prof([[0.04, -0.016], [0.132, -0.016], [0.132, -0.057], [0.126, -0.064], [0.046, -0.064], [0.04, -0.058]], 0.04, AC, 'a', { bevel: 0.0035, bseg: 2 }),
            mprof([[0.044, -0.056], [0.13, -0.056], [0.13, -0.061], [0.044, -0.061]], 0.0472, BLK, { bevel: 0.001, bseg: 1 }),
            ...pic(-0.142, 0.194, 0.0498, 0.022),
            // окно экстракции справа, затвор в окне, отражатель
            box(0.0012, 0.018, 0.07, 0.0252, 0.027, 0.0, GRV), mbox(0.0012, 0.011, 0.034, 0.0248, 0.025, 0.012, '#5d636b'),
            mprof([[-0.048, 0.017], [-0.035, 0.017], [-0.035, 0.036], ['q', -0.044, 0.036, -0.048, 0.03]], 0.006, AC, { x: 0.0262, bevel: 0.0012, bseg: 1, cs: 3, m: false, skin: 'a' }),
            // паз рукояти заряжания слева
            box(0.0012, 0.005, 0.124, -0.0252, 0.031, -0.17, GRV),
            // переводчик огня с обеих сторон (сталь), ось с головками
            ...[1, -1].map(s => mprof([[-0.08, -0.002], [-0.052, -0.011], [-0.05, -0.006], [-0.076, 0.004]], 0.003, ST, { x: s * 0.0262, bevel: 0.0008, bseg: 1 })),
            { cyl: true, r: 0.0052, h: 0.0545, x: 0, y: -0.001, z: 0.078, rz: HP, color: ST, m: true, seg: 10 },
            pinX(-0.132, -0.022, 0.0385), pinX(0.024, -0.022, 0.0385), pinX(0.11, 0.004, 0.0525), pinX(-0.12, 0.03, 0.0525), pinX(0.2, 0.004, 0.0525),
            // спусковая коробка с рукоятью: скруглённые борта, горб сверху сзади и расширение снизу
            prof([[-0.148, -0.0145], [0.034, -0.0145], [0.034, -0.03], [-0.026, -0.031], ['q', -0.031, -0.078, -0.05, -0.129], [-0.053, -0.139], [-0.103, -0.139], [-0.106, -0.131],
              ['q', -0.091, -0.085, -0.089, -0.05], ['q', -0.096, -0.033, -0.116, -0.03], [-0.148, -0.028]], 0.034, PC, 'b', { bevel: 0.0055, bseg: 2, cs: 5 }),
            prof([[-0.05, -0.134], [-0.106, -0.134], [-0.108, -0.145], ['q', -0.08, -0.15, -0.048, -0.145]], 0.038, PC, 'b', { bevel: 0.003, bseg: 2, cs: 3 }),
            // рельефная вставка на тыльной стороне рукояти (упор ладони)
            ...[1, -1].map(s => prof([[-0.06, -0.05], [-0.084, -0.046], ['q', -0.086, -0.09, -0.098, -0.124], [-0.066, -0.124], ['q', -0.058, -0.09, -0.06, -0.05]], 0.003, PC, 'b', { x: s * 0.0196, bevel: 0.001, bseg: 1, cs: 3 })),
            // большая спусковая скоба под перчатку, крючок, защёлка магазина за шахтой
            Object.assign(loop([[-0.03, -0.028], [0.04, -0.028], [0.04, -0.073], ['q', 0.04, -0.081, 0.032, -0.081], [-0.033, -0.081], ['q', -0.039, -0.07, -0.036, -0.05]],
              [[-0.025, -0.036], [0.032, -0.036], [0.032, -0.069], [0.029, -0.072], [-0.027, -0.072], ['q', -0.031, -0.06, -0.029, -0.047]], 0.014, PC, 'b'), { bseg: 1 }),
            trig(0.004, -0.031, ST),
            mprof([[0.034, -0.052], [0.044, -0.054], [0.046, -0.074], [0.037, -0.075]], 0.02, BLK, { bevel: 0.0015, bseg: 1 }),
            // узел складывания приклада: колодка со скруглённым верхом и ось шарнира справа
            mprof([[-0.174, -0.014], [-0.15, -0.014], [-0.15, 0.042], ['q', -0.152, 0.046, -0.162, 0.046], ['q', -0.174, 0.046, -0.174, 0.036]], 0.046, BLK, { bevel: 0.003, bseg: 1, cs: 3 }),
            { cyl: true, r: 0.0062, h: 0.06, x: 0.0205, y: 0.014, z: 0.166, color: ST, m: true, seg: 10 },
            { cyl: true, r: 0.0034, h: 0.062, x: 0.0205, y: 0.014, z: 0.166, color: '#0a0a0b', seg: 8 },
            // прицельные: барабанный диоптр в «ушах» сзади, мушка-штырь в кольце спереди
            mprof([[-0.126, 0.05], [-0.084, 0.05], [-0.087, 0.061], [-0.123, 0.061]], 0.026, BLK, { bevel: 0.0015, bseg: 1 }),
            { cyl: true, r: 0.0088, h: 0.02, x: 0, y: 0.0685, z: 0.105, rz: HP, color: BLK, m: true, seg: 14 },
            ...[-0.0068, -0.0022, 0.0022, 0.0068].map(x => ({ cyl: true, r: 0.0091, h: 0.0012, x, y: 0.0685, z: 0.105, rz: HP, color: '#0c0d0e', m: true, seg: 14, open: true })),
            { cyl: true, r: 0.0024, h: 0.0182, x: 0, y: 0.0705, z: 0.105, rx: HP, color: '#040404', seg: 8 },
            ...[1, -1].map(s => mprof([[-0.124, 0.058], [-0.086, 0.058], [-0.091, 0.068], [-0.099, 0.079], [-0.111, 0.079], ['q', -0.12, 0.071, -0.124, 0.065]], 0.0034, BLK, { x: s * 0.0118, bevel: 0.0008, bseg: 1 })),
            mprof([[0.196, 0.046], [0.24, 0.046], [0.238, 0.058], [0.229, 0.066], [0.207, 0.066], [0.198, 0.058]], 0.02, BLK, { bevel: 0.0015, bseg: 1 }),
            { torus: true, r: 0.0105, tube: 0.0026, x: 0, y: 0.0785, z: -0.219, color: BLK, m: true, seg: 16 },
            mbox(0.0028, 0.015, 0.003, 0, 0.0745, -0.219, ST), dot(0, 0.0822, -0.2175, '#f4f4ee', 0.0013),
            // торцевая крышка цевья, ствол, гайка резьбы с насечкой и фаской, канал
            cylZ(0.0135, 0.256, 0.266, BLK, { seg: 16 }), cylZ(0.0082, 0.262, 0.303, '#3a3e44', { seg: 12 }),
            cylZ(0.0112, 0.3, 0.33, '#2c3035'), ...[0.306, 0.312, 0.318].map(f => cylZ(0.0115, f, f + 0.0016, GRV, { open: true })),
            cylZ(0.0112, 0.33, 0.334, '#2c3035', { r2: 0.0092 }),
            { cyl: true, r: 0.0058, h: 0.0012, x: 0, y: BY, z: -0.3344, rx: HP, color: '#030303', seg: 12 },
            // антабки: спереди и сзади слева
            loopS(-1, 0.246, 0.04), loopS(-1, -0.142, 0.022),
            // скелетный приклад: рамка с окном, затыльник с рёбрами
            prof([[-0.17, 0.043], [-0.386, 0.045], ['q', -0.398, 0.045, -0.398, 0.033], [-0.398, -0.07], ['q', -0.398, -0.08, -0.388, -0.08], [-0.366, -0.08], [-0.2, -0.026], ['q', -0.174, -0.018, -0.17, -0.006]], 0.02, PC, 'b',
              { bevel: 0.0055, bseg: 2, cs: 4, holes: [[[-0.19, 0.033], ['q', -0.19, 0.002, -0.205, -0.0145], [-0.377, -0.067], [-0.377, 0.034]]] }),
            prof([[-0.398, 0.047], [-0.41, 0.047], ['q', -0.413, 0.047, -0.413, 0.041], [-0.413, -0.077], ['q', -0.413, -0.085, -0.405, -0.085], [-0.398, -0.083]], 0.036, '#0e0f10', null, { bevel: 0.003 }),
            ...[0.03, 0.012, -0.006, -0.024, -0.042, -0.06].map(y => box(0.037, 0.0022, 0.0105, 0, y, 0.4085, '#060707')),
            Object.assign(swivel(-0.07, 0.384), { seg: 8 })
          ],
          // рукоять заряжания слева спереди: шток в пазу и лопатка
          slide: [{ cyl: true, r: 0.0034, h: 0.014, x: -0.031, y: 0.031, z: -0.214, rz: HP, color: ST, m: true, seg: 8 },
            mprof([[0.199, 0.0255], [0.226, 0.0255], ['q', 0.233, 0.031, 0.226, 0.0365], [0.199, 0.0365], ['q', 0.195, 0.031, 0.199, 0.0255]], 0.007, BLK, { x: -0.0385, bevel: 0.0015, bseg: 1, cs: 3 })],
          slideK: 0.055,
          // прямой магазин .45: корпус, рёбра, утолщение у горловины, пятка, патрон сверху
          mag: [prof([[0.056, -0.022], [0.118, -0.022], [0.121, -0.2], [0.059, -0.2]], 0.03, MG, null, { bevel: 0.003, bseg: 2 }),
            ...[1, -1].flatMap(s => [box(0.0028, 0.122, 0.006, s * 0.0155, -0.132, -0.107, MG), box(0.0028, 0.122, 0.005, s * 0.0155, -0.132, -0.072, MG)]),
            ...[1, -1].map(s => box(0.0012, 0.12, 0.024, s * 0.0152, -0.133, -0.0895, '#0b0c0d')),
            box(0.0335, 0.008, 0.066, 0, -0.07, -0.0882, MG),
            prof([[0.055, -0.197], [0.126, -0.197], [0.128, -0.211], ['q', 0.09, -0.214, 0.053, -0.211]], 0.036, '#0f1012', null, { bevel: 0.0025, bseg: 2, cs: 3 }),
            { cyl: true, r: 0.0058, h: 0.03, x: 0, y: -0.024, z: -0.085, rx: HP, color: '#b08a3e', m: true, seg: 10 },
            { cyl: true, r: 0.0058, r2: 0.003, h: 0.01, x: 0, y: -0.024, z: -0.105, rx: HP, color: '#a8683a', m: true, seg: 10 }],
          muzzle: [0, BY, -0.336], rh: [0, -0.08, 0.064], lh: [0, -0.02, -0.18], charge: [-0.032, 0.006, -0.2]
        };
      }
      case 'sniper': {
        // AWM / AWP (Accuracy International): ложа-«тамбхол» оливкового цвета на алюминиевом шасси — длинное прямоугольное цевьё
        // со скруглёнными рёбрами и вентиляционными прорезями, вертикальная рукоять, окно для большого пальца, регулируемая щека
        // с винтами, резиновый затыльник с проставками; круглая ствольная коробка с планкой, затвор с крупной рукоятью,
        // рифлёный ствол, дульный тормоз с окнами, оптика с турелями на двух кольцах, отъёмный коробчатый магазин
        const BY = 0.045, GRV = '#0c0e0a', OD = '#3a4430', RUB = '#141516';
        return {
          body: [
            // ложа: цевьё, шасси под коробкой, рукоять, окно для пальца, приклад
            prof([[-0.488, 0.024], [-0.43, 0.026], [-0.2, 0.03], [-0.14, 0.022], [0.12, 0.018], [0.372, 0.016], ['q', 0.382, 0.016, 0.382, 0.004], [0.382, -0.026],
              ['q', 0.382, -0.036, 0.372, -0.036], [0.06, -0.038], [0.04, -0.044], [-0.03, -0.044], ['q', -0.06, -0.044, -0.098, -0.058], [-0.124, -0.124],
              ['q', -0.126, -0.132, -0.136, -0.132], [-0.162, -0.13], ['q', -0.2, -0.124, -0.26, -0.11], [-0.44, -0.1], ['q', -0.488, -0.098, -0.488, -0.086]], 0.056, OLIVE, 'a',
              { bevel: 0.006, bseg: 2, cs: 4, holes: [[[-0.168, -0.028], [-0.27, -0.03], ['q', -0.31, -0.031, -0.31, -0.06], ['q', -0.31, -0.088, -0.27, -0.09], [-0.2, -0.102],
                ['q', -0.182, -0.104, -0.178, -0.09], [-0.164, -0.045], ['q', -0.162, -0.028, -0.168, -0.028]]] }),
            // щека: подъёмная накладка с прорезью и винтами-барашками слева
            prof([[-0.432, 0.034], [-0.262, 0.036], ['q', -0.246, 0.037, -0.246, 0.048], ['q', -0.25, 0.058, -0.27, 0.058], [-0.424, 0.056], ['q', -0.434, 0.056, -0.434, 0.046]], 0.046, OLIVE, 'a', { bevel: 0.005, bseg: 2, cs: 4 }),
            box(0.05, 0.0016, 0.17, 0, 0.0352, 0.345, GRV),
            ...[0.3, 0.39].map(z => ({ cyl: true, r: 0.0065, h: 0.012, x: -0.031, y: 0.02, z, rz: HP, color: BLK, m: true, seg: 10 })),
            // резиновый затыльник с проставками
            prof([[-0.497, 0.03], [-0.515, 0.03], ['q', -0.52, 0.03, -0.52, 0.022], [-0.52, -0.098], ['q', -0.52, -0.106, -0.515, -0.106], [-0.497, -0.106]], 0.06, RUB, null, { bevel: 0.004, bseg: 2, cs: 3 }),
            ...[0.499, 0.505].map(z => box(0.0632, 0.13, 0.0016, 0, -0.038, z, '#2a2c2e')),
            ...[0.02, -0.004, -0.028, -0.052, -0.076].map(y => box(0.062, 0.0022, 0.016, 0, y, 0.522, '#0a0b0c')),
            // вентиляционные прорези цевья и накладка-планка снизу, антабки
            ...[0.24, 0.285, 0.33].flatMap(f => [1, -1].map(s => prof(rrect(f - 0.016, -0.018, f + 0.016, 0.0, 0.006), 0.0016, GRV, null, { x: s * 0.0286, bevel: 0, cs: 3 }))),
            ...picL(0.24, 0.35, -0.0445, 0.018), swivel(-0.05, -0.37), swivel(-0.112, 0.43),
            // ствольная коробка: цилиндр с плоским низом, планка под оптику, окно экстракции справа, хвост затвора
            cz(0.0205, -0.13, 0.16, BY, MET, { seg: 16 }), mbox(0.034, 0.02, 0.28, 0, BY - 0.014, -0.015, MET),
            ...picL(-0.13, 0.17, BY + 0.0232, 0.024),
            box(0.0012, 0.016, 0.07, 0.0204, BY + 0.004, -0.02, GRV),
            cz(0.017, -0.16, -0.13, BY, MET2, { seg: 14 }), cz(0.008, -0.168, -0.16, BY, BLK, { seg: 10 }),
            // спусковая скоба шасси и крючок, защёлка магазина
            Object.assign(loop([[-0.03, -0.042], [-0.112, -0.044], ['q', -0.122, -0.06, -0.116, -0.078], [-0.07, -0.088], ['q', -0.034, -0.088, -0.03, -0.068]],
              [[-0.038, -0.049], [-0.104, -0.05], ['q', -0.112, -0.062, -0.108, -0.074], [-0.07, -0.081], ['q', -0.04, -0.081, -0.038, -0.066]], 0.012, BLK, null, true), { bseg: 1, cs: 4 }),
            trig(-0.074, -0.046, MET2), mbox(0.012, 0.012, 0.01, 0, -0.05, -0.03, MET2),
            // ствол: усиленный казённик, долы, дульный тормоз с окнами
            cz(0.0152, 0.16, 0.25, BY, MET, { r2: 0.0138, seg: 16 }), cz(0.0138, 0.25, 0.79, BY, MET, { r2: 0.0114, seg: 14 }),
            ...[0, 1, 2, 3].map(i => { const a = i * HP + Math.PI / 4; return box(0.0028, 0.0016, 0.44, Math.cos(a) * 0.0122, BY + Math.sin(a) * 0.0122, -0.5, '#121314', 0, 0, a + HP); }),
            cz(0.0118, 0.785, 0.795, BY, MET2, { seg: 14 }),
            cz(0.0188, 0.795, 0.872, BY, BLK, { seg: 16 }), ringZ(0.0188, 0.0016, 0.8, BY, MET2, 16),
            ...[0.812, 0.831, 0.85].flatMap(f => [1, -1].map(s => box(0.008, 0.0105, 0.011, s * 0.0158, BY, -f, '#050506'))),
            ...[0.82, 0.842].map(f => box(0.016, 0.0016, 0.012, 0, BY + 0.0186, -f, '#050506')),
            { cyl: true, r: 0.0074, h: 0.0018, x: 0, y: BY, z: -0.8722, rx: HP, color: '#050505', seg: 12 },
            // оптика на двух кольцах
            ...scopeParts(-0.2, 0.29, 0.112, { rt: 0.0185, ro: 0.031, re: 0.0255, tf: -0.035, len: 0.1, le: 0.08, ring: [-0.13, 0.07], base: BY + 0.03 }),
            // 2.5: сложенные сошки на нижней планке цевья
            ...bipod(0.335, -0.05, 0.0135, 0.23)
          ],
          // затвор: корпус, стебель рукояти, крупная шаровая рукоять
          bolt: [cz(0.0128, -0.03, 0.04, 0, MET2, { seg: 14 }), { cyl: true, r: 0.0052, h: 0.062, x: 0.044, y: 0, z: 0.012, rz: HP, color: MET2, m: true, seg: 10 },
            { sph: true, r: 0.0125, x: 0.08, y: 0, z: 0.012, sx: 1.1, color: BLK, m: true, seg: 14 }, ringZ(0.0128, 0.0014, -0.03, 0, BLK, 14)],
          boltPos: [0, BY, 0.06],
          // коробчатый магазин на 5
          mag: [mprof([[-0.02, -0.04], [0.06, -0.04], [0.06, -0.088], ['q', 0.06, -0.092, 0.056, -0.092], [-0.016, -0.092], ['q', -0.02, -0.092, -0.02, -0.088]], 0.036, MET2, { bevel: 0.002, bseg: 1, cs: 2 }),
            mprof([[-0.024, -0.09], [0.064, -0.09], [0.064, -0.098], ['q', 0.064, -0.101, 0.06, -0.101], [-0.02, -0.101], ['q', -0.024, -0.101, -0.024, -0.098]], 0.042, BLK, { bevel: 0.0018, bseg: 1, cs: 2 })],
          muzzle: [0, BY, -0.88], rh: [0, -0.09, 0.145], lh: [0, -0.045, -0.26]
        };
      }
      case 'shotgun': {
        // M870: фрезерованная коробка со скосом к прикладу, окно экстракции с затвором справа, окно заряжания снизу, спусковая
        // коробка со скобой, кнопкой предохранителя и рычагом затворной задержки; гладкий ствол с мушкой-шариком, подствольный
        // магазин с хомутом и крышкой; деревянное цевьё-помпа с проточками на штангах, приклад с полупистолетной шейкой,
        // белой проставкой и резиновым затыльником; патронташ на 4 патрона на левом борту
        const BY = 0.024, MY = -0.017, GRV = '#0a0b0c', SH = '#b02a1e', BRS = '#c9a23a', BLU = '#23272c';
        const shellS = (f) => [{ cyl: true, r: 0.0105, h: 0.044, x: -0.0425, y: 0.002, z: -f, color: SH, seg: 10 }, { cyl: true, r: 0.0108, h: 0.012, x: -0.0425, y: -0.024, z: -f, color: BRS, m: true, seg: 10 }];
        return {
          body: [
            // коробка
            prof([[-0.122, -0.04], [0.14, -0.04], [0.14, 0.035], ['q', 0.14, 0.045, 0.13, 0.045], [-0.064, 0.045], ['q', -0.104, 0.045, -0.118, 0.026], [-0.122, 0.012]], 0.052, MET, 'a', { bevel: 0.0035, bseg: 2, cs: 4 }),
            // окно экстракции и затвор в нём, окно заряжания снизу, оси спусковой коробки
            box(0.0012, 0.026, 0.086, 0.0262, 0.017, -0.052, GRV), mbox(0.0012, 0.017, 0.05, 0.0268, 0.016, -0.064, STEEL),
            box(0.03, 0.0012, 0.092, 0, -0.0442, -0.06, GRV),
            pinT(-0.08, -0.03, 0.0536, 0.0028, STEEL), pinT(0.06, -0.03, 0.0536, 0.0028, STEEL),
            // спусковая коробка, скоба, крючок, кнопка предохранителя (красное кольцо слева), рычаг затворной задержки
            mprof([[-0.104, -0.04], [0.054, -0.04], [0.054, -0.047], [-0.1, -0.047]], 0.032, MET2, { bevel: 0.0015, bseg: 1 }),
            Object.assign(loop([[-0.078, -0.045], [0.006, -0.045], ['q', 0.008, -0.078, -0.02, -0.082], [-0.064, -0.082], ['q', -0.08, -0.078, -0.078, -0.06]],
              [[-0.069, -0.051], [-0.003, -0.051], ['q', -0.001, -0.072, -0.022, -0.074], [-0.06, -0.074], ['q', -0.07, -0.071, -0.069, -0.06]], 0.012, MET2, null, true), { bseg: 1, cs: 4 }),
            trig(-0.03, -0.047, STEEL),
            { cyl: true, r: 0.0042, h: 0.038, x: 0, y: -0.043, z: 0.071, rz: HP, color: MET2, m: true, seg: 8 }, { cyl: true, r: 0.0046, h: 0.0022, x: -0.0186, y: -0.043, z: 0.071, rz: HP, color: '#c0281c', seg: 10 },
            mprof([[0.008, -0.046], [0.02, -0.046], [0.022, -0.058], [0.012, -0.062], [0.006, -0.056]], 0.003, MET2, { x: -0.0165, bevel: 0.0008, bseg: 1 }),
            // патронташ слева
            mbox(0.004, 0.046, 0.124, -0.0285, 0.0, -0.02, BLK), ...[-0.04, -0.013, 0.014, 0.041].flatMap(f => shellS(f)),
            // ствол: удлинитель, ствол с мушкой-шариком, дульный срез
            cz(0.0158, 0.14, 0.17, BY, MET, { seg: 16 }), cz(0.0138, 0.17, 0.692, BY, BLU, { r2: 0.0128, seg: 14 }),
            { cyl: true, r: 0.0096, h: 0.0016, x: 0, y: BY, z: -0.6925, rx: HP, color: '#050505', seg: 12 },
            { sph: true, r: 0.0036, x: 0, y: BY + 0.0134, z: -0.678, color: '#e8e2c8', m: true, seg: 8 },
            // магазин: труба, хомут ствола, крышка с проточками и антабкой
            cz(0.0126, 0.14, 0.612, MY, BLU, { seg: 14 }),
            xs(rrect(-0.0105, MY - 0.0118, 0.0105, BY + 0.0118, 0.0098), 0.566, 0.588, BLU, null, { bevel: 0.0018, bseg: 1, cs: 3, m: true }),
            cz(0.0142, 0.612, 0.638, MY, MET2, { seg: 14 }), ...[0.618, 0.624, 0.63].map(f => ringZ(0.0143, 0.0011, f, MY, '#1a1c1f', 12)),
            { sph: true, r: 0.0142, x: 0, y: MY, z: -0.638, sz: 0.35, color: MET2, m: true, seg: 12 }, swivel(MY - 0.016, -0.626),
            // приклад: полупистолетная шейка, гребень; белая проставка и резиновый затыльник
            prof([[-0.124, 0.024], ['q', -0.15, 0.022, -0.19, 0.0], [-0.432, -0.026], ['q', -0.44, -0.027, -0.44, -0.034], [-0.44, -0.112], ['q', -0.44, -0.118, -0.432, -0.118],
              [-0.25, -0.08], ['q', -0.19, -0.072, -0.172, -0.086], ['q', -0.156, -0.094, -0.143, -0.08], ['q', -0.128, -0.06, -0.124, -0.04]], 0.046, WOOD, 'b', { bevel: 0.007, bseg: 2, cs: 5 }),
            box(0.05, 0.106, 0.0018, 0, -0.072, 0.4478, '#d8d4c8', -0.0),
            prof([[-0.449, -0.017], [-0.466, -0.017], ['q', -0.47, -0.017, -0.47, -0.024], [-0.47, -0.122], ['q', -0.47, -0.128, -0.466, -0.128], [-0.449, -0.128]], 0.05, '#141516', null, { bevel: 0.004, bseg: 2, cs: 3 }),
            ...[-0.04, -0.06, -0.08, -0.1].map(y => box(0.052, 0.0022, 0.004, 0, y, 0.4736, '#060707')),
            swivel(-0.114, 0.37)
          ],
          // цевьё-помпа: деревянная накладка вокруг трубы магазина с проточками, гайка, штанги затвора
          pump: [xs(rrect(-0.0235, -0.046, 0.0235, 0.0, 0.017), 0.244, 0.414, WOOD, 'b', { bevel: 0.006, bseg: 2, cs: 4 }),
            ...[0.266, 0.288, 0.31, 0.332, 0.354, 0.376, 0.398].flatMap(f => [box(0.0036, 0.036, 0.006, 0.0294, -0.023, -f, '#3a2414'), box(0.0036, 0.036, 0.006, -0.0294, -0.023, -f, '#3a2414')]),
            cz(0.0128, 0.414, 0.426, MY, MET2, { seg: 12 }),
            ...[1, -1].map(s => mbox(0.003, 0.006, 0.11, s * 0.0145, -0.002, -0.195, STEEL))],
          shell: [{ cyl: true, r: 0.0105, h: 0.05, x: 0, y: 0, z: 0, rx: HP, color: SH, seg: 12 }, { cyl: true, r: 0.0108, h: 0.012, x: 0, y: 0, z: 0.026, rx: HP, color: BRS, m: true, seg: 12 }],
          mag: [], muzzle: [0, BY, -0.7], rh: [0, -0.075, 0.15], lh: [0, -0.05, -0.33]
        };
      }
      case 'pistol': {
        // Glock-18: затвор с плоскими бортами и фасками по верху (сечение-«домик»), насечки сзади на бортах, задняя крышка,
        // переводчик огня слева сзади на затворе, окно экстракции с казёнником ствола; полимерная рамка со скруглёнными
        // краями, углом рукояти ~22°, упорами под пальцы, хвостовиком; планка под фонарь, квадратная скоба, спуск
        // с клавишей предохранителя, магазин на 20 патронов
        const SC = '#141618', FR = '#151618', GRV = '#08090a', WH = '#f0f0e6', ST = '#6c727a';
        const pinX = (f, y) => ({ cyl: true, r: 0.0018, h: 0.0272, x: 0, y, z: -f, rz: HP, color: ST, m: true, seg: 8 });
        const em = (p) => Object.assign(p, { em: true });
        const xsec = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
        // насечки на бортах затвора (вертикальные пазы только по плоской части)
        // тёмная канавка и светлая кромка за ней — насечки читаются и на чёрном затворе
        const serS = (n, f0, step) => Array.from({ length: n * 2 }, (_, i) => box(0.0012, 0.019, 0.0021, (i % 2 ? 1 : -1) * 0.01285, 0.0128, -(f0 + (i >> 1) * step), GRV))
          .concat(Array.from({ length: n * 2 }, (_, i) => mbox(0.0011, 0.019, 0.0007, (i % 2 ? 1 : -1) * 0.01285, 0.0128, -(f0 + (i >> 1) * step) + 0.0015, '#41464d')));
        return {
          body: [
            // рамка: направляющие, рукоять с упорами под пальцы, хвостовик; толстая скруглённая фаска по краям
            prof([[-0.084, -0.002], [0.096, -0.002], [0.096, -0.011], ['q', 0.095, -0.016, 0.089, -0.016], [-0.017, -0.016], ['q', -0.028, -0.033, -0.0267, -0.0487],
              ['q', -0.04, -0.0626, -0.0383, -0.0765], ['q', -0.053, -0.095, -0.056, -0.112], [-0.059, -0.115], [-0.1, -0.102], [-0.102, -0.098],
              ['q', -0.095, -0.062, -0.086, -0.034], ['q', -0.083, -0.024, -0.09, -0.017], ['q', -0.094, -0.011, -0.089, -0.006], [-0.084, -0.002]], 0.0268, FR, 'b', { bevel: 0.0058, bseg: 2, cs: 5 }),
            // граница рельефной зоны рукояти (тонкий кант)
            ...[1, -1].map(s => prof([[-0.036, -0.03], [-0.084, -0.03], ['q', -0.091, -0.064, -0.097, -0.098], [-0.06, -0.109], ['q', -0.048, -0.08, -0.036, -0.03]], 0.0016, FR, 'b', { x: s * 0.0138, bevel: 0.0006, bseg: 1, cs: 3 })),
            // планка под фонарь: продольные пазы и поперечный паз
            box(0.0275, 0.0014, 0.05, 0, -0.0118, -0.07, GRV), box(0.0275, 0.004, 0.0034, 0, -0.0162, -0.072, GRV),
            // квадратная скоба, спуск с клавишей предохранителя
            Object.assign(loop([[-0.02, -0.015], [0.04, -0.015], [0.042, -0.022], [0.04, -0.046], ['q', 0.038, -0.052, 0.032, -0.052], [-0.014, -0.052], ['q', -0.022, -0.05, -0.024, -0.038]],
              [[-0.014, -0.021], [0.034, -0.021], [0.035, -0.026], [0.033, -0.044], ['q', 0.031, -0.046, 0.027, -0.046], [-0.009, -0.046], ['q', -0.016, -0.044, -0.017, -0.034]], 0.011, FR, 'b'), { bseg: 1 }),
            mprof([[0.002, -0.017], [0.01, -0.017], ['q', 0.011, -0.032, 0.002, -0.042], [-0.003, -0.04], ['q', 0.004, -0.03, 0.002, -0.017]], 0.0062, BLK, { bevel: 0.0008, bseg: 1, cs: 4 }),
            mprof([[0.009, -0.024], [0.0118, -0.025], ['q', 0.0115, -0.033, 0.006, -0.0385], [0.004, -0.037], ['q', 0.0085, -0.031, 0.009, -0.024]], 0.0022, ST, { bevel: 0, cs: 3 }),
            // затворная задержка слева, рычаг разборки с обеих сторон, защёлка магазина, штифты
            mprof([[-0.002, -0.004], [0.022, -0.0055], [0.024, -0.0005], [0.0, 0.0005]], 0.0024, '#2a2d31', { x: -0.0148, bevel: 0.0006, bseg: 1 }),
            mbox(0.0302, 0.0034, 0.008, 0, -0.0072, -0.035, '#2a2d31'),
            mbox(0.0292, 0.0075, 0.009, 0, -0.0215, 0.012, BLK),
            pinX(-0.003, -0.0085), pinX(0.021, -0.011), pinX(-0.062, -0.0075),
            // ствол в торце затвора: дульный срез, канал, отверстие направляющей пружины
            { cyl: true, r: 0.0068, h: 0.002, x: 0, y: 0.017, z: -0.1052, rx: HP, color: '#5a6067', m: true, seg: 14 },
            { cyl: true, r: 0.0046, h: 0.0024, x: 0, y: 0.017, z: -0.1054, rx: HP, color: '#030303', seg: 12 },
            { cyl: true, r: 0.0032, h: 0.002, x: 0, y: 0.0055, z: -0.1052, rx: HP, color: '#050505', seg: 8 }
          ],
          slide: [
            // затвор: сечение с фасками сверху (снаружи ±0.01275, высота 0.0305), скруглённые торцы
            xsec([[-0.0105, 0.0012], [0.0105, 0.0012], [0.0115, 0.0022], [0.0115, 0.0262], [0.0085, 0.0293], [-0.0085, 0.0293], [-0.0115, 0.0262], [-0.0115, 0.0022]],
              -0.083, 0.105, SC, 'a', { bevel: 0.0013, bseg: 2 }),
            ...serS(9, -0.0775, 0.0034),
            // задняя крышка затвора
            mprof([[-0.0842, 0.004], [-0.0832, 0.004], [-0.0832, 0.025], [-0.0842, 0.025]], 0.0135, '#1f2226', { bevel: 0.0005, bseg: 1 }),
            // окно экстракции сверху справа с казёнником ствола, выбрасыватель
            box(0.0128, 0.0012, 0.042, 0.0042, 0.0302, -0.009, GRV), box(0.0012, 0.0075, 0.042, 0.0128, 0.0245, -0.009, GRV),
            mbox(0.0108, 0.0014, 0.034, 0.0035, 0.0303, -0.011, '#585e65'), mbox(0.0108, 0.0034, 0.0014, 0.0035, 0.0293, -0.0277, '#4a4f55'),
            mbox(0.0012, 0.0036, 0.016, 0.0132, 0.021, 0.02, ST),
            // переводчик огня Glock-18 слева сзади: ось и флажок
            { cyl: true, r: 0.0046, h: 0.0024, x: -0.0137, y: 0.0185, z: 0.067, rz: HP, color: '#2a2d31', m: true, seg: 12 },
            mprof([[-0.071, 0.0148], [-0.054, 0.0168], [-0.052, 0.0222], [-0.069, 0.0228]], 0.0022, '#2a2d31', { x: -0.0141, bevel: 0.0006, bseg: 1 }),
            em(box(0.0012, 0.0012, 0.0006, -0.0153, 0.0185, 0.067, '#e03a2a')),
            // целик со скошенной передней гранью и белой «П»-рамкой к стрелку, мушка с точкой
            mprof([[-0.0795, 0.0298], [-0.066, 0.0298], [-0.0685, 0.0368], [-0.079, 0.0372]], 0.018, BLK, { bevel: 0.0008, bseg: 1 }),
            box(0.0042, 0.0046, 0.0155, 0, 0.0352, 0.0728, GRV),
            em(box(0.0011, 0.0042, 0.0006, 0.0029, 0.0346, 0.0805, WH)), em(box(0.0011, 0.0042, 0.0006, -0.0029, 0.0346, 0.0805, WH)), em(box(0.0068, 0.0011, 0.0006, 0, 0.0327, 0.0805, WH)),
            mbox(0.0042, 0.0058, 0.0062, 0, 0.0332, -0.096, BLK), dot(0, 0.0338, -0.0928, WH, 0.0015)
          ],
          // магазин на 20: корпус под углом рукояти, пятка с выступом, патрон сверху
          mag: [box(0.019, 0.096, 0.032, 0, -0.0631, 0.0614, '#141517', -0.38), mbox(0.0272, 0.008, 0.052, 0, -0.1132, 0.0815, BLK, -0.38),
            mbox(0.0274, 0.003, 0.008, 0, -0.1158, 0.0596, BLK, -0.38),
            { cyl: true, r: 0.0045, h: 0.02, x: 0, y: -0.0165, z: 0.043, rx: HP, color: '#b08a3e', m: true, seg: 10 }],
          muzzle: [0, 0.017, -0.107], rh: [0, -0.064, 0.066], lh: [-0.035, -0.078, 0.045]
        };
      }
      case 'usp': {
        // H&K USP-S (USP Tactical): затвор со скруглённым верхом и вертикальными насечками сзади, окно экстракции с казёнником,
        // три точки прицела, открытый курок со спицей; полимерная рамка: пылезащитная часть с пазами планки, крупная скоба
        // с квадратным передом, рычаг защёлки магазина под скобой, флажок предохранителя/декокера слева, рукоять ~14°
        // с рифлёными накладками; ствол с резьбой и длинный глушитель с муфтой и торцевой крышкой
        const SC = '#16181b', FR = '#1b1c1f', GRV = '#08090a', WH = '#f0f0e6', ST = '#6c727a', BR = '#5f656c', SUP = '#1d1f22', BY = 0.0185;
        const em = (p) => Object.assign(p, { em: true });
        const xsec = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
        const pinX = (f, y, w) => ({ cyl: true, r: 0.0019, h: w || 0.0282, x: 0, y, z: -f, rz: HP, color: ST, m: true, seg: 8 });
        const serS = (n, f0, step) => Array.from({ length: n * 2 }, (_, i) => mbox(0.0011, 0.0185, 0.0019, (i % 2 ? 1 : -1) * 0.0134, 0.0122, -(f0 + (i >> 1) * step), '#3a3e44'));
        // рифлёные накладки рукояти: приподнятая панель с частыми поперечными канавками вдоль оси рукояти (наклон 0.25)
        const chk = [];
        for (const s of [1, -1]) {
          chk.push(prof([[-0.033, -0.04], ['q', -0.037, -0.075, -0.047, -0.111], [-0.09, -0.105], ['q', -0.083, -0.07, -0.078, -0.04]], 0.0016, FR, 'b', { x: s * 0.0151, bevel: 0.0006, bseg: 1, cs: 3 }));
          for (let i = 0; i < 8; i++) chk.push(box(0.0012, 0.0011, 0.04 - i * 0.0006, s * 0.0161, -0.047 - i * 0.008, 0.0605 + i * 0.008 * 0.25, '#0b0c0d', -0.245));
        }
        return {
          body: [
            // рамка сверху: направляющие и пылезащитная часть до среза затвора, хвостовик под курком
            prof([[-0.074, -0.002], [0.1, -0.002], [0.1, -0.013], ['q', 0.0995, -0.0235, 0.09, -0.0235], [-0.016, -0.0235], [-0.074, -0.019]], 0.0262, FR, 'b', { bevel: 0.0032, bseg: 2, cs: 4 }),
            // рукоять: передняя часть с лёгким выгибом, спинка с «бобровым хвостом»; толстая скруглённая фаска
            prof([[-0.014, -0.02], ['q', -0.025, -0.028, -0.027, -0.044], ['q', -0.032, -0.08, -0.047, -0.12], [-0.05, -0.1235], [-0.0985, -0.1155],
              ['q', -0.092, -0.07, -0.0775, -0.03], ['q', -0.077, -0.019, -0.088, -0.012], ['q', -0.0945, -0.0085, -0.0875, -0.0035], [-0.07, -0.002], [-0.03, -0.004]], 0.0305, FR, 'b', { bevel: 0.0058, bseg: 2, cs: 4 }),
            ...chk,
            // пазы универсальной планки на бортах пылезащитной части и поперечный паз снизу
            ...[1, -1].flatMap(s => [box(0.0012, 0.0022, 0.074, s * 0.0132, -0.0128, -0.06, GRV)]), box(0.022, 0.003, 0.0032, 0, -0.0245, -0.074, GRV),
            // скоба: квадратный перед с выступом, скругление к рукояти
            Object.assign(loop([[-0.024, -0.021], [0.052, -0.021], ['q', 0.0615, -0.024, 0.0615, -0.034], [0.059, -0.052], ['q', 0.057, -0.0605, 0.047, -0.0605], [-0.008, -0.0605], ['q', -0.022, -0.059, -0.028, -0.045]],
              [[-0.017, -0.027], [0.048, -0.027], ['q', 0.0545, -0.028, 0.0545, -0.035], [0.052, -0.049], ['q', 0.0505, -0.0545, 0.044, -0.0545], [-0.006, -0.0545], ['q', -0.016, -0.053, -0.02, -0.043]], 0.0112, FR, 'b'), { bseg: 1, bevel: 0.0018, cs: 3 }),
            // рычаг защёлки магазина под скобой (двусторонний), спуск
            mprof([[-0.008, -0.058], [0.012, -0.058], [0.014, -0.0625], [0.0, -0.065], [-0.012, -0.063]], 0.017, BLK, { bevel: 0.0012, bseg: 1 }),
            mprof([[0.004, -0.021], [0.012, -0.021], ['q', 0.0135, -0.036, 0.004, -0.046], [-0.001, -0.044], ['q', 0.006, -0.034, 0.004, -0.021]], 0.0062, '#2a2d31', { bevel: 0.0009, bseg: 1, cs: 4 }),
            // затворная задержка и флажок предохранителя/декокера слева, оси и штифты
            mprof([[-0.004, -0.0035], [0.026, -0.006], [0.029, -0.0005], [0.026, 0.002], [-0.002, 0.0015]], 0.0026, '#26292d', { x: -0.0146, bevel: 0.0006, bseg: 1 }),
            { cyl: true, r: 0.0036, h: 0.003, x: -0.0145, y: -0.002, z: 0.003, rz: HP, color: ST, m: true, seg: 10 },
            mprof([[-0.074, -0.006], [-0.066, -0.006], [-0.054, -0.012], [-0.05, -0.0165], [-0.057, -0.0195], [-0.068, -0.0165], [-0.076, -0.012]], 0.0028, '#26292d', { x: -0.0148, bevel: 0.0007, bseg: 1 }),
            { cyl: true, r: 0.0042, h: 0.0032, x: -0.0146, y: -0.0105, z: 0.07, rz: HP, color: '#26292d', m: true, seg: 10 },
            pinX(0.022, -0.0105), pinX(-0.062, -0.0075), pinX(-0.004, -0.0165),
            // курок со спицей и поперечными насечками
            mprof([[-0.0745, 0.002], [-0.068, 0.002], [-0.0685, 0.017], ['q', -0.071, 0.0255, -0.081, 0.0265], ['q', -0.0875, 0.0255, -0.0865, 0.0205], ['q', -0.08, 0.017, -0.0775, 0.009]], 0.0078, '#2b2e33', { bevel: 0.0011, bseg: 1, cs: 4 }),
            ...[0, 1, 2].map(i => box(0.0082, 0.0012, 0.0016, 0, 0.0245 - i * 0.0018, 0.0795 + i * 0.0026, GRV, 0.5)),
            // ствол: выступ с резьбой перед затвором; глушитель — муфта с накаткой, корпус, светлое кольцо, скруглённая крышка
            tube(0.0072, 0.098, 0.118, BY, BR, 0, null, 14), ...[0.106, 0.111].map(f => ({ cyl: true, r: 0.0081, h: 0.0016, x: 0, y: BY, z: -f, rx: HP, color: '#3c4147', m: true, seg: 12 })),
            tube(0.0162, 0.114, 0.136, BY, '#26292d', 0, null, 18),
            ...[0, 1, 2, 3, 4, 5, 6, 7].map(i => box(0.0018, 0.0028, 0.018, Math.cos(i * 0.785) * 0.0163, BY + Math.sin(i * 0.785) * 0.0163, -0.125, '#121315', 0, 0, i * 0.785 + HP)),
            tube(0.0152, 0.136, 0.262, BY, SUP, 0, null, 18), tube(0.0156, 0.18, 0.186, BY, '#2e3135', 0, null, 18),
            { cyl: true, r: 0.0128, r2: 0.0152, h: 0.01, x: 0, y: BY, z: -0.267, rx: HP, color: '#26292d', m: true, seg: 18 },
            { cyl: true, r: 0.0046, h: 0.002, x: 0, y: BY, z: -0.2716, rx: HP, color: '#030303', seg: 12 },
            // дульный торец затвора: втулка ствола и направляющая пружины
            { cyl: true, r: 0.0034, h: 0.002, x: 0, y: 0.0055, z: -0.1035, rx: HP, color: '#050505', seg: 8 }
          ],
          slide: [
            // затвор: плоские борта, скруглённый верх; скошенный торец
            xsec([[-0.0124, 0.0], [0.0124, 0.0], [0.0132, 0.0012], [0.0132, 0.0215], ['q', 0.0132, 0.0302, 0.0072, 0.0328], [-0.0072, 0.0328], ['q', -0.0132, 0.0302, -0.0132, 0.0215], [-0.0132, 0.0012]],
              -0.078, 0.104, SC, 'a', { bevel: 0.0016, bseg: 2, cs: 3 }),
            ...serS(8, -0.0735, 0.0039),
            // задняя крышка, окно экстракции справа сверху с казёнником ствола, выбрасыватель
            mprof([[-0.0792, 0.004], [-0.0782, 0.004], [-0.0782, 0.026], [-0.0792, 0.026]], 0.016, '#202326', { bevel: 0.0005, bseg: 1 }),
            box(0.012, 0.0012, 0.04, 0.0045, 0.0328, -0.004, GRV), box(0.0012, 0.0085, 0.04, 0.0131, 0.0255, -0.004, GRV),
            mbox(0.0102, 0.0016, 0.034, 0.0042, 0.0324, -0.006, BR), mbox(0.0102, 0.0036, 0.0016, 0.0042, 0.0312, -0.0226, '#4a4f55'),
            mbox(0.0012, 0.0034, 0.018, 0.0137, 0.0205, 0.024, ST),
            // целик с двумя точками, мушка с точкой
            mprof([[-0.0745, 0.032], [-0.061, 0.032], [-0.0635, 0.0395], [-0.074, 0.0398]], 0.0178, BLK, { bevel: 0.0008, bseg: 1 }), box(0.0036, 0.0046, 0.0145, 0, 0.0378, 0.0675, GRV),
            dot(0.0055, 0.0372, 0.0748, WH, 0.0013), dot(-0.0055, 0.0372, 0.0748, WH, 0.0013),
            mprof([[0.09, 0.032], [0.1, 0.032], [0.0985, 0.0385], [0.0925, 0.0385]], 0.0042, BLK, { bevel: 0.0006, bseg: 1 }), dot(0, 0.0362, -0.0905, WH, 0.0013)
          ],
          // магазин на 12: корпус под углом рукояти, пятка с выступом, патрон сверху
          mag: [box(0.0185, 0.098, 0.031, 0, -0.077, 0.0605, '#2a2c30', -0.245),
            mprof([[-0.0465, -0.1215], [-0.101, -0.1125], [-0.1015, -0.1195], ['q', -0.1005, -0.1245, -0.096, -0.1245], [-0.051, -0.1315], ['q', -0.046, -0.1318, -0.0458, -0.127]], 0.0305, BLK, { bevel: 0.0022, bseg: 2, cs: 3 }),
            { cyl: true, r: 0.0055, h: 0.022, x: 0, y: -0.0215, z: 0.047, rx: HP, color: '#b08a3e', m: true, seg: 10 }],
          muzzle: [0, BY, -0.274], rh: [0, -0.064, 0.058], lh: [-0.035, -0.078, 0.045]
        };
      }
      case 'magnum': {
        // Desert Eagle Mark XIX: массивный затвор с трапециевидным сечением (плоские борта, скошенный верх), длинный неподвижный
        // ствол той же формы (светлее затвора) с планкой и поперечными пазами сверху, гладкой табличкой на борту и «носом» рамки
        // под ним; насечки сзади, курок с кольцом, двусторонний предохранитель на затворе, затворная задержка,
        // большая скоба с квадратным передом и крючком, резиновые накладки с рёбрами
        const SL = '#2a2e34', BRL = '#454b53', FR = '#24272c', GRV = '#08090b', RUB = '#111214', ST = '#6c727a', ENG = '#8a9199';
        // сечение: низ шириной w0 на y0 (с фаской c), вертикальные борта до y1, скосы к верху шириной w1 на y2
        const sec = (w0, w1, y0, y1, y2, c) => { const a = w0 / 2, b = w1 / 2; return c ? [[-a + c, y0], [a - c, y0], [a, y0 + c], [a, y1], [b, y2], [-b, y2], [-a, y1], [-a, y0 + c]] : [[-a, y0], [a, y0], [a, y1], [b, y2], [-b, y2], [-a, y1]]; };
        // выдавливание сечения вдоль ствола от f0 до f1
        const xsec = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
        const ax = (r, f, y, x, h, c) => ({ cyl: true, r, h: h || 0.003, x, y, z: -f, rz: HP, color: c || ST, m: true, seg: 10 });
        return {
          body: [
            // рамка: направляющие под затвором, рукоять с «бобровым хвостом», скруглённые края
            prof([[-0.1, 0.0], [0.059, 0.0], [0.059, -0.024], [-0.024, -0.024], ['q', -0.028, -0.07, -0.045, -0.134], [-0.106, -0.123], [-0.108, -0.116],
              ['q', -0.094, -0.07, -0.091, -0.022], ['q', -0.099, -0.016, -0.111, -0.013], ['q', -0.116, -0.007, -0.107, -0.002], [-0.1, 0.0]], 0.029, FR, 'b', { bevel: 0.004, bseg: 2, cs: 5 }),
            // «нос» рамки под стволом со скошенным торцом
            prof([[0.057, -0.024], [0.158, -0.024], ['q', 0.166, -0.024, 0.168, -0.016], [0.172, 0.006], [0.057, 0.006]], 0.036, FR, 'b', { bevel: 0.0022, bseg: 2, cs: 3 }),
            box(0.0372, 0.0012, 0.112, 0, -0.0175, -0.115, GRV),
            // скоба с квадратным передом и упором под палец
            Object.assign(loop([[-0.022, -0.022], [0.054, -0.022], [0.058, -0.028], [0.058, -0.06], [0.063, -0.066], [0.058, -0.072], [-0.012, -0.072], ['q', -0.024, -0.068, -0.026, -0.05]],
              [[-0.015, -0.03], [0.048, -0.03], [0.05, -0.034], [0.05, -0.06], [0.047, -0.064], [-0.008, -0.064], ['q', -0.017, -0.061, -0.018, -0.046]], 0.016, FR, 'b'), { bseg: 1 }),
            trig(0.014, -0.025, ST),
            // резиновые накладки рукояти с поперечными рёбрами и винтом
            prof([[-0.031, -0.03], ['q', -0.035, -0.08, -0.049, -0.124], [-0.099, -0.115], ['q', -0.087, -0.07, -0.085, -0.028], [-0.04, -0.028]], 0.0345, RUB, null, { bevel: 0.003, bseg: 2, cs: 4 }),
            ...[-0.044, -0.054, -0.064, -0.074, -0.084, -0.094, -0.104].map(y => box(0.0362, 0.0014, 0.042, 0, y, 0.061 - (y + 0.05) * 0.2, '#050506', -0.18)),
            ...[1, -1].map(s => ax(0.0034, -0.066, -0.073, s * 0.0181, 0.0016, '#7d838b')),
            // курок с кольцом, затворная задержка и защёлка магазина слева, рычаг разборки спереди
            mprof([[-0.104, 0.0], [-0.093, 0.0], [-0.093, 0.016], ['q', -0.097, 0.027, -0.108, 0.027], ['q', -0.119, 0.025, -0.119, 0.015], ['q', -0.117, 0.006, -0.104, 0.0]], 0.0085, '#4a5058',
              { bevel: 0.0012, bseg: 1, cs: 4, holes: [[[-0.105, 0.009], [-0.112, 0.009], [-0.112, 0.019], [-0.105, 0.019]]] }),
            mprof([[-0.006, -0.003], [0.03, -0.006], [0.033, 0.0], [0.03, 0.005], [-0.004, 0.006]], 0.003, ST, { x: -0.0165, bevel: 0.0008, bseg: 1 }), ax(0.0042, -0.002, 0.0, -0.0168),
            ax(0.0046, -0.017, -0.031, -0.0162), mbox(0.003, 0.006, 0.014, -0.0162, -0.011, -0.046, ST),
            ax(0.0026, 0.044, -0.012, 0, 0.0302, ST), ax(0.0026, -0.062, -0.012, 0, 0.0302, ST),
            // гладкая табличка на правом борту рамки (без надписей)
            mprof([[0.012, -0.006], [0.046, -0.006], ['q', 0.048, -0.006, 0.048, -0.008], [0.048, -0.017], ['q', 0.048, -0.019, 0.046, -0.019], [0.012, -0.019], ['q', 0.01, -0.019, 0.01, -0.017], [0.01, -0.008], ['q', 0.01, -0.006, 0.012, -0.006]],
              0.001, '#3a3f46', { x: 0.015, bevel: 0.0004, bseg: 1, cs: 2 }),
            // ствол: высокий блок со скошенным верхом (светлее затвора), планка с поперечными пазами, мушка, торец с каналом
            xsec(sec(0.0325, 0.0115, 0.006, 0.029, 0.0445, 0.002), 0.059, 0.177, BRL, 'a', { bevel: 0.0022, bseg: 2 }),
            // табличка с «гравировкой» на левом борту ствола (без текста): утопленная рамка и тонкие линии
            box(0.0012, 0.012, 0.074, -0.0185, 0.0185, -0.119, '#1b1e22'),
            box(0.0012, 0.0014, 0.056, -0.0188, 0.0215, -0.114, ENG), box(0.0012, 0.0011, 0.036, -0.0188, 0.0165, -0.104, ENG), box(0.0012, 0.0011, 0.012, -0.0188, 0.0165, -0.146, ENG),
            Object.assign(mbox(0.0105, 0.006, 0.11, 0, 0.0468, -0.117, BRL), { skin: 'a', m: false }),
            // продольные канавки по бортам ствола под планкой и скошенный дульный срез («коронка»)
            ...[1, -1].map(s => box(0.0012, 0.0022, 0.104, s * 0.0158, 0.033, -0.12, GRV)),
            ...[1, -1].map(s => mbox(0.0011, 0.0011, 0.104, s * 0.0161, 0.0312, -0.12, '#6a717a')),
            mprof([[0.177, 0.006], [0.177, 0.0445], [0.1815, 0.0405], [0.1835, 0.01]], 0.0302, BRL, { bevel: 0.0014, bseg: 2, cs: 2 }),
            ...[0.07, 0.082, 0.094, 0.106, 0.118, 0.13, 0.142].map(f => box(0.0112, 0.003, 0.0034, 0, 0.0488, -f, GRV)),
            mprof([[0.155, 0.049], [0.171, 0.049], [0.169, 0.057], [0.162, 0.0615], [0.158, 0.0615]], 0.006, BLK, { bevel: 0.0008, bseg: 1 }), dot(0, 0.0575, -0.1566, '#ffb030', 0.0016),
            { cyl: true, r: 0.0098, h: 0.0014, x: 0, y: 0.026, z: -0.1777, rx: HP, color: '#8a9098', m: true, seg: 16 },
            { cyl: true, r: 0.0068, h: 0.0018, x: 0, y: 0.026, z: -0.178, rx: HP, color: '#030303', seg: 14 },
            // ствол внутри затвора (виден, когда затвор откатан)
            tube(0.0108, -0.03, 0.062, 0.026, '#5a6068', 0, null, 12)
          ],
          slide: [
            xsec(sec(0.0325, 0.0115, 0.0, 0.029, 0.0445, 0), -0.097, 0.0585, SL, 'b', { bevel: 0.0022, bseg: 2 }),
            // насечки затвора наклонены вперёд, как у Mark XIX; светлая кромка за каждой — читаются и на тёмном затворе
            ...Array.from({ length: 10 }, (_, i) => box(0.0372, 0.022, 0.0019, 0, 0.0135, 0.092 - i * 0.0042, '#050506', 0.22)),
            ...Array.from({ length: 10 }, (_, i) => mbox(0.0366, 0.021, 0.0007, 0, 0.0135, 0.0905 - i * 0.0042, '#3b4148', 0.22)),
            // скошенный передний срез затвора
            mprof([[0.0585, 0.0], [0.0645, 0.0], [0.0585, 0.0285]], 0.0322, SL, { bevel: 0.0012, bseg: 1, cs: 2 }),
            // окно экстракции справа с затвором, целик с двумя точками к стрелку
            box(0.0012, 0.011, 0.04, 0.0185, 0.021, 0.008, GRV), mbox(0.0012, 0.0065, 0.024, 0.0181, 0.021, 0.006, '#5a6068'),
            mbox(0.019, 0.0085, 0.014, 0, 0.048, 0.083, BLK), box(0.004, 0.005, 0.0144, 0, 0.0507, 0.083, GRV),
            dot(0.0056, 0.0495, 0.0902, '#e8ffe8', 0.0014), dot(-0.0056, 0.0495, 0.0902, '#e8ffe8', 0.0014),
            // двусторонний предохранитель
            ...[1, -1].flatMap(s => [mprof([[-0.09, 0.012], [-0.072, 0.0155], [-0.069, 0.021], [-0.088, 0.023]], 0.003, ST, { x: s * 0.0196, bevel: 0.0008, bseg: 1 }), ax(0.0048, -0.084, 0.018, s * 0.0189, 0.003, ST)])
          ],
          // магазин .50 AE: корпус под углом рукояти, пятка, патрон сверху
          mag: [mbox(0.022, 0.1, 0.042, 0, -0.08, 0.068, MET2, -0.18), mbox(0.034, 0.008, 0.064, 0, -0.1344, 0.0777, BLK, -0.18),
            { cyl: true, r: 0.0062, h: 0.03, x: 0, y: -0.029, z: 0.06, rx: HP, color: '#b08a3e', m: true, seg: 10 }],
          muzzle: [0, 0.026, -0.185], rh: [0, -0.07, 0.064], lh: [-0.038, -0.084, 0.055]
        };
      }
      case 'galil': {
        // Galil AR: фрезерованная коробка с продольными канавками и заклёпками, крышка-«арка» с откидным диоптром в «ушах»,
        // загнутая вверх рукоять заряжания справа, переводчики справа (рычаг) и слева (флажок); чёрное полимерное цевьё со скруглённым
        // сечением и окнами, накладка газовой трубки; высокая стойка мушки с «ушами», пламегаситель с прорезями;
        // складной трубчатый приклад с резиновым затыльником; стальной магазин на 35 с рёбрами
        const BY = 0.016, RW = 0.043;
        const GRV = '#08090a', HG = '#2b2d30', RB = '#17181a', BOLT = '#8e959c', BR = '#b08a3e';
        const rod = (a, b, r, c) => { const o = []; bone(o, a, b, r, r, c || MET2, { m: true, noJoint: true }); return o[0]; };
        return {
          body: [
            // коробка: борта с продольными канавками, скос к переднему вкладышу
            prof([[-0.14, -0.03], [0.12, -0.03], [0.156, -0.027], ['q', 0.172, -0.025, 0.172, -0.012], [0.172, 0.022], [-0.14, 0.022]], RW, MET, 'a', { bevel: 0.0024, bseg: 1, cs: 3 }),
            ...[1, -1].flatMap(s => [box(0.0012, 0.0035, 0.2, s * 0.0222, 0.006, 0.02, GRV), box(0.0012, 0.0035, 0.2, s * 0.0222, -0.013, 0.02, GRV)]),
            ...[[-0.126, 0.01], [-0.126, -0.018], [-0.044, -0.02], [-0.02, -0.02], [0.138, -0.018], [0.15, 0.012]].map(([f, y]) => pinT(f, y, RW + 0.0016, 0.0026, '#3e444b')),
            // крышка-арка, стык, кнопка направляющей
            xs(archS(0.0188, 0.0205, 0.032, 0.047), -0.146, 0.17, MET, 'a', { bevel: 0.0018, bseg: 1, cs: 5 }),
            mbox(0.011, 0.01, 0.008, 0, 0.034, 0.1505, MET2),
            // окно экстракции справа, затворная рама в нём (часть рукояти заряжания)
            box(0.0012, 0.016, 0.07, 0.0219, 0.012, -0.004, GRV),
            // откидной диоптр в «ушах» на хвосте крышки
            mprof([[-0.146, 0.046], [-0.084, 0.049], [-0.088, 0.055], [-0.146, 0.057]], 0.03, BLK, { bevel: 0.0015, bseg: 1 }),
            ...[1, -1].map(s => mprof([[-0.15, 0.052], [-0.09, 0.054], [-0.094, 0.068], [-0.106, 0.073], [-0.134, 0.073], ['q', -0.148, 0.07, -0.15, 0.062]], 0.0042, BLK, { x: s * 0.0152, bevel: 0.0008, bseg: 1, cs: 2 })),
            mprof([[-0.13, 0.055], [-0.116, 0.055], [-0.117, 0.07], ['q', -0.123, 0.073, -0.129, 0.07]], 0.02, STEEL, { bevel: 0.0008, bseg: 1, cs: 2 }), box(0.006, 0.006, 0.0018, 0, 0.0645, 0.1235, '#050505'),
            // переводчики: длинный рычаг справа, флажок слева над рукоятью
            { cyl: true, r: 0.0062, h: 0.003, x: 0.0234, y: 0.012, z: 0.122, rz: HP, color: MET2, m: true, seg: 10 },
            mprof([[-0.128, 0.0175], [-0.03, 0.013], ['q', -0.022, 0.012, -0.021, 0.004], [-0.022, -0.012], [-0.031, -0.012], [-0.032, 0.004], [-0.128, 0.007]], 0.0026, MET2, { x: 0.0236, bevel: 0.0007, bseg: 1, cs: 3 }),
            mprof([[-0.074, -0.004], [-0.046, -0.012], [-0.044, -0.004], [-0.07, 0.004]], 0.003, MET2, { x: -0.0236, bevel: 0.0007, bseg: 1 }), { cyl: true, r: 0.0048, h: 0.003, x: -0.0236, y: 0.0, z: 0.072, rz: HP, color: MET2, m: true, seg: 8 },
            // хвостовик коробки и шарнир приклада
            mprof([[-0.168, 0.02], [-0.138, 0.02], [-0.138, -0.03], [-0.168, -0.034]], 0.044, MET2, { bevel: 0.002, bseg: 1 }),
            { cyl: true, r: 0.0058, h: 0.05, x: 0.0, y: 0.034, z: 0.162, rz: HP, color: MET2, m: true, seg: 10 },
            // цевьё: нижнее со скруглённым сечением и окнами, накладка газовой трубки, торцевое кольцо
            xs(rrect(-0.0215, -0.036, 0.0215, 0.016, 0.012), 0.18, 0.428, HG, 'b', { bevel: 0.0045, bseg: 2, cs: 3 }),
            xs(archS(0.0145, 0.021, 0.034, 0.049), 0.186, 0.42, HG, 'b', { bevel: 0.0035, bseg: 2, cs: 4 }),
            ...[0.22, 0.258, 0.296, 0.334, 0.372].flatMap(f => [1, -1].map(s => prof(rrect(f - 0.013, -0.016, f + 0.013, -0.003, 0.0055), 0.0016, '#0a0b0c', null, { x: s * 0.026, bevel: 0, cs: 3 }))),
            ...[0.22, 0.258, 0.296, 0.334, 0.372].map(f => box(0.024, 0.0014, 0.02, 0, -0.0408, -f, GRV)),
            xs(rrect(-0.026, -0.036, 0.026, 0.052, 0.012), 0.43, 0.442, MET2, null, { bevel: 0.0014, bseg: 1, cs: 3, m: true }),
            // газовый блок со стойкой мушки: «уши», мушка, штыковая планка
            mprof([[0.442, -0.006], [0.506, -0.006], ['q', 0.51, 0.004, 0.506, 0.012], [0.498, 0.05], [0.452, 0.05], [0.442, 0.04]], 0.028, MET2, { bevel: 0.0022, bseg: 1, cs: 2 }),
            mprof([[0.462, 0.05], [0.49, 0.05], [0.487, 0.076], [0.466, 0.076]], 0.014, MET2, { bevel: 0.0014, bseg: 1 }),
            ...[1, -1].map(s => mprof([[0.462, 0.07], [0.488, 0.07], [0.486, 0.096], ['q', 0.483, 0.1, 0.478, 0.1], [0.472, 0.1], ['q', 0.466, 0.1, 0.464, 0.095]], 0.0034, MET, { x: s * 0.0108, bevel: 0.0008, bseg: 1, cs: 2 })),
            mbox(0.0028, 0.02, 0.0028, 0, 0.086, -0.475, STEEL), dot(0, 0.0965, -0.4735, '#d6ff9a', 0.0012),
            mbox(0.012, 0.016, 0.03, 0, -0.016, -0.49, MET2),
            // ствол, пламегаситель с прорезями (низ закрыт)
            cz(0.0105, 0.44, 0.6, BY, MET, { r2: 0.0096, seg: 12 }), cz(0.0128, 0.596, 0.606, BY, MET2, { seg: 14 }), cz(0.0128, 0.605, 0.676, BY, BLK, { seg: 14 }),
            ...[0, 0.9, HP, Math.PI - 0.9, Math.PI].map(a => box(0.0018, 0.0036, 0.038, Math.cos(a) * 0.0126, BY + Math.sin(a) * 0.0126, -0.648, '#050506', 0, 0, a + HP)),
            { cyl: true, r: 0.0062, h: 0.0018, x: 0, y: BY, z: -0.6762, rx: HP, color: '#050505', seg: 10 },
            // рукоять с рёбрами, спусковая скоба, крючок, защёлка магазина
            prof([[-0.06, -0.029], [-0.022, -0.029], ['q', -0.029, -0.072, -0.042, -0.131], ['q', -0.062, -0.134, -0.084, -0.126], ['q', -0.072, -0.07, -0.06, -0.029]], 0.034, HG, 'b', { bevel: 0.006, bseg: 2, cs: 5 }),
            ...[-0.064, -0.08, -0.096, -0.112].map(y => box(0.0412, 0.0026, 0.014, 0, y, 0.054 - (y + 0.06) * 0.4, '#101112')),
            Object.assign(loop([[-0.03, -0.029], [0.058, -0.029], ['q', 0.06, -0.064, 0.03, -0.068], [-0.02, -0.068], ['q', -0.03, -0.064, -0.03, -0.046]],
              [[-0.02, -0.036], [0.048, -0.036], ['q', 0.048, -0.058, 0.028, -0.06], [-0.014, -0.06], ['q', -0.02, -0.056, -0.02, -0.046]], 0.01, MET, null, true), { bseg: 1, cs: 3 }),
            trig(0.004, -0.03), mprof([[0.03, -0.03], [0.04, -0.03], [0.041, -0.05], ['q', 0.04, -0.055, 0.035, -0.055], [0.03, -0.052]], 0.016, MET2, { bevel: 0.0012, bseg: 1, cs: 2 }),
            // складной трубчатый приклад: верхняя и нижняя трубы, перемычка, щека, затыльник с рёбрами
            rod([0, 0.034, 0.168], [0, 0.028, 0.4], 0.0078), rod([0, -0.022, 0.168], [0, -0.092, 0.4], 0.0078), rod([0, 0.03, 0.29], [0, -0.054, 0.29], 0.006),
            prof([[-0.21, 0.031], [-0.37, 0.033], ['q', -0.38, 0.033, -0.38, 0.042], ['q', -0.378, 0.05, -0.368, 0.05], [-0.218, 0.048], ['q', -0.208, 0.047, -0.208, 0.04]], 0.026, HG, 'b', { bevel: 0.004, bseg: 2, cs: 2 }),
            prof([[-0.395, 0.046], [-0.41, 0.046], ['q', -0.417, 0.046, -0.417, 0.038], [-0.417, -0.104], ['q', -0.417, -0.112, -0.408, -0.112], [-0.395, -0.108]], 0.042, RB, 'b', { bevel: 0.004, bseg: 2, cs: 3 }),
            ...[0.03, 0.01, -0.01, -0.03, -0.05, -0.07, -0.09].map(y => box(0.044, 0.0022, 0.004, 0, y, 0.4208, '#060707')),
            swivel(-0.036, -0.3), swivel(-0.1, 0.39)
          ],
          // рукоять заряжания справа: рама в окне, шток в пазу и загнутый вверх рычаг
          slide: [mbox(0.0012, 0.01, 0.054, 0.0226, 0.0125, -0.006, BOLT), mbox(0.004, 0.009, 0.05, 0.0245, 0.015, -0.08, STEEL), { cyl: true, r: 0.0045, h: 0.026, x: 0.036, y: 0.016, z: -0.104, rz: HP, color: MET2, m: true, seg: 8 },
            mprof([[0.098, 0.011], [0.118, 0.011], [0.118, 0.036], ['q', 0.117, 0.04, 0.113, 0.04], [0.108, 0.04], [0.108, 0.02], [0.098, 0.02]], 0.0065, MET2, { x: 0.05, bevel: 0.0012, bseg: 1, cs: 2 })],
          // изогнутый стальной магазин на 35: корпус, рёбра вдоль изгиба, крышка, патрон сверху
          mag: [prof([[0.042, -0.028], [0.11, -0.028], ['q', 0.128, -0.12, 0.203, -0.212], [0.166, -0.24], ['q', 0.09, -0.13, 0.042, -0.028]], 0.028, '#202123', null, { bevel: 0.0028, bseg: 1, cs: 10 }),
            prof([[0.06, -0.044], [0.068, -0.044], ['q', 0.086, -0.124, 0.165, -0.204], [0.158, -0.21], ['q', 0.077, -0.128, 0.06, -0.044]], 0.0322, '#2f3236', null, { cs: 10 }),
            prof([[0.088, -0.036], [0.095, -0.036], ['q', 0.11, -0.114, 0.184, -0.192], [0.178, -0.198], ['q', 0.1, -0.118, 0.088, -0.036]], 0.0322, '#2f3236', null, { cs: 10 }),
            mprof([[0.163, -0.238], [0.204, -0.209], [0.21, -0.2165], [0.1695, -0.2455]], 0.032, MET, { bevel: 0.0014, bseg: 1 }),
            { cyl: true, r: 0.0048, h: 0.03, x: 0, y: -0.023, z: -0.074, rx: HP, color: BR, m: true, seg: 8 }],
          magPivot: [0, -0.026, -0.112], charge: [0.05, 0.026, -0.104],
          muzzle: [0, BY, -0.682], rh: [0, -0.078, 0.065], lh: [0, -0.03, -0.28]
        };
      }
      case 'famas': {
        // FAMAS F1 (булл-пап): скруглённый полимерный корпус-приклад со щекой и резиновым затыльником, магазин за рукоятью,
        // узкое цевьё с вентиляционными окнами и сложенными вдоль бортов сошками; высокая дуга-ручка с каналом прицеливания,
        // диоптром сзади и мушкой в «ушах» на переднем столбе; рукоять взведения под дугой; большая скоба на всю кисть;
        // ствол с кольцами под ружейную гранату и пламегасителем
        const BY = 0.018;
        const GRV = '#08090a', BD = '#3a4034', GP = '#1c1d1f';
        const rod = (a, b, r, c) => { const o = []; bone(o, a, b, r, r, c || MET2, { m: true, noJoint: true }); return o[0]; };
        return {
          body: [
            // корпус-приклад: от затыльника до рукояти, скошенный низ к шахте магазина
            prof([[-0.354, 0.033], [-0.02, 0.033], [0.12, 0.03], [0.12, -0.026], [-0.02, -0.028], [-0.18, -0.038], ['q', -0.27, -0.052, -0.322, -0.08], [-0.354, -0.086]], 0.048, BD, 'a', { bevel: 0.007, bseg: 2, cs: 4 }),
            // цевьё: уже корпуса, скос снизу к носу, окна сверху по бортам
            prof([[0.11, 0.03], [0.318, 0.026], ['q', 0.334, 0.026, 0.334, 0.012], [0.334, -0.012], ['q', 0.332, -0.024, 0.318, -0.026], [0.11, -0.03]], 0.04, BD, 'a', { bevel: 0.006, bseg: 2, cs: 4 }),
            ...[0.2, 0.232, 0.264, 0.296].flatMap(f => [1, -1].map(s => prof(rrect(f - 0.011, 0.008, f + 0.011, 0.02, 0.005), 0.0016, GRV, null, { x: s * 0.026, bevel: 0, cs: 3 }))),
            // щека сверху на прикладе и стык с цевьём
            prof([[-0.33, 0.036], [-0.226, 0.036], ['q', -0.214, 0.036, -0.214, 0.044], ['q', -0.218, 0.05, -0.23, 0.05], [-0.32, 0.05], ['q', -0.33, 0.05, -0.33, 0.042]], 0.04, BD, 'a', { bevel: 0.004, bseg: 2, cs: 3 }),
            ...[1, -1].map(s => box(0.0012, 0.062, 0.0016, s * 0.0312, 0.0, -0.112, GRV)),
            // дуга-ручка: передний и задний столбы, канал прицеливания сверху, диоптр сзади, мушка в «ушах» спереди
            Object.assign(loop([[-0.222, 0.034], [-0.206, 0.08], ['q', -0.2, 0.09, -0.186, 0.09], [0.252, 0.09], ['q', 0.272, 0.09, 0.282, 0.078], [0.31, 0.03]],
              [[-0.184, 0.036], [-0.176, 0.074], [0.244, 0.074], [0.262, 0.068], [0.282, 0.036]], 0.026, BD, 'a', false), { bevel: 0.004, bseg: 2, cs: 3 }),
            box(0.008, 0.002, 0.42, 0, 0.0952, -0.03, GRV),
            mprof([[-0.212, 0.09], [-0.17, 0.09], [-0.17, 0.104], ['q', -0.172, 0.11, -0.18, 0.11], [-0.204, 0.11], ['q', -0.212, 0.108, -0.212, 0.1]], 0.024, GP, { bevel: 0.002, bseg: 1, cs: 2 }),
            { torus: true, r: 0.0042, tube: 0.0016, x: 0, y: 0.104, z: 0.19, color: BLK, m: true, seg: 10 },
            ...[1, -1].map(s => mprof([[0.262, 0.09], [0.288, 0.09], [0.284, 0.112], ['q', 0.282, 0.116, 0.278, 0.116], [0.272, 0.116], ['q', 0.266, 0.115, 0.265, 0.11]], 0.0034, GP, { x: s * 0.0088, bevel: 0.0008, bseg: 1, cs: 2 })),
            mbox(0.003, 0.016, 0.003, 0, 0.102, -0.276, MET2),
            // окно экстракции справа у щеки с затвором, переводчик слева, защёлка магазина
            box(0.0012, 0.02, 0.064, 0.0262, 0.012, 0.096, GRV), mbox(0.0014, 0.012, 0.04, 0.0268, 0.012, 0.09, '#5d636b'),
            mprof([[-0.03, 0.004], [-0.1, -0.006], [-0.1, 0.002], [-0.04, 0.012]], 0.003, MET2, { x: -0.0262 }), mbox(0.012, 0.014, 0.022, 0.0, -0.047, 0.098, BLK),
            // рукоять, большая скоба на всю кисть, крючок
            prof([[0.008, -0.032], [-0.026, -0.032], ['q', -0.032, -0.074, -0.046, -0.126], [-0.084, -0.12], ['q', -0.078, -0.07, -0.066, -0.032]], 0.03, GP, 'b', { bevel: 0.006, bseg: 2, cs: 5 }),
            ...[-0.06, -0.075, -0.09, -0.105].map(y => box(0.0412, 0.0026, 0.012, 0, y, 0.056 - (y + 0.06) * 0.35, '#0b0c0d')),
            prof([[0.098, -0.03], [0.114, -0.03], ['q', 0.12, -0.082, 0.018, -0.126], [-0.044, -0.138], [-0.046, -0.127], [0.01, -0.114], ['q', 0.1, -0.076, 0.098, -0.03]], 0.014, GP, 'b', { bevel: 0.0025, bseg: 2, cs: 6 }),
            trig(0.03, -0.034),
            // затыльник с рёбрами
            prof([[-0.361, 0.04], [-0.375, 0.04], ['q', -0.381, 0.04, -0.381, 0.033], [-0.381, -0.088], ['q', -0.381, -0.095, -0.374, -0.095], [-0.361, -0.093]], 0.05, GP, 'b', { bevel: 0.004, bseg: 2, cs: 3 }),
            ...[0.02, 0.0, -0.02, -0.04, -0.06].map(y => box(0.05, 0.0022, 0.004, 0, y, 0.3848, '#060707')),
            // ствол: кольца под гранату, переходник, пламегаситель с прорезями
            cz(0.0118, 0.33, 0.6, BY, MET, { seg: 12 }), cz(0.0152, 0.36, 0.49, BY, MET2, { seg: 14 }), ...[0.4, 0.43, 0.46].map(f => cz(0.0168, f, f + 0.007, BY, BLK, { seg: 14 })),
            cz(0.0168, 0.585, 0.63, BY, BLK, { seg: 14 }), ringZ(0.0168, 0.0014, 0.6, BY, MET2, 14),
            ...[0, HP, Math.PI].map(a => box(0.0018, 0.003, 0.026, Math.cos(a) * 0.0166, BY + Math.sin(a) * 0.0166, -0.615, '#050506', 0, 0, a + HP)),
            { cyl: true, r: 0.0075, h: 0.0018, x: 0, y: BY, z: -0.6302, rx: HP, color: '#050505', seg: 10 },
            // сошки: ножки вдоль бортов цевья, шарнир на носу, лапки
            rod([0.0255, -0.008, -0.33], [0.0255, -0.008, -0.16], 0.0046), rod([-0.0255, -0.008, -0.33], [-0.0255, -0.008, -0.16], 0.0046),
            xs(rrect(-0.03, -0.016, 0.03, 0.0, 0.006), 0.322, 0.34, MET2, null, { bevel: 0.0015, bseg: 1, cs: 2, m: true }),
            mbox(0.008, 0.012, 0.018, 0.0262, -0.008, -0.16, BLK), mbox(0.008, 0.012, 0.018, -0.0262, -0.008, -0.16, BLK),
            swivel(-0.046, 0.3), swivel(-0.03, -0.31)
          ],
          // рукоять взведения под дугой: Т-образная лопатка, ход назад
          slide: [mbox(0.006, 0.006, 0.05, 0, 0.056, 0.17, STEEL), mbox(0.03, 0.01, 0.012, 0, 0.056, 0.2, MET2), mbox(0.006, 0.018, 0.01, 0, 0.066, 0.2, MET2)],
          slideK: 0.05,
          // прямой магазин на 25 за рукоятью: рёбра, пятка
          mag: [prof([[-0.172, -0.044], [-0.1, -0.044], ['q', -0.104, -0.12, -0.116, -0.198], [-0.182, -0.198], ['q', -0.176, -0.12, -0.172, -0.044]], 0.026, '#232427', null, { bevel: 0.0028, bseg: 1, cs: 6 }),
            ...[-0.07, -0.095, -0.12, -0.145, -0.17].map(y => box(0.0316, 0.004, 0.06, 0, y, 0.138 + (y + 0.07) * -0.1, '#17181a')),
            mprof([[-0.186, -0.196], [-0.112, -0.196], [-0.11, -0.208], ['q', -0.11, -0.212, -0.115, -0.212], [-0.184, -0.212], ['q', -0.188, -0.212, -0.188, -0.208]], 0.034, BLK, { bevel: 0.0015, bseg: 1, cs: 2 }),
            { cyl: true, r: 0.0046, h: 0.032, x: 0, y: -0.04, z: 0.13, rx: HP, color: '#b08a3e', m: true, seg: 8 }],
          charge: [0, 0.068, 0.2],
          muzzle: [0, BY, -0.635], rh: [0, -0.078, 0.052], lh: [0, -0.01, -0.22]
        };
      }
      case 'ssg': {
        // SSG 08: алюминиевое шасси — коробка с планкой, длинное цевьё-труба с прорезями M-LOK и планкой снизу, эргономичная рукоять,
        // складной скелетный приклад с регулируемой щекой и затыльником; рифлёный ствол с дульным тормозом, оптика на кольцах,
        // затвор с шаровой рукоятью, полимерный магазин на 10
        const BY = 0.04, SY = 0.084;
        const GRV = '#08090a', SK = '#2a2d2b', SB = '#1b1c1e', RUB = '#121314';
        return {
          body: [
            // ствольная коробка, шасси под ней со шахтой магазина, планка под оптику
            cz(0.0175, -0.13, 0.15, BY, MET, { seg: 16 }),
            prof([[-0.172, BY - 0.004], [0.152, BY - 0.004], [0.152, -0.03], [0.082, -0.034], [-0.006, -0.034], [-0.03, -0.03], [-0.172, -0.026]], 0.044, SK, 'a', { bevel: 0.003, bseg: 1, cs: 2 }),
            ...picL(-0.128, 0.16, 0.0606, 0.02),
            box(0.0012, 0.014, 0.066, 0.0178, BY + 0.003, -0.012, GRV), mbox(0.0014, 0.008, 0.04, 0.0182, BY + 0.003, -0.008, '#5d636b'),
            cz(0.0138, -0.158, -0.13, BY, MET2, { seg: 12 }),
            // цевьё: восьмигранная труба вокруг ствола, прорези по бортам, планка снизу, торцевое кольцо
            xs([[-0.016, BY - 0.026], [0.016, BY - 0.026], [0.022, BY - 0.02], [0.022, BY + 0.01], [0.016, BY + 0.016], [-0.016, BY + 0.016], [-0.022, BY + 0.01], [-0.022, BY - 0.02]],
              0.15, 0.44, SK, 'a', { bevel: 0.002, bseg: 1 }),
            ...[0.19, 0.236, 0.282, 0.328, 0.374].flatMap(f => [1, -1].map(s => prof(rrect(f - 0.016, BY - 0.012, f + 0.016, BY + 0.0, 0.0055), 0.0016, GRV, null, { x: s * 0.0236, bevel: 0, cs: 3 }))),
            ...picL(0.3, 0.42, BY - 0.031, 0.016).map(p => Object.assign(p, { y: 2 * (BY - 0.031) - p.y })),
            // ствол с долами, дульный тормоз с окнами
            cz(0.011, 0.44, 0.72, BY, MET, { r2: 0.0102, seg: 12 }),
            ...[0, 1, 2, 3].map(i => { const a = i * HP + Math.PI / 4; return box(0.0024, 0.0014, 0.24, Math.cos(a) * 0.0102, BY + Math.sin(a) * 0.0102, -0.58, '#121314', 0, 0, a + HP); }),
            cz(0.0152, 0.716, 0.766, BY, BLK, { seg: 14 }), ringZ(0.0152, 0.0013, 0.722, BY, MET2, 14),
            ...[0.734, 0.748].flatMap(f => [1, -1].map(s => box(0.006, 0.009, 0.008, s * 0.0128, BY, -f, '#050506'))),
            { cyl: true, r: 0.006, h: 0.0016, x: 0, y: BY, z: -0.7662, rx: HP, color: '#050505', seg: 10 },
            // рукоять, спусковая скоба шасси, крючок, защёлка магазина
            prof([[-0.112, -0.026], [-0.076, -0.026], ['q', -0.09, -0.07, -0.108, -0.124], ['q', -0.112, -0.134, -0.124, -0.134], [-0.156, -0.13], ['q', -0.152, -0.09, -0.14, -0.06], ['q', -0.132, -0.04, -0.142, -0.03], [-0.142, -0.026]], 0.03, SB, 'b', { bevel: 0.006, bseg: 2, cs: 5 }),
            ...[1, -1].map(s => prof([[-0.112, -0.052], [-0.13, -0.05], ['q', -0.138, -0.09, -0.148, -0.12], [-0.122, -0.124], ['q', -0.108, -0.09, -0.112, -0.052]], 0.0018, '#141517', null, { x: s * 0.0182, bevel: 0.0006, bseg: 1, cs: 3 })),
            Object.assign(loop([[-0.03, -0.03], [-0.096, -0.03], ['q', -0.102, -0.05, -0.098, -0.07], [-0.06, -0.08], ['q', -0.032, -0.08, -0.03, -0.06]],
              [[-0.038, -0.037], [-0.088, -0.037], ['q', -0.093, -0.052, -0.09, -0.066], [-0.06, -0.073], ['q', -0.04, -0.073, -0.038, -0.058]], 0.011, BLK, null, true), { bseg: 1, cs: 3 }),
            trig(-0.062, -0.031, MET2), mbox(0.012, 0.01, 0.01, 0, -0.036, -0.094, MET2),
            // складной скелетный приклад: шарнир, рама с окном, щека на двух стойках, затыльник
            mprof([[-0.2, BY + 0.002], [-0.168, BY + 0.002], [-0.168, -0.03], [-0.2, -0.034]], 0.04, BLK, { bevel: 0.003, bseg: 1 }),
            { cyl: true, r: 0.0058, h: 0.048, x: 0.0, y: -0.022, z: 0.184, color: MET2, m: true, seg: 10 },
            prof([[-0.2, 0.04], [-0.416, 0.04], ['q', -0.426, 0.04, -0.426, 0.03], [-0.426, -0.094], ['q', -0.426, -0.104, -0.416, -0.104], [-0.392, -0.104], [-0.21, -0.042], ['q', -0.2, -0.038, -0.2, -0.028]], 0.026, SK, 'a',
              { bevel: 0.005, bseg: 2, cs: 3, holes: [[[-0.222, 0.026], [-0.404, 0.026], [-0.404, -0.08], ['q', -0.404, -0.086, -0.396, -0.086], [-0.384, -0.086], [-0.228, -0.032], ['q', -0.222, -0.03, -0.222, -0.022]]] }),
            prof([[-0.25, 0.054], [-0.392, 0.056], ['q', -0.402, 0.056, -0.402, 0.064], ['q', -0.398, 0.072, -0.388, 0.072], [-0.262, 0.07], ['q', -0.248, 0.068, -0.248, 0.06]], 0.034, SB, 'b', { bevel: 0.004, bseg: 2, cs: 3 }),
            ...[-0.28, -0.37].map(f => ({ cyl: true, r: 0.0042, h: 0.018, x: 0, y: 0.048, z: -f, color: MET2, m: true, seg: 8 })),
            prof([[-0.428, 0.046], [-0.44, 0.046], ['q', -0.445, 0.046, -0.445, 0.04], [-0.445, -0.104], ['q', -0.445, -0.11, -0.44, -0.11], [-0.428, -0.11]], 0.04, RUB, null, { bevel: 0.0035, bseg: 2, cs: 3 }),
            swivel(-0.112, 0.4), Object.assign(swivel(BY - 0.04, -0.4), { seg: 8 }),
            // оптика на двух кольцах
            ...scopeParts(-0.205, 0.255, SY, { rt: 0.0152, ro: 0.0245, re: 0.0215, tf: -0.03, len: 0.075, le: 0.065, ring: [-0.1, 0.08], base: 0.0662 }),
            // 2.5: сложенные сошки на нижней планке цевья
            ...bipod(0.39, 0.004, 0.0125, 0.2)
          ],
          // затвор: корпус, ручка с шаровой рукоятью (повёрнута вверх при открытии)
          bolt: [{ cyl: true, r: 0.0058, h: 0.052, x: 0.03, y: 0.0, z: 0.0, rz: HP, color: MET2, m: true }, { cyl: true, r: 0.0048, h: 0.022, x: 0.062, y: -0.008, z: 0.012, rz: HP + 0.35, color: MET2, m: true },
            { sph: true, r: 0.0125, x: 0.074, y: -0.014, z: 0.018, color: BLK, m: true }, tube(0.0128, -0.02, 0.05, 0, MET2), tube(0.0116, -0.07, -0.02, 0, '#16171a')],
          boltPos: [0, BY, 0.06],
          // отъёмный полимерный магазин на 10: корпус, рёбра, пятка
          mag: [mprof([[-0.004, -0.032], [0.076, -0.032], [0.08, -0.112], ['q', 0.08, -0.116, 0.076, -0.116], [0.0, -0.116], ['q', -0.004, -0.116, -0.004, -0.112]], 0.03, '#232427', { bevel: 0.002, bseg: 1, cs: 2 }),
            ...[-0.05, -0.07, -0.09].map(y => mbox(0.0318, 0.0035, 0.07, 0, y, -0.039, '#17181a')),
            mprof([[-0.008, -0.114], [0.084, -0.114], [0.086, -0.124], ['q', 0.086, -0.128, 0.082, -0.128], [-0.006, -0.128], ['q', -0.01, -0.128, -0.01, -0.124]], 0.034, BLK, { bevel: 0.0015, bseg: 1, cs: 2 })],
          muzzle: [0, BY, -0.768], rh: [0, -0.09, 0.145], lh: [0, 0.0, -0.27]
        };
      }
      case 'fiveseven': {
        // Five-SeveN: длинный узкий затвор с круглой верхней гранью, косыми насечками сзади и спереди и окном экстракции, высокая полимерная
        // рамка с планкой на три паза и рукоятью с упорами, скруглённая скоба, магазин на 20 с широкой пяткой и ушком под шнур
        const SC = '#17181b', FR = '#2a2c30', GRV = '#08090a', WH = '#f0f0e6', ST = '#6c727a';
        const pinX = (f, y) => ({ cyl: true, r: 0.0018, h: 0.0262, x: 0, y, z: -f, rz: HP, color: ST, m: true, seg: 8 });
        const em = (p) => Object.assign(p, { em: true });
        const xsec = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
        // косые насечки на бортах затвора
        const serD = (n, f0, step, y0) => Array.from({ length: n * 2 }, (_, i) => box(0.0012, 0.017, 0.0021, (i % 2 ? 1 : -1) * 0.0124, y0, -(f0 + (i >> 1) * step), GRV, 0, 0, 0.32))
          .concat(Array.from({ length: n * 2 }, (_, i) => mbox(0.0011, 0.017, 0.0007, (i % 2 ? 1 : -1) * 0.0124, y0, -(f0 + (i >> 1) * step) + 0.0015, '#41464d', 0, 0, 0.32)));
        return {
          body: [
            // рамка: направляющие, рукоять с упором под палец и выступом, хвостовик
            prof([[-0.088, -0.002], [0.098, -0.002], [0.098, -0.014], ['q', 0.097, -0.02, 0.09, -0.02], [-0.014, -0.02], ['q', -0.025, -0.036, -0.0255, -0.052],
              ['q', -0.036, -0.074, -0.0385, -0.094], ['q', -0.04, -0.113, -0.043, -0.126], [-0.047, -0.131], [-0.1, -0.12], [-0.104, -0.114],
              ['q', -0.098, -0.07, -0.092, -0.04], ['q', -0.088, -0.022, -0.094, -0.014], ['q', -0.098, -0.008, -0.092, -0.005], [-0.088, -0.002]], 0.0248, FR, 'b', { bevel: 0.0056, bseg: 2, cs: 5 }),
            // накладки на рукояти (насечка) и граница зоны
            ...[1, -1].map(s => prof([[-0.04, -0.034], [-0.088, -0.034], ['q', -0.094, -0.07, -0.1, -0.114], [-0.058, -0.124], ['q', -0.05, -0.08, -0.04, -0.034]], 0.0016, FR, 'b', { x: s * 0.013, bevel: 0.0006, bseg: 1, cs: 3 })),
            ...[-0.05, -0.062, -0.074, -0.086, -0.098].flatMap(y => [1, -1].map(s => box(0.0012, 0.0016, 0.044, s * 0.0138, y, 0.067 - (y + 0.05) * 0.33, GRV, -0.32))),
            // планка под фонарь на три паза
            mbox(0.024, 0.0075, 0.058, 0, -0.0235, -0.07, '#1b1c1f'), ...[0.052, 0.07, 0.088].map(f => box(0.0246, 0.0034, 0.0032, 0, -0.0242, -f, GRV)),
            // скоба со скруглённым верхом, крючок, защёлка магазина, затворная задержка, штифты
            Object.assign(loop([[-0.02, -0.016], [0.044, -0.016], ['q', 0.048, -0.024, 0.046, -0.034], [0.042, -0.05], ['q', 0.04, -0.056, 0.034, -0.056], [-0.014, -0.056], ['q', -0.024, -0.054, -0.026, -0.04]],
              [[-0.014, -0.022], [0.037, -0.022], [0.039, -0.027], [0.036, -0.046], ['q', 0.034, -0.05, 0.03, -0.05], [-0.01, -0.05], ['q', -0.018, -0.048, -0.019, -0.036]], 0.0105, FR, 'b'), { bseg: 1 }),
            mprof([[0.003, -0.018], [0.011, -0.018], ['q', 0.012, -0.034, 0.003, -0.046], [-0.002, -0.044], ['q', 0.005, -0.032, 0.003, -0.018]], 0.0058, BLK, { bevel: 0.0008, bseg: 1, cs: 4 }),
            mbox(0.0268, 0.0034, 0.008, 0, -0.0075, -0.037, '#2a2d31'), mbox(0.0268, 0.0075, 0.009, 0, -0.024, 0.0, BLK),
            mprof([[-0.002, -0.004], [0.026, -0.0055], [0.028, -0.0005], [0.0, 0.0005]], 0.0022, '#2a2d31', { x: -0.0134, bevel: 0.0006, bseg: 1 }),
            pinX(-0.003, -0.0095), pinX(0.027, -0.0105), pinX(-0.068, -0.0085),
            // дульный срез ствола и канал
            { cyl: true, r: 0.0066, h: 0.002, x: 0, y: 0.0185, z: -0.1062, rx: HP, color: '#5a6067', m: true, seg: 14 },
            { cyl: true, r: 0.0042, h: 0.0024, x: 0, y: 0.0185, z: -0.1064, rx: HP, color: '#030303', seg: 12 },
            // ушко под шнур в основании рукояти
            { torus: true, r: 0.0055, tube: 0.0015, x: 0, y: -0.126, z: 0.103, ry: HP, color: ST, m: true, seg: 10 }
          ],
          slide: [
            // затвор: круглая верхняя грань и скосы по бокам (±0.0118), длинная передняя скос-фаска
            xsec([[-0.0105, 0.0006], [0.0105, 0.0006], [0.0118, 0.0018], [0.0118, 0.0255], ['q', 0.0105, 0.0318, 0.0062, 0.0318], [-0.0062, 0.0318], ['q', -0.0105, 0.0318, -0.0118, 0.0255], [-0.0118, 0.0018]],
              -0.088, 0.106, SC, 'a', { bevel: 0.0012, bseg: 2 }),
            ...serD(8, -0.082, 0.0034, 0.0135), ...serD(4, 0.074, 0.0036, 0.0135),
            mprof([[-0.0892, 0.004], [-0.0882, 0.004], [-0.0882, 0.026], [-0.0892, 0.026]], 0.0128, '#1f2226', { bevel: 0.0005, bseg: 1 }),
            // окно экстракции справа
            box(0.0128, 0.0012, 0.046, 0.0038, 0.0319, 0.0, GRV), box(0.0012, 0.0085, 0.046, 0.0122, 0.0245, 0.0, GRV),
            mbox(0.0105, 0.0014, 0.036, 0.003, 0.0319, -0.002, '#585e65'), mbox(0.0012, 0.0036, 0.016, 0.0124, 0.0205, 0.022, ST),
            // целик: регулируемый с винтом, мушка на пьедестале с точкой
            mprof([[-0.0845, 0.0315], [-0.07, 0.0315], [-0.0725, 0.0385], [-0.0845, 0.0385]], 0.0175, BLK, { bevel: 0.0008, bseg: 1 }), box(0.0048, 0.0042, 0.0125, 0, 0.0366, 0.0788, GRV),
            em(box(0.0011, 0.0036, 0.0006, 0.0032, 0.0361, 0.0848, WH)), em(box(0.0011, 0.0036, 0.0006, -0.0032, 0.0361, 0.0848, WH)),
            { cyl: true, r: 0.0022, h: 0.004, x: 0.0097, y: 0.0348, z: 0.0775, rz: HP, color: ST, m: true, seg: 8 },
            mbox(0.0046, 0.0064, 0.0066, 0, 0.0348, -0.1005, BLK), dot(0, 0.0352, -0.0976, WH, 0.0016)
          ],
          // магазин на 20: слегка скошенный корпус, пятка с выступом и ушком, патрон сверху
          mag: [box(0.0176, 0.114, 0.03, 0, -0.0735, 0.067, '#17181a', -0.3), mbox(0.0262, 0.008, 0.052, 0, -0.1305, 0.0905, BLK, -0.3),
            mbox(0.0264, 0.003, 0.008, 0, -0.1335, 0.0665, BLK, -0.3), { cyl: true, r: 0.0042, h: 0.02, x: 0, y: -0.0205, z: 0.0452, rx: HP, color: '#b08a3e', m: true, seg: 10 }],
          muzzle: [0, 0.0185, -0.108], rh: [0, -0.066, 0.068], lh: [-0.035, -0.08, 0.045]
        };
      }
      case 'tec9': {
        // Tec-9: штампованный кожух-коробка с рёбрами и взводной ручкой, ствольный кожух с рядами круглых отверстий и «ушами» мушки,
        // магазин ВПЕРЕДИ спусковой скобы (кожух шахты), полимерная рукоять с упором, переводчик слева
        const GRV = '#08090a', RC = '#1d1f22', FR = '#26282b', ST = '#6c727a', BY = 0.021;
        // отверстия кожуха: ряды вдоль ствола, углы вокруг оси
        const holes = [];
        const R = 0.0158;
        // видимые ряды отверстий (верх и борта), шахматный порядок; низ кожуха из камеры не виден
        for (const th of [-32, 28, 90, 152, 212]) {
          const a = th * Math.PI / 180;
          for (let i = 0; i < 6; i++) {
            if (th === 90 && i % 2) continue;
            holes.push({ cyl: true, r: 0.0024, h: 0.0016, x: (R + 0.0002) * Math.cos(a), y: BY + (R + 0.0002) * Math.sin(a), z: -(0.136 + i * 0.0168 + (th === 90 ? 0 : (th === 28 || th === 152) ? 0.0084 : 0)), rz: a - HP, color: GRV, seg: 6 });
          }
        }
        return {
          body: [
            // кожух затвора: коробка с фасками, рёбра жёсткости и пазы
            prof([[-0.0145, -0.004], [0.0145, -0.004], [0.015, -0.003], [0.015, 0.03], ['q', 0.015, 0.0405, 0.0055, 0.041], [-0.0055, 0.041], ['q', -0.015, 0.0405, -0.015, 0.03], [-0.015, -0.003]], 0.232, RC, 'a', { ry: -HP, z: -0.012, bevel: 0.0022, bseg: 2, cs: 3 }),
            prof([[-0.11, 0.012], [-0.104, 0.012], [-0.104, 0.036], [-0.11, 0.036]], 0.034, '#2a2d31', null, { m: true }),
            ...[1, -1].flatMap(s => [box(0.0012, 0.0032, 0.2, s * 0.0155, 0.022, -0.012, GRV), box(0.0012, 0.0032, 0.2, s * 0.0155, 0.006, -0.012, GRV)]),
            // верхние рёбра и окно экстракции справа, затвор в окне
            ...[-0.07, -0.05, -0.03, -0.01, 0.01, 0.03, 0.05].map(f => box(0.0304, 0.0016, 0.0032, 0, 0.0404, -f, GRV)),
            box(0.0012, 0.016, 0.052, 0.0152, 0.028, 0.012, GRV), mbox(0.0012, 0.01, 0.026, 0.0148, 0.026, 0.02, '#5d636b'),
            // целик: прорезь в стойке, взводная рукоять-«гриб» сверху сзади
            mprof([[-0.1, 0.04], [-0.074, 0.04], [-0.078, 0.054], [-0.096, 0.054]], 0.03, BLK, { bevel: 0.0012, bseg: 1 }), box(0.007, 0.01, 0.003, 0, 0.0505, 0.079, GRV),
            // паз взводной рукояти сверху, задняя антабка-петля
            box(0.0042, 0.0012, 0.062, 0, 0.0412, 0.03, GRV), { torus: true, r: 0.0068, tube: 0.0016, x: 0, y: 0.034, z: 0.112, ry: HP, color: ST, m: true, seg: 10 },
                        // ствольный кожух с отверстиями, торцевой хомут, дульный срез
            tube(R, 0.12, 0.248, BY, MET2, 0, null, 16), tube(0.0185, 0.118, 0.13, BY, BLK, 0, null, 16), ...[0.121, 0.1245, 0.128].map(f => ringZ(0.0186, 0.0009, f, BY, '#0b0c0d', 16)), tube(0.0175, 0.236, 0.252, BY, BLK, 0, null, 16), tube(0.0072, 0.2515, 0.2535, BY, '#030303', 0, null, 10),
            ...holes,
            // «уши» мушки: рамка из двух щёк и стойка
            mprof([[0.19, 0.036], [0.246, 0.036], [0.246, 0.07], [0.236, 0.07], [0.236, 0.044], [0.2, 0.044]], 0.006, BLK, { x: 0.011 }), mprof([[0.19, 0.036], [0.246, 0.036], [0.246, 0.07], [0.236, 0.07], [0.236, 0.044], [0.2, 0.044]], 0.006, BLK, { x: -0.011 }),
            mbox(0.004, 0.026, 0.004, 0, 0.056, -0.241, STEEL),
            // нижняя часть: шахта магазина спереди, скоба, полимерная рукоять с упором и «пальцами»
            prof([[0.07, -0.004], [0.128, -0.004], [0.126, -0.051], ['q', 0.126, -0.057, 0.12, -0.057], [0.076, -0.057], ['q', 0.07, -0.057, 0.07, -0.051]], 0.03, FR, 'b', { bevel: 0.005, bseg: 2, cs: 3 }),
            mbox(0.0302, 0.004, 0.066, 0, -0.058, -0.098, BLK),
            prof([[-0.104, -0.004], [0.07, -0.004], [0.07, -0.02], ['q', 0.07, -0.026, 0.062, -0.026], [-0.02, -0.026], ['q', -0.032, -0.052, -0.04, -0.082],
              ['q', -0.05, -0.108, -0.056, -0.138], [-0.06, -0.146], [-0.11, -0.134], [-0.114, -0.126], ['q', -0.108, -0.072, -0.1, -0.036], [-0.104, -0.01]], 0.0272, FR, 'b', { bevel: 0.0058, bseg: 2, cs: 4 }),
            ...[-0.06, -0.072, -0.084, -0.096, -0.108].flatMap(y => [1, -1].map(s => box(0.0012, 0.0024, 0.036, s * 0.0138, y, 0.078 - (y + 0.06) * 0.36, GRV, -0.3))),
            Object.assign(loop([[-0.03, -0.024], [0.075, -0.024], ['q', 0.077, -0.07, 0.044, -0.072], [-0.006, -0.074], ['q', -0.024, -0.07, -0.03, -0.05]],
              [[-0.02, -0.03], [0.066, -0.03], ['q', 0.066, -0.062, 0.042, -0.064], [-0.002, -0.066], ['q', -0.018, -0.062, -0.02, -0.05]], 0.0105, FR, 'b', false), { cs: 3 }),
            trig(0.018, -0.026), mprof([[0.0, -0.01], [-0.026, -0.016], [-0.026, -0.008], [-0.0, -0.002]], 0.003, ST, { x: -0.0148 }),
            // кнопка защёлки магазина, антабка у затыльника рукояти
            { cyl: true, r: 0.0042, h: 0.004, x: -0.0148, y: -0.024, z: 0.01, rz: HP, color: BLK, m: true, seg: 8 },
            { torus: true, r: 0.0055, tube: 0.0015, x: 0, y: -0.14, z: 0.1, ry: HP, color: ST, m: true, seg: 8 }
          ],
          // затвор в окне и взводная рукоять-«гриб» сверху: ходят вместе при взводе
          slide: [mbox(0.0028, 0.008, 0.044, 0.0156, 0.034, 0.06, ST), { cyl: true, r: 0.0042, h: 0.01, x: 0, y: 0.0455, z: 0.052, color: MET2, m: true, seg: 8 },
            { cyl: true, r: 0.0095, h: 0.0065, x: 0, y: 0.0525, z: 0.052, color: BLK, m: true, seg: 14 }, ...[0, 1, 2, 3, 4, 5].map(i => box(0.0016, 0.0062, 0.0035, Math.cos(i * 1.047) * 0.0095, 0.0525, 0.052 + Math.sin(i * 1.047) * 0.0095, '#050506', 0, -i * 1.047, 0))],
          slideK: 0.04,
          // длинный магазин впереди скобы, с рёбрами
          mag: [prof([[0.074, -0.01], [0.122, -0.01], ['q', 0.124, -0.09, 0.123, -0.178], [0.075, -0.178], ['q', 0.073, -0.09, 0.074, -0.01]], 0.0208, '#17181a', null, { bevel: 0.0022, cs: 6 }),
            ...[-0.04, -0.06, -0.08, -0.1, -0.12, -0.14].map(y => mbox(0.0228, 0.0032, 0.046, 0, y, -0.098, '#0d0e10')),
            mprof([[0.07, -0.176], [0.127, -0.176], [0.128, -0.188], [0.069, -0.188]], 0.0276, BLK)],
          muzzle: [0, BY, -0.256], rh: [0, -0.066, 0.068], lh: [-0.035, -0.078, 0.045]
        };
      }
      case 'duals': {
        // 2.5: Dual Berettas — Beretta 92: затвор с открытым верхом (ствол виден сверху между «щеками»), насечки сзади, флажки
        // предохранителя-декокера с обеих сторон, целик с двумя точками и мушка с точкой; рамка с крышкой под стволом, скоба,
        // открытый курок, рычаг разборки и кнопка, задержка затвора; щёчки рукояти с насечкой, винтами и медальоном; магазин на 15.
        // От первого лица в руках правый пистолет, левый — его зеркальная копия (buildViewModel); на витрине и на земле — пара
        const BY = 0.02, GRV = '#08090a', ST = '#6c727a', WH = '#f0f0e6', FRC = '#3b3f45', DK = '#202226', SW = 0.0126;
        const em = (p) => Object.assign(p, { em: true });
        const xsec = (pts, f0, f1, color, skin, opt) => prof(pts, f1 - f0, color, skin, Object.assign({ ry: -HP, z: -(f0 + f1) / 2 }, opt || {}));
        const grip = [[-0.022, -0.019], ['q', -0.025, -0.042, -0.031, -0.062], [-0.049, -0.115], [-0.099, -0.112], ['q', -0.091, -0.07, -0.083, -0.036], ['q', -0.081, -0.022, -0.07, -0.019]];
        const body = [
          // рамка: направляющие под затвором, крышка под стволом со скруглённым носом, рукоять с наклоном ~17°, хвостовик под курком
          prof([[-0.094, 0.005], [0.103, 0.005], ['q', 0.11, 0.004, 0.108, -0.004], [0.099, -0.012], [-0.014, -0.012],
            ['q', -0.017, -0.03, -0.024, -0.05], [-0.048, -0.122], ['q', -0.05, -0.13, -0.058, -0.13], [-0.1, -0.126], ['q', -0.108, -0.124, -0.106, -0.116],
            ['q', -0.094, -0.07, -0.082, -0.03], ['q', -0.08, -0.016, -0.094, -0.01], ['q', -0.106, -0.006, -0.104, 0.0], [-0.094, 0.005]], 0.024, FRC, 'a', { bevel: 0.0035, bseg: 2, cs: 5 }),
          // скоба со скруглённым передком
          Object.assign(loop([[-0.016, -0.012], [0.05, -0.012], ['q', 0.06, -0.014, 0.059, -0.028], [0.056, -0.046], ['q', 0.053, -0.056, 0.04, -0.056], [0.0, -0.056], ['q', -0.014, -0.054, -0.018, -0.04]],
            [[-0.006, -0.018], [0.045, -0.018], ['q', 0.052, -0.02, 0.051, -0.03], [0.049, -0.044], ['q', 0.047, -0.049, 0.038, -0.049], [0.003, -0.049], ['q', -0.006, -0.047, -0.007, -0.038]], 0.0105, FRC, 'a'), { bseg: 1, cs: 4 }),
          trig(0.011, -0.014, ST),
          // щёчки рукояти с насечкой, винты, медальон
          ...[1, -1].map(s => prof(grip, 0.0046, DK, 'b', { x: s * 0.0137, bevel: 0.0016, bseg: 2, cs: 4 })),
          ...[[-0.035, -0.03], [-0.084, -0.1]].flatMap(([f, y]) => [1, -1].map(s => ({ cyl: true, r: 0.0026, h: 0.0012, x: s * 0.0163, y, z: -f, rz: HP, color: ST, m: true, seg: 8 }))),
          ...[1, -1].map(s => ({ cyl: true, r: 0.0058, h: 0.0012, x: s * 0.0163, y: -0.064, z: 0.059, rz: HP, color: '#b9952f', m: true, seg: 14 })),
          // рычаг разборки и кнопка, задержка затвора, защёлка магазина (слева)
          { cyl: true, r: 0.0042, h: 0.0028, x: -0.0132, y: -0.004, z: -0.02, rz: HP, color: DK, m: true, seg: 10 },
          mprof([[0.02, -0.0065], [0.037, -0.005], [0.037, -0.0015], [0.02, -0.0015]], 0.0022, DK, { x: -0.0138, bevel: 0.0006, bseg: 1 }),
          { cyl: true, r: 0.0034, h: 0.0024, x: 0.0128, y: -0.004, z: -0.02, rz: HP, color: DK, m: true, seg: 8 },
          mprof([[-0.034, -0.001], [-0.002, -0.001], [0.001, 0.0035], [-0.034, 0.003]], 0.0022, DK, { x: -0.0131, bevel: 0.0006, bseg: 1 }),
          { cyl: true, r: 0.0042, h: 0.004, x: -0.0125, y: -0.027, z: 0.021, rz: HP, color: DK, m: true, seg: 10 },
          // ствол в открытом верху затвора: казённик с площадкой, ствол, дульный срез
          mbox(0.0142, 0.007, 0.034, 0, BY + 0.004, -0.011, '#565c64'),
          cz(0.0073, 0.006, 0.1135, BY, '#4d535b', { seg: 16 }), ringZ(0.0074, 0.0009, 0.112, BY, '#3a3f45', 16),
          { cyl: true, r: 0.0044, h: 0.0014, x: 0, y: BY, z: -0.1139, rx: HP, color: '#030303', seg: 12 }
        ];
        // затвор: глухая задняя часть со скруглённым верхом и насечками, «щёки» открытого верха с выборкой, нос с мушкой,
        // флажки предохранителя, целик; курок — с затвором (взводится им)
        const slide = [
          xsec(rrect(-SW, 0.004, SW, 0.034, 0.0062), -0.094, 0.006, FRC, 'a', { bevel: 0.0014, bseg: 2, cs: 3 }),
          ...[1, -1].map(s => prof([[0.004, 0.004], [0.098, 0.004], [0.098, 0.027], [0.03, 0.027], ['q', 0.013, 0.0272, 0.004, 0.0335]], 0.0042, FRC, 'a', { x: s * (SW - 0.0021), bevel: 0.0011, bseg: 1, cs: 4 })),
          xsec(rrect(-SW, 0.004, SW, 0.031, 0.0058), 0.096, 0.1112, FRC, 'a', { bevel: 0.0014, bseg: 2, cs: 3 }),
          { cyl: true, r: 0.0081, h: 0.0016, x: 0, y: BY, z: -0.1115, rx: HP, color: '#24272b', seg: 14 },
          ...Array.from({ length: 16 }, (_, i) => box(0.0012, 0.02, 0.0018, (i % 2 ? 1 : -1) * (SW + 0.0001), 0.018, -(-0.09 + (i >> 1) * 0.0034), GRV)),
          // флажки предохранителя-декокера: ось и рычажок назад-вверх
          ...[1, -1].flatMap(s => [{ cyl: true, r: 0.0046, h: 0.0022, x: s * (SW + 0.0009), y: 0.0215, z: 0.081, rz: HP, color: DK, m: true, seg: 12 },
            mprof([[-0.083, 0.0185], [-0.099, 0.0215], ['q', -0.102, 0.025, -0.099, 0.028], [-0.083, 0.0255]], 0.0024, DK, { x: s * (SW + 0.0014), bevel: 0.0006, bseg: 1 })]),
          // целик: основание в «ласточкином хвосте», прорезь и две белые точки к стрелку
          mbox(0.0165, 0.0055, 0.0095, 0, 0.0362, 0.0845, DK), box(0.0034, 0.0042, 0.0098, 0, 0.0378, 0.0845, GRV),
          em(dot(0.0052, 0.0372, 0.0795, WH, 0.0011)), em(dot(-0.0052, 0.0372, 0.0795, WH, 0.0011)),
          // мушка с белой точкой
          mprof([[0.0998, 0.0305], [0.1085, 0.0305], [0.1075, 0.0372], [0.1008, 0.0372]], 0.0032, DK, { bevel: 0.0005, bseg: 1 }), em(dot(0, 0.0352, -0.0996, WH, 0.001)),
          // выбрасыватель справа, курок со спицей
          mbox(0.0012, 0.004, 0.018, SW + 0.0004, 0.025, 0.004, ST),
          mprof([[-0.094, 0.006], [-0.1, 0.008], ['q', -0.109, 0.016, -0.106, 0.025], [-0.1, 0.026], ['q', -0.098, 0.017, -0.094, 0.014]], 0.0066, DK, { bevel: 0.0008, bseg: 1 })
        ];
        // магазин на 15: корпус под наклоном рукояти, пятка, патрон сверху
        const mag = [box(0.0165, 0.108, 0.033, 0, -0.07, 0.066, '#1b1c1f', -0.3), mprof([[-0.048, -0.127], [-0.104, -0.123], [-0.106, -0.133], [-0.05, -0.137]], 0.0232, DK, { bevel: 0.0014, bseg: 1 }),
          { cyl: true, r: 0.0045, h: 0.02, x: 0, y: -0.017, z: 0.04, rx: HP, color: '#b08a3e', m: true, seg: 10 }];
        return { body, slide, mag, slideK: 0.022, muzzle: [0, BY, -0.115], rh: [0, -0.066, 0.068], lh: null, dual: { yaw: 0.07 } };
      }
      // ---------- ножи (12.0): клинки со спусками — тонкая подводка к кромке + толстая часть над линией спуска (дол — вырез в ней),
      // рукояти из накладок на хвостовике с винтами, гарды, навершия с темляковыми отверстиями ----------
      case 'knife': case 'm9': case 'butterfly': case 'karambit': case 'tanto': return knifeParts(id);
      // eslint-disable-next-line no-fallthrough
      function knifeParts(id) {
        const SCR = '#8d939a', DK = '#0d0e10', TANG = '#1c1e21', BRASS = '#c99a3a';
        // окружность из 8 квадратичных дуг (f, y — центр)
        const circ = (f, y, r) => { const o = [[f + r, y]], rc = r / Math.cos(Math.PI / 8); for (let i = 0; i < 8; i++) { const am = (i + 0.5) * Math.PI / 4, a1 = (i + 1) * Math.PI / 4; o.push(['q', f + Math.cos(am) * rc, y + Math.sin(am) * rc, f + Math.cos(a1) * r, y + Math.sin(a1) * r]); } return o; };
        // прорезь со скруглёнными концами вдоль клинка
        const slotH = (f0, f1, y0, y1) => { const m = (y0 + y1) / 2, e = (y1 - y0) * 0.75; return [[f0, y0], [f1, y0], ['q', f1 + e, m, f1, y1], [f0, y1], ['q', f0 - e, m, f0, y0]]; };
        // клинок: ядро (по всему контуру — подводка) + «полотно» над линией спуска с вырезом дола; холы — сквозные отверстия
        const blade = (outer, flat, o) => {
          o = o || {};
          const out = [prof(outer, o.dc || 0.0024, STEEL, 'a', { bevel: 0.0008, bseg: 1, cs: o.cs || 6, holes: o.holes })];
          if (flat) out.push(prof(flat, o.df || 0.0056, STEEL, 'a', { bevel: 0.0013, bseg: 2, cs: o.cs || 6, holes: (o.fuller ? [o.fuller] : []).concat(o.holes || []) }));
          return out;
        };
        // винт накладки: шляпка и шлиц-звёздочка, с обеих сторон
        const screws = (f, y, x, r) => [1, -1].flatMap(s => [{ cyl: true, r: r || 0.0026, h: 0.0014, x: s * x, y, z: -f, rz: HP, color: SCR, m: true, seg: 8 },
          { cyl: true, r: (r || 0.0026) * 0.45, h: 0.0016, x: s * (x + 0.0001), y, z: -f, rz: HP, color: DK, seg: 6 }]);
        // насечка-джимпинг на обухе
        const jimp = (f0, n, step, y, w) => Array.from({ length: n }, (_, i) => Object.assign(box(w || 0.0058, 0.0016, 0.0013, 0, y, -(f0 + i * step), STEEL), { skin: 'a' }));
        switch (id) {
          case 'knife': {
            // тактический нож: клинок drop-point со скосом обуха к острию, дол, джимпинг; двойная гарда; накладки G10 на хвостовике
            const outer = [[0, -0.011], [0.008, -0.011], ['q', 0.011, -0.016, 0.02, -0.016], [0.118, -0.016], ['q', 0.178, -0.015, 0.206, 0.003], [0.14, 0.016], [0.0, 0.016]];
            const flat = [[0.004, -0.0035], [0.112, -0.0035], ['q', 0.16, -0.003, 0.187, 0.0028], [0.137, 0.0118], [0.13, 0.0146], [0.004, 0.0146]];
            const H = [[0.0, 0.0125], ['q', -0.05, 0.0155, -0.1, 0.0128], ['q', -0.118, 0.0118, -0.126, 0.0135], [-0.134, 0.0128], ['q', -0.141, 0.0, -0.134, -0.0195],
              ['q', -0.122, -0.0225, -0.11, -0.021], ['q', -0.099, -0.0175, -0.088, -0.0215], ['q', -0.077, -0.0255, -0.068, -0.0205], ['q', -0.058, -0.0165, -0.048, -0.0215],
              ['q', -0.036, -0.026, -0.02, -0.0205], [0.0, -0.0185]];
            const S = [[-0.006, 0.0118], ['q', -0.05, 0.0148, -0.1, 0.0121], [-0.118, 0.0114], ['q', -0.123, 0.0, -0.118, -0.0185], ['q', -0.11, -0.0198, -0.1, -0.0175],
              ['q', -0.088, -0.0205, -0.078, -0.0225], ['q', -0.068, -0.0198, -0.058, -0.0168], ['q', -0.048, -0.0205, -0.036, -0.0225], ['q', -0.022, -0.0205, -0.006, -0.0178]];
            return {
              body: [
                ...blade(outer, flat, { fuller: slotH(0.03, 0.098, 0.0036, 0.0092) }), ...jimp(0.006, 6, 0.0042, 0.0166),
                // гарда: верхний и нижний усы, торцы скруглены
                mprof([[-0.007, -0.027], ['q', -0.002, -0.031, 0.0035, -0.027], [0.004, -0.017], [0.004, 0.019], ['q', 0.0035, 0.025, -0.002, 0.0245], [-0.007, 0.02]], 0.0125, '#2b2e33', { bevel: 0.0022, bseg: 2, cs: 4 }),
                // хвостовик (виден между накладками) с темляковым отверстием в навершии
                prof(H, 0.0062, TANG, null, { m: true, bevel: 0.0012, bseg: 1, cs: 4, holes: [circ(-0.1295, -0.003, 0.0038)] }),
                // накладки с продольными канавками и винтами
                ...[1, -1].map(s => prof(S, 0.0088, '#24262a', 'b', { x: s * 0.0074, bevel: 0.0032, bseg: 2, cs: 4 })),
                ...[-0.045, -0.06, -0.075].flatMap(f => [1, -1].map(s => box(0.0014, 0.02, 0.0024, s * 0.0118, -0.004, -f, DK, 0.35))),
                ...screws(-0.022, -0.003, 0.0118), ...screws(-0.101, -0.002, 0.0118)
              ],
              mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.004, 0.07], lh: null
            };
          }
          case 'm9': {
            // штык-нож М9: широкий клинок, пила на обухе, скос к острию, отверстие под кусачки, широкий дол;
            // крестовина с дульным кольцом, резиновая рукоять с рёбрами, стальное навершие с пазом и кнопкой
            const outer = [[0, -0.017], [0.012, -0.017], [0.118, -0.017], ['q', 0.172, -0.0155, 0.203, 0.004], [0.17, 0.0175], [0.145, 0.0222]];
            for (let f = 0.1395; f > 0.05; f -= 0.0095) outer.push([f, 0.0278], [f - 0.0048, 0.0218]);
            outer.push([0.04, 0.0218], [0.03, 0.0222], [0, 0.0222]);
            const hole = slotH(0.151, 0.162, 0.0032, 0.0094);
            const flat = [[0.004, -0.0058], [0.114, -0.0058], ['q', 0.158, -0.0055, 0.186, 0.0032], [0.169, 0.0128], [0.142, 0.0192], [0.004, 0.0192]];
            const ribs = [];
            for (let i = 0; i < 6; i++) ribs.push({ cyl: true, r: 0.0174, h: 0.0042, x: 0, y: -0.002, z: 0.022 + i * 0.0165, rx: HP, sx: 0.84, color: '#1c211c', seg: 12, skin: 'b' });
            return {
              body: [
                ...blade(outer, flat, { fuller: slotH(0.022, 0.108, 0.0035, 0.0112), holes: [hole], cs: 5 }),
                // рикассо: клеймо-полоска
                box(0.0058, 0.0035, 0.0012, 0, -0.008, -0.009, '#1d2024'),
                // крестовина и дульное кольцо, заклёпки
                mprof([[-0.008, -0.027], ['q', -0.008, -0.031, -0.002, -0.031], ['q', 0.004, -0.031, 0.004, -0.026], [0.004, 0.03], [-0.008, 0.03]], 0.0125, '#2c2f33', { bevel: 0.002, bseg: 2, cs: 4 }),
                prof([[-0.008, 0.028], [0.004, 0.028], [0.004, 0.042], [-0.008, 0.042]], 0.0105, '#2c2f33', null, { m: true, bevel: 0.0018 }),
                { torus: true, r: 0.0118, tube: 0.0034, x: 0, y: 0.0535, z: 0.002, color: '#34383d', seg: 16, m: true },
                ...screws(0.0, -0.016, 0.0064, 0.0018), ...screws(0.0, 0.022, 0.0064, 0.0018),
                // рукоять: резиновый овальный корпус, рёбра, ромбовидная накатка между ними
                { cyl: true, r: 0.0162, r2: 0.0156, h: 0.112, x: 0, y: -0.002, z: 0.064, rx: HP, sx: 0.82, color: '#1f241f', seg: 14, skin: 'b' },
                ...ribs,
                // навершие: стальной колпак с пазом под защёлку и кнопкой
                loop([[-0.118, -0.0225], [-0.143, -0.0215], ['q', -0.147, 0.002, -0.143, 0.0255], [-0.118, 0.0255]], slotH(-0.14, -0.126, 0.011, 0.019), 0.023, '#2c2f33', null, true),
                { cyl: true, r: 0.0042, h: 0.004, x: 0, y: -0.0225, z: 0.13, color: '#5d636a', m: true, seg: 10 },
                ...screws(-0.128, -0.006, 0.0115, 0.0024)
              ],
              mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.002, 0.07], lh: null
            };
          }
          case 'butterfly': {
            // 2.4: балисонг как в CS. Клинок и две рукояти-«швеллера» вращаются на своих осях шарнира (y = PY, z = PZ).
            // Клинок: хвостовик-«таблетка» вокруг оси, кикер, полукруглый чойл, прямой обух → скос (clip) со сведжем к острию,
            // три слоя (кромка → подводка → полотно). Рукоять: стенка со скелетными окнами, полки-«швеллер» сверху и снизу внутрь,
            // тёмный вкладыш, винт шарнира с «торксом», дзен-штифты, винт у торца; на «кусачей» рукояти — защёлка на оси
            const PY = 0.003, PZ = 0.004, PF = -PZ, HL = 0.152;
            const core = [[PF, -0.0098], ['q', -0.0172, -0.0098, -0.0172, PY], ['q', -0.0172, 0.0158, PF, 0.0158], [0.084, 0.0158],
              ['q', 0.116, 0.0148, 0.1435, 0.0028], ['q', 0.124, -0.0108, 0.094, -0.0108], [0.032, -0.0108], ['q', 0.0265, -0.0038, 0.0205, -0.0108], [0.015, -0.0128], [0.004, -0.0128]];
            const mid = [[PF, -0.009], ['q', -0.0162, -0.009, -0.0162, PY], ['q', -0.0162, 0.0151, PF, 0.0151], [0.083, 0.0151],
              ['q', 0.112, 0.0141, 0.1335, 0.0042], ['q', 0.118, -0.0066, 0.093, -0.0066], [0.033, -0.0066], ['q', 0.0272, -0.0026, 0.0222, -0.0086], [0.0155, -0.0114], [0.004, -0.0114]];
            const flat = [[PF, -0.0082], ['q', -0.0152, -0.0082, -0.0152, PY], ['q', -0.0152, 0.0144, PF, 0.0144], [0.081, 0.0144], [0.1165, 0.0082],
              ['q', 0.1, 0.0016, 0.074, 0.0012], [0.034, 0.0012], ['q', 0.029, 0.0005, 0.0262, -0.0062], [0.0155, -0.0098], [0.004, -0.0098]];
            const HO = [[0.0118, PY], ['q', 0.0118, 0.0178, PF, 0.0178], ['q', -0.08, 0.0166, -HL + 0.008, 0.0174], ['q', -HL, 0.0174, -HL, 0.0095], [-HL, -0.0035],
              ['q', -HL, -0.0116, -HL + 0.008, -0.0116], ['q', -0.08, -0.0104, PF, -0.0118], ['q', 0.0118, -0.0118, 0.0118, PY]];
            const win = (f0, f1) => rrect(f1, -0.0042, f0, 0.0102, 0.0034);
            return {
              body: [
                prof(core, 0.0018, STEEL, 'a', { bevel: 0.0005, bseg: 1, cs: 6 }),
                prof(mid, 0.0032, STEEL, 'a', { bevel: 0.0008, bseg: 1, cs: 6 }),
                prof(flat, 0.0056, STEEL, 'a', { bevel: 0.0013, bseg: 2, cs: 6, holes: [rrect(0.006, -0.0038, 0.0135, 0.0002, 0.0018)] }),
                // упорный штифт хвостовика и насечка на обухе у шарнира
                { cyl: true, r: 0.0017, h: 0.0062, x: 0, y: 0.0118, z: -0.006, rz: HP, color: SCR, m: true, seg: 8 },
                ...[0, 1, 2, 3].map(i => Object.assign(box(0.0044, 0.0012, 0.0014, 0, 0.0161, -(0.02 + i * 0.0036), STEEL), { skin: 'a' }))
              ],
              pivot: [0, PY, PZ],
              handle: (side) => {
                const X = (v) => side * v;
                const out = [
                  // стенка со скелетными окнами
                  prof(HO, 0.0028, '#3a3e44', 'b', { bevel: 0.0009, bseg: 2, holes: [win(-0.024, -0.05), win(-0.056, -0.082), win(-0.088, -0.114), win(-0.12, -0.141)], x: X(0.0082), cs: 5 }),
                  // полки «швеллера» внутрь — закрытые рукояти обнимают клинок
                  box(0.0036, 0.0024, HL - 0.012, X(0.0052), 0.0163, (HL - 0.012) / 2 + 0.001, '#3a3e44'), box(0.0036, 0.0024, HL - 0.012, X(0.0052), -0.0103, (HL - 0.012) / 2 + 0.001, '#3a3e44'),
                  // тёмный вкладыш — окна читаются глубокими
                  prof(HO, 0.0008, '#121417', null, { m: true, bevel: 0, x: X(0.0064), cs: 4 }),
                  // винт шарнира (шляпка, «торкс»), дзен-штифты, винты у торца
                  { cyl: true, r: 0.0052, h: 0.0016, x: X(0.0102), y: PY, z: PZ, rz: HP, color: SCR, m: true, seg: 14 },
                  ...[0, 1, 2].map(i => box(0.0008, 0.0046, 0.0012, X(0.0111), PY, PZ, DK, i * 1.047)),
                  { cyl: true, r: 0.0014, h: 0.0012, x: X(0.0098), y: 0.0136, z: 0.017, rz: HP, color: SCR, m: true, seg: 6 },
                  { cyl: true, r: 0.0014, h: 0.0012, x: X(0.0098), y: -0.0076, z: 0.017, rz: HP, color: SCR, m: true, seg: 6 },
                  { cyl: true, r: 0.0026, h: 0.0012, x: X(0.0099), y: PY, z: HL - 0.008, rz: HP, color: SCR, m: true, seg: 8 },
                  { cyl: true, r: 0.0012, h: 0.0014, x: X(0.0101), y: PY, z: HL - 0.008, rz: HP, color: DK, seg: 6 },
                  { cyl: true, r: 0.002, h: 0.0012, x: X(0.0099), y: PY, z: 0.084, rz: HP, color: SCR, m: true, seg: 8 }];
                // защёлка на торце «кусачей» рукояти: ось и язычок
                if (side < 0) out.push(mprof([[-HL + 0.026, -0.0118], [-HL + 0.002, -0.0118], ['q', -HL - 0.002, -0.0148, -HL + 0.004, -0.0158], [-HL + 0.024, -0.0152]], 0.0046, '#5b6168', { x: X(0.0062), bevel: 0.0008, bseg: 1 }),
                  { cyl: true, r: 0.0017, h: 0.0186, x: 0, y: -0.0134, z: HL - 0.004, rz: HP, color: SCR, m: true, seg: 8 });
                return out;
              },
              mag: [], muzzle: [0, 0, -0.22], rh: [0, PY, 0.07], lh: null
            };
          }
          case 'karambit': {
            // 2.4: керамбит как в CS — обратный хват. Плоскость ножа (вперёд f, вверх y): кольцо в начале координат (ось кольца — X,
            // вокруг неё крутится нож на пальце), рукоять уходит вниз (по −y) с выемками под пальцы на «брюшке» (+f), из-под мизинца —
            // коготь: обух — внешняя выпуклая дуга, кромка — внутренняя вогнутая, остриё смотрит вперёд-вверх.
            // Клинок в три слоя (кромка → подводка → полотно у обуха) даёт видимые спуски; хвостовик с кольцом — под скин клинка,
            // накладки G10 с насечкой и винтами — под скин рукояти
            const sm = (pts) => { const o = [pts[0]]; for (let i = 1; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1], last = i === pts.length - 2; o.push(['q', a[0], a[1], last ? b[0] : (a[0] + b[0]) / 2, last ? b[1] : (a[1] + b[1]) / 2]); } return o; };
            const lerp2 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
            const arc = (cf, cy, r, a0, a1, n) => { const o = [], da = (a1 - a0) / n, rc = r / Math.cos(da / 2); for (let i = 0; i < n; i++) { const am = a0 + (i + 0.5) * da, ae = a0 + (i + 1) * da; o.push(['q', cf + Math.cos(am) * rc, cy + Math.sin(am) * rc, cf + Math.cos(ae) * r, cy + Math.sin(ae) * r]); } return o; };
            const RO = 0.0168, RI = 0.0118, D = Math.PI / 180;
            // клинок: обух и кромка — парные точки от пяты к острию
            const SP = [[-0.0335, -0.071], [-0.0345, -0.101], [-0.0292, -0.1285], [-0.012, -0.1475], [0.016, -0.1545], [0.047, -0.1465], [0.0715, -0.1265]], TIP = [0.0865, -0.1065];
            const ED = [[-0.0078, -0.071], [-0.0072, -0.088], [-0.0012, -0.1055], [0.0145, -0.1195], [0.0365, -0.1255], [0.0585, -0.1205], [0.0755, -0.1105]];
            const layer = (t, n) => SP.slice(0, n).concat(SP.slice(0, n).map((p, i) => lerp2(p, ED[i], t)).reverse());
            const core = sm(SP.concat([TIP])).concat(sm([TIP].concat(ED.slice().reverse())).slice(1));
            const mid = sm(layer(0.7, 7).slice(0, 7)).concat(sm(layer(0.7, 7).slice(7))); // полоса подводки
            const flat = sm(layer(0.42, 6).slice(0, 6)).concat(sm(layer(0.42, 6).slice(6)));
            // хвостовик: брюшко с тремя выемками под пальцы, спинка, кольцо
            const FR = [[-0.0068, -0.0215], [-0.0091, -0.0255], [-0.0052, -0.0345], [-0.0092, -0.0445], [-0.0052, -0.0535], [-0.0094, -0.0625], [-0.0062, -0.0705], [-0.0072, -0.075]];
            const BK = [[-0.0338, -0.075], [-0.0342, -0.052], [-0.0326, -0.032], [-0.0262, -0.0205], [RO * Math.cos(-138 * D), RO * Math.sin(-138 * D)]];
            const T = [[RO * Math.cos(-42 * D), RO * Math.sin(-42 * D)], ...sm([[RO * Math.cos(-42 * D), RO * Math.sin(-42 * D)], ...FR]).slice(1),
              ...sm(BK), ...arc(0, 0, RO, -138 * D, -402 * D, 9)];
            // накладки: тот же контур с отступом 1.2 мм, сверху — дуга под кольцом
            const SF = FR.slice(0, 7).map(p => [p[0] - 0.0013, p[1]]), SB = [[-0.0326, -0.0705], [-0.033, -0.052], [-0.0314, -0.032], [-0.0256, -0.0228]];
            const S = sm([[-0.0074, -0.0222], ...SF.slice(1)]).concat(sm(SB), [['q', -0.016, -0.0162, -0.0074, -0.0222]]);
            const sc = (y, r) => [{ cyl: true, r: r || 0.0024, h: 0.0012, x: 0.0068, y, z: 0.0205, rz: HP, color: SCR, m: true, seg: 8 }, { cyl: true, r: (r || 0.0024) * 0.45, h: 0.0014, x: 0.0069, y, z: 0.0205, rz: HP, color: DK, seg: 6 },
              { cyl: true, r: r || 0.0024, h: 0.0012, x: -0.0068, y, z: 0.0205, rz: HP, color: SCR, m: true, seg: 8 }, { cyl: true, r: (r || 0.0024) * 0.45, h: 0.0014, x: -0.0069, y, z: 0.0205, rz: HP, color: DK, seg: 6 }];
            const body = [
              prof(core, 0.0016, STEEL, 'a', { bevel: 0.0005, bseg: 1, cs: 6 }),
              prof(mid, 0.003, STEEL, 'a', { bevel: 0.0008, bseg: 1, cs: 6 }),
              prof(flat, 0.0052, STEEL, 'a', { bevel: 0.0013, bseg: 2, cs: 6 }),
              // хвостовик с кольцом (скин клинка, как в CS) и скруглённый обод кольца
              prof(T, 0.0056, STEEL, 'a', { bevel: 0.0012, bseg: 2, cs: 5, holes: [circ(0, 0, RI)] }),
              { torus: true, r: (RO + RI) / 2, tube: 0.0031, x: 0, y: 0, z: 0, ry: HP, color: STEEL, seg: 20, skin: 'a' },
              // накладки G10 с поперечной насечкой и винтами
              ...[1, -1].map(s => prof(S, 0.0042, '#25272b', 'b', { x: s * 0.0049, bevel: 0.0015, bseg: 2, cs: 4 })),
              ...[-0.029, -0.035, -0.041, -0.047, -0.053].flatMap(y => [1, -1].map(s => box(0.0008, 0.0014, 0.017, s * 0.007, y, 0.0205, DK, 0.18))),
              ...sc(-0.0255), ...sc(-0.0615),
              // гарда между рукоятью и когтем, насечка на обухе у пяты
              mprof([[-0.0352, -0.0688], [-0.0058, -0.0688], [-0.0058, -0.0768], [-0.0352, -0.0768]], 0.0112, '#2c3035', { bevel: 0.0018, bseg: 2 }),
              ...[0, 1, 2, 3, 4].map(i => Object.assign(box(0.0046, 0.0013, 0.0016, 0, -0.082 - i * 0.0042, 0.0342 + i * 0.0002, STEEL), { skin: 'a' }))
            ];
            return {
              body, mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.03, 0.0205], lh: null, ring: [0, 0, 0],
              // обратный хват: A — вниз вдоль рукояти (от указательного к мизинцу), B — к «брюшку» (костяшки), пальцы загибаются к −X;
              // указательный при θ = 0 проходит ровно через центр кольца (C + B·(rb + fr) = кольцо), обнимая обод кольца
              hold: KHOLD.karambit, wrist: holdWrist([0, -0.03, 0.0205], KHOLD.karambit),
              vmRot: KHOLD.karambit.vmRot
            };
          }
          case 'tanto': {
            // японский танто: клинок с изломом у острия (ёкотэ), ребро синоги, хабаки, цуба с сэппа, рукоять с оплёткой ито «ромбами» по скату самэ,
            // мэнуки, фути и кашира
            const outer = [[0, -0.0155], [0.168, -0.0155], [0.211, 0.0165], ['q', 0.2135, 0.0205, 0.209, 0.0212], ['q', 0.1, 0.0222, 0, 0.0212]];
            const flat = [[0.004, 0.0035], [0.164, 0.0035], [0.198, 0.0178], ['q', 0.1, 0.0196, 0.004, 0.0192]];
            const ito = [];
            for (let i = 0; i < 6; i++) {
              const z = 0.026 + i * 0.0178;
              for (const s of [1, -1]) ito.push(box(0.0026, 0.036, 0.0072, s * 0.0148, 0.002, z, '#211518', 0.62), box(0.0026, 0.036, 0.0072, s * 0.0148, 0.002, z, '#211518', -0.62));
              for (const s of [1, -1]) ito.push(box(0.03, 0.0026, 0.0072, 0, 0.002 + s * 0.0158, z, '#211518', 0, 0.62), box(0.03, 0.0026, 0.0072, 0, 0.002 + s * 0.0158, z, '#211518', 0, -0.62));
            }
            for (const p of ito) p.skin = 'b';
            return {
              body: [
                ...blade(outer, flat, { df: 0.006 }),
                // ёкотэ — поперечная грань у острия
                Object.assign(box(0.0062, 0.019, 0.0011, 0, -0.006, -0.1665, STEEL), { skin: 'a' }),
                // хабаки и цуба с сэппа
                mprof([[-0.002, -0.0185], [0.013, -0.017], [0.013, 0.0232], [-0.002, 0.0245]], 0.0082, BRASS, { bevel: 0.0012, bseg: 1 }),
                { cyl: true, r: 0.0225, h: 0.0014, x: 0, y: 0.003, z: 0.0028, rx: HP, sz: 0.8, color: BRASS, seg: 16, m: true },
                { cyl: true, r: 0.03, h: 0.0062, x: 0, y: 0.003, z: 0.0072, rx: HP, color: '#2a2420', seg: 18, m: true, sz: 0.78, skin: 'b' },
                { torus: true, r: 0.0285, tube: 0.0018, x: 0, y: 0.003, z: 0.0072, color: BRASS, seg: 20, m: true, sy: 0.78 },
                { cyl: true, r: 0.0225, h: 0.0014, x: 0, y: 0.003, z: 0.0112, rx: HP, sz: 0.8, color: BRASS, seg: 16, m: true },
                // фути, самэ (светлая кожа ската) под оплёткой, оплётка
                { cyl: true, r: 0.0178, r2: 0.0172, h: 0.01, x: 0, y: 0.003, z: 0.0165, rx: HP, sx: 0.84, color: BRASS, seg: 14, m: true },
                { cyl: true, r: 0.0152, r2: 0.0146, h: 0.112, x: 0, y: 0.002, z: 0.077, rx: HP, sx: 0.86, color: '#e6dcc4', seg: 12 },
                ...ito,
                // мэнуки (накладной орнамент) с обеих сторон
                ...[1, -1].map(s => ({ sph: true, r: 0.0065, x: s * 0.0152, y: 0.002, z: 0.068, sx: 0.35, sz: 1.6, color: BRASS, seg: 8, m: true })),
                // кашира
                { cyl: true, r: 0.0172, r2: 0.0166, h: 0.012, x: 0, y: 0.002, z: 0.138, rx: HP, sx: 0.86, color: BRASS, seg: 14, m: true },
                { sph: true, r: 0.0146, x: 0, y: 0.002, z: 0.144, sx: 0.86, sz: 0.45, color: '#b8862e', seg: 12, m: true }
              ],
              mag: [], muzzle: [0, 0, -0.3], rh: [0, -0.002, 0.075], lh: null
            };
          }
        }
      }
      case 'he': case 'flash': case 'smoke': return nadeParts(id);
    }
  }
  // ---------- 2.4: позы кисти ножей (керамбит) — в таблице G.HOLD, формат как в ветке hands-240 (G.holdPose) ----------
  // pose: { C, A (рукоять, от указательного к мизинцу), B (костяшки), wrap, rb, rn, fingers, thumb [a, b, n], Wl [a, b, n], elbow, shoulder };
  // vmRot — поворот ножа в ладони (gun.rotation), локоть/плечо пересчитаны под него (L(p) = p − VM_POS в системе ножа)
  const KHOLD = {
    karambit: {
      // обратный хват (2.4, под анатомическую кисть hands-240): A — вниз вдоль рукояти (от указательного к мизинцу), B — костяшки
      // (+X, от камеры), пальцы обходят рукоять со стороны «брюшка» (wrap = вперёд f, к центру экрана) и возвращаются к ладони
      // перед камерой. Указательный при θ = π/2 (идёт к камере) проходит ровно через центр кольца: C + N·(rn + fr) = кольцо;
      // ладонь смотрит к камере, большой палец — вверх вдоль ближней правой грани, запястье справа, предплечье — вниз-вправо
      A: [0, -1, 0], B: [1, 0, 0], wrap: [0, 0, -1], rb: 0.0068, rn: 0.0115,
      fingers: [{ s: -0.03, t: [-0.3, 0.75, 1.75, 2.6] }, { s: -0.0075, t: [-0.3, 0.75, 1.75, 2.65] }, { s: 0.0135, t: [-0.3, 0.75, 1.75, 2.6] }, { s: 0.0335, sc: 0.86, t: [-0.25, 0.8, 1.75, 2.45] }],
      thumb: [[0.018, -0.014, -0.038], [0.0, -0.022, -0.024], [-0.018, -0.022, -0.016], [-0.034, -0.018, -0.012]],
      Wl: [0.034, 0.0, -0.068], fore: [0.36, -0.88, 0.3], vmRot: [-0.2, 1.3, -0.08]
    }
  };
  // запястье позы (для оси поворота кисти в анимациях)
  function holdWrist(C, h) {
    const A = VA.norm(h.A), B = VA.norm(h.B); let N = VA.norm(VA.cross(B, A)); if (VA.dot(N, h.wrap) < 0) N = VA.mul(N, -1);
    return comb(C, A, h.Wl[0], B, h.Wl[1], N, h.Wl[2]);
  }
  G.HOLD = G.HOLD || {};
  G.HOLD.karambit = { r: (gp) => Object.assign({ C: gp.rh }, KHOLD.karambit) };

  // ---------- 2.3: гранаты ----------
  // ось корпуса — Z, запал впереди (−Z). Детали: body — корпус с запалом и рычагом (в руке), pin — кольцо с чекой
  // (выдёргивается), lever — рычаг-«ложка» (отлетает при броске), fly — корпус в полёте (без чеки и рычага)
  // деталь, повёрнутая так, что её Y смотрит по нормали n, а X — по касательной t
  const _ob = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()], _om = new THREE.Matrix4(), _oe = new THREE.Euler();
  function obox(w, h, d, c, n, t, color, extra) {
    const N = VA.norm(n), T = VA.norm(VA.sub(t, VA.mul(N, VA.dot(t, N)))), Z = VA.cross(T, N);
    _ob[0].set(T[0], T[1], T[2]); _ob[1].set(N[0], N[1], N[2]); _ob[2].set(Z[0], Z[1], Z[2]);
    _om.makeBasis(_ob[0], _ob[1], _ob[2]); _oe.setFromRotationMatrix(_om);
    return Object.assign({ w, h, d, x: c[0], y: c[1], z: c[2], rx: _oe.x, ry: _oe.y, rz: _oe.z, color }, extra || {});
  }
  function nadeParts(id) {
    const LEV = '#8f948b', FZ = '#6f746c', DKF = '#3b3f3a', RING = '#c9ccce';
    // запал общий: горловина, корпус запала с ударником, рычаг вдоль корпуса от запала (по +Y), чека с кольцом сбоку (+X)
    const fuse = (zTop, rNeck, prof) => {
      const z0 = zTop;
      const body = [
        { cyl: true, r: rNeck, r2: rNeck * 1.05, h: 0.008, x: 0, y: 0, z: z0 - 0.004, rx: HP, color: FZ, m: true, seg: 12 },
        { cyl: true, r: 0.0098, h: 0.012, x: 0, y: 0, z: z0 - 0.014, rx: HP, color: FZ, m: true, seg: 12 },
        { cyl: true, r: 0.0104, h: 0.0024, x: 0, y: 0, z: z0 - 0.0205, rx: HP, color: DKF, m: true, seg: 12 },
        mbox(0.017, 0.012, 0.013, 0, 0.007, z0 - 0.014, '#7b8078'),
        // ушки для оси рычага и сама ось
        mbox(0.0026, 0.008, 0.008, 0.0072, 0.0125, z0 - 0.019, '#6a6f68'), mbox(0.0026, 0.008, 0.008, -0.0072, 0.0125, z0 - 0.019, '#6a6f68'),
        { cyl: true, r: 0.0016, h: 0.0178, x: 0, y: 0.0145, z: z0 - 0.0195, rz: HP, color: '#555a55', m: true, seg: 6 }
      ];
      // рычаг: верхняя полка над запалом и «ложка» вниз по корпусу (точки профиля корпуса prof: [z, y])
      const lever = [mbox(0.0118, 0.0022, 0.02, 0, 0.0145, z0 - 0.0115, LEV)];
      for (let i = 0; i < prof.length - 1; i++) {
        const a = prof[i], b = prof[i + 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]) + 0.0016;
        lever.push(obox(0.0112 - i * 0.0006, 0.0022, len, [0, (a[1] + b[1]) / 2, (a[0] + b[0]) / 2], [0, b[0] - a[0], -(b[1] - a[1])].map((v, k) => k === 1 ? Math.abs(v) : v), [1, 0, 0], LEV, { m: true }));
      }
      // кольцо — слева (−X): его выдёргивает левая рука
      const pin = [{ torus: true, r: 0.0105, tube: 0.0017, x: -0.0235, y: 0.004, z: z0 - 0.015, ry: HP, color: RING, m: true, seg: 14 },
        { cyl: true, r: 0.0014, h: 0.022, x: -0.009, y: 0.004, z: z0 - 0.015, rz: HP, color: RING, m: true, seg: 6 },
        { cyl: true, r: 0.0021, h: 0.003, x: 0.0095, y: 0.004, z: z0 - 0.015, rz: HP, color: RING, m: true, seg: 6 }];
      return { body, lever, pin, pinC: [-0.0235, 0.004, z0 - 0.015] };
    };
    let body, f, nr, rh;
    if (id === 'he') {
      // осколочная: корпус-«ананас» — эллипсоид с рядами насечек-сегментов, жёлтая полоса у горловины, пробка снизу
      const R = 0.0305, SZ = 1.14, OL = '#56653a', OD = '#3f4c2a';
      body = [{ sph: true, r: R, sz: SZ, x: 0, y: 0, z: 0, color: OL, seg: 16, hs: 10 }];
      const lat = [-0.92, -0.5, -0.08, 0.34, 0.76];
      lat.forEach((ph, j) => {
        for (let i = 0; i < 8; i++) {
          const th = (i + (j & 1) * 0.5) * Math.PI / 4, c = Math.cos(ph), n = [c * Math.cos(th), c * Math.sin(th), Math.sin(ph) / SZ];
          const p = [R * c * Math.cos(th) * 1.0, R * c * Math.sin(th), R * SZ * Math.sin(ph)];
          body.push(obox(0.0105 * (0.6 + 0.4 * c), 0.0034, 0.0098, VA.add(p, VA.mul(VA.norm(n), 0.0008)), n, [-Math.sin(th), Math.cos(th), 0], j === 2 ? OL : '#5d6d40'));
        }
      });
      body.push({ torus: true, r: 0.0118, tube: 0.0015, x: 0, y: 0, z: -R * SZ + 0.002, color: '#d4b13a', seg: 14 },
        { cyl: true, r: 0.0078, h: 0.004, x: 0, y: 0, z: R * SZ - 0.0005, rx: HP, color: OD, m: true, seg: 10 });
      const z0 = -R * SZ - 0.002;
      f = fuse(z0, 0.0105, [[z0 - 0.003, 0.0155], [-0.024, 0.026], [-0.008, 0.0335], [0.012, 0.0335], [0.026, 0.028]]);
      nr = 0.031; rh = [0, 0, 0];
    } else if (id === 'flash') {
      // светошумовая: стальной цилиндр с рядами прорезей, тёмные торцы с ободом, синяя полоса
      const R = 0.0205, Z0 = -0.042, Z1 = 0.06, BD = '#7a8186', CAP = '#2e3337';
      body = [{ cyl: true, r: R, h: Z1 - Z0, x: 0, y: 0, z: (Z0 + Z1) / 2, rx: HP, color: BD, m: true, seg: 14 },
        { cyl: true, r: R + 0.0012, h: 0.008, x: 0, y: 0, z: Z0 + 0.004, rx: HP, color: CAP, m: true, seg: 14 },
        { cyl: true, r: R + 0.0012, h: 0.008, x: 0, y: 0, z: Z1 - 0.004, rx: HP, color: CAP, m: true, seg: 14 },
        { torus: true, r: R + 0.0008, tube: 0.0011, x: 0, y: 0, z: Z0 + 0.0085, color: '#4a5055', seg: 16 },
        { torus: true, r: R + 0.0008, tube: 0.0011, x: 0, y: 0, z: Z1 - 0.0085, color: '#4a5055', seg: 16 },
        { cyl: true, r: R + 0.0004, h: 0.006, x: 0, y: 0, z: Z0 + 0.016, rx: HP, color: '#3a7cc2', seg: 14 },
        { cyl: true, r: 0.012, h: 0.002, x: 0, y: 0, z: Z1 + 0.0005, rx: HP, color: '#1d2023', m: true, seg: 10 }];
      for (const zr of [0.006, 0.025, 0.044]) for (let i = 0; i < 6; i++) {
        const th = (i + 0.5) * Math.PI / 3 + (zr === 0.025 ? Math.PI / 6 : 0), n = [Math.cos(th), Math.sin(th), 0];
        if (Math.abs(th - HP) < 0.4) continue; // под рычагом прорезей нет
        body.push(obox(0.012, 0.0016, 0.0062, VA.mul(n, R + 0.0003).map((v, k) => k === 2 ? zr : v), n, [0, 0, 1], '#0d0f11'));
      }
      f = fuse(Z0, 0.0092, [[Z0 - 0.004, 0.0152], [Z0 + 0.004, 0.0232], [0.03, 0.0232]]);
      nr = 0.0215; rh = [0, 0, 0.008];
    } else {
      // дымовая: оливковая банка с белой маркировкой, обод крышки с отверстиями-выпусками сверху и снизу
      const R = 0.0255, Z0 = -0.046, Z1 = 0.07, OD = '#4b5643', DK = '#2b3128';
      body = [{ cyl: true, r: R, h: Z1 - Z0, x: 0, y: 0, z: (Z0 + Z1) / 2, rx: HP, color: OD, seg: 16 },
        { cyl: true, r: R + 0.0008, h: 0.006, x: 0, y: 0, z: Z0 + 0.003, rx: HP, color: DK, m: true, seg: 16 },
        { cyl: true, r: R + 0.0008, h: 0.006, x: 0, y: 0, z: Z1 - 0.003, rx: HP, color: DK, m: true, seg: 16 },
        { cyl: true, r: R + 0.0003, h: 0.026, x: 0, y: 0, z: 0.006, rx: HP, color: '#d9d6ca', seg: 16 },
        { cyl: true, r: R + 0.0005, h: 0.004, x: 0, y: 0, z: 0.024, rx: HP, color: '#8c8f88', seg: 16 },
        // надпись-полоса и номер партии — тёмные штрихи на белом поле
        ...[-0.012, -0.004, 0.004, 0.012].map((xx) => obox(0.0055, 0.0008, 0.012, [xx, -(R + 0.0006) * Math.cos(xx / R), 0.005], [Math.sin(xx / R), -Math.cos(xx / R), 0], [Math.cos(xx / R), Math.sin(xx / R), 0], '#2a2c28')),
        { torus: true, r: R - 0.002, tube: 0.0014, x: 0, y: 0, z: Z1 + 0.0005, color: DK, seg: 16 }];
      for (let i = 0; i < 4; i++) {
        const th = i * HP + 0.6;
        body.push({ cyl: true, r: 0.0042, h: 0.0018, x: Math.cos(th) * 0.0135, y: Math.sin(th) * 0.0135, z: Z0 - 0.0002, rx: HP, color: '#101210', seg: 8 },
          { cyl: true, r: 0.0036, h: 0.0018, x: Math.cos(th) * 0.0135, y: Math.sin(th) * 0.0135, z: Z1 + 0.0004, rx: HP, color: '#101210', seg: 8 });
      }
      f = fuse(Z0, 0.0105, [[Z0 - 0.004, 0.0172], [Z0 + 0.005, 0.0282], [0.024, 0.0282]]);
      nr = 0.0262; rh = [0, 0, 0.012];
    }
    const fly = body.concat(f.body);
    return { body: fly.concat(f.lever), fly, lever: f.lever, pin: f.pin, pinC: f.pinC, mag: [], muzzle: [0, 0, -0.1], rh, lh: null, nr };
  }
  // параметры хвата: наклон рукояти, размеры рукояти и цевья (для рук)
  const HOLD = {
    ar: { grip: { rake: 0.28, rb: 0.017, rn: 0.02 }, fg: { c: [0, -0.004, -0.29], rb: 0.036, rn: 0.03 } },
    ar2: { grip: { rake: 0.2, rb: 0.017, rn: 0.02 }, fg: { c: [0, 0.021, -0.29], rb: 0.034, rn: 0.032 } },
    m4s: { grip: { rake: 0.2, rb: 0.017, rn: 0.02 }, fg: { c: [0, 0.021, -0.3], rb: 0.03, rn: 0.029 } },
    smg: { grip: { rake: 0.22, rb: 0.017, rn: 0.024 }, fg: { c: [0, 0.012, -0.18], rb: 0.031, rn: 0.032 } },
    sniper: { grip: { rake: 0.3, rb: 0.02, rn: 0.022 }, fg: { c: [0, -0.007, -0.26], rb: 0.036, rn: 0.032 } },
    shotgun: { grip: { rake: 0.45, rb: 0.022, rn: 0.022 }, fg: { c: [0, -0.022, -0.33], rb: 0.033, rn: 0.034 } },
    pistol: { grip: { rake: 0.36, rb: 0.015, rn: 0.024 } }, usp: { grip: { rake: 0.25, rb: 0.0155, rn: 0.0235 } },
    magnum: { grip: { rake: 0.18, rb: 0.018, rn: 0.028 } },
    galil: { grip: { rake: 0.26, rb: 0.017, rn: 0.02 }, fg: { c: [0, -0.004, -0.31], rb: 0.037, rn: 0.031 } },
    famas: { grip: { rake: 0.24, rb: 0.017, rn: 0.021 }, fg: { c: [0, 0.0, -0.23], rb: 0.03, rn: 0.03 } },
    ssg: { grip: { rake: 0.3, rb: 0.017, rn: 0.022 }, fg: { c: [0, 0.03, -0.27], rb: 0.028, rn: 0.027 } },
    fiveseven: { grip: { rake: 0.28, rb: 0.015, rn: 0.025 } }, tec9: { grip: { rake: 0.2, rb: 0.016, rn: 0.025 } },
    duals: { grip: { rake: 0.3, rb: 0.0155, rn: 0.026 } }
  };
  const gunParts0 = gunParts;
  // 2.0.1: тонкие декоративные пластины (окна, выштамповки, флажки, «уши») помечены fine — облегчённая модель в руках бота их пропускает
  gunParts = (id) => {
    const gp = Object.assign(gunParts0(id), HOLD[id] || {}), d = W[id];
    if (d && !d.melee && !d.nade) for (const k of ['body', 'mag', 'slide', 'pump']) for (const p of gp[k] || []) if (p.shape && p.d < 0.0045) p.fine = true;
    return gp;
  };
  G.gunParts = gunParts;

  // «конечность» от точки a к точке b — коробка вдоль вектора
  const _q = new THREE.Quaternion(), _e = new THREE.Euler(), _up = new THREE.Vector3(0, 1, 0), _d = new THREE.Vector3();
  function limb(a, b, t, color) {
    _d.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const len = _d.length(); _d.normalize();
    _q.setFromUnitVectors(_up, _d); _e.setFromQuaternion(_q);
    return { w: t, h: len, d: t * 1.05, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, color, rx: _e.x, ry: _e.y, rz: _e.z };
  }
  G.limb = limb;

  // «Классика» (до 2.5): оружие ниже и дальше, кисти почти за краем экрана
  const VM_POS_CLASSIC = {
    ar: [0.15, -0.148, -0.42], ar2: [0.15, -0.15, -0.42], m4s: [0.15, -0.15, -0.42], smg: [0.14, -0.138, -0.38], sniper: [0.15, -0.15, -0.44],
    shotgun: [0.15, -0.152, -0.42], pistol: [0.096, -0.084, -0.36], usp: [0.096, -0.084, -0.36], magnum: [0.1, -0.086, -0.37],
    galil: [0.15, -0.15, -0.42], famas: [0.15, -0.165, -0.42], ssg: [0.15, -0.15, -0.44], fiveseven: [0.096, -0.084, -0.36], tec9: [0.1, -0.086, -0.38],
    duals: [0, -0.095, -0.36],
    knife: [0.17, -0.095, -0.27], m9: [0.17, -0.095, -0.27], butterfly: [0.17, -0.095, -0.27], karambit: [0.125, 0.03, -0.27], tanto: [0.17, -0.095, -0.27],
    he: [0.165, -0.12, -0.33], flash: [0.165, -0.12, -0.33], smoke: [0.165, -0.12, -0.33]
  };
  // 2.5 «Ближе» (по умолчанию): оружие выше и крупнее, ствол чуть к центру — левая кисть на цевье и обе кисти у пистолета видны
  // над нижней панелью интерфейса (телефон 19.5:9 и 16:9)
  const VM_POS = {
    ar: [0.14, -0.1, -0.35], ar2: [0.14, -0.108, -0.35], m4s: [0.14, -0.108, -0.35], galil: [0.14, -0.102, -0.35], famas: [0.145, -0.145, -0.38],
    smg: [0.13, -0.092, -0.32], shotgun: [0.14, -0.104, -0.35], sniper: [0.14, -0.108, -0.35], ssg: [0.14, -0.104, -0.35],
    pistol: [0.085, -0.066, -0.335], usp: [0.085, -0.066, -0.335], fiveseven: [0.085, -0.066, -0.335], magnum: [0.09, -0.068, -0.345], tec9: [0.09, -0.068, -0.35],
    duals: [0, -0.064, -0.335],
    knife: [0.145, -0.068, -0.26], m9: [0.145, -0.068, -0.26], butterfly: [0.145, -0.068, -0.26], karambit: [0.11, 0.04, -0.26], tanto: [0.145, -0.068, -0.26],
    he: [0.15, -0.1, -0.31], flash: [0.15, -0.1, -0.31], smoke: [0.15, -0.1, -0.31]
  };
  G.VM_POS = VM_POS; G.VM_POS_CLASSIC = VM_POS_CLASSIC;
  // 2.5: базовый поворот модели в кадре [rx, ry, rz] (вокруг начала модели) для «Ближе»; нет записи — прежний (0.02, 0.05 / 0.1 у пистолетов, 0)
  const RIF_R = [0.05, 0.15, -0.05], PIS_R = [0.03, 0.12, -0.02];
  const VM_ROT = G.VM_ROT = { ar: RIF_R, ar2: RIF_R, m4s: RIF_R, galil: RIF_R, famas: [0.04, 0.15, -0.05], smg: RIF_R, shotgun: RIF_R, sniper: RIF_R, ssg: RIF_R,
    pistol: PIS_R, usp: PIS_R, fiveseven: PIS_R, magnum: PIS_R, tec9: PIS_R, duals: [0.03, 0, 0] };
  G.vmClassic = () => !!(G.settings && G.settings.vmPos === 'classic');
  G.vmBasePos = (id) => (G.vmClassic() ? VM_POS_CLASSIC[id] : null) || VM_POS[id];
  const sub =(a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

  // ================= 2.4: позы кистей (хват) — одна таблица на всё оружие =================
  // G.HOLD[id] = { r: pose | (gp, id) => pose, l: pose | (gp, id) => pose | null }  — правая / левая кисть.
  // pose (в системе модели оружия, см. solveHand): { C, A, B, wrap, rb, rn, fingers: 4 × { s, t: [θ0..θ3], sc, ls, pts },
  //   thumb: 4 точки ([a, b, n] в системе (A, B, N) или [[x, y, z]]), W (запястье) или Wl ([a, b, n]),
  //   elbow, shoulder — локоть и плечо (камера, как VM_POS; без них — значения класса) }.
  // Нет записи для оружия — берётся поза класса HOLD_CLS (винтовка/пистолет/нож/граната); null — кисти нет.
  // Позы ножей (керамбит, бабочка) задаются здесь же, сетка кисти и перчатки строятся по ним одинаково.
  const XA = [1, 0, 0], YA = [0, 1, 0], ZA = [0, 0, 1], XN = [-1, 0, 0], YN = [0, -1, 0];
  const HOLD_CLS = {
    // кулак на рукояти ножа: клинок вперёд-вверх, большой палец сверху на рукояти
    knifeR: (gp) => {
      // 2.4: рукоять поперёк ладони (а не продолжением предплечья): тыл кисти к камере, пальцы обхватывают рукоять сверху,
      // большой палец ложится на указательный; предплечье уходит вниз-вправо к краю экрана
      const C = gp.rh, rb = 0.0165, rn = 0.0165;
      return { C, A: ZA, B: [-0.87, -0.48, 0], wrap: [-0.48, 0.87, 0], rb, rn,
        fingers: [{ s: -0.03, t: [-0.3, 0.75, 1.75, 2.6] }, { s: -0.0105, t: [-0.3, 0.75, 1.75, 2.65] }, { s: 0.009, t: [-0.3, 0.75, 1.75, 2.6] }, { s: 0.027, t: [-0.25, 0.8, 1.75, 2.45] }],
        thumb: [[-0.016, -0.004, -0.05], [-0.03, -(rb + 0.013), -0.02], [-0.029, -(rb + 0.017), 0.008], [-0.017, -(rb + 0.012), 0.026]],
        Wl: [0.014, 0.004, -0.077], fore: [0.36, -0.92, 0.14] };
    },
    // граната в кулаке: пальцы обхватывают корпус, большой палец прижимает рычаг
    nadeR: (gp) => {
      const C = gp.rh, R = gp.nr;
      return { C, A: ZA, B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: R, rn: R,
        fingers: [{ s: -0.028, t: [-0.2, 0.7, 1.6, 2.4] }, { s: -0.009, t: [-0.2, 0.7, 1.6, 2.45] }, { s: 0.01, t: [-0.2, 0.7, 1.6, 2.4] }, { s: 0.028, t: [-0.15, 0.75, 1.6, 2.3] }],
        thumb: [[comb(C, ZA, 0.05, XN, R + 0.004, YN, 0.004)], [comb(C, ZA, 0.026, XN, R + 0.006, YA, R * 0.45)], [comb(C, ZA, 0.004, XN, R * 0.55, YA, R + 0.008)], [comb(C, ZA, -0.014, XN, 0.004, YA, R + 0.012)]],
        W: comb(C, ZA, 0.07 + R, XA, 0.014, YN, 0.014), elbow: [0.3, -0.42, -0.04], shoulder: [0.44, -0.66, 0.12] };
    },
    // левая рука у гранаты: кулак вокруг кольца чеки (указательный и средний через кольцо)
    nadePin: (gp) => {
      const pc = gp.pinC, C = [pc[0] - 0.004, pc[1] - 0.0105, pc[2]];
      return { C, A: [0.25, 0, 1], B: [-0.75, -0.65, 0], wrap: [0.6, -0.6, 0], rb: 0.006, rn: 0.006,
        fingers: [{ s: -0.004, t: [-0.3, 0.7, 1.7, 2.6] }, { s: 0.015, t: [-0.3, 0.7, 1.7, 2.6] }, { s: 0.034, t: [-0.3, 0.7, 1.7, 2.6] }, { s: 0.051, t: [-0.25, 0.75, 1.7, 2.5] }],
        thumb: [[comb(C, ZA, 0.04, XA, 0.016, YN, 0.012)], [comb(C, ZA, 0.018, XA, 0.02, YN, 0.0)], [comb(C, ZA, -0.002, XA, 0.012, YA, 0.006)], [comb(C, ZA, -0.016, XA, 0.002, YA, 0.01)]],
        W: comb(C, ZA, 0.1, XN, 0.03, YN, 0.03), elbow: [-0.04, -0.46, -0.06], shoulder: [-0.22, -0.72, 0.1] };
    },
    // пистолетная рукоять (винтовки, ПП, пистолеты): указательный на спуске, большой палец по левому борту
    gripR: (gp) => {
      const g = gp.grip || {}, rb = g.rb || 0.016, rn = g.rn || 0.021;
      return { C: gp.rh, A: [0, -1, g.rake != null ? g.rake : 0.25], B: [1, 0, 0.25], wrap: [0, 0, -1], rb, rn,
        fingers: [
          { pts: [[-0.026, rb + 0.016, 0.002], [-0.036, rb + 0.013, rn + 0.018], [-0.04, rb + 0.004, rn + 0.04], [-0.036, 0.004, rn + 0.05]] },
          { s: -0.004, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.016, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.035, t: [-0.2, 0.8, 1.75, 2.4] }],
        thumb: [[0.028, -0.004, -(rn + 0.022)], [-0.004, -(rb + 0.012), -0.012], [-0.02, -(rb + 0.011), 0.012], [-0.028, -(rb + 0.008), 0.032]],
        Wl: [0.046, 0.014, -0.066], elbow: [0.33, -0.44, -0.07], shoulder: [0.44, -0.66, 0.12] };
    },
    // пистолет двумя руками: левая ладонь обнимает правую снизу-слева, большой палец вдоль рамы
    pistolL: (gp) => {
      const g = gp.grip || {};
      return { C: gp.rh, A: [0, -1, g.rake != null ? g.rake : 0.25], B: [-1, 0, 0.2], wrap: [0, 0, -1], rb: 0.03, rn: 0.034,
        fingers: [{ s: 0.006, t: [-0.25, 0.55, 1.3, 1.85] }, { s: 0.024, t: [-0.25, 0.55, 1.3, 1.85] }, { s: 0.041, t: [-0.25, 0.55, 1.3, 1.8] }, { s: 0.056, t: [-0.2, 0.6, 1.3, 1.75] }],
        thumb: [[0.03, 0.012, -0.034], [0.004, 0.031, -0.006], [-0.012, 0.028, 0.016], [-0.018, 0.023, 0.036]],
        Wl: [0.07, 0.036, -0.036], elbow: [0.02, -0.46, -0.16], shoulder: [-0.2, -0.72, -0.12] };
    },
    // вертикальная рукоятка под цевьём
    vgL: (gp) => {
      return { C: gp.vg, A: [0, -1, 0.08], B: [-1, 0, 0.2], wrap: [0, 0, -1], rb: 0.015, rn: 0.018,
        fingers: [{ s: -0.024, t: [-0.25, 0.75, 1.75, 2.5] }, { s: -0.005, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.014, t: [-0.25, 0.75, 1.75, 2.55] }, { s: 0.032, t: [-0.2, 0.8, 1.75, 2.4] }],
        thumb: [[0.024, 0.002, -0.04], [-0.006, -0.027, -0.01], [-0.022, -0.026, 0.012], [-0.03, -0.023, 0.03]],
        Wl: [0.046, 0.016, -0.064], elbow: [-0.05, -0.47, -0.3], shoulder: [-0.2, -0.72, -0.12] };
    },
    // цевьё снизу: ладонь под цевьём, пальцы обхватывают справа, большой палец — по левому борту
    foreL: (gp) => {
      const fg = gp.fg || {}, C = fg.c || add(gp.lh, [0, 0.03, 0]), rb = fg.rb || 0.034, rn = fg.rn || 0.034;
      return { C, A: ZA, B: [0.45, -0.9, 0], wrap: [1, 1, 0], rb, rn,
        fingers: [{ s: -0.034, t: [-0.15, 0.55, 1.3, 1.85] }, { s: -0.013, t: [-0.15, 0.58, 1.35, 1.95] }, { s: 0.008, t: [-0.15, 0.58, 1.35, 1.9] }, { s: 0.028, t: [-0.1, 0.6, 1.3, 1.8] }],
        thumb: [[comb(C, ZA, 0.03, XN, rb * 0.75, YN, rn * 0.85)], [comb(C, ZA, 0.004, XN, rb + 0.012, YN, rn * 0.3)], [comb(C, ZA, -0.022, XN, rb + 0.012, YA, 0.004)], [comb(C, ZA, -0.042, XN, rb + 0.008, YA, rn * 0.3)]],
        W: comb(C, ZA, 0.045, XN, 0.036, YN, rn + 0.05), elbow: [-0.05, -0.47, -0.3], shoulder: [-0.2, -0.72, -0.12] };
    },
    // витрина перчаток в меню: кулак
    showR: () => {
      const C = [0, 0, 0];
      return { C, A: ZA, B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: 0.02, rn: 0.019,
        fingers: [{ s: -0.031, t: [-0.25, 0.75, 1.75, 2.65] }, { s: -0.011, t: [-0.25, 0.75, 1.75, 2.7] }, { s: 0.009, t: [-0.25, 0.75, 1.75, 2.65] }, { s: 0.028, t: [-0.2, 0.8, 1.75, 2.5] }],
        thumb: [[comb(C, ZA, 0.036, XN, 0.022, YN, 0.002)], [comb(C, ZA, 0.012, XN, 0.025, YA, 0.012)], [comb(C, ZA, -0.012, XN, 0.014, YA, 0.026)], [comb(C, ZA, -0.026, XN, 0.002, YA, 0.029)]],
        W: comb(C, ZA, 0.085, XA, 0.012, YN, 0.012) };
    }
  };
  G.HOLD_CLS = HOLD_CLS;
  G.HOLD = G.HOLD || {};
  // керамбит: указательный палец в кольце, остальные — кулаком на рукояти, клинок изгибом вниз-вперёд (поза 2.3; правит инженер ножей)
  if (!G.HOLD.karambit) G.HOLD.karambit = {
    r: (gp) => {
      const C = gp.rh;
      return { C, A: [0, 0, -1], B: [0.6, 0.8, 0], wrap: [0.4, -1, 0], rb: 0.016, rn: 0.016,
        fingers: [{ s: -0.036, t: [-0.25, 0.75, 1.75, 2.65] }, { s: -0.016, t: [-0.25, 0.75, 1.75, 2.7] }, { s: 0.004, t: [-0.25, 0.75, 1.75, 2.65] }, { s: 0.023, t: [-0.2, 0.8, 1.75, 2.5] }],
        thumb: [[comb(C, ZA, 0.03, XN, 0.02, YN, 0.004)], [comb(C, ZA, 0.03, XN, 0.025, YA, 0.014)], [comb(C, ZA, 0.04, XN, 0.012, YA, 0.027)], [comb(C, ZA, 0.05, XN, 0.0, YA, 0.03)]],
        W: comb(C, ZA, 0.07, YN, 0.016, XA, 0.012), elbow: [0.3, -0.42, -0.04], shoulder: [0.44, -0.66, 0.12] };
    }
  };
  // поза кисти: запись оружия → класс; side 'r' | 'l'
  G.holdPose = (id, side, gp) => {
    const d = G.WEAPONS[id] || {}, nade = !!d.nade, knife = !!d.melee, pist = d.slot === 'secondary';
    const own = G.HOLD[id] && G.HOLD[id][side];
    if (own !== undefined) return typeof own === 'function' ? own(gp, id) : own;
    if (side === 'r') return gp.rh ? (nade ? HOLD_CLS.nadeR(gp) : knife ? HOLD_CLS.knifeR(gp) : HOLD_CLS.gripR(gp)) : null;
    if (nade) return gp.pinC ? HOLD_CLS.nadePin(gp) : null;
    if (!gp.lh) return null;
    return pist ? HOLD_CLS.pistolL(gp) : gp.vg ? HOLD_CLS.vgL(gp) : HOLD_CLS.foreL(gp);
  };

  // группа мешей: пластик / металл / стекло / скин a / скин b
  function skinnedGroup(parts, mats) {
    const sk = G.geo.buildSkinned(parts, mats.k);
    const g = new THREE.Group();
    if (sk.base) g.add(new THREE.Mesh(sk.base, mats.poly));
    if (sk.metal) g.add(new THREE.Mesh(sk.metal, mats.metal));
    if (sk.glass) g.add(new THREE.Mesh(sk.glass, mats.glass));
    if (sk.a) g.add(new THREE.Mesh(sk.a, mats.a));
    if (sk.b) g.add(new THREE.Mesh(sk.b, mats.b));
    if (sk.em) g.add(new THREE.Mesh(sk.em, G.emMat()));
    return g;
  }
  G.skinnedGroup = skinnedGroup;
  let emMat = null;
  G.emMat = () => emMat || (emMat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }));

  // модель от первого лица: оружие + руки с пальцами
  G.buildViewModel = (id, sleeveColor, skinId, wear, glOverride) => {
    // glOverride — перчатки другого игрока (наблюдение от первого лица); null — стандартные
    const gl = glOverride !== undefined ? glOverride : G.equippedGloves ? G.equippedGloves() : null;
    GLV = glovePal(gl && gl.id, sleeveColor === 1 || sleeveColor === '1' ? 1 : 0);
    try { return buildVM(id, sleeveColor, skinId, wear, gl); } finally { GLV = GLV_DEF; }
  };
  function buildVM(id, sleeveColor, skinId, wear, gl) {
    const gp = gunParts(id);
    const root = new THREE.Group();
    const gun = new THREE.Group();
    root.add(gun);
    const mats = G.skinMats(id, skinId, wear);
    const base = G.vmBasePos(id);
    // 2.5: парные пистолеты — корень по центру, правый пистолет на +DX, левый (зеркальная копия) на −DX
    const dual = !!gp.dual, DX = dual ? (gp.dual.dx || 0.098) : 0;
    const L = (p) => [p[0] - base[0] - DX, p[1] - base[1], p[2] - base[2]];
    const nade = !!G.WEAPONS[id].nade, knife = G.WEAPONS[id].melee || nade, pist = G.WEAPONS[id].slot === 'secondary';
    // 2.4: кисти по позам G.HOLD → гладкие сетки: перчатка (+ открытая кожа у бинтов) и рукав
    const gR = newM(), sR = newM(), kR = newM(), gL = newM(), sL = newM(), kL = newM();
    let lSh = null;
    const team = sleeveColor === 1 || sleeveColor === '1' ? 1 : 0;
    // pose.fore — направление предплечья от запястья в системе камеры (у ножей и гранат модель повёрнута — переводим)
    // gp.vmRot — свой поворот модели в ладони (ветка ножей 2.4: керамбит); иначе стандартный наклон ножа/гранаты
    const gq = knife ? new THREE.Quaternion().setFromEuler(gp.vmRot ? new THREE.Euler(gp.vmRot[0], gp.vmRot[1], gp.vmRot[2]) : nade ? new THREE.Euler(0.32, 0.38, -0.22) : new THREE.Euler(0.42, 0.45, -0.3)).invert() : null;
    const toLoc = (d) => { const v = new THREE.Vector3(d[0], d[1], d[2]); if (gq) v.applyQuaternion(gq); return [v.x, v.y, v.z]; };
    const arm = (pose, Mg, Ms, Mk) => {
      const r = handMesh(Mg, Mk, pose);
      let E, Sh;
      if (pose.fore) {
        E = comb(r.W, VA.norm(toLoc(pose.fore)), pose.foreLen || 0.27);
        Sh = comb(E, VA.norm(toLoc(pose.upper || [0.3, -0.2, 0.93])), 0.25);
      } else { E = L(pose.elbow || [0.3, -0.42, -0.04]); Sh = L(pose.shoulder || [0.44, -0.66, 0.12]); }
      armParts(Mg, Ms, r.W, E, Sh, r.lat, r.up);
      return Sh;
    };
    const pr = G.holdPose(id, 'r', gp);
    if (pr) arm(pr, gR, sR, kR);
    const pl = G.holdPose(id, 'l', gp);
    if (pl) lSh = arm(pl, gL, sL, kL);
    const armMesh = new THREE.Group();
    const gMat = G.gloveMat(gl && gl.id, gl && gl.wear, team), sMat = G.sleeveMat(team);
    const put = (grp, Mg, Ms, Mk) => {
      if (Mg.i.length) grp.add(new THREE.Mesh(meshGeo(Mg), gMat));
      if (Ms.i.length) grp.add(new THREE.Mesh(meshGeo(Ms), sMat));
      if (Mk.i.length) grp.add(new THREE.Mesh(meshGeo(Mk), G.handSkinMat()));
    };
    put(armMesh, gR, sR, kR);
    const lArm = new THREE.Group();
    put(lArm, gL, sL, kL);
    const knifeGroup = new THREE.Group();
    if (knife) gun.add(knifeGroup);
    const bodyG = skinnedGroup(gp.body, mats);
    let blade = null;
    if (gp.handle) {
      // бабочка: клинок в своей группе на оси шарнира — вращается независимо от рукоятей
      const pv = gp.pivot; blade = new THREE.Group(); blade.position.set(pv[0], pv[1], pv[2]);
      bodyG.position.set(-pv[0], -pv[1], -pv[2]); blade.add(bodyG); knifeGroup.add(blade);
    } else (knife ? knifeGroup : gun).add(bodyG);
    gun.add(armMesh, lArm);
    let magMesh = null, slide = null, pump = null, shell = null;
    if (gp.mag.length) {
      magMesh = skinnedGroup(gp.mag, mats);
      if (gp.magPivot) {
        // магазин качается вокруг переднего зацепа, как у калаша
        const mp = gp.magPivot, piv = new THREE.Group(); piv.position.set(mp[0], mp[1], mp[2]);
        magMesh.position.set(-mp[0], -mp[1], -mp[2]); piv.add(magMesh); gun.add(piv);
        magMesh = piv; magMesh.userData.rock = true;
      } else gun.add(magMesh);
    }
    if (gp.slide) { slide = skinnedGroup(gp.slide, mats); gun.add(slide); }
    if (gp.pump) { pump = skinnedGroup(gp.pump, mats); gun.add(pump); }
    // точки для анимаций перезарядки: где левая рука «дома», где она берёт магазин, куда выпадает магазин
    let home = nade && gp.pinC ? gp.pinC.slice() : null, grab = null, magDir = [0, -0.99, 0.15], magGhost = null, magC = [0, 0, 0];
    if (gp.lh) {
      home = pist ? gp.rh : gp.vg ? gp.vg : (gp.fg && gp.fg.c) || add(gp.lh, [0, 0.03, 0]);
      if (magMesh) {
        magMesh.updateMatrixWorld(true);
        const bb = new THREE.Box3().setFromObject(magMesh), c = bb.getCenter(new THREE.Vector3());
        magC = magMesh.userData.rock ? magMesh.position.toArray() : [c.x, c.y, c.z];
        grab = pist ? [c.x - 0.012, bb.min.y - 0.006, c.z + 0.004] : [c.x - 0.022, c.y - 0.012, c.z];
      }
      if (id === 'shotgun') grab = [-0.016, -0.062, -0.03];
      if (pist) magDir = [0, -0.98, 0.2];
      if (id === 'sniper' || id === 'ssg') magDir = [0, -1, 0];
    }
    // чека гранаты: на корпусе, пока не выдернута; выдернутая летит вниз отдельной копией
    let pinMesh = null, pinGhost = null;
    // 2.3: выдернутая чека остаётся на пальце левой руки и уходит с ней из кадра
    if (gp.pin) { pinMesh = skinnedGroup(gp.pin, mats); knifeGroup.add(pinMesh); pinGhost = pinMesh.clone(true); pinGhost.visible = false; (nade && gL.i.length ? lArm : gun).add(pinGhost); }
    if (nade && gL.i.length) lArm.visible = false;
    // выброшенный магазин при перезарядке: копия с общей геометрией и материалами
    if (magMesh && gp.lh) { magGhost = magMesh.clone(true); magGhost.visible = false; gun.add(magGhost); }
    if (gp.shell) { shell = skinnedGroup(gp.shell, mats); shell.visible = false; shell.position.set(home[0] - 0.004, home[1] - 0.048, home[2] + 0.012); lArm.add(shell); }
    let bolt = null;
    if (gp.bolt) {
      bolt = new THREE.Group(); bolt.position.set(gp.boltPos[0], gp.boltPos[1], gp.boltPos[2]);
      bolt.add(skinnedGroup(gp.bolt, mats)); gun.add(bolt);
    }
    let hA = null, hB = null;
    if (gp.handle) {
      // обе рукояти — на той же оси, что и клинок
      const pv = gp.pivot;
      hA = new THREE.Group(); hA.position.set(pv[0], pv[1], pv[2]);
      const ga = skinnedGroup(gp.handle(1), mats); ga.position.set(-pv[0], -pv[1], -pv[2]); hA.add(ga);
      hB = new THREE.Group(); hB.position.set(pv[0], pv[1], pv[2]);
      const gb = skinnedGroup(gp.handle(-1), mats); gb.position.set(-pv[0], -pv[1], -pv[2]); hB.add(gb);
      knifeGroup.add(hA, hB);
    }
    const flareMat = new THREE.MeshBasicMaterial({ map: G.tex('flare'), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
    const flash = new THREE.Group();
    const s = id === 'shotgun' || id === 'sniper' || id === 'magnum' ? 0.26 : id === 'ssg' ? 0.22 : id === 'pistol' || id === 'tec9' ? 0.13 : id === 'fiveseven' ? 0.115 : id === 'usp' ? 0.07 : id === 'm4s' ? 0.075 : id === 'famas' ? 0.17 : 0.19;
    const p1 = new THREE.Mesh(new THREE.PlaneGeometry(s, s), flareMat);
    const p2 = new THREE.Mesh(new THREE.PlaneGeometry(s * 0.6, s * 1.8), flareMat); p2.rotation.x = HP; p2.position.z = -s * 0.5;
    const p3 = new THREE.Mesh(new THREE.PlaneGeometry(s * 0.6, s * 1.8), flareMat); p3.rotation.set(HP, HP, 0); p3.position.z = -s * 0.5;
    flash.add(p1, p2, p3);
    flash.position.set(gp.muzzle[0], gp.muzzle[1], gp.muzzle[2]);
    flash.visible = false;
    gun.add(flash);
    // искры золотых скинов живут в той же группе, что и клинок/корпус (у бабочки клинок вращается отдельно)
    const sparkHost = blade ? bodyG : knife ? knifeGroup : gun;
    if (mats.shine) {
      const am = bodyG.children.find(c => c.material === mats.a);
      G.addSparkles(sparkHost, am, knife ? 7 : 12, knife ? 0.028 : 0.04);
    }
    let pivot = [0, 0, 0];
    if (knife) {
      // нож держится под углом; повороты анимаций идут вокруг запястья, а не вокруг гарды
      if (nade) gun.rotation.set(0.32, 0.38, -0.22); else gun.rotation.set(0.42, 0.45, -0.3);
      if (gp.vmRot) gun.rotation.set(gp.vmRot[0], gp.vmRot[1], gp.vmRot[2]); // 2.4: керамбит/бабочка
      const w = (gp.wrist ? new THREE.Vector3(gp.wrist[0], gp.wrist[1], gp.wrist[2]) : new THREE.Vector3(0.01, -0.025, id === 'karambit' ? 0.09 : nade ? 0.1 : 0.15)).applyEuler(gun.rotation);
      pivot = [w.x, w.y, w.z];
      gun.position.set(-w.x, -w.y, -w.z);
    }
    root.position.set(base[0] + pivot[0], base[1] + pivot[1], base[2] + pivot[2]);
    // 2.5: парные пистолеты — левый пистолет с левой кистью: зеркальная копия правого (scale.x = −1) в своей обёртке lw
    // (на неё идут каналы k/kp анимаций и своя отдача); затвор, магазин, выпавший магазин и вспышка копии найдены по индексам
    let dualL = null;
    if (dual) {
      gun.position.x = DX; gun.rotation.y = -(gp.dual.yaw || 0);
      const ix = (o) => gun.children.indexOf(o);
      const iS = slide ? ix(slide) : -1, iM = magMesh ? ix(magMesh) : -1, iG = magGhost ? ix(magGhost) : -1, iF = ix(flash);
      const gunL = gun.clone(true); gunL.scale.x = -1; gunL.position.set(0, 0, 0);
      const lw = new THREE.Group(); lw.position.x = -DX; lw.add(gunL); root.add(lw);
      dualL = { lw, gunL, slide: iS >= 0 ? gunL.children[iS] : null, mag: iM >= 0 ? gunL.children[iM] : null, magGhost: iG >= 0 ? gunL.children[iG] : null, flash: gunL.children[iF], dx: DX };
      if (dualL.magGhost) dualL.magGhost.visible = false;
    }
    return { root, gun, mag: magMesh, slide, pump, shell, bolt, flash, base: [base[0] + pivot[0], base[1] + pivot[1], base[2] + pivot[2]], muzzle: gp.muzzle, id, knifeGroup, hA, hB, blade, sparkHost, skin: skinId, lArm, armMesh, home, grab, magDir, pist, charge: gp.charge || null, magBase: magMesh ? magMesh.position.toArray() : null, magGhost, magC, pinMesh, pinGhost, pinC: gp.pinC || null, lSh, slideK: gp.slideK || 0, nadeL: !!(nade && gL.i.length), dual: dualL };
  }
  // материалы рук: перчатка (кожа с фактурой) и рукав (камуфляж команды)
  const handMats = {};
  G.gloveMat = (gid, wear, team) => {
    const sk = gid && G.SKINS[gid], pbr = G.pbrOn();
    const tl = !sk && (team === 1 || team === '1'); // 2.5: Налётчики по умолчанию — гладкая чёрная кожа
    const k = 'g' + (pbr ? 1 : 0) + '|' + (gid || '') + '|' + (wear || 0) + (tl ? '|t' : '');
    if (!handMats[k]) {
      if (!sk && tl) {
        const t = G.skinTex('leather', 0);
        handMats[k] = pbr
          ? new THREE.MeshStandardMaterial({ map: t, vertexColors: true, metalness: 0.05, roughness: 0.48, bumpMap: t, bumpScale: 0.006, envMap: G.envTex || null, envMapIntensity: 0.55 })
          : new THREE.MeshPhongMaterial({ map: t, vertexColors: true, shininess: 42, specular: 0x3a3a3a });
        if (pbr) G.pbrMats.push(handMats[k]);
      } else if (!sk) {
        handMats[k] = pbr
          ? new THREE.MeshStandardMaterial({ map: G.tex('glove'), vertexColors: true, metalness: 0, roughness: 0.72, normalMap: G.normalTex('glove'), normalScale: new THREE.Vector2(0.5, 0.5) })
          : new THREE.MeshPhongMaterial({ map: G.tex('glove'), vertexColors: true, shininess: 18, specular: 0x222222 });
      } else {
        // перчатки из каталога: узор скина + вершинная палитра
        const t = G.skinTex(sk.p, wear || 0), L = G.LOOK[sk.p] || [0.1, 0.6];
        let m;
        if (pbr) {
          const o = { map: t, vertexColors: true, metalness: L[0], roughness: G.clamp(L[1] + (wear || 0) * 0.08, 0, 1), envMapIntensity: L[0] < 0.5 ? 0.6 : 1 };
          if (L[2]) { o.emissiveMap = t; o.emissive = new THREE.Color(0xffffff); o.emissiveIntensity = L[2]; }
          if (L[4]) { o.bumpMap = t; o.bumpScale = L[4]; }
          m = new THREE.MeshStandardMaterial(Object.assign({ envMap: G.envTex || null }, o)); G.pbrMats.push(m);
        } else {
          m = new THREE.MeshPhongMaterial({ map: t, vertexColors: true, shininess: 20 + (1 - L[1]) * 80, specular: L[0] > 0.6 ? 0x666666 : 0x2a2a2a });
          if (L[2]) { m.emissiveMap = t; m.emissive = new THREE.Color(0xffffff); m.emissiveIntensity = L[2]; }
        }
        if (L[5] && G.addShineTo) G.addShineTo(m, L[5], sk.p);
        handMats[k] = m;
      }
    }
    return handMats[k];
  };
  // витрина перчаток: кулак правой руки с манжетой (2.4: та же гладкая сетка, что и от первого лица)
  G.buildGloveShow = (gid, wear) => {
    GLV = glovePal(gid);
    const Mg = newM(), Mk = newM();
    try {
      const r = handMesh(Mg, Mk, HOLD_CLS.showR());
      const D = VA.norm([0.012, -0.012, 0.085]);
      armParts(Mg, null, r.W, comb(r.W, D, 0.11), comb(r.W, D, 0.125), r.lat, r.up, { noSleeve: true });
    } finally { GLV = GLV_DEF; }
    const g = new THREE.Group();
    g.add(new THREE.Mesh(meshGeo(Mg), G.gloveMat(gid, wear)));
    if (Mk.i.length) g.add(new THREE.Mesh(meshGeo(Mk), G.handSkinMat()));
    // тыльная сторона кисти к зрителю, запястье внизу
    g.rotation.set(HP * 0.8, 0.15, 0.0);
    return g;
  };
  // открытая кожа (пальцы из бинтов): цвет — в вершинах
  G.handSkinMat = () => {
    const k = 'k' + (G.pbrOn() ? 1 : 0);
    if (!handMats[k]) handMats[k] = G.pbrOn() ? new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0, roughness: 0.6 }) : new THREE.MeshLambertMaterial({ vertexColors: true });
    return handMats[k];
  };
  // 2.4: ткань рукава по стороне — Спецназ: тёмно-синяя тактическая ткань рип-стоп с приглушённым камуфляжем;
  // Налётчики: песочная куртка из плотного канваса. Шов вдоль рукава, двойная строчка; обшлаг — в вершинных цветах сетки
  const paintSleeve = (team) => {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const x = c.getContext('2d'), t1 = team === '1' || team === 1;
    const pal = t1 ? ['#86734f', '#7a6845', '#91805c', '#6d5c3c'] : ['#3a465a', '#323d4f', '#435167', '#2a3343'];
    x.fillStyle = pal[0]; x.fillRect(0, 0, 256, 256);
    let sd = t1 ? 11 : 7; const r = () => { sd = (sd * 16807) % 2147483647; return (sd - 1) / 2147483646; };
    // крупные пятна (приглушённые), бесшовно
    for (let k = 1; k < 4; k++) for (let i = 0; i < (t1 ? 10 : 18); i++) {
      const px = r() * 256, py = r() * 256, rad = 12 + r() * 30;
      x.fillStyle = pal[k]; x.globalAlpha = t1 ? 0.35 : 0.55;
      for (const ox of [-256, 0, 256]) for (const oy of [-256, 0, 256]) {
        x.beginPath();
        for (let a = 0; a < 8; a++) { const an = a / 8 * Math.PI * 2, rr = rad * (0.6 + r() * 0.5); x.lineTo(px + ox + Math.cos(an) * rr * 1.3, py + oy + Math.sin(an) * rr); }
        x.fill();
      }
    }
    x.globalAlpha = 1;
    if (t1) {
      // канвас: косое плетение
      for (let yy = 0; yy < 256; yy += 2) for (let xx = (yy >> 1) % 2; xx < 256; xx += 3) { x.fillStyle = 'rgba(0,0,0,0.07)'; x.fillRect(xx, yy, 2, 1); }
    } else {
      // рип-стоп: мелкая клетка из толстых нитей
      x.fillStyle = 'rgba(255,255,255,0.05)';
      for (let i = 0; i < 256; i += 8) { x.fillRect(0, i, 256, 1); x.fillRect(i, 0, 1, 256); }
      x.fillStyle = 'rgba(0,0,0,0.06)';
      for (let i = 0; i < 256; i += 2) x.fillRect(0, i, 256, 1);
    }
    for (let i = 0; i < 2600; i++) { const v = r() < 0.5 ? 0 : 255; x.fillStyle = `rgba(${v},${v},${v},0.05)`; x.fillRect(r() * 256, r() * 256, 1.5, 1.5); }
    // шов вдоль рукава (поперёк развёртки) с двойной строчкой
    x.fillStyle = 'rgba(0,0,0,0.28)'; x.fillRect(126, 0, 3, 256);
    x.strokeStyle = t1 ? 'rgba(235,220,180,0.4)' : 'rgba(170,185,210,0.35)'; x.lineWidth = 1; x.setLineDash([4, 3]);
    for (const sx of [121.5, 133.5]) { x.beginPath(); x.moveTo(sx, 0); x.lineTo(sx, 256); x.stroke(); }
    x.setLineDash([]);
    const tx = new THREE.CanvasTexture(c); tx.wrapS = tx.wrapT = THREE.RepeatWrapping; tx.anisotropy = G.maxAniso || 1;
    return tx;
  };
  G.sleeveMat = (team) => {
    const k = 's' + team + (G.pbrOn() ? 1 : 0);
    if (!handMats[k]) {
      if (G.T && !G.T.sleeve24) G.T.sleeve24 = paintSleeve;
      const tn = G.T ? 'sleeve24' : 'sleeve';
      handMats[k] = G.pbrOn()
        ? new THREE.MeshStandardMaterial({ map: G.tex(tn, String(team)), vertexColors: true, metalness: 0, roughness: 0.92, normalMap: G.normalTex(tn, String(team)), normalScale: new THREE.Vector2(0.6, 0.6) })
        : new THREE.MeshLambertMaterial({ map: G.tex(tn, String(team)), vertexColors: true });
    }
    return handMats[k];
  };
  G.armMat = G.gloveMat;

  // модель для витрины (без рук)
  G.buildShowcase = (id, skinId, wear) => {
    if (id === 'gloves') return G.buildGloveShow(skinId, wear);
    const gp = gunParts(id);
    const mats = G.skinMats(id, skinId, wear);
    const g = new THREE.Group();
    g.add(skinnedGroup(gp.body, mats));
    if (gp.mag.length) g.add(skinnedGroup(gp.mag, mats));
    if (gp.slide) g.add(skinnedGroup(gp.slide, mats));
    if (gp.pump) g.add(skinnedGroup(gp.pump, mats));
    if (gp.bolt) { const b = skinnedGroup(gp.bolt, mats); b.position.set(gp.boltPos[0], gp.boltPos[1], gp.boltPos[2]); g.add(b); }
    if (gp.handle) g.add(skinnedGroup(gp.handle(1), mats), skinnedGroup(gp.handle(-1), mats));
    if (mats.shine) { const am = g.children[0].children.find(c => c.material === mats.a); G.addSparkles(g, am, 14, G.WEAPONS[id].melee ? 0.035 : 0.06); }
    if (gp.dual) {
      // 2.5: пара — второй пистолет рядом, зеркально (витрина и руки бойца)
      const one = new THREE.Group(); for (const c of g.children.slice()) { g.remove(c); one.add(c); }
      const two = one.clone(true); two.scale.x = -1;
      one.position.x = 0.03; two.position.x = -0.03; g.add(one, two);
      if (one.userData.sparks) { g.userData.sparks = one.userData.sparks; delete one.userData.sparks; }
    }
    return g;
  };

  // модель в руках бота (вершинные цвета, дёшево)
  G.buildWorldGun = (id) => {
    const gp = gunParts(id);
    const parts = gp.body.concat(gp.mag, gp.slide || [], gp.pump || []).filter(p => !p.em);
    if (gp.handle) parts.push(...gp.handle(1), ...gp.handle(-1));
    return { geo: G.geo.build(parts), muzzle: gp.muzzle };
  };
})(window.G);
