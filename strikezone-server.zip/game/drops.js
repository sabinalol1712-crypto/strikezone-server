'use strict';
/* Оружие на земле: выпадает при смерти, его можно подобрать или выбросить.
   Подобранный ствол сохраняет скин, патроны в магазине и запас.
   Одиночная игра — всё считает телефон; онлайн — сервер (тот же файл, G.HEADLESS),
   а телефон только рисует оружие из снимков и просит сервер подобрать/выбросить. */
(function (G) {
  const geoCache = {};
  function dropGeo(id) {
    if (geoCache[id]) return geoCache[id];
    const gp = G.gunParts(id);
    const src = gp.body.concat(gp.mag || [], gp.slide || [], gp.pump || [], gp.handle ? gp.handle(1).concat(gp.handle(-1)) : []).filter(p => !p.em);
    const geo = G.geo.build(src);
    geo.computeBoundingBox();
    return (geoCache[id] = geo);
  }
  const R2 = 1.15 * 1.15;
  let SEQ = 0;
  const online = () => !!(G.net && G.net.active);
  const emit = (t, o) => { if (G.emit) G.emit(t, o); };
  const D = G.drops = {
    list: [], MAX: 14, LIFE: 45, cand: null, reqT: 0,
    // в этом матче есть оружие на земле (онлайн — только если сервер это умеет)
    on() { return (!online() || !!G.net.dropsOK) && G.game.mode !== 'tutorial' && G.game.mode !== 'duel'; },
    // оружие на земле считает сам (одиночная игра или сервер), а не повторяет за сервером
    local() { return !online() && this.on(); },
    // геометрию всех стволов строим заранее (под заставкой), чтобы первое выпадение не давало рывок
    prewarm() { if (G.HEADLESS) return; for (const id of G.PRIMARIES.concat(G.PISTOLS)) { try { dropGeo(id); } catch (e) { } } },
    reset() { for (const d of this.list) this.removeMesh(d); this.list.length = 0; this.cand = null; emit('dropClear', {}); },
    removeMesh(d) { if (d.mesh && d.mesh.parent) d.mesh.parent.remove(d.mesh); d.mesh = null; },
    addMesh(d) {
      const g = G.game;
      if (G.HEADLESS || !g.scene) return;
      try {
        const geo = dropGeo(d.st.id), m = new THREE.Mesh(geo, G.getVCMat());
        m.rotation.z = Math.PI / 2; // на боку
        m.position.y = -geo.boundingBox.min.x + 0.015;
        const mesh = new THREE.Group(); mesh.add(m);
        mesh.position.copy(d.pos); mesh.rotation.y = d.yaw;
        g.scene.add(mesh); d.mesh = mesh;
      } catch (e) { d.mesh = null; }
    },
    remove(d) {
      const i = this.list.indexOf(d); if (i < 0) return;
      this.list.splice(i, 1); this.removeMesh(d);
      if (this.cand === d) this.cand = null;
      emit('dropDel', { d });
    },
    // 2.0: высота пола под точкой (оружие падает на пол/ящик под собой — раньше висело в воздухе, если владелец
    // погиб в прыжке или выбросил ствол с ящика); над открытой водой («Лагуна») — null: ствол тонет.
    // Считается одинаково на телефоне и на сервере (тот же файл)
    floorAt(x, y, z) {
      const M = G.map;
      // луч вниз с высоты пояса (там у игрока всегда свободно); начало внутри коробки (навес, ящик сверху) — ниже
      let oy = y + 0.9, h = M.ray(x, oy, z, 0, -1, 0, oy + 50);
      if (h && h.t < 0.02) { oy = y + 0.2; h = M.ray(x, oy, z, 0, -1, 0, oy + 50); if (h && h.t < 0.02) return y; }
      const fy = h ? oy - h.t : y;
      if (fy < 0.05 && M.waterAt && M.waterAt(x, z) != null) return null;
      return fy;
    },
    // положить оружие на землю (st — состояние ствола: скин, патроны)
    spawn(st, x, y, z, yaw, owner) {
      if (!st || !st.def || st.def.melee || st.def.nade || !this.local()) return null;
      const fy = this.floorAt(x, y, z);
      if (fy == null) { this.sank(x, z); return null; }
      y = fy;
      while (this.list.length >= this.MAX) this.remove(this.list[0]);
      st.reloadT = 0; st.drawT = 0; st.cd = 0;
      const d = { id: ++SEQ, st, slot: st.def.slot, pos: new THREE.Vector3(x, y, z), yaw: (yaw || 0) + (Math.random() - 0.5) * 1.2, mesh: null, t: 0, owner: owner || null };
      this.addMesh(d);
      this.list.push(d);
      emit('dropAdd', { d });
      return d;
    },
    // ствол упал в канал: всплеск и звук (на сервере G.fx/G.audio — заглушки)
    sank(x, z) {
      const wl = G.map.waterAt(x, z);
      if (G.fx && G.fx.splash) G.fx.splash(x, wl == null ? 0 : wl, z, 0.9);
      if (G.audio && G.audio.impact) G.audio.impact(x, 0, z, false);
    },
    // выпадение при смерти: основное оружие, а если его нет — пистолет (в режиме бомбы)
    onDeath(a) {
      if (!this.local() || !a || !a.slots) return;
      const st = a.slots.primary || (G.game.mode === 'bomb' ? a.slots.secondary : null);
      if (!st) return;
      this.spawn(st, a.pos.x, a.pos.y, a.pos.z, a.yaw, a);
      if (G.game.mode === 'bomb') { if (st === a.slots.primary) { a.slots.primary = null; a.primaryId = null; } else a.slots.secondary = null; }
    },
    // выбросить текущее оружие перед собой
    throwOut(a) {
      if (!this.on() || !a || !a.alive) return false;
      const slot = a.cur === 'primary' || a.cur === 'secondary' ? a.cur : null;
      const st = slot && a.slots[slot];
      if (!st || st.def.melee) return false;
      // нельзя остаться совсем без огнестрела? — можно, нож всегда есть
      const fx = -Math.sin(a.yaw), fz = -Math.cos(a.yaw);
      let dist = 1.7;
      const h = G.map.ray(a.pos.x, a.pos.y + 0.9, a.pos.z, fx, 0, fz, 2.1);
      if (h) dist = Math.max(0.3, h.t - 0.35);
      const tx = a.pos.x + fx * dist, tz = a.pos.z + fz * dist;
      if (online()) {
        // онлайн: выбрасывает сервер, новое оружие в руках придёт со снимком
        if (a !== G.game.player || performance.now() - this.reqT < 300) return false;
        this.reqT = performance.now();
        G.net.send({ t: 'toss', s: slot });
        G.audio.ui();
        if (this.floorAt(tx, a.pos.y, tz) == null) this.sank(tx, tz); // сервер утопит ствол так же — всплеск видим сразу
        return true;
      }
      this.spawn(st, tx, a.pos.y, tz, a.yaw, a);
      a.slots[slot] = null; if (slot === 'primary') a.primaryId = null;
      a.scoped = false;
      a.cur = a.slots.primary ? 'primary' : a.slots.secondary ? 'secondary' : 'melee';
      if (a.w) a.w.drawT = G.anim ? G.anim.dur(G.anim.drawName(a.w.id)) : 0.3;
      if (a.isPlayer && !a.net) G.audio.ui();
      return true;
    },
    take(a, d) {
      if (!d) return;
      if (online()) {
        // онлайн: просим сервер, он проверит расстояние и пришлёт «dtake»
        if (a === G.game.player && d.id != null && performance.now() - this.reqT > 250) { this.reqT = performance.now(); G.net.send({ t: 'take', id: d.id }); }
        return;
      }
      const slot = d.slot, old = a.slots[slot];
      this.remove(d);
      if (old) this.spawn(old, a.pos.x, a.pos.y, a.pos.z, a.yaw, a);
      const was = a.slots[a.cur]; if (was && was !== old && was.reloadT > 0) was.reloadT = 0; // смена оружия прерывает перезарядку
      a.autoReload = 0;
      a.slots[slot] = d.st; if (slot === 'primary') a.primaryId = d.st.id;
      a.cur = slot; a.scoped = false;
      d.st.drawT = G.anim ? G.anim.dur(G.anim.drawName(d.st.id)) : 0.3;
      emit('dropTake', { a, d, slot });
      if (a.isPlayer && !a.net) this.pickedMsg(d.st);
      else if (a.buildModel && slot === 'primary') a.buildModel(d.st.id);
    },
    pickedMsg(st) {
      G.audio.buy();
      const sk = st.skin && G.SKINS && G.SKINS[st.skin];
      G.hud.message('ПОДОБРАНО: ' + st.def.name.toUpperCase() + (sk ? ' | ' + sk.name.toUpperCase() : ''), '');
    },
    update(dt) {
      this.cand = null;
      if (!this.list.length) return;
      const g = G.game;
      if (online()) {
        // онлайн: срок жизни и подбор ведёт сервер; здесь только подсказка «ПОДОБРАТЬ»
        for (const d of this.list) d.t += dt;
        const p = g.player;
        if (!this.on() || g.frozenR || !p || !p.alive) return;
        let best = 1e9;
        for (const d of this.list) {
          const dx = d.pos.x - p.pos.x, dz = d.pos.z - p.pos.z, r = dx * dx + dz * dz;
          if (r > R2 || Math.abs(d.pos.y - p.pos.y) > 1.3) continue;
          if (d.ownerNid === p.nid && d.t < 2.5) continue;
          if (!p.slots[d.slot]) continue; // в пустой слот сервер поднимет сам
          if (r < best) { best = r; this.cand = d; }
        }
        return;
      }
      for (let i = this.list.length - 1; i >= 0; i--) {
        const d = this.list[i];
        d.t += dt;
        if (d.t > this.LIFE) this.remove(d);
      }
      if (!this.on() || g.frozenR) return;
      let best = 1e9;
      for (const a of g.actors) {
        if (!a.alive || a.dummy || a.noDrops) continue;
        for (const d of this.list) {
          const dx = d.pos.x - a.pos.x, dz = d.pos.z - a.pos.z, r = dx * dx + dz * dz;
          if (r > R2 || Math.abs(d.pos.y - a.pos.y) > 1.3) continue;
          if (d.owner === a && d.t < 2.5) continue; // только что выбросил сам
          if (a.isPlayer) {
            // пустой слот — поднимаем сразу, иначе предлагаем обменять
            if (!a.slots[d.slot]) { this.take(a, d); return; }
            if (r < best && !a.net) { best = r; this.cand = d; }
          } else if (d.slot === 'primary' && !a.slots.primary) { this.take(a, d); return; }
        }
      }
    },

    // ---------- онлайн: телефон повторяет за сервером ----------
    // полный список с сервера: [id, оружие, скин, износ, x, y, z, поворот, чьё (nid), возраст]
    netSync(arr) {
      if (!Array.isArray(arr)) return;
      const keep = new Set();
      for (const r of arr) {
        if (!Array.isArray(r)) continue;
        const id = r[0], wid = r[1], def = G.WEAPONS[wid];
        keep.add(id);
        if (!def || def.melee || def.nade || this.list.some(d => d.id === id)) continue;
        const st = G.newWeaponState(wid, r[2] || null, r[3] | 0);
        const d = { id, st, slot: def.slot, pos: new THREE.Vector3(+r[4] || 0, +r[5] || 0, +r[6] || 0), yaw: +r[7] || 0, mesh: null, t: +r[9] || 0, ownerNid: r[8] | 0, owner: null };
        this.addMesh(d);
        this.list.push(d);
      }
      for (let i = this.list.length - 1; i >= 0; i--) if (!keep.has(this.list[i].id)) { const d = this.list[i]; this.removeMesh(d); this.list.splice(i, 1); if (this.cand === d) this.cand = null; }
    },
    netGone(id) { const d = this.list.find(x => x.id === id); if (d) { this.removeMesh(d); this.list.splice(this.list.indexOf(d), 1); if (this.cand === d) this.cand = null; } },
    // сервер отдал оружие своему игроку: ствол в слот и сразу в руки (снимок потом только сверит патроны)
    netTook(p, slot, wid, skin, wear, mag, reserve) {
      const def = G.WEAPONS[wid];
      if (!p || !def || def.slot !== slot || !(slot === 'primary' || slot === 'secondary')) return;
      const st = G.newWeaponState(wid, skin || null, wear | 0);
      st.mag = mag | 0; st.reserve = reserve | 0;
      st.drawT = G.anim ? G.anim.dur(G.anim.drawName(wid)) : 0.3;
      st.firedT = -9;
      p.slots[slot] = st; if (slot === 'primary') p.primaryId = wid;
      if (p.alive) { if (p.w) p.w.reloadT = 0; p.cur = slot; p.scoped = false; }
      this.pickedMsg(st);
    }
  };
})(window.G);
