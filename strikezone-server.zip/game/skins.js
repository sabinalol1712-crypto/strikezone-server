'use strict';
/* Скины v3: процедурные узоры 512px, PBR-материалы с отражениями, износ, кейсы, инвентарь */
(function (G) {
  const S = 512;
  function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h || w; if (G.cpuCanvas && G.cpuCanvas()) { try { c.getContext('2d', { willReadFrequently: true }); } catch (e) { } } return c; } // 2.2 perf: «Низкое» — см. textures.js
  // детерминированный генератор, чтобы узор был одинаковым при каждой генерации
  let seed = 1;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const pick = (a) => a[Math.floor(rnd() * a.length)];
  function grain(x, amt) {
    const im = x.getImageData(0, 0, S, S), d = im.data;
    for (let i = 0; i < d.length; i += 4) { const n = (rnd() - 0.5) * amt; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
    x.putImageData(im, 0, 0);
  }
  // бесшовное рисование: повторяет вызов со сдвигами
  function tile(x, fn) { for (const ox of [-S, 0, S]) for (const oy of [-S, 0, S]) { x.save(); x.translate(ox, oy); fn(); x.restore(); } }
  function softBlob(x, px, py, r, col) {
    tile(x, () => { const g = x.createRadialGradient(px, py, 0, px, py, r); g.addColorStop(0, col); g.addColorStop(1, col.replace(/[\d.]+\)$/, '0)')); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2); });
  }
  // камуфляжное пятно с плавными краями
  function camoBlob(x, px, py, r, col) {
    const n = 9, pts = [];
    for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2, rr = r * (0.55 + rnd() * 0.7); pts.push([Math.cos(a) * rr * (1 + rnd() * 0.6), Math.sin(a) * rr]); }
    tile(x, () => {
      x.fillStyle = col; x.beginPath();
      for (let k = 0; k <= n; k++) {
        const p = pts[k % n], q = pts[(k + 1) % n];
        const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2;
        k ? x.quadraticCurveTo(px + p[0], py + p[1], px + mx, py + my) : x.moveTo(px + mx, py + my);
      }
      x.fill();
    });
  }
  const vgrad = (x, stops, x0, y0, x1, y1) => { const g = x.createLinearGradient(x0 || 0, y0 || 0, x1 == null ? 0 : x1, y1 == null ? S : y1); stops.forEach((c, i) => g.addColorStop(i / (stops.length - 1), c)); x.fillStyle = g; x.fillRect(0, 0, S, S); };
  function brushed(x, a) { for (let i = 0; i < 260; i++) { x.fillStyle = `rgba(255,255,255,${rnd() * a})`; x.fillRect(0, rnd() * S, S, 1); x.fillStyle = `rgba(0,0,0,${rnd() * a})`; x.fillRect(0, rnd() * S, S, 1); } }
  function sparkle(x, n, col, sz) { for (let i = 0; i < n; i++) { x.fillStyle = col; const s = (sz || 1.5) * (0.5 + rnd()); x.fillRect(rnd() * S, rnd() * S, s, s); } }
  function glowLine(x, pts, col, w, blur) {
    x.save(); x.strokeStyle = col; x.lineWidth = w; x.lineCap = 'round'; x.lineJoin = 'round'; x.shadowColor = col; x.shadowBlur = blur || 10;
    tile(x, () => { x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.stroke(); });
    x.restore();
  }

  // 2.3: бесшовное рисование только там, где фигура выходит за край (вместо 9 копий как в tile) — заметно дешевле для свечения
  function tileB(x, pts, fn) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const p of pts) { if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1]; }
    const m = 24;
    for (const ox of [-S, 0, S]) for (const oy of [-S, 0, S]) {
      if (x1 + ox < -m || x0 + ox > S + m || y1 + oy < -m || y0 + oy > S + m) continue;
      x.save(); x.translate(ox, oy); fn(); x.restore();
    }
  }
  function glowPts(x, pts, col, w, blur) {
    x.save(); x.strokeStyle = col; x.lineWidth = w; x.lineCap = 'round'; x.lineJoin = 'round'; x.shadowColor = col; x.shadowBlur = blur || 0;
    tileB(x, pts, () => { x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.stroke(); });
    x.restore();
  }

  // ---------- узоры ----------
  const P = {
    // заводские покрытия: крупные детали, чтобы фактура читалась на оружии в руках
    f_metal: (x) => {
      // воронёная штампованная сталь: пятнистое воронение, шлифовка, потёртости
      x.fillStyle = '#262a30'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 70; i++) softBlob(x, rnd() * S, rnd() * S, 24 + rnd() * 70, rnd() < 0.5 ? 'rgba(52,60,72,0.32)' : 'rgba(14,16,20,0.35)');
      for (let i = 0; i < 520; i++) { x.fillStyle = `rgba(${rnd() < 0.5 ? '255,255,255' : '0,0,0'},${rnd() * 0.07})`; x.fillRect(0, rnd() * S, S, 1 + rnd() * 1.5); }
      x.strokeStyle = 'rgba(190,198,210,0.16)'; x.lineWidth = 0.8;
      for (let i = 0; i < 70; i++) { const px = rnd() * S, py = rnd() * S, a = rnd() * 6.28, l = 6 + rnd() * 26; x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke(); }
      grain(x, 7);
    },
    f_black: (x) => {
      // чёрное матовое покрытие: лёгкая пятнистость и мелкое зерно
      x.fillStyle = '#1d2024'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 60; i++) softBlob(x, rnd() * S, rnd() * S, 20 + rnd() * 60, rnd() < 0.5 ? 'rgba(48,53,60,0.3)' : 'rgba(10,11,13,0.32)');
      x.strokeStyle = 'rgba(160,168,178,0.12)'; x.lineWidth = 0.7;
      for (let i = 0; i < 50; i++) { const px = rnd() * S, py = rnd() * S, a = rnd() * 6.28, l = 5 + rnd() * 20; x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke(); }
      grain(x, 8);
    },
    f_poly: (x) => {
      // полимер с крупной «насечкой» под ладонь
      x.fillStyle = '#26292d'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 60, rnd() < 0.5 ? 'rgba(46,50,56,0.35)' : 'rgba(18,19,22,0.35)');
      for (let yy = 0; yy < S; yy += 6) for (let xx = (yy / 6 % 2) * 3; xx < S; xx += 6) {
        x.fillStyle = 'rgba(0,0,0,0.28)'; x.fillRect(xx, yy, 3, 3); x.fillStyle = 'rgba(255,255,255,0.05)'; x.fillRect(xx, yy, 1.5, 1.5);
      }
      grain(x, 10);
    },
    f_wood: (x) => {
      // лакированное дерево: широкие годовые полосы, тонкие волокна, сучки
      vgrad(x, ['#5a2812', '#74361a', '#4c210e', '#7f401c', '#62301a', '#5a2812']);
      for (let i = 0; i < 26; i++) {
        const y = rnd() * S, w = 4 + rnd() * 12, dark = rnd() < 0.6;
        x.strokeStyle = dark ? `rgba(40,16,4,${0.25 + rnd() * 0.25})` : `rgba(170,96,44,${0.14 + rnd() * 0.16})`; x.lineWidth = w;
        tile(x, () => { x.beginPath(); x.moveTo(-10, y); x.bezierCurveTo(S * 0.3, y + (rnd() - 0.5) * 40, S * 0.65, y + (rnd() - 0.5) * 40, S + 10, y); x.stroke(); });
      }
      for (let i = 0; i < 140; i++) {
        x.strokeStyle = `rgba(${30 + rnd() * 30},${12 + rnd() * 10},4,${0.18 + rnd() * 0.3})`; x.lineWidth = 0.6 + rnd() * 1.6;
        const y = rnd() * S; x.beginPath(); x.moveTo(0, y); x.bezierCurveTo(S * 0.3, y + (rnd() - 0.5) * 24, S * 0.6, y + (rnd() - 0.5) * 24, S, y); x.stroke();
      }
      for (let i = 0; i < 3; i++) { const px = rnd() * S, py = rnd() * S; for (let r = 3; r < 26; r += 3.5) { x.strokeStyle = `rgba(45,18,5,${0.55 - r * 0.012})`; x.lineWidth = 1.4; x.beginPath(); x.ellipse(px, py, r * 2.4, r * 0.7, 0, 0, 7); x.stroke(); } }
      // блеск лака: светлые продольные полосы
      for (let i = 0; i < 6; i++) { const y = rnd() * S; x.fillStyle = 'rgba(255,190,130,0.06)'; x.fillRect(0, y, S, 6 + rnd() * 14); }
      grain(x, 9);
    },
    // тёмные заводские покрытия UMP-45 / Glock-18 / Desert Eagle: чёрный полимер с точечной насечкой, гладкий полимер,
    // азотированная сталь, воронёная сталь затвора и чуть более светлый шлифованный ствол
    f_polyBk: (x) => {
      x.fillStyle = '#17181a'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 60, rnd() < 0.5 ? 'rgba(34,36,40,0.35)' : 'rgba(6,6,8,0.35)');
      for (let yy = 0; yy < S; yy += 5) for (let xx = (yy / 5 % 2) * 2.5; xx < S; xx += 5) {
        x.fillStyle = 'rgba(0,0,0,0.45)'; x.fillRect(xx, yy, 2.5, 2.5); x.fillStyle = 'rgba(255,255,255,0.045)'; x.fillRect(xx + 2.5, yy + 2.5, 1.2, 1.2);
      }
      grain(x, 8);
    },
    f_polySm: (x) => {
      x.fillStyle = '#1c1e21'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 50; i++) softBlob(x, rnd() * S, rnd() * S, 24 + rnd() * 60, rnd() < 0.5 ? 'rgba(36,39,43,0.3)' : 'rgba(6,7,8,0.3)');
      x.strokeStyle = 'rgba(150,158,168,0.08)'; x.lineWidth = 0.7;
      for (let i = 0; i < 30; i++) { const px = rnd() * S, py = rnd() * S, a = rnd() * 6.28, l = 4 + rnd() * 14; x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke(); }
      grain(x, 6);
    },
    f_nitride: (x) => {
      x.fillStyle = '#17191c'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 60; i++) softBlob(x, rnd() * S, rnd() * S, 20 + rnd() * 60, rnd() < 0.5 ? 'rgba(40,44,50,0.3)' : 'rgba(6,7,9,0.3)');
      for (let i = 0; i < 300; i++) { x.fillStyle = `rgba(${rnd() < 0.5 ? '255,255,255' : '0,0,0'},${rnd() * 0.04})`; x.fillRect(0, rnd() * S, S, 1); }
      x.strokeStyle = 'rgba(170,178,188,0.12)'; x.lineWidth = 0.7;
      for (let i = 0; i < 40; i++) { const px = rnd() * S, py = rnd() * S, a = rnd() * 6.28, l = 5 + rnd() * 18; x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke(); }
      grain(x, 6);
    },
    f_dsteel: (x) => {
      x.fillStyle = '#1e2227'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 60; i++) softBlob(x, rnd() * S, rnd() * S, 24 + rnd() * 70, rnd() < 0.5 ? 'rgba(44,52,64,0.3)' : 'rgba(8,9,12,0.35)');
      for (let i = 0; i < 520; i++) { x.fillStyle = `rgba(${rnd() < 0.5 ? '255,255,255' : '0,0,0'},${rnd() * 0.06})`; x.fillRect(0, rnd() * S, S, 1 + rnd() * 1.5); }
      x.strokeStyle = 'rgba(190,198,210,0.14)'; x.lineWidth = 0.8;
      for (let i = 0; i < 50; i++) { const px = rnd() * S, py = rnd() * S, a = rnd() * 6.28, l = 6 + rnd() * 22; x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke(); }
      grain(x, 6);
    },
    f_dbarrel: (x) => {
      x.fillStyle = '#343a42'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 50; i++) softBlob(x, rnd() * S, rnd() * S, 24 + rnd() * 70, rnd() < 0.5 ? 'rgba(84,92,104,0.3)' : 'rgba(24,27,32,0.3)');
      for (let i = 0; i < 700; i++) { x.fillStyle = `rgba(${rnd() < 0.5 ? '255,255,255' : '0,0,0'},${rnd() * 0.08})`; x.fillRect(0, rnd() * S, S, 1 + rnd()); }
      grain(x, 5);
    },
    f_olive: (x) => { x.fillStyle = '#3f4a30'; x.fillRect(0, 0, S, S); for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 60, 'rgba(60,70,45,0.35)'); grain(x, 8); },
    f_sage: (x) => {
      // матовый серо-зелёный полимер (FAMAS): мелкое «зерно» и редкие потёртости на кромках
      x.fillStyle = '#3d443a'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 46; i++) softBlob(x, rnd() * S, rnd() * S, 26 + rnd() * 64, rnd() < 0.5 ? 'rgba(74,84,66,0.34)' : 'rgba(24,28,22,0.34)');
      for (let yy = 0; yy < S; yy += 5) for (let xx = (yy / 5 % 2) * 2.5; xx < S; xx += 5) { x.fillStyle = 'rgba(0,0,0,0.16)'; x.fillRect(xx, yy, 2, 2); }
      grain(x, 9);
    },
    f_steel: (x) => { vgrad(x, ['#8a9096', '#d2d7db', '#9aa1a7', '#e2e6e9', '#8a9096'], 0, 0, S, 0); brushed(x, 0.1); grain(x, 4); },
    desert: (x) => {
      x.fillStyle = '#c9ab80'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 26; i++) camoBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 45, pick(['#9c7a4f', '#b18f62']));
      for (let i = 0; i < 18; i++) camoBlob(x, rnd() * S, rnd() * S, 16 + rnd() * 26, '#6a5236');
      grain(x, 10);
    },
    forest: (x) => {
      x.fillStyle = '#5f6d42'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 24; i++) camoBlob(x, rnd() * S, rnd() * S, 28 + rnd() * 40, pick(['#3c4a2b', '#7f7b4c']));
      for (let i = 0; i < 18; i++) camoBlob(x, rnd() * S, rnd() * S, 14 + rnd() * 22, '#262219');
      grain(x, 10);
    },
    snowcamo: (x) => {
      x.fillStyle = '#e8edf1'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 26; i++) camoBlob(x, rnd() * S, rnd() * S, 26 + rnd() * 40, pick(['#b8c3cc', '#cfd8de']));
      for (let i = 0; i < 16; i++) camoBlob(x, rnd() * S, rnd() * S, 12 + rnd() * 24, '#7d8b97');
      grain(x, 8);
    },
    urban: (x) => {
      x.fillStyle = '#8e9296'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 26; i++) camoBlob(x, rnd() * S, rnd() * S, 26 + rnd() * 38, pick(['#5f6468', '#b4b8bb']));
      for (let i = 0; i < 16; i++) camoBlob(x, rnd() * S, rnd() * S, 12 + rnd() * 22, '#2e3134');
      grain(x, 10);
    },
    digital: (x) => {
      x.fillStyle = '#7f8a94'; x.fillRect(0, 0, S, S);
      const cols = ['#5d6770', '#a7b0b8', '#3f474f', '#8e99a3', '#6b7782'];
      for (let i = 0; i < 900; i++) { x.fillStyle = pick(cols); const s = 8 * (1 + Math.floor(rnd() * 3)); x.fillRect(Math.floor(rnd() * 64) * 8, Math.floor(rnd() * 64) * 8, s, 8 * (1 + Math.floor(rnd() * 2))); }
    },
    night: (x) => {
      x.fillStyle = '#15171b'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 700; i++) { x.fillStyle = pick(['#22252b', '#0d0e11', '#1b1e23']); x.fillRect(Math.floor(rnd() * 64) * 8, Math.floor(rnd() * 64) * 8, 16, 8); }
      for (let i = 0; i < 6; i++) glowLine(x, [[rnd() * S, rnd() * S], [rnd() * S, rnd() * S]], 'rgba(90,120,160,0.25)', 1, 0);
    },
    carbon: (x) => {
      const c = 16;
      for (let i = 0; i < S; i += c) for (let j = 0; j < S; j += c) {
        const h = ((i + j) / c) % 2;
        const g = h ? x.createLinearGradient(i, j, i + c, j) : x.createLinearGradient(i, j, i, j + c);
        g.addColorStop(0, '#0e0f11'); g.addColorStop(0.5, '#3d4147'); g.addColorStop(1, '#0e0f11');
        x.fillStyle = g; x.fillRect(i, j, c, c);
      }
      vgrad(x, ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0)', 'rgba(255,255,255,0.08)'], 0, 0, S, S);
    },
    tiger: (x) => {
      vgrad(x, ['#f2a640', '#de7a1d', '#f0b050', '#de7a1d']);
      x.fillStyle = '#140f0b';
      for (let i = 0; i < 22; i++) {
        const y = rnd() * S, w = 5 + rnd() * 12, ph = rnd() * 6;
        tile(x, () => {
          x.beginPath(); x.moveTo(-20, y);
          for (let k = 0; k <= 16; k++) x.lineTo(k * S / 16, y + Math.sin(k * 0.8 + ph) * 18 - w * Math.sin(k / 16 * Math.PI));
          for (let k = 16; k >= 0; k--) x.lineTo(k * S / 16, y + Math.sin(k * 0.8 + ph) * 18 + w * Math.sin(k / 16 * Math.PI) * (0.6 + (k % 3) * 0.3));
          x.fill();
        });
      }
      grain(x, 8);
    },
    ocean: (x) => {
      vgrad(x, ['#06203c', '#0d4f7a', '#1782ad', '#0d4f7a', '#06203c']);
      for (let i = 0; i < 26; i++) {
        const y = rnd() * S, ph = rnd() * 6, amp = 6 + rnd() * 10;
        x.strokeStyle = `rgba(190,240,255,${0.25 + rnd() * 0.35})`; x.lineWidth = 1.5 + rnd() * 2;
        tile(x, () => { x.beginPath(); for (let k = 0; k <= 40; k++) x.lineTo(k * S / 40, y + Math.sin(k * 0.5 + ph) * amp); x.stroke(); });
      }
      for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 10 + rnd() * 30, 'rgba(120,220,255,0.18)');
      sparkle(x, 400, 'rgba(230,250,255,0.7)');
    },
    sunset: (x) => { vgrad(x, ['#ffd45a', '#ff8a3a', '#ff4f7a', '#a63fc4', '#3a2a8e']); sparkle(x, 1500, 'rgba(255,255,255,0.12)', 1); grain(x, 6); },
    galaxy: (x) => {
      x.fillStyle = '#07071c'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 26; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 110, pick(['rgba(140,60,230,0.35)', 'rgba(40,110,255,0.33)', 'rgba(255,70,170,0.28)', 'rgba(60,220,255,0.18)']));
      sparkle(x, 900, 'rgba(255,255,255,0.8)', 1.2);
      for (let i = 0; i < 18; i++) {
        const px = rnd() * S, py = rnd() * S; softBlob(x, px, py, 8, 'rgba(255,255,255,0.9)');
        x.strokeStyle = 'rgba(255,255,255,0.6)'; x.lineWidth = 1; x.beginPath(); x.moveTo(px - 9, py); x.lineTo(px + 9, py); x.moveTo(px, py - 9); x.lineTo(px, py + 9); x.stroke();
      }
    },
    gold: (x) => {
      vgrad(x, ['#a8781f', '#f4d27a', '#c9962f', '#ffe9a6', '#b8862b'], 0, 0, S, S); brushed(x, 0.08);
      x.strokeStyle = 'rgba(95,60,8,0.6)'; x.lineWidth = 1.6;
      for (let i = 0; i < 16; i++) { const cx = rnd() * S, cy = rnd() * S, dir = rnd() < 0.5 ? 1 : -1; tile(x, () => { x.beginPath(); for (let a = 0; a < 13; a += 0.15) x.lineTo(cx + Math.cos(a * dir) * a * 2.8, cy + Math.sin(a * dir) * a * 2.8); x.stroke(); }); }
    },
    ice: (x) => {
      vgrad(x, ['#e9f8ff', '#bfe7ff', '#e2f5ff']);
      for (let i = 0; i < 70; i++) { x.fillStyle = `rgba(${110 + rnd() * 80},${180 + rnd() * 60},255,${0.15 + rnd() * 0.3})`; const px = rnd() * S, py = rnd() * S; tile(x, () => { x.beginPath(); x.moveTo(px, py); for (let k = 0; k < 3; k++) x.lineTo(px + (rnd() - 0.5) * 140, py + (rnd() - 0.5) * 140); x.fill(); }); }
      for (let i = 0; i < 10; i++) { // ветки инея
        const px = rnd() * S, py = rnd() * S;
        for (let b = 0; b < 6; b++) { const a = b / 6 * Math.PI * 2; glowLine(x, [[px, py], [px + Math.cos(a) * 26, py + Math.sin(a) * 26]], 'rgba(255,255,255,0.75)', 1.2, 4); }
      }
    },
    frost: (x) => { P.ice(x); for (let i = 0; i < 30; i++) softBlob(x, rnd() * S, rnd() * S, 30, 'rgba(90,150,220,0.15)'); },
    aurora: (x) => {
      vgrad(x, ['#04101c', '#0a2236', '#0b1a2e', '#04101c']);
      const cols = ['rgba(60,255,170,0.5)', 'rgba(120,90,255,0.45)', 'rgba(40,200,255,0.4)'];
      for (let i = 0; i < 9; i++) {
        const y0 = rnd() * S, ph = rnd() * 6, col = pick(cols);
        x.save(); x.filter = 'blur(6px)';
        x.fillStyle = col; x.beginPath(); x.moveTo(0, y0);
        for (let k = 0; k <= 32; k++) x.lineTo(k * S / 32, y0 + Math.sin(k * 0.35 + ph) * 30);
        for (let k = 32; k >= 0; k--) x.lineTo(k * S / 32, y0 + Math.sin(k * 0.35 + ph) * 30 + 26 + Math.sin(k * 0.9) * 10);
        x.fill(); x.restore();
      }
      sparkle(x, 300, 'rgba(255,255,255,0.7)', 1);
    },
    toxic: (x) => {
      x.fillStyle = '#16190f'; x.fillRect(0, 0, S, S);
      x.fillStyle = '#8ae61f';
      for (let i = -S; i < S * 2; i += 64) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + 28, 0); x.lineTo(i + 28 - S, S); x.lineTo(i - S, S); x.fill(); }
      for (let i = 0; i < 40; i++) { const px = rnd() * S; const h = 20 + rnd() * 70; const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(140,240,40,0.9)'); g.addColorStop(1, 'rgba(140,240,40,0)'); x.fillStyle = g; x.fillRect(px, rnd() * S, 3 + rnd() * 4, h); }
      for (let i = 0; i < 30; i++) camoBlob(x, rnd() * S, rnd() * S, 6 + rnd() * 14, 'rgba(14,16,10,0.85)');
      grain(x, 10);
    },
    neon: (x) => {
      x.fillStyle = '#0c0e14'; x.fillRect(0, 0, S, S);
      x.strokeStyle = 'rgba(255,255,255,0.04)'; x.lineWidth = 1;
      for (let i = 0; i < S; i += 32) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i, S); x.moveTo(0, i); x.lineTo(S, i); x.stroke(); }
      const cols = ['#19e6ff', '#ff2bd6', '#8a5cff'];
      for (let i = 0; i < 40; i++) {
        const col = pick(cols); let px = Math.floor(rnd() * 16) * 32, py = Math.floor(rnd() * 16) * 32; const pts = [[px, py]];
        for (let k = 0; k < 5; k++) { if (rnd() < 0.5) px += (rnd() < 0.5 ? -1 : 1) * 32; else py += (rnd() < 0.5 ? -1 : 1) * 32; pts.push([px, py]); }
        glowLine(x, pts, col, 3, 12);
        x.fillStyle = col; x.beginPath(); x.arc(px, py, 5, 0, 7); x.fill();
      }
    },
    cyber: (x) => {
      vgrad(x, ['#120a24', '#1a0f3a', '#0b1630']);
      for (let i = 0; i < 26; i++) { const y = rnd() * S, h = 4 + rnd() * 16; x.fillStyle = pick(['rgba(255,40,200,0.55)', 'rgba(30,230,255,0.55)', 'rgba(255,220,40,0.45)']); x.fillRect(rnd() * S * 0.5, y, S * (0.2 + rnd() * 0.6), h); }
      x.font = 'bold 34px monospace'; x.fillStyle = 'rgba(30,230,255,0.25)';
      for (let i = 0; i < 26; i++) x.fillText(pick(['01', '10', 'FF', 'SZ', '7A', 'C4']), rnd() * S, rnd() * S);
      P.neonOverlay(x);
    },
    neonOverlay: (x) => { for (let i = 0; i < 10; i++) glowLine(x, [[rnd() * S, rnd() * S], [rnd() * S, rnd() * S]], pick(['#ff2bd6', '#19e6ff']), 2, 14); },
    marble: (x) => {
      x.fillStyle = '#f0efea'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 30; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 80, 'rgba(200,200,205,0.25)');
      x.save(); x.filter = 'blur(1px)';
      for (let i = 0; i < 28; i++) { x.strokeStyle = `rgba(${80 + rnd() * 40},${80 + rnd() * 40},${95 + rnd() * 40},${0.3 + rnd() * 0.45})`; x.lineWidth = 0.6 + rnd() * 2.6; let px = rnd() * S, py = rnd() * S; x.beginPath(); x.moveTo(px, py); for (let k = 0; k < 6; k++) { const nx = px + (rnd() - 0.3) * 120, ny = py + (rnd() - 0.5) * 120; x.quadraticCurveTo((px + nx) / 2 + 25, (py + ny) / 2 - 25, nx, ny); px = nx; py = ny; } x.stroke(); }
      x.restore();
      for (let i = 0; i < 8; i++) glowLine(x, [[rnd() * S, rnd() * S], [rnd() * S, rnd() * S], [rnd() * S, rnd() * S]], 'rgba(205,165,70,0.7)', 1.4, 0);
    },
    flame: (x) => {
      vgrad(x, ['#050505', '#141010', '#2a0d05']);
      for (let layer = 0; layer < 3; layer++) for (let i = 0; i < 18; i++) {
        const px = rnd() * S, h = 140 + rnd() * 260 - layer * 50, w = 18 + rnd() * 36;
        const g = x.createLinearGradient(0, S, 0, S - h);
        const c = layer === 2 ? ['rgba(255,255,200,1)', 'rgba(255,200,60,0.9)'] : layer === 1 ? ['rgba(255,190,40,0.95)', 'rgba(255,90,10,0.85)'] : ['rgba(255,110,20,0.9)', 'rgba(180,10,0,0.8)'];
        g.addColorStop(0, c[0]); g.addColorStop(0.5, c[1]); g.addColorStop(1, 'rgba(120,0,0,0)');
        x.fillStyle = g; x.shadowColor = '#ff5000'; x.shadowBlur = 16;
        x.beginPath(); x.moveTo(px - w, S); x.bezierCurveTo(px - w, S - h * 0.4, px + w * 0.5, S - h * 0.6, px + (rnd() - 0.5) * 30, S - h); x.bezierCurveTo(px + w * 0.2, S - h * 0.5, px + w, S - h * 0.3, px + w, S); x.fill();
      }
      x.shadowBlur = 0;
    },
    rust: (x) => {
      x.fillStyle = '#4e4640'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 50; i++) camoBlob(x, rnd() * S, rnd() * S, 10 + rnd() * 40, pick(['#8a4a20', '#a85d25', '#6b3a1c', '#b8702e']));
      for (let i = 0; i < 26; i++) camoBlob(x, rnd() * S, rnd() * S, 8 + rnd() * 20, 'rgba(70,80,90,0.9)');
      for (let i = 0; i < 40; i++) { const px = rnd() * S, g = x.createLinearGradient(0, 0, 0, 90); g.addColorStop(0, 'rgba(120,60,20,0.5)'); g.addColorStop(1, 'rgba(120,60,20,0)'); x.fillStyle = g; x.fillRect(px, rnd() * S, 2 + rnd() * 3, 90); }
      grain(x, 20);
    },
    gem: (x, c) => {
      vgrad(x, c, 0, 0, S, S);
      for (let i = 0; i < 30; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 70, 'rgba(255,255,255,0.12)');
      for (let i = 0; i < 14; i++) softBlob(x, rnd() * S, rnd() * S, 20 + rnd() * 50, 'rgba(0,0,0,0.25)');
      sparkle(x, 600, 'rgba(255,255,255,0.65)', 1.4);
    },
    ruby: (x) => P.gem(x, ['#2a0008', '#b80f35', '#ff4a72', '#8a0020', '#2a0008']),
    sapphire: (x) => P.gem(x, ['#020833', '#0f3fc4', '#58a0ff', '#082a8a', '#020833']),
    emerald: (x) => P.gem(x, ['#012a14', '#0c9a52', '#4cf0a0', '#08703a', '#012a14']),
    pearl: (x) => { vgrad(x, ['#f6f1ff', '#ffd9ef', '#d6f4ff', '#fff6dc', '#efe4ff'], 0, 0, S, S); for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 80, pick(['rgba(255,170,220,0.2)', 'rgba(150,220,255,0.2)', 'rgba(255,240,170,0.2)'])); },
    chrome: (x) => { vgrad(x, ['#f6f8fa', '#b9c2ca', '#6f7a84', '#e8ecef', '#9aa4ad', '#f6f8fa']); brushed(x, 0.05); },
    temper: (x) => {
      P.f_steel(x);
      for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 90, pick(['rgba(40,70,200,0.45)', 'rgba(130,60,170,0.4)', 'rgba(220,170,60,0.4)', 'rgba(40,140,190,0.35)']));
    },
    damascus: (x) => {
      x.fillStyle = '#7b8187'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 90; i++) { x.strokeStyle = i % 2 ? 'rgba(35,38,42,0.75)' : 'rgba(210,214,218,0.75)'; x.lineWidth = 2.6; const y = i * 6 - 20; x.beginPath(); for (let k = 0; k <= 60; k++) x.lineTo(k * S / 60, y + Math.sin(k * 0.45 + i * 0.25) * 10 + Math.sin(k * 0.13) * 16); x.stroke(); }
    },
    magma: (x) => {
      x.fillStyle = '#120d0c'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 40; i++) camoBlob(x, rnd() * S, rnd() * S, 14 + rnd() * 36, pick(['#231915', '#1a1210', '#2e201a']));
      for (let i = 0; i < 46; i++) { let px = rnd() * S, py = rnd() * S; const pts = [[px, py]]; for (let k = 0; k < 4; k++) { px += (rnd() - 0.5) * 80; py += (rnd() - 0.5) * 80; pts.push([px, py]); } glowLine(x, pts, pick(['#ff6a1a', '#ff9a2a', '#ff3a10']), 1.5 + rnd() * 2, 10); }
    },
    hex: (x) => {
      x.fillStyle = '#121820'; x.fillRect(0, 0, S, S);
      const r = 22, h = r * Math.sqrt(3);
      for (let row = -1; row < S / h + 2; row++) for (let col = -1; col < S / (r * 1.5) + 2; col++) {
        const cx = col * r * 1.5, cy = row * h + (col % 2 ? h / 2 : 0);
        x.beginPath(); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; x.lineTo(cx + Math.cos(a) * (r - 2), cy + Math.sin(a) * (r - 2)); } x.closePath();
        const on = rnd() < 0.18;
        x.fillStyle = on ? pick(['rgba(255,190,40,0.7)', 'rgba(255,140,20,0.55)']) : 'rgba(40,50,62,0.9)'; x.fill();
        x.strokeStyle = 'rgba(255,190,60,0.35)'; x.lineWidth = 1.5; x.stroke();
      }
    },
    circuit: (x) => {
      x.fillStyle = '#0c3b22'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 60; i++) { let px = Math.floor(rnd() * 32) * 16, py = Math.floor(rnd() * 32) * 16; x.strokeStyle = 'rgba(200,170,70,0.85)'; x.lineWidth = 2.5; x.beginPath(); x.moveTo(px, py); for (let k = 0; k < 4; k++) { if (rnd() < 0.5) px += (rnd() < 0.5 ? -1 : 1) * 32; else py += (rnd() < 0.5 ? -1 : 1) * 32; x.lineTo(px, py); } x.stroke(); x.fillStyle = '#d8c070'; x.beginPath(); x.arc(px, py, 4.5, 0, 7); x.fill(); }
      for (let i = 0; i < 14; i++) { x.fillStyle = '#111'; const w = 30 + rnd() * 40; x.fillRect(rnd() * S, rnd() * S, w, w * 0.6); }
      grain(x, 8);
    },
    graffiti: (x) => {
      x.fillStyle = '#4a4d51'; x.fillRect(0, 0, S, S); grain(x, 18);
      const cols = ['#ff3b6b', '#2fd0ff', '#ffd23a', '#7cff4a', '#b05cff', '#ff8a2a'];
      for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 20 + rnd() * 60, pick(cols).replace('#', 'rgba(') && 'rgba(' + parseInt(pick(cols).slice(1, 3), 16) + ',' + parseInt(pick(cols).slice(3, 5), 16) + ',' + parseInt(pick(cols).slice(5, 7), 16) + ',0.55)');
      x.lineCap = 'round';
      for (let i = 0; i < 20; i++) { x.strokeStyle = pick(cols); x.lineWidth = 5 + rnd() * 9; x.beginPath(); let px = rnd() * S, py = rnd() * S; x.moveTo(px, py); for (let k = 0; k < 4; k++) { px += (rnd() - 0.5) * 120; py += (rnd() - 0.5) * 80; x.quadraticCurveTo(px + 30, py - 30, px, py); } x.stroke(); }
      x.font = 'bold 64px "Russo One", Arial Black, sans-serif'; x.lineWidth = 6; x.strokeStyle = '#111';
      for (let i = 0; i < 5; i++) { const t = pick(['SZ', 'BOOM', 'ZONE', 'GG', 'WOW']); const px = rnd() * S, py = rnd() * S; x.strokeText(t, px, py); x.fillStyle = pick(cols); x.fillText(t, px, py); }
    },
    lightning: (x) => {
      vgrad(x, ['#050a24', '#0c1a4a', '#050a24']);
      for (let i = 0; i < 20; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 60, 'rgba(60,90,220,0.25)');
      for (let i = 0; i < 12; i++) { let px = rnd() * S, py = 0; const pts = [[px, py]]; while (py < S) { px += (rnd() - 0.5) * 50; py += 20 + rnd() * 30; pts.push([px, py]); } glowLine(x, pts, 'rgba(180,220,255,0.95)', 2, 16); }
    },
    scales: (x) => {
      vgrad(x, ['#0d3a2a', '#1f6b4a', '#c9a23a'], 0, 0, S, S);
      const r = 18;
      for (let row = 0; row < S / (r * 0.7) + 2; row++) for (let col = -1; col < S / (r * 2) + 2; col++) {
        const cx = col * r * 2 + (row % 2 ? r : 0), cy = row * r * 0.7;
        x.strokeStyle = 'rgba(0,0,0,0.45)'; x.lineWidth = 2; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI); x.stroke();
        x.strokeStyle = 'rgba(255,240,180,0.25)'; x.lineWidth = 1; x.beginPath(); x.arc(cx, cy - 2, r - 3, 0.3, Math.PI - 0.3); x.stroke();
      }
    },
    // ---------- золотая коллекция ----------
    goldEngrave: (x) => {
      vgrad(x, ['#a87a22', '#f6d77e', '#c8962e', '#fff0b8', '#b6862a'], 0, 0, S, S); brushed(x, 0.035);
      // фон гравюры — мелкая штриховка
      x.strokeStyle = 'rgba(110,70,12,0.22)'; x.lineWidth = 0.8;
      for (let i = -S; i < S * 2; i += 5) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + S, S); x.stroke(); }
      x.lineCap = 'round';
      const scrolls = [];
      for (let i = 0; i < 26; i++) scrolls.push([rnd() * S, rnd() * S, 30 + rnd() * 34, rnd() < 0.5 ? 1 : -1, rnd() * 6.28]);
      for (const [cx, cy, r0, dir, a0] of scrolls) tile(x, () => {
        const sp = (off) => { x.beginPath(); for (let a = 0; a < 11; a += 0.1) { const rr = r0 * (1 - a / 12) + off; x.lineTo(cx + Math.cos(a0 + a * dir) * rr, cy + Math.sin(a0 + a * dir) * rr); } x.stroke(); };
        // полированная дорожка с тёмным контуром
        x.strokeStyle = 'rgba(70,40,6,0.85)'; x.lineWidth = 7; sp(0);
        x.strokeStyle = 'rgba(255,236,170,0.95)'; x.lineWidth = 4; sp(0);
        x.strokeStyle = 'rgba(255,255,235,0.8)'; x.lineWidth = 1.2; sp(-1);
        for (let a = 0.5; a < 9; a += 0.9) {
          const rr = r0 * (1 - a / 12), px = cx + Math.cos(a0 + a * dir) * rr, py = cy + Math.sin(a0 + a * dir) * rr;
          x.save(); x.translate(px, py); x.rotate(a0 + a * dir + Math.PI / 2 * dir); const L = 14 + r0 * 0.25;
          x.beginPath(); x.moveTo(0, 0); x.quadraticCurveTo(L * 0.5, -L * 0.45, 0, -L); x.quadraticCurveTo(-L * 0.5, -L * 0.45, 0, 0);
          const g = x.createLinearGradient(0, 0, 0, -L); g.addColorStop(0, '#fff3c4'); g.addColorStop(1, '#d6a23e'); x.fillStyle = g; x.fill();
          x.strokeStyle = 'rgba(70,40,6,0.85)'; x.lineWidth = 1.6; x.stroke();
          x.beginPath(); x.moveTo(0, -2); x.lineTo(0, -L * 0.8); x.strokeStyle = 'rgba(120,75,15,0.7)'; x.lineWidth = 0.9; x.stroke(); x.restore();
        }
      });
    },
    goldLeaf: (x) => {
      vgrad(x, ['#8a6418', '#b8892a', '#9a7020'], 0, 0, S, S);
      for (let i = 0; i < 280; i++) {
        const px = rnd() * S, py = rnd() * S, r = 8 + rnd() * 24, n = 5 + Math.floor(rnd() * 3), pts = [];
        for (let k = 0; k < n; k++) { const a = k / n * 6.28 + rnd() * 0.6, rr = r * (0.6 + rnd() * 0.5); pts.push([Math.cos(a) * rr, Math.sin(a) * rr]); }
        const col = pick(['#f7d66e', '#ffe49a', '#e8be4e', '#fff0c0', '#d9aa3c']);
        tile(x, () => { x.fillStyle = col; x.beginPath(); pts.forEach((q, k) => k ? x.lineTo(px + q[0], py + q[1]) : x.moveTo(px + q[0], py + q[1])); x.closePath(); x.fill(); x.strokeStyle = 'rgba(110,70,10,0.35)'; x.lineWidth = 0.8; x.stroke(); });
      }
      sparkle(x, 500, 'rgba(255,255,240,0.85)', 1.3);
    },
    blackGold: (x) => {
      x.fillStyle = '#0b0a09'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 30; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 70, 'rgba(46,40,32,0.35)');
      for (let i = 0; i < 24; i++) { let px = rnd() * S, py = rnd() * S; const pts = [[px, py]]; for (let k = 0; k < 6; k++) { px += (rnd() - 0.4) * 90; py += (rnd() - 0.5) * 90; pts.push([px, py]); } glowLine(x, pts, pick(['#ffcf5a', '#f2b632', '#ffe08a']), 0.8 + rnd() * 2.6, 9); }
      sparkle(x, 320, 'rgba(255,220,120,0.75)', 1.2);
    },
    roseGold: (x) => {
      vgrad(x, ['#b9786a', '#f2c2b2', '#c98a7a', '#ffd9cc', '#b06f62'], 0, 0, S, 0); brushed(x, 0.07);
      x.strokeStyle = 'rgba(120,60,50,0.38)'; x.lineWidth = 1.4;
      for (let gy = 0; gy <= S; gy += 64) for (let gx = -32; gx <= S; gx += 64) {
        const ox = gx + ((gy / 64) % 2 ? 32 : 0);
        x.beginPath(); x.moveTo(ox, gy - 22); x.quadraticCurveTo(ox + 18, gy, ox, gy + 22); x.quadraticCurveTo(ox - 18, gy, ox, gy - 22); x.stroke();
        x.beginPath(); x.arc(ox, gy, 4, 0, 7); x.stroke();
      }
      sparkle(x, 300, 'rgba(255,240,235,0.7)', 1.2);
    },
    royal: (x) => {
      vgrad(x, ['#170a3a', '#2a1468', '#1a0c48'], 0, 0, S, S);
      x.strokeStyle = 'rgba(230,190,90,0.3)'; x.lineWidth = 1;
      for (let i = -S; i <= S * 2; i += 64) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + S, S); x.stroke(); x.beginPath(); x.moveTo(i, 0); x.lineTo(i - S, S); x.stroke(); }
      const motif = (cx, cy, k) => {
        x.save(); x.translate(cx, cy); x.scale(k, k);
        const g = x.createLinearGradient(0, -30, 0, 30); g.addColorStop(0, '#fff0b0'); g.addColorStop(0.5, '#d9a53a'); g.addColorStop(1, '#a8781f'); x.fillStyle = g;
        x.beginPath(); x.moveTo(0, -30); x.bezierCurveTo(12, -14, 10, 6, 0, 14); x.bezierCurveTo(-10, 6, -12, -14, 0, -30); x.fill();
        for (const sx of [1, -1]) { x.beginPath(); x.moveTo(0, 10); x.bezierCurveTo(sx * 18, 6, sx * 26, -10, sx * 16, -20); x.bezierCurveTo(sx * 22, -6, sx * 14, 8, sx * 4, 14); x.fill(); }
        x.fillRect(-12, 14, 24, 4); x.beginPath(); x.moveTo(-6, 18); x.lineTo(6, 18); x.lineTo(0, 30); x.fill();
        x.restore();
      };
      for (let r = 0; r <= 4; r++) for (let c = -1; c <= 4; c++) motif(c * 128 + (r % 2 ? 64 : 0), r * 128, 1.1);
      sparkle(x, 260, 'rgba(255,230,160,0.7)', 1.2);
    },
    diamond: (x) => {
      x.fillStyle = '#cfe6f5'; x.fillRect(0, 0, S, S);
      const N = 16, cs = S / N;
      const tri = (a, b, c, v) => { const l = 165 + v * 90 | 0; x.fillStyle = `rgb(${l - 25},${l - 4},${Math.min(255, l + 22)})`; x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.lineTo(c[0], c[1]); x.fill(); };
      for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
        const px = i * cs, py = j * cs, m = [px + cs / 2, py + cs / 2];
        tri([px, py], [px + cs, py], m, rnd()); tri([px + cs, py], [px + cs, py + cs], m, rnd()); tri([px + cs, py + cs], [px, py + cs], m, rnd()); tri([px, py + cs], [px, py], m, rnd());
      }
      for (let i = 0; i < 40; i++) softBlob(x, rnd() * S, rnd() * S, 20 + rnd() * 50, pick(['rgba(255,150,220,0.2)', 'rgba(120,220,255,0.22)', 'rgba(255,240,150,0.18)']));
      sparkle(x, 900, 'rgba(255,255,255,0.95)', 1.6);
    },
    dragon: (x) => {
      vgrad(x, ['#3a0606', '#7a0c0c', '#2a0404'], 0, 0, S, S);
      const r = 32;
      for (let row = 0; row <= 20; row++) for (let col = -1; col <= 8; col++) {
        const cx = col * r * 2 + (row % 2 ? r : 0), cy = row * 25.6;
        const g = x.createRadialGradient(cx, cy - 6, 2, cx, cy, r); g.addColorStop(0, 'rgba(255,236,160,0.97)'); g.addColorStop(0.55, 'rgba(214,150,40,0.9)'); g.addColorStop(0.85, 'rgba(140,40,10,0.9)'); g.addColorStop(1, 'rgba(60,10,4,0.95)');
        x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI); x.fill(); x.strokeStyle = 'rgba(40,8,2,0.85)'; x.lineWidth = 2; x.stroke();
        x.strokeStyle = 'rgba(255,240,190,0.5)'; x.lineWidth = 1; x.beginPath(); x.arc(cx, cy + 3, r - 6, 0.4, Math.PI - 0.4); x.stroke();
      }
    },
    goldCarbon: (x) => {
      P.carbon(x);
      x.save(); x.shadowColor = '#ffcc44'; x.shadowBlur = 6; x.strokeStyle = 'rgba(255,205,80,0.75)'; x.lineWidth = 1.6;
      for (let i = -S; i <= S * 2; i += 48) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + S, S); x.stroke(); x.beginPath(); x.moveTo(i, 0); x.lineTo(i - S, S); x.stroke(); }
      x.restore();
    },
    // ---------- пропуск «Цветение» ----------
    // ветви сакуры с цветами на тёмном лаке
    sakura: (x) => {
      vgrad(x, ['#1a0d14', '#3a1626', '#24101c'], 0, 0, S, S);
      for (let i = 0; i < 26; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 70, 'rgba(120,40,70,0.22)');
      const flower = (px, py, r, a0) => tile(x, () => {
        for (let k = 0; k < 5; k++) {
          const a = a0 + k * 1.2566, cx = px + Math.cos(a) * r * 0.62, cy = py + Math.sin(a) * r * 0.62;
          const g = x.createRadialGradient(cx, cy, 0, cx, cy, r * 0.62); g.addColorStop(0, '#fff4f8'); g.addColorStop(0.7, '#f7b6cc'); g.addColorStop(1, '#e07fa2');
          x.fillStyle = g; x.beginPath(); x.ellipse(cx, cy, r * 0.62, r * 0.46, a, 0, 7); x.fill();
          x.strokeStyle = 'rgba(150,40,80,0.5)'; x.lineWidth = 0.8; x.stroke();
        }
        x.fillStyle = '#d23a6a'; x.beginPath(); x.arc(px, py, r * 0.22, 0, 7); x.fill();
        x.fillStyle = '#ffd860'; for (let k = 0; k < 6; k++) { const a = k * 1.047 + a0; x.fillRect(px + Math.cos(a) * r * 0.3 - 1, py + Math.sin(a) * r * 0.3 - 1, 2.4, 2.4); }
      });
      // ветви
      for (let b = 0; b < 7; b++) {
        let px = rnd() * S, py = rnd() * S, a = rnd() * 6.28; const pts = [[px, py]];
        for (let k = 0; k < 9; k++) { a += (rnd() - 0.5) * 0.9; px += Math.cos(a) * 34; py += Math.sin(a) * 34; pts.push([px, py]); }
        x.save(); x.lineCap = 'round'; x.strokeStyle = '#0d0608'; x.lineWidth = 9 - b * 0.5;
        tile(x, () => { x.beginPath(); pts.forEach((q, k) => k ? x.lineTo(q[0], q[1]) : x.moveTo(q[0], q[1])); x.stroke(); });
        x.strokeStyle = 'rgba(120,80,60,0.6)'; x.lineWidth = 2;
        tile(x, () => { x.beginPath(); pts.forEach((q, k) => k ? x.lineTo(q[0] - 1, q[1] - 1) : x.moveTo(q[0] - 1, q[1] - 1)); x.stroke(); });
        x.restore();
        for (const q of pts) if (rnd() < 0.8) flower(q[0] + (rnd() - 0.5) * 22, q[1] + (rnd() - 0.5) * 22, 9 + rnd() * 9, rnd() * 6.28);
      }
      for (let i = 0; i < 70; i++) { const px = rnd() * S, py = rnd() * S; tile(x, () => { x.fillStyle = pick(['#f7b6cc', '#fde0ea', '#e98fb0']); x.beginPath(); x.ellipse(px, py, 4, 2.4, rnd() * 3, 0, 7); x.fill(); }); }
      sparkle(x, 200, 'rgba(255,220,235,0.6)', 1.2);
    },
    // карпы кои в тёмной воде с кругами
    koi: (x) => {
      vgrad(x, ['#06222e', '#0b3a4a', '#062430'], 0, 0, S, S);
      x.strokeStyle = 'rgba(160,230,240,0.18)'; x.lineWidth = 1.4;
      for (let i = 0; i < 26; i++) { const px = rnd() * S, py = rnd() * S, r = 14 + rnd() * 40; tile(x, () => { for (let k = 0; k < 3; k++) { x.beginPath(); x.ellipse(px, py, r + k * 9, (r + k * 9) * 0.45, 0, 0, 7); x.stroke(); } }); }
      const fish = (px, py, a, k, body, spot) => tile(x, () => {
        x.save(); x.translate(px, py); x.rotate(a); x.scale(k, k);
        x.fillStyle = 'rgba(0,0,0,0.35)'; x.beginPath(); x.ellipse(4, 6, 34, 13, 0, 0, 7); x.fill();
        x.fillStyle = body; x.beginPath(); x.moveTo(-34, 0); x.bezierCurveTo(-20, -15, 18, -15, 32, 0); x.bezierCurveTo(18, 15, -20, 15, -34, 0); x.fill();
        x.beginPath(); x.moveTo(-30, 0); x.lineTo(-52, -14); x.quadraticCurveTo(-44, 0, -52, 14); x.closePath(); x.fill();
        for (const sd of [-1, 1]) { x.beginPath(); x.moveTo(8, sd * 8); x.quadraticCurveTo(0, sd * 24, -8, sd * 10); x.fill(); }
        x.fillStyle = spot; for (let i = 0; i < 4; i++) { x.beginPath(); x.ellipse(-16 + i * 11 + rnd() * 4, (rnd() - 0.5) * 8, 6 + rnd() * 4, 4 + rnd() * 3, rnd(), 0, 7); x.fill(); }
        x.fillStyle = '#111'; x.beginPath(); x.arc(24, -5, 2, 0, 7); x.arc(24, 5, 2, 0, 7); x.fill();
        x.strokeStyle = 'rgba(255,255,255,0.35)'; x.lineWidth = 1.2; x.beginPath(); x.moveTo(-22, -8); x.bezierCurveTo(-4, -12, 12, -11, 26, -4); x.stroke();
        x.restore();
      });
      for (let i = 0; i < 9; i++) fish(rnd() * S, rnd() * S, rnd() * 6.28, 0.7 + rnd() * 0.5, pick(['#f4efe6', '#ff7a2a', '#ffb040', '#f8f4ec']), pick(['#e8452a', '#1a1a1a', '#ff5a1a']));
      for (let i = 0; i < 16; i++) { const px = rnd() * S, py = rnd() * S, r = 12 + rnd() * 10; tile(x, () => { x.fillStyle = '#2f6e3a'; x.beginPath(); x.moveTo(px, py); x.arc(px, py, r, 0.4, 6); x.fill(); x.strokeStyle = 'rgba(160,220,140,0.4)'; x.lineWidth = 1; x.stroke(); }); }
      sparkle(x, 300, 'rgba(220,250,255,0.5)', 1.2);
    },
    // чёрный лак с золотыми сакурами и гербами — «Император»
    emperor: (x) => {
      x.fillStyle = '#07060a'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 34; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 80, 'rgba(60,30,80,0.3)');
      x.strokeStyle = 'rgba(214,170,70,0.35)'; x.lineWidth = 1;
      for (let i = -S; i <= S * 2; i += 32) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + S, S); x.stroke(); }
      const gold = (y0, y1) => { const g = x.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, '#fff3c0'); g.addColorStop(0.45, '#e2b04a'); g.addColorStop(1, '#8a5e14'); return g; };
      const mon = (cx, cy, r) => tile(x, () => {
        x.save(); x.translate(cx, cy);
        x.shadowColor = '#ffcf6a'; x.shadowBlur = 10;
        x.strokeStyle = gold(-r, r); x.lineWidth = 3; x.beginPath(); x.arc(0, 0, r, 0, 7); x.stroke();
        x.fillStyle = gold(-r, r);
        for (let k = 0; k < 16; k++) { const a = k * Math.PI / 8; x.beginPath(); x.ellipse(Math.cos(a) * r * 0.55, Math.sin(a) * r * 0.55, r * 0.3, r * 0.1, a, 0, 7); x.fill(); }
        x.beginPath(); x.arc(0, 0, r * 0.22, 0, 7); x.fill();
        x.restore();
      });
      for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) mon(c * 128 + (r % 2 ? 64 : 0) + 32, r * 128 + 64, 26);
      for (let i = 0; i < 40; i++) {
        const px = rnd() * S, py = rnd() * S, r = 7 + rnd() * 6, a0 = rnd() * 6.28;
        tile(x, () => { x.fillStyle = gold(py - r, py + r); for (let k = 0; k < 5; k++) { const a = a0 + k * 1.2566; x.beginPath(); x.ellipse(px + Math.cos(a) * r * 0.6, py + Math.sin(a) * r * 0.6, r * 0.55, r * 0.4, a, 0, 7); x.fill(); } x.fillStyle = '#7a1020'; x.beginPath(); x.arc(px, py, r * 0.2, 0, 7); x.fill(); });
      }
      for (let i = 0; i < 10; i++) { let px = rnd() * S, py = rnd() * S; const pts = [[px, py]]; for (let k = 0; k < 6; k++) { px += (rnd() - 0.4) * 80; py += (rnd() - 0.5) * 80; pts.push([px, py]); } glowLine(x, pts, '#d9a33a', 1.4, 8); }
      sparkle(x, 500, 'rgba(255,230,160,0.85)', 1.3);
    },
    // ---------- 2.3: Аркана ----------
    // яркий узор на тёмной основе: в игре он светится (emissive) и «течёт» волнами в шейдере (addArcane)
    // плазма: ветвящиеся электрические дуги, сгустки плазмы, тонкие соты
    plasma: (x) => {
      vgrad(x, ['#03050e', '#0a1028', '#05081a', '#0d0a26', '#03050e'], 0, 0, S, S);
      for (let i = 0; i < 16; i++) softBlob(x, rnd() * S, rnd() * S, 50 + rnd() * 100, pick(['rgba(30,110,255,0.22)', 'rgba(140,60,255,0.24)', 'rgba(0,210,255,0.14)']));
      const r = 11, h = r * Math.sqrt(3); x.strokeStyle = 'rgba(110,150,255,0.13)'; x.lineWidth = 1;
      for (let row = 0; row <= S / h + 1; row++) for (let col = 0; col <= S / (r * 1.5) + 1; col++) {
        const cx = col * r * 1.5, cy = row * h + (col % 2 ? h / 2 : 0);
        x.beginPath(); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; x.lineTo(cx + Math.cos(a) * (r - 1.5), cy + Math.sin(a) * (r - 1.5)); } x.closePath(); x.stroke();
      }
      const arc = (px, py, a, len, w, d) => {
        const pts = [[px, py]];
        for (let k = 0; k < len; k++) {
          a += (rnd() - 0.5) * 1.2; px += Math.cos(a) * 13; py += Math.sin(a) * 13; pts.push([px, py]);
          if (d < 2 && rnd() < 0.2) arc(px, py, a + (rnd() < 0.5 ? -1 : 1) * (0.5 + rnd() * 0.7), Math.max(3, len * 0.45 | 0), w * 0.6, d + 1);
        }
        glowPts(x, pts, 'rgba(130,70,255,0.6)', w * 3.4, 16); glowPts(x, pts, '#2fe6ff', w * 1.5, 9); glowPts(x, pts, 'rgba(240,255,255,0.95)', w * 0.55, 2);
      };
      for (let i = 0; i < 8; i++) arc(rnd() * S, rnd() * S, rnd() * 6.28, 12 + rnd() * 14 | 0, 1.7 + rnd() * 1.3, 0);
      for (let i = 0; i < 12; i++) { const px = rnd() * S, py = rnd() * S, rr = 4 + rnd() * 9; softBlob(x, px, py, rr * 3.2, 'rgba(60,190,255,0.4)'); softBlob(x, px, py, rr, 'rgba(235,255,255,0.95)'); }
      sparkle(x, 520, 'rgba(150,235,255,0.85)', 1.3);
    },
    // голограмма: радужная дифракционная фольга, грани-«наклейки», тонкие штрихи решётки, призмы и блёстки
    holo: (x) => {
      for (let d = -S; d < 2 * S; d += 2) { x.strokeStyle = `hsl(${((d / (S / 2)) * 360 % 360 + 360) % 360},86%,58%)`; x.lineWidth = 2.6; x.beginPath(); x.moveTo(d, 0); x.lineTo(d - S, S); x.stroke(); }
      vgrad(x, ['rgba(255,255,255,0.28)', 'rgba(40,40,70,0.22)', 'rgba(255,255,255,0.34)', 'rgba(30,30,60,0.2)', 'rgba(255,255,255,0.28)']); // хромовые полосы поверх радуги
      const N = 16, cs = S / N; // грани
      for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
        const px = i * cs, py = j * cs, up = (i + j) % 2;
        for (const tri of up ? [[[px, py], [px + cs, py], [px, py + cs]], [[px + cs, py], [px + cs, py + cs], [px, py + cs]]] : [[[px, py], [px + cs, py], [px + cs, py + cs]], [[px, py], [px + cs, py + cs], [px, py + cs]]]) {
          const v = rnd(); x.fillStyle = v < 0.5 ? `rgba(255,255,255,${0.03 + v * 0.26})` : `rgba(20,0,60,${(v - 0.5) * 0.3})`;
          x.beginPath(); x.moveTo(tri[0][0], tri[0][1]); x.lineTo(tri[1][0], tri[1][1]); x.lineTo(tri[2][0], tri[2][1]); x.fill();
        }
      }
      // гильош, как на голографической защитной наклейке
      for (let i = 0; i < 4; i++) {
        const cx = rnd() * S, cy = rnd() * S, R = 44 + rnd() * 40;
        tileB(x, [[cx - R, cy - R], [cx + R, cy + R]], () => {
          x.strokeStyle = 'rgba(255,255,255,0.4)'; x.lineWidth = 0.8;
          for (let k = 0; k < 36; k++) { x.beginPath(); x.ellipse(cx, cy, R, R * 0.38, k / 36 * Math.PI, 0, 7); x.stroke(); }
          const g = x.createRadialGradient(cx, cy, 0, cx, cy, R * 0.5); g.addColorStop(0, 'rgba(255,255,255,0.85)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, R * 0.5, 0, 7); x.fill();
        });
      }
      x.strokeStyle = 'rgba(255,255,255,0.12)'; x.lineWidth = 0.7;
      for (let d = -S; d < 2 * S; d += 5) { x.beginPath(); x.moveTo(d, 0); x.lineTo(d + S * 0.5, S); x.stroke(); }
      for (let i = 0; i < 8; i++) { // призмы: светлые осколки с радужным контуром
        const px = rnd() * S, py = rnd() * S, rr = 24 + rnd() * 36, a0 = rnd() * 6.28, pts = [];
        for (let k = 0; k < 3; k++) { const a = a0 + k * 2.1 + (rnd() - 0.5) * 0.5; pts.push([px + Math.cos(a) * rr, py + Math.sin(a) * rr]); }
        tileB(x, pts, () => {
          const g = x.createLinearGradient(pts[0][0], pts[0][1], pts[1][0], pts[1][1]); g.addColorStop(0, 'rgba(255,255,255,0.7)'); g.addColorStop(1, 'rgba(255,255,255,0)');
          x.fillStyle = g; x.beginPath(); pts.forEach((q, k) => k ? x.lineTo(q[0], q[1]) : x.moveTo(q[0], q[1])); x.closePath(); x.fill();
        });
        glowPts(x, pts.concat([pts[0]]), `hsl(${rnd() * 360 | 0},100%,72%)`, 1.6, 8);
      }
      for (let i = 0; i < 1400; i++) { x.fillStyle = rnd() < 0.6 ? 'rgba(255,255,255,0.9)' : `hsla(${rnd() * 360 | 0},100%,78%,0.9)`; const sz = 0.8 + rnd() * 1.8; x.fillRect(rnd() * S, rnd() * S, sz, sz); }
    },
    // феникс: огненные перья веером на чёрно-багровом лаке, золотая филигрань, угли
    phoenix: (x) => {
      vgrad(x, ['#100204', '#2a0508', '#150306', '#2c0906', '#100204'], 0, 0, S, S);
      for (let i = 0; i < 24; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 80, pick(['rgba(120,10,10,0.3)', 'rgba(60,0,10,0.35)', 'rgba(160,50,0,0.18)']));
      const feather = (px, py, a, L, w) => {
        const tx = px + Math.cos(a) * L, ty = py + Math.sin(a) * L, nx = -Math.sin(a), ny = Math.cos(a), bend = (rnd() - 0.5) * 0.5 * L;
        const mx = (px + tx) / 2 + nx * bend, my = (py + ty) / 2 + ny * bend;
        const pts = [[px, py], [tx, ty], [mx + nx * w, my + ny * w], [mx - nx * w, my - ny * w]];
        tileB(x, pts, () => {
          const g = x.createLinearGradient(px, py, tx, ty);
          g.addColorStop(0, 'rgba(70,4,4,0.95)'); g.addColorStop(0.35, '#c21d0c'); g.addColorStop(0.7, '#ff7a14'); g.addColorStop(0.92, '#ffd36a'); g.addColorStop(1, '#fff3c8');
          x.fillStyle = g; x.shadowColor = '#ff5a10'; x.shadowBlur = 12;
          x.beginPath(); x.moveTo(px, py);
          x.quadraticCurveTo(mx + nx * w * 1.25, my + ny * w * 1.25, tx, ty); x.quadraticCurveTo(mx - nx * w * 1.25, my - ny * w * 1.25, px, py); x.fill();
          x.shadowBlur = 0; x.strokeStyle = 'rgba(40,0,0,0.45)'; x.lineWidth = 1;
          for (let t = 0.15; t < 0.95; t += 0.07) { // бородки пера
            const qx = px + (tx - px) * t + nx * bend * 4 * t * (1 - t), qy = py + (ty - py) * t + ny * bend * 4 * t * (1 - t), ww = w * 1.1 * Math.sin(t * Math.PI);
            x.beginPath(); x.moveTo(qx + nx * ww, qy + ny * ww); x.lineTo(qx, qy); x.lineTo(qx - nx * ww, qy - ny * ww); x.stroke();
          }
          x.strokeStyle = 'rgba(255,236,170,0.9)'; x.lineWidth = 1.6; x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(mx, my, tx, ty); x.stroke();
        });
      };
      for (let i = 0; i < 18; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 50, 'rgba(255,90,20,0.16)'); // отсветы жара
      for (let f = 0; f < 7; f++) { // веера перьев
        const px = (f % 3 + 0.2 + rnd() * 0.6) * S / 3, py = ((f * 0.43 + rnd() * 0.3) % 1) * S, a0 = rnd() * 6.28, n = 6 + (rnd() * 3 | 0), L = 120 + rnd() * 80;
        for (let k = 0; k < n; k++) feather(px, py, a0 + (k - n / 2) * 0.26, L * (0.7 + rnd() * 0.35), 12 + rnd() * 6);
      }
      for (let i = 0; i < 10; i++) { // золотая филигрань — завитки
        const cx = rnd() * S, cy = rnd() * S, r0 = 14 + rnd() * 16, dir = i % 2 ? 1 : -1, a0 = rnd() * 6.28, pts = [];
        for (let a = 0; a < 9; a += 0.25) { const rr = r0 * (1 - a / 10); pts.push([cx + Math.cos(a0 + a * dir) * rr, cy + Math.sin(a0 + a * dir) * rr]); }
        glowPts(x, pts, '#ffd36a', 1.4, 6);
      }
      for (let i = 0; i < 260; i++) { const px = rnd() * S, py = rnd() * S; x.fillStyle = pick(['rgba(255,200,80,0.95)', 'rgba(255,120,30,0.9)', 'rgba(255,240,190,0.95)']); x.fillRect(px, py, 1 + rnd() * 2, 1 + rnd() * 2); }
    },
    // кровавая луна: обсидиан, светящиеся алые трещины и печати с рунами, луна в центре печати
    bloodmoon: (x) => {
      vgrad(x, ['#070205', '#14040a', '#090306', '#16050b', '#070205'], 0, 0, S, S);
      for (let i = 0; i < 30; i++) softBlob(x, rnd() * S, rnd() * S, 30 + rnd() * 90, pick(['rgba(90,0,20,0.3)', 'rgba(20,0,10,0.4)', 'rgba(140,10,40,0.16)']));
      softBlob(x, S * 0.5, S * 0.5, 220, 'rgba(150,0,30,0.2)');
      const crack = (px, py, a, n, w, d) => { // трещины со светящейся лавой
        const pts = [[px, py]];
        for (let k = 0; k < n; k++) { a += (rnd() - 0.5) * 0.9; px += Math.cos(a) * (8 + rnd() * 8); py += Math.sin(a) * (8 + rnd() * 8); pts.push([px, py]); if (d < 2 && rnd() < 0.16) crack(px, py, a + (rnd() < 0.5 ? -1 : 1) * 0.9, n / 2 | 0, w * 0.6, d + 1); }
        glowPts(x, pts, 'rgba(255,20,50,0.55)', w * 2.6, 12); glowPts(x, pts, '#ff8090', w * 0.7, 3);
      };
      for (let i = 0; i < 8; i++) crack(rnd() * S, rnd() * S, rnd() * 6.28, 10 + rnd() * 12 | 0, 1.2 + rnd() * 1.4, 0);
      const sigil = (cx, cy, R) => {
        const ring = (rr, w) => { const pts = []; for (let k = 0; k <= 48; k++) { const a = k / 48 * Math.PI * 2; pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr]); } glowPts(x, pts, '#ff2a48', w, 12); };
        tileB(x, [[cx - R, cy - R], [cx + R, cy + R]], () => { const g = x.createRadialGradient(cx, cy, 0, cx, cy, R * 0.42); g.addColorStop(0, '#ffd0d6'); g.addColorStop(0.35, '#ff3050'); g.addColorStop(0.8, 'rgba(120,0,20,0.9)'); g.addColorStop(1, 'rgba(60,0,10,0)'); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, R * 0.42, 0, 7); x.fill(); });
        ring(R, 2.2); ring(R * 0.8, 1.4); ring(R * 0.45, 1.2);
        const n = 5 + (rnd() * 3 | 0), st = [];
        for (let k = 0; k <= n; k++) { const a = (k * 2 % n) / n * Math.PI * 2 - Math.PI / 2; st.push([cx + Math.cos(a) * R * 0.8, cy + Math.sin(a) * R * 0.8]); }
        glowPts(x, st, 'rgba(255,60,90,0.9)', 1.2, 8);
        for (let k = 0; k < 18; k++) { // руны между кольцами
          const a = k / 18 * Math.PI * 2, rx = cx + Math.cos(a) * R * 0.9, ry = cy + Math.sin(a) * R * 0.9, s = R * 0.07, g = [[rx - s, ry - s]];
          for (let q = 0; q < 3; q++) g.push([rx + (rnd() - 0.5) * s * 2.4, ry + (rnd() - 0.5) * s * 2.4]);
          glowPts(x, g, '#ff6d80', 1.1, 5);
        }
      };
      for (let i = 0; i < 5; i++) sigil((i % 3 + 0.2 + rnd() * 0.6) * S / 3, (i * 0.37 + rnd() * 0.25) % 1 * S, 40 + rnd() * 34);
      sparkle(x, 340, 'rgba(255,90,110,0.85)', 1.3);
    },
    // сверхновая: спиральные галактики с раскалённым ядром, ударная волна, туманности и звёзды
    supernova: (x) => {
      vgrad(x, ['#02010a', '#0a0420', '#05021a', '#0c0626', '#02010a'], 0, 0, S, S);
      for (let i = 0; i < 26; i++) softBlob(x, rnd() * S, rnd() * S, 40 + rnd() * 110, pick(['rgba(200,40,180,0.22)', 'rgba(60,80,255,0.24)', 'rgba(20,200,255,0.14)', 'rgba(255,120,60,0.12)']));
      sparkle(x, 700, 'rgba(255,255,255,0.75)', 1.1);
      x.globalCompositeOperation = 'lighter';
      const galaxy = (cx, cy, R, arms, n) => {
        const a0 = rnd() * 6.28, dir = rnd() < 0.5 ? 1 : -1;
        for (let i = 0; i < n; i++) {
          const t = rnd(), arm = i % arms, a = a0 + dir * (arm / arms * Math.PI * 2 + t * 4.2) + (rnd() - 0.5) * 0.5 * (1 - t * 0.5), rr = R * (0.06 + t * 0.94) * (0.85 + rnd() * 0.3);
          const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr * 0.86;
          const hot = 1 - t, col = hot > 0.75 ? `rgba(255,${235 + rnd() * 20 | 0},${190 + rnd() * 60 | 0},0.9)` : hot > 0.45 ? `rgba(255,${120 + rnd() * 80 | 0},${150 + rnd() * 80 | 0},0.7)` : `rgba(${90 + rnd() * 80 | 0},${110 + rnd() * 80 | 0},255,0.6)`;
          const sz = 0.8 + rnd() * 2.2 * (0.5 + hot);
          tileB(x, [[px - 3, py - 3], [px + 3, py + 3]], () => { x.fillStyle = col; x.fillRect(px, py, sz, sz); });
        }
        tileB(x, [[cx - R * 0.5, cy - R * 0.5], [cx + R * 0.5, cy + R * 0.5]], () => {
          const g = x.createRadialGradient(cx, cy, 0, cx, cy, R * 0.45); g.addColorStop(0, 'rgba(255,255,245,1)'); g.addColorStop(0.18, 'rgba(255,230,160,0.9)'); g.addColorStop(0.45, 'rgba(255,90,170,0.35)'); g.addColorStop(1, 'rgba(120,40,255,0)');
          x.fillStyle = g; x.fillRect(cx - R * 0.5, cy - R * 0.5, R, R);
        });
        const flare = [[cx - R * 0.55, cy], [cx + R * 0.55, cy]], flare2 = [[cx, cy - R * 0.4], [cx, cy + R * 0.4]];
        glowPts(x, flare, 'rgba(255,240,255,0.7)', 1.2, 10); glowPts(x, flare2, 'rgba(255,240,255,0.6)', 1, 10);
      };
      galaxy(S * 0.3, S * 0.32, 150, 3, 2400); galaxy(S * 0.8, S * 0.76, 120, 2, 1700); galaxy(S * 0.8, S * 0.2, 60, 2, 500); galaxy(S * 0.22, S * 0.82, 70, 3, 600);
      x.globalCompositeOperation = 'source-over';
      const ring = (cx, cy, R) => { const pts = []; for (let k = 0; k <= 72; k++) { const a = k / 72 * Math.PI * 2, rr = R * (1 + Math.sin(k / 72 * Math.PI * 12) * 0.012); pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.86]); }
        glowPts(x, pts, 'rgba(60,160,255,0.35)', 9, 18); glowPts(x, pts, 'rgba(140,235,255,0.85)', 1.8, 8); };
      ring(S * 0.3, S * 0.32, 175); ring(S * 0.8, S * 0.76, 140);
      for (let i = 0; i < 14; i++) { const px = rnd() * S, py = rnd() * S; softBlob(x, px, py, 7, 'rgba(255,255,255,0.95)'); glowPts(x, [[px - 10, py], [px + 10, py]], 'rgba(255,255,255,0.7)', 1, 4); glowPts(x, [[px, py - 10], [px, py + 10]], 'rgba(255,255,255,0.7)', 1, 4); }
    },
    // левиафан: чешуя морского змея с биолюминесцентной каймой, каустика, щупальца и планктон в тёмной воде
    leviathan: (x) => {
      vgrad(x, ['#010a10', '#032430', '#021820', '#04283a', '#010a10']);
      const r = 16, glow = (px, py) => 0.5 + 0.5 * Math.sin((px / S * 2 + py / S) * Math.PI * 2);
      for (let row = -1; row <= S / r + 1; row++) for (let col = -1; col <= S / (r * 2) + 1; col++) {
        const cx = col * r * 2 + (row % 2 ? r : 0), cy = row * r, k = glow(cx, cy);
        const g = x.createRadialGradient(cx, cy - 4, 1, cx, cy, r);
        g.addColorStop(0, `rgba(${20 + k * 30 | 0},${90 + k * 60 | 0},${110 + k * 50 | 0},0.95)`); g.addColorStop(0.75, 'rgba(4,40,56,0.95)'); g.addColorStop(1, 'rgba(1,14,22,0.95)');
        x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI); x.fill();
        x.strokeStyle = `rgba(80,255,${210 + k * 45 | 0},${0.15 + k * k * 0.75})`; x.lineWidth = 1.2 + k * 1.2; x.beginPath(); x.arc(cx, cy, r - 1, 0.15, Math.PI - 0.15); x.stroke();
      }
      x.strokeStyle = 'rgba(150,255,240,0.12)'; x.lineWidth = 1.2;
      for (let i = 0; i < 18; i++) { const y = rnd() * S, ph = rnd() * 6, amp = 8 + rnd() * 10; tile(x, () => { x.beginPath(); for (let k = 0; k <= 32; k++) x.lineTo(k * S / 32, y + Math.sin(k * 0.6 + ph) * amp + Math.sin(k * 1.7 + ph) * 4); x.stroke(); }); }
      for (let i = 0; i < 9; i++) { let px = rnd() * S, py = rnd() * S, a = rnd() * 6.28; const pts = [[px, py]]; for (let k = 0; k < 18; k++) { a += Math.sin(k * 0.6 + i) * 0.35; px += Math.cos(a) * 9; py += Math.sin(a) * 9; pts.push([px, py]); } glowPts(x, pts, i % 3 ? 'rgba(80,255,220,0.85)' : 'rgba(170,110,255,0.85)', 1.4, 10); }
      for (let i = 0; i < 70; i++) { const px = rnd() * S, py = rnd() * S; softBlob(x, px, py, 5 + rnd() * 8, rnd() < 0.7 ? 'rgba(90,255,230,0.55)' : 'rgba(180,120,255,0.5)'); }
      sparkle(x, 420, 'rgba(170,255,245,0.85)', 1.3);
    },
    // ---------- перчатки ----------
    leather: (x) => {
      x.fillStyle = '#c4c4c4'; x.fillRect(0, 0, S, S);
      for (let i = 0; i < 12000; i++) { const v = 160 + rnd() * 90 | 0; x.fillStyle = `rgb(${v},${v},${v})`; x.fillRect(rnd() * S, rnd() * S, 2, 2); }
      x.strokeStyle = 'rgba(70,70,70,0.4)'; x.lineWidth = 1.4;
      for (let i = 0; i < 46; i++) { const y = rnd() * S; x.beginPath(); x.moveTo(0, y); x.bezierCurveTo(S * 0.3, y + (rnd() - 0.5) * 30, S * 0.7, y - (rnd() - 0.5) * 30, S, y); x.stroke(); }
      x.strokeStyle = 'rgba(240,240,240,0.55)'; x.lineWidth = 2.2; x.setLineDash([7, 6]);
      x.beginPath(); x.moveTo(0, S * 0.5); x.lineTo(S, S * 0.5); x.stroke(); x.setLineDash([]);
      grain(x, 10);
    },
    driver: (x) => {
      P.leather(x);
      x.fillStyle = 'rgba(25,18,12,0.85)';
      for (let y = 10; y < S; y += 20) for (let px = 10; px < S; px += 20) { x.beginPath(); x.arc(px + ((y / 20) % 2) * 10, y, 3.2, 0, 7); x.fill(); }
    },
    knit: (x) => {
      x.fillStyle = '#d9d9d9'; x.fillRect(0, 0, S, S);
      for (let y = 0; y < S; y += 9) for (let px = 0; px < S; px += 9) {
        const d = ((px / 9 + y / 9) % 2) | 0;
        x.fillStyle = d ? 'rgba(0,0,0,0.2)' : 'rgba(255,255,255,0.16)';
        x.beginPath(); x.ellipse(px + 4.5, y + 4.5, 4.6, 2.5, d ? 0.75 : -0.75, 0, 7); x.fill();
      }
      grain(x, 8);
    },
    wrap: (x) => {
      x.fillStyle = '#ece6d9'; x.fillRect(0, 0, S, S);
      x.strokeStyle = 'rgba(120,110,95,0.3)'; x.lineWidth = 1;
      for (let y = 0; y < S; y += 4) { x.beginPath(); x.moveTo(0, y); x.lineTo(S, y + 3); x.stroke(); }
      for (let y = 26; y < S; y += 72) { x.fillStyle = 'rgba(90,80,70,0.55)'; x.fillRect(0, y, S, 4); x.fillStyle = 'rgba(255,255,255,0.6)'; x.fillRect(0, y + 4, S, 3); }
      for (let i = 0; i < 26; i++) softBlob(x, rnd() * S, rnd() * S, 20 + rnd() * 50, 'rgba(120,100,70,0.16)');
      grain(x, 10);
    },
    waves: (x) => {
      x.fillStyle = '#123a73'; x.fillRect(0, 0, S, S);
      const r = 32;
      for (let row = 0; row < S / (r * 0.5) + 2; row++) for (let col = -1; col < S / (r * 2) + 2; col++) {
        const cx = col * r * 2 + (row % 2 ? r : 0), cy = row * r * 0.5;
        for (let k = 4; k >= 1; k--) { x.fillStyle = k % 2 ? '#e9f2ff' : '#1d55a0'; x.beginPath(); x.arc(cx, cy, r * k / 4, Math.PI, 0); x.fill(); }
      }
    }
  };

  // износ: царапины и сколы краски
  function addWear(x, level) {
    if (!level) return;
    const n = level === 1 ? 70 : 220;
    for (let i = 0; i < n; i++) {
      x.strokeStyle = `rgba(${150 + rnd() * 60},${150 + rnd() * 60},${150 + rnd() * 60},${0.25 + rnd() * 0.4})`;
      x.lineWidth = 0.6 + rnd() * 1.2;
      const px = rnd() * S, py = rnd() * S, a = rnd() * Math.PI, l = 6 + rnd() * 30;
      x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke();
    }
    if (level === 2) for (let i = 0; i < 40; i++) camoBlob(x, rnd() * S, rnd() * S, 3 + rnd() * 10, `rgba(${110 + rnd() * 40},${110 + rnd() * 40},${115 + rnd() * 40},0.85)`);
  }

  const texCache = {};
  G.skinTex = (p, wear) => {
    const key = p + '|' + (wear || 0);
    if (texCache[key]) return texCache[key];
    const c = cv(S), x = c.getContext('2d');
    seed = 1 + [...p].reduce((a, ch) => a * 31 + ch.charCodeAt(0), 7) % 100000;
    (P[p] || P.f_metal)(x);
    addWear(x, wear || 0);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = G.maxAniso || 1;
    texCache[key] = t;
    return t;
  };

  // ---------- карта окружения для отражений ----------
  G.pbrMats = [];
  G.makeEnv = (renderer, env) => {
    const c = cv(512, 256), x = c.getContext('2d');
    const sky = new THREE.Color(env.skyTop).lerp(new THREE.Color('#9aa4b0'), 0.45).getStyle();
    const hor = new THREE.Color(env.skyHor).lerp(new THREE.Color('#f2f2f2'), 0.5).getStyle();
    const g = x.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, sky); g.addColorStop(0.44, hor); g.addColorStop(0.5, '#d8d8d8'); g.addColorStop(0.54, '#7a7a7a'); g.addColorStop(0.75, '#4a4a4a'); g.addColorStop(1, '#2a2a2a');
    x.fillStyle = g; x.fillRect(0, 0, 512, 256);
    // студийные полосы: длинные блики вдоль плоских граней оружия
    x.fillStyle = 'rgba(255,255,255,0.55)'; x.fillRect(0, 104, 512, 7);
    x.fillStyle = 'rgba(255,255,255,0.3)'; x.fillRect(0, 150, 512, 10);
    x.fillStyle = 'rgba(255,244,225,0.7)'; x.fillRect(120, 186, 90, 18); x.fillRect(300, 176, 60, 26);
    // солнце и «софтбоксы» — чтобы металл красиво бликовал
    const sg = x.createRadialGradient(150, 80, 0, 150, 80, 40); sg.addColorStop(0, 'rgba(255,255,245,1)'); sg.addColorStop(1, 'rgba(255,250,230,0)');
    x.fillStyle = sg; x.fillRect(100, 30, 100, 100);
    x.fillStyle = 'rgba(255,255,255,0.85)'; x.fillRect(330, 46, 80, 30); x.fillRect(36, 56, 30, 54); x.fillRect(440, 70, 22, 40);
    x.fillStyle = 'rgba(255,255,255,0.35)'; x.fillRect(240, 18, 140, 12);
    const tex = new THREE.CanvasTexture(c);
    tex.mapping = THREE.EquirectangularReflectionMapping;
    if (!G._pmrem) G._pmrem = new THREE.PMREMGenerator(renderer);
    const rt = G._pmrem.fromEquirectangular(tex);
    tex.dispose();
    if (G.envRT) G.envRT.dispose();
    G.envRT = rt; G.envTex = rt.texture;
    for (const m of G.pbrMats) { m.envMap = G.envTex; m.needsUpdate = true; }
  };
  const pbr = (o) => { const m = new THREE.MeshStandardMaterial(Object.assign({ envMap: G.envTex || null }, o)); G.pbrMats.push(m); return m; };
  // мягкая подсветка контура (френель) — плоские грани оружия перестают сливаться
  G.rimU = { value: typeof THREE !== 'undefined' ? new THREE.Color('#e4ebf5') : null }; // 2.3: файл грузится и без THREE (сервер, G.HEADLESS)
  G.rimify = (m, k) => {
    if (!m || m.userData.rim) return m;
    m.userData.rim = k;
    const prev = m.onBeforeCompile, prevKey = m.customProgramCacheKey;
    m.onBeforeCompile = function (sh, r) {
      if (prev) prev.call(this, sh, r);
      sh.uniforms.uRimK = { value: k }; sh.uniforms.uRimC = G.rimU;
      sh.fragmentShader = 'uniform float uRimK; uniform vec3 uRimC;\n' + sh.fragmentShader.replace('#include <output_fragment>',
        '{ vec3 rvd = normalize(vViewPosition); float rfr = 1.0 - clamp(abs(dot(normal, rvd)), 0.0, 1.0);\n  outgoingLight += uRimC * (rfr * rfr * rfr * uRimK) * (0.35 + 0.65 * diffuseColor.rgb + 0.25); }\n#include <output_fragment>');
    };
    const pk = prevKey && prevKey !== THREE.Material.prototype.customProgramCacheKey ? prevKey.call(m) : '';
    m.customProgramCacheKey = () => pk + '|rim' + k;
    m.needsUpdate = true;
    return m;
  };
  // физически корректные материалы с отражениями — на «высоком», а в меню (витрина) всегда: там это ничего не стоит
  G.pbrOn = () => G.settings.quality === 'high' || !!(G.game && G.game.state === 'menu');

  // ---------- каталог ----------
  // 2.3: редкости как в Standoff 2. Номера 1..6 прежние (6 — ★ ножи, проверки `r === 6` по всему коду остаются верными),
  // 7 — новая «Аркана». Порядок показа (от простого к ценному) — G.RAR_ORDER: … Легендарный → Аркана → Золото.
  // Перчатки хранят в r свою «ступень» (вес внутри золотого слота), а показываются как Золото — см. G.rarOf / G.rarInfo
  G.RARITY = [null,
    { n: 'Обычный', c: '#9aa3ab' }, { n: 'Необычный', c: '#62b6f0' }, { n: 'Редкий', c: '#3f66f2' },
    { n: 'Эпический', c: '#9b4dff' }, { n: 'Легендарный', c: '#ee3ec6' }, { n: 'Золото', c: '#ffc23a', star: true }, { n: 'Аркана', c: '#ff2b45' }];
  G.RAR_ORDER = [1, 2, 3, 4, 5, 7, 6];
  G.RARITY.forEach((x, i) => { if (x) { x.id = i; x.o = G.RAR_ORDER.indexOf(i); } });
  G.RAR = { COMMON: 1, UNCOMMON: 2, RARE: 3, EPIC: 4, LEGEND: 5, GOLD: 6, ARCANE: 7 };
  // редкость для показа: ножи и перчатки — Золото (6), остальное — r
  G.rarOf = (id) => { const s = typeof id === 'string' ? SK[id] : id; return !s ? 1 : s.r === 6 || s.w === 'gloves' ? 6 : s.r; };
  G.rarInfo = (id) => G.RARITY[G.rarOf(id)] || G.RARITY[1];
  G.rarRank = (r) => G.RAR_ORDER.indexOf(r); // для сортировки: чем больше, тем ценнее
  G.WEAR = ['Новый', 'Боевой', 'Потёртый'];
  G.SELL = [0, 15, 30, 60, 120, 250, 800, 450];
  // перчатки дороже: кейс стоит 1750
  const SELL_GL = [0, 350, 600, 1000, 1900, 4200];
  G.sellPrice = (id) => { const s = SK[id]; return s.w === 'gloves' ? SELL_GL[s.r] : G.SELL[s.r]; };
  // [узор, металличность, шероховатость, свечение, масштаб UV, рельеф, (сила отражений окружения)]
  const LOOK = {
    f_metal: [0.8, 0.38], f_black: [0.45, 0.45], f_poly: [0.05, 0.72], f_wood: [0, 0.55], f_olive: [0.1, 0.62], f_sage: [0.06, 0.66, 0, 0, 0.004, 0, 0.45], f_steel: [1, 0.2],
    f_polyBk: [0.02, 0.78, 0, 0, 0.006, 0, 0.42], f_polySm: [0.08, 0.55, 0, 0, 0, 0, 0.55], f_nitride: [0.55, 0.42, 0, 0, 0, 0, 0.75], f_dsteel: [0.88, 0.3, 0, 0, 0, 0, 1.05], f_dbarrel: [0.88, 0.36, 0, 0, 0, 0, 1.0],
    desert: [0.15, 0.6], forest: [0.15, 0.6], snowcamo: [0.15, 0.55], urban: [0.15, 0.6], digital: [0.2, 0.55], night: [0.45, 0.4],
    carbon: [0.55, 0.28, 0, 0, 0.015], tiger: [0.25, 0.42], ocean: [0.45, 0.25], sunset: [0.55, 0.22], galaxy: [0.4, 0.3, 0.12],
    gold: [1, 0.22, 0, 0, 0.012], ice: [0.4, 0.15], frost: [0.45, 0.18], aurora: [0.3, 0.3, 0.25], toxic: [0.2, 0.45, 0.12],
    neon: [0.25, 0.35, 0.9], cyber: [0.3, 0.32, 0.55], marble: [0.05, 0.18], flame: [0.3, 0.32, 0.35], rust: [0.4, 0.75, 0, 0, 0.02],
    ruby: [0.85, 0.16, 0.06], sapphire: [0.85, 0.16, 0.06], emerald: [0.85, 0.16, 0.06], pearl: [0.6, 0.18], chrome: [1, 0.06],
    temper: [0.95, 0.25], damascus: [0.95, 0.28, 0, 0, 0.01], magma: [0.3, 0.45, 0.8], hex: [0.4, 0.35, 0.35], circuit: [0.35, 0.4, 0.15],
    graffiti: [0.1, 0.55], lightning: [0.35, 0.3, 0.6], scales: [0.6, 0.3, 0, 0, 0.012], waves: [0.3, 0.35],
    goldEngrave: [1, 0.15, 0, 0, 0.014, 1], goldLeaf: [1, 0.2, 0, 0, 0.01, 1], blackGold: [0.85, 0.12, 0, 0, 0.004, 1], roseGold: [1, 0.17, 0, 0, 0.006, 0.8],
    royal: [0.7, 0.18, 0, 0, 0.008, 0.85], diamond: [0.9, 0.05, 0.06, 0, 0.004, 1.3], dragon: [0.85, 0.2, 0.05, 0, 0.012, 0.9], goldCarbon: [0.6, 0.22, 0, 0, 0.012, 0.6],
    leather: [0.04, 0.62, 0, 0, 0.012], driver: [0.06, 0.5, 0, 0, 0.012], knit: [0, 0.88, 0, 0, 0.02], wrap: [0, 0.92, 0, 0, 0.012],
    sakura: [0.25, 0.28, 0.04, 0, 0.004, 0.45], koi: [0.35, 0.22, 0.05, 0, 0.004, 0.4], emperor: [0.75, 0.14, 0.04, 0, 0.006, 1.15],
    // 2.3 Аркана: светящийся узор (emissive), «течение» энергии и мерцающие хлопья в шейдере (addArcane), блеск окружения
    plasma: [0.55, 0.2, 1.0, 0, 0.004, 1.0, 1.1], holo: [0.72, 0.12, 0.42, 0, 0.003, 1.2, 1.1], phoenix: [0.6, 0.2, 0.85, 0, 0.006, 1.0, 1.0],
    bloodmoon: [0.65, 0.18, 0.95, 0, 0.004, 1.0, 1.05], supernova: [0.45, 0.2, 0.95, 0, 0.003, 1.0, 1.0], leviathan: [0.6, 0.2, 0.9, 0, 0.008, 1.0, 1.05]
  };
  G.LOOK = LOOK;
  LOOK.gold[5] = 0.8; LOOK.chrome[5] = 0.5;
  const SHINE_COL = { roseGold: '#ffd0c0', diamond: '#e6f6ff', chrome: '#f0f6ff', sakura: '#ffd6e6', koi: '#d6f6ff', emperor: '#ffe2a0',
    plasma: '#7ff6ff', holo: '#ffffff', phoenix: '#ffb347', bloodmoon: '#ff3550', supernova: '#ff9cf0', leviathan: '#5ff8e0' };
  // узоры Арканы — свой шейдер (бегущие волны свечения + хлопья), остальное как у обычных скинов
  const ARC_P = { plasma: 1, holo: 1, phoenix: 1, bloodmoon: 1, supernova: 1, leviathan: 1 };
  const FACTORY = {
    ar: { a: 'f_metal', b: 'f_wood' }, ar2: { a: 'f_black', b: 'f_poly' }, m4s: { a: 'f_black', b: 'f_poly' }, smg: { a: 'f_polySm', b: 'f_polyBk' },
    sniper: { a: 'f_olive', b: 'f_olive' }, shotgun: { a: 'f_metal', b: 'f_wood' }, pistol: { a: 'f_nitride', b: 'f_polyBk' }, usp: { a: 'f_nitride', b: 'f_polyBk' },
    magnum: { a: 'f_dbarrel', b: 'f_dsteel' }, galil: { a: 'f_metal', b: 'f_polyBk' }, famas: { a: 'f_sage', b: 'f_polyBk' }, ssg: { a: 'f_polyBk', b: 'f_polySm' },
    fiveseven: { a: 'f_black', b: 'f_polySm' }, tec9: { a: 'f_nitride', b: 'f_polyBk' }, knife: { a: 'f_steel', b: 'f_black' }, m9: { a: 'f_steel', b: 'f_black' },
    butterfly: { a: 'f_steel', b: 'f_metal' }, karambit: { a: 'f_steel', b: 'f_black' }, tanto: { a: 'f_steel', b: 'f_black' }
  };
  // [id, оружие, название, редкость, узор, масштаб UV]
  const RAW = [
    // Гавань
    ['pistol_rust', 'pistol', 'Ржавчина', 1, 'rust'], ['smg_night', 'smg', 'Ночь', 1, 'night'], ['shotgun_forest', 'shotgun', 'Лес', 1, 'forest'],
    ['ar2_carbon', 'ar2', 'Карбон', 2, 'carbon'], ['sniper_ocean', 'sniper', 'Океан', 2, 'ocean', 2], ['magnum_digital', 'magnum', 'Цифра', 2, 'digital'],
    ['ar_tiger', 'ar', 'Тигр', 3, 'tiger'], ['smg_toxic', 'smg', 'Токсин', 3, 'toxic'], ['shotgun_marble', 'shotgun', 'Мрамор', 3, 'marble', 2],
    ['ar2_neon', 'ar2', 'Неон', 4, 'neon', 2.5], ['sniper_sunset', 'sniper', 'Закат', 4, 'sunset', 1.2], ['ar_flame', 'ar', 'Пламя', 5, 'flame', 1.8],
    // Пустыня
    ['ar_desert', 'ar', 'Барханы', 1, 'desert'], ['magnum_rust', 'magnum', 'Ржавчина', 1, 'rust'], ['sniper_forest', 'sniper', 'Лес', 1, 'forest'],
    ['pistol_carbon', 'pistol', 'Карбон', 2, 'carbon'], ['shotgun_digital', 'shotgun', 'Цифра', 2, 'digital'], ['smg_ocean', 'smg', 'Океан', 2, 'ocean', 2],
    ['ar2_tiger', 'ar2', 'Тигр', 3, 'tiger'], ['sniper_marble', 'sniper', 'Мрамор', 3, 'marble', 2], ['pistol_toxic', 'pistol', 'Токсин', 3, 'toxic'],
    ['ar_galaxy', 'ar', 'Галактика', 4, 'galaxy', 1.6], ['magnum_neon', 'magnum', 'Неон', 4, 'neon', 2.5],
    ['ar2_magma', 'ar2', 'Магма', 5, 'magma', 2], ['magnum_gold', 'magnum', 'Золото', 5, 'gold', 2],
    // Неон
    ['pistol_circuit', 'pistol', 'Плата', 1, 'circuit', 2.5], ['ar_urban', 'ar', 'Город', 1, 'urban'], ['shotgun_hex', 'shotgun', 'Улей', 1, 'hex', 2.5],
    ['smg_graffiti', 'smg', 'Граффити', 2, 'graffiti', 2], ['magnum_circuit', 'magnum', 'Плата', 2, 'circuit', 2.5], ['sniper_hex', 'sniper', 'Улей', 2, 'hex', 2.5],
    ['ar2_lightning', 'ar2', 'Разряд', 3, 'lightning', 1.8], ['pistol_neon', 'pistol', 'Неон', 3, 'neon', 3], ['shotgun_temper', 'shotgun', 'Закалка', 3, 'temper', 2],
    ['ar_cyber', 'ar', 'Кибер', 4, 'cyber', 1.6], ['smg_lightning', 'smg', 'Разряд', 4, 'lightning', 1.8],
    ['sniper_cyber', 'sniper', 'Кибер', 5, 'cyber', 1.4], ['ar2_graffiti', 'ar2', 'Граффити', 5, 'graffiti', 1.6],
    // Арктика
    ['ar_snow', 'ar', 'Снег', 1, 'snowcamo'], ['pistol_snow', 'pistol', 'Снег', 1, 'snowcamo'], ['smg_frost', 'smg', 'Иней', 1, 'frost', 2],
    ['shotgun_snow', 'shotgun', 'Снег', 2, 'snowcamo'], ['ar2_frost', 'ar2', 'Иней', 2, 'frost', 2], ['magnum_pearl', 'magnum', 'Перламутр', 2, 'pearl', 1.5],
    ['sniper_aurora', 'sniper', 'Сияние', 3, 'aurora', 1.4], ['ar_scales', 'ar', 'Чешуя', 3, 'scales', 2.5], ['pistol_chrome', 'pistol', 'Хром', 3, 'chrome', 2],
    ['ar2_aurora', 'ar2', 'Сияние', 4, 'aurora', 1.4], ['shotgun_waves', 'shotgun', 'Волны', 4, 'waves', 2.5],
    ['sniper_chrome', 'sniper', 'Хром', 5, 'chrome', 1.5], ['ar_aurora', 'ar', 'Сияние', 5, 'aurora', 1.4],
    // Корона (золото)
    ['pistol_goldcarbon', 'pistol', 'Золотая нить', 1, 'goldCarbon', 2.5], ['smg_rose', 'smg', 'Розовое золото', 1, 'roseGold', 2], ['shotgun_goldleaf', 'shotgun', 'Сусальное золото', 1, 'goldLeaf', 2],
    ['usp_royal', 'usp', 'Корона', 2, 'royal', 3], ['ar_blackgold', 'ar', 'Чёрное золото', 2, 'blackGold', 1.6], ['sniper_goldcarbon', 'sniper', 'Золотая нить', 2, 'goldCarbon', 2],
    ['ar2_engrave', 'ar2', 'Гравировка', 3, 'goldEngrave', 2], ['magnum_diamond', 'magnum', 'Бриллиант', 3, 'diamond', 2.5], ['usp_goldleaf', 'usp', 'Сусальное золото', 3, 'goldLeaf', 2.5],
    ['sniper_dragon', 'sniper', 'Золотой дракон', 4, 'dragon', 2], ['ar_royal', 'ar', 'Корона', 4, 'royal', 2],
    ['ar2_diamond', 'ar2', 'Бриллиант', 5, 'diamond', 2], ['ar_engrave', 'ar', 'Гравировка', 5, 'goldEngrave', 1.8], ['usp_engrave', 'usp', 'Гравировка', 4, 'goldEngrave', 3]
  ];
  // M4A1-S: по кейсам — [id, оружие, название, редкость, узор, масштаб UV, кейс]
  const M4S = [
    ['m4s_temper', 'm4s', 'Закалка', 3, 'temper', 2, 'harbor'], ['m4s_desert', 'm4s', 'Барханы', 1, 'desert', 3, 'desert'],
    ['m4s_galaxy', 'm4s', 'Галактика', 5, 'galaxy', 1.6, 'desert'], ['m4s_cyber', 'm4s', 'Кибер', 4, 'cyber', 1.6, 'neon'],
    ['m4s_ice', 'm4s', 'Лёд', 2, 'ice', 2, 'arctic'], ['m4s_blackgold', 'm4s', 'Чёрное золото', 4, 'blackGold', 2, 'royal']
  ];
  // 11.3: кейс «Prodigy» — 5 новых M4A1-S и новые скины для других стволов
  const PRODIGY = [
    ['m4s_urban', 'm4s', 'Город', 1, 'urban', 3], ['usp_frost', 'usp', 'Иней', 1, 'frost', 2], ['smg_hex', 'smg', 'Улей', 1, 'hex', 2.5], ['shotgun_urban', 'shotgun', 'Город', 1, 'urban'],
    ['m4s_waves', 'm4s', 'Волны', 2, 'waves', 2.5], ['pistol_lightning', 'pistol', 'Разряд', 2, 'lightning', 2], ['sniper_graffiti', 'sniper', 'Граффити', 2, 'graffiti', 1.8],
    ['m4s_neon', 'm4s', 'Неон', 3, 'neon', 2.5], ['magnum_scales', 'magnum', 'Чешуя', 3, 'scales', 2.5], ['ar2_hex', 'ar2', 'Улей', 3, 'hex', 2.5],
    ['m4s_flame', 'm4s', 'Пламя', 4, 'flame', 1.8], ['ar_magma', 'ar', 'Магма', 4, 'magma', 2],
    ['m4s_aurora', 'm4s', 'Сияние', 5, 'aurora', 1.4]
  ];
  // 11.9: кейс «Арсенал» — 13 скинов для новых стволов: Galil AR, FAMAS, SSG 08, Five-SeveN, Tec-9
  const ARSENAL = [
    ['galil_desert', 'galil', 'Барханы', 1, 'desert', 3], ['famas_forest', 'famas', 'Лес', 1, 'forest', 3], ['ssg_urban', 'ssg', 'Город', 1, 'urban', 3], ['fiveseven_snow', 'fiveseven', 'Снег', 1, 'snowcamo', 3],
    ['famas_frost', 'famas', 'Иней', 2, 'frost', 2], ['ssg_sunset', 'ssg', 'Закат', 2, 'sunset', 1.2], ['tec9_graffiti', 'tec9', 'Граффити', 2, 'graffiti', 1.8],
    ['galil_toxic', 'galil', 'Токсин', 3, 'toxic', 2], ['fiveseven_neon', 'fiveseven', 'Неон', 3, 'neon', 3], ['tec9_scales', 'tec9', 'Чешуя', 3, 'scales', 2.5],
    ['galil_flame', 'galil', 'Пламя', 4, 'flame', 1.8], ['famas_cyber', 'famas', 'Кибер', 4, 'cyber', 1.6],
    ['ssg_aurora', 'ssg', 'Сияние', 5, 'aurora', 1.4]
  ];
  // новые отделки ножей — только в кейсе «Prodigy» (и на танто, которого раньше в кейсах не было)
  const NEW_KF = [['flame', 'Пламя', 'flame', 1.6], ['neon', 'Неон', 'neon', 2.5], ['lightning', 'Разряд', 'lightning', 1.8], ['waves', 'Волны', 'waves', 2]];
  const GOLD_FIN = [['engrave', 'Гравировка', 'goldEngrave', 2.5], ['goldleaf', 'Сусальное золото', 'goldLeaf', 2.5], ['blackgold', 'Чёрное золото', 'blackGold', 2],
    ['rosegold', 'Розовое золото', 'roseGold', 2.5], ['diamond', 'Бриллиант', 'diamond', 2.5], ['dragon', 'Золотой дракон', 'dragon', 2.5]];
  const KNIFE_FIN = [['vanilla', 'Ванильный', 'f_steel'], ['sunset', 'Закат', 'sunset', 1.3], ['ocean', 'Океан', 'ocean'], ['galaxy', 'Галактика', 'galaxy', 1.6],
    ['damascus', 'Дамаск', 'damascus'], ['gold', 'Золото', 'gold'], ['ruby', 'Рубин', 'ruby', 1.3], ['sapphire', 'Сапфир', 'sapphire', 1.3], ['emerald', 'Изумруд', 'emerald', 1.3],
    ['tiger', 'Тигр', 'tiger'], ['carbon', 'Карбон', 'carbon'], ['ice', 'Лёд', 'ice'], ['magma', 'Магма', 'magma'], ['marble', 'Мрамор', 'marble'],
    ['temper', 'Закалка', 'temper'], ['chrome', 'Хром', 'chrome'], ['pearl', 'Перламутр', 'pearl', 1.4], ['aurora', 'Сияние', 'aurora', 1.4], ['cyber', 'Кибер', 'cyber', 1.6]];
  // 2.3: шесть скинов редкости «Аркана» — по два в каждом кейсе
  const ARCANA = [
    ['m4s_plasma', 'm4s', 'Плазма', 7, 'plasma', 1.5], ['magnum_holo', 'magnum', 'Голограмма', 7, 'holo', 1.6],
    ['ar_phoenix', 'ar', 'Феникс', 7, 'phoenix', 1.4], ['pistol_bloodmoon', 'pistol', 'Кровавая луна', 7, 'bloodmoon', 2.4],
    ['sniper_supernova', 'sniper', 'Сверхновая', 7, 'supernova', 1.6], ['ar2_leviathan', 'ar2', 'Левиафан', 7, 'leviathan', 1.5]
  ];
  const SK = G.SKINS = {};
  for (const r of RAW.concat(M4S, PRODIGY, ARSENAL, ARCANA)) SK[r[0]] = { id: r[0], w: r[1], name: r[2], r: r[3], p: r[4], k: r[5] || 3 };
  for (const r of ARCANA) SK[r[0]].arc = true;
  // перчатки: [id, название, редкость, узор, палитра (тыл, накладки, пальцы, кончики, манжета, ремешок), масштаб UV]
  const WH = ['#ffffff', '#f2f2f2', '#f6f6f6', '#dedede', '#2a2d31', '#3d434a'];
  const GLOVES = [
    ['gl_tact_sand', 'Тактические | Песок', 1, 'leather', ['#a89064', '#7d6d4e', '#9d8760', '#8c7a55', '#5a4e3a', '#6e624b'], 22],
    ['gl_tact_olive', 'Тактические | Олива', 1, 'leather', ['#5f7046', '#404d31', '#5a6a42', '#4c5a39', '#2f3a26', '#414f33'], 22],
    ['gl_wrap_white', 'Бинты | Белые', 1, 'wrap', ['#ffffff', '#ffffff', '#f8f8f8', '#ececec', '#e0e0e0', '#cfcfcf'], 20],
    ['gl_camo_digital', 'Тактические | Цифра', 1, 'digital', ['#ffffff', '#cfcfcf', '#f4f4f4', '#d6d6d6', '#2a2d31', '#3d434a'], 20],
    ['gl_wrap_black', 'Бинты | Чёрные', 2, 'wrap', ['#33343a', '#33343a', '#303136', '#2a2b30', '#26272c', '#202126'], 20],
    ['gl_driver_brown', 'Водительские | Коньяк', 2, 'driver', ['#9a6234', '#9a6234', '#8f5a30', '#7c4e2a', '#4a3020', '#5a3a26'], 22],
    ['gl_sport_red', 'Спортивные | Красный пульс', 2, 'knit', ['#e03434', '#ffffff', '#e03434', '#b82a2a', '#1e1e22', '#ffffff'], 24],
    ['gl_moto_carbon', 'Мотоперчатки | Карбон', 2, 'carbon', ['#ffffff', '#d0d0d0', '#ececec', '#c2c2c2', '#2a2d31', '#555b63'], 24],
    ['gl_sport_blue', 'Спортивные | Лазурь', 3, 'knit', ['#2c82e8', '#ffffff', '#2c82e8', '#2266c0', '#1e1e22', '#ffd040'], 24],
    ['gl_snake', 'Змеиная кожа', 3, 'scales', WH, 18],
    ['gl_tiger', 'Тигр', 3, 'tiger', WH, 18],
    ['gl_marble', 'Мрамор', 3, 'marble', WH, 18],
    ['gl_galaxy', 'Галактика', 4, 'galaxy', WH, 16],
    ['gl_hex_neon', 'Неоновый улей', 4, 'hex', WH, 20],
    ['gl_flame', 'Пламя', 4, 'flame', WH, 16],
    ['gl_gold', 'Золотые', 5, 'gold', WH, 18],
    ['gl_dragon', 'Золотой дракон', 5, 'dragon', WH, 16],
    ['gl_diamond', 'Бриллиант', 5, 'diamond', WH, 18]
  ];
  for (const g of GLOVES) SK[g[0]] = { id: g[0], w: 'gloves', name: g[1], r: g[2], p: g[3], gl: g[4], k: g[5] || 20, gold: ['gold', 'dragon', 'diamond'].includes(g[3]) };
  G.GLOVE_IDS = GLOVES.map(g => g[0]);
  // эксклюзивы пропуска «Цветение» — не выпадают из кейсов
  const BP_SKINS = [
    ['smg_koi', 'smg', 'Кои', 3, 'koi', 1.8], ['ar_sakura', 'ar', 'Ханами', 4, 'sakura', 1.6], ['usp_sakura', 'usp', 'Сакура', 4, 'sakura', 2.4],
    ['sniper_koi', 'sniper', 'Кои', 5, 'koi', 1.5], ['magnum_emperor', 'magnum', 'Император', 5, 'emperor', 2.4], ['ar2_sakura', 'ar2', 'Ханами', 5, 'sakura', 1.6],
    ['ar_emperor', 'ar', 'Император', 5, 'emperor', 1.6], ['shotgun_koi', 'shotgun', 'Кои', 4, 'koi', 1.8], ['pistol_sakura', 'pistol', 'Сакура', 3, 'sakura', 2.4],
    ['karambit_sakura', 'karambit', 'Ханами', 6, 'sakura', 1.4], ['butterfly_koi', 'butterfly', 'Кои', 6, 'koi', 1.4], ['m9_emperor', 'm9', 'Император', 6, 'emperor', 1.6],
    ['tanto_emperor', 'tanto', 'Император', 6, 'emperor', 1.5]
  ];
  for (const r of BP_SKINS) SK[r[0]] = { id: r[0], w: r[1], name: r[2], r: r[3], p: r[4], k: r[5] || 3, bp: true, gold: r[4] === 'emperor' };
  SK.gl_sakura = { id: 'gl_sakura', w: 'gloves', name: 'Сакура', r: 5, p: 'sakura', gl: ['#ffffff', '#f2c2d4', '#f6f6f6', '#e8b8c8', '#2a1a22', '#d23a6a'], k: 16, bp: true };
  SK.gl_emperor = { id: 'gl_emperor', w: 'gloves', name: 'Император', r: 5, p: 'emperor', gl: WH, k: 16, bp: true, gold: true };
  G.wName = (w) => w === 'gloves' ? 'Перчатки' : G.WEAPONS[w].name;
  for (const kn of ['m9', 'butterfly', 'karambit']) for (const f of KNIFE_FIN.concat(GOLD_FIN)) {
    SK[kn + '_' + f[0]] = { id: kn + '_' + f[0], w: kn, name: f[1], r: 6, p: f[2], k: f[3] || 3, goldFin: GOLD_FIN.includes(f), gold: GOLD_FIN.includes(f) || f[0] === 'gold' };
  }
  for (const kn of ['m9', 'butterfly', 'karambit', 'tanto']) for (const f of NEW_KF) {
    SK[kn + '_' + f[0]] = { id: kn + '_' + f[0], w: kn, name: f[1], r: 6, p: f[2], k: f[3] || 3, nf: true };
  }
  for (const k in SK) if ((LOOK[SK[k].p] || [])[5]) SK[k].shine = LOOK[SK[k].p][5];
  // ---------- 2.3: ровно три кейса по 100 монет ----------
  // в каждом: 2 необычных + 4 редких + 2 эпических + 2 легендарных + 2 арканы (скины оружия) и золотой слот (1,2 %):
  // «Prodigy» — перчатки, «Феникс» — бабочка или керамбит, «Бездна» — только штык-нож М9.
  // Скин оружия лежит не больше чем в одном кейсе, его редкость = редкость слота (несколько старых скинов поменяли редкость).
  // Предметы убранных кейсов у игроков остаются; бесплатные открытия и промокоды убранных кейсов идут через G.CASE_REMAP
  const goldKnives = (ws) => Object.keys(SK).filter(k => SK[k].r === 6 && !SK[k].bp && ws.includes(SK[k].w));
  const CASE_DEF = [
    { id: 'prodigy', name: 'Кейс «Prodigy»', color: '#ff5a1f', theme: 'Неон, плазма и энергия', goldLabel: 'перчатки', gloves: true, newsIcon: 'gloves',
      t: { 2: ['smg_graffiti', 'shotgun_hex'], 3: ['ar2_lightning', 'pistol_neon', 'fiveseven_neon', 'galil_toxic'], 4: ['m4s_cyber', 'ar2_neon'],
        5: ['sniper_cyber', 'ar_cyber'], 7: ['m4s_plasma', 'magnum_holo'] }, gold: () => G.GLOVE_IDS.slice() },
    { id: 'phoenix', name: 'Кейс «Феникс»', color: '#ff3b2a', theme: 'Огонь, хищники и золото', goldLabel: 'бабочка или керамбит', newsIcon: 'butterfly',
      t: { 2: ['ssg_sunset', 'magnum_rust'], 3: ['ar_tiger', 'ar2_tiger', 'usp_goldleaf', 'tec9_scales'], 4: ['m4s_flame', 'galil_flame'],
        5: ['ar_flame', 'sniper_dragon'], 7: ['ar_phoenix', 'pistol_bloodmoon'] }, gold: () => goldKnives(['butterfly', 'karambit']) },
    { id: 'abyss', name: 'Кейс «Бездна»', color: '#5b6cff', theme: 'Космос, лёд и глубина', goldLabel: 'штык-нож М9', newsIcon: 'm9',
      t: { 2: ['smg_ocean', 'usp_frost'], 3: ['sniper_aurora', 'pistol_chrome', 'm4s_waves', 'famas_frost'], 4: ['ar_galaxy', 'shotgun_waves'],
        5: ['m4s_galaxy', 'ar_aurora'], 7: ['sniper_supernova', 'ar2_leviathan'] }, gold: () => goldKnives(['m9']) }
  ];
  // шансы редкостей — одинаковые во всех кейсах (сумма 1); внутри редкости — поровну, в золотом слоте перчатки по весу ступени, ножи поровну
  G.TIER_P = { 2: 0.48, 3: 0.30, 4: 0.125, 5: 0.055, 7: 0.028, 6: 0.012 };
  const TIERS = [2, 3, 4, 5, 7]; // скины оружия, по возрастанию ценности; 6 — золотой слот
  const GLOVE_W = [0, 40, 30, 18, 8, 4]; // ступень перчаток (r 1..5): простые чаще, «золотые» реже
  G.CASES = CASE_DEF.map(d => {
    const tiers = {}, gold = d.gold().filter(id => SK[id]);
    for (const r of TIERS) tiers[r] = d.t[r].filter(id => SK[id]);
    for (const r of TIERS) for (const id of tiers[r]) SK[id].r = r; // редкость скина = редкость слота
    const items = [].concat(...TIERS.map(r => tiers[r]), gold);
    return { id: d.id, name: d.name, price: 100, color: d.color, theme: d.theme, items, tiers, gold, goldLabel: d.goldLabel, knifeLabel: d.goldLabel,
      gloves: !!d.gloves, newsIcon: d.newsIcon, isNew: d.id !== 'prodigy', newsSub: 'Новые редкости «Аркана» и «Золото» · ★ ' + d.goldLabel + ' · 100 монет' };
  });
  // убранные кейсы → текущие (бесплатные открытия в инвентаре, промокоды, старые награды пропуска, миграция облачного инвентаря)
  G.CASE_REMAP = { harbor: 'prodigy', desert: 'prodigy', neon: 'prodigy', arctic: 'prodigy', royal: 'prodigy', gloves: 'prodigy', arsenal: 'phoenix' };
  G.CASE_OLD_NAMES = { harbor: 'Гавань', desert: 'Пустыня', neon: 'Неон', arctic: 'Арктика', royal: 'Корона', gloves: 'Перчатки', arsenal: 'Арсенал' };
  G.caseId = (id) => G.CASE_REMAP[id] || id;
  G.caseOf = (id) => G.CASES.find(x => x.id === G.caseId(id)) || null;
  G.RARE_CHANCE = G.GOLD_CHANCE = G.TIER_P[6]; // золотой слот — ровно 1,2 % в каждом кейсе
  // предмет золотого слота (нож ★ или перчатки)
  G.isRare = G.isGold = (id) => { const s = typeof id === 'string' ? SK[id] : id; return !!s && (s.r === 6 || s.w === 'gloves'); };
  G.isArcane = (id) => { const s = typeof id === 'string' ? SK[id] : id; return !!s && s.r === 7; };
  // шансы кейса: [{ r, p, n (сколько предметов), gold? }] по возрастанию ценности: Необычный … Аркана, Золото; сумма 1
  G.caseOdds = (c) => {
    c = typeof c === 'string' ? G.caseOf(c) : c;
    return TIERS.map(r => ({ r, p: G.TIER_P[r], n: c.tiers[r].length })).concat([{ r: 6, p: G.TIER_P[6], n: c.gold.length, gold: true }]).filter(o => o.n);
  };
  G.knifeChance = (c) => (typeof c === 'string' ? G.caseOf(c) : c).gold.length ? G.TIER_P[6] : 0;
  // rnd — функция, возвращающая [0, 1) (сервер передаёт криптографический ГСЧ); без неё — Math.random
  const rf = (R) => { const v = +R(); return v >= 0 && v < 1 ? v : 0; };
  G.rollCase = (caseId, rnd) => {
    const c = G.caseOf(caseId) || G.CASES[0], R = typeof rnd === 'function' ? rnd : Math.random;
    const odds = G.caseOdds(c), tot = odds.reduce((a, o) => a + o.p, 0);
    let x = rf(R) * tot, o = odds[odds.length - 1];
    for (const q of odds) { x -= q.p; if (x < 0) { o = q; break; } }
    if (o.gold) {
      const L = c.gold, w = L.map(id => SK[id].w === 'gloves' ? GLOVE_W[SK[id].r] || 1 : 1), tw = w.reduce((a, b) => a + b, 0);
      let y = rf(R) * tw; for (let i = 0; i < L.length; i++) { y -= w[i]; if (y < 0) return L[i]; }
      return L[L.length - 1];
    }
    const pool = c.tiers[o.r];
    return pool[Math.min(pool.length - 1, Math.floor(rf(R) * pool.length))];
  };
  // износ: 30 % «Новый», 45 % «Боевой», 25 % «Потёртый»
  G.rollWear = (rnd) => { const r = rf(typeof rnd === 'function' ? rnd : Math.random); return r < 0.3 ? 0 : r < 0.75 ? 1 : 2; };
  G.skinLabel = (id) => { const s = SK[id]; return s.w === 'gloves' ? (s.name.includes('|') ? s.name : 'Перчатки | ' + s.name) : G.WEAPONS[s.w].name + ' | ' + s.name; };

  // ---------- материалы ----------
  const matCache = {};
  let poly = null, metal = null, glass = null, lpoly = null, lmetal = null;
  G.vmBase = () => {
    if (!poly) {
      const pd = G.tex('polyDetail'), md = G.tex('metalDetail');
      poly = pbr({ vertexColors: true, map: pd, roughnessMap: pd, normalMap: G.normalTex('polyDetail'), normalScale: new THREE.Vector2(0.3, 0.3), metalness: 0.05, roughness: 0.74, envMapIntensity: 0.6 });
      metal = pbr({ vertexColors: true, map: md, roughnessMap: md, normalMap: G.normalTex('metalDetail'), normalScale: new THREE.Vector2(0.25, 0.25), metalness: 0.72, roughness: 0.36, envMapIntensity: 1.45 });
      glass = pbr({ color: 0x0e2a3a, metalness: 0.3, roughness: 0.06, envMapIntensity: 1.1 });
      lpoly = new THREE.MeshPhongMaterial({ vertexColors: true, map: pd, shininess: 30, specular: 0x262626 });
      lmetal = new THREE.MeshPhongMaterial({ vertexColors: true, map: md, shininess: 60, specular: 0x555555 });
    }
    if (!poly.userData.rim) { G.rimify(poly, 0.32); G.rimify(metal, 0.42); G.rimify(lpoly, 0.3); G.rimify(lmetal, 0.4); }
    return G.pbrOn() ? { poly, metal, glass } : { poly: lpoly, metal: lmetal, glass: lpoly };
  };
  // бегущий блик и мерцающие искры прямо в шейдере (золотые и хромированные скины)
  G.shineU = { value: 0 };
  function addShine(m, k, col) {
    m.onBeforeCompile = (sh) => {
      sh.uniforms.uShT = G.shineU; sh.uniforms.uShK = { value: k }; sh.uniforms.uShC = { value: new THREE.Color(col) };
      sh.fragmentShader = 'uniform float uShT; uniform float uShK; uniform vec3 uShC;\n' + sh.fragmentShader.replace('#include <emissivemap_fragment>', [
        '#include <emissivemap_fragment>',
        '{',
        ' float band = fract((vUv.x + vUv.y * 0.6) * 0.45 - uShT * 0.28);',
        ' float g = smoothstep(0.0, 0.05, band) * smoothstep(0.13, 0.05, band);',
        ' vec2 cu = vUv * 46.0; vec2 ci = floor(cu); vec2 cf = fract(cu);',
        ' float hh = fract(sin(dot(ci, vec2(12.9898, 78.233))) * 43758.5453);',
        ' vec2 cp = vec2(fract(hh * 7.13), fract(hh * 3.71)) * 0.6 + 0.2;',
        ' vec2 dd = (cf - cp) * vec2(1.0, 1.0);',
        ' float star = max(smoothstep(0.1, 0.0, length(dd)), max(smoothstep(0.03, 0.0, abs(dd.x)) * smoothstep(0.3, 0.0, abs(dd.y)), smoothstep(0.03, 0.0, abs(dd.y)) * smoothstep(0.3, 0.0, abs(dd.x))));',
        ' float tw = pow(0.5 + 0.5 * sin(uShT * (2.0 + hh * 3.0) + hh * 40.0), 18.0) * star * step(0.45, hh);',
        ' totalEmissiveRadiance += uShC * (g * 0.75 * (0.35 + diffuseColor.g) + tw * 2.2) * uShK;',
        '}'].join('\n'));
    };
    m.customProgramCacheKey = () => 'shine' + k;
  }
  G.addShineTo = (m, k, p) => addShine(m, k, SHINE_COL[p] || '#ffe6a0');
  // 2.3 Аркана: свечение узора бежит волнами вдоль оружия, по нему проходит цветной блик, мерцают металлические хлопья.
  // Всё — несколько операций во фрагментном шейдере на общем таймере G.shineU (без работы на CPU каждый кадр)
  function addArcane(m, k, col) {
    m.onBeforeCompile = (sh) => {
      sh.uniforms.uShT = G.shineU; sh.uniforms.uShK = { value: k }; sh.uniforms.uShC = { value: new THREE.Color(col) };
      sh.fragmentShader = 'uniform float uShT; uniform float uShK; uniform vec3 uShC;\n' + sh.fragmentShader.replace('#include <emissivemap_fragment>', [
        '#include <emissivemap_fragment>',
        '{',
        ' float lum = dot(diffuseColor.rgb, vec3(0.3, 0.59, 0.11));',
        ' float w1 = 0.5 + 0.5 * sin((vUv.x * 2.0 + vUv.y * 1.2) * 8.0 - uShT * 2.6);',
        ' float w2 = 0.5 + 0.5 * sin((vUv.y * 2.3 - vUv.x * 1.1) * 5.0 - uShT * 1.7 + 1.3);',
        ' totalEmissiveRadiance *= 0.45 + 1.25 * w1 * w2 + 0.3 * w1;',
        ' float band = fract((vUv.x + vUv.y * 0.6) * 0.45 - uShT * 0.32);',
        ' float g = smoothstep(0.0, 0.06, band) * smoothstep(0.16, 0.06, band);',
        ' vec2 cu = vUv * 64.0; vec2 ci = floor(cu); vec2 cf = fract(cu);',
        ' float hh = fract(sin(dot(ci, vec2(12.9898, 78.233))) * 43758.5453);',
        ' vec2 cp = vec2(fract(hh * 7.13), fract(hh * 3.71)) * 0.6 + 0.2;',
        ' float fl = smoothstep(0.13, 0.0, length(cf - cp)) * pow(0.5 + 0.5 * sin(uShT * (1.5 + hh * 4.0) + hh * 50.0), 10.0) * step(0.35, hh);',
        ' totalEmissiveRadiance += uShC * (g * (0.25 + lum) * 0.9 + fl * 1.6 + w1 * w2 * lum * 0.35) * uShK;',
        '}'].join('\n'));
    };
    m.customProgramCacheKey = () => 'arc' + k;
  }
  G.skinMats = (wid, skinId, wear) => {
    const tier = G.pbrOn() ? 'p' : 'l';
    const key = wid + '|' + (skinId || 'factory') + '|' + (wear || 0) + '|' + tier;
    if (matCache[key]) return matCache[key];
    const f = FACTORY[wid] || FACTORY.ar;
    const sk = skinId && SK[skinId];
    const mk = (p, w) => {
      const t = G.skinTex(p, w), L = LOOK[p] || [0.3, 0.4];
      if (tier === 'l') {
        const m = new THREE.MeshPhongMaterial({ map: t, vertexColors: true, shininess: 20 + (1 - L[1]) * 80, specular: L[0] > 0.6 ? 0x666666 : 0x2a2a2a });
        if (L[2]) { m.emissiveMap = t; m.emissive = new THREE.Color(0xffffff); m.emissiveIntensity = L[2]; }
        if (ARC_P[p]) addArcane(m, L[5] || 1, SHINE_COL[p] || '#ffffff'); else if (L[5]) addShine(m, L[5], SHINE_COL[p] || '#ffe6a0');
        return G.rimify(m, 0.3);
      }
      const o = { map: t, vertexColors: true, metalness: L[0], roughness: G.clamp(L[1] + (w || 0) * 0.08, 0, 1), envMapIntensity: L[6] != null ? L[6] : L[0] < 0.5 ? 0.85 : 1.25 };
      if (L[2]) { o.emissiveMap = t; o.emissive = new THREE.Color(0xffffff); o.emissiveIntensity = L[2]; }
      if (L[4]) { o.bumpMap = t; o.bumpScale = L[4]; }
      const m = pbr(o);
      if (ARC_P[p]) addArcane(m, L[5] || 1, SHINE_COL[p] || '#ffffff'); else if (L[5]) addShine(m, L[5], SHINE_COL[p] || '#ffe6a0');
      return G.rimify(m, L[0] > 0.6 ? 0.38 : 0.3);
    };
    let res;
    if (sk) {
      const ma = mk(sk.p, wear || 0);
      res = { a: ma, b: G.WEAPONS[wid].melee && !sk.gold ? mk(f.b, 0) : ma, k: sk.k, shine: sk.shine || 0 };
    } else res = { a: mk(f.a, 0), b: mk(f.b, 0), k: 3 };
    Object.assign(res, G.vmBase());
    matCache[key] = res;
    return res;
  };

  // крупные вспыхивающие звёздочки на поверхности (для золотых скинов)
  let sparkMat = null;
  G.addSparkles = (group, mesh, n, size) => {
    if (!mesh) return;
    if (!sparkMat) sparkMat = new THREE.SpriteMaterial({ map: G.tex('star'), color: 0xfff2c8, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false });
    const pa = mesh.geometry.attributes.position, na = mesh.geometry.attributes.normal, list = [];
    for (let i = 0; i < n; i++) {
      const k = Math.floor(Math.random() * pa.count);
      const sp = new THREE.Sprite(sparkMat);
      sp.position.set(pa.getX(k) + na.getX(k) * 0.004, pa.getY(k) + na.getY(k) * 0.004, pa.getZ(k) + na.getZ(k) * 0.004);
      sp.scale.setScalar(1e-5); group.add(sp);
      list.push({ s: sp, ph: Math.random() * 6.28, sp: 1.2 + Math.random() * 2.2, sz: size * (0.6 + Math.random() * 0.7) });
    }
    group.userData.sparks = (group.userData.sparks || []).concat(list);
  };
  G.tickSparkles = (obj, t) => {
    const L = obj && obj.userData.sparks; if (!L) return;
    for (const q of L) { const v = Math.pow(Math.max(0, Math.sin(t * q.sp + q.ph)), 16); q.s.scale.setScalar(q.sz * v + 1e-5); q.s.material.rotation = t * 0.6; }
  };

  // ---------- инвентарь ----------
  let inv = null;
  // инвентарь текущего профиля
  // 2.3: у инвентаря есть метод buyOp (не сохраняется: JSON его пропускает) — покупка оперативника, см. G.invBuyOp
  const withApi = (o) => { try { Object.defineProperty(o, 'buyOp', { value: (id, cb) => G.invBuyOp(id, cb), enumerable: false, configurable: true, writable: true }); } catch (e) { } return o; };
  G.loadInv = (key) => {
    G.invKey = key;
    inv = G.inv = withApi(Object.assign({ coins: 1000, items: [], equip: {}, knife: null, gloves: null, next: 1, opened: 0 }, G.store.get(key, {})));
    inv.items = inv.items.filter(it => SK[it.s]); // старые предметы с удалёнными скинами
    // 11.1: новый сезон — у всех один раз обнуляются скины, ножи, перчатки и монеты
    if (!inv.wipe11) {
      const had = inv.items.length > 0 || inv.coins !== 1000;
      Object.assign(inv, { coins: 1000, items: [], equip: {}, knife: null, gloves: null, tokens: {}, wipe11: 1 });
      G.store.set(key, inv);
      if (had && key !== 'inv') G.wipeNotice = true;
    }
    // 2.2: бесплатные открытия убранных кейсов превращаются в открытия нового кейса 1:1 (меню один раз объясняет это сообщением)
    if (inv.tokens) {
      let n = 0; const got = [], per = {};
      for (const k of Object.keys(inv.tokens)) {
        const to = G.CASE_REMAP[k]; if (!to) continue;
        const v = Math.max(0, inv.tokens[k] | 0); delete inv.tokens[k];
        if (v) { inv.tokens[to] = (inv.tokens[to] || 0) + v; n += v; per[to] = (per[to] || 0) + v; got.push([k, v, to]); }
      }
      // 2.3: убранные кейсы ведут в разные кейсы — сообщение называет основной, остальные помечены стрелкой
      const main = Object.keys(per).sort((a, b) => per[b] - per[a])[0], nm = (id) => ((G.caseOf(id) || {}).name || '').replace(/^Кейс\s*/, '');
      const names = got.map(([k, v, to]) => '«' + (G.CASE_OLD_NAMES[k] || k) + '»' + (v > 1 ? ' ×' + v : '') + (to !== main ? ' → ' + nm(to) : ''));
      if (n) { G.store.set(key, inv); if (key !== 'inv') G.caseMigrated = { n, names, to: main }; }
    }
  };
  // скины для ботов: обычные чаще, редкие реже
  const BOT_POOL = {};
  G.botSkinPool = (id) => {
    if (BOT_POOL[id]) return BOT_POOL[id];
    const W = { 1: 6, 2: 4, 3: 2, 4: 1, 5: 1, 7: 1 }, out = []; // 2.3: 7 — Аркана
    for (const k in SK) { const s = SK[k]; if (s.w === id && !s.bp && W[s.r]) for (let i = 0; i < W[s.r]; i++) out.push(s.id); }
    return (BOT_POOL[id] = out);
  };
  if (!G.HEADLESS) G.loadInv('inv'); // 2.3: сервер (G.HEADLESS) берёт отсюда только данные кейсов/скинов — без localStorage
  G.saveInv = () => G.store.set(G.invKey, inv);
  G.invAddQuiet = (skinId, wear) => { const it = { uid: inv.next++, s: skinId, w: wear != null ? wear : G.rollWear(), t: Date.now() }; inv.items.unshift(it); return it; };
  G.invAdd = (skinId, wear) => { const it = G.invAddQuiet(skinId, wear); G.saveInv(); return it; };
  G.invItem = (uid) => inv.items.find(i => i.uid === uid);
  // 2.3: продажи предметов игре больше нет (только рынок между игроками — js/market.js). Заглушка оставлена для совместимости
  G.invSell = () => 0;
  // 2.3: облачный инвентарь (js/cloud.js) подменяет инвентарь профиля своим зеркалом: obj — готовый объект, key — куда сохранять
  G.useInv = (obj, key) => { if (key) G.invKey = key; inv = G.inv = withApi(obj); return inv; };
  // 2.3: покупка оперативника за монеты (цена — G.OPS_DATA). Гость/офлайн-профиль — сразу здесь; облачный аккаунт — через сервер (op_buy).
  // Ответ сразу: { ok } | { pending } (ждём сервер) | { err: 'nf'|'lock'|'owned'|'coins'|'free'|'offline', m: текст, need? };
  // cb (если есть) получает окончательный результат в обоих случаях
  G.opPrice = (id) => { const o = (G.OPS_DATA || []).find(x => x && x.id === id); return o ? { price: Math.max(0, o.price | 0), lock: o.lock || null, name: o.name || id } : null; };
  G.invBuyOp = (id, cb) => {
    const done = (r) => { if (cb) { try { cb(r); } catch (e) { console.error(e); } } return r; };
    const d = G.opPrice(id);
    if (!d) return done({ err: 'nf', m: 'Такого оперативника нет' });
    if (d.lock === 'bp') return done({ err: 'lock', m: 'Этот оперативник — только из боевого пропуска' });
    if ((inv.opsOwned || []).includes(id)) return done({ err: 'owned', m: 'Уже ваш' });
    if (!d.price) return done({ err: 'free', m: 'Этот оперативник доступен всем' });
    if (G.cloud && G.cloud.on()) return G.cloud.opBuy(id, cb);
    if (inv.coins < d.price) return done({ err: 'coins', need: d.price - inv.coins, m: 'Не хватает ' + (d.price - inv.coins) + ' монет' });
    inv.coins -= d.price;
    inv.opsOwned = (inv.opsOwned || []).concat([id]);
    G.saveInv();
    try { window.dispatchEvent(new CustomEvent('sz:inv', { detail: { why: 'op_buy' } })); } catch (e) { }
    return done({ ok: true, id, price: d.price });
  };
  G.invEquip = (uid) => {
    const it = G.invItem(uid); if (!it) return;
    const sk = SK[it.s];
    if (sk.r === 6) inv.knife = uid; else if (sk.w === 'gloves') inv.gloves = uid; else inv.equip[sk.w] = uid;
    G.saveInv();
  };
  G.invUnequip = (uid) => {
    for (const w in inv.equip) if (inv.equip[w] === uid) delete inv.equip[w];
    if (inv.knife === uid) inv.knife = null;
    if (inv.gloves === uid) inv.gloves = null;
    G.saveInv();
  };
  G.isEquipped = (uid) => inv.knife === uid || inv.gloves === uid || Object.values(inv.equip).includes(uid);
  // надетые перчатки: { id, wear } или null
  G.equippedGloves = () => {
    const it = inv.gloves && G.invItem(inv.gloves);
    return it && SK[it.s] && SK[it.s].w === 'gloves' ? { id: it.s, wear: it.w || 0 } : null;
  };
  // скин на оружии игрока: { s, w } или null
  G.equippedSkin = (wid) => {
    const uid = inv.equip[wid]; const it = uid && G.invItem(uid);
    return it ? it.s : null;
  };
  G.equippedWear = (wid) => { const uid = inv.equip[wid]; const it = uid && G.invItem(uid); return it ? (it.w || 0) : 0; };
  G.equippedKnife = () => {
    const it = inv.knife && G.invItem(inv.knife);
    if (!it || !SK[it.s]) return { id: 'knife', skin: null, wear: 0 };
    return { id: SK[it.s].w, skin: it.s, wear: it.w || 0 };
  };
})(window.G);
