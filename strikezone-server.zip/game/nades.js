'use strict';
/* Гранаты: полёт с отскоками, осколочный взрыв, ослепление, дымовая завеса (закрывает обзор ботам и игроку) */
(function (G) {
  const V3 = THREE.Vector3;
  // 2.3: физика полёта — фиксированный шаг (1/64 с) с накоплением времени: путь гранаты зависит только от точки и скорости
  // броска, а не от частоты кадров/тиков — клиент, сервер (30 тиков/с) и предпросмотр траектории считают одно и то же.
  // Настоящая тяжесть, слабое сопротивление воздуха, отскок с упругостью и трением своими для каждой поверхности,
  // качение по полу с трением качения, скатывание с края, без «пролёта» тонких стен (луч на весь шаг + радиус гранаты)
  const STEP = 1 / 64, GRAV = 9.81, DRAG = 0.0032, RAD = 0.035, ROLL_V = 1.1, REST_V = 0.14;
  const FUSE = { he: 1.6, flash: 1.45, smoke: 1.9 };
  const FK = { he: Math.round(1.6 / STEP), flash: Math.round(1.45 / STEP), smoke: Math.round(7 / STEP) }; // дымовая — когда улеглась (не позже 7 с)
  const SMOKE_MIN = Math.round(0.55 / STEP);
  // поверхности: [упругость, трение скольжения при ударе, трение качения]
  const SURF = { hard: [0.42, 0.32, 0.42], metal: [0.52, 0.22, 0.3], wood: [0.36, 0.38, 0.48], soft: [0.22, 0.6, 0.95], glass: [0.48, 0.2, 0.32] };
  const SURF_RE = [[/metal|corrug|container|shutter|hvac|wagon|steel|iron|pipe|rail|tank/i, 'metal'], [/plank|wood|crate|door|shoji|fusuma|deck|kura|machiya|bench|box/i, 'wood'],
    [/ground|grass|hedge|leaves|sand|dirt|ballast|soil|mushiko|petal|tatami/i, 'soft'], [/win|glass/i, 'glass']];
  const surfClass = (mat) => { if (!mat) return 'hard'; for (const [re, c] of SURF_RE) if (re.test(mat)) return c; return 'hard'; };
  // броски игрока (м/с): полный — сверху, «снизу» — короткий навесной
  const THROW_V = 17.5, LOB_V = 7.2, MAX_V = 23.9;
  const SMOKE_R = 4.3, SMOKE_H = 1.9, SMOKE_DUR = 16, PUFFS = 26;
  const _v = new V3();
  const r3 = (v) => Math.round(v * 1000) / 1000;
  // поверхность, о которую ударились: пол карты или грань твёрдой коробки (по точке и нормали)
  function surfAt(x, y, z, nx, ny, nz) {
    const M = G.map, g = M.grid;
    if (ny > 0.5 && y < 0.02) return M.def && M.def.ground ? (M.def._sf || (M.def._sf = surfClass(M.def.ground.mat))) : 'hard';
    const S = M.solids;
    const test = (b) => {
      const e = 0.02;
      if (x < b.x0 - e || x > b.x1 + e || y < b.y0 - e || y > b.y1 + e || z < b.z0 - e || z > b.z1 + e) return false;
      return nx ? Math.abs(x - (nx < 0 ? b.x0 : b.x1)) < e : ny ? Math.abs(y - (ny < 0 ? b.y0 : b.y1)) < e : Math.abs(z - (nz < 0 ? b.z0 : b.z1)) < e;
    };
    let b = null;
    if (g && g.solids === S && g.cx) {
      const c = g.cz(z) * g.nx + g.cx(x);
      for (let k = g.start[c], e = g.start[c + 1]; k < e; k++) { const q = S[g.idx[k]]; if (!q.nr && test(q)) { b = q; break; } }
    } else for (const q of S) if (!q.nr && test(q)) { b = q; break; }
    if (!b) return 'hard';
    return b._sf || (b._sf = surfClass(b.mat));
  }
  // 2.0: «пол» y = 0 над каналом — это вода ниже: не удар, граната летит дальше (к воде)
  const waterFloor = (hit, py, dy, px, pz, dx, dz) => hit && hit.ny > 0.5 && py + dy * hit.t < 0.05 && G.map.waterAt(px + dx * hit.t, pz + dz * hit.t) != null;

  // 2.3: короткий луч шага гранаты по сетке коробок карты (тот же расчёт, что G.map.ray: пол y = 0, коробки «nr» пропускаются,
  // меньшее t, при равенстве — меньший индекс), но без выделения памяти и замыканий — шаг дешёвый и для предпросмотра.
  // Результат в RH: t и нормаль; true — попадание
  const RH = { t: 0, nx: 0, ny: 0, nz: 0 };
  let _mark = null, _stamp = 0;
  function segRay(ox, oy, oz, dx, dy, dz, L) {
    const M = G.map, g = M.grid, S = M.solids;
    if (!g || g.solids !== S || !g.cx) { const h = M.ray(ox, oy, oz, dx, dy, dz, L); if (!h) return false; RH.t = h.t; RH.nx = h.nx; RH.ny = h.ny; RH.nz = h.nz; return true; }
    let best = L, hit = false, bi = -1, bnx = 0, bny = 0, bnz = 0;
    if (dy < -1e-6) { const t = -oy / dy; if (t > 0 && t < best) { best = t; hit = true; bny = 1; } }
    if (!_mark || _mark.length < S.length) { _mark = new Uint32Array(S.length + 64); _stamp = 0; }
    if (++_stamp > 0xfffffff0) { _mark.fill(0); _stamp = 1; }
    const ex = ox + dx * L, ey = oy + dy * L, ez = oz + dz * L;
    const ax0 = Math.min(ox, ex), ax1 = Math.max(ox, ex), ay0 = Math.min(oy, ey), ay1 = Math.max(oy, ey), az0 = Math.min(oz, ez), az1 = Math.max(oz, ez);
    const i0 = g.cx(ax0 - 1e-3), i1 = g.cx(ax1 + 1e-3), j0 = g.cz(az0 - 1e-3), j1 = g.cz(az1 + 1e-3), st = g.start, idx = g.idx, nx = g.nx;
    const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const c = j * nx + i;
      for (let k = st[c], e = st[c + 1]; k < e; k++) {
        const n = idx[k];
        if (_mark[n] === _stamp) continue;
        _mark[n] = _stamp;
        const b = S[n];
        if (b.nr || b.x1 < ax0 || b.x0 > ax1 || b.y1 < ay0 || b.y0 > ay1 || b.z1 < az0 || b.z0 > az1) continue;
        // плиты (slab): как rayBox в maps.js
        let tmin = 0, tmax = best, nx_ = 0, ny_ = 0, nz_ = 0, t1, t2;
        if (Math.abs(dx) < 1e-9) { if (ox < b.x0 || ox > b.x1) continue; }
        else { t1 = (b.x0 - ox) * ix; t2 = (b.x1 - ox) * ix; if (t1 > t2) { const q = t1; t1 = t2; t2 = q; } if (t1 > tmin) { tmin = t1; nx_ = dx > 0 ? -1 : 1; } if (t2 < tmax) tmax = t2; if (tmin > tmax) continue; }
        if (Math.abs(dy) < 1e-9) { if (oy < b.y0 || oy > b.y1) continue; }
        else { t1 = (b.y0 - oy) * iy; t2 = (b.y1 - oy) * iy; if (t1 > t2) { const q = t1; t1 = t2; t2 = q; } if (t1 > tmin) { tmin = t1; nx_ = 0; ny_ = dy > 0 ? -1 : 1; } if (t2 < tmax) tmax = t2; if (tmin > tmax) continue; }
        if (Math.abs(dz) < 1e-9) { if (oz < b.z0 || oz > b.z1) continue; }
        else { t1 = (b.z0 - oz) * iz; t2 = (b.z1 - oz) * iz; if (t1 > t2) { const q = t1; t1 = t2; t2 = q; } if (t1 > tmin) { tmin = t1; nx_ = 0; ny_ = 0; nz_ = dz > 0 ? -1 : 1; } if (t2 < tmax) tmax = t2; if (tmin > tmax) continue; }
        if (tmin < best || (tmin === best && n < bi)) { best = tmin; hit = true; bi = n; bnx = nx_; bny = ny_; bnz = nz_; }
      }
    }
    if (hit) { RH.t = best; RH.nx = bnx; RH.ny = bny; RH.nz = bnz; }
    return hit;
  }
  // один шаг физики. fx — можно звук и брызги (в предпросмотре нельзя). Возвращает силу удара (м/с) для звука, иначе 0
  function stepNade(n, fx) {
    if (n.rest) return 0;
    if (n.wet) { N.sink(n, STEP); return 0; }
    const v = n.vel, p = n.pos, h = STEP;
    let imp = 0;
    if (n.roll) {
      // качение: трение качения поверхности, скорость только вдоль пола
      const sp = Math.sqrt(v.x * v.x + v.z * v.z), dec = n.rf * GRAV * h;
      v.y = 0;
      if (sp <= dec || sp < REST_V) { v.x = 0; v.z = 0; n.rest = true; return 0; }
      const k = (sp - dec) / sp; v.x *= k; v.z *= k;
    } else {
      const sp = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z), kd = 1 / (1 + DRAG * sp * h);
      v.x *= kd; v.y *= kd; v.z *= kd;
      v.y -= GRAV * h;
    }
    n.sx = p.x; n.sy = p.y; n.sz = p.z; // точка до шага — заведомо вне стен
    let rem = h;
    for (let it = 0; it < 4 && rem > 1e-7; it++) {
      const mx = v.x * rem, my = v.y * rem, mz = v.z * rem, len = Math.sqrt(mx * mx + my * my + mz * mz);
      if (len < 1e-7) break;
      const dx = mx / len, dy = my / len, dz = mz / len;
      let hit = segRay(p.x, p.y, p.z, dx, dy, dz, len + RAD) ? RH : null;
      if (waterFloor(hit, p.y, dy, p.x, p.z, dx, dz)) hit = null;
      if (!hit) {
        p.x += mx; p.y += my; p.z += mz;
        if (p.y < 0.05) N.wetStep(n, mx, mz, fx);
        break;
      }
      if (!hit.nx && !hit.ny && !hit.nz) { // начало луча внутри коробки (не должно случаться) — назад в последнюю чистую точку
        p.set(n.sx, n.sy, n.sz); v.multiplyScalar(-0.3); break;
      }
      const go = Math.max(0, hit.t - RAD);
      p.x += dx * go; p.y += dy * go; p.z += dz * go;
      rem *= 1 - go / len;
      const vn = v.x * hit.nx + v.y * hit.ny + v.z * hit.nz;
      if (vn >= 0) continue; // скользим вдоль грани
      const S = SURF[surfAt(p.x + dx * RAD, p.y + dy * RAD, p.z + dz * RAD, hit.nx, hit.ny, hit.nz)];
      const e = S[0], mu = S[1];
      // нормальная часть — отскок с упругостью, касательная — теряет скорость от трения (закон Кулона)
      let tx = v.x - vn * hit.nx, ty = v.y - vn * hit.ny, tz = v.z - vn * hit.nz;
      const tl = Math.sqrt(tx * tx + ty * ty + tz * tz), fr = mu * (1 + e) * -vn, kt = tl > 1e-6 ? Math.max(0, tl - fr) / tl : 0;
      const vnn = -vn * e * (n.type === 'smoke' ? 0.85 : 1);
      tx *= kt; ty *= kt; tz *= kt;
      v.x = tx + vnn * hit.nx; v.y = ty + vnn * hit.ny; v.z = tz + vnn * hit.nz;
      imp = Math.max(imp, -vn);
      n.bounces = (n.bounces | 0) + 1;
      if (fx && n.spin) n.spin.multiplyScalar(0.55);
      // на полу с малой скоростью отскока — катится (цилиндрические катятся хуже)
      if (hit.ny > 0.7 && vnn < ROLL_V) {
        n.roll = true; v.y = 0; n.rf = S[2] * (n.type === 'he' ? 0.8 : 1.25);
        if (Math.sqrt(v.x * v.x + v.z * v.z) < REST_V) { v.x = 0; v.z = 0; n.rest = true; break; }
      }
    }
    if (n.roll && !n.rest) {
      // опора под гранатой: нет — скатилась с края и снова падает; есть — держим высоту ровно над полом
      let gh = segRay(p.x, p.y, p.z, 0, -1, 0, RAD + 0.08) ? RH : null;
      if (waterFloor(gh, p.y, -1, p.x, p.z, 0, 0)) gh = null;
      if (!gh) n.roll = false;
      else { p.y += RAD - gh.t; const sf = surfAt(p.x, p.y - RAD, p.z, 0, 1, 0); n.rf = SURF[sf][2] * (n.type === 'he' ? 0.8 : 1.25); }
    }
    // граница карты — как стена
    const B = G.map.bounds;
    if (B) {
      if (p.x < B.x0 + RAD) { p.x = B.x0 + RAD; v.x = Math.abs(v.x) * 0.4; } else if (p.x > B.x1 - RAD) { p.x = B.x1 - RAD; v.x = -Math.abs(v.x) * 0.4; }
      if (p.z < B.z0 + RAD) { p.z = B.z0 + RAD; v.z = Math.abs(v.z) * 0.4; } else if (p.z > B.z1 - RAD) { p.z = B.z1 - RAD; v.z = -Math.abs(v.z) * 0.4; }
    }
    if (p.y < -5) n.rest = true;
    return imp;
  }

  const N = G.nades = {
    list: [], smokes: [], STEP, GRAV, RAD, FK, lob: false,
    init(scene) {
      this.scene = scene;
      this.geo = {};
      // облака дыма: все клубы — одни точки с размером и прозрачностью на вершину
      const M = this.M = PUFFS * 5;
      this.sPos = new Float32Array(M * 3); this.sSize = new Float32Array(M); this.sA = new Float32Array(M); this.sShade = new Float32Array(M);
      for (let i = 0; i < M; i++) this.sPos[i * 3 + 1] = -999;
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(this.sPos, 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('size', new THREE.BufferAttribute(this.sSize, 1).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('alpha', new THREE.BufferAttribute(this.sA, 1).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('shade', new THREE.BufferAttribute(this.sShade, 1));
      this.sGeo = g;
      const mat = this.sMat = new THREE.ShaderMaterial({
        uniforms: { map: { value: G.tex('puff') }, scale: { value: 500 }, lit: { value: new THREE.Color('#e2e1dc') }, dark: { value: new THREE.Color('#7f8287') } },
        vertexShader: 'attribute float size; attribute float alpha; attribute float shade; uniform float scale; varying float vA; varying float vS;' +
          'void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = size * scale / max(0.35, -mv.z); gl_Position = projectionMatrix * mv; vA = alpha; vS = shade; }',
        fragmentShader: 'uniform sampler2D map; uniform vec3 lit; uniform vec3 dark; varying float vA; varying float vS;' +
          'void main(){ vec4 t = texture2D(map, gl_PointCoord); float a = t.a * vA; if (a < 0.01) discard; gl_FragColor = vec4(mix(dark, lit, vS) * (0.82 + 0.18 * t.r), a); }',
        transparent: true, depthWrite: false
      });
      const pts = this.sPts = new THREE.Points(g, mat);
      pts.frustumCulled = false;
      pts.matrixAutoUpdate = false; pts.visible = false; // 2.0 perf: рисуются, только пока есть дым (раньше — пустой вызов каждый кадр)
      const dbs = new THREE.Vector2();
      pts.onBeforeRender = (r, s, cam) => { r.getDrawingBufferSize(dbs); mat.uniforms.scale.value = dbs.y / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov || 60) / 2)); };
      scene.add(pts);
      // вспышка светошумовой
      this.pop = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('flare'), color: 0xffffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      this.pop.visible = false; this.popT = 0; scene.add(this.pop);
      this.initArc(scene);
    },
    reset() {
      if (G.HEADLESS || !this.sGeo) { this.list = []; this.smokes = []; return; }
      for (const n of this.list) if (n.mesh) this.scene.remove(n.mesh);
      for (const s of this.spoons || []) this.scene.remove(s.m);
      this.list = []; this.smokes = []; this.spoons = [];
      for (let i = 0; i < this.M; i++) { this.sA[i] = 0; this.sPos[i * 3 + 1] = -999; }
      this.sGeo.attributes.position.needsUpdate = true; this.sGeo.attributes.alpha.needsUpdate = true;
      this.pop.visible = false; this.sPts.visible = false;
      if (this.arc) this.arc.visible = this.mark.visible = false;
    },
    setEnv(env) {
      const lit = new THREE.Color('#e6e4de').lerp(new THREE.Color(env.sun), 0.22);
      this.sMat.uniforms.lit.value.copy(lit);
      this.sMat.uniforms.dark.value.copy(new THREE.Color('#7d8086').lerp(new THREE.Color(env.hemiGround), 0.2));
    },
    // мировая модель летящей гранаты: корпус без чеки и рычага (их уже нет), чуть крупнее настоящей — читается издалека
    model(type) {
      if (!this.geo[type]) { const gp = G.gunParts(type); this.geo[type] = G.geo.build(gp.fly || gp.body); }
      return this.geo[type];
    },
    // запустить гранату: точка и скорость округляются до мм — сервер рассылает их так же, и копии у клиентов летят тем же путём
    spawn(a, type, ox, oy, oz, vx, vy, vz, nid, visual, pred) {
      ox = r3(ox); oy = r3(oy); oz = r3(oz); vx = r3(vx); vy = r3(vy); vz = r3(vz);
      // своя граната онлайн: копия уже летит (предсказание при броске) — сервер подтвердил её, забираем номер
      if (visual && !pred && a && a.isPlayer && !a.net) {
        const q = this.list.find(n => n.pred && n.type === type && n.o0[0] === ox && n.o0[1] === oy && n.o0[2] === oz && n.v0[0] === vx && n.v0[1] === vy && n.v0[2] === vz);
        if (q) { q.pred = false; q.id = nid; return q; }
      }
      let mesh = null;
      if (!G.HEADLESS && this.scene) {
        mesh = new THREE.Mesh(this.model(type), G.getVCMat());
        mesh.position.set(ox, oy, oz); mesh.castShadow = false; mesh.scale.setScalar(1.2);
        mesh.rotation.set(Math.random() * 6.28, Math.random() * 6.28, 0);
        this.scene.add(mesh);
        this.spoon(type, ox, oy, oz, vx, vy, vz);
      }
      const n = { type, owner: a, team: a ? a.team : 0, pos: new V3(ox, oy, oz), vel: new V3(vx, vy, vz), pp: new V3(ox, oy, oz), acc: 0, k: 0, t: 0, mesh, rest: false, roll: false,
        spin: new V3(Math.random() * 14 - 7, Math.random() * 8 - 4, 9 + Math.random() * 7), heard: false, o0: [ox, oy, oz], v0: [vx, vy, vz],
        id: nid != null ? nid : (this.nid = (this.nid || 0) + 1), visual: !!visual, pred: !!pred };
      if (pred) n.id = -1;
      this.list.push(n);
      if (!visual) G.emit('nadeSpawn', { n, o: [ox, oy, oz], v: [vx, vy, vz] });
      if (!(visual && !pred && a && a.isPlayer)) G.audio.nadeThrow(a && !a.isPlayer ? a.pos : null, !!(a && a.isPlayer)); // своя чека уже прозвучала
      if (a && a.isPlayer && !a.net && !visual && G.game.mode !== 'tutorial') G.bp.ev('nade');
      return n;
    },
    // сетевая игра: граната взорвалась у сервера — убрать её копию и показать эффект
    remoteBoom(id, type, x, y, z) {
      const i = this.list.findIndex(n => n.id === id && n.visual);
      const n = i >= 0 ? this.list[i] : { type, owner: null, pos: new V3() };
      if (i >= 0) { if (n.mesh) this.scene.remove(n.mesh); this.list.splice(i, 1); }
      n.pos.set(x, y, z); n.type = type;
      this.detonate(n, true);
    },
    // параметры броска игрока (точка вылета и скорость) — одна функция для броска, сети и предпросмотра траектории.
    // lob — «снизу»: от пояса, слабее и круче вверх. Направление — по взгляду с подъёмом как в CS (до 10° над горизонтом
    // при взгляде прямо), к скорости броска прибавляется скорость самого игрока
    throwParams(a, lob, out) {
      out = out || {};
      let pitch = a.pitch;
      pitch += (Math.PI / 2 - Math.abs(pitch)) * (lob ? 0.3 : 1 / 9);
      const cp = Math.cos(pitch);
      const dx = -Math.sin(a.yaw) * cp, dy = Math.sin(pitch), dz = -Math.cos(a.yaw) * cp;
      const rx = Math.cos(a.yaw), rz = -Math.sin(a.yaw);
      const eye = a.pos.y + a.eyeH(), ey = eye - (lob ? 0.42 : 0.1);
      let ox = a.pos.x + dx * 0.3 + rx * 0.12, oz = a.pos.z + dz * 0.3 + rz * 0.12, oy = ey + dy * 0.12;
      // не выпускать гранату внутри стены: точка вылета должна быть видна от глаз
      if (!G.map.clear(a.pos.x, eye, a.pos.z, ox, oy, oz)) { ox = a.pos.x; oz = a.pos.z; oy = Math.min(oy, eye); }
      const sp = lob ? LOB_V : THROW_V, av = a.vel;
      let vx = dx * sp + av.x, vy = dy * sp + Math.max(-2, Math.min(av.y, 7)), vz = dz * sp + av.z;
      const s = Math.sqrt(vx * vx + vy * vy + vz * vz);
      if (s > MAX_V) { vx *= MAX_V / s; vy *= MAX_V / s; vz *= MAX_V / s; } // у сервера предел 24 м/с — не упираемся в него
      out.ox = r3(ox); out.oy = r3(oy); out.oz = r3(oz); out.vx = r3(vx); out.vy = r3(vy); out.vz = r3(vz);
      return out;
    },
    // бросок игрока: по направлению взгляда (lob — «снизу»)
    throwFrom(a, type, lob) {
      const q = this.throwParams(a, !!lob);
      // онлайн: гранату запускает сервер; своя копия летит сразу (тот же путь), сервер подтвердит её номером
      if (G.net && G.net.active && a === G.game.player) {
        G.net.throwNade(a, type, q.ox, q.oy, q.oz, q.vx, q.vy, q.vz);
        this.spawn(a, type, q.ox, q.oy, q.oz, q.vx, q.vy, q.vz, null, true, true);
        return;
      }
      this.spawn(a, type, q.ox, q.oy, q.oz, q.vx, q.vy, q.vz);
    },
    // бросок бота в точку: подбираем навесную траекторию, проверяем, что она не упирается в стены
    throwAt(a, type, tx, ty, tz) {
      if (!a.nades || !(a.nades[type] > 0)) return false;
      // если прямой бросок не проходит — пробуем точку ближе к себе или чуть в сторону (граната докатится)
      const bx = a.pos.x - tx, bz = a.pos.z - tz, bl = Math.hypot(bx, bz) || 1, ux = bx / bl, uz = bz / bl;
      const C = [[0, 0], [2.5, 0], [0, 2.8], [0, -2.8], [5, 0], [3, 3], [3, -3]];
      for (const [f, s] of C) {
        if (f >= bl - 3) continue;
        if (this.tryThrow(a, type, tx + ux * f - uz * s, ty, tz + uz * f + ux * s)) return true;
      }
      return false;
    },
    tryThrow(a, type, tx, ty, tz) {
      const ox = a.pos.x, oy = a.pos.y + 1.5, oz = a.pos.z;
      const dx = tx - ox, dz = tz - oz, d = Math.hypot(dx, dz), h = ty - oy;
      if (d < 2) return false;
      const ux = dx / d, uz = dz / d;
      // навесная по формуле, затем одна поправка скорости по настоящей физике (сопротивление воздуха, точка первого касания)
      let v = Math.min(THROW_V, 6 + d * 0.5);
      for (const hi of [false, true]) {
        let ok = false, vh = 0, vy = 0;
        for (let it = 0; it < 2; it++) {
          const v2 = v * v, disc = v2 * v2 - GRAV * (GRAV * d * d + 2 * h * v2);
          if (disc < 0) { v = Math.min(THROW_V, v * 1.12); continue; }
          const th = Math.atan((v2 + (hi ? 1 : -1) * Math.sqrt(disc)) / (GRAV * d));
          if (th > 1.25) break;
          vh = v * Math.cos(th); vy = v * Math.sin(th);
          const r = this.predict(ox + ux * 0.4, oy, oz + uz * 0.4, ux * vh, vy, uz * vh, type, null, true);
          if (!r.first) break;
          const fd = Math.hypot(r.first.x - ox, r.first.z - oz);
          if (Math.abs(fd - d) < 1.6 && Math.abs(r.first.y - ty) < 1.2) { ok = true; break; }
          if (fd < 0.5 || r.first.y > ty + 1.2) break; // упёрлись в стену/навес — эта траектория не годится
          v = Math.min(THROW_V, v * Math.sqrt(d / Math.max(0.5, fd)));
        }
        if (!ok) continue;
        a.yaw = Math.atan2(-dx, -dz);
        this.spawn(a, type, ox + ux * 0.4, oy, oz + uz * 0.4, ux * vh, vy, uz * vh);
        a.nades[type]--;
        return true;
      }
      return false;
    },
    // предсказать полёт тем же шагом физики: точки пути (каждый 2-й шаг) в out (Float32Array x,y,z), первое касание,
    // конечная точка (взрыв по запалу или остановка) и нормаль поверхности под ней. firstOnly — до первого касания
    predict(ox, oy, oz, vx, vy, vz, type, out, firstOnly) {
      const n = this._pn || (this._pn = { pos: new V3(), vel: new V3(), type: 'he' });
      n.pos.set(r3(ox), r3(oy), r3(oz)); n.vel.set(r3(vx), r3(vy), r3(vz)); n.type = type; n.rest = n.roll = n.wet = false; n.bounces = 0; n.spin = null;
      const res = this._pr || (this._pr = { n: 0, first: null, end: new V3(), fx: 0, fy: 0, fz: 0, bnc: [] });
      res.first = null; res.bnc.length = 0; res.n = 0;
      const maxP = out ? out.length / 3 : 0, K = FK[type] || 100;
      let k = 0;
      if (maxP) { out[0] = n.pos.x; out[1] = n.pos.y; out[2] = n.pos.z; res.n = 1; }
      for (; k < K; k++) {
        const b0 = n.bounces;
        stepNade(n, false);
        if (n.bounces !== b0) {
          if (!res.first) res.first = this._pf || (this._pf = new V3());
          if (res.bnc.length === 0) res.first.copy(n.pos);
          if (res.bnc.length < 6 && !n.roll) res.bnc.push(n.pos.x, n.pos.y, n.pos.z);
          if (firstOnly) break;
        }
        if (maxP && (k & 1) && res.n < maxP) { const i = res.n * 3; out[i] = n.pos.x; out[i + 1] = n.pos.y; out[i + 2] = n.pos.z; res.n++; }
        if (n.rest || n.wet) { if (type === 'smoke' && k < SMOKE_MIN) continue; break; }
      }
      if (maxP && res.n < maxP) { const i = res.n * 3; out[i] = n.pos.x; out[i + 1] = n.pos.y; out[i + 2] = n.pos.z; res.n++; }
      res.end.copy(n.pos); res.steps = k; res.rest = n.rest || n.roll; res.wet = !!n.wet;
      return res;
    },
    update(dt) {
      const g = G.game;
      dt = Math.min(dt, 0.25);
      for (let i = this.list.length - 1; i >= 0; i--) {
        const n = this.list[i];
        n.t += dt;
        // своя копия, которую сервер так и не подтвердил (бросок отклонён), — убрать
        if (n.pred && n.t > 1.2) { if (n.mesh) this.scene.remove(n.mesh); this.list.splice(i, 1); continue; }
        // копия сетевой гранаты дошла до взрыва раньше сигнала сервера — замирает и ждёт его (не дольше 1.5 с)
        if (n.done) { if (n.t - n.doneT > 1.5) { if (n.mesh) this.scene.remove(n.mesh); this.list.splice(i, 1); } continue; }
        n.acc += dt;
        let boom = false, imp = 0;
        const fk = FK[n.type] || 100;
        while (n.acc >= STEP) {
          n.acc -= STEP;
          n.pp.copy(n.pos);
          imp = Math.max(imp, stepNade(n, true));
          n.k++;
          // запал считается в шагах физики: взрыв в той же точке у сервера и у клиента
          if (n.k >= fk || (n.type === 'smoke' && (n.rest || n.wet) && n.k >= SMOKE_MIN)) { boom = true; break; }
        }
        if (imp > 2.2) G.audio.bounce(n.pos, Math.min(1, imp / 12));
        if (n.mesh) this.pose(n, dt);
        // противники слышат упавшую рядом гранату
        if (!n.heard && !n.visual && n.owner && (n.rest || n.roll || n.t > 0.8)) { n.heard = true; g.onNoise(n.owner, n.pos.x, n.pos.z, 12); }
        // копия сетевой гранаты ждёт сигнала сервера (с запасом — если сигнал потерялся)
        if (n.visual) { if (boom) { n.done = true; n.doneT = n.t; } continue; }
        if (boom) {
          this.detonate(n);
          if (n.mesh) this.scene.remove(n.mesh);
          this.list.splice(i, 1);
        }
      }
      this.updateSmokes(dt);
      if (this.spoons && this.spoons.length) this.updateSpoons(dt);
      if (this.pop && this.pop.visible) {
        this.popT += dt;
        const k = this.popT / 0.28;
        this.pop.scale.setScalar(2 + k * 9); this.pop.material.opacity = Math.max(0, 1 - k);
        if (k >= 1) this.pop.visible = false;
      }
      if (this.arc) this.updateArc();
    },
    // положение модели между шагами физики (плавно при любой частоте кадров) и вращение: в полёте кувыркается,
    // по полу катится вокруг своей оси (цилиндр — поперёк движения), лёжа — на боку
    pose(n, dt) {
      const m = n.mesh, u = n.acc / STEP, p = n.pos, q = n.pp;
      m.position.set(q.x + (p.x - q.x) * u, q.y + (p.y - q.y) * u, q.z + (p.z - q.z) * u);
      if (n.rest || n.roll || n.wet) {
        const hs = Math.hypot(n.vel.x, n.vel.z);
        if (!n.flat) { n.flat = true; n.ang = Math.random() * 6.28; n.rollA = 0; n.yaw0 = hs > 0.05 ? Math.atan2(n.vel.x, n.vel.z) : Math.random() * 6.28; }
        if (hs > 0.05) n.yaw0 = Math.atan2(n.vel.x, n.vel.z);
        n.rollA += hs * dt / (RAD * 1.1);
        // ось корпуса (Z) — горизонтально и поперёк качения; вращение вокруг неё
        m.rotation.set(0, n.yaw0 + Math.PI / 2, 0, 'YXZ'); m.rotateZ(n.rollA + n.ang);
        m.position.y -= RAD - (n.type === 'he' ? 0.04 : n.type === 'flash' ? 0.027 : 0.031);
      } else {
        m.rotation.x += n.spin.x * dt; m.rotation.y += n.spin.y * dt; m.rotation.z += n.spin.z * dt;
      }
    },
    // 2.3: рычаг («ложка») отлетает при броске — чисто картинка, без влияния на игру
    spoon(type, x, y, z, vx, vy, vz) {
      if (!this.spoonGeo) { const gp = G.gunParts('he'); this.spoonGeo = gp.lever ? G.geo.build(gp.lever) : null; }
      if (!this.spoonGeo) return;
      const m = new THREE.Mesh(this.spoonGeo, G.getVCMat());
      m.position.set(x, y, z); m.scale.setScalar(1.2);
      (this.spoons || (this.spoons = [])).push({ m, v: new V3(vx * 0.35 + (Math.random() - 0.5) * 2, vy * 0.3 + 2.2, vz * 0.35 + (Math.random() - 0.5) * 2), t: 0, s: new V3(Math.random() * 20 - 10, Math.random() * 20 - 10, Math.random() * 20 - 10) });
      this.scene.add(m);
    },
    updateSpoons(dt) {
      for (let i = this.spoons.length - 1; i >= 0; i--) {
        const s = this.spoons[i], m = s.m;
        s.t += dt;
        if (s.t > 2.5) { this.scene.remove(m); this.spoons.splice(i, 1); continue; }
        if (s.rest) continue;
        s.v.y -= GRAV * dt;
        const nx = m.position.x + s.v.x * dt, ny = m.position.y + s.v.y * dt, nz = m.position.z + s.v.z * dt;
        if (!G.map.clear(m.position.x, m.position.y, m.position.z, nx, ny, nz) || ny < 0.01) {
          s.v.multiplyScalar(-0.25); s.v.y = Math.abs(s.v.y); if (s.v.length() < 0.6 || ny < 0.01) { s.rest = true; m.position.y = Math.max(m.position.y, 0.01); m.rotation.set(Math.PI / 2, m.rotation.y, 0); }
          continue;
        }
        m.position.set(nx, ny, nz);
        m.rotation.x += s.s.x * dt; m.rotation.y += s.s.y * dt; m.rotation.z += s.s.z * dt;
      }
    },
    // ---------- 2.3: граната в руке игрока ----------
    // нажали «огонь» — выдернул чеку (рука отведена, видна траектория), держим сколько нужно, отпустили — бросок.
    // Короткий тап — тоже полный бросок, как раньше (сразу после того, как чека выдернута). lob — «снизу» (кнопка/ПКМ)
    PIN_T: 0.3, REL_T: 0.1,
    holdTick(a, st, dt, want) {
      const type = st.def.nade;
      if (st.throwT > 0) {
        st.throwT -= dt;
        if (st.throwT <= 0) {
          this.throwFrom(a, type, st.lob);
          a.nades[type] = Math.max(0, (a.nades[type] || 0) - 1);
          a.afterThrow = 0.5; st.pinT = 0;
          G.game.onNoise(a, a.pos.x, a.pos.z, 10);
        }
        return null;
      }
      if (st.drawT > 0 || a.afterThrow > 0) { st.pinT = 0; return null; }
      if (st.pinT > 0) {
        st.pinT += dt;
        if (!(a.nades[type] > 0)) { st.pinT = 0; return null; }
        if (!want && st.pinT >= this.PIN_T) {
          st.lob = !!this.lob; st.throwT = this.REL_T; st.cd = 1;
          a.throwLob = st.lob; a.throwAnimT = G.anim.dur(st.lob ? 'nade_lob' : 'nade_throw');
          return { nade: true };
        }
        return null;
      }
      if (!want || st.cd > 0 || !(a.nades[type] > 0)) return null;
      st.pinT = 1e-4;
      if (G.audio.nadePin) G.audio.nadePin();
      if (a.protect > 0) a.protect = 0;
      return null;
    },
    toggleLob() { this.lob = !this.lob; this.arcKey = null; if (G.audio.click) G.audio.click(); },
    // ---------- 2.3: предпросмотр траектории ----------
    // лента вдоль предсказанного пути (до 64 точек, тем же шагом физики), метки отскоков и место взрыва/остановки.
    // Только у самого игрока с выдернутой чекой; пересчёт не чаще раза в 2 кадра и только если бросок изменился
    initArc(scene) {
      const NP = this.NP = 64;
      this.arcPts = new Float32Array(NP * 3);
      const pos = this.arcPos = new Float32Array(NP * 2 * 3), col = this.arcCol = new Float32Array(NP * 2 * 4);
      const idx = []; for (let i = 0; i < NP - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('color', new THREE.BufferAttribute(col, 4).setUsage(THREE.DynamicDrawUsage));
      g.setIndex(idx);
      this.arcGeo = g;
      const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false }));
      m.frustumCulled = false; m.visible = false; m.renderOrder = 5;
      scene.add(this.arc = m);
      // метка: кольцо и точка, видны сквозь стены; метки отскоков — маленькие кольца
      const mk = new THREE.Group();
      const mm = this.markMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, depthTest: false, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false });
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.26, 0.34, 28), mm); ring.rotation.x = -Math.PI / 2;
      const dotM = new THREE.Mesh(new THREE.CircleGeometry(0.07, 12), mm); dotM.rotation.x = -Math.PI / 2;
      const halo = new THREE.Mesh(new THREE.RingGeometry(0.34, 0.62, 28), this.haloMat = mm.clone()); halo.rotation.x = -Math.PI / 2; this.haloMat.opacity = 0.18;
      mk.add(ring, dotM, halo); mk.visible = false; mk.renderOrder = 6;
      for (const c of mk.children) c.renderOrder = 6;
      scene.add(this.mark = mk);
      this.bmarks = [];
      const bg = new THREE.RingGeometry(0.07, 0.11, 16);
      for (let i = 0; i < 4; i++) { const b = new THREE.Mesh(bg, mm); b.visible = false; b.renderOrder = 6; scene.add(b); this.bmarks.push(b); }
      this.arcQ = {}; this.arcF = 0; this.arcMs = 0;
    },
    arcHide() { if (this.arc.visible) { this.arc.visible = false; this.mark.visible = false; for (const b of this.bmarks) b.visible = false; } this.arcKey = null; },
    updateArc() {
      const g = G.game, p = g && g.player;
      const st = p && p.w;
      const on = p && p.alive && !p.spectator && !g.specMode && !g.spectating && g.state === 'playing' && p.cur === 'nade' && st && st.def && st.def.nade && st.pinT > 0 && !(st.throwT > 0) && !(p.afterThrow > 0) && G.settings.nadeArc !== false;
      if (!on) { this.arcHide(); return; }
      if ((this.arcF = (this.arcF + 1) & 1) && this.arc.visible) return; // не чаще раза в 2 кадра
      const t0 = performance.now();
      const q = this.throwParams(p, !!this.lob, this.arcQ);
      const key = q.ox + ',' + q.oy + ',' + q.oz + ',' + q.vx + ',' + q.vy + ',' + q.vz + ',' + st.def.nade;
      if (key === this.arcKey) return;
      this.arcKey = key;
      const res = this.predict(q.ox, q.oy, q.oz, q.vx, q.vy, q.vz, st.def.nade, this.arcPts);
      const n = res.n, P = this.arcPts, pos = this.arcPos, col = this.arcCol, cam = g.camera.position;
      const c = this._tc || (this._tc = new THREE.Color());
      c.set(p.team === 1 ? '#ffb22e' : '#5cb6ff');
      let along = 0;
      for (let i = 0; i < this.NP; i++) {
        const j = Math.min(i, n - 1), x = P[j * 3], y = P[j * 3 + 1], z = P[j * 3 + 2];
        const a0 = Math.max(0, j - 1), a1 = Math.min(n - 1, j + 1);
        let tx = P[a1 * 3] - P[a0 * 3], ty = P[a1 * 3 + 1] - P[a0 * 3 + 1], tz = P[a1 * 3 + 2] - P[a0 * 3 + 2];
        const cx = cam.x - x, cy = cam.y - y, cz = cam.z - z, dist = Math.sqrt(cx * cx + cy * cy + cz * cz) || 1;
        // ширина — постоянная на экране (растёт с расстоянием), сторона — поперёк пути и взгляда
        let sx = ty * cz - tz * cy, sy = tz * cx - tx * cz, sz = tx * cy - ty * cx;
        const sl = Math.sqrt(sx * sx + sy * sy + sz * sz) || 1, w = Math.min(0.09, Math.max(0.008, dist * 0.0042)) / sl;
        sx *= w; sy *= w; sz *= w;
        const o = i * 6;
        pos[o] = x - sx; pos[o + 1] = y - sy; pos[o + 2] = z - sz; pos[o + 3] = x + sx; pos[o + 4] = y + sy; pos[o + 5] = z + sz;
        if (i > 0 && j === i) along += Math.sqrt(tx * tx + ty * ty + tz * tz) * 0.5;
        // проявляется от руки, тускнеет вдаль
        const al = i >= n ? 0 : Math.min(1, along / 0.8) * Math.max(0.3, 1 - dist / 40) * 0.85;
        const k = i * 8;
        col[k] = col[k + 4] = c.r; col[k + 1] = col[k + 5] = c.g; col[k + 2] = col[k + 6] = c.b; col[k + 3] = col[k + 7] = al;
      }
      this.arcGeo.attributes.position.needsUpdate = true; this.arcGeo.attributes.color.needsUpdate = true;
      this.arc.visible = true;
      this.markMat.color.copy(c); this.haloMat.color.copy(c);
      const e = res.end, ly = res.rest ? e.y - RAD + 0.02 : e.y;
      this.mark.position.set(e.x, ly, e.z); this.mark.visible = true;
      const sc = Math.min(2.2, Math.max(0.6, Math.hypot(e.x - cam.x, e.y - cam.y, e.z - cam.z) / 14)); this.mark.scale.setScalar(sc);
      const B = res.bnc;
      for (let i = 0; i < this.bmarks.length; i++) {
        const b = this.bmarks[i], ok = i * 3 + 2 < B.length;
        b.visible = ok;
        if (ok) { b.position.set(B[i * 3], B[i * 3 + 1], B[i * 3 + 2]); b.lookAt(cam); b.scale.setScalar(Math.min(2, Math.max(0.6, Math.hypot(B[i * 3] - cam.x, B[i * 3 + 1] - cam.y, B[i * 3 + 2] - cam.z) / 14))); }
      }
      this.arcMs = this.arcMs * 0.9 + (performance.now() - t0) * 0.1;
    },
    // 2.0: граната ниже пола над водой: у стенки набережной — отскок назад, на уровне воды — всплеск, дальше тонет
    wetStep(n, mx, mz, fx) {
      const M = G.map;
      if (!M.def || !M.def.wet) return;
      if (n.pos.y < 0 && M.waterAt(n.pos.x, n.pos.z) == null) { n.pos.x -= mx; n.pos.z -= mz; n.vel.x *= -0.3; n.vel.z *= -0.3; }
      const wl = M.waterAt(n.pos.x, n.pos.z);
      if (wl == null || n.pos.y > wl) return;
      n.wet = true; n.wl = wl; n.pos.y = wl;
      const sp = n.vel.length();
      n.vel.multiplyScalar(0.2); n.roll = false;
      if (!fx) return;
      if (n.spin) n.spin.multiplyScalar(0.25);
      G.fx.splash(n.pos.x, wl, n.pos.z, Math.min(1.6, 0.6 + sp / 12));
      G.audio.impact(n.pos.x, 0, n.pos.z, false);
    },
    // под водой: сопротивление, медленно тонет до дна канала (≈0.4 м под поверхностью) и лежит
    sink(n, h) {
      n.vel.multiplyScalar(Math.max(0, 1 - 5 * h));
      n.vel.y -= 2.2 * h;
      n.pos.x += n.vel.x * h; n.pos.y += n.vel.y * h; n.pos.z += n.vel.z * h;
      if (G.map.waterAt(n.pos.x, n.pos.z) == null) { n.pos.x -= n.vel.x * h; n.pos.z -= n.vel.z * h; n.vel.x = 0; n.vel.z = 0; }
      if (n.pos.y <= n.wl - 0.4) { n.pos.y = n.wl - 0.4; n.vel.set(0, 0, 0); n.rest = true; }
    },
    // remote — эффект по сигналу сервера: только картинка и звук, урон и ослепление считает сервер
    detonate(n, remote) {
      const g = G.game, x = n.pos.x, z = n.pos.z;
      // 2.0: граната в воде («Лагуна»). Сервер присылает точку под поверхностью; старый сервер — на «полу» y ≈ 0
      const wl = G.map.waterAt(x, z), wet = wl != null && (n.wet || (remote && n.pos.y < 0.2));
      const y = wet ? wl : Math.max(0.05, n.pos.y);
      if (!remote) G.emit('nadeBoom', { n, x, y, z });
      if (wet) return this.detonateWet(n, remote, x, y, z, n.pos.y < -0.2);
      if (remote) {
        if (n.type === 'he') {
          G.fx.explosion(x, y, z, 0.45); G.audio.nadeBoom({ x, z });
          const p = g.player; if (p && p.alive) { const d = Math.hypot(p.pos.x - x, p.pos.z - z); if (d < 22) g.shake = Math.max(g.shake || 0, 0.9 * (1 - d / 22)); }
        } else if (n.type === 'flash') {
          if (this.pop) { this.pop.position.set(x, y + 0.2, z); this.pop.visible = true; this.popT = 0; }
          for (let k = 0; k < 18; k++) G.fx.particle(x, y + 0.1, z, (Math.random() - 0.5) * 9, Math.random() * 6, (Math.random() - 0.5) * 9, 1, 1, 0.92, 1, 0.25, 6);
          G.audio.flashPop({ x, z });
        } else { this.addSmoke(x, z); G.audio.smokeHiss({ x, z }); }
        return;
      }
      if (n.type === 'he') {
        G.fx.explosion(x, y, z, 0.45);
        G.audio.nadeBoom({ x, z });
        g.onNoise(n.owner, x, z, 45);
        const R = 8.5;
        for (const a of g.actors) {
          if (!a.alive) continue;
          if (a !== n.owner && !g.isEnemy(n.owner, a)) continue;
          const cy = a.pos.y + 1.0, d = Math.hypot(a.pos.x - x, cy - y, a.pos.z - z);
          if (d > R) continue;
          if (!G.map.clear(x, y + 0.25, z, a.pos.x, cy, a.pos.z) && !G.map.clear(x, y + 0.25, z, a.pos.x, a.pos.y + a.headY(), a.pos.z)) continue;
          let dmg = 105 * Math.pow(1 - d / R, 1.4);
          if (a === n.owner) dmg *= 0.5;
          if (dmg < 1) continue;
          const dir = new V3(a.pos.x - x, 0.3, a.pos.z - z).normalize();
          a.damage(dmg, n.owner, 'he', false, dir);
          if (n.owner && n.owner.isPlayer && a !== n.owner) G.hud.hitmarker(false, !a.alive);
        }
        const p = g.player;
        if (p && p.alive) { const d = Math.hypot(p.pos.x - x, p.pos.z - z); if (d < 22) g.shake = Math.max(g.shake || 0, 0.9 * (1 - d / 22)); }
        if (g.mode === 'tutorial' && n.owner && n.owner.isPlayer) G.tutorial.onBoom(x, z);
      } else if (n.type === 'flash') {
        if (this.pop) { this.pop.position.set(x, y + 0.2, z); this.pop.visible = true; this.popT = 0; }
        for (let k = 0; k < 18; k++) G.fx.particle(x, y + 0.1, z, (Math.random() - 0.5) * 9, Math.random() * 6, (Math.random() - 0.5) * 9, 1, 1, 0.92, 1, 0.25, 6);
        G.audio.flashPop({ x, z });
        g.onNoise(n.owner, x, z, 30);
        for (const a of g.actors) {
          if (!a.alive) continue;
          const ex = a.pos.x, ey = a.pos.y + a.eyeH(), ez = a.pos.z;
          const dx = x - ex, dy = y + 0.2 - ey, dz = z - ez, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (d > 34) continue;
          if (!G.map.clear(x, y + 0.25, z, ex, ey, ez) || this.blocks(x, y + 0.25, z, ex, ey, ez)) continue;
          const cp = Math.cos(a.pitch), fx = -Math.sin(a.yaw) * cp, fy = Math.sin(a.pitch), fz = -Math.cos(a.yaw) * cp;
          const dot = (dx * fx + dy * fy + dz * fz) / (d || 1);
          let k = Math.pow(1 - d / 34, 0.55) * (dot > 0.55 ? 1 : dot > 0 ? 0.6 : dot > -0.4 ? 0.3 : 0.12);
          if (!a.isPlayer && n.owner && (a === n.owner || (a.team === n.owner.team && g.mode !== 'ffa'))) continue; // свои боты знают о вспышке и отворачиваются
          const T = 0.35 + k * 4.6;
          if (a.net) { a.blindT = Math.max(a.blindT || 0, T); G.emit('blind', { a, T, k }); if (n.owner && n.owner.isPlayer && g.isEnemy(n.owner, a) && k > 0.3) G.bp.ev('blind', { a: n.owner }); }
          else if (a.isPlayer) {
            g.blindT = Math.max(g.blindT || 0, T); g.blindMax = Math.max(g.blindT, g.blindMax || 0);
            G.audio.ring(k);
          } else {
            a.blindT = Math.max(a.blindT || 0, T * 0.9);
            if (k > 0.3) { a.tVisible = false; a.path = null; G.chat.event('flash', { a }); if (n.owner && n.owner.isPlayer && g.isEnemy(n.owner, a)) G.bp.ev('blind', { a: n.owner }); }
          }
        }
      } else {
        this.addSmoke(x, z);
        G.audio.smokeHiss({ x, z });
        if (n.owner && !n.owner.isPlayer) G.chat.event('smoke', { a: n.owner });
      }
    },
    // 2.0: в воде осколочная поднимает столб воды (вода гасит осколки — урон вдвое меньше), светошумовая хлопает
    // глухо и не слепит, дымовая шипит и гаснет без завесы. sunk — сервер подтвердил, что граната под водой
    detonateWet(n, remote, x, y, z, sunk) {
      const g = G.game;
      if (n.type === 'he') {
        G.fx.geyser(x, y, z); G.audio.nadeBoom({ x, z }); G.audio.impact(x, 0, z, false);
        const p = g.player; if (p && p.alive) { const d = Math.hypot(p.pos.x - x, p.pos.z - z); if (d < 18) g.shake = Math.max(g.shake || 0, 0.6 * (1 - d / 18)); }
        if (remote) return;
        g.onNoise(n.owner, x, z, 40);
        const R = 8.5;
        for (const a of g.actors) {
          if (!a.alive || (a !== n.owner && !g.isEnemy(n.owner, a))) continue;
          const cy = a.pos.y + 1.0, d = Math.hypot(a.pos.x - x, cy - y, a.pos.z - z);
          if (d > R) continue;
          if (!G.map.clear(x, y + 0.25, z, a.pos.x, cy, a.pos.z) && !G.map.clear(x, y + 0.25, z, a.pos.x, a.pos.y + a.headY(), a.pos.z)) continue;
          let dmg = 0.5 * 105 * Math.pow(1 - d / R, 1.4);
          if (a === n.owner) dmg *= 0.5;
          if (dmg < 1) continue;
          a.damage(dmg, n.owner, 'he', false, new V3(a.pos.x - x, 0.3, a.pos.z - z).normalize());
          if (n.owner && n.owner.isPlayer && a !== n.owner) G.hud.hitmarker(false, !a.alive);
        }
        return;
      }
      if (n.type === 'smoke' && remote && !sunk) { this.addSmoke(x, z); G.audio.smokeHiss({ x, z }); return; } // старый сервер: завеса есть
      G.fx.splash(x, y, z, n.type === 'flash' ? 1.4 : 0.8);
      for (let k = 0; k < 10; k++) G.fx.particle(x + (Math.random() - 0.5) * 0.6, y + 0.05, z + (Math.random() - 0.5) * 0.6, (Math.random() - 0.5) * 0.4, 0.5 + Math.random() * 0.8, (Math.random() - 0.5) * 0.4, 0.92, 0.94, 0.95, 0.45, 1.2 + Math.random(), -0.2, y);
      G.audio.impact(x, 0, z, false);
      if (!remote) g.onNoise(n.owner, x, z, 14);
    },
    addSmoke(x, z) {
      // свободные клубы — из самой старой завесы, если не хватает
      const used = new Set(); for (const s of this.smokes) for (const i of s.idx) used.add(i);
      let free = []; for (let i = 0; i < this.M && free.length < PUFFS; i++) if (!used.has(i)) free.push(i);
      if (free.length < PUFFS && this.smokes.length) { const old = this.smokes.shift(); free = free.concat(old.idx).slice(0, PUFFS); }
      const s = { x, z, t: 0, idx: free, off: [] };
      if (G.HEADLESS || !this.sGeo) { s.idx = []; this.smokes.push(s); return; }
      for (const i of free) {
        const a = Math.random() * 6.28, r = Math.sqrt(Math.random()) * SMOKE_R * 0.72;
        s.off.push([Math.cos(a) * r, 0.5 + Math.random() * 2.3, Math.sin(a) * r, 3.4 + Math.random() * 1.6, Math.random() * 6.28]);
        this.sShade[i] = 0.55 + Math.random() * 0.45;
      }
      this.sGeo.attributes.shade.needsUpdate = true;
      this.smokes.push(s); this.sPts.visible = true;
    },
    updateSmokes(dt) {
      if (!this.smokes.length && !this._smk) return;
      const P = this.sPos, S = this.sSize, A = this.sA;
      for (let j = this.smokes.length - 1; j >= 0; j--) {
        const s = this.smokes[j];
        s.t += dt;
        const grow = 1 - Math.pow(1 - Math.min(1, s.t / 1.8), 3);
        const fade = s.t > SMOKE_DUR - 3 ? Math.max(0, (SMOKE_DUR - s.t) / 3) : 1;
        s.dens = Math.min(1, s.t / 0.9) * fade;
        s.idx.forEach((i, k) => {
          const o = s.off[k], w = s.t * 0.06 + o[4];
          const dx = o[0] * grow + Math.cos(w) * 0.3, dz = o[2] * grow + Math.sin(w) * 0.3;
          P[i * 3] = s.x + dx; P[i * 3 + 1] = 0.4 + (o[1] - 0.4) * (0.4 + 0.6 * grow) + s.t * 0.012; P[i * 3 + 2] = s.z + dz;
          S[i] = o[3] * (0.35 + 0.65 * grow); A[i] = 0.82 * s.dens;
        });
        if (s.t >= SMOKE_DUR) { for (const i of s.idx) { A[i] = 0; P[i * 3 + 1] = -999; } this.smokes.splice(j, 1); }
      }
      if (!this.sGeo) { this._smk = this.smokes.length > 0; return; }
      const at = this.sGeo.attributes;
      at.position.needsUpdate = true; at.size.needsUpdate = true; at.alpha.needsUpdate = true;
      this._smk = this.smokes.length > 0; this.sPts.visible = this._smk;
    },
    // отрезок проходит сквозь плотную часть завесы?
    blocks(ax, ay, az, bx, by, bz) {
      for (const s of this.smokes) {
        if ((s.dens || 0) < 0.45) continue;
        const R = SMOKE_R * 0.86 * Math.min(1, 0.4 + s.t / 1.5), cy = 1.5, k = R / SMOKE_H;
        // эллипсоид → сфера: растягиваем ось Y
        const px = ax - s.x, py = (ay - cy) * k, pz = az - s.z;
        const dx = bx - ax, dy = (by - ay) * k, dz = bz - az;
        const L2 = dx * dx + dy * dy + dz * dz;
        let t = L2 > 0 ? -(px * dx + py * dy + pz * dz) / L2 : 0;
        t = Math.max(0, Math.min(1, t));
        const qx = px + dx * t, qy = py + dy * t, qz = pz + dz * t;
        if (qx * qx + qy * qy + qz * qz < R * R * 0.8) return true;
      }
      return false;
    },
    // насколько камера внутри дыма (0..1)
    density(x, y, z) {
      let best = 0;
      for (const s of this.smokes) {
        const R = SMOKE_R * Math.min(1, 0.4 + s.t / 1.5), k = R / SMOKE_H;
        const d = Math.hypot(x - s.x, (y - 1.5) * k, z - s.z) / R;
        if (d < 1) best = Math.max(best, (1 - d) * 1.6 * (s.dens || 0));
      }
      return Math.min(1, best);
    }
  };
})(window.G);
