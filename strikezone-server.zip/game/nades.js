'use strict';
/* Гранаты: полёт с отскоками, осколочный взрыв, ослепление, дымовая завеса (закрывает обзор ботам и игроку) */
(function (G) {
  const V3 = THREE.Vector3;
  const GRAV = 17;
  const FUSE = { he: 1.6, flash: 1.45, smoke: 1.9 };
  const SMOKE_R = 4.3, SMOKE_H = 1.9, SMOKE_DUR = 16, PUFFS = 26;
  const _v = new V3();

  const N = G.nades = {
    list: [], smokes: [],
    init(scene) {
      this.scene = scene;
      this.geo = {};
      // облака дыма: все клубы — одни точки с размером и прозрачностью на вершину
      const M = this.M = PUFFS * 5;
      this.sPos = new Float32Array(M * 3); this.sSize = new Float32Array(M); this.sA = new Float32Array(M); this.sShade = new Float32Array(M);
      for (let i = 0; i < M; i++) this.sPos[i * 3 + 1] = -999;
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(this.sPos, 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('size', new THREE.BufferAttribute(this.sSize, 1).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('alpha', new THREE.BufferAttribute(this.sA, 1).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('shade', new THREE.BufferAttribute(this.sShade, 1));
      this.sGeo = g;
      const mat = this.sMat = new THREE.ShaderMaterial({
        uniforms: { map: { value: G.tex('puff') }, scale: { value: 500 }, lit: { value: new THREE.Color('#e2e1dc') }, dark: { value: new THREE.Color('#7f8287') } },
        vertexShader: 'attribute float size; attribute float alpha; attribute float shade; uniform float scale; varying float vA; varying float vS;' +
          'void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = size * scale / max(0.35, -mv.z); gl_Position = projectionMatrix * mv; vA = alpha; vS = shade; }',
        fragmentShader: 'uniform sampler2D map; uniform vec3 lit; uniform vec3 dark; varying float vA; varying float vS;' +
          'void main(){ vec4 t = texture2D(map, gl_PointCoord); float a = t.a * vA; if (a < 0.01) discard; gl_FragColor = vec4(mix(dark, lit, vS) * (0.82 + 0.18 * t.r), a); }',
        transparent: true, depthWrite: false
      });
      const pts = this.sPts = new THREE.Points(g, mat);
      pts.frustumCulled = false;
      const dbs = new THREE.Vector2();
      pts.onBeforeRender = (r, s, cam) => { r.getDrawingBufferSize(dbs); mat.uniforms.scale.value = dbs.y / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov || 60) / 2)); };
      scene.add(pts);
      // вспышка светошумовой
      this.pop = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('flare'), color: 0xffffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      this.pop.visible = false; this.popT = 0; scene.add(this.pop);
    },
    reset() {
      if (G.HEADLESS || !this.sGeo) { this.list = []; this.smokes = []; return; }
      for (const n of this.list) if (n.mesh) this.scene.remove(n.mesh);
      this.list = []; this.smokes = [];
      for (let i = 0; i < this.M; i++) { this.sA[i] = 0; this.sPos[i * 3 + 1] = -999; }
      this.sGeo.attributes.position.needsUpdate = true; this.sGeo.attributes.alpha.needsUpdate = true;
      this.pop.visible = false;
    },
    setEnv(env) {
      const lit = new THREE.Color('#e6e4de').lerp(new THREE.Color(env.sun), 0.22);
      this.sMat.uniforms.lit.value.copy(lit);
      this.sMat.uniforms.dark.value.copy(new THREE.Color('#7d8086').lerp(new THREE.Color(env.hemiGround), 0.2));
    },
    model(type) {
      if (!this.geo[type]) this.geo[type] = G.geo.build(G.gunParts(type).body);
      return this.geo[type];
    },
    // запустить гранату из рук: скорость задаётся вектором
    spawn(a, type, ox, oy, oz, vx, vy, vz, nid, visual) {
      let mesh = null;
      if (!G.HEADLESS && this.scene) {
        mesh = new THREE.Mesh(this.model(type), G.getVCMat());
        mesh.position.set(ox, oy, oz); mesh.castShadow = false;
        this.scene.add(mesh);
      }
      const n = { type, owner: a, team: a ? a.team : 0, pos: new V3(ox, oy, oz), vel: new V3(vx, vy, vz), t: 0, mesh, rest: false, spin: new V3(Math.random() * 12 - 6, Math.random() * 6, 8 + Math.random() * 6), heard: false, id: nid != null ? nid : (this.nid = (this.nid || 0) + 1), visual: !!visual };
      this.list.push(n);
      if (!visual) G.emit('nadeSpawn', { n, o: [ox, oy, oz], v: [vx, vy, vz] });
      G.audio.nadeThrow(a && !a.isPlayer ? a.pos : null);
      if (a && a.isPlayer && !a.net && !visual && G.game.mode !== 'tutorial') G.bp.ev('nade');
      return n;
    },
    // сетевая игра: граната взорвалась у сервера — убрать её копию и показать эффект
    remoteBoom(id, type, x, y, z) {
      const i = this.list.findIndex(n => n.id === id && n.visual);
      const n = i >= 0 ? this.list[i] : { type, owner: null, pos: new V3() };
      if (i >= 0) { if (n.mesh) this.scene.remove(n.mesh); this.list.splice(i, 1); }
      n.pos.set(x, y, z); n.type = type;
      this.detonate(n, true);
    },
    // бросок игрока: по направлению взгляда, чуть вверх
    throwFrom(a, type) {
      const cp = Math.cos(a.pitch + 0.09);
      const dx = -Math.sin(a.yaw) * cp, dy = Math.sin(a.pitch + 0.09), dz = -Math.cos(a.yaw) * cp;
      const rx = Math.cos(a.yaw), rz = -Math.sin(a.yaw);
      const ey = a.pos.y + a.eyeH() - 0.12;
      let ox = a.pos.x + dx * 0.35 + rx * 0.14, oz = a.pos.z + dz * 0.35 + rz * 0.14;
      // не выпускать гранату внутри стены
      if (!G.map.clear(a.pos.x, ey, a.pos.z, ox, ey, oz)) { ox = a.pos.x; oz = a.pos.z; }
      const sp = 16.5;
      const vx = dx * sp + a.vel.x * 0.6, vy = dy * sp + 1.2 + Math.max(0, a.vel.y) * 0.4, vz = dz * sp + a.vel.z * 0.6;
      // онлайн: гранату запускает сервер, его копия прилетит обратно событием
      if (G.net && G.net.active && a === G.game.player) { G.net.throwNade(a, type, ox, ey, oz, vx, vy, vz); return; }
      this.spawn(a, type, ox, ey, oz, vx, vy, vz);
    },
    // бросок бота в точку: подбираем навесную траекторию, проверяем, что она не упирается в стены
    throwAt(a, type, tx, ty, tz) {
      if (!a.nades || !(a.nades[type] > 0)) return false;
      // если прямой бросок не проходит — пробуем точку ближе к себе или чуть в сторону (граната докатится)
      const bx = a.pos.x - tx, bz = a.pos.z - tz, bl = Math.hypot(bx, bz) || 1, ux = bx / bl, uz = bz / bl;
      const C = [[0, 0], [2.5, 0], [0, 2.8], [0, -2.8], [5, 0], [3, 3], [3, -3]];
      for (const [f, s] of C) {
        if (f >= bl - 3) continue;
        if (this.tryThrow(a, type, tx + ux * f - uz * s, ty, tz + uz * f + ux * s)) return true;
      }
      return false;
    },
    tryThrow(a, type, tx, ty, tz) {
      const ox = a.pos.x, oy = a.pos.y + 1.5, oz = a.pos.z;
      const dx = tx - ox, dz = tz - oz, d = Math.hypot(dx, dz), h = ty - oy;
      if (d < 2) return false;
      const v = Math.min(17, 7 + d * 0.55), v2 = v * v, disc = v2 * v2 - GRAV * (GRAV * d * d + 2 * h * v2);
      if (disc < 0) return false;
      const sq = Math.sqrt(disc);
      for (const th of [Math.atan((v2 - sq) / (GRAV * d)), Math.atan((v2 + sq) / (GRAV * d))]) {
        if (th > 1.25) continue;
        const vh = v * Math.cos(th), vy = v * Math.sin(th), T = d / vh;
        let ok = true, px = ox, py = oy, pz = oz;
        for (let i = 1; i <= 10 && ok; i++) {
          const t = T * i / 10, nx = ox + dx / d * vh * t, ny = oy + vy * t - GRAV * t * t / 2, nz = oz + dz / d * vh * t;
          if (i < 10 && !G.map.clear(px, py, pz, nx, ny, nz)) ok = false;
          if (ny > 9) ok = false;
          px = nx; py = ny; pz = nz;
        }
        if (!ok) continue;
        a.yaw = Math.atan2(-dx, -dz);
        this.spawn(a, type, ox + dx / d * 0.4, oy, oz + dz / d * 0.4, dx / d * vh, vy, dz / d * vh);
        a.nades[type]--;
        return true;
      }
      return false;
    },
    update(dt) {
      const g = G.game;
      for (let i = this.list.length - 1; i >= 0; i--) {
        const n = this.list[i];
        n.t += dt;
        if (!n.rest) {
          // два подшага — надёжнее отскоки от тонких стен
          for (let s = 0; s < 2; s++) {
            const h2 = dt / 2;
            n.vel.y -= GRAV * h2;
            const mx = n.vel.x * h2, my = n.vel.y * h2, mz = n.vel.z * h2, len = Math.sqrt(mx * mx + my * my + mz * mz);
            if (len < 1e-5) continue;
            const hit = G.map.ray(n.pos.x, n.pos.y, n.pos.z, mx / len, my / len, mz / len, len + 0.05);
            if (hit) {
              n.pos.x += mx / len * Math.max(0, hit.t - 0.05); n.pos.y += my / len * Math.max(0, hit.t - 0.05); n.pos.z += mz / len * Math.max(0, hit.t - 0.05);
              const vn = n.vel.x * hit.nx + n.vel.y * hit.ny + n.vel.z * hit.nz;
              const sp = n.vel.length();
              n.vel.x -= 1.45 * vn * hit.nx; n.vel.y -= 1.45 * vn * hit.ny; n.vel.z -= 1.45 * vn * hit.nz;
              n.vel.multiplyScalar(hit.ny > 0.5 ? 0.62 : 0.72);
              n.spin.multiplyScalar(0.6);
              if (sp > 2.2) G.audio.bounce(n.pos, Math.min(1, sp / 12));
              if (hit.ny > 0.5 && n.vel.length() < 0.9) { n.rest = true; n.vel.set(0, 0, 0); n.pos.y = Math.max(n.pos.y, 0.03); break; }
            } else { n.pos.x += mx; n.pos.y += my; n.pos.z += mz; }
          }
          if (n.mesh) { n.mesh.rotation.x += n.spin.x * dt; n.mesh.rotation.y += n.spin.y * dt; n.mesh.rotation.z += n.spin.z * dt; }
          if (n.pos.y < -5) n.t = 99;
        }
        if (n.mesh) n.mesh.position.set(n.pos.x, n.pos.y + (n.rest ? 0.03 : 0), n.pos.z);
        // противники слышат упавшую рядом гранату
        if (!n.heard && !n.visual && n.owner && (n.rest || n.t > 0.8)) { n.heard = true; g.onNoise(n.owner, n.pos.x, n.pos.z, 12); }
        const fuse = FUSE[n.type];
        // копия сетевой гранаты ждёт сигнала сервера (с запасом — если сигнал потерялся)
        if (n.visual) { if (n.t > fuse + 3) { if (n.mesh) this.scene.remove(n.mesh); this.list.splice(i, 1); } continue; }
        if (n.t >= fuse || (n.type === 'smoke' && n.rest && n.t > 0.7)) {
          this.detonate(n);
          if (n.mesh) this.scene.remove(n.mesh);
          this.list.splice(i, 1);
        }
      }
      this.updateSmokes(dt);
      if (this.pop && this.pop.visible) {
        this.popT += dt;
        const k = this.popT / 0.28;
        this.pop.scale.setScalar(2 + k * 9); this.pop.material.opacity = Math.max(0, 1 - k);
        if (k >= 1) this.pop.visible = false;
      }
    },
    // remote — эффект по сигналу сервера: только картинка и звук, урон и ослепление считает сервер
    detonate(n, remote) {
      const g = G.game, x = n.pos.x, y = Math.max(0.05, n.pos.y), z = n.pos.z;
      if (!remote) G.emit('nadeBoom', { n, x, y, z });
      if (remote) {
        if (n.type === 'he') {
          G.fx.explosion(x, y, z, 0.45); G.audio.nadeBoom({ x, z });
          const p = g.player; if (p && p.alive) { const d = Math.hypot(p.pos.x - x, p.pos.z - z); if (d < 22) g.shake = Math.max(g.shake || 0, 0.9 * (1 - d / 22)); }
        } else if (n.type === 'flash') {
          if (this.pop) { this.pop.position.set(x, y + 0.2, z); this.pop.visible = true; this.popT = 0; }
          for (let k = 0; k < 18; k++) G.fx.particle(x, y + 0.1, z, (Math.random() - 0.5) * 9, Math.random() * 6, (Math.random() - 0.5) * 9, 1, 1, 0.92, 1, 0.25, 6);
          G.audio.flashPop({ x, z });
        } else { this.addSmoke(x, z); G.audio.smokeHiss({ x, z }); }
        return;
      }
      if (n.type === 'he') {
        G.fx.explosion(x, y, z, 0.45);
        G.audio.nadeBoom({ x, z });
        g.onNoise(n.owner, x, z, 45);
        const R = 8.5;
        for (const a of g.actors) {
          if (!a.alive) continue;
          if (a !== n.owner && !g.isEnemy(n.owner, a)) continue;
          const cy = a.pos.y + 1.0, d = Math.hypot(a.pos.x - x, cy - y, a.pos.z - z);
          if (d > R) continue;
          if (!G.map.clear(x, y + 0.25, z, a.pos.x, cy, a.pos.z) && !G.map.clear(x, y + 0.25, z, a.pos.x, a.pos.y + a.headY(), a.pos.z)) continue;
          let dmg = 105 * Math.pow(1 - d / R, 1.4);
          if (a === n.owner) dmg *= 0.5;
          if (dmg < 1) continue;
          const dir = new V3(a.pos.x - x, 0.3, a.pos.z - z).normalize();
          a.damage(dmg, n.owner, 'he', false, dir);
          if (n.owner && n.owner.isPlayer && a !== n.owner) G.hud.hitmarker(false, !a.alive);
        }
        const p = g.player;
        if (p && p.alive) { const d = Math.hypot(p.pos.x - x, p.pos.z - z); if (d < 22) g.shake = Math.max(g.shake || 0, 0.9 * (1 - d / 22)); }
        if (g.mode === 'tutorial' && n.owner && n.owner.isPlayer) G.tutorial.onBoom(x, z);
      } else if (n.type === 'flash') {
        if (this.pop) { this.pop.position.set(x, y + 0.2, z); this.pop.visible = true; this.popT = 0; }
        for (let k = 0; k < 18; k++) G.fx.particle(x, y + 0.1, z, (Math.random() - 0.5) * 9, Math.random() * 6, (Math.random() - 0.5) * 9, 1, 1, 0.92, 1, 0.25, 6);
        G.audio.flashPop({ x, z });
        g.onNoise(n.owner, x, z, 30);
        for (const a of g.actors) {
          if (!a.alive) continue;
          const ex = a.pos.x, ey = a.pos.y + a.eyeH(), ez = a.pos.z;
          const dx = x - ex, dy = y + 0.2 - ey, dz = z - ez, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (d > 34) continue;
          if (!G.map.clear(x, y + 0.25, z, ex, ey, ez) || this.blocks(x, y + 0.25, z, ex, ey, ez)) continue;
          const cp = Math.cos(a.pitch), fx = -Math.sin(a.yaw) * cp, fy = Math.sin(a.pitch), fz = -Math.cos(a.yaw) * cp;
          const dot = (dx * fx + dy * fy + dz * fz) / (d || 1);
          let k = Math.pow(1 - d / 34, 0.55) * (dot > 0.55 ? 1 : dot > 0 ? 0.6 : dot > -0.4 ? 0.3 : 0.12);
          if (!a.isPlayer && n.owner && (a === n.owner || (a.team === n.owner.team && g.mode !== 'ffa'))) continue; // свои боты знают о вспышке и отворачиваются
          const T = 0.35 + k * 4.6;
          if (a.net) { a.blindT = Math.max(a.blindT || 0, T); G.emit('blind', { a, T, k }); if (n.owner && n.owner.isPlayer && g.isEnemy(n.owner, a) && k > 0.3) G.bp.ev('blind', { a: n.owner }); }
          else if (a.isPlayer) {
            g.blindT = Math.max(g.blindT || 0, T); g.blindMax = Math.max(g.blindT, g.blindMax || 0);
            G.audio.ring(k);
          } else {
            a.blindT = Math.max(a.blindT || 0, T * 0.9);
            if (k > 0.3) { a.tVisible = false; a.path = null; G.chat.event('flash', { a }); if (n.owner && n.owner.isPlayer && g.isEnemy(n.owner, a)) G.bp.ev('blind', { a: n.owner }); }
          }
        }
      } else {
        this.addSmoke(x, z);
        G.audio.smokeHiss({ x, z });
        if (n.owner && !n.owner.isPlayer) G.chat.event('smoke', { a: n.owner });
      }
    },
    addSmoke(x, z) {
      // свободные клубы — из самой старой завесы, если не хватает
      const used = new Set(); for (const s of this.smokes) for (const i of s.idx) used.add(i);
      let free = []; for (let i = 0; i < this.M && free.length < PUFFS; i++) if (!used.has(i)) free.push(i);
      if (free.length < PUFFS && this.smokes.length) { const old = this.smokes.shift(); free = free.concat(old.idx).slice(0, PUFFS); }
      const s = { x, z, t: 0, idx: free, off: [] };
      if (G.HEADLESS || !this.sGeo) { s.idx = []; this.smokes.push(s); return; }
      for (const i of free) {
        const a = Math.random() * 6.28, r = Math.sqrt(Math.random()) * SMOKE_R * 0.72;
        s.off.push([Math.cos(a) * r, 0.5 + Math.random() * 2.3, Math.sin(a) * r, 3.4 + Math.random() * 1.6, Math.random() * 6.28]);
        this.sShade[i] = 0.55 + Math.random() * 0.45;
      }
      this.sGeo.attributes.shade.needsUpdate = true;
      this.smokes.push(s);
    },
    updateSmokes(dt) {
      if (!this.smokes.length && !this._smk) return;
      const P = this.sPos, S = this.sSize, A = this.sA;
      for (let j = this.smokes.length - 1; j >= 0; j--) {
        const s = this.smokes[j];
        s.t += dt;
        const grow = 1 - Math.pow(1 - Math.min(1, s.t / 1.8), 3);
        const fade = s.t > SMOKE_DUR - 3 ? Math.max(0, (SMOKE_DUR - s.t) / 3) : 1;
        s.dens = Math.min(1, s.t / 0.9) * fade;
        s.idx.forEach((i, k) => {
          const o = s.off[k], w = s.t * 0.06 + o[4];
          const dx = o[0] * grow + Math.cos(w) * 0.3, dz = o[2] * grow + Math.sin(w) * 0.3;
          P[i * 3] = s.x + dx; P[i * 3 + 1] = 0.4 + (o[1] - 0.4) * (0.4 + 0.6 * grow) + s.t * 0.012; P[i * 3 + 2] = s.z + dz;
          S[i] = o[3] * (0.35 + 0.65 * grow); A[i] = 0.82 * s.dens;
        });
        if (s.t >= SMOKE_DUR) { for (const i of s.idx) { A[i] = 0; P[i * 3 + 1] = -999; } this.smokes.splice(j, 1); }
      }
      if (!this.sGeo) { this._smk = this.smokes.length > 0; return; }
      const at = this.sGeo.attributes;
      at.position.needsUpdate = true; at.size.needsUpdate = true; at.alpha.needsUpdate = true;
      this._smk = this.smokes.length > 0;
    },
    // отрезок проходит сквозь плотную часть завесы?
    blocks(ax, ay, az, bx, by, bz) {
      for (const s of this.smokes) {
        if ((s.dens || 0) < 0.45) continue;
        const R = SMOKE_R * 0.86 * Math.min(1, 0.4 + s.t / 1.5), cy = 1.5, k = R / SMOKE_H;
        // эллипсоид → сфера: растягиваем ось Y
        const px = ax - s.x, py = (ay - cy) * k, pz = az - s.z;
        const dx = bx - ax, dy = (by - ay) * k, dz = bz - az;
        const L2 = dx * dx + dy * dy + dz * dz;
        let t = L2 > 0 ? -(px * dx + py * dy + pz * dz) / L2 : 0;
        t = Math.max(0, Math.min(1, t));
        const qx = px + dx * t, qy = py + dy * t, qz = pz + dz * t;
        if (qx * qx + qy * qy + qz * qz < R * R * 0.8) return true;
      }
      return false;
    },
    // насколько камера внутри дыма (0..1)
    density(x, y, z) {
      let best = 0;
      for (const s of this.smokes) {
        const R = SMOKE_R * Math.min(1, 0.4 + s.t / 1.5), k = R / SMOKE_H;
        const d = Math.hypot(x - s.x, (y - 1.5) * k, z - s.z) / R;
        if (d < 1) best = Math.max(best, (1 - d) * 1.6 * (s.dens || 0));
      }
      return Math.min(1, best);
    }
  };
})(window.G);
