'use strict';
/* Карты: описание, постройка геометрии, столкновения и лучи. Активная карта — G.map */
(function (G) {
  const HP = Math.PI / 2;

  // ---------- конструктор описания карты ----------
  // все координаты раскладки умножаются на масштаб карты sc (размеры ящиков, бочек, высоты — нет)
  function makeApi(sc) {
    sc = sc || 1;
    const S = (v) => v * sc;
    const api = { boxes: [], decor: [], lamps: [], letters: [], sc };
    const rawB = (x0, z0, x1, z1, h, mat, y0, opts) => {
      opts = opts || {};
      api.boxes.push({
        x0: Math.min(x0, x1), z0: Math.min(z0, z1), x1: Math.max(x0, x1), z1: Math.max(z0, z1),
        y0: y0 || 0, y1: (y0 || 0) + h, mat, solid: opts.solid !== false, hidden: !!opts.hidden, uv: opts.uv || 'world',
        // tint — оттенок штукатурки (один материал, разные цвета); nr — не задерживает пули и взгляд (вода); ch — фаска
        tint: opts.tint || null, nr: !!opts.nr, ch: opts.ch || 0
      });
    };
    api.B = (x0, z0, x1, z1, h, mat, y0, opts) => rawB(S(x0), S(z0), S(x1), S(z1), h, mat, y0, opts);
    api.crate = (cx, cz, s, y0) => rawB(S(cx) - s / 2, S(cz) - s / 2, S(cx) + s / 2, S(cz) + s / 2, s, 'crate', y0 || 0, { uv: 'face' });
    api.stack = (cx, cz, s) => { api.crate(cx, cz, s); api.crate(cx + 0.08 / sc, cz - 0.05 / sc, s * 0.8, s); };
    api.lintel = (x0, z0, x1, z1, yb, yt, mat) => api.B(x0, z0, x1, z1, yt - yb, mat, yb);
    // декор: позиция масштабируется; DS — ещё и размеры по X/Z (кран, корабль)
    api.D = (...parts) => { for (const p of parts) { p.x = S(p.x || 0); p.z = S(p.z || 0); api.decor.push(p); } };
    api.DS = (...parts) => { for (const p of parts) { p.x = S(p.x || 0); p.z = S(p.z || 0); if (p.w) p.w *= sc; if (p.d) p.d *= sc; api.decor.push(p); } };
    api.barrel = (x, z, color) => {
      x = S(x); z = S(z);
      rawB(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 0.95, 'none', 0, { hidden: true });
      api.decor.push(G.geo.cyl(0.3, 0.95, x, 0.475, z, color || '#2f5f8a', 0, 0, 0, 12));
      api.decor.push(G.geo.cyl(0.31, 0.05, x, 0.3, z, '#222'), G.geo.cyl(0.31, 0.05, x, 0.68, z, '#222'));
    };
    api.lamp = (x, z, h, armDir) => {
      x = S(x); z = S(z);
      const d = armDir || 0;
      api.decor.push(G.geo.cyl(0.09, h, x, h / 2, z, '#3a3d40', 0, 0, 0, 8));
      api.decor.push(G.geo.box(0.1, 0.1, 1.2, x + Math.sin(d) * 0.55, h, z + Math.cos(d) * 0.55, '#3a3d40', 0, d, 0));
      api.decor.push(G.geo.box(0.36, 0.14, 0.5, x + Math.sin(d) * 1.1, h - 0.08, z + Math.cos(d) * 1.1, '#2a2c2e', 0, d, 0));
      api.lamps.push([x + Math.sin(d) * 1.1, h - 0.2, z + Math.cos(d) * 1.1]);
      rawB(x - 0.12, z - 0.12, x + 0.12, z + 0.12, h, 'none', 0, { hidden: true });
    };
    api.letter = (ch, x, z, size, rotY) => api.letters.push({ ch, x: S(x), z: S(z), size: size || 5, rotY: rotY || 0 });
    // наклейка на стену из атласа фасадов: n — '+x' | '-x' | '+z' | '-z'
    api.decals = []; api.awnings = []; api.fronds = []; api.ground = []; api.roofs = []; api.trees = []; api.blossoms = [];
    // hi — мелкие детали и пейзаж за стенами: строятся отдельным мешем и видны только на высоком качестве
    api.hi = []; api.lo = [];
    api.decal = (cell, x, y, z, w, h, n, atlas) => api.decals.push({ cell, x: S(x), y, z: S(z), w, h, n, atlas: atlas || 'facade', lit: cell === 5 });
    api.awning = (x, y, z, w, depth, n, col) => api.awnings.push({ x: S(x), y, z: S(z), w: w * sc, depth, n, col });
    api.palm = (x, z, h) => {
      x = S(x); z = S(z); h = h || 6.5;
      rawB(x - 0.25, z - 0.25, x + 0.25, z + 0.25, h, 'none', 0, { hidden: true });
      const lean = Math.random() * 6.28, segs = 6;
      let px = x, pz = z, py = 0;
      for (let i = 0; i < segs; i++) {
        const t = i / segs, sh = h / segs;
        const ox = Math.cos(lean) * 0.12 * (i + 1) * t, oz = Math.sin(lean) * 0.12 * (i + 1) * t;
        api.decor.push(G.geo.cyl(0.2 - t * 0.06, sh * 1.02, x + ox, py + sh / 2, z + oz, i % 2 ? '#7a6248' : '#6a543c', 0, 0, 0, 8, 0.22 - t * 0.06));
        api.decor.push(G.geo.cyl(0.23 - t * 0.06, 0.08, x + ox, py + sh * 0.95, z + oz, '#5a4632', 0, 0, 0, 8));
        px = x + ox; pz = z + oz; py += sh;
      }
      api.fronds.push({ x: px, y: py, z: pz, n: 9 });
    };
    api.wire = (a, b, sag) => {
      a = [S(a[0]), a[1], S(a[2])]; b = [S(b[0]), b[1], S(b[2])];
      const n = 6;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n;
        const p0 = [a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0 - Math.sin(t0 * Math.PI) * sag, a[2] + (b[2] - a[2]) * t0];
        const p1 = [a[0] + (b[0] - a[0]) * t1, a[1] + (b[1] - a[1]) * t1 - Math.sin(t1 * Math.PI) * sag, a[2] + (b[2] - a[2]) * t1];
        api.decor.push(G.limb(p0, p1, 0.025, '#1c1c1c'));
      }
    };
    api.pole = (x, z, h) => {
      const X = S(x), Z = S(z);
      api.decor.push(G.geo.cyl(0.11, h, X, h / 2, Z, '#5a4430', 0, 0, 0, 8), G.geo.box(1.4, 0.1, 0.1, X, h - 0.4, Z, '#5a4430'));
      api.decor.push(G.geo.cyl(0.04, 0.12, X - 0.55, h - 0.3, Z, '#cfcfcf'), G.geo.cyl(0.04, 0.12, X + 0.55, h - 0.3, Z, '#cfcfcf'));
      rawB(X - 0.15, Z - 0.15, X + 0.15, Z + 0.15, h, 'none', 0, { hidden: true });
      return [x, h - 0.3, z];
    };
    api.sandbags = (x, z, len, rotY, rows) => {
      x = S(x); z = S(z); rows = rows || 2;
      const c = Math.cos(rotY), sn = Math.sin(rotY), n = Math.max(2, Math.round(len / 0.55));
      for (let r = 0; r < rows; r++) for (let i = 0; i < n - (r % 2); i++) {
        const o = -len / 2 + 0.28 + i * 0.55 + (r % 2) * 0.27;
        api.decor.push({ sph: true, r: 0.3, x: x + c * o, y: 0.13 + r * 0.22, z: z - sn * o, ry: rotY + (Math.random() - 0.5) * 0.12, sx: 0.98, sy: 0.46, sz: 0.72, color: ['#a8946a', '#9a865e', '#b09c72'][(i + r) % 3], seg: 9 });
      }
      const hx = Math.abs(c) * len / 2 + Math.abs(sn) * 0.3, hz = Math.abs(sn) * len / 2 + Math.abs(c) * 0.3;
      rawB(x - hx, z - hz, x + hx, z + hz, rows * 0.24 + 0.1, 'none', 0, { hidden: true });
    };
    api.tires = (x, z, n) => { x = S(x); z = S(z); for (let i = 0; i < n; i++) api.decor.push({ torus: true, r: 0.32, tube: 0.13, x, y: 0.13 + i * 0.25, z, rx: Math.PI / 2, color: '#1b1b1b', seg: 12 }); rawB(x - 0.45, z - 0.45, x + 0.45, z + 0.45, n * 0.25 + 0.05, 'none', 0, { hidden: true }); };
    api.reel = (x, z) => { x = S(x); z = S(z); api.decor.push(G.geo.cyl(0.6, 0.08, x, 0.6, z - 0.4, '#8a6a42', Math.PI / 2), G.geo.cyl(0.6, 0.08, x, 0.6, z + 0.4, '#8a6a42', Math.PI / 2), G.geo.cyl(0.3, 0.8, x, 0.6, z, '#2a2a2a', Math.PI / 2)); rawB(x - 0.6, z - 0.45, x + 0.6, z + 0.45, 1.2, 'none', 0, { hidden: true }); };
    api.stain = (x, z, sz) => api.ground.push({ kind: 'stain', x: S(x), z: S(z), sz: sz || 2 });
    api.pool = (x, z, sz) => api.ground.push({ kind: 'pool', x: S(x), z: S(z), sz: sz || 5 });
    jpApi(api, S, rawB, sc);
    return api;
  }

  // ---------- японский квартал: крыши, деревья, фонари, ворота ----------
  const _qa = new THREE.Quaternion(), _ea = new THREE.Euler(), _va = new THREE.Vector3(), _upv = new THREE.Vector3(0, 1, 0);
  // цилиндр между двумя точками (ветви, стебли, коньки вальм)
  function stick(a, b, r0, r1, color, seg) {
    _va.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const len = _va.length(); _va.normalize();
    _qa.setFromUnitVectors(_upv, _va); _ea.setFromQuaternion(_qa);
    return { cyl: true, r: r1, r2: r0, h: len, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, color, rx: _ea.x, ry: _ea.y, rz: _ea.z, seg: seg || 6 };
  }
  const rnd = (a, b) => a + Math.random() * (b - a);
  const PINK = ['#ffffff', '#fff2f6', '#ffe8ef', '#f8e2ea', '#fff8fa'];

  function jpApi(api, S, rawB, sc) {
    const box = G.geo.box, cyl = G.geo.cyl, dec = api.decor;
    // черепичная крыша над стенами (x0..x1, z0..z1) с верхом стен y: подъём h и свес ov — в метрах
    // opt: hip — вальмовая, col — оттенок черепицы, gable — цвет фронтона, along — 'x'|'z'
    api.roof = (x0, z0, x1, z1, y, h, ov, opt) => {
      opt = opt || {}; ov = ov == null ? 0.8 : ov;
      const X0 = S(Math.min(x0, x1)), X1 = S(Math.max(x0, x1)), Z0 = S(Math.min(z0, z1)), Z1 = S(Math.max(z0, z1));
      const ax = opt.along ? opt.along === 'x' : (X1 - X0) >= (Z1 - Z0);
      const r = { X0, X1, Z0, Z1, y, h, ov, hip: !!opt.hip, col: opt.col || '#ffffff', alongX: ax };
      api.roofs.push(r);
      const g = roofFrame(r);
      const P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa];
      const rc = opt.ridgeCol || '#2a2e34', trim = '#2b2622';
      const along = (len, hh, dd, aa, c, yy, col) => { const p = P(aa, c, yy); dec.push(box(ax ? len : dd, hh, ax ? dd : len, p[0], p[1], p[2], col)); };
      // доски свеса
      along(g.A1 - g.A0, 0.13, 0.1, g.mid, g.C0, g.ey - 0.05, trim); along(g.A1 - g.A0, 0.13, 0.1, g.mid, g.C1, g.ey - 0.05, trim);
      // конёк
      if (g.ra1 - g.ra0 > 0.05) along(g.ra1 - g.ra0 + 0.25, 0.26, 0.3, (g.ra0 + g.ra1) / 2, g.cc, g.top + 0.05, rc);
      if (!r.hip) {
        // фронтоны и концевые плитки они-гавара
        for (const aa of [g.a0w + 0.07, g.a1w - 0.07]) {
          const p = P(aa, g.cc, y);
          dec.push({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: opt.gable || '#e9e2d4', ry: ax ? 0 : HP, cs: 1 });
        }
        for (const aa of [g.A0 + 0.12, g.A1 - 0.12]) { const p = P(aa, g.cc, g.top + 0.12); dec.push(box(ax ? 0.26 : 0.36, 0.44, ax ? 0.36 : 0.26, p[0], p[1], p[2], rc)); }
        // торцевые доски вдоль скатов
        for (const aa of [g.A0, g.A1]) for (const s of [-1, 1]) dec.push(stick(P(aa, g.cc + s * g.hw, g.ey - 0.02), P(aa, g.cc, g.top), 0.07, 0.07, trim, 4));
      } else {
        for (const aa of [g.A0, g.A1]) { const p = P(aa, g.cc, g.ey - 0.05); dec.push(box(ax ? 0.1 : g.C1 - g.C0, 0.13, ax ? g.C1 - g.C0 : 0.1, p[0], p[1], p[2], trim)); }
        // рёбра вальм
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) dec.push(stick(P(aa, c, g.ey + 0.02), P(ra, g.cc, g.top + 0.06), 0.11, 0.09, rc, 5));
        if (opt.finial) { const p = P(g.mid, g.cc, g.top); dec.push(cyl(0.12, opt.finial, p[0], g.top + opt.finial / 2, p[2], '#6b5a3a', 0, 0, 0, 8)); if (opt.finial > 3) for (let i = 0; i < 7; i++) dec.push({ torus: true, r: 0.5 - i * 0.04, tube: 0.07, x: p[0], y: g.top + opt.finial * (0.25 + i * 0.08), z: p[2], rx: HP, color: '#8a7448', seg: 10 });
          dec.push({ sph: true, r: opt.finial > 3 ? 0.32 : 0.14, x: p[0], y: g.top + opt.finial, z: p[2], color: '#c9a54a', seg: 8 }); }
      }
    };
    // сакура: ствол, развилка, ветви и облака цветов; лепестки падают вокруг
    api.sakura = (x, z, h, k, far) => {
      const X = S(x), Z = S(z); h = h || 6; k = k || 1;
      const lean = Math.random() * 6.28, fh = h * 0.36;
      const fork = [X + Math.cos(lean) * 0.35 * k, fh, Z + Math.sin(lean) * 0.35 * k];
      dec.push(stick([X, 0, Z], [X, 0.6, Z], 0.42 * k, 0.32 * k, '#3a2a20', 7), stick([X, 0.5, Z], fork, 0.32 * k, 0.22 * k, '#4a3428', 7));
      const m = 4 + (Math.random() < 0.5 ? 1 : 0);
      const blob = (p, r) => api.blossoms.push({ sph: true, r, x: p[0], y: p[1], z: p[2], sx: 1.15, sy: 0.74, sz: 1.1, ry: Math.random() * 3, color: PINK[(Math.random() * PINK.length) | 0], seg: far ? 6 : 8 });
      for (let j = 0; j < m; j++) {
        const ang = lean + j * 6.28 / m + rnd(-0.35, 0.35), out = rnd(1.5, 2.3) * k, up = h * rnd(0.6, 0.72);
        const end = [fork[0] + Math.cos(ang) * out, up, fork[2] + Math.sin(ang) * out];
        dec.push(stick(fork, end, 0.2 * k, 0.09 * k, '#4a3428'));
        const midp = [(fork[0] + end[0]) / 2, (fork[1] + end[1]) / 2, (fork[2] + end[2]) / 2];
        const a2 = ang + rnd(-0.7, 0.7), end2 = [midp[0] + Math.cos(a2) * 1.4 * k, up + rnd(-0.6, 0.4), midp[2] + Math.sin(a2) * 1.4 * k];
        dec.push(stick(midp, end2, 0.1 * k, 0.05 * k, '#4a3428', 5));
        blob(end, rnd(1.25, 1.6) * k); blob(end2, rnd(1.0, 1.3) * k);
        blob([end[0] + Math.cos(ang) * 0.9 * k, end[1] - 0.7 * k, end[2] + Math.sin(ang) * 0.9 * k], rnd(0.8, 1.05) * k);
      }
      blob([fork[0], h * 0.86, fork[2]], 1.75 * k); blob([fork[0] + 0.6, h * 0.76, fork[2] - 0.5], 1.4 * k);
      if (!far) {
        rawB(X - 0.32 * k, Z - 0.32 * k, X + 0.32 * k, Z + 0.32 * k, fh + 0.3, 'none', 0, { hidden: true });
        api.ground.push({ kind: 'petals', x: X, z: Z, sz: 6.5 * k });
      }
      api.trees.push({ x: fork[0], y: h * 0.72, z: fork[2], r: 2.6 * k, petals: !far });
    };
    // каменный фонарь торо
    api.toro = (x, z, k) => {
      const X = S(x), Z = S(z); k = k || 1;
      const st = '#8e8b83', dk = '#77746c';
      dec.push(box(0.78 * k, 0.22 * k, 0.78 * k, X, 0.11 * k, Z, dk), cyl(0.3 * k, 0.18 * k, X, 0.31 * k, Z, st, 0, 0, 0, 6),
        cyl(0.13 * k, 0.78 * k, X, 0.79 * k, Z, st, 0, 0, 0, 8), box(0.64 * k, 0.16 * k, 0.64 * k, X, 1.25 * k, Z, dk),
        box(0.44 * k, 0.42 * k, 0.44 * k, X, 1.54 * k, Z, st), box(0.22 * k, 0.22 * k, 0.46 * k, X, 1.54 * k, Z, '#ffdc96'), box(0.46 * k, 0.22 * k, 0.22 * k, X, 1.54 * k, Z, '#ffdc96'),
        { cyl: true, r: 0.03, r2: 0.56 * k, h: 0.32 * k, x: X, y: 1.91 * k, z: Z, color: dk, seg: 4, ry: Math.PI / 4 }, { sph: true, r: 0.1 * k, x: X, y: 2.12 * k, z: Z, color: st, seg: 6 });
      api.lamps.push([X, 1.54 * k, Z, 0.8 * k]);
      rawB(X - 0.39 * k, Z - 0.39 * k, X + 0.39 * k, Z + 0.39 * k, 2.15 * k, 'none', 0, { hidden: true });
    };
    // бумажный фонарь тётин на шнуре (координаты x,z — в масштабе карты, y — в метрах)
    api.chochin = (x, y, z, col, top) => {
      const X = S(x), Z = S(z), t = Math.max(top || 0, y + 0.6);
      dec.push(cyl(0.01, t - y - 0.3, X, (t + y + 0.3) / 2, Z, '#1a1a1a', 0, 0, 0, 4), { sph: true, r: 0.24, x: X, y, z: Z, sy: 1.3, color: col || '#d6402a', seg: 7 },
        cyl(0.13, 0.06, X, y + 0.3, Z, '#1d1d1d', 0, 0, 0, 6), cyl(0.13, 0.06, X, y - 0.3, Z, '#1d1d1d', 0, 0, 0, 6));
      api.lamps.push([X, y, Z, 1.0]);
    };
    // ворота тории: w — пролёт (в масштабе карты), h — высота в метрах, rot — 0 (поперёк Z) или HP
    api.torii = (x, z, w, h, rot, col) => {
      const X = S(x), Z = S(z), W = S(w), c = col || '#c8321e', dx = rot ? 0 : 1, dz = rot ? 1 : 0, ry = rot ? HP : 0;
      for (const s of [-1, 1]) {
        const px = X + dx * s * W / 2, pz = Z + dz * s * W / 2;
        dec.push(cyl(0.21, h, px, h / 2, pz, c, 0, 0, 0, 12, 0.25), cyl(0.27, 0.5, px, 0.25, pz, '#1d1d1d', 0, 0, 0, 12));
        rawB(px - 0.28, pz - 0.28, px + 0.28, pz + 0.28, h, 'none', 0, { hidden: true });
        // приподнятые концы верхней балки
        dec.push(box(1.5, 0.3, 0.55, X + dx * s * (W / 2 + 0.55), h + 0.42, Z + dz * s * (W / 2 + 0.55), '#1d1d1d', rot ? -s * 0.12 : 0, ry, rot ? 0 : s * 0.12));
      }
      dec.push(box(W + 0.6, 0.3, 0.55, X, h + 0.36, Z, '#1d1d1d', 0, ry, 0), box(W + 1.7, 0.24, 0.44, X, h + 0.12, Z, c, 0, ry, 0),
        box(W + 0.9, 0.22, 0.24, X, h - 0.85, Z, c, 0, ry, 0), box(0.24, 0.7, 0.22, X, h - 0.4, Z, c, 0, ry, 0),
        box(0.62, 0.78, 0.1, X, h - 0.4, Z, '#24201c', 0, ry, 0), box(0.46, 0.6, 0.12, X, h - 0.4, Z, '#d9b23a', 0, ry, 0));
    };
    // горбатый мост вдоль X: ступени-столкновения + изогнутый настил и перила
    api.bridge = (xc, zc, len) => {
      const L = S(len), X = S(xc), Z = S(zc), Wd = 2.4;
      for (const [f0, f1, hh] of [[0, 0.15, 0.3], [0.15, 0.3, 0.6], [0.3, 0.7, 0.85], [0.7, 0.85, 0.6], [0.85, 1, 0.3]])
        rawB(X - L / 2 + f0 * L, Z - Wd / 2, X - L / 2 + f1 * L, Z + Wd / 2, hh, 'none', 0, { hidden: true });
      const yAt = (t) => 0.06 + 0.82 * Math.min(1, Math.sin(Math.PI * t) * 1.25);
      const N = 14, xAt = (t) => X - L / 2 + t * L;
      for (let i = 0; i < N; i++) {
        const t0 = i / N, t1 = (i + 1) / N, x0 = xAt(t0), x1 = xAt(t1), y0 = yAt(t0), y1 = yAt(t1);
        const ang = Math.atan2(y1 - y0, x1 - x0), ln = Math.hypot(x1 - x0, y1 - y0);
        dec.push(box(ln + 0.04, 0.14, Wd, (x0 + x1) / 2, (y0 + y1) / 2 - 0.07, Z, i % 2 ? '#7a4e30' : '#86583a', 0, 0, ang));
        for (const s of [-1, 1]) {
          dec.push(box(ln + 0.02, 0.08, 0.1, (x0 + x1) / 2, (y0 + y1) / 2 + 0.85, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, ang));
          if (i % 2 === 0) dec.push(cyl(0.06, 0.9, x0, y0 + 0.43, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, 0, 6));
        }
      }
      for (const t of [0, 1]) for (const s of [-1, 1]) dec.push(cyl(0.08, 1.0, xAt(t), 0.5, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, 0, 8), { sph: true, r: 0.12, x: xAt(t), y: 1.08, z: Z + s * (Wd / 2 - 0.06), sy: 1.4, color: '#b58a3a', seg: 8 });
      for (const t of [0.3, 0.5, 0.7]) for (const s of [-1, 1]) dec.push(cyl(0.11, yAt(t), xAt(t), yAt(t) / 2, Z + s * (Wd / 2 - 0.3), '#4a3426', 0, 0, 0, 8));
    };
    // пруд с карпами: вода на земле и каменная кайма
    api.pond = (x0, z0, x1, z1) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.ground.push({ kind: 'pond', x: (X0 + X1) / 2, z: (Z0 + Z1) / 2, w: X1 - X0, d: Z1 - Z0 });
      const per = 2 * (X1 - X0 + Z1 - Z0), n = Math.round(per / 0.75);
      for (let i = 0; i < n; i++) {
        let t = i / n * per, px, pz;
        if (t < X1 - X0) { px = X0 + t; pz = Z0; } else if ((t -= X1 - X0) < Z1 - Z0) { px = X1; pz = Z0 + t; }
        else if ((t -= Z1 - Z0) < X1 - X0) { px = X1 - t; pz = Z1; } else { t -= X1 - X0; px = X0; pz = Z1 - t; }
        const v = 92 + Math.random() * 34 | 0;
        dec.push({ sph: true, r: rnd(0.32, 0.46), x: px + rnd(-0.1, 0.1), y: 0.04, z: pz + rnd(-0.1, 0.1), sy: 0.55, ry: Math.random() * 3, color: `rgb(${v},${v - 2},${v - 8})`, seg: 7 });
      }
    };
    api.rock = (x, z, s) => {
      const X = S(x), Z = S(z);
      dec.push({ sph: true, r: s * 0.62, x: X, y: s * 0.18, z: Z, sx: 1.25, sy: 0.8, sz: 1.0, ry: Math.random() * 3, color: '#7b7870', seg: 7 },
        { sph: true, r: s * 0.38, x: X + s * 0.45, y: s * 0.08, z: Z - s * 0.3, sy: 0.7, ry: Math.random() * 3, color: '#6d6b64', seg: 6 });
      rawB(X - s * 0.62, Z - s * 0.55, X + s * 0.62, Z + s * 0.55, s * 0.62, 'none', 0, { hidden: true });
    };
    // пирамида бочек сакэ (rot: 0 — вдоль X, HP — вдоль Z), лицом в сторону face (+1/-1)
    api.taru = (x, z, n, rot, face) => {
      const X = S(x), Z = S(z), dx = rot ? 0 : 1, dz = rot ? 1 : 0, f = face || 1;
      const lab = ['#b02a1e', '#23326a', '#f2ece0', '#1d1d1d'];
      for (let r = 0; r < n; r++) for (let i = 0; i < n - r; i++) {
        const o = (i - (n - r - 1) / 2) * 0.7, px = X + dx * o, pz = Z + dz * o, y = r * 0.66 + 0.33;
        dec.push(cyl(0.34, 0.64, px, y, pz, '#dccb9c', 0, 0, 0, 9), cyl(0.35, 0.05, px, y + 0.26, pz, '#3a2a1a', 0, 0, 0, 9), cyl(0.35, 0.05, px, y - 0.26, pz, '#3a2a1a', 0, 0, 0, 9));
        dec.push(box(rot ? 0.03 : 0.34, 0.34, rot ? 0.34 : 0.03, px + (rot ? f * 0.335 : 0), y, pz + (rot ? 0 : f * 0.335), lab[(r * 3 + i) % 4]));
      }
      const hl = n * 0.35 + 0.02;
      rawB(X - (dx ? hl : 0.36), Z - (dz ? hl : 0.36), X + (dx ? hl : 0.36), Z + (dz ? hl : 0.36), n * 0.66, 'none', 0, { hidden: true });
    };
    // ручная тележка (rot: 0 — вдоль X, HP — вдоль Z)
    api.cart = (x, z, rot) => {
      const X = S(x), Z = S(z), ax = !rot, ry = rot ? HP : 0;
      const L = (lx, lz) => ax ? [X + lx, Z + lz] : [X + lz, Z - lx];
      dec.push(box(2.4, 0.12, 1.3, X, 0.78, Z, '#7a5434', 0, ry, 0));
      for (const s of [-1, 1]) { const p = L(0, s * 0.62); dec.push(box(2.4, 0.3, 0.06, p[0], 0.98, p[1], '#6a4a2e', 0, ry, 0)); }
      for (const s of [-1, 1]) {
        const p = L(0.2, s * 0.76);
        dec.push({ torus: true, r: 0.46, tube: 0.06, x: p[0], y: 0.46, z: p[1], ry, color: '#3a2a1e', seg: 16 });
        for (let k = 0; k < 4; k++) dec.push(box(0.9, 0.05, 0.05, p[0], 0.46, p[1], '#3a2a1e', 0, ry, k * Math.PI / 4));
      }
      for (const s of [-1, 1]) { const a0 = L(-1.2, s * 0.5), a1 = L(-2.5, s * 0.5); dec.push(stick([a0[0], 0.8, a0[1]], [a1[0], 0.35, a1[1]], 0.05, 0.04, '#6a4a2e', 5)); }
      const sk = ['#d8c8a0', '#cdbb8c', '#e2d4b0'];
      for (let i = 0; i < 4; i++) { const p = L(-0.75 + i * 0.5, (i % 2 ? 0.25 : -0.2)); dec.push({ sph: true, r: 0.36, x: p[0], y: 1.06, z: p[1], sx: 1.2, sy: 0.6, sz: 0.8, ry: ry + i, color: sk[i % 3], seg: 8 }); }
      const hx = ax ? 1.3 : 0.8, hz = ax ? 0.8 : 1.3;
      rawB(X - hx, Z - hz, X + hx, Z + hz, 1.3, 'none', 0, { hidden: true });
    };
    // лавка-ятай: прилавок, стойки, навес-крыша, занавес норэн
    api.stall = (x0, z0, x1, z1, face, col) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.B(x0, z0, x1, z1, 1.05, 'planks');
      for (const [px, pz] of [[X0 + 0.1, Z0 + 0.1], [X1 - 0.1, Z0 + 0.1], [X0 + 0.1, Z1 - 0.1], [X1 - 0.1, Z1 - 0.1]]) dec.push(cyl(0.07, 2.5, px, 1.25, pz, '#5a3c26', 0, 0, 0, 6));
      api.roof(x0 - 0.1, z0 - 0.1, x1 + 0.1, z1 + 0.1, 2.5, 0.7, 0.35, { col: '#b8a089', gable: '#5a3c26' });
      const fz = face > 0 ? Z1 + 0.05 : Z0 - 0.05, w = X1 - X0, n = Math.max(2, Math.round(w / 0.9));
      for (let i = 0; i < n; i++) dec.push(box(w / n - 0.06, 0.7, 0.03, X0 + (i + 0.5) * w / n, 2.12, fz, col || '#23326a'));
      const goods = ['#e8452a', '#f2a03a', '#e9e3d0', '#7aa04a', '#c8321e'];
      for (let i = 0; i < 6; i++) dec.push({ sph: true, r: 0.12, x: X0 + 0.4 + Math.random() * (w - 0.8), y: 1.12, z: (Z0 + Z1) / 2 + rnd(-0.3, 0.3), color: goods[i % 5], seg: 6 });
      dec.push(box(0.5, 0.18, 0.35, X0 + w * 0.3, 1.14, (Z0 + Z1) / 2, '#3a2a1e'), box(0.4, 0.22, 0.4, X0 + w * 0.7, 1.16, (Z0 + Z1) / 2 + 0.1, '#7a5a3a'));
    };
    // беседка азумая с вальмовой крышей
    api.pavilion = (x, z, s) => {
      const X = S(x), Z = S(z), hs = S(s) / 2;
      api.B(x - s / 2, z - s / 2, x + s / 2, z + s / 2, 0.25, 'planks');
      for (const [px, pz] of [[X - hs + 0.25, Z - hs + 0.25], [X + hs - 0.25, Z - hs + 0.25], [X - hs + 0.25, Z + hs - 0.25], [X + hs - 0.25, Z + hs - 0.25]]) {
        dec.push(cyl(0.12, 2.5, px, 1.5, pz, '#6a4a30', 0, 0, 0, 8));
        rawB(px - 0.16, pz - 0.16, px + 0.16, pz + 0.16, 2.75, 'none', 0, { hidden: true });
      }
      rawB(X - 0.9, Z - 0.3, X + 0.9, Z + 0.3, 0.7, 'none', 0, { hidden: true });
      dec.push(box(1.8, 0.08, 0.6, X, 0.68, Z, '#7a5434'), box(0.1, 0.42, 0.5, X - 0.8, 0.46, Z, '#5a3c26'), box(0.1, 0.42, 0.5, X + 0.8, 0.46, Z, '#5a3c26'));
      api.roof(x - s / 2, z - s / 2, x + s / 2, z + s / 2, 2.75, 1.5, 0.55, { hip: true, col: '#d4d8de', finial: 0.5 });
    };
    // двухэтажная машия: цоколь, решётка первого этажа, штукатурка с балками наверху, навес между этажами, главная крыша
    // o: h — высота, rise — подъём крыши, face — сторона фасада ('+z'|'-z'|'+x'|'-x'), shop — вывеска/норэн, solid:false — декорация за оградой
    api.house2 = (x0, z0, x1, z1, o) => {
      o = o || {}; const h = o.h || 5.6, lo = 2.5, X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      const sopt = o.solid === false ? { solid: false } : null;
      api.B(x0, z0, x1, z1, 0.3, 'stonewall', 0, sopt);
      api.B(x0, z0, x1, z1, lo - 0.3, 'koshi', 0.3, sopt);
      api.B(x0, z0, x1, z1, h - lo, 'plaster', lo, sopt);
      // горизонтальные балки и столбы
      const beam = '#3a2a1e';
      for (const yy of [lo + 0.05, h - 0.12]) {
        dec.push(box(X1 - X0 + 0.16, 0.22, 0.16, (X0 + X1) / 2, yy, Z0 - 0.04, beam), box(X1 - X0 + 0.16, 0.22, 0.16, (X0 + X1) / 2, yy, Z1 + 0.04, beam));
        dec.push(box(0.16, 0.22, Z1 - Z0 + 0.16, X0 - 0.04, yy, (Z0 + Z1) / 2, beam), box(0.16, 0.22, Z1 - Z0 + 0.16, X1 + 0.04, yy, (Z0 + Z1) / 2, beam));
      }
      const nx = Math.max(1, Math.round((X1 - X0) / 3.2)), nz = Math.max(1, Math.round((Z1 - Z0) / 3.2));
      for (let i = 0; i <= nx; i++) { const px = X0 + (X1 - X0) * i / nx; dec.push(box(0.16, h - lo, 0.1, px, (h + lo) / 2, Z0 - 0.05, beam), box(0.16, h - lo, 0.1, px, (h + lo) / 2, Z1 + 0.05, beam)); }
      for (let i = 0; i <= nz; i++) { const pz = Z0 + (Z1 - Z0) * i / nz; dec.push(box(0.1, h - lo, 0.16, X0 - 0.05, (h + lo) / 2, pz, beam), box(0.1, h - lo, 0.16, X1 + 0.05, (h + lo) / 2, pz, beam)); }
      // навес хисаси над первым этажом и главная крыша
      api.roof(x0, z0, x1, z1, lo + 0.25, 0.42, 0.95, { col: o.col || '#ffffff', ridgeCol: '#30343a' });
      api.roof(x0, z0, x1, z1, h, o.rise || 2.2, o.ov == null ? 1.0 : o.ov, { col: o.col || '#ffffff', gable: '#e9e2d4', hip: !!o.hip });
      // окна верхнего этажа (сёдзи) по длинным сторонам
      const long = (X1 - X0) >= (Z1 - Z0);
      const n = Math.max(1, Math.round((long ? X1 - X0 : Z1 - Z0) / 4));
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n;
        if (long) { const px = X0 + (X1 - X0) * t; api.decals.push({ cell: 1, x: px, y: lo + 1.55, z: Z0, w: 1.6, h: 1.5, n: '-z', atlas: 'jp' }, { cell: 1, x: px, y: lo + 1.55, z: Z1, w: 1.6, h: 1.5, n: '+z', atlas: 'jp' }); }
        else { const pz = Z0 + (Z1 - Z0) * t; api.decals.push({ cell: 1, x: X0, y: lo + 1.55, z: pz, w: 1.6, h: 1.5, n: '-x', atlas: 'jp' }, { cell: 1, x: X1, y: lo + 1.55, z: pz, w: 1.6, h: 1.5, n: '+x', atlas: 'jp' }); }
      }
    };
    // энгава: приподнятая деревянная веранда вдоль стены дома (x0..x1 по X при n='+z'/'-z'), со столбами и перилами
    api.veranda = (x0, z0, x1, z1, n) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.B(x0, z0, x1, z1, 0.4, 'planks');
      const along = n === '+z' || n === '-z', edge = n === '+z' ? Z1 : n === '-z' ? Z0 : n === '+x' ? X1 : X0;
      const len = along ? X1 - X0 : Z1 - Z0, m = Math.max(2, Math.round(len / 2.2));
      for (let i = 0; i <= m; i++) {
        const t = i / m, px = along ? X0 + len * t : edge, pz = along ? edge : Z0 + len * t;
        dec.push(cyl(0.07, 0.95, px, 0.85, pz, '#5a3c26', 0, 0, 0, 6));
      }
      const cx = along ? (X0 + X1) / 2 : edge, cz = along ? edge : (Z0 + Z1) / 2;
      dec.push(box(along ? len : 0.08, 0.07, along ? 0.08 : len, cx, 1.28, cz, '#6a4a30'), box(along ? len : 0.05, 0.05, along ? 0.05 : len, cx, 0.86, cz, '#6a4a30'));
      // ступенька
      const sx = along ? (X0 + X1) / 2 : edge + (n === '+x' ? 0.35 : -0.35), sz = along ? edge + (n === '+z' ? 0.35 : -0.35) : (Z0 + Z1) / 2;
      rawB(sx - (along ? 0.8 : 0.3), sz - (along ? 0.3 : 0.8), sx + (along ? 0.8 : 0.3), sz + (along ? 0.3 : 0.8), 0.2, 'stonewall', 0);
    };
    // каменная лестница на платформу: dir — направление подъёма ('+z' и т.д.), w — ширина, top — высота платформы
    api.stairs = (x, z, dir, w, top) => {
      const X = S(x), Z = S(z), W = S(w), n = Math.max(1, Math.round(top / 0.4)), dx = dir === '+x' ? 1 : dir === '-x' ? -1 : 0, dz = dir === '+z' ? 1 : dir === '-z' ? -1 : 0;
      for (let i = 0; i < n; i++) {
        const hh = top * (i + 1) / n, d0 = i * 0.45, d1 = (n - 0) * 0.45;
        const ax = X + dx * d0, az = Z + dz * d0, bx = X + dx * d1, bz = Z + dz * d1;
        rawB(Math.min(ax, bx) - (dx ? 0 : W / 2), Math.min(az, bz) - (dz ? 0 : W / 2), Math.max(ax, bx) + (dx ? 0 : W / 2), Math.max(az, bz) + (dz ? 0 : W / 2), hh, 'stonewall', 0);
      }
    };
    // живая изгородь (с проходами, если даны gaps — массив [z0,z1] или [x0,x1] пропусков по длинной оси)
    api.hedge = (x0, z0, x1, z1, h, gaps) => {
      const along = Math.abs(x1 - x0) >= Math.abs(z1 - z0);
      let segs = [[along ? x0 : z0, along ? x1 : z1]];
      for (const g of gaps || []) { const out = []; for (const [a0, a1] of segs) { if (g[1] <= a0 || g[0] >= a1) out.push([a0, a1]); else { if (g[0] > a0) out.push([a0, g[0]]); if (g[1] < a1) out.push([g[1], a1]); } } segs = out; }
      for (const [a0, a1] of segs) {
        if (along) api.B(a0, z0, a1, z1, h || 1.25, 'hedge'); else api.B(x0, a0, x1, a1, h || 1.25, 'hedge');
        const n = Math.max(1, Math.round(S(a1 - a0) / 1.1));
        for (let i = 0; i < n; i++) {
          const t = (i + 0.5) / n, px = along ? S(a0 + (a1 - a0) * t) : S((x0 + x1) / 2), pz = along ? S((z0 + z1) / 2) : S(a0 + (a1 - a0) * t);
          dec.push({ sph: true, r: 0.62, x: px, y: (h || 1.25) - 0.05, z: pz, sx: along ? 1.1 : 0.75, sy: 0.5, sz: along ? 0.75 : 1.1, color: i % 2 ? '#4f7a36' : '#5a8a3c', seg: 7 });
        }
      }
    };
    // деревянный забор с перекладинами
    api.fence = (x0, z0, x1, z1) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1), along = Math.abs(X1 - X0) >= Math.abs(Z1 - Z0), len = along ? X1 - X0 : Z1 - Z0;
      const n = Math.max(1, Math.round(len / 1.6)), cx = (X0 + X1) / 2, cz = (Z0 + Z1) / 2;
      for (let i = 0; i <= n; i++) { const t = i / n; dec.push(box(0.12, 1.2, 0.12, along ? X0 + len * t : cx, 0.6, along ? cz : Z0 + len * t, '#4a3426')); }
      for (const yy of [0.5, 1.0]) dec.push(box(along ? len : 0.06, 0.1, along ? 0.06 : len, cx, yy, cz, '#6a4a30'));
      rawB(Math.min(X0, X1) - 0.06, Math.min(Z0, Z1) - 0.06, Math.max(X0, X1) + 0.06, Math.max(Z0, Z1) + 0.06, 1.2, 'none', 0, { hidden: true });
    };
    api.bench = (x, z, rot) => {
      const X = S(x), Z = S(z), ry = rot ? HP : 0;
      dec.push(box(1.8, 0.08, 0.5, X, 0.45, Z, '#7a5434', 0, ry, 0), box(0.12, 0.42, 0.42, X + (rot ? 0 : 0.75), 0.21, Z + (rot ? 0.75 : 0), '#4a3426', 0, ry, 0), box(0.12, 0.42, 0.42, X - (rot ? 0 : 0.75), 0.21, Z - (rot ? 0.75 : 0), '#4a3426', 0, ry, 0));
      dec.push(box(1.5, 0.05, 0.4, X, 0.52, Z, '#b02a1e', 0, ry, 0));
      const hx = rot ? 0.28 : 0.92, hz = rot ? 0.92 : 0.28;
      rawB(X - hx, Z - hz, X + hx, Z + hz, 0.5, 'none', 0, { hidden: true });
    };
    // горшок с растением
    api.pot = (x, z, k) => {
      const X = S(x), Z = S(z); k = k || 1;
      dec.push(cyl(0.22 * k, 0.32 * k, X, 0.16 * k, Z, '#6b4a3a', 0, 0, 0, 8, 0.17 * k));
      for (let i = 0; i < 4; i++) dec.push({ sph: true, r: 0.2 * k, x: X + rnd(-0.1, 0.1) * k, y: 0.42 * k + i * 0.06, z: Z + rnd(-0.1, 0.1) * k, sx: 1.2, sy: 0.7, color: i % 2 ? '#4f8a3a' : '#5f9a42', seg: 6 });
      rawB(X - 0.24 * k, Z - 0.24 * k, X + 0.24 * k, Z + 0.24 * k, 0.5 * k, 'none', 0, { hidden: true });
    };
    // каменная чаша цукубай с бамбуковым желобом
    api.basin = (x, z) => {
      const X = S(x), Z = S(z);
      dec.push({ sph: true, r: 0.48, x: X, y: 0.3, z: Z, sy: 0.7, color: '#767a74', seg: 9 }, cyl(0.3, 0.04, X, 0.6, Z, '#2a5a5e', 0, 0, 0, 10));
      dec.push(cyl(0.05, 1.0, X + 0.5, 0.5, Z, '#b8b56a', 0, 0, 0, 6), cyl(0.04, 0.5, X + 0.3, 0.95, Z, '#b8b56a', 0, 0, HP, 6));
      for (let i = 0; i < 4; i++) dec.push({ sph: true, r: 0.14, x: X + rnd(-0.8, 0.8), y: 0.06, z: Z + rnd(-0.8, 0.8), sy: 0.5, color: '#7e8278', seg: 6 });
      rawB(X - 0.5, Z - 0.5, X + 0.5, Z + 0.5, 0.7, 'none', 0, { hidden: true });
    };
    // бумажный зонт вагаса, раскрытый (стоит или лежит)
    api.wagasa = (x, z, col, tilt) => {
      const X = S(x), Z = S(z), c = col || '#c8321e';
      dec.push({ cyl: true, r: 0.02, r2: 1.05, h: 0.32, x: X, y: 1.9, z: Z, color: c, seg: 16, rz: tilt || 0 }, cyl(0.025, 1.9, X, 0.95, Z, '#5a3c26', 0, 0, tilt || 0, 6));
      for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; dec.push(box(0.02, 0.012, 1.0, X + Math.cos(an) * 0.5, 1.75, Z + Math.sin(an) * 0.5, '#f2e6c8', 0, -an + HP, 0)); }
      rawB(X - 0.15, Z - 0.15, X + 0.15, Z + 0.15, 1.9, 'none', 0, { hidden: true });
    };
    // колокол на деревянной раме
    api.bell = (x, z) => {
      const X = S(x), Z = S(z);
      api.B(x - 1.1, z - 1.1, x + 1.1, z + 1.1, 0.45, 'stonewall');
      for (const [px, pz] of [[X - 0.85, Z - 0.85], [X + 0.85, Z - 0.85], [X - 0.85, Z + 0.85], [X + 0.85, Z + 0.85]]) { dec.push(cyl(0.11, 3.0, px, 1.95, pz, '#5a3c26', 0, 0, 0, 8)); rawB(px - 0.14, pz - 0.14, px + 0.14, pz + 0.14, 3.5, 'none', 0, { hidden: true }); }
      dec.push(box(2.2, 0.2, 0.2, X, 3.45, Z - 0.85, '#5a3c26'), box(2.2, 0.2, 0.2, X, 3.45, Z + 0.85, '#5a3c26'), box(0.2, 0.2, 2.0, X, 3.45, Z, '#5a3c26'));
      dec.push({ cyl: true, r: 0.42, r2: 0.3, h: 1.0, x: X, y: 2.4, z: Z, color: '#4b5a3a', seg: 14 }, cyl(0.1, 0.4, X, 3.1, Z, '#3a2a1e', 0, 0, 0, 6), cyl(0.44, 0.06, X, 1.9, Z, '#3f4a30', 0, 0, 0, 14));
      dec.push(cyl(0.12, 1.6, X + 1.4, 2.6, Z, '#6a4a30', 0, 0, HP, 8));
      api.roof(x - 1.3, z - 1.3, x + 1.3, z + 1.3, 3.55, 1.0, 0.5, { hip: true, col: '#8cbcaa', ridgeCol: '#3d5a50' });
      rawB(X - 0.45, Z - 0.45, X + 0.45, Z + 0.45, 3.0, 'none', 0, { hidden: true });
    };
    // стена с табличками эма (укрытие)
    api.emaWall = (x, z, w, rot) => {
      const X = S(x), Z = S(z), W = S(w), ry = rot ? HP : 0;
      dec.push(box(W, 0.12, 0.3, X, 1.85, Z, '#5a3c26', 0, ry, 0), box(W, 1.3, 0.08, X, 1.15, Z, '#8a6a46', 0, ry, 0));
      for (const s of [-1, 1]) dec.push(box(0.14, 1.9, 0.14, X + (rot ? 0 : s * W / 2), 0.95, Z + (rot ? s * W / 2 : 0), '#4a3426'));
      const n = Math.max(2, Math.round(W / 0.5));
      for (let i = 0; i < n; i++) for (let r = 0; r < 2; r++) for (const sd of [-1, 1]) { const t = (i + 0.5) / n - 0.5, px = X + (rot ? 0 : t * W), pz = Z + (rot ? t * W : 0); dec.push(box(0.34, 0.28, 0.04, px + (rot ? sd * 0.06 : 0), 1.3 - r * 0.34, pz + (rot ? 0 : sd * 0.06), ['#c8a06a', '#d8b27a', '#b89060'][(i + r) % 3], 0, ry, 0)); }
      api.roof(x - (rot ? 0.5 : w / 2), z - (rot ? w / 2 : 0.5), x + (rot ? 0.5 : w / 2), z + (rot ? w / 2 : 0.5), 1.95, 0.4, 0.3, { col: '#d4d8de', along: rot ? 'z' : 'x' });
      rawB(X - (rot ? 0.2 : W / 2), Z - (rot ? W / 2 : 0.2), X + (rot ? 0.2 : W / 2), Z + (rot ? W / 2 : 0.2), 2.0, 'none', 0, { hidden: true });
    };
    // маленькое придорожное святилище хокора
    api.hokora = (x, z, rot) => {
      const X = S(x), Z = S(z), ry = rot ? HP : 0;
      api.B(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 0.5, 'stonewall');
      dec.push(box(1.0, 1.2, 0.9, X, 1.1, Z, '#6a4a30', 0, ry, 0), box(0.6, 0.9, 0.06, X + (rot ? 0.46 : 0), 1.05, Z + (rot ? 0 : 0.46), '#2a1c14', 0, ry, 0));
      dec.push(box(0.1, 1.5, 0.1, X - 0.6, 1.25, Z - 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X + 0.6, 1.25, Z - 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X - 0.6, 1.25, Z + 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X + 0.6, 1.25, Z + 0.6, '#c8321e'));
      api.roof(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 1.95, 0.7, 0.35, { hip: true, col: '#d4d8de' });
      rawB(X - 0.55, Z - 0.5, X + 0.55, Z + 0.5, 2.2, 'none', 0, { hidden: true });
      api.lamps.push([X, 1.0, Z + (rot ? 0 : 0.6), 0.6]);
    };
    // колодец с крышей
    api.well = (x, z) => {
      const X = S(x), Z = S(z);
      api.B(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 0.85, 'stonewall');
      dec.push(box(2.0, 0.04, 2.0, X, 0.86, Z, '#203a40'), cyl(0.08, 2.4, X - 1.0, 1.2, Z, '#5a3c26', 0, 0, 0, 6), cyl(0.08, 2.4, X + 1.0, 1.2, Z, '#5a3c26', 0, 0, 0, 6), cyl(0.05, 2.2, X, 2.25, Z, '#5a3c26', 0, 0, HP, 6), cyl(0.2, 0.3, X, 1.6, Z, '#6a4a2e'), box(0.28, 0.3, 0.28, X + 0.3, 1.0, Z + 0.3, '#5a3c26'));
      api.roof(x - 1.1, z - 1.1, x + 1.1, z + 1.1, 2.4, 0.7, 0.3, { along: 'x' });
    };
    // куст бамбука
    api.bamboo = (x, z, n) => {
      const X = S(x), Z = S(z);
      const cols = ['#7f9c3c', '#8aa645', '#6f8e34', '#94a84e'];
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.28, rr = Math.random() * 0.7, px = X + Math.cos(a) * rr, pz = Z + Math.sin(a) * rr, h = rnd(4.5, 6.8);
        const tx = px + rnd(-0.4, 0.4), tz = pz + rnd(-0.4, 0.4);
        dec.push(stick([px, 0, pz], [tx, h, tz], 0.06, 0.045, cols[i % 4], 6));
        for (let k = 0; k < 4; k++) {
          const t = 0.55 + k * 0.13, lx = px + (tx - px) * t, lz = pz + (tz - pz) * t;
          dec.push({ sph: true, r: 0.5, x: lx + rnd(-0.3, 0.3), y: h * t, z: lz + rnd(-0.3, 0.3), sx: 0.35, sy: 0.12, sz: 1.0, rx: rnd(-0.4, 0.4), ry: Math.random() * 6.28, color: k % 2 ? '#5f8a32' : '#6f9a3a', seg: 6 });
        }
      }
      rawB(X - 0.75, Z - 0.75, X + 0.75, Z + 0.75, 3, 'none', 0, { hidden: true });
    };
  }

  // размеры крыши: стены, свесы, конёк
  function roofFrame(r) {
    const ax = r.alongX;
    const a0w = ax ? r.X0 : r.Z0, a1w = ax ? r.X1 : r.Z1, c0w = ax ? r.Z0 : r.X0, c1w = ax ? r.Z1 : r.X1;
    const cc = (c0w + c1w) / 2, hw0 = (c1w - c0w) / 2, sl = r.h / hw0, ov = r.ov;
    const A0 = a0w - ov, A1 = a1w + ov, C0 = c0w - ov, C1 = c1w + ov, hw = hw0 + ov, mid = (A0 + A1) / 2;
    return {
      a0w, a1w, cc, hw0, hw, A0, A1, C0, C1, mid, ey: r.y - ov * sl, top: r.y + r.h,
      ra0: r.hip ? Math.min(A0 + hw, mid) : A0, ra1: r.hip ? Math.max(A1 - hw, mid) : A1
    };
  }

  // ===================== «Пыльный квартал»: старый город в пустыне =====================
  // 88×68 м, три линии. Налётчики — юг (площадь у городских ворот), спецназ — север (площадь у бани).
  // A — двор мечети (северо-восток): длинная — базар и улица с воротами, короткая — сквозь чайхану со средней площади.
  // B — двор караван-сарая (северо-запад): крытые туннели от налётчиков, проулок со средней площади, улица спецназа.
  // Всё проходимое — на уровне земли; проёмы — по целым координатам (центры клеток навигации на полуцелых).
  function layoutDust(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 4111; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    if (!MAT_FACTORY.dsStone) { MAT_FACTORY.dsStone = () => lam('dsStone', null, 1.2); MAT_FACTORY.dsAdobe = () => lam('dsAdobe', null, 0.6); MAT_FACTORY.dsGround = () => lam('dsGround', null, 0.8); }
    const AB = new THREE.Color('#e9dcc6'), wc = (t, k) => '#' + new THREE.Color(t).multiply(AB).multiplyScalar(k || 1).getHexString();
    const SAND = '#f6dcae', OCHRE = '#f2c48a', PINK = '#f4c4a4', CREAM = '#fcecd4', TERRA = '#eaa676', WHITE = '#fff9f0', DUSTY = '#ead2a8', STONE = '#ffffff';
    const WOOD = '#6a4528', WOOD_D = '#4a2e18', BRASS = '#c9a24a', TURQ = '#3f9ea4', SANDC = '#dcc092';
    const NN = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] };
    const isX = (n) => NN[n][0] !== 0;
    const at = (n, c, t, o) => { const N = NN[n]; return N[0] ? [c + N[0] * (o || 0), t] : [t, c + N[1] * (o || 0)]; };
    const wbox = (n, c, t, y, len, hh, dep, col, list) => { const X = isX(n), p = at(n, c, t, dep / 2); (list || a.decor).push(box(X ? dep : len, hh, X ? len : dep, p[0], y, p[1], col)); };
    // 2.0.1: все наклейки — один атлас ds2Atlas (8×4 ячеек); DD — номера старого dsAtlas (0–7), DN — новые ячейки
    const DUV = (i, flip) => { const e = 0.0012, u0 = (i % 8) / 8, v1 = 1 - Math.floor(i / 8) / 4; return flip ? [u0 + 0.125 - e, v1 - 0.25 + e, u0 + e, v1 - e] : [u0 + e, v1 - 0.25 + e, u0 + 0.125 - e, v1 - e]; };
    const DN = (cell, n, c, t, y, w, h, lit, flip) => { const p = at(n, c, t); a.decals.push({ cell, x: p[0], y, z: p[1], w, h, n, atlas: 'ds2Atlas', lit: !!lit, uv: DUV(cell, flip) }); };
    const DD = (cell, n, c, t, y, w, h, lit) => DN(cell < 4 ? cell : cell + 4, n, c, t, y, w, h, lit);
    const floor = (x0, z0, x1, z1, mat, tint) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false, tint });
    const hid = (x0, z0, x1, z1, h, y0) => B(x0, z0, x1, z1, h, 'none', y0 || 0, { hidden: true });
    const HOUSES = [], COV = [];
    const W = (x0, z0, x1, z1, h, tint, y0) => B(x0, z0, x1, z1, h, 'dsAdobe', y0, { tint, ch: 1 });
    const St = (x0, z0, x1, z1, h, tint, y0) => B(x0, z0, x1, z1, h, 'dsStone', y0, { tint, ch: 1 });

    // ---------- помощники ----------
    // парапет плоской крыши: кольцо из четырёх брусьев
    const parapet = (x0, z0, x1, z1, y, col, hh) => {
      hh = hh || 0.55; const t = 0.28, o = 0.06;
      D(box(x1 - x0 + 2 * o, hh, t, (x0 + x1) / 2, y + hh / 2, z0 + t / 2 - o, col), box(x1 - x0 + 2 * o, hh, t, (x0 + x1) / 2, y + hh / 2, z1 - t / 2 + o, col),
        box(t, hh, z1 - z0 - 2 * t + 2 * o, x0 + t / 2 - o, y + hh / 2, (z0 + z1) / 2, col), box(t, hh, z1 - z0 - 2 * t + 2 * o, x1 - t / 2 + o, y + hh / 2, (z0 + z1) / 2, col));
      D(box(x1 - x0 + 0.3, 0.12, z1 - z0 + 0.3, (x0 + x1) / 2, y - 0.3, (z0 + z1) / 2, wc(col === STONE ? '#e8d4b0' : col, 0.86)));
    };
    // купол на барабане: r — радиус, y — низ барабана
    const dome = (x, z, r, y, col, o) => {
      o = o || {}; const dh = o.drum == null ? r * 0.35 : o.drum, dc = o.drumCol || wc(SAND, 0.98);
      if (dh > 0.01) D(cyl(r * 1.04, dh, x, y + dh / 2, z, dc, 0, 0, 0, 16), cyl(r * 1.1, 0.14, x, y + dh, z, wc(dc, 0.9), 0, 0, 0, 16));
      D({ sph: true, r, x, y: y + dh, z, sy: o.sy || 0.92, color: col || '#e8d2a8', seg: o.seg || 16, hs: 8 });
      const top = y + dh + r * (o.sy || 0.92);
      D(cyl(0.05, 0.9 + r * 0.12, x, top + 0.4, z, BRASS, 0, 0, 0, 5), { sph: true, r: 0.14 + r * 0.02, x, y: top + 0.2, z, color: BRASS, seg: 8 });
      if (o.crescent) (r > 4 ? D : H)({ torus: true, r: 0.32, tube: 0.06, x, y: top + 1.25, z, ry: o.cry || 0, color: BRASS, seg: 10 });
      if (o.drumWin && dh > 0.6) for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; H(box(0.06, dh * 0.55, 0.36, x + Math.cos(an) * r * 1.05, y + dh / 2, z + Math.sin(an) * r * 1.05, '#3a2c1e', 0, -an, 0)); }
    };
    // дом-массив: глина или камень, парапет; o.dome — купол [x, z, r, цвет]; o.up — надстройка [x0,z0,x1,z1,h]
    const house = (x0, z0, x1, z1, h, tint, o) => {
      o = o || {};
      (o.stone ? St : W)(x0, z0, x1, z1, h, tint);
      const col = o.stone ? '#efe0c4' : wc(tint, 0.97);
      if (!o.noPar) parapet(x0, z0, x1, z1, h, col);
      HOUSES.push({ x0, z0, x1, z1, h, tint, stone: !!o.stone, plain: !!o.plain, cren: o.noPar ? false : o.cren != null ? o.cren : o.stone ? true : 'hi', up: o.up || null });
      if (o.up) { const u = o.up; (o.stone ? St : W)(u[0], u[1], u[2], u[3], u[4], tint, h); parapet(u[0], u[1], u[2], u[3], h + u[4], col); }
      if (o.dome) dome(o.dome[0], o.dome[1], o.dome[2], (o.up ? h + o.up[4] : h), o.dome[3] || '#ead6b0', { drumWin: o.dome[2] > 2.2 });
      // мелочь на крышах: кувшины, бочка для воды, жерди
      if (!o.noClutter && (x1 - x0) > 4 && (z1 - z0) > 4) {
        const y = o.up ? h + o.up[4] : h, cx = x0 + 1.2 + R(0, x1 - x0 - 2.4), cz = z0 + 1.2 + R(0, z1 - z0 - 2.4);
        if (R(0, 1) < 0.5) H(cyl(0.5, 0.9, cx, y + 0.45, cz, '#7a7a74', 0, 0, 0, 8), cyl(0.52, 0.06, cx, y + 0.9, cz, '#5a5a56', 0, 0, 0, 8));
        else H({ sph: true, r: 0.32, x: cx, y: y + 0.3, z: cz, sy: 1.2, color: '#b8693e', seg: 7 }, { sph: true, r: 0.26, x: cx + 0.6, y: y + 0.25, z: cz + 0.2, sy: 1.2, color: '#a85a32', seg: 7 });
      }
    };
    // стрельчатая арка-заполнение под перемычкой: (cx, cz) — центр проёма, span — ширина, ry: 0 — проём вдоль z, HP — вдоль x
    const archFill = (cx, cz, span, spring, apex, top, dep, col, ry) => {
      const hw = span / 2, rise = apex - spring;
      for (const sg of [-1, 1]) D({ shape: true, pts: [[sg * hw, top], [0, top], [0, apex], ['c', sg * hw * 0.45, apex - rise * 0.25, sg * hw, spring + rise * 0.45, sg * hw, spring]], d: dep, x: cx, y: 0, z: cz, color: col, ry: ry || 0, cs: 6 });
    };
    // ворота в стене: опоры — часть стен, сверху перемычка (столкновение) и арка
    const gate = (x0, z0, x1, z1, yb, yt, col, mat) => {
      B(x0, z0, x1, z1, yt - yb, mat || 'dsStone', yb, { tint: col === STONE ? null : col, ch: 1 });
      const alongX = (x1 - x0) > (z1 - z0), span = alongX ? x1 - x0 : z1 - z0, dep = (alongX ? z1 - z0 : x1 - x0) + 0.06;
      archFill((x0 + x1) / 2, (z0 + z1) / 2, span, yb - 0.9, yb - 0.08, yb + 0.02, dep, col === STONE ? '#efe0c4' : wc(col, 0.96), alongX ? HP : 0);
    };
    // висячий латунный фонарь
    const lantern = (x, y, z, top, k) => {
      k = k || 1;
      D(cyl(0.012, top - y - 0.3 * k, x, (top + y + 0.3 * k) / 2, z, '#1a1a1a', 0, 0, 0, 3), cyl(0.17 * k, 0.34 * k, x, y, z, '#e0a040', 0, 0, 0, 6));
      a.hi.push({ cyl: true, r: 0.02, r2: 0.2 * k, h: 0.22 * k, x, y: y + 0.28 * k, z, color: BRASS, seg: 6 }, cyl(0.2 * k, 0.05, x, y - 0.19 * k, z, BRASS, 0, 0, 0, 6));
      a.lo.push({ cyl: true, r: 0.02, r2: 0.19 * k, h: 0.2 * k, x, y: y + 0.27 * k, z, color: BRASS, seg: 4, open: true });
      H({ cyl: true, r: 0.11 * k, r2: 0.02, h: 0.16, x, y: y - 0.29 * k, z, color: BRASS, seg: 6 });
      a.lamps.push([x, y, z, 0.75 * k]);
    };
    // провод с провисом
    const wire = (p0, p1, sag, r, list) => {
      const n = 4;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n, f = (t) => [p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag, p0[2] + (p1[2] - p0[2]) * t];
        (list || a.decor).push(stick(f(t0), f(t1), r || 0.022, r || 0.022, '#3a2e24', 3));
      }
    };
    const FLAGC = ['#c8402a', '#e8b030', '#2f8f8a', '#f2e6cc', '#7a2f6a', '#2a5a9a'];
    // гирлянда флажков поперёк улицы
    const bunting = (p0, p1, sag, list) => {
      wire(p0, p1, sag, 0.015, list);
      const len = Math.hypot(p1[0] - p0[0], p1[2] - p0[2]), n = Math.max(3, Math.floor(len / 0.55)), ry = Math.atan2(-(p1[2] - p0[2]), p1[0] - p0[0]);
      for (let i = 1; i < n; i++) {
        const t = i / n, y = p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag;
        (list || a.decor).push({ cyl: true, r: 0.2, r2: 0.0, h: 0.34, x: p0[0] + (p1[0] - p0[0]) * t, y: y - 0.2, z: p0[2] + (p1[2] - p0[2]) * t, color: FLAGC[i % FLAGC.length], seg: 3, sx: 1, sz: 0.08, ry, rx: Math.PI });
      }
    };
    const CLOTH = ['#f4ecdc', '#c8402a', '#2f8f8a', '#e8b030', '#3a5a9a', '#d98a5a', '#ffffff'];
    const laundry = (p0, p1, sag) => {
      wire(p0, p1, sag);
      const len = Math.hypot(p1[0] - p0[0], p1[2] - p0[2]), n = Math.max(2, Math.floor(len / 0.8)), ry = Math.atan2(-(p1[2] - p0[2]), p1[0] - p0[0]);
      for (let i = 0; i < n; i++) {
        if (R(0, 1) < 0.3) continue;
        const t = (i + 0.5) / n, y = p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag, hh = R(0.5, 1.0), ww = R(0.4, 0.7);
        D(box(ww, hh, 0.04, p0[0] + (p1[0] - p0[0]) * t, y - hh / 2 - 0.02, p0[2] + (p1[2] - p0[2]) * t, CLOTH[Math.floor(R(0, 6.99))], 0, ry, 0));
      }
    };
    // тент-парус над улицей (наклонный)
    const sail = (x, y, z, w, d, col, tilt, along) => D(box(along ? w : d, 0.04, along ? d : w, x, y, z, col, along ? tilt : 0, 0, along ? 0 : tilt));
    // глиняный кувшин
    const jar = (x, z, k, col) => {
      k = k || 1; col = col || '#b8693e';
      D({ sph: true, r: 0.32 * k, x, y: 0.36 * k, z, sy: 1.25, color: col, seg: 8 }, cyl(0.1 * k, 0.2 * k, x, 0.78 * k, z, col, 0, 0, 0, 7), cyl(0.15 * k, 0.05, x, 0.88 * k, z, wc(col, 0.85), 0, 0, 0, 7));
      hid(x - 0.3 * k, z - 0.3 * k, x + 0.3 * k, z + 0.3 * k, 0.85 * k);
    };
    // мешки с зерном/специями
    const sacks = (x, z, n, rot) => {
      for (let i = 0; i < n; i++) { const o = (i - (n - 1) / 2) * 0.62; D({ sph: true, r: 0.36, x: x + (rot ? 0 : o), y: 0.26, z: z + (rot ? o : 0), sx: 1.0, sy: 0.75, sz: 0.8, ry: R(0, 3), color: ['#d8c8a0', '#cdb88a', '#e2d2ae'][i % 3], seg: 8 }); }
      const hl = n * 0.31 + 0.05; hid(x - (rot ? 0.4 : hl), z - (rot ? hl : 0.4), x + (rot ? 0.4 : hl), z + (rot ? hl : 0.4), 0.55);
    };
    // горки специй в мисках на прилавке
    const SPICE = ['#e0742a', '#c8321e', '#e8b828', '#7a8a2a', '#8a3a1e', '#f0d8a0'];
    const spices = (x0, x1, z, y) => {
      const n = Math.max(2, Math.round((x1 - x0) / 0.55));
      for (let i = 0; i < n; i++) { const x = x0 + (i + 0.5) * (x1 - x0) / n, c = SPICE[(i + Math.floor(x)) % SPICE.length]; D(cyl(0.22, 0.1, x, y + 0.05, z, '#8a5a32', 0, 0, 0, 8), { cyl: true, r: 0.02, r2: 0.2, h: 0.22, x, y: y + 0.2, z, color: c, seg: 8 }); }
    };
    // лавка у стены: прилавок (укрытие), навес, товар; n — сторона, куда смотрит лавка
    const stall = (x0, z0, x1, z1, n, col, kind) => {
      hid(x0, z0, x1, z1, 1.0);
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, w = isX(n) ? z1 - z0 : x1 - x0, dp = isX(n) ? x1 - x0 : z1 - z0;
      D(box(x1 - x0, 0.9, z1 - z0, cx, 0.45, cz, '#7a5434'), box(x1 - x0 + 0.08, 0.06, z1 - z0 + 0.08, cx, 0.93, cz, '#5a3a22'));
      const front = n === '+z' ? z1 : n === '-z' ? z0 : n === '+x' ? x1 : x0, back = n === '+z' ? z0 : n === '-z' ? z1 : n === '+x' ? x0 : x1;
      for (const s of [-1, 1]) { const p = isX(n) ? [front, cz + s * (w / 2 - 0.1)] : [cx + s * (w / 2 - 0.1), front]; D(cyl(0.05, 2.7, p[0], 1.35, p[1], WOOD, 0, 0, 0, 5)); }
      a.awning(isX(n) ? back : cx, 2.95, isX(n) ? cz : back, w + 0.2, dp + 0.9, n, col);
      if (kind === 'spice') { if (isX(n)) for (let i = 0; i < Math.round(w / 0.55); i++) { const z = z0 + (i + 0.5) * w / Math.round(w / 0.55), c = SPICE[i % 6]; D(cyl(0.22, 0.1, cx, 1.01, z, '#8a5a32', 0, 0, 0, 8), { cyl: true, r: 0.02, r2: 0.2, h: 0.22, x: cx, y: 1.16, z, color: c, seg: 8 }); } else spices(x0 + 0.1, x1 - 0.1, cz, 0.96); }
      else if (kind === 'pots') { const n2 = Math.round(w / 0.5); for (let i = 0; i < n2; i++) { const t = -w / 2 + (i + 0.5) * w / n2, p = isX(n) ? [cx, cz + t] : [cx + t, cz]; D({ sph: true, r: 0.17, x: p[0], y: 1.12, z: p[1], sy: 1.2, color: i % 2 ? '#b8693e' : '#c98a52', seg: 6 }); H(cyl(0.06, 0.12, p[0], 1.33, p[1], '#a85a32', 0, 0, 0, 5)); } }
      else { const n2 = Math.round(w / 0.4); for (let i = 0; i < n2; i++) { const t = -w / 2 + (i + 0.5) * w / n2, p = isX(n) ? [cx + R(-0.2, 0.2), cz + t] : [cx + t, cz + R(-0.2, 0.2)]; D({ sph: true, r: 0.13, x: p[0], y: 1.06, z: p[1], color: ['#e8452a', '#f2a03a', '#7aa04a', '#f2d23a', '#6a2a5a'][i % 5], seg: 5 }); } }
    };
    // тележка с сеном (столкновение коробкой)
    // телега с тюками сена: колёса-диски, борта, оглобли; столкновение — кузов 1 м и тюки до 1,75 м (можно запрыгнуть)
    const dsCart = (x, z, rot, tall, noCol) => {
      const ry = rot ? HP : 0, L = (lx, lz) => rot ? [x + lz, z - lx] : [x + lx, z + lz];
      D(box(2.4, 0.14, 1.3, x, 0.86, z, '#7a5434', 0, ry, 0));
      for (const s of [-1, 1]) { const p = L(0, s * 0.62); D(box(2.4, 0.3, 0.07, p[0], 1.06, p[1], '#6a4a2e', 0, ry, 0)); }
      for (const s of [-1, 1]) {
        const p = L(0.25, s * 0.76);
        D(cyl(0.5, 0.08, p[0], 0.5, p[1], '#4a3422', rot ? 0 : HP, 0, rot ? HP : 0, 12), cyl(0.12, 0.2, p[0], 0.5, p[1], '#2e2218', rot ? 0 : HP, 0, rot ? HP : 0, 6));
        for (let k = 0; k < 3; k++) { const q = L(0.25, s * 0.81); HD(box(rot ? 0.04 : 0.86, 0.05, rot ? 0.86 : 0.04, q[0], 0.5, q[1], '#5a4430', rot ? k * Math.PI / 3 : 0, 0, rot ? 0 : k * Math.PI / 3)); }
      }
      for (const s of [-1, 1]) { const a0 = L(-1.2, s * 0.5), a1 = L(-2.6, s * 0.5); D(stick([a0[0], 0.84, a0[1]], [a1[0], 0.12, a1[1]], 0.05, 0.04, '#6a4a2e', 5)); }
      const HAY = ['#d8b860', '#cfae54', '#e0c46c'];
      for (let i = 0; i < 3; i++) { const p = L(-0.75 + i * 0.75, 0); D(box(rot ? 1.15 : 0.66, 0.5, rot ? 0.66 : 1.15, p[0], 1.18, p[1], HAY[i])); HD(box(rot ? 1.17 : 0.05, 0.52, rot ? 0.05 : 1.17, p[0], 1.18, p[1], '#9a7a3a')); }
      { const p = L(-0.35, 0); D(box(rot ? 1.15 : 0.66, 0.5, rot ? 0.66 : 1.15, p[0], 1.68, p[1], HAY[1], 0, 0.2, 0)); if (tall) { const q = L(0.3, 0); D(box(rot ? 1.15 : 0.66, 0.46, rot ? 0.66 : 1.15, q[0], 1.66, q[1], HAY[2], 0, -0.15, 0)); } }
      if (!noCol) { const hx = rot ? 0.75 : 1.25, hz = rot ? 1.25 : 0.75; hid(x - hx, z - hz, x + hx, z + hz, 1.0); hid(x - (rot ? 0.6 : 0.8), z - (rot ? 0.8 : 0.6), x + (rot ? 0.6 : 0.8), z + (rot ? 0.8 : 0.6), 0.75, 1.0); }
    };
    const hayCart = (x, z, rot) => dsCart(x, z, rot);
    // песчаный нанос у стены
    const drift = (x, z, r, k) => H({ sph: true, r, x, y: -0.02, z, sx: k || 1.4, sy: 0.1, sz: 1, ry: R(0, 3), color: '#e2c696', seg: 9, hs: 4 });
    // бугенвиллия, свисающая со стены
    const bougain = (n, c, t, y, w) => {
      const X = isX(n);
      for (let i = 0; i < Math.round(w / 0.5); i++) { const tt = t - w / 2 + (i + 0.5) * w / Math.round(w / 0.5), p = at(n, c, tt, 0.25); L({ sph: true, r: R(0.3, 0.42), x: p[0], y: y - R(0, 1.2), z: p[1], sx: X ? 0.5 : 1.15, sy: 0.9, sz: X ? 1.15 : 0.5, color: ['#c84a86', '#6a8a3a', '#b8407a', '#5a7a32', '#d86a9a'][i % 5], seg: 6 }); }
    };
    // пальма в каменной кадке
    const palmPot = (x, z, h) => { St(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 0.6, '#f0dcc0'); D(cyl(0.7, 0.04, x, 0.62, z, '#5a4430', 0, 0, 0, 10)); ds2Palm(x, z, h); };

    // ===================== 2.0.1: объёмная отделка (двери, окна, зубцы, указатели) =====================
    // HD — деталь только для высокого качества (в упрощённом декоре низкого/среднего её нет)
    const HD = (...p) => { for (const q of p) { q.hiOnly = true; a.decor.push(q); } };
    const sgn = (n) => NN[n][0] + NN[n][1];
    // брус у стены: o — вынос центра от плоскости стены (может быть отрицательным — над стеной)
    const nb = (n, c, t, o, y, len, hh, dep, col, list) => { const p = at(n, c, t, o); (list || a.decor).push(box(isX(n) ? dep : len, hh, isX(n) ? len : dep, p[0], y, p[1], col)); };
    // пальма: ствол из трёх конических частей, кольца коры — только на высоком качестве
    function ds2Palm(x, z, h) {
      h = h || 6.5;
      hid(x - 0.25, z - 0.25, x + 0.25, z + 0.25, h);
      const lean = R(0, 6.28), segs = 6;
      let py = 0, px = x, pz = z;
      for (let i = 0; i < segs; i++) {
        const t = i / segs, sh = h / segs, ox = Math.cos(lean) * 0.12 * (i + 1) * t, oz = Math.sin(lean) * 0.12 * (i + 1) * t;
        D(cyl(0.2 - t * 0.06, sh * 1.02, x + ox, py + sh / 2, z + oz, i % 2 ? '#7a6248' : '#6a543c', 0, 0, 0, 8, 0.22 - t * 0.06));
        HD(cyl(0.23 - t * 0.06, 0.08, x + ox, py + sh * 0.95, z + oz, '#5a4632', 0, 0, 0, 8));
        px = x + ox; pz = z + oz; py += sh;
      }
      HD({ sph: true, r: 0.32, x: px, y: py - 0.1, z: pz, sy: 0.8, color: '#6a5a36', seg: 7 });
      a.fronds.push({ x: px, y: py, z: pz, n: 9 });
    }
    // каменная рама двери: косяки, перемычка с замковым камнем, порог; полотно — наклейка в глубине проёма
    const portal = (n, c, t, w, h, cell, col) => {
      col = col || '#e6d4b0';
      const fw = 0.26, fd = 0.17, fc = wc(col, 0.94);
      if (cell === 0) { nb(n, c, t, 0.2, 0.07, w + 0.36, 0.14, 0.4, wc(col, 0.84)); DD(0, n, c, t, h * 0.55 + 0.1, w + 0.4, h * 1.1 + 0.2); return; }
      nb(n, c, t - w / 2 - fw / 2, fd / 2, h / 2 + 0.02, fw, h + 0.04, fd, col);
      nb(n, c, t + w / 2 + fw / 2, fd / 2, h / 2 + 0.02, fw, h + 0.04, fd, col);
      nb(n, c, t, (fd + 0.05) / 2, h + 0.2, w + 2 * fw + 0.16, 0.36, fd + 0.05, fc);
      nb(n, c, t, 0.2, 0.07, w + 0.36, 0.14, 0.4, wc(col, 0.84));
      HD(...[box(0.3, 0.42, 0.24, 0, 0, 0, wc(col, 1.02))].map(q => { const p = at(n, c, t, 0.12); q.x = p[0]; q.y = h + 0.22; q.z = p[1]; if (isX(n)) { q.w = 0.24; q.d = 0.3; } return q; }));
      HD(...[0.34, 0.5].map(o => { const p = at(n, c, t, o); return box(isX(n) ? 0.05 : w + 0.5, 0.05, isX(n) ? w + 0.5 : 0.05, p[0], h + 0.42, p[1], fc); }));
      DN(cell, n, c, t, h / 2, w, h);
    };
    // окно: наклейка + подоконник и перемычка; на высоком — объёмная рама, решётка, кронштейны
    // kind: 'sh' — бирюзовые ставни, 'cl' — закрытые ставни, 'gr' — арочное с решёткой, 'sq' — окошко, 'lit' — светится
    const win = (n, c, t, y, kind, col, list) => {
      col = col || '#e2cfa8';
      const W2 = kind === 'sq' ? 0.7 : 1.0;
      if (kind === 'sh') DD(2, n, c, t, y, 1.0, 2.0); else if (kind === 'lit') DD(3, n, c, t, y, 1.1, 2.2, true);
      else DN(kind === 'cl' ? 6 : kind === 'gr' ? 7 : 22, n, c, t, y, W2 + (kind === 'sq' ? 0.4 : 0), kind === 'sq' ? 2.2 : 2.0);
      const sill = kind === 'sq' ? 0.32 : 0.62, top = kind === 'sq' ? 0.36 : 0.62;
      nb(n, c, t, 0.08, y - sill - 0.05, W2 + 0.34, 0.1, 0.16, wc(col, 0.88), list);
      nb(n, c, t, 0.05, y + top + 0.1, W2 + 0.3, 0.14, 0.1, wc(col, 0.95), list);
      // объёмная рама и решётка — только на высоком
      HD(...[-1, 1].map(s => { const p = at(n, c, t + s * (W2 / 2 + 0.05), 0.05); return box(isX(n) ? 0.1 : 0.1, sill + top + 0.1, isX(n) ? 0.1 : 0.1, p[0], y + (top - sill) / 2 + 0.05, p[1], wc(col, 0.92)); }));
      if (kind === 'gr' || kind === 'sq') { const nbar = kind === 'sq' ? 4 : 5; for (let k = 0; k < nbar; k++) { const p = at(n, c, t - W2 * 0.38 + k * W2 * 0.76 / (nbar - 1), 0.07); HD(cyl(0.016, sill + top * 0.8, p[0], y + (top * 0.8 - sill) / 2, p[1], '#1c1a18', 0, 0, 0, 4)); } }
      if (kind === 'sh') for (const s of [-1, 1]) { const p = at(n, c, t + s * 0.56, 0.08); HD(box(isX(n) ? 0.12 : 0.04, 0.06, isX(n) ? 0.04 : 0.12, p[0], y + 0.4, p[1], '#2a2420'), box(isX(n) ? 0.12 : 0.04, 0.06, isX(n) ? 0.04 : 0.12, p[0], y - 0.4, p[1], '#2a2420')); }
    };
    // зубцы над парапетом вдоль стороны (n — наружу): ступенчатые мерлоны, как на «Пыльном» и «Песчанике»
    const merlons = (n, c, t0, t1, y, col, list) => {
      const len = t1 - t0, k = Math.max(1, Math.round(len / 1.9)), sp = len / k;
      for (let i = 0; i < k; i++) { const t = t0 + (i + 0.5) * sp; nb(n, c, t, -0.08, y + 0.21, 0.86, 0.42, 0.28, col, list); }
    };
    // тюк сена на поддоне (вместо бесформенной кучи)
    const bale = (x, z, rot, col) => { const w = rot ? 0.6 : 1.1, d = rot ? 1.1 : 0.6; D(box(w, 0.5, d, x, 0.25, z, col || '#d8b860')); HD(box(w + 0.02, 0.05, 0.06, x, 0.25, z + (rot ? 0 : 0.0), '#8a6a30', 0, rot ? HP : 0, 0)); };
    // декоративная арка над улицей: две опоры у стен, арка с перемычкой на высоте (проход под ней свободен)
    // ax — вдоль какой оси идёт улица ('x' — арка поперёк z), (x0..x1 | z0..z1) — от стены до стены
    const span = (alongX, a0, a1, c, yb, th, col) => {
      col = col || '#ead8b4';
      const w = a1 - a0, m = (a0 + a1) / 2, dep = th || 1.2;
      if (alongX) { B(c - dep / 2, a0, c + dep / 2, a1, 1.0, 'dsStone', yb, { tint: col, ch: 1 }); archFill(c, m, w, yb - 1.4, yb - 0.12, yb + 0.02, dep + 0.04, wc(col, 0.95), 0); }
      else { B(a0, c - dep / 2, a1, c + dep / 2, 1.0, 'dsStone', yb, { tint: col, ch: 1 }); archFill(m, c, w, yb - 1.4, yb - 0.12, yb + 0.02, dep + 0.04, wc(col, 0.95), HP); }
      HD(...(alongX ? [box(dep + 0.2, 0.16, w, c, yb + 1.08, m, wc(col, 0.9))] : [box(w, 0.16, dep + 0.2, m, yb + 1.08, c, wc(col, 0.9))]));
      COV.push(alongX ? [c - dep / 2, a0, c + dep / 2, a1] : [a0, c - dep / 2, a1, c + dep / 2]);
    };

    // ===================== кварталы (массивы домов) =====================
    // юго-запад: за туннелями
    house(-44, -34, -34, -20, 7.4, OCHRE, { up: [-44, -34, -38, -27, 2.6] });
    house(-34, -34, -27, -20, 5.4, PINK, { dome: [-30.5, -24, 2.4, '#efdcb8'] });
    house(-44, -20, -35, -6, 8.2, STONE, { stone: true });
    house(-35, -20, -27, -6, 5.8, SAND);
    // юг: вдоль проулка к туннелям
    house(-27, -34, -10, -31, 5.0, CREAM);
    // между туннелями и средней улицей
    house(-22, -27, -10, -18, 6.4, WHITE, { dome: [-16, -22.5, 2.2, '#f4ead6'] });
    house(-10, -23, -6, -18, 6.4, WHITE, { noClutter: true, cren: true });
    house(-22, -15, -6, -8, 5.6, TERRA, { cren: true });
    house(-20, -8, -9, -1, 7.0, SAND, { up: [-17, -7, -12, -2, 2.4] });
    house(-22, -8, -20, -6, 5.6, TERRA, { noPar: true, noClutter: true });
    // между проулком к B и спецназом
    house(-20, 2, -9, 12, 6.8, CREAM, { cren: true });
    house(-20, 12, -9, 22, 5.2, OCHRE, { dome: [-14.5, 17, 2.6, '#ecd8b2'] });
    house(-9, 6, 2, 14, 6.0, PINK);
    house(-9, 14, 2, 22, 7.6, WHITE, { up: [-6, 16, -1, 21, 2.2], cren: true });
    // северо-запад: за караван-сараем и улицей спецназа к B
    house(-44, 20, -32, 34, 6.6, SAND, { up: [-44, 26, -36, 34, 2.4] });
    house(-32, 28, -21, 34, 7.0, OCHRE);
    house(-21, 28, -10, 34, 5.8, CREAM, { dome: [-15.5, 31, 2.0, '#f2e2c4'] });
    // 2.0: каменный блок у галереи B сужен (−26 → −22,5): проход спецназа с улицы на B шире и прямее
    St(-22.5, 20, -20, 22, 5.2, null); HOUSES.push({ x0: -22.5, z0: 20, x1: -20, z1: 22, h: 5.2, stone: true });
    St(-46, -6, -42, 20, 7.0, null); HOUSES.push({ x0: -46, z0: -6, x1: -42, z1: 20, h: 7.0, stone: true, plain: true });
    // север: за спавном спецназа (баня с куполами)
    house(-14, 34, 14, 38, 6.2, STONE, { stone: true, noClutter: true });
    dome(-6, 36.5, 2.2, 6.2, '#efe0c4', {}); dome(0, 36.5, 2.8, 6.2, '#efe0c4', { drum: 0.9 }); dome(6, 36.5, 2.2, 6.2, '#efe0c4', {});
    house(10, 27, 22, 34, 6.4, SAND, { cren: true });
    // между средней улицей спецназа и A
    house(7, 10, 14, 20, 7.0, WHITE);
    house(14, 10, 21, 20, 5.4, PINK, { dome: [17.5, 15, 2.4, '#ecd6ae'] });
    house(7, 20, 10, 22, 5.0, WHITE, { noPar: true, noClutter: true });
    house(7, 7, 9, 10, 5.0, PINK, { noPar: true, noClutter: true });
    // юго-восток: между средней площадью, базаром и длинной
    house(-1, -23, 10, -8, 6.0, SAND, { up: [2, -20, 8, -13, 2.2] });
    house(9, -8, 10, -3, 6.0, SAND, { noPar: true, noClutter: true });
    house(10, -25, 32, -20, 5.0, PINK, { cren: true });
    house(10, -20, 22, -3, 6.6, CREAM, { dome: [16, -11.5, 2.6, '#f0dcb4'] });
    house(22, -20, 35, -3, 5.4, OCHRE, { up: [25, -17, 32, -8, 2.6] });
    house(21, -3, 35, 6, 6.2, STONE, { stone: true });
    house(10, -34, 32, -31, 5.2, SAND);
    house(42, -34, 47, -10, 6.4, OCHRE);
    house(42, -10, 47, 24, 5.4, SAND, { cren: true });
    house(30, -38, 47, -34, 6.0, DUSTY, { noClutter: true });
    house(-47, -38, -27, -34, 6.6, DUSTY, { noClutter: true });

    // ===================== юг: площадь у городских ворот, спавн налётчиков =====================
    floor(-10, -34, 10, -23, 'flag', '#e8d6b6');
    // городские ворота с башнями за спавном
    St(-14, -38, 14, -34, 8.2, null); HOUSES.push({ x0: -14, z0: -38, x1: 14, z1: -34, h: 8.2, stone: true, plain: true });
    for (const x of [-12, 12]) { St(x - 2.4, -39, x + 2.4, -33.4, 10.4, '#f6e6cc'); for (let i = 0; i < 4; i++) for (const s of [-1, 1]) D(box(0.8, 0.8, 0.8, x - 1.8 + i * 1.2, 10.8, -36.2 + s * 2.4, '#efe0c4')); }
    for (let i = 0; i < 9; i++) D(box(0.9, 0.9, 0.7, -8 + i * 2, 8.65, -34.3, '#efe0c4'));
    DD(0, '+z', -33.4, -12, 2.2, 2.2, 4.4); DD(0, '+z', -33.4, 12, 2.2, 2.2, 4.4);
    D(box(6.4, 7.0, 0.3, 0, 3.5, -33.9, '#d8c098'));
    archFill(0, -33.7, 5.2, 4.2, 6.4, 7.0, 0.5, '#e8d4b0', HP);
    DD(0, '+z', -33.62, 0, 3.0, 4.6, 6.0); D(box(5.0, 0.35, 0.4, 0, 7.2, -33.6, '#cdb48c'));
    DD(6, '+z', -33.6, 0, 7.75, 1.2, 1.0);
    for (const x of [-4.2, 4.2]) lantern(x, 4.4, -33.2, 5.6);
    // колодец
    St(5.4, -25.6, 7.6, -23.4, 0.9, '#f0dcc0'); D(cyl(0.9, 0.03, 6.5, 0.92, -24.5, '#2a4a50', 0, 0, 0, 12));
    D(cyl(0.07, 2.4, 5.5, 2.1, -24.5, WOOD, 0, 0, 0, 6), cyl(0.07, 2.4, 7.5, 2.1, -24.5, WOOD, 0, 0, 0, 6), cyl(0.05, 2.2, 6.5, 3.2, -24.5, WOOD, 0, 0, HP, 6), cyl(0.15, 0.3, 6.5, 3.2, -24.5, WOOD_D, 0, 0, HP, 8), cyl(0.01, 1.5, 6.5, 2.4, -24.5, '#3a3a3a', 0, 0, 0, 3), cyl(0.16, 0.26, 6.5, 1.55, -24.5, '#6a5440', 0, 0, 0, 8));
    hid(5.3, -25.7, 7.7, -23.3, 3.3);
    palmPot(-8.6, -24.4, 7.2); ds2Palm(8.8, -32.7, 6.4);
    stack(-9.1, -32.9, 1.0); crate(-7.9, -33.1, 0.8); jar(9.2, -27.5, 1); jar(9.4, -28.3, 0.8, '#c98a52'); sacks(-9.3, -29.5, 3, true);
    hayCart(2.2, -24.6, 0);
    drift(-9.5, -31, 1.6); drift(9.5, -30, 1.3); drift(2, -33.6, 1.8, 2);

    // ===================== проулок и туннели к B =====================
    floor(-27, -31, -10, -27, 'dsGround', '#ead2a8');
    laundry([-24, 4.6, -31], [-22.5, 4.4, -27], 0.4); laundry([-17, 4.4, -31], [-15.5, 4.8, -27], 0.35);
    crate(-26.4, -30.4, 0.9); jar(-11, -30.4, 0.9); a.barrel(-19.5, -30.5, '#7a5a3a'); drift(-21, -30.8, 1.2, 1.8);
    bunting([-10, 4.8, -31], [-10, 4.8, -27], 0.3, a.hi);
    // туннель: крыша-плита, балки, фонари; вход-арка с проулка, выход в караван-сарай
    const TT = '#c9b490';
    B(-27, -27, -22, -6, 0.5, 'dsAdobe', 3.4, { tint: '#d8c4a4' }); COV.push([-27, -27, -22, -6]);
    B(-22, -18, -6, -15, 0.5, 'dsAdobe', 3.4, { tint: '#d8c4a4' }); COV.push([-22, -18, -6, -15]);
    floor(-27, -27, -22, -6, 'flag', TT); floor(-22, -18, -6, -15, 'flag', TT);
    archFill(-24.5, -27.02, 5, 2.4, 3.3, 3.4, 0.3, wc(SAND, 0.96), HP); archFill(-24.5, -6.02, 5, 2.4, 3.3, 3.4, 0.3, wc(SAND, 0.96), HP);
    archFill(-6.02, -16.5, 3, 2.3, 3.2, 3.4, 0.3, wc(WHITE, 0.96), 0);
    for (let z = -25; z <= -8; z += 2.5) D(box(5.0, 0.22, 0.24, -24.5, 3.28, z, WOOD_D));
    for (let x = -20; x <= -8; x += 2.5) D(box(0.24, 0.22, 3.0, x, 3.28, -16.5, WOOD_D));
    for (const z of [-23, -15, -9]) lantern(-24.5, 2.6, z, 3.4);
    lantern(-17, 2.6, -16.5, 3.4); lantern(-10.5, 2.6, -16.5, 3.4);
    // ящики и бочки в туннелях (ширина прохода — не меньше 3 м)
    stack(-26.3, -21.2, 1.0); crate(-26.4, -19.9, 0.8); a.barrel(-22.6, -24.6, '#6a4a2e'); a.barrel(-22.7, -23.8, '#7a5a3a');
    crate(-22.6, -9.0, 1.1); sacks(-26.5, -12.5, 2, true); jar(-26.5, -7.2, 0.9);
    crate(-12.5, -15.5, 0.9); jar(-8, -17.6, 0.8);
    for (const [n, c, t] of [['+x', -27, -24], ['+x', -27, -11], ['-x', -22, -21], ['-x', -22, -10.5]]) DD(7, n, c, t, 1.5, 1.4, 2.8);
    DD(5, '+z', -18, -14, 1.6, 1.0, 2.0); DD(4, '-z', -15, -19, 1.7, 1.0, 2.0);

    // ===================== средняя улица (налётчики) и средняя площадь =====================
    floor(-6, -23, -1, -8, 'dsGround', '#e6cca0');
    floor(-9, -8, 9, 6, 'flag', '#eedcbc');
    for (let i = 0; i < 12; i++) { const an = i / 12 * Math.PI * 2; D(box(0.45, 0.012, 1.2, Math.cos(an) * 4.1, 0.031, Math.sin(an) * 4.1, '#c9b090', 0, -an, 0)); }
    // себиль — общественный фонтан с куполом посреди площади (закрывает прострел)
    St(-2.5, -2.5, 2.5, 2.5, 3.4, '#f6e8d0');
    for (const [n, c] of [['+x', 2.5], ['-x', -2.5], ['+z', 2.5], ['-z', -2.5]]) { DD(6, n, c, 0, 1.75, 2.6, 3.3); const p = at(n, c, 0, 0.35); D(box(isX(n) ? 0.7 : 2.0, 0.5, isX(n) ? 2.0 : 0.7, p[0], 0.25, p[1], '#d8c4a0'), cyl(0.04, 0.3, at(n, c, 0, 0.12)[0], 1.2, at(n, c, 0, 0.12)[1], BRASS, isX(n) ? 0 : HP, 0, isX(n) ? HP : 0, 5)); }
    hid(-2.5, -3.2, 2.5, 3.2, 0.5); hid(-3.2, -2.5, 3.2, 2.5, 0.5);
    D(box(5.5, 0.3, 5.5, 0, 3.55, 0, '#e8d4b0'));
    dome(0, 0, 2.2, 3.7, '#f0dcb4', { drum: 0.4, crescent: true });
    // ящик «икс-бокс», кувшины, пальма, лотки
    stack(-6.2, 3.6, 1.2); crate(6.4, -5.8, 1.0); jar(-8.3, -7.2, 1.0); jar(-7.6, -7.4, 0.8, '#c98a52'); jar(8.3, 5.2, 0.9);
    palmPot(7.4, -6.6, 6.8);
    stall(-9, -7.6, -7.8, -3.6, '+x', '#2f8f8a', 'spice');
    drift(-5.5, -22.5, 1.2); drift(-1.5, -12, 1.0, 2);
    laundry([-6, 4.2, -20], [-1, 4.6, -19.4], 0.35); laundry([-6, 5.0, -13], [-1, 4.8, -12.2], 0.4);
    bunting([-9, 5.2, -8], [9, 5.2, 6], 0.7, a.hi); bunting([-9, 5.4, 6], [9, 5.0, -8], 0.8, a.hi);
    // средние ворота к спецназу (проём x 3…6)
    St(2, 6, 3, 7, 4.6, '#f4e4c8'); St(6, 6, 9, 7, 4.6, '#f4e4c8'); HOUSES.push({ x0: 6, z0: 6, x1: 9, z1: 7, h: 4.6, stone: true, plain: true });
    gate(3, 6, 6, 7, 3.3, 4.6, '#f4e4c8');
    D(box(1.4, 3.0, 0.1, 3.75, 1.5, 7.6, WOOD, 0, -1.25, 0), box(1.4, 3.0, 0.1, 5.25, 1.5, 7.6, WOOD, 0, 1.25, 0));
    for (const [x, r] of [[3.75, -1.25], [5.25, 1.25]]) for (const y of [0.45, 2.55]) D(box(1.36, 0.12, 0.13, x, y, 7.6, '#2b2622', 0, r, 0));
    H(box(0.08, 2.4, 0.05, 3.3, 1.5, 7.9, '#3a2a1a', 0, -1.25, 0), box(0.08, 2.4, 0.05, 5.7, 1.5, 7.9, '#3a2a1a', 0, 1.25, 0));
    // проулок к B (z −1…2): арки на концах, бельё
    floor(-20, -1, -9, 2, 'dsGround', '#e4c89c');
    gate(-10, -1, -9, 2, 3.2, 4.4, SAND, 'dsAdobe'); gate(-20.6, -1, -20, 2, 3.2, 4.6, STONE);
    for (const x of [-18, -15, -12.5]) laundry([x, 4.2 + R(0, 0.8), -1], [x + 0.6, 4.4 + R(0, 0.8), 2], 0.35);
    jar(-17.5, 1.5, 0.8); crate(-13.8, -0.5, 0.8);

    // ===================== чайхана: короткая A (вход со средней площади, выход во двор мечети) =====================
    const CH = '#f6e2c0';
    W(9, -3, 9.4, 0, 3.6, CH); W(9, 3, 9.4, 10, 3.6, CH); W(9, 0, 9.4, 3, 0.8, CH, 2.8);
    W(9.4, -3, 20.6, -2.6, 3.6, CH); W(9.4, 9.6, 20.6, 10, 3.6, CH);
    W(20.6, -3, 21, 6, 3.6, CH); W(20.6, 9, 21, 10, 3.6, CH); W(20.6, 6, 21, 9, 0.8, CH, 2.8);
    W(14.8, -2.6, 15.2, 2, 3.6, '#f2dcc0'); W(14.8, 5, 15.2, 9.6, 3.6, '#f2dcc0'); W(14.8, 2, 15.2, 5, 0.8, '#f2dcc0', 2.8);
    B(9, -3, 21, 10, 0.3, 'dsAdobe', 3.6, { tint: '#fff4e2' }); COV.push([9, -3, 21, 10]);
    W(9, -3, 21, 10, 3.0, OCHRE, 3.9); parapet(9, -3, 21, 10, 6.9, wc(OCHRE, 0.97));
    HOUSES.push({ x0: 9, z0: -3, x1: 21, z1: 10, h: 6.9, tint: OCHRE, upOnly: true });
    dome(15, 3.5, 3.0, 6.9, '#e6cfa4', { drumWin: true, crescent: true, cry: HP });
    floor(9.4, -2.6, 20.6, 9.6, 'cotto', '#f0d8c0'); floor(9, 0, 9.4, 3, 'cotto'); floor(20.6, 6, 21, 9, 'cotto'); floor(14.8, 2, 15.2, 5, 'cotto');
    archFill(9.2, 1.5, 3, 2.1, 2.75, 2.8, 0.46, wc(CH, 0.96), 0); archFill(20.8, 7.5, 3, 2.1, 2.75, 2.8, 0.46, wc(CH, 0.96), 0); archFill(15, 3.5, 3, 2.1, 2.75, 2.8, 0.46, '#e8d2b4', 0);
    // снаружи: вывеска-ковёр, навес, фонари
    a.awning(9, 3.3, -1.8, 2.2, 1.0, '-x', '#2f8f8a'); DD(4, '-x', 9, 5.5, 1.9, 1.2, 2.4); DD(3, '-x', 9, 8.2, 1.9, 1.0, 2.0, true);
    lantern(8.4, 3.0, 0.0, 3.6); lantern(21.6, 3.0, 9.8, 3.6);
    // внутри: стойка с самоварами, тахты с коврами и подушками, низкие столики, кальяны, фонари
    hid(10, 8.6, 14.4, 9.6, 1.05); D(box(4.4, 1.0, 1.0, 12.2, 0.5, 9.1, '#6a4428'), box(4.5, 0.06, 1.1, 12.2, 1.03, 9.1, '#3a2418'));
    for (const x of [10.8, 12.2, 13.6]) { D(cyl(0.2, 0.42, x, 1.27, 9.1, '#d0a040', 0, 0, 0, 8), { sph: true, r: 0.13, x, y: 1.56, z: 9.1, color: '#d0a040', seg: 6 }); H(cyl(0.03, 0.18, x + 0.22, 1.3, 9.1, '#d0a040', 0, 0, HP, 4)); }
    for (let i = 0; i < 8; i++) H(cyl(0.04, 0.1, 10.3 + i * 0.5, 1.11, 8.75, '#c87a3a', 0, 0, 0, 5));
    D(box(4.2, 0.06, 0.3, 12.2, 2.2, 9.45, WOOD_D)); for (let i = 0; i < 9; i++) H({ sph: true, r: 0.12, x: 10.4 + i * 0.45, y: 2.37, z: 9.45, sy: 1.3, color: ['#2f8f8a', '#c8402a', '#e8b030'][i % 3], seg: 5 });
    const takhta = (x0, z0, x1, z1, col) => {
      hid(x0, z0, x1, z1, 0.45);
      D(box(x1 - x0, 0.4, z1 - z0, (x0 + x1) / 2, 0.2, (z0 + z1) / 2, '#6a4428'), box(x1 - x0 - 0.1, 0.06, z1 - z0 - 0.1, (x0 + x1) / 2, 0.43, (z0 + z1) / 2, col));
      const n = Math.max(2, Math.round((x1 - x0) / 0.8));
      for (let i = 0; i < n; i++) D({ sph: true, r: 0.24, x: x0 + (i + 0.5) * (x1 - x0) / n, y: 0.56, z: z0 + 0.25, sx: 1.4, sy: 0.6, color: ['#c8402a', '#e8b030', '#2f6a9a'][i % 3], seg: 6 });
      D(box(0.9, 0.08, 0.6, (x0 + x1) / 2, 0.66, (z0 + z1) / 2 + 0.1, '#5a3a22')); H(cyl(0.1, 0.06, (x0 + x1) / 2 - 0.2, 0.73, (z0 + z1) / 2 + 0.1, '#e8dcc0', 0, 0, 0, 8), cyl(0.04, 0.09, (x0 + x1) / 2 + 0.2, 0.75, (z0 + z1) / 2 + 0.1, '#c87a3a', 0, 0, 0, 5));
    };
    takhta(10, -2.6, 14, -0.9, '#9a2420'); takhta(15.8, -2.6, 20.4, -0.9, '#1f3460'); takhta(16.4, 8.2, 20.4, 9.6, '#9a2420');
    for (const [x, z] of [[11.3, 6.2], [18.4, 2.0]]) { D(cyl(0.16, 0.5, x, 0.25, z, '#2f6a8a', 0, 0, 0, 8), cyl(0.03, 0.6, x, 0.8, z, BRASS, 0, 0, 0, 5), cyl(0.14, 0.12, x, 1.12, z, '#8a3a1e', 0, 0, 0, 7)); hid(x - 0.2, z - 0.2, x + 0.2, z + 0.2, 1.1); }
    D(box(4.6, 0.012, 3.2, 12, 0.03, 3.0, '#8a2a20'), box(4.0, 0.014, 2.6, 12, 0.031, 3.0, '#c8a060'), box(4.6, 0.012, 3.2, 18, 0.03, 5.0, '#1f3460'), box(4.0, 0.014, 2.6, 18, 0.031, 5.0, '#b8402a'));
    DD(5, '+z', -2.6, 12, 1.9, 1.3, 2.6); DD(4, '+z', -2.6, 18.2, 1.9, 1.3, 2.6); DD(2, '-z', 9.6, 17.4, 1.9, 1.1, 2.2); DD(4, '+x', 15.2, 7.4, 1.8, 1.0, 2.0); DD(5, '-x', 14.8, -1.0, 1.8, 1.0, 2.0);
    DD(2, '+x', 9.4, -1.6, 1.9, 1.1, 2.2); DD(2, '-x', 20.6, 1.0, 1.9, 1.1, 2.2);
    for (const [x, z] of [[12, 1.5], [12, 6.5], [18, 4.5], [18, -0.5]]) lantern(x, 2.7, z, 3.6, 1.1);
    D(box(11.2, 0.18, 0.2, 15, 3.5, -0.5, WOOD_D), box(11.2, 0.18, 0.2, 15, 3.5, 3.5, WOOD_D), box(11.2, 0.18, 0.2, 15, 3.5, 7.5, WOOD_D));

    // ===================== средняя улица спецназа и спавн спецназа =====================
    floor(2, 7, 7, 22, 'dsGround', '#e6cca0');
    // телега с сеном и ящики — перекрывают прострел вдоль средней линии
    hid(4.8, 15, 7, 17.2, 2.1); dsCart(5.9, 16.1, HP, true, true);
    crate(2.6, 11.0, 0.9); jar(6.4, 20.6, 0.9); laundry([2, 4.4, 10], [7, 4.8, 10.6], 0.35); laundry([2, 5.0, 19], [7, 4.8, 19.4], 0.3);
    floor(-10, 22, 10, 34, 'flag', '#eedcbc');
    // спавн спецназа: колоннада бани, корыто, пальмы
    for (const x of [-9, -3, 3, 9]) { St(x - 0.4, 33.0, x + 0.4, 33.8, 4.2, '#f6e8d0'); D(box(1.1, 0.3, 1.1, x, 4.35, 33.4, '#e8d4b0')); }
    D(box(19, 0.4, 1.4, 0, 4.6, 33.4, '#efe0c4'));
    DD(0, '-z', 34, 0, 1.6, 1.8, 3.2); DD(3, '-z', 34, -6, 1.8, 1.1, 2.2, true); DD(3, '-z', 34, 6, 1.8, 1.1, 2.2, true);
    lantern(-6, 3.4, 33.4, 4.4); lantern(6, 3.4, 33.4, 4.4); lantern(0, 3.4, 33.4, 4.4);
    St(-9.6, 25.2, -7.6, 26.0, 0.7, '#e8d4b0'); D(box(1.8, 0.03, 0.6, -8.6, 0.72, 25.6, '#2a4a50'));
    ds2Palm(-9.1, 31.6, 6.6); ds2Palm(9.2, 23.4, 7.0);
    stack(8.9, 32.4, 1.0); crate(-8.9, 22.9, 0.9); sacks(9.2, 26.5, 2, true);
    drift(-9.6, 28, 1.3); drift(9.6, 30, 1.2);
    // улица спецназа к B
    floor(-32, 22, -10, 28, 'dsGround', '#e6cca0');
    gate(-21, 22, -20, 28, 3.6, 4.8, SAND, 'dsAdobe');
    St(-21, 22, -20, 22.6, 3.6, null); St(-21, 27.4, -20, 28, 3.6, null);
    crate(-31.3, 27.3, 1.0); jar(-24.5, 27.4, 0.9); jar(-23.8, 27.5, 0.7, '#c98a52'); a.barrel(-12.6, 27.4, '#7a5a3a'); ds2Palm(-28.3, 27.2, 6.2);
    laundry([-17, 4.6, 22], [-16, 4.9, 28], 0.4); laundry([-13, 5.0, 22], [-12.4, 4.6, 28], 0.35);
    // улица спецназа к A
    floor(10, 20, 22, 27, 'dsGround', '#e6cca0');
    crate(13.4, 26.3, 1.0); stack(11.0, 20.8, 1.0); jar(19.4, 26.4, 0.9); ds2Palm(16.2, 26.2, 6.8);
    bunting([10, 5.2, 20], [10, 5.4, 27], 0.4, a.hi); bunting([16, 5.0, 20], [16, 5.2, 27], 0.4, a.hi);

    // ===================== точка B: двор караван-сарая =====================
    floor(-42, -6, -20, 20, 'dsGround', '#ead2a4');
    floor(-38, 4.5, -22, 7.5, 'flag', '#e2cca8'); floor(-31.5, -6, -28.5, 16, 'flag', '#e2cca8');
    // галереи на колоннах: запад (x −42…−38) и север (z 16…20), над ними — плиты крыши
    St(-42, -6, -38, 20, 0.5, '#f0dcbc', 3.8); COV.push([-42, -6, -38, 20]);
    St(-38, 16, -20, 20, 0.5, '#f0dcbc', 3.8); COV.push([-38, 16, -20, 20]);
    for (const z of [-2, 2, 6, 10, 14]) { St(-38.4, z - 0.4, -37.6, z + 0.4, 3.8, '#f4e4c8'); D(box(1.0, 0.25, 1.0, -38, 0.12, z, '#d8c4a0'), box(1.0, 0.2, 1.0, -38, 3.7, z, '#d8c4a0')); }
    for (const z of [0, 4, 8, 12]) archFill(-38, z, 3.2, 2.5, 3.5, 3.8, 0.5, '#f0dcbc', 0);
    archFill(-38, -4, 3.2, 2.5, 3.5, 3.8, 0.5, '#f0dcbc', 0); archFill(-38, 17.8, 3.6, 2.5, 3.5, 3.8, 0.5, '#f0dcbc', 0);
    for (const x of [-34, -30, -26, -22]) { St(x - 0.4, 15.6, x + 0.4, 16.4, 3.8, '#f4e4c8'); D(box(1.0, 0.25, 1.0, x, 0.12, 16, '#d8c4a0'), box(1.0, 0.2, 1.0, x, 3.7, 16, '#d8c4a0')); }
    for (const x of [-36, -32, -28, -24]) archFill(x, 16, 3.2, 2.5, 3.5, 3.8, 0.5, '#f0dcbc', HP);
    archFill(-21, 16, 1.6, 2.6, 3.4, 3.8, 0.5, '#f0dcbc', HP);
    parapet(-42, -6, -38, 20, 4.3, '#efe0c4', 0.4); parapet(-38, 16, -20, 20, 4.3, '#efe0c4', 0.4);
    // в галереях: двери келий, ковры, сундуки, фонари
    for (const z of [-4, 0, 4, 8, 12, 17.5]) { DD(R(0, 1) < 0.6 ? 0 : 7, '+x', -42, z, 1.5, 1.5, 3.0); }
    for (const x of [-35, -28, -23]) DD(0, '-z', 20, x, 1.5, 1.5, 3.0);
    DD(4, '+x', -42, 2, 2.0, 1.3, 2.6); DD(5, '+x', -42, 10, 2.0, 1.3, 2.6);
    for (const z of [0, 8, 14]) lantern(-40, 2.9, z, 3.8); for (const x of [-34, -24]) lantern(x, 2.9, 18, 3.8);
    stack(-41.3, 5.2, 1.0); sacks(-41.4, -2.8, 2, true); jar(-41.4, 15.0, 0.9); jar(-40.8, 15.4, 0.7, '#c98a52');
    // водоём посреди двора (на него можно запрыгнуть), подъёмник с ведром
    St(-32, 4, -28, 8, 0.85, '#f0dcc0'); D(box(3.4, 0.03, 3.4, -30, 0.86, 6, '#2a5258'));
    for (const [x, z] of [[-31.7, 4.3], [-28.3, 7.7]]) D(cyl(0.08, 2.6, x, 2.15, z, WOOD, 0, 0, 0, 6));
    D(stick([-31.7, 3.4, 4.3], [-28.3, 3.4, 7.7], 0.06, 0.06, WOOD_D, 5), cyl(0.01, 1.6, -30, 2.6, 6, '#3a3a3a', 0, 0, 0, 3), cyl(0.18, 0.3, -30, 1.7, 6, '#6a5440', 0, 0, 0, 8));
    // укрытия на точке: ящики, телега, мешки, кувшины, тюки
    stack(-35.6, -1.4, 1.2); crate(-34.4, -1.6, 0.9); hayCart(-24.6, 10.5, HP); sacks(-35.2, 10.8, 3, false); crate(-23.6, -3.6, 1.1); crate(-22.6, -4.4, 0.8);
    jar(-27.0, 13.4, 1.0); jar(-26.3, 13.7, 0.8, '#c98a52'); jar(-36.5, 6.2, 0.9);
    // штабель тюков сена (укрытие 1,2 м, на него можно запрыгнуть)
    hid(-26.6, 1.0, -24.0, 2.6, 1.2);
    for (const [x, z, y, r, c] of [[-25.95, 1.4, 0.3, 0, '#d8b860'], [-24.65, 1.4, 0.3, 0, '#cfae54'], [-25.95, 2.2, 0.3, 0, '#e0c46c'], [-24.65, 2.2, 0.3, 0, '#d8b860'], [-25.95, 1.8, 0.9, HP, '#cfae54'], [-24.65, 1.8, 0.9, HP, '#e0c46c']]) {
      D(box(1.25, 0.6, 0.78, x, y, z, c, 0, r, 0)); HD(box(1.27, 0.62, 0.05, x, y, z + (r ? 0 : 0.0), '#9a7a3a', 0, r, 0));
    }
    palmPot(-35.5, 14.0, 7.4); stack(-31.4, 13.4, 1.1);
    a.letter('B', -30, 0.6, 4.2);
    // верблюжья коновязь и седло (детали)
    D(box(2.6, 0.12, 0.12, -23.6, 1.0, 6.0, WOOD), cyl(0.06, 1.0, -22.4, 0.5, 6.0, WOOD, 0, 0, 0, 5), cyl(0.06, 1.0, -24.8, 0.5, 6.0, WOOD, 0, 0, 0, 5)); hid(-24.9, 5.9, -22.3, 6.1, 1.0);
    H(box(0.7, 0.3, 0.5, -23.2, 1.15, 6.0, '#8a2a20'), box(0.5, 0.05, 0.6, -23.2, 1.32, 6.0, '#e8b030'));
    drift(-21, -5, 1.4); drift(-41, 18.6, 1.2); drift(-33, 19.4, 1.5, 2);
    bougain('-x', -20, 9, 5.0, 4.0);

    // ===================== длинная A: базар, угол, ворота =====================
    floor(10, -31, 34, -25, 'dsGround', '#e8cea2');
    stall(12.5, -31, 16.5, -29.8, '+z', '#c8402a', 'spice'); stall(19.5, -31, 23.5, -29.8, '+z', '#2f8f8a', 'pots'); stall(26.5, -31, 30, -29.8, '+z', '#e8b030', 'fruit');
    stall(15, -26, 18.5, -25, '-z', '#7a2f6a', 'fruit'); stall(24, -26, 27.5, -25, '-z', '#c8402a', 'spice');
    for (const [x, c] of [[11.4, 4], [18.0, 5], [25.0, 4], [31.0, 5]]) DD(c, '+z', -31, x, 2.2, 1.2, 2.4);
    DD(5, '-z', -25, 12.2, 2.2, 1.3, 2.6); DD(4, '-z', -25, 21.2, 2.2, 1.3, 2.6); DD(7, '-z', -25, 29.6, 1.6, 1.6, 3.2);
    sail(14.5, 4.4, -28, 5.0, 6.4, '#e8dcc0', 0.12, false); sail(21.5, 4.6, -28, 4.6, 6.4, '#c8402a', -0.1, false); sail(28.5, 4.4, -28, 5.0, 6.4, '#2f8f8a', 0.1, false);
    for (const x of [12, 17, 24, 31]) bunting([x, 5.0, -31], [x + 1, 5.3, -25], 0.35);
    for (const x of [13, 20, 27]) lantern(x, 3.4, -28, 4.9);
    jar(33.4, -30.6, 1.0); jar(32.8, -31.2, 0.8, '#c98a52'); a.barrel(33.3, -26.0, '#7a5a3a');
    // угол длинной
    floor(32, -34, 42, -20, 'dsGround', '#e8cea2');
    stack(40.8, -32.6, 1.2); crate(39.6, -33.0, 0.9); sacks(36.0, -33.3, 3, false); ds2Palm(41.0, -21.2, 6.6); drift(37, -33.6, 1.8, 2);
    // длинная улица: ворота (проём x 37…40), створки распахнуты
    floor(35, -20, 42, 6, 'dsGround', '#e6cca0');
    St(35, -11, 37, -10, 4.4, '#f4e4c8'); St(40, -11, 42, -10, 4.4, '#f4e4c8'); HOUSES.push({ x0: 35, z0: -11, x1: 37, z1: -10, h: 4.4, stone: true, plain: true }, { x0: 40, z0: -11, x1: 42, z1: -10, h: 4.4, stone: true, plain: true });
    gate(37, -11, 40, -10, 3.3, 4.4, '#f4e4c8');
    D(box(0.1, 3.1, 1.5, 37.1, 1.55, -9.2, WOOD, 0, 0.25, 0), box(0.1, 3.1, 1.5, 39.9, 1.55, -9.2, WOOD, 0, -0.25, 0));
    for (const [x, r] of [[37.1, 0.25], [39.9, -0.25]]) for (const y of [0.45, 2.65]) D(box(0.13, 0.12, 1.46, x, y, -9.2, '#2b2622', 0, r, 0));
    for (const x of [37.1, 39.9]) for (const y of [0.8, 2.3]) H(box(0.04, 0.08, 1.4, x + (x < 38 ? 0.07 : -0.07), y, -9.2, '#2a2a2a', 0, x < 38 ? 0.25 : -0.25, 0));
    hid(36.9, -10, 37.3, -8.4, 3.0); hid(39.7, -10, 40.1, -8.4, 3.0);
    crate(41.2, -12.0, 1.1); crate(35.8, -12.2, 0.9); stack(41.0, -1.8, 1.1); a.barrel(35.6, -15.5, '#6a4a2e'); a.barrel(35.7, -16.3, '#7a5a3a');
    palmPot(36.0, 2.6, 6.8); jar(41.3, 3.4, 0.9); drift(41.4, -6, 1.4); drift(35.4, -19, 1.2);
    laundry([35, 4.6, -16], [42, 4.4, -15.4], 0.4); bunting([35, 4.8, -4], [42, 4.6, -3.6], 0.4, a.hi);
    bougain('-x', 42, -5, 5.2, 5.0); bougain('+x', 35, -15, 5.2, 3.2);

    // ===================== точка A: двор мечети =====================
    floor(21, 6, 42, 24, 'flag', '#f2e2c4');
    // мечеть: массив, портал-айван, портик на колоннах, большой бирюзовый купол, минарет
    St(22, 24, 47, 38, 9.2, '#fff2dc'); HOUSES.push({ x0: 22, z0: 24, x1: 47, z1: 38, h: 9.2, stone: true, plain: true });
    for (let i = 0; i < 13; i++) D(box(0.7, 0.7, 0.5, 22.6 + i * 1.9, 9.55, 24.15, '#f4e6cc'));
    D(box(25.4, 0.3, 0.5, 34.5, 8.9, 23.85, '#e6d0a8'));
    St(28.6, 23.4, 29.4, 24, 12.4, '#fff4e2'); St(34.6, 23.4, 35.4, 24, 12.4, '#fff4e2'); St(29.4, 23.4, 34.6, 24, 1.6, '#fff4e2', 10.8);
    D(box(7.2, 0.4, 1.0, 32, 12.6, 23.7, '#e6d0a8'));
    DD(6, '-z', 23.4, 32, 5.3, 5.2, 10.6); D(box(5.2, 0.04, 0.25, 32, 10.62, 23.3, '#1d5a7a'));
    DD(0, '-z', 23.38, 32, 1.5, 1.7, 3.0);
    // портик
    for (const x of [23.4, 27.0, 37.0, 40.6]) { St(x - 0.4, 20.6, x + 0.4, 21.4, 4.0, '#fff4e2'); D(box(1.0, 0.25, 1.0, x, 0.12, 21, '#e8d4b0'), box(1.0, 0.2, 1.0, x, 3.9, 21, '#e8d4b0')); }
    St(22.6, 20.6, 28.6, 24, 0.5, '#fff0d8', 4.0); St(35.4, 20.6, 41.4, 24, 0.5, '#fff0d8', 4.0); COV.push([22.6, 20.6, 28.6, 24], [35.4, 20.6, 41.4, 24]);
    archFill(25.2, 21, 2.8, 2.7, 3.7, 4.0, 0.6, '#fff0d8', HP); archFill(38.8, 21, 2.8, 2.7, 3.7, 4.0, 0.6, '#fff0d8', HP);
    for (const x of [24.8, 38.8]) DD(2, '-z', 24, x, 1.9, 1.1, 2.2);
    DD(3, '-z', 24, 26.6, 6.6, 1.0, 2.0, true); DD(3, '-z', 24, 37.4, 6.6, 1.0, 2.0, true); DD(2, '-z', 24, 41.8, 6.6, 1.0, 2.0); DD(2, '-z', 24, 22.8, 6.6, 0.9, 1.8);
    lantern(25.2, 3.0, 22.4, 4.0); lantern(38.8, 3.0, 22.4, 4.0);
    // купол и малые купола
    D(cyl(6.2, 1.2, 34, 9.8, 31, '#f4e6cc', 0, 0, 0, 20));
    dome(34, 31, 5.4, 10.4, TURQ, { drum: 2.4, drumCol: '#fff2dc', seg: 22, crescent: true, drumWin: true });
    dome(25.5, 28, 1.8, 9.2, '#4aa8ac', { drum: 0.5, drumCol: '#fff2dc' }); dome(42.5, 28, 1.8, 9.2, '#4aa8ac', { drum: 0.5, drumCol: '#fff2dc' });
    // минарет
    St(41.6, 18.6, 44.4, 21.4, 8.0, '#fff2dc'); HOUSES.push({ x0: 41.6, z0: 18.6, x1: 44.4, z1: 21.4, h: 8, stone: true, plain: true });
    D(box(3.1, 0.35, 3.1, 43, 8.15, 20, '#e6d0a8'));
    D(cyl(1.2, 9.5, 43, 13.05, 20, '#fff2dc', 0, 0, 0, 10), cyl(1.25, 0.3, 43, 12.0, 20, '#e6d0a8', 0, 0, 0, 10), cyl(1.25, 0.6, 43, 15.4, 20, TURQ, 0, 0, 0, 10));
    D(cyl(1.85, 0.35, 43, 17.9, 20, '#e6d0a8', 0, 0, 0, 12), cyl(1.8, 0.7, 43, 18.4, 20, '#fff4e2', 0, 0, 0, 12, 1.75));
    D(cyl(0.85, 3.2, 43, 20.2, 20, '#fff2dc', 0, 0, 0, 10), cyl(0.95, 0.3, 43, 21.9, 20, '#e6d0a8', 0, 0, 0, 10));
    D({ cyl: true, r: 0.05, r2: 1.0, h: 2.2, x: 43, y: 23.1, z: 20, color: TURQ, seg: 10 }, cyl(0.04, 1.2, 43, 24.6, 20, BRASS, 0, 0, 0, 5), { sph: true, r: 0.16, x: 43, y: 24.4, z: 20, color: BRASS, seg: 8 }); H({ torus: true, r: 0.3, tube: 0.05, x: 43, y: 25.3, z: 20, color: BRASS, seg: 10 });
    for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; H(box(0.08, 1.4, 0.4, 43 + Math.cos(an) * 1.22, 13.6, 20 + Math.sin(an) * 1.22, '#3a2c1e', 0, -an, 0)); }
    a.lamps.push([43, 18.6, 20, 1.6]);
    // двор: фонтан для омовений (можно запрыгнуть), кадки с пальмами, укрытия
    hid(29.4, 12.4, 32.6, 15.6, 0.8);
    D(cyl(1.75, 0.8, 31, 0.4, 14, '#f0dcc0', 0, 0, 0, 8), cyl(1.85, 0.12, 31, 0.84, 14, '#e2caa4', 0, 0, 0, 8), cyl(1.55, 0.02, 31, 0.8, 14, '#2f7f86', 0, 0, 0, 8));
    D(cyl(0.3, 0.9, 31, 1.25, 14, '#e8d4b0', 0, 0, 0, 8), cyl(0.5, 0.1, 31, 1.7, 14, '#e2caa4', 0, 0, 0, 8), cyl(0.06, 0.3, 31, 1.9, 14, BRASS, 0, 0, 0, 5));
    for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4 + Math.PI / 8; H(cyl(0.03, 0.18, 31 + Math.cos(an) * 1.55, 0.95, 14 + Math.sin(an) * 1.55, BRASS, 0, 0, 0, 4)); }
    palmPot(24.5, 16.5, 7.6); palmPot(39.0, 10.8, 7.0);
    stack(26.2, 9.4, 1.2); crate(27.4, 9.1, 0.9);
    St(34.0, 16.6, 37.6, 17.4, 1.1, '#f0dcc0'); D(box(3.8, 0.12, 1.0, 35.8, 1.16, 17.0, '#e2caa4'));
    for (let i = 0; i < 4; i++) H({ sph: true, r: 0.22, x: 34.4 + i * 0.95, y: 1.4, z: 17.0, sy: 1.2, color: '#b8693e', seg: 6 }, { sph: true, r: 0.3, x: 34.4 + i * 0.95, y: 1.75, z: 17.0, sy: 0.8, color: '#5f8a3a', seg: 6 });
    crate(40.6, 15.6, 1.0); jar(41.2, 22.8, 1.0);
    // 2.0.1: укрытия спецназа на A — ящики у портика и «дефолт» у восточной стены (на них можно запрыгнуть)
    stack(24.4, 19.0, 1.1); crate(25.5, 19.4, 0.8); stack(37.8, 12.8, 1.2); jar(40.5, 23.1, 0.8, '#c98a52'); sacks(22.2, 12.8, 2, true);
    a.letter('A', 31.5, 9.4, 4.4);
    drift(41.3, 7.2, 1.3); drift(21.6, 19.6, 1.2);
    bougain('+x', 21, 13, 5.2, 4.4); bougain('+z', 6, 28, 6.0, 5.0);

    // ===================== 2.0.1: арки над улицами, указатели, буквы точек =====================
    // арки-перекрытия: вход на базар, выход с базара к углу длинной, средняя улица налётчиков, выход длинной к A
    span(true, -31, -25, 11.0, 3.7, 1.1, '#ecd8b2'); span(true, -31, -25, 33.0, 3.9, 1.2, '#f0dcb8');
    span(false, -6, -1, -12.5, 3.6, 1.0, '#ead2a8'); span(false, 35, 42, 3.4, 4.2, 1.2, '#f4e4c8');
    lantern(11.0, 3.0, -28, 3.7); lantern(-3.5, 2.9, -12.5, 3.6);
    // указатели «A» и «B» со стрелками на развилках (стрелка — в сторону точки для того, кто смотрит на стену)
    DN(14, '-z', -23, -8, 2.3, 1.0, 2.0); DN(13, '-z', -23, 1.2, 2.3, 1.0, 2.0);
    DN(12, '-x', 9, -2.2, 2.0, 0.9, 1.8); DN(15, '+x', -9, -4.2, 2.0, 0.9, 1.8);
    DN(15, '+z', -31, -20.5, 2.0, 0.9, 1.8); DN(12, '-x', 42, -27.5, 2.2, 1.0, 2.0);
    DN(15, '+z', 22, -7.4, 2.3, 1.0, 2.0); DN(12, '+z', 22, 0.6, 2.3, 1.0, 2.0);
    // большие буквы на стенах точек
    DN(20, '+z', 6, 28, 2.6, 1.7, 3.4); DN(20, '-x', 41.6, 20, 2.6, 1.3, 2.6);
    DN(21, '-x', -20, 5.6, 2.2, 1.6, 3.2); DN(21, '+x', -42, 6.0, 2.0, 1.2, 2.4);

    // ===================== автоматическая отделка фасадов =====================
    // окна, двери, машрабии, балки-виги и сливы — только на сторонах, выходящих на проходимые улицы
    const SOL = a.boxes.filter(b => b.solid && b.y0 < 1.2 && b.y1 > 1.0);
    const bnd = { x0: -44, x1: 44, z0: -34, z1: 34 };
    const freeAt = (x, z) => { if (x < bnd.x0 + 0.2 || x > bnd.x1 - 0.2 || z < bnd.z0 + 0.2 || z > bnd.z1 - 0.2) return false; for (const b of SOL) if (x > b.x0 - 0.05 && x < b.x1 + 0.05 && z > b.z0 - 0.05 && z < b.z1 + 0.05) return false; return true; };
    const covAt = (x, z) => COV.some(c => x > c[0] && x < c[2] && z > c[1] && z < c[3]);
    const DOORS = [[4, 0.4], [5, 0.68], [23, 0.82], [0, 1]], WINS = ['sh', 'sh', 'cl', 'gr', 'gr', 'sq'];
    const pickDoor = () => { const r = R(0, 1); for (const [c, p] of DOORS) if (r < p) return c; return 4; };
    for (const h of HOUSES) {
      for (const n of ['+x', '-x', '+z', '-z']) {
        const c = n === '+x' ? h.x1 : n === '-x' ? h.x0 : n === '+z' ? h.z1 : h.z0, t0 = isX(n) ? h.z0 : h.x0, t1 = isX(n) ? h.z1 : h.x1, len = t1 - t0;
        if (len < 1.6) continue;
        const cnt = Math.max(1, Math.round(len / 3.4)), sp = len / cnt;
        let any = false;
        const SC = h.stone ? '#e2cfa8' : wc(h.tint || SAND, 0.9);
        for (let i = 0; i < cnt; i++) {
          const t = t0 + (i + 0.5) * sp + R(-0.3, 0.3), p = at(n, c, t, 0.9), p2 = at(n, c, t, 2.5);
          if (!freeAt(p[0], p[1])) continue;
          any = true;
          const cov = covAt(p[0], p[1]), r = R(0, 1);
          if (h.plain) { if (!cov && h.h > 5 && r < 0.5) win(n, c, t, h.h - 2.2, 'sq', SC); continue; }
          // первый этаж: дверь в каменной раме, ставни лавки, окна с подоконником и перемычкой, ковры
          if (!h.upOnly) {
            if (r < 0.2) { portal(n, c, t, 1.25, 2.45, pickDoor(), SC); if (!cov && R(0, 1) < 0.45) a.awning(at(n, c, t)[0], 3.35, at(n, c, t)[1], 2.1, 0.9, n, ['#2f8f8a', '#c8402a', '#e8b030', '#7a2f6a'][Math.floor(R(0, 3.99))]); }
            else if (r < 0.32) { DD(7, n, c, t, 1.6, 1.6, 3.2); nb(n, c, t, 0.2, 0.07, 1.9, 0.14, 0.4, wc(SC, 0.86)); nb(n, c, t, 0.07, 3.16, 1.9, 0.18, 0.14, SC); }
            else if (r < 0.62) win(n, c, t, 1.8, WINS[Math.floor(R(0, 5.99))], SC);
            else if (r < 0.7 && !cov) { DD(R(0, 1) < 0.5 ? 4 : 5, n, c, t, 2.0, 1.1, 2.2); nb(n, c, t, 0.06, 3.15, 1.4, 0.06, 0.06, WOOD_D); }
            else if (r < 0.78 && !cov) DN(17, n, c, t, 1.7, 1.4, 2.8);
          }
          // верхний этаж: машрабия на балках, окна
          if (!cov && h.h >= 5) {
            const yy = Math.min(h.h - 1.9, 4.6), r2 = R(0, 1);
            if (r2 < 0.22 && freeAt(p2[0], p2[1])) {
              wbox(n, c, t, yy - 0.2, 1.5, 2.3, 0.4, '#5a3a20'); wbox(n, c, t, yy - 1.45, 1.7, 0.18, 0.55, '#4a2e18'); wbox(n, c, t, yy + 1.02, 1.7, 0.16, 0.55, '#4a2e18'); DD(1, n, c + sgn(n) * 0.41, t, yy - 0.2, 1.5, 2.9);
              for (const s of [-0.6, 0.6]) { const q = at(n, c, t + s, 0.25); HD(box(isX(n) ? 0.5 : 0.12, 0.42, isX(n) ? 0.12 : 0.5, q[0], yy - 1.75, q[1], '#4a2e18', isX(n) ? 0 : sgn(n) * 0.5, 0, isX(n) ? -sgn(n) * 0.5 : 0)); }
            } else if (r2 < 0.82) win(n, c, t, yy, r2 > 0.74 ? 'lit' : WINS[Math.floor(R(0, 5.99))], SC, a.hi);
          }
        }
        if (!any) continue;
        // цоколь — тёмная полоса камня по низу стены, выходящей на улицу
        if (!h.upOnly) wbox(n, c, (t0 + t1) / 2, 0.17, len, 0.34, 0.045, h.stone ? '#cdb48c' : wc(h.tint || SAND, 0.78));
        // зубцы парапета (каменные дома и отмеченные) — кроме сторон, к которым примыкает надстройка
        if (h.cren && !h.plain) {
          const u = h.up, touch = u && ((n === '+x' && u[2] >= h.x1 - 0.01) || (n === '-x' && u[0] <= h.x0 + 0.01) || (n === '+z' && u[3] >= h.z1 - 0.01) || (n === '-z' && u[1] <= h.z0 + 0.01));
          if (!touch) { const ml = []; merlons(n, c, t0 + 0.2, t1 - 0.2, h.h + 0.55, h.stone ? '#efe0c4' : wc(h.tint, 0.97), ml); if (h.cren === 'hi') HD(...ml); else D(...ml); }
        }
        // виги — торцы потолочных балок под парапетом (только на высоком качестве)
        if (!h.stone) { const nbm = Math.floor(len / 0.9); for (let k = 0; k < nbm; k++) { if (R(0, 1) < 0.25) continue; const p = at(n, c, t0 + (k + 0.5) * len / nbm, 0.22); H(isX(n) ? box(0.44, 0.17, 0.17, p[0], h.h - 0.55, p[1], WOOD_D) : box(0.17, 0.17, 0.44, p[0], h.h - 0.55, p[1], WOOD_D)); } }
        // водосток (желоб) и потёк под ним
        { const t = t0 + R(0.2, 0.8) * len, p = at(n, c, t, 0.35); D(isX(n) ? box(0.7, 0.16, 0.2, p[0], h.h - 0.25, p[1], h.stone ? '#d8c4a0' : WOOD) : box(0.2, 0.16, 0.7, p[0], h.h - 0.25, p[1], h.stone ? '#d8c4a0' : WOOD)); if (h.h > 4) DN(18, n, c, t + (R(0, 1) < 0.5 ? 0.25 : -0.25), h.h - 1.6, 0.8, 2.6); }
        // трещины и грязь у основания
        if (!h.upOnly && R(0, 1) < 0.5) { const t = t0 + R(0.15, 0.85) * len; DN(16, n, c, t, 1.2, 1.6, 2.4); }
        // песок у основания стены
        if (!h.upOnly && R(0, 1) < 0.55) { const t = t0 + R(0.15, 0.85) * len, p = at(n, c, t, 0.4); if (freeAt(p[0], p[1]) && !covAt(p[0], p[1])) drift(p[0], p[1], R(0.8, 1.5), isX(n) ? 0.7 : 1.6); }
      }
    }

    // 2.0.1: облегчение низкого/среднего: водостоки, верхние брусья машрабий и обода бочек — только на высоком
    for (const p of a.decor) {
      if (p.hiOnly || p.cyl || p.sph || p.torus || p.shape) { if (p.cyl && p.color === '#222' && p.h <= 0.06 && p.r > 0.29 && p.r < 0.33) p.hiOnly = true; continue; }
      if (p.h === 0.16 && Math.abs(Math.max(p.w, p.d) - 0.7) < 0.01 && Math.abs(Math.min(p.w, p.d) - 0.2) < 0.01) p.hiOnly = true;
      else if (p.color === '#4a2e18' && Math.abs(p.h - 0.16) < 0.005 && (p.y || 0) > 3) p.hiOnly = true;
    }

    // ===================== за пределами карты: крыши города, пальмовая роща, дюны =====================
    for (let i = 0; i < 22; i++) {
      const side = i % 4, t = (Math.floor(i / 4) + R(0, 0.6)) / 5.6;
      const w = R(6, 11), d = R(6, 10), hh = R(5, 10);
      const x = side === 0 ? -54 - R(0, 6) : side === 1 ? 55 + R(0, 6) : -44 + t * 88, z = side === 0 || side === 1 ? -34 + t * 68 : side === 2 ? 46 + R(0, 6) : -46 - R(0, 6);
      const tint = [SAND, OCHRE, PINK, CREAM, DUSTY][i % 5];
      H(box(w, hh, d, x, hh / 2, z, wc(tint, 0.92)), box(w + 0.3, 0.5, d + 0.3, x, hh + 0.25, z, wc(tint, 0.86)));
      if (i % 3 === 0) H({ sph: true, r: Math.min(w, d) * 0.3, x, y: hh, z, sy: 0.9, color: i % 2 ? '#e8d4ac' : '#5aa8aa', seg: 10 });
    }
    for (const [x, z, h] of [[-52, 8, 8], [-50, -14, 7], [-55, 22, 9], [52, -22, 8], [54, 6, 7.5], [-20, 44, 8], [24, 46, 7], [-30, -44, 7.5], [20, -45, 8.5]]) {
      for (let i = 0; i < 4; i++) H(cyl(0.2 - i * 0.03, h / 4, x + i * 0.15, h / 8 + i * h / 4, z, '#7a6248', 0, 0, 0, 5));
      for (let k = 0; k < 6; k++) { const an = k * 1.05; H(stick([x + 0.6, h, z], [x + 0.6 + Math.cos(an) * 2.2, h - 1.0, z + Math.sin(an) * 2.2], 0.12, 0.04, '#5f7a34', 3)); }
    }
    // пятна на земле, светлые круги под фонарями
    a.stain(-3.5, -24.2, 3); a.stain(-24.6, 10.5, 3); a.stain(5.9, 16.1, 3); a.stain(36.5, -27, 3); a.stain(-30, 2, 4); a.stain(31, 10, 3);
  }

  // ===================== «Порт» (2.0): портовый квартал на закате =====================
  // 88×68 м, три линии. Налётчики — юг (рыбный рынок), спецназ — север (площадь у морвокзала).
  // B — склад №3 (запад): через подъезд жилого дома, западный проулок с бельём или подворотню с площади.
  // A — причал с портальным краном (восток): длинная — вдоль набережной, короткая — через кафе «Чайка».
  // 2.0: фасады с цоколем, тягами, профильными карнизами, подоконниками, сандриками и водостоками; тротуары с бордюром;
  // контейнеры с угловыми стойками и дверями, решётчатый кран, новые машины, грузовик и погрузчики, кнехты с коллизией.
  // Детализация задаётся вручную (lite: false): декор — средняя детализация на всех качествах, мелочь — только на высоком.
  // Проёмы центрированы на полуцелых координатах — там центры клеток навигационной сетки (шаг 1 м).
  function layoutHarbor(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    // HD — деталь декора только для высокого качества (в упрощённом декоре низкого/среднего её нет)
    const HD = (...p) => { for (const q of p) { q.hiOnly = true; a.decor.push(q); } };
    const hd = (q) => { q.hiOnly = true; return q; };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 9157; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    const PL = new THREE.Color('#e9e2d4'), wc = (t, k) => '#' + new THREE.Color(t).multiply(PL).multiplyScalar(k || 1).getHexString();
    const sh = (hex, k) => '#' + new THREE.Color(hex).multiplyScalar(k).getHexString();
    // свои материалы (регистрируем здесь, чтобы не трогать общую таблицу): штукатурка с потёками, контейнеры одним материалом
    // (цвет — оттенком вершин: один вызов отрисовки вместо четырёх), бетонные плиты причала
    if (!MAT_FACTORY.hbPlaster) {
      MAT_FACTORY.hbPlaster = () => lam('hbStucco', null, 0.5);
      MAT_FACTORY.hbCont = () => lam('container', '#dad6ce', 1.5);
      MAT_FACTORY.hbSlab = () => lam('hbSlab', null, 0.9);
    }
    const CREAM = '#f6e0b4', PEACH = '#f2b48e', SALMON = '#e8967a', OCHRE = '#ebb468', ROSE = '#e6a89a', SKY = '#b6cfd8', SAND = '#ecd2a2', MINT = '#c2dab8', LEMON = '#efd184';
    const IRON = '#26282b', WOOD = '#6b4a2e', WOOD_L = '#9c7350', TEAL = '#2f7f7a', TERRA = '#b65a33', TERRA_D = '#8a3f22', YEL = '#e2a72a', BRONZE = '#4f4636';
    const CRANE = '#e09a1c', CRANE_D = '#b8760e', RED_C = '#a8392a', BLUE_C = '#2f5d86', ORANGE_C = '#c86a1f', TEAL_C = '#2c7a74', GREEN_C = '#4d6b3a', GREY_C = '#8a9096';
    const NN = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] };
    const isX = (n) => NN[n][0] !== 0;
    const sg = (n) => NN[n][0] + NN[n][1];
    // точка на плоскости стены c (нормаль n), t — вдоль стены, o — вынос наружу
    const at = (n, c, t, o) => { const N = NN[n]; return N[0] ? [c + N[0] * (o || 0), t] : [t, c + N[1] * (o || 0)]; };
    const wbox = (n, c, t, y, len, hh, dep, col, list) => { const X = isX(n), p = at(n, c, t, dep / 2); (list || a.decor).push(box(X ? dep : len, hh, X ? len : dep, p[0], y, p[1], col)); };
    // наклейки — один атлас hbAtlas (8×4 ячеек 128×256): старые атласы «порта» и «фасадов» в нём, плюс новые ячейки
    const AT = 'hbAtlas';
    const UV = (i, span) => { const e = 0.0012, u0 = (i % 8) / 8, v1 = 1 - Math.floor(i / 8) / 4; return [u0 + e, v1 - 0.25 + e, u0 + 0.125 * (span || 1) - e, v1 - e]; };
    const AD = (cell, n, c, t, y, w, h, lit, span) => { const p = at(n, c, t); a.decals.push({ cell, x: p[0], y, z: p[1], w, h, n, atlas: AT, lit: !!lit, uv: UV(cell, span) }); };
    const PC = [0, 1, 2, 3, 8, 9, 10, 11], FC = [4, 5, 6, 7, 12, 13, 14, 15];
    const PD = (cell, n, c, t, y, w, h, lit) => AD(PC[cell], n, c, t, y, w, h, lit);
    const FD = (cell, n, c, t, y, w, h, lit) => AD(FC[cell], n, c, t, y, w, h, lit);
    const W = (x0, z0, x1, z1, h, tint, y0) => B(x0, z0, x1, z1, h, 'hbPlaster', y0, { tint, ch: 1 });
    const floor = (x0, z0, x1, z1, mat, tint) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false, tint });
    const hid = (x0, z0, x1, z1, h, y0) => B(x0, z0, x1, z1, h, 'none', y0 || 0, { hidden: true });
    // ящики: обычные — 0.9–1.3 м (запрыгнуть можно), штабель — выше 1.6 м
    const box3 = (x, z, w, h, d, y0) => B(x - w / 2, z - d / 2, x + w / 2, z + d / 2, h, 'crate', y0 || 0, { uv: 'face' });

    // ---------- фасады ----------
    // учёт фасадов: цоколь строится в конце по всей длине стены, кроме проёмов дверей и витрин
    const FACES = [];
    const face = (n, c, t0, t1) => {
      for (const f of FACES) if (f.base && f.n === n && Math.abs(f.c - c) < 0.01 && t0 < f.t1 + 0.6 && t1 > f.t0 - 0.6) { f.t0 = Math.min(f.t0, t0); f.t1 = Math.max(f.t1, t1); return f; }
      const f = { n, c, t0, t1, skip: [], base: true }; FACES.push(f); return f;
    };
    const faceOf = (n, c, t) => FACES.find(f => f.n === n && Math.abs(f.c - c) < 0.01 && t >= f.t0 - 0.01 && t <= f.t1 + 0.01);
    const skipAt = (n, c, t, hw) => { const f = faceOf(n, c, t); if (f) f.skip.push([t - hw, t + hw]); };
    // цоколь: серый камень 0.55 м, выступ 7 см, с разрывами под двери и витрины
    const plinths = () => {
      for (const f of FACES) {
        if (!f.base) continue;
        let segs = [[f.t0, f.t1]];
        for (const g of f.skip) { const out = []; for (const [a0, a1] of segs) { if (g[1] <= a0 || g[0] >= a1) out.push([a0, a1]); else { if (g[0] > a0) out.push([a0, g[0]]); if (g[1] < a1) out.push([g[1], a1]); } } segs = out; }
        const s = sg(f.n), c0 = s > 0 ? f.c - 0.02 : f.c - 0.07, c1 = s > 0 ? f.c + 0.07 : f.c + 0.02;
        for (const [a0, a1] of segs) if (a1 - a0 > 0.3) { if (isX(f.n)) B(c0, a0, c1, a1, 0.55, 'concrete', 0, { solid: false, tint: '#cbc2b2' }); else B(a0, c0, a1, c1, 0.55, 'concrete', 0, { solid: false, tint: '#cbc2b2' }); }
      }
    };
    // профильный карниз плоской крыши: полочка, выносная плита, слезник; тёмная кровля
    const cornice = (x0, z0, x1, z1, y, col) => {
      const w = x1 - x0, d = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, j = R(0, 0.03);
      D(box(w + 0.16 + j, 0.14, d + 0.16 + j, cx, y - 0.37, cz, sh(col, 0.86)),
        box(w + 0.44 + j, 0.27, d + 0.44 + j, cx, y - 0.165, cz, col),
        box(w + 0.56 + j, 0.09, d + 0.56 + j, cx, y + 0.015, cz, sh(col, 1.05)));
      if (w > 1.2 && d > 1.2) H(box(w - 0.2, 0.05, d - 0.2, cx, y + 0.07, cz, '#5e5750'));
    };
    // межэтажная тяга вдоль фасада
    const band = (n, c, t0, t1, y, col) => { wbox(n, c, (t0 + t1) / 2, y, t1 - t0, 0.17, 0.085, col); wbox(n, c, (t0 + t1) / 2, y - 0.12, t1 - t0 - 0.02, 0.07, 0.045, sh(col, 0.9), a.hi); };
    // черепичная крыша (коппо): вальмовая или двускатная с фронтонами под цвет стены; свес с подшивкой, жёлоб
    const roof = (x0, z0, x1, z1, y, h, ov, o) => {
      o = o || {};
      const r = { X0: x0, X1: x1, Z0: z0, Z1: z1, y, h, ov, hip: !!o.hip, col: o.col || '#ffffff', alongX: o.along ? o.along === 'x' : (x1 - x0) >= (z1 - z0) };
      a.roofs.push(r);
      const g = roofFrame(r), ax = r.alongX, P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa], RC = o.ridge || '#9a4228', ED = '#6e3a24';
      // доска свеса и жёлоб по длинным сторонам
      for (const c of [g.C0, g.C1]) { const p = P(g.mid, c, g.ey - 0.08); D(box(ax ? g.A1 - g.A0 : 0.07, 0.2, ax ? 0.07 : g.A1 - g.A0, p[0], p[1], p[2], ED)); const q = P(g.mid, c + (c > g.cc ? 0.09 : -0.09), g.ey - 0.12); HD({ cyl: true, r: 0.075, h: g.A1 - g.A0, x: q[0], y: q[1], z: q[2], color: '#7a7670', rx: ax ? 0 : HP, rz: ax ? HP : 0, seg: 5, open: true }); }
      // подшивка свеса (тёмная плоскость под черепицей у стены)
      for (const c of [g.C0, g.C1]) { const cm = (c + (c > g.cc ? c - ov : c + ov)) / 2, p = P(g.mid, cm, y - 0.04); H(box(ax ? g.A1 - g.A0 : ov, 0.05, ax ? ov : g.A1 - g.A0, p[0], p[1], p[2], '#4a3a30')); }
      if (g.ra1 - g.ra0 > 0.05) { const p = P((g.ra0 + g.ra1) / 2, g.cc, g.top + 0.03); D(cyl(0.15, g.ra1 - g.ra0 + 0.3, p[0], p[1], p[2], RC, ax ? 0 : HP, 0, ax ? HP : 0, 6)); }
      if (r.hip) {
        for (const aa of [g.A0, g.A1]) { const p = P(aa, g.cc, g.ey - 0.08); D(box(ax ? 0.07 : g.C1 - g.C0, 0.2, ax ? g.C1 - g.C0 : 0.07, p[0], p[1], p[2], ED)); }
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) D(stick(P(aa, c, g.ey + 0.04), P(ra, g.cc, g.top + 0.05), 0.12, 0.12, RC, 5));
      } else {
        for (const aa of [g.a0w + 0.06, g.a1w - 0.06]) { const p = P(aa, g.cc, y); D({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: o.gable || '#e8dcc6', ry: ax ? 0 : HP, cs: 1 }); }
        for (const aa of [g.A0, g.A1]) for (const s of [-1, 1]) D(stick(P(aa, g.cc + s * g.hw, g.ey - 0.02), P(aa, g.cc, g.top), 0.1, 0.1, RC, 5));
      }
      // печные трубы на коньке
      if (o.chim !== false && g.A1 - g.A0 > 6) for (const f of [0.28, 0.72]) {
        if (R(0, 1) < 0.35) continue;
        const p = P(g.A0 + (g.A1 - g.A0) * f, g.cc + R(-0.8, 0.8), 0), hh = h * 0.7 + 1.0;
        D(box(0.7, hh, 0.55, p[0], y + hh / 2, p[2], o.chimCol || '#a4553c')); HD(box(0.84, 0.14, 0.7, p[0], y + hh + 0.07, p[2], '#6e6a64'));
        H(cyl(0.12, 0.35, p[0], y + hh + 0.3, p[2], '#3a3a3a', 0, 0, 0, 6));
      }
    };
    // дом-массив: штукатурка с тоном, плоская крыша с карнизом или черепичная
    const bld = (x0, z0, x1, z1, h, tint, o) => {
      o = o || {};
      W(x0, z0, x1, z1, h, tint);
      if (o.roof) roof(x0, z0, x1, z1, h, o.roof, 0.55, { hip: o.hip, along: o.along, gable: wc(tint) });
      else cornice(x0, z0, x1, z1, h, wc(tint, 0.93));
    };
    // балкон: плита с толщиной и кронштейнами; ограждение — крашеный профлист или чугунная решётка
    const BALC = ['#3f8a86', '#c25b3a', '#e4d8bc', '#6f8796', '#c79a45', '#8fb8a6'];
    const balcony = (n, c, t, y, w) => {
      const X = isX(n), iron = R(0, 1) < 0.45, col = BALC[Math.floor(R(0, BALC.length - 0.01))];
      wbox(n, c, t, y, w + 0.16, 0.15, 1.05, '#d8d0c0'); wbox(n, c, t, y - 0.12, w - 0.1, 0.09, 0.95, '#b2aa9a', a.hi);
      for (const s of [-1, 1]) { const q = at(n, c, t + s * (w / 2 - 0.3), 0.3); H(box(X ? 0.55 : 0.1, 0.3, X ? 0.1 : 0.55, q[0], y - 0.3, q[1], '#b2aa9a')); }
      if (iron) {
        const r = at(n, c, t, 0.99); D(box(X ? 0.07 : w + 0.06, 0.06, X ? w + 0.06 : 0.07, r[0], y + 1.02, r[1], IRON)); H(box(X ? 0.05 : w, 0.05, X ? w : 0.05, r[0], y + 0.2, r[1], IRON));
        for (const s of [-1, 1]) { const q = at(n, c, t + s * (w / 2 - 0.03), 0.5); HD(box(X ? 0.95 : 0.05, 0.06, X ? 0.05 : 0.95, q[0], y + 1.02, q[1], IRON)); }
        const nb = Math.round(w / 0.13);
        for (let k = 0; k <= nb; k++) { const q = at(n, c, t - w / 2 + k * w / nb, 0.99); H(box(0.025, 0.82, 0.025, q[0], y + 0.6, q[1], IRON)); }
        for (const s of [-1, 1]) for (let k = 1; k < 7; k++) { const q = at(n, c, t + s * (w / 2 - 0.03), 0.99 - k * 0.14); H(box(0.025, 0.82, 0.025, q[0], y + 0.6, q[1], IRON)); }
        for (let k = 0; k < 4; k++) { const q = at(n, c, t - w / 2 + 0.25 + k * (w - 0.5) / 3, 0.99); (k % 3 ? H : HD)(box(0.05, 0.84, 0.05, q[0], y + 0.6, q[1], IRON)); }
      } else {
        const f = at(n, c, t, 0.98); D(box(X ? 0.05 : w, 0.9, X ? w : 0.05, f[0], y + 0.55, f[1], col));
        for (const s of [-1, 1]) { const q = at(n, c, t + s * (w / 2 - 0.03), 0.5); HD(box(X ? 0.95 : 0.05, 0.9, X ? 0.05 : 0.95, q[0], y + 0.55, q[1], col)); }
        const r = at(n, c, t, 1.0); D(box(X ? 0.09 : w + 0.08, 0.06, X ? w + 0.08 : 0.09, r[0], y + 1.03, r[1], '#3a3c3e'));
        // гофра профлиста — тонкими рёбрами (только высокое)
        const nb = Math.round(w / 0.2); for (let k = 1; k < nb; k++) { const q = at(n, c, t - w / 2 + k * w / nb, 1.01); H(box(0.03, 0.86, 0.02, q[0], y + 0.55, q[1], sh(col, 0.85))); }
      }
      if (R(0, 1) < 0.5) {
        for (let k = 0; k < 3; k++) { const q = at(n, c, t - w / 2 + 0.4 + k * (w - 0.8) / 2, 0.8); H(cyl(0.16, 0.24, q[0], y + 0.2, q[1], TERRA, 0, 0, 0, 7, 0.12), { sph: true, r: 0.2, x: q[0], y: y + 0.42, z: q[1], sy: 0.75, color: k % 2 ? '#4f8a3a' : '#e0302c', seg: 6 }); }
      } else {
        const p0 = at(n, c, t - w / 2 + 0.1, 0.6), p1 = at(n, c, t + w / 2 - 0.1, 0.6);
        H(stick([p0[0], y + 1.9, p0[1]], [p1[0], y + 1.9, p1[1]], 0.012, 0.012, '#dddddd', 3));
        for (let k = 0; k < 3; k++) { const q = at(n, c, t - w / 2 + 0.45 + k * 0.58, 0.6); H(box(X ? 0.03 : 0.42, 0.5 + (k % 2) * 0.15, X ? 0.42 : 0.03, q[0], y + 1.6 - (k % 2) * 0.07, q[1], ['#f4f1ea', '#4a86c8', '#e86a5a', '#f2c94c'][(k + Math.floor(R(0, 3.99))) % 4])); }
      }
    };
    const acUnit = (n, c, t, y) => {
      const X = isX(n); wbox(n, c, t, y, 0.82, 0.56, 0.32, '#dedcd6'); wbox(n, c, t, y - 0.33, 0.7, 0.05, 0.36, '#9a9890', a.hi);
      const p = at(n, c, t + 0.12, 0.33); H(cyl(0.19, 0.02, p[0], y, p[1], '#55595d', X ? 0 : HP, 0, X ? HP : 0, 8));
      const q = at(n, c, t - 0.25, 0.25); H(cyl(0.015, y - 0.3, q[0], (y - 0.3) / 2 + 0.15, q[1], '#e8e8e4', 0, 0, 0, 3));
    };
    // окно: наклейка из атласа + настоящий подоконник и сандрик (дают тень и глубину)
    const WCELL = [0, 16, 17, 0, 16, 16];
    const win = (n, c, t, yb, cell, hoodCol) => {
      AD(cell, n, c, t, yb + 1.45, 1.15, 2.3, cell === 1);
      { const q = at(n, c, t, 0.085); (yb < 1 ? D : HD)(box(isX(n) ? 0.17 : 0.9, 0.07, isX(n) ? 0.9 : 0.17, q[0], yb + 0.755, q[1], '#e2dacb')); } wbox(n, c, t, yb + 0.69, 0.76, 0.06, 0.08, '#b8b0a0', a.hi);
      wbox(n, c, t, yb + 2.33, 0.94, 0.12, 0.11, hoodCol || '#ddd3c2', yb < 1 ? null : a.hi); wbox(n, c, t, yb + 2.42, 1.0, 0.06, 0.14, sh(hoodCol || '#ddd3c2', 1.04), a.hi);
    };
    // жилой фасад: ряды окон по этажам (часть светится тёплым), балконы, кондиционеры
    const facade = (n, c, t0, t1, nf, o) => {
      o = o || {};
      if (o.noBase) FACES.push({ n, c, t0: t0 - 0.5, t1: t1 + 0.5, skip: [], base: false }); else face(n, c, t0 - 0.5, t1 + 0.5);
      const fh = o.fh || 3.2, y0 = o.y0 != null ? o.y0 : 3.4, step = o.step || 3.2, cnt = Math.max(1, Math.round((t1 - t0) / step)), sp = (t1 - t0) / cnt;
      const hc = o.hood || '#ddd3c2';
      for (let f = 0; f < nf; f++) for (let i = 0; i < cnt; i++) {
        const t = t0 + (i + 0.5) * sp, yb = y0 + f * fh, lit = R(0, 1) < (o.lit == null ? 0.18 : o.lit);
        const r = R(0, 1);
        if (o.balc && r < o.balc) { balcony(n, c, t, yb + 0.1, 2.0); AD(lit ? 1 : 18, n, c, t, yb + 1.33, 1.15, 2.3, lit); wbox(n, c, t, yb + 2.55, 1.0, 0.12, 0.1, hc, a.hi); }
        else {
          win(n, c, t, yb, lit ? 1 : WCELL[Math.floor(R(0, WCELL.length - 0.01))], hc);
          if (r > 0.8 && o.ac !== false) acUnit(n, c, t + sp * 0.4, yb + 2.0);
        }
      }
      if (o.band) { band(n, c, t0 - 0.45, t1 + 0.45, y0 - 0.06, o.band); for (let f = 1; f < nf; f++) if (o.bands) band(n, c, t0 - 0.45, t1 + 0.45, y0 + f * fh - 0.06, o.band); }
      if (o.pipes) for (const t of o.pipes) pipe(n, c, t, o.pipeH || (y0 + nf * fh));
    };
    // водосточная труба: труба, воронка сверху, отмёт внизу, хомуты
    const pipe = (n, c, t, h) => {
      const X = isX(n), p = at(n, c, t, 0.14), col = '#76736c';
      D({ cyl: true, r: 0.07, h: h - 0.6, x: p[0], y: (h - 0.6) / 2 + 0.3, z: p[1], color: col, seg: 5, open: true });
      HD(box(0.26, 0.3, 0.26, p[0], h - 0.2, p[1], col)); const q = at(n, c, t, 0.3); H(box(X ? 0.34 : 0.16, 0.12, X ? 0.16 : 0.34, q[0], 0.2, q[1], col));
      for (let y = 1.6; y < h - 1; y += 2.4) { const b = at(n, c, t, 0.07); H(box(X ? 0.14 : 0.2, 0.05, X ? 0.2 : 0.14, b[0], y, b[1], '#4a4844')); }
    };
    // первый этаж: двери с наличником и ступенью, витрины, рольставни, афиши, граффити
    const shop = (kind, n, c, t, o) => {
      o = o || {};
      const X = isX(n);
      if (kind === 'door') {
        PD(2, n, c, t, 1.5, 1.5, 3.0); skipAt(n, c, t, 0.85);
        for (const s of [-1, 1]) wbox(n, c, t + s * 0.72, 1.3, 0.16, 2.6, 0.1, '#d8ccb2');
        wbox(n, c, t, 2.78, 1.8, 0.16, 0.2, '#d8ccb2'); wbox(n, c, t, 2.9, 1.9, 0.08, 0.26, '#e6dccb', a.hi);
        wbox(n, c, t, 0.06, 1.7, 0.12, 0.5, '#9e968a');
      } else if (kind === 'shutter') {
        PD(5, n, c, t, 1.5, 2.6, 3.0); skipAt(n, c, t, 1.35);
        wbox(n, c, t, 3.05, 2.8, 0.36, 0.3, '#7e8488'); for (const s of [-1, 1]) wbox(n, c, t + s * 1.33, 1.4, 0.08, 2.8, 0.08, '#5c6064', a.hi);
      } else if (kind === 'store') {
        AD(19, n, c, t, 1.5, 2.7, 3.0, false, 2); skipAt(n, c, t, 1.45);
        for (const s of [-1, 1]) wbox(n, c, t + s * 1.42, 1.5, 0.22, 3.0, 0.14, '#3a4a40');
        wbox(n, c, t, 3.1, 3.1, 0.24, 0.18, '#2c3a33');
      } else if (kind === 'poster') PD(4, n, c, t, 1.7, 1.4, 2.8);
      else if (kind === 'graffiti') PD(3, n, c, t, 2.1, o.w || 2.4, (o.w || 2.4) * 2);
      else if (kind === 'win') { const cell = o.cell === 3 ? 17 : o.cell === 1 ? 4 + 1 : 16; if (cell === 5) FD(1, n, c, t, 1.75, 1.2, 2.4); else win(n, c, t, 0.3, cell); }
      else if (kind === 'lit') { win(n, c, t, 0.25, 1); }
      else if (kind === 'vent') FD(7, n, c, t, o.y || 2.6, 0.9, 1.8);
      else if (kind === 'wanted') FD(6, n, c, t, 1.6, 1.0, 2.0);
      else if (kind === 'box') AD(26, n, c, t, o.y || 1.6, 1.0, 2.0);
      else if (kind === 'plaque') AD(27, n, c, t, o.y || 2.6, 0.9, 1.8);
    };
    // провод/бельевая верёвка с провисом
    const wire = (p0, p1, sag, r) => {
      const n = 4;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n, f = (t) => [p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag, p0[2] + (p1[2] - p0[2]) * t];
        D(stick(f(t0), f(t1), r || 0.026, r || 0.026, '#2a2a2a', 3));
      }
    };
    const CLOTH = ['#f4f1ea', '#4a86c8', '#e86a5a', '#f2c94c', '#8fc0a0', '#d98ab0', '#ffffff', '#3f5f8a'];
    const laundry = (p0, p1, sag) => {
      wire(p0, p1, sag);
      const len = Math.hypot(p1[0] - p0[0], p1[2] - p0[2]), n = Math.max(2, Math.floor(len / 0.75)), ry = Math.atan2(-(p1[2] - p0[2]), p1[0] - p0[0]);
      for (let i = 0; i < n; i++) {
        if (R(0, 1) < 0.25) continue;
        const t = (i + 0.5) / n, y = p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag, hh = R(0.45, 0.85), ww = R(0.35, 0.6);
        D(box(ww, hh, 0.04, p0[0] + (p1[0] - p0[0]) * t, y - hh / 2 - 0.02, p0[2] + (p1[2] - p0[2]) * t, CLOTH[Math.floor(R(0, 7.99))], 0, ry, 0));
      }
    };
    // платан: ствол с ветвями, крона из нескольких облаков листвы; приствольная решётка (низкое укрытие — бордюр)
    const tree = (x, z, k) => {
      k = k || 1;
      hid(x - 0.75, z - 0.75, x + 0.75, z + 0.75, 0.45); hid(x - 0.28, z - 0.28, x + 0.28, z + 0.28, 3.2);
      D(cyl(0.78, 0.42, x, 0.21, z, '#9a9286', 0, 0, 0, 10), cyl(0.7, 0.03, x, 0.43, z, '#3a3026', 0, 0, 0, 10)); H(cyl(0.82, 0.06, x, 0.45, z, '#8a8276', 0, 0, 0, 12));
      const bk = '#8a8070', bk2 = '#a49a86';
      D(stick([x, 0.4, z], [x + 0.12, 2.5 * k, z - 0.08], 0.22, 0.16, bk, 8), stick([x + 0.12, 2.3 * k, z - 0.08], [x + 1.0, 3.7 * k, z + 0.35], 0.13, 0.07, bk2, 6),
        stick([x + 0.12, 2.3 * k, z - 0.08], [x - 0.85, 3.8 * k, z - 0.4], 0.13, 0.07, bk2, 6), stick([x + 0.1, 2.5 * k, z - 0.05], [x + 0.05, 4.3 * k, z + 0.6], 0.11, 0.06, bk, 6));
      const cl = [[0.1, 4.6, 0, 1.45], [1.15, 4.0, 0.45, 1.15], [-1.0, 4.1, -0.45, 1.15], [0.2, 4.0, 1.1, 1.05], [-0.25, 4.2, -1.05, 1.0], [0.55, 5.2, -0.3, 0.95]];
      for (const [ox, oy, oz, r] of cl) L({ sph: true, r: r * k, x: x + ox * k, y: oy * k, z: z + oz * k, sx: 1.15, sy: 0.82, sz: 1.1, ry: R(0, 3), color: ['#6f9a46', '#7aa64e', '#5f8a3e', '#6a9442'][Math.floor(R(0, 3.99))], seg: 9, hs: 6 });
    };
    // уличный фонарь: литой столб с цоколем, кронштейн, фонарь-«колпак»
    const lampPost = (x, z, h, dir) => {
      const dx = Math.sin(dir), dz = Math.cos(dir);
      hid(x - 0.2, z - 0.2, x + 0.2, z + 0.2, h);
      D(cyl(0.2, 0.5, x, 0.25, z, '#2b2d2f', 0, 0, 0, 8), { cyl: true, r: 0.06, r2: 0.1, h: h - 0.6, x, y: (h + 0.6) / 2, z, color: '#2b2d2f', seg: 6, open: true }); H(cyl(0.15, 0.12, x, 0.56, z, '#3a3c3f', 0, 0, 0, 10));
      D(stick([x, h - 0.4, z], [x + dx * 0.7, h - 0.05, z + dz * 0.7], 0.04, 0.04, '#2b2d2f', 4), stick([x + dx * 0.7, h - 0.05, z + dz * 0.7], [x + dx * 1.25, h - 0.1, z + dz * 1.25], 0.04, 0.04, '#2b2d2f', 4));
      const lx = x + dx * 1.25, lz = z + dz * 1.25;
      D({ cyl: true, r: 0.05, r2: 0.36, h: 0.22, x: lx, y: h - 0.2, z: lz, color: '#2b2d2f', seg: 8 }, cyl(0.2, 0.18, lx, h - 0.4, lz, '#ffe2a6', 0, 0, 0, 6));
      H(cyl(0.035, 0.18, lx, h - 0.04, lz, '#2b2d2f', 0, 0, 0, 5));
      a.lamps.push([lx, h - 0.42, lz]);
    };
    // фонарь у стены
    const wallLamp = (n, c, t, y) => {
      const p = at(n, c, t, 0.38), q = at(n, c, t, 0.18);
      D(box(isX(n) ? 0.38 : 0.05, 0.05, isX(n) ? 0.05 : 0.38, q[0], y + 0.32, q[1], IRON), cyl(0.12, 0.28, p[0], y, p[1], '#f7e2a8', 0, 0, 0, 8),
        { cyl: true, r: 0.03, r2: 0.2, h: 0.16, x: p[0], y: y + 0.22, z: p[1], color: IRON, seg: 8 }, cyl(0.13, 0.04, p[0], y - 0.15, p[1], IRON, 0, 0, 0, 8));
      a.lamps.push([p[0], y, p[1], 0.9]);
    };
    // скамья на чугунных ножках
    const bench = (x, z, rot) => {
      const X = !rot; hid(x - (X ? 0.9 : 0.3), z - (X ? 0.3 : 0.9), x + (X ? 0.9 : 0.3), z + (X ? 0.3 : 0.9), 0.5);
      D(box(X ? 1.8 : 0.44, 0.05, X ? 0.44 : 1.8, x, 0.46, z, WOOD_L), box(X ? 1.8 : 0.04, 0.3, X ? 0.04 : 1.8, x + (X ? 0 : 0.27), 0.74, z + (X ? 0.27 : 0), WOOD_L));
      for (let k = 0; k < 3; k++) H(box(X ? 1.81 : 0.02, 0.052, X ? 0.02 : 1.81, x + (X ? 0 : -0.07 + k * 0.15), 0.462, z + (X ? -0.07 + k * 0.15 : 0), '#6a4a30'));
      for (const s of [-0.75, 0.75]) { D(box(X ? 0.07 : 0.5, 0.46, X ? 0.5 : 0.07, x + (X ? s : 0), 0.23, z + (X ? 0 : s), IRON)); H(box(X ? 0.06 : 0.06, 0.5, X ? 0.06 : 0.06, x + (X ? s : 0.27), 0.7, z + (X ? 0.27 : s), IRON)); }
    };
    // поддон с мешками или коробками
    const pallet = (x, z, n, col) => {
      hid(x - 0.6, z - 0.5, x + 0.6, z + 0.5, 0.15 + n * 0.32);
      D(box(1.2, 0.15, 1.0, x, 0.075, z, '#8a6a44')); H(box(1.21, 0.04, 1.01, x, 0.13, z, '#a8865c'));
      for (let i = 0; i < n; i++) { const c2 = col || (i % 2 ? '#c69a62' : '#b98a52'); D(box(1.1, 0.3, 0.9, x, 0.3 + i * 0.32, z, c2)); H(box(1.12, 0.03, 0.06, x, 0.3 + i * 0.32 + 0.08, z + 0.46, sh(c2, 0.8))); }
      H(box(1.12, 0.04, 0.05, x, 0.3 + (n - 1) * 0.32, z + 0.46, '#e8e0cc'));
    };
    // погрузчик: противовес, кабина-каркас, мачта с цепями, вилы, колёса
    const forklift = (x, z, dir, rot) => {
      const s = dir || 1, P = (lx, lz) => rot ? [x - lz, z + lx * s] : [x + lx * s, z + lz], ry = rot ? HP : 0, rx = rot ? 0 : HP, rz = rot ? HP : 0;
      if (rot) hid(x - 0.75, z - 1.6, x + 0.75, z + 1.6, 2.2); else hid(x - 1.6, z - 0.75, x + 1.6, z + 0.75, 2.2);
      let p = P(0.2, 0); D(box(1.5, 0.75, 1.15, p[0], 0.7, p[1], YEL, 0, ry, 0));
      p = P(0.95, 0); D(box(0.45, 0.85, 1.15, p[0], 0.82, p[1], '#4a4a48', 0, ry, 0)); p = P(1.05, 0); D(cyl(0.5, 1.12, p[0], 0.95, p[1], '#4a4a48', rx, 0, rz, 12));
      p = P(0.55, 0); D(box(0.45, 0.12, 0.5, p[0], 1.22, p[1], '#1f1f1f', 0, ry, 0), box(0.45, 0.5, 0.08, p[0] + (rot ? 0 : 0), 1.5, p[1], '#1f1f1f', 0, ry, 0));
      for (const lz of [-0.52, 0.52]) for (const lx of [-0.2, 0.85]) { p = P(lx, lz); D(box(0.07, 1.35, 0.07, p[0], 1.72, p[1], IRON, 0, ry, 0)); }
      p = P(0.32, 0); D(box(1.15, 0.06, 1.12, p[0], 2.4, p[1], IRON, 0, ry, 0)); for (let k = 0; k < 4; k++) { p = P(-0.1 + k * 0.28, 0); H(box(0.04, 0.04, 1.1, p[0], 2.42, p[1], IRON, 0, ry, 0)); }
      p = P(-0.1, 0); D({ torus: true, r: 0.16, tube: 0.025, x: p[0], y: 1.3, z: p[1], rx: 1.0, ry, color: '#1a1a1a', seg: 10 });
      for (const lz of [-0.32, 0.32]) { p = P(-0.62, lz); D(box(0.1, 2.2, 0.1, p[0], 1.2, p[1], '#3a3c3e', 0, ry, 0)); }
      p = P(-0.62, 0); D(box(0.08, 0.1, 0.75, p[0], 2.25, p[1], '#3a3c3e', 0, ry, 0), box(0.08, 0.1, 0.75, p[0], 0.4, p[1], '#3a3c3e', 0, ry, 0));
      p = P(-0.7, 0); D(box(0.06, 0.55, 0.9, p[0], 0.55, p[1], '#2c2e30', 0, ry, 0));
      for (const lz of [-0.28, 0.28]) { p = P(-1.15, lz); D(box(0.95, 0.05, 0.12, p[0], 0.08, p[1], '#3a3c3e', 0, ry, 0)); }
      for (const [lx, lz] of [[-0.3, -0.6], [-0.3, 0.6], [0.85, -0.58], [0.85, 0.58]]) { p = P(lx, lz); D(cyl(lx < 0 ? 0.3 : 0.26, 0.24, p[0], lx < 0 ? 0.3 : 0.26, p[1], '#1c1c1c', rot ? 0 : HP, 0, rot ? HP : 0, 12)); H(cyl(lx < 0 ? 0.15 : 0.13, 0.25, p[0], lx < 0 ? 0.3 : 0.26, p[1], '#c8a020', rot ? 0 : HP, 0, rot ? HP : 0, 8)); }
      p = P(0.95, 0); H(box(0.06, 0.1, 0.5, p[0] + (rot ? 0 : s * 0.5), 1.05, p[1] + (rot ? s * 0.5 : 0), '#d83a2a', 0, ry, 0));
    };
    // грузовик с фургоном (вдоль x, кабина к +x при dir=1)
    const truck = (x, z, dir, col) => {
      const s = dir || 1, cab = '#c64a32';
      hid(x - 3.2, z - 1.15, x + 3.2, z + 1.15, 2.95);
      // фургон: короб с рёбрами, задние двери
      D(box(4.3, 2.45, 2.25, x - s * 0.95, 1.72, z, col || '#e9e4da'), box(4.36, 0.12, 2.3, x - s * 0.95, 2.98, z, sh(col || '#e9e4da', 0.9)));
      for (let k = 0; k < 6; k++) H(box(0.06, 2.4, 2.29, x - s * (2.95 - k * 0.8), 1.72, z, sh(col || '#e9e4da', 0.92)));
      D(box(0.06, 2.2, 2.0, x - s * 3.12, 1.65, z, sh(col || '#e9e4da', 0.85)), box(0.07, 2.2, 0.05, x - s * 3.14, 1.65, z, '#3a3a3a'));
      // кабина: низ, капот, лобовое стекло, решётка, бампер, фары, зеркала
      D(box(1.7, 1.25, 2.15, x + s * 2.15, 1.25, z, cab), box(1.35, 0.8, 2.1, x + s * 2.05, 2.25, z, cab), box(0.6, 0.62, 2.0, x + s * 2.7, 2.2, z, '#22303c', 0, 0, s * 0.18));
      D(box(0.5, 0.45, 2.1, x + s * 2.85, 1.6, z, cab, 0, 0, s * 0.1), box(0.08, 0.5, 1.6, x + s * 3.03, 1.1, z, '#2a2a2a'), box(0.2, 0.3, 2.25, x + s * 3.08, 0.68, z, '#b8bcbe'));
      for (const lz of [-0.82, 0.82]) { D(cyl(0.12, 0.06, x + s * 3.06, 1.05, z + lz, '#fff3d0', 0, 0, HP, 8)); H(box(0.06, 0.32, 0.05, x + s * 1.75, 2.3, z + lz * 1.38, IRON), box(0.04, 0.3, 0.16, x + s * 1.82, 2.3, z + lz * 1.45, '#3a3a3a')); }
      for (const lz of [-0.7, 0.7]) HD(box(0.04, 0.55, 0.85, x + s * 1.35, 1.95, z + lz * 1.53, '#22303c'));
      // рама, баки, колёса с дисками
      D(box(6.2, 0.26, 1.5, x, 0.55, z, '#222'), cyl(0.28, 0.9, x + s * 0.6, 0.62, z + 1.0, '#9aa0a4', HP, 0, 0, 10));
      for (const lx of [-2.3, -1.45, 2.05]) for (const lz of [-0.95, 0.95]) { D(cyl(0.47, 0.32, x + s * lx, 0.47, z + lz, '#1a1a1a', HP, 0, 0, 10)); H(cyl(0.26, 0.34, x + s * lx, 0.47, z + lz, '#8a8e92', HP, 0, 0, 8)); }
      for (const lz of [-1.12, 1.12]) HD(box(1.1, 0.06, 0.4, x + s * 2.05, 0.98, z + lz * 0.98, '#2a2a2a'), box(1.6, 0.06, 0.4, x - s * 1.88, 0.98, z + lz * 0.98, '#2a2a2a'));
      D({ cyl: true, r: 1.2, h: 0.01, x, y: 0.025, z, sx: 2.8, sz: 1.05, color: '#3a332c', seg: 10 });
    };
    // легковая «Волга»: обтекаемый кузов из нескольких объёмов, стёкла, хром, фары, колёса с колпаками
    const car = (x, z, col, rot) => {
      const ry = rot ? HP : 0, P = (lx, lz) => rot ? [x - lz, z + lx] : [x + lx, z + lz], rX = rot ? 0 : HP, rZ = rot ? HP : 0;
      if (rot) hid(x - 0.95, z - 2.45, x + 0.95, z + 2.45, 1.45); else hid(x - 2.45, z - 0.95, x + 2.45, z + 0.95, 1.45);
      let p;
      D(box(4.75, 0.5, 1.8, x, 0.6, z, col, 0, ry, 0));
      p = P(1.72, 0); D(box(1.25, 0.12, 1.72, p[0], 0.88, p[1], col, 0, ry, rot ? 0 : -0.06));
      p = P(-1.8, 0); D(box(1.15, 0.12, 1.72, p[0], 0.88, p[1], col, 0, ry, rot ? 0 : 0.05));
      p = P(-0.15, 0); D(box(2.4, 0.08, 1.74, p[0], 0.88, p[1], col, 0, ry, 0), box(1.75, 0.08, 1.5, p[0], 1.45, p[1], col, 0, ry, 0));
      p = P(0.82, 0); D(box(0.6, 0.55, 1.46, p[0], 1.17, p[1], '#22303a', 0, ry, rot ? 0 : -0.75)); p = P(-1.1, 0); D(box(0.55, 0.55, 1.46, p[0], 1.17, p[1], '#22303a', 0, ry, rot ? 0 : 0.7));
      p = P(-0.15, 0); D(box(1.62, 0.5, 1.56, p[0], 1.17, p[1], '#2c3a46', 0, ry, 0));
      for (const lx of [-1.5, 1.5]) for (const lz of [-0.82, 0.82]) { p = P(lx, lz); D(cyl(0.33, 0.22, p[0], 0.33, p[1], '#1a1a1a', rX, 0, rZ, 10)); H(cyl(0.2, 0.24, p[0], 0.33, p[1], '#d9dde0', rX, 0, rZ, 8)); }
      for (const lx of [-2.4, 2.4]) { p = P(lx, 0); D(box(0.1, 0.13, 1.84, p[0], 0.46, p[1], '#d9dde0', 0, ry, 0)); }
      for (const lz of [-0.62, 0.62]) { p = P(2.36, lz); D(cyl(0.11, 0.08, p[0], 0.7, p[1], '#fff6d8', rX, 0, rZ, 8)); p = P(-2.37, lz); H(box(0.05, 0.12, 0.22, p[0], 0.72, p[1], '#b02a1e', 0, ry, 0)); }
      p = P(2.38, 0); D(box(0.06, 0.18, 0.7, p[0], 0.66, p[1], '#c8ccd0', 0, ry, 0));
      for (const lx of [-1.5, 1.5]) { p = P(lx, 0); HD(box(0.98, 0.1, 1.86, p[0], 0.82, p[1], col, 0, ry, 0)); }
      D({ cyl: true, r: 1, h: 0.01, x, y: 0.025, z, sx: rot ? 1.05 : 2.6, sz: rot ? 2.6 : 1.05, color: '#3a332c', seg: 10 });
    };
    // морской контейнер: короб одним материалом (цвет — оттенком), угловые стойки, верхние балки, торцевые двери с запорами
    const contBox = (x0, z0, x1, z1, y0, col, doorEnd) => {
      B(x0, z0, x1, z1, 2.6, 'hbCont', y0, { tint: col, ch: 1 });
      const dk = sh(col, 0.72), alongX = (x1 - x0) > (z1 - z0), y1 = y0 + 2.6;
      for (const [cx, cz] of [[x0, z0], [x1, z0], [x0, z1], [x1, z1]]) HD(box(0.17, 2.6, 0.17, cx + (cx === x0 ? 0.07 : -0.07), y0 + 1.3, cz + (cz === z0 ? 0.07 : -0.07), dk));
      if (alongX) { for (const zz of [z0 + 0.05, z1 - 0.05]) { D(box(x1 - x0 - 0.1, 0.14, 0.12, (x0 + x1) / 2, y1 - 0.07, zz, dk)); H(box(x1 - x0 - 0.1, 0.16, 0.12, (x0 + x1) / 2, y0 + 0.08, zz, dk)); } }
      else { for (const xx of [x0 + 0.05, x1 - 0.05]) { D(box(0.12, 0.14, z1 - z0 - 0.1, xx, y1 - 0.07, (z0 + z1) / 2, dk)); H(box(0.12, 0.16, z1 - z0 - 0.1, xx, y0 + 0.08, (z0 + z1) / 2, dk)); } }
      // двери на торце: шов посередине, четыре запорных штанги с ручками
      const ends = doorEnd === 0 ? [] : doorEnd === 2 ? [-1, 1] : [doorEnd || 1];
      for (const e of ends) {
        const n = alongX ? (e > 0 ? '+x' : '-x') : (e > 0 ? '+z' : '-z'), c = alongX ? (e > 0 ? x1 : x0) : (e > 0 ? z1 : z0), mid = alongX ? (z0 + z1) / 2 : (x0 + x1) / 2, w = alongX ? z1 - z0 : x1 - x0;
        wbox(n, c, mid, y0 + 1.3, 0.05, 2.3, 0.04, dk);
        for (const o of [-0.62, -0.26, 0.26, 0.62]) { const q = at(n, c, mid + o * w / 2.44, 0.06); H(cyl(0.028, 2.3, q[0], y0 + 1.3, q[1], '#5a5c5e', 0, 0, 0, 5)); const hq = at(n, c, mid + o * w / 2.44 + 0.08, 0.1); H(box(isX(n) ? 0.06 : 0.16, 0.05, isX(n) ? 0.16 : 0.06, hq[0], y0 + 1.15, hq[1], '#5a5c5e')); }
        for (const yy of [y0 + 0.25, y0 + 2.35]) wbox(n, c, mid, yy, w - 0.3, 0.1, 0.05, dk, a.hi);
      }
    };
    const cont = (x0, z0, x1, z1, c1, c2, door) => { contBox(x0, z0, x1, z1, 0, c1, door); if (c2) contBox(x0 + 0.02, z0 + 0.02, x1 - 0.02, z1 - 0.02, 2.6, c2, door == null ? -1 : door); };
    // швартовая тумба (кнехт) — с коллизией
    const bollard = (x, z) => { D(cyl(0.2, 0.5, x, 0.25, z, '#2b2b2b', 0, 0, 0, 8), cyl(0.28, 0.08, x, 0.54, z, '#2b2b2b', 0, 0, 0, 8)); H(cyl(0.26, 0.04, x, 0.02, z, '#3a3a3a', 0, 0, 0, 10)); hid(x - 0.25, z - 0.25, x + 0.25, z + 0.25, 0.58); };
    // стеллаж склада вдоль z: каркас и паллеты с грузом на трёх ярусах
    const rack = (x0, z0, x1, z1) => {
      B(x0, z0, x1, z1, 3.4, 'none', 0, { hidden: true });
      const cx = (x0 + x1) / 2, d = x1 - x0, len = z1 - z0, n = Math.max(1, Math.round(len / 2.6)), bay = len / n;
      for (let i = 0; i <= n; i++) for (const sx of [x0 + 0.05, x1 - 0.05]) D(box(0.09, 3.4, 0.09, sx, 1.7, z0 + i * bay, '#2f5d86'));
      for (let i = 0; i <= n; i++) for (let k = 0; k < 3; k++) H(stick([x0 + 0.05, 0.3 + k * 1.1, z0 + i * bay], [x1 - 0.05, 0.85 + k * 1.1, z0 + i * bay], 0.015, 0.015, '#2f5d86', 3));
      for (const y of [0.15, 1.3, 2.45]) for (const sx of [x0 + 0.05, x1 - 0.05]) D(box(0.1, 0.12, len, sx, y, (z0 + z1) / 2, '#e07a28'));
      for (let i = 0; i < n; i++) for (let lv = 0; lv < 3; lv++) {
        if (R(0, 1) < 0.12) continue;
        const zc = z0 + (i + 0.5) * bay, hh = R(0.7, 0.95), col = ['#c69a62', '#b98a52', '#e8e2d4', '#8fa4ae', '#c25b3a'][Math.floor(R(0, 4.99))];
        D(box(d - 0.25, hh, bay - 0.35, cx, 0.22 + lv * 1.15 + hh / 2, zc, col), box(d - 0.2, 0.08, bay - 0.3, cx, 0.22 + lv * 1.15 + 0.04, zc, '#9a7a52'));
      }
      D(box(d - 0.1, 0.03, len, cx, 3.38, (z0 + z1) / 2, '#6d7175'));
    };
    // висячая лампа склада/кафе
    const pendant = (x, y, z, top) => {
      D({ cyl: true, r: 0.08, r2: 0.36, h: 0.3, x, y, z, color: '#3d4a44', seg: 8 }); H(cyl(0.012, top - y, x, (top + y) / 2 + 0.15, z, '#1a1a1a', 0, 0, 0, 3));
      H({ sph: true, r: 0.09, x, y: y - 0.16, z, color: '#fff2c8', seg: 6 });
      a.lamps.push([x, y - 0.18, z, 1.1]);
    };
    // мебель (коллизия — невидимая коробка)
    const sofa = (x, z, rot, col) => {
      const X = !rot; hid(x - (X ? 1.0 : 0.45), z - (X ? 0.45 : 1.0), x + (X ? 1.0 : 0.45), z + (X ? 0.45 : 1.0), 0.85);
      D(box(X ? 2.0 : 0.9, 0.42, X ? 0.9 : 2.0, x, 0.25, z, col), box(X ? 2.0 : 0.22, 0.5, X ? 0.22 : 2.0, x + (X ? 0 : rot * 0.34), 0.62, z + (X ? 0.34 : 0), col));
      for (const s of [-1, 1]) D(box(X ? 0.2 : 0.9, 0.62, X ? 0.9 : 0.2, x + (X ? s * 0.9 : 0), 0.34, z + (X ? 0 : s * 0.9), col));
      H(box(X ? 0.5 : 0.18, 0.4, X ? 0.18 : 0.5, x + (X ? -0.45 : rot * 0.18), 0.65, z + (X ? 0.2 : -0.45), '#f2c94c'));
    };
    const table = (x, z, w, d, col) => {
      hid(x - w / 2, z - d / 2, x + w / 2, z + d / 2, 0.78);
      D(box(w, 0.07, d, x, 0.75, z, col || WOOD_L));
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) D(box(0.07, 0.72, 0.07, x + sx * (w / 2 - 0.08), 0.36, z + sz * (d / 2 - 0.08), WOOD));
    };
    const chair = (x, z, ry, col) => {
      D(box(0.44, 0.05, 0.44, x, 0.46, z, col || WOOD, 0, ry, 0), box(0.44, 0.5, 0.05, x - Math.sin(ry) * 0.2, 0.72, z - Math.cos(ry) * 0.2, col || WOOD, 0, ry, 0));
      for (const [ox, oz] of [[-0.18, -0.18], [0.18, -0.18], [-0.18, 0.18], [0.18, 0.18]]) H(box(0.04, 0.44, 0.04, x + ox, 0.22, z + oz, '#3a2a1a'));
    };
    // столик кафе с зонтом
    const terrace = (x, z, col) => {
      hid(x - 0.45, z - 0.45, x + 0.45, z + 0.45, 0.78);
      D(cyl(0.45, 0.04, x, 0.76, z, '#f4f1ea', 0, 0, 0, 10), cyl(0.04, 0.74, x, 0.37, z, IRON, 0, 0, 0, 5)); H(cyl(0.24, 0.04, x, 0.02, z, IRON, 0, 0, 0, 10));
      D(cyl(0.03, 2.4, x, 1.2, z, '#e9e3d6', 0, 0, 0, 5), { cyl: true, r: 0.06, r2: 1.35, h: 0.45, x, y: 2.42, z, color: col, seg: 8 }); H({ cyl: true, r: 1.36, r2: 1.36, h: 0.12, x, y: 2.15, z, color: sh(col, 0.9), seg: 8, open: true });
      for (let i = 0; i < 3; i++) { const an = i * 2.1 + 0.4; chair(x + Math.cos(an) * 0.75, z + Math.sin(an) * 0.75, -an - HP, '#2a2c2e'); }
    };
    // тротуар: плитка на земле и низкий гранитный бордюр со стороны улицы (side — сторона бордюра)
    const walk = (x0, z0, x1, z1, side) => {
      floor(x0, z0, x1, z1, 'pave', '#e8dcc6');
      const X = side === '+x' || side === '-x', c = side === '+x' ? x1 : side === '-x' ? x0 : side === '+z' ? z1 : z0, s = sg(side);
      if (X) B(Math.min(c, c - s * 0.22), z0, Math.max(c, c - s * 0.22), z1, 0.06, 'concrete', 0, { solid: false, tint: '#c4beb2' });
      else B(x0, Math.min(c, c - s * 0.22), x1, Math.max(c, c - s * 0.22), 0.06, 'concrete', 0, { solid: false, tint: '#c4beb2' });
    };
    // люк и решётка ливнёвки
    const manhole = (x, z) => D(cyl(0.4, 0.03, x, 0.02, z, '#3a3836', 0, 0, 0, 14), cyl(0.33, 0.035, x, 0.022, z, '#4a4642', 0, 0, 0, 14));
    const grate = (x, z, rot) => { D(box(rot ? 0.4 : 0.8, 0.03, rot ? 0.8 : 0.4, x, 0.02, z, '#2a2a2a')); for (let k = 0; k < 5; k++) H(box(rot ? 0.42 : 0.04, 0.035, rot ? 0.04 : 0.42, x + (rot ? 0 : -0.3 + k * 0.15), 0.025, z + (rot ? -0.3 + k * 0.15 : 0), '#4a4a48')); };

    // ===================== периметр и набережная =====================
    hid(44, -34, 46, 34, 8);
    B(44, -34, 44.7, 34, 1.4, 'concrete', -1.4, { solid: false, tint: '#b8b0a2' });
    floor(34, -34, 44, 4, 'hbSlab'); floor(24, 4, 44, 28, 'hbSlab');
    // гранитный кордон у кромки, деревянный отбойный брус, жёлто-чёрная разметка
    floor(42.9, -34, 44, 34, 'concrete', '#d8d0c2');
    D(box(0.32, 0.24, 68, 43.86, 0.12, 0, '#4a3a2c'), box(0.12, 0.012, 68, 42.75, 0.032, 0, YEL));
    for (let z = -33; z < 34; z += 2) H(box(0.06, 0.013, 1.0, 42.75, 0.034, z, '#1d1d1d'));
    for (const z of [-29, -23, -17, -11, -5, 13, 19, 25]) bollard(43.2, z);
    // отбойные покрышки и вертикальные брусья на стенке причала (видно с воды и с кромки)
    for (let z = -30; z <= 30; z += 7.5) H({ torus: true, r: 0.36, tube: 0.15, x: 44.86, y: -0.5, z, ry: HP, color: '#1b1b1b', seg: 12 });
    for (let z = -32; z <= 32; z += 4) H(box(0.18, 1.3, 0.25, 44.8, -0.7, z, '#3a2e24'));
    // лестницы к воде
    for (const z of [-20, 9]) { for (const s of [-0.3, 0.3]) D(box(0.06, 1.7, 0.06, 44.78, -0.55, z + s, '#3a3c3e')); for (let k = 0; k < 4; k++) H(box(0.05, 0.05, 0.62, 44.78, -1.2 + k * 0.35, z, '#3a3c3e')); H({ torus: true, r: 0.3, tube: 0.04, x: 44.0, y: 0.3, z: z - 0.32, ry: HP, rx: HP, color: '#3a3c3e', seg: 10 }); }
    // спасательные круги на стойках
    for (const z of [-12, 16]) { D({ torus: true, r: 0.3, tube: 0.075, x: 43.7, y: 1.05, z, ry: HP, color: '#e8531f', seg: 10 }, box(0.08, 1.4, 0.08, 43.7, 0.7, z - 0.42, '#ddd'), box(0.08, 1.4, 0.08, 43.7, 0.7, z + 0.42, '#ddd'), box(0.1, 0.08, 0.95, 43.7, 1.42, z, '#ddd')); hid(43.6, z - 0.5, 43.8, z + 0.5, 1.4); }

    // ===================== юг: рыбный рынок, спавн налётчиков =====================
    // рыночный зал из кирпича за спавном: арочные окна, вывеска, ворота, навесы
    B(-12, -40, 12, -32.5, 7.6, 'brick'); roof(-12, -40, 12, -32.5, 7.6, 2.8, 0.6, { along: 'x', gable: '#8a4a36', col: '#f0d8c8', chim: false });
    for (const x of [-9, -3, 3, 9]) { FD(5, '+z', -32.5, x, 4.9, 1.6, 3.2, true); wbox('+z', -32.5, x, 3.25, 1.9, 0.12, 0.2, '#c8bca8'); wbox('+z', -32.5, x, 6.55, 1.9, 0.18, 0.14, '#c8bca8'); }
    D(box(24.6, 0.3, 0.3, 0, 7.45, -32.38, '#7a3a2a'));
    PD(2, '+z', -32.5, 0, 1.5, 1.8, 3.2); AD(21, '+z', -32.5, 0, 3.5, 3.6, 3.6, false, 2);
    for (const s of [-1, 1]) wbox('+z', -32.5, s * 1.05, 1.5, 0.22, 3.0, 0.16, '#c8bca8');
    FD(6, '+z', -32.5, -6, 1.7, 1.0, 2.0); PD(4, '+z', -32.5, 5.6, 1.7, 1.4, 2.8);
    a.awning(-6, 3.0, -32.5, 5.0, 1.5, '+z', TEAL); a.awning(6, 3.0, -32.5, 5.0, 1.5, '+z', '#b0392b');
    // прилавки с рыбой: мраморная столешница, лёд, рыба, весы
    for (const x0 of [-8.5, 3.5]) {
      hid(x0, -32.5, x0 + 5, -31.3, 0.95);
      D(box(5, 0.86, 1.2, x0 + 2.5, 0.43, -31.9, '#6a4a30'), box(5.1, 0.08, 1.3, x0 + 2.5, 0.9, -31.9, '#d8dcdc'), box(4.9, 0.06, 1.0, x0 + 2.5, 0.97, -31.9, '#eef4f6'));
      for (let i = 0; i < 5; i++) { D(box(0.8, 0.14, 0.6, x0 + 0.55 + i * 0.98, 1.05, -31.85, '#3a6a8a')); for (let k = 0; k < 3; k++) H({ sph: true, r: 0.12, x: x0 + 0.4 + i * 0.98 + k * 0.15, y: 1.15, z: -31.85 + R(-0.15, 0.15), sx: 2.2, sy: 0.5, color: ['#b8c4cc', '#d88a6a', '#9aa8b0'][k], seg: 6 }); }
      H(box(0.35, 0.12, 0.3, x0 + 4.6, 1.06, -31.6, '#d8d8d4'), box(0.3, 0.02, 0.3, x0 + 4.6, 1.14, -31.6, '#b8b8b4'));
    }
    // дома южного ряда
    bld(-44, -40, -27, -28, 10.4, PEACH); bld(-27, -40, -12, -28, 8.6, CREAM, { roof: 2.4, along: 'x' });
    bld(12, -40, 23, -28, 9.2, SALMON, { roof: 2.2, along: 'x' }); bld(23, -40, 34, -28, 7.4, OCHRE);
    facade('+z', -28, -43, -27.5, 2, { balc: 0.45, band: '#d9c3a8', bands: true, pipes: [-27.4] }); facade('+z', -28, -26.5, -12.5, 1, { balc: 0.3, band: '#e0d2b8', pipes: [-12.4] });
    facade('+z', -28, 12.5, 22.5, 1, { balc: 0.35, band: '#d8b49c', pipes: [12.4, 22.6] }); facade('+z', -28, 23.5, 33.5, 1, { lit: 0.35, band: '#dcc49a', pipes: [33.6] });
    shop('shutter', '+z', -28, -40); shop('door', '+z', -28, -36.5); shop('poster', '+z', -28, -33); shop('graffiti', '+z', -28, -30.6, { w: 2.2 });
    shop('door', '+z', -28, -22.5); shop('store', '+z', -28, -18.5); shop('shutter', '+z', -28, -14.6);
    shop('shutter', '+z', -28, 15); shop('door', '+z', -28, 19); shop('poster', '+z', -28, 21.6); shop('win', '+z', -28, 26, { cell: 0 }); shop('door', '+z', -28, 29.5); shop('graffiti', '+z', -28, 32);
    shop('box', '+z', -28, -25.2); shop('plaque', '+z', -28, 13.4);
    a.awning(-18.5, 3.25, -28, 3.2, 1.3, '+z', TEAL); a.awning(15, 3.0, -28, 3.2, 1.3, '+z', TEAL);
    walk(-43, -28, -12.2, -26.9, '+z'); walk(12.2, -28, 34, -26.9, '+z');
    // спавн налётчиков: ящики с рыбой, тележка, бочки, мотороллер
    box3(-10.6, -30.6, 1.3, 1.2, 1.1); box3(-10.75, -30.55, 1.0, 0.9, 0.9, 1.2);
    crate(10.7, -23.4, 1.0); crate(-10.6, -23.5, 0.95); box3(9.8, -31.6, 1.2, 0.9, 0.9);
    a.barrel(11.2, -31.2, '#2f5f8a'); a.barrel(11.2, -30.3, '#8a2d22');
    lampPost(-11.3, -27.2, 5.6, HP); lampPost(11.3, -27.2, 5.6, -HP);
    manhole(-4, -27.5); manhole(5.5, -24); grate(-0.5, -28.3);
    // южный конец набережной: стенка из контейнеров
    cont(34, -34, 40, -31.5, RED_C, TEAL_C, 1); cont(40, -34, 44, -31.5, ORANGE_C, null, 0);

    // ===================== улица к апартаментам (запад) =====================
    bld(-18, -22, -6, -8, 10.2, SAND, { roof: 2.4, along: 'z' }); bld(-18, -8, -12, -4, 10.2, SAND);
    facade('-z', -22, -17.5, -6.5, 2, { balc: 0.5, band: '#dcc8a4', bands: true, pipes: [-6.4] }); facade('+x', -6, -21.5, -8.5, 2, { balc: 0.3, band: '#dcc8a4', bands: true });
    shop('shutter', '-z', -22, -15); shop('door', '-z', -22, -10.5); shop('poster', '-z', -22, -8);
    shop('win', '+x', -6, -19.5, { cell: 3 }); shop('door', '+x', -6, -16.5); shop('graffiti', '+x', -6, -13.5); shop('shutter', '+x', -6, -10.5);
    a.awning(-6, 3.0, -16.5, 2.6, 1.2, '+x', '#b0392b');
    car(-20.5, -25.2, '#7aa0b8'); bench(-14.5, -27.4); lampPost(-24, -27.5, 5.6, 0);
    // мусорные баки
    for (const [x, c] of [[-33.9, '#3f6a4a'], [-32.7, '#2f5a7a']]) { D(box(1.1, 1.15, 1.0, x, 0.6, -27.3, c), box(1.16, 0.08, 1.06, x, 1.2, -27.3, sh(c, 0.8))); for (const s of [-0.4, 0.4]) D(cyl(0.08, 0.06, x + s, 0.08, -26.85, '#1a1a1a', HP, 0, 0, 8)); }
    hid(-34.5, -27.85, -32.1, -26.75, 1.25);

    // ===================== жилой дом с подъездом (апартаменты) =====================
    const AW = '#e8b89c', AU = PEACH;
    // первый этаж: наружные стены 0.4, проёмы: подъезд (юг), выход во двор (север)
    W(-38, -22, -29.5, -21.6, 3.4, AW); W(-27.5, -22, -18, -21.6, 3.4, AW);
    W(-38, -6.4, -29.5, -6, 3.4, AW); W(-27.5, -6.4, -18, -6, 3.4, AW);
    W(-38, -21.6, -37.6, -6.4, 3.4, AW); W(-18.4, -21.6, -18, -6.4, 3.4, AW);
    W(-29.5, -22, -27.5, -21.6, 0.8, AW, 2.6); W(-29.5, -6.4, -27.5, -6, 0.8, AW, 2.6);
    // глухие подсобки по бокам вестибюля
    W(-37.6, -21.6, -32, -15.8, 3.4, '#efe2cc'); W(-24.4, -21.6, -18.4, -15.8, 3.4, '#efe2cc');
    // перегородки: вестибюль | коридор | две квартиры
    W(-32, -16.2, -30, -15.8, 3.4, '#efe2cc'); W(-27, -16.2, -24.4, -15.8, 3.4, '#efe2cc');
    W(-30.4, -15.8, -30, -12.3, 3.4, '#efe2cc'); W(-30.4, -10.7, -30, -6.4, 3.4, '#efe2cc'); W(-30.4, -12.3, -30, -10.7, 0.8, '#efe2cc', 2.6);
    W(-27, -15.8, -26.6, -9.3, 3.4, '#efe2cc'); W(-27, -7.7, -26.6, -6.4, 3.4, '#efe2cc'); W(-27, -9.3, -26.6, -7.7, 0.8, '#efe2cc', 2.6);
    // этажи над первым — один массив; плита пола между этажами снаружи — пояс
    W(-38, -22, -18, -6, 10.4, AU, 3.4); cornice(-38, -22, -18, -6, 13.8, wc(AU, 0.93));
    facade('-z', -22, -37.5, -18.5, 3, { balc: 0.55, pipes: [-37.8, -18.2], pipeH: 13.6, band: '#d8c6ac', bands: true, y0: 3.6, noBase: true }); facade('+z', -6, -37.5, -18.5, 3, { balc: 0.55, y0: 3.6, band: '#d8c6ac', bands: true, noBase: true }); facade('-x', -38, -21.5, -6.5, 3, { balc: 0.4, y0: 3.6, pipes: [-14], band: '#d8c6ac', bands: true });
    // цоколь первого этажа апартаментов (стены первого этажа тоньше, поэтому отдельно)
    B(-38.08, -22.08, -29.5, -21.98, 0.6, 'concrete', 0, { solid: false, tint: '#c9c0b0' }); B(-27.5, -22.08, -17.92, -21.98, 0.6, 'concrete', 0, { solid: false, tint: '#c9c0b0' });
    // полы внутри
    floor(-30, -21.6, -24.4, -16.2, 'pave', '#f2ece0'); floor(-30, -16.2, -27, -6.4, 'pave', '#f2ece0');
    floor(-37.6, -15.8, -30.4, -6.4, 'planks', '#f0d6b8'); floor(-26.6, -15.8, -18.4, -6.4, 'planks', '#f6dcc0');
    floor(-29.5, -22, -27.5, -21.6, 'pave', '#f2ece0'); floor(-29.5, -6.4, -27.5, -6, 'pave', '#f2ece0');
    // подъезд снаружи: бетонный козырёк на стойках, наличник, табличка, урна
    D(box(3.2, 0.16, 1.5, -28.5, 3.05, -22.75, '#cfc8b8'), box(3.3, 0.06, 1.6, -28.5, 3.16, -22.75, '#b8b0a0'), cyl(0.05, 2.97, -30, 1.49, -23.4, IRON, 0, 0, 0, 6), cyl(0.05, 2.97, -27, 1.49, -23.4, IRON, 0, 0, 0, 6));
    hid(-30.08, -23.48, -29.92, -23.32, 3.0); hid(-27.08, -23.48, -26.92, -23.32, 3.0);
    for (const s of [-1, 1]) wbox('-z', -22, -28.5 + s * 1.08, 1.35, 0.16, 2.7, 0.08, '#d8ccb2');
    D(box(0.06, 2.4, 0.95, -29.4, 1.2, -22.1, '#5a3a22', 0, 0.9, 0)); H(box(0.4, 0.28, 0.03, -26.9, 2.0, -22.03, '#2a5ea8'));
    PD(7, '-z', -22, -25.6, 2.2, 1.2, 2.4); shop('graffiti', '-z', -22, -34.5, { w: 2.0 }); shop('poster', '-z', -22, -20.2); shop('box', '-z', -22, -31.6);
    D(cyl(0.22, 0.7, -26.4, 0.35, -22.5, '#4a5a4a', 0, 0, 0, 10)); hid(-26.65, -22.75, -26.15, -22.25, 0.7);
    // вестибюль: лестница наверх (декор), почтовые ящики, лампа, батарея, фикус
    hid(-32, -21.6, -30.5, -16.2, 3.4);
    for (let i = 0; i < 9; i++) D(box(1.4, 0.36 * (i + 1), 0.52, -31.3, 0.18 * (i + 1), -21.3 + i * 0.52, i % 2 ? '#a8998a' : '#b4a593'), box(1.42, 0.05, 0.08, -31.3, 0.36 * (i + 1) - 0.02, -21.56 + i * 0.52, '#5a4636'));
    D(stick([-30.58, 0.1, -21.56], [-30.58, 3.3, -16.9], 0.12, 0.12, '#5a4636', 4));
    for (let i = 0; i < 4; i++) D(box(0.05, 1.0, 0.05, -30.55, 0.36 * (i * 2 + 1) + 0.5, -21.3 + i * 1.04, IRON));
    D(stick([-30.55, 1.36, -21.3], [-30.55, 4.24, -17.14], 0.03, 0.03, '#5a3a22', 4));
    D(box(0.2, 0.9, 1.6, -24.5, 1.5, -19.2, '#6f7a80')); for (let r = 0; r < 3; r++) for (let k = 0; k < 4; k++) H(box(0.03, 0.22, 0.32, -24.39, 1.2 + r * 0.28, -19.8 + k * 0.4, '#8c979d'));
    D(box(0.12, 0.6, 1.0, -24.45, 0.5, -17.2, '#e6e2d8')); PD(4, '-x', -24.435, -17.4, 1.9, 0.9, 1.8);
    D(cyl(0.22, 0.4, -25.0, 0.2, -21.1, TERRA, 0, 0, 0, 8)); L({ sph: true, r: 0.42, x: -25.0, y: 0.9, z: -21.1, sy: 1.3, color: '#4f8a3a', seg: 8, hs: 6 }); hid(-25.3, -21.4, -24.7, -20.8, 1.2);
    pendant(-27.2, 2.9, -19, 3.4); pendant(-28.5, 2.9, -11, 3.4);
    // коридор: двери квартир (открытые створки), наличники, коврик
    D(box(0.85, 2.2, 0.05, -30.85, 1.1, -12.25, '#7a5434'), box(0.85, 2.2, 0.05, -26.15, 1.1, -9.25, '#7a5434'));
    for (const [xx, z0, z1, n] of [[-30, -12.3, -10.7, '+x'], [-27, -9.3, -7.7, '-x']]) { for (const zz of [z0, z1]) wbox(n, xx, zz, 1.3, 0.12, 2.6, 0.05, '#e8e0d0'); wbox(n, xx, (z0 + z1) / 2, 2.66, 1.84, 0.12, 0.05, '#e8e0d0'); }
    D(box(1.6, 0.012, 2.2, -28.5, 0.03, -20, '#8a3a2c'));
    // западная квартира: гостиная + кухня
    sofa(-36.9, -13.4, -1, '#4a6a8a'); table(-34.9, -13.4, 0.8, 1.1, '#7a5434');
    D(box(1.9, 0.012, 2.8, -35.3, 0.03, -13.4, '#b8563e'), box(1.6, 0.014, 2.4, -35.3, 0.031, -13.4, '#d8a070'));
    hid(-33.4, -15.8, -31.0, -15.3, 1.9); D(box(2.4, 1.9, 0.45, -32.2, 0.95, -15.55, '#5a3a22')); for (let k = 0; k < 3; k++) for (let i = 0; i < 8; i++) H(box(0.07, R(0.3, 0.42), 0.28, -33.2 + i * 0.28, 0.45 + k * 0.6, -15.5, ['#8a2a2a', '#2a4a6a', '#3a5a32', '#c8a050'][(i + k) % 4]));
    hid(-31.0, -14.6, -30.4, -13.2, 1.1); D(box(0.5, 0.5, 1.3, -30.7, 0.25, -13.9, '#3a2a1a'), box(0.08, 0.6, 1.1, -30.75, 0.85, -13.9, '#111418'));
    hid(-37.6, -7.0, -33.6, -6.4, 0.95); D(box(4.0, 0.9, 0.6, -35.6, 0.45, -6.7, '#d8d4ca'), box(4.0, 0.05, 0.62, -35.6, 0.92, -6.7, '#8a6a4a'), box(2.6, 0.7, 0.35, -36.3, 2.1, -6.6, '#d8d4ca'));
    hid(-33.5, -7.1, -32.8, -6.4, 1.8); D(box(0.7, 1.8, 0.7, -33.15, 0.9, -6.75, '#eeeeea'));
    table(-33.6, -9.2, 1.1, 0.8, '#c8a878'); chair(-33.6, -8.6, Math.PI); chair(-34.4, -9.2, -HP); chair(-32.8, -9.2, HP);
    for (const z of [-13.5, -9]) { PD(0, '+x', -37.565, z, 1.7, 1.1, 2.2); win('-x', -38, z, 0.25, 16); }
    pendant(-34.8, 2.8, -12.5, 3.4); D(box(1.1, 0.75, 0.04, -32.0, 1.7, -6.43, '#c8b88a')); H(box(0.9, 0.55, 0.02, -32.0, 1.7, -6.45, '#6a8aa8'));
    // восточная квартира: спальня + столовая
    hid(-20.8, -15.4, -18.4, -12.8, 0.6); D(box(2.3, 0.45, 2.5, -19.6, 0.3, -14.1, '#e8e0d0'), box(0.1, 1.0, 2.5, -18.5, 0.6, -14.1, '#6a4a2e'), box(2.0, 0.08, 2.3, -19.7, 0.56, -14.1, '#c25b6a'));
    H(box(0.5, 0.15, 0.7, -18.9, 0.62, -14.6, '#f4f1ea'), box(0.5, 0.15, 0.7, -18.9, 0.62, -13.6, '#f4f1ea'));
    hid(-24.6, -15.8, -22.0, -15.2, 2.1); D(box(2.6, 2.1, 0.6, -23.3, 1.05, -15.5, '#8a6a46'), box(0.02, 1.9, 0.02, -23.3, 1.05, -15.19, '#3a2a1a'));
    table(-22.5, -9.6, 1.4, 0.9, '#9c7350'); chair(-22.5, -8.9, Math.PI, '#c25b3a'); chair(-22.5, -10.3, 0, '#c25b3a'); chair(-23.4, -9.6, -HP, '#c25b3a');
    hid(-19.2, -9.0, -18.4, -7.2, 0.9); D(box(0.8, 0.9, 1.8, -18.8, 0.45, -8.1, '#d8d4ca'), box(0.82, 0.05, 1.82, -18.8, 0.92, -8.1, '#5a5a5a'));
    hid(-26.6, -14.6, -25.9, -13.0, 1.1); D(box(0.6, 1.1, 1.6, -26.25, 0.55, -13.8, '#6a7a5a'));
    D(box(2.4, 0.012, 1.8, -22.5, 0.03, -12.6, '#2f6f8a'));
    for (const x of [-24.5, -20.5]) { PD(0, '-z', -6.435, x, 1.7, 1.1, 2.2); }
    pendant(-22.5, 2.8, -9.6, 3.4); pendant(-20.5, 2.8, -13.5, 3.4);
    H(box(0.9, 0.6, 0.03, -20.5, 1.8, -15.74, '#d8b878'));
    for (const [x, l] of [[-35.5, 1], [-32.2, 0], [-24.5, 1], [-20.5, 0]]) win('+z', -6, x, 0.25, l ? 1 : 0);
    // отделка: обои/краска тонкими панелями штукатурки (тот же меш), плинтус и поручень-раскладка
    const skin = (n, c, t0, t1, y0, y1, tint) => {
      const s = NN[n][0] + NN[n][1], a0 = t0 + 0.02, a1 = t1 - 0.02, c0 = s > 0 ? c : c - 0.03, c1 = s > 0 ? c + 0.03 : c;
      if (isX(n)) B(c0, a0, c1, a1, y1 - y0, 'hbPlaster', y0, { solid: false, tint }); else B(a0, c0, a1, c1, y1 - y0, 'hbPlaster', y0, { solid: false, tint });
    };
    const trim = (n, c, t0, t1, y, hh, col) => wbox(n, c + (NN[n][0] + NN[n][1]) * 0.03, (t0 + t1) / 2, y, t1 - t0, hh, 0.04, col);
    const ENT = [['+z', -21.6, -30.5, -29.5], ['+z', -21.6, -27.5, -24.4], ['-x', -24.4, -21.6, -16.2], ['-z', -16.2, -27, -24.4],
      ['+x', -30, -15.8, -12.3], ['+x', -30, -10.7, -6.4], ['-x', -27, -15.8, -9.3], ['-x', -27, -7.7, -6.4]];
    for (const [n, c, t0, t1] of ENT) { skin(n, c, t0, t1, 0, 1.25, '#5f9d93'); trim(n, c, t0, t1, 1.27, 0.06, '#4a3424'); }
    const FL1 = [['+x', -37.6, -15.8, -6.4], ['-x', -30.4, -15.8, -12.3], ['-x', -30.4, -10.7, -6.4], ['+z', -15.8, -37.6, -30.4], ['-z', -6.4, -37.6, -30.4]];
    const FL2 = [['+x', -26.6, -15.8, -9.3], ['+x', -26.6, -7.7, -6.4], ['-x', -18.4, -15.8, -6.4], ['+z', -15.8, -26.6, -18.4], ['-z', -6.4, -26.6, -18.4]];
    for (const [L2, tint] of [[FL1, '#f0c890'], [FL2, '#b8d8c8']]) for (const [n, c, t0, t1] of L2) { skin(n, c, t0, t1, 0, 3.4, tint); trim(n, c, t0, t1, 0.07, 0.14, '#4a3424'); trim(n, c, t0, t1, 3.32, 0.12, '#f4eee2'); }
    B(-37.6, -21.6, -18.4, -6.4, 0.02, 'hbPlaster', 3.36, { solid: false, tint: '#fff4e2' });
    D(box(0.05, 0.8, 1.1, -37.53, 1.75, -11.2, '#6a4a2e'), box(0.05, 0.62, 0.92, -37.5, 1.75, -11.2, '#d98a4a'));
    H(box(0.05, 0.3, 0.5, -37.49, 1.8, -11.35, '#3f7f9a'), box(0.05, 0.22, 0.3, -37.49, 1.62, -10.95, '#f2d06a'));
    D(box(0.9, 0.62, 0.05, -22.6, 1.8, -15.73, '#6a4a2e'), box(0.74, 0.48, 0.05, -22.6, 1.8, -15.7, '#7aa8c8'));
    D(cyl(0.22, 0.05, -18.47, 2.3, -10.8, '#f4f1ea', 0, 0, HP, 12)); H(box(0.02, 0.16, 0.02, -18.5, 2.36, -10.8, '#1d1d1d'), box(0.02, 0.02, 0.12, -18.5, 2.3, -10.75, '#1d1d1d'));
    D(box(1.4, 0.012, 3.0, -22.4, 0.032, -9.6, '#a8443a'), box(1.1, 0.014, 2.6, -22.4, 0.034, -9.6, '#e8c890'));

    // ===================== западный проулок с бельём =====================
    bld(-50, -34, -41.5, -18, 11.6, SALMON); bld(-50, -18, -41.5, -6, 13.2, CREAM); bld(-50, -6, -41.5, 2, 9.2, OCHRE, { roof: 2, along: 'z' });
    facade('+x', -41.5, -27.5, -18.5, 2, { balc: 0.25, band: '#d9b49c', bands: true }); facade('+x', -41.5, -17.5, -6.5, 3, { balc: 0.25, band: '#e6d6b8' }); facade('+x', -41.5, -5.5, 1.5, 1, { lit: 0.4, band: '#dcc49a' });
    shop('graffiti', '+x', -41.5, -24.5, { w: 2.6 }); shop('door', '+x', -41.5, -20.5); shop('poster', '+x', -41.5, -14); shop('graffiti', '-x', -38, -17.5, { w: 2.2 }); shop('vent', '-x', -38, -11.5);
    shop('door', '+x', -41.5, -9.5); shop('wanted', '+x', -41.5, -3.5); shop('box', '+x', -41.5, -12.2);
    for (const [z, y] of [[-25.5, 5.2], [-21.5, 8.4], [-17.5, 5.6], [-13.5, 8.8], [-9.5, 5.0]]) laundry([-41.5, y, z - 0.3], [-38, y + 0.3, z + 0.4], 0.45);
    wire([-41.5, 10.2, -27], [-38, 10.4, -8], 0.6);
    // контейнер-мусорка и ящики (запрыгнуть можно на ящик 1.0)
    hid(-41.5, -16.2, -40.4, -14.2, 1.3); D(box(1.0, 1.2, 1.9, -40.95, 0.6, -15.2, '#3f6a4a'), box(1.1, 0.1, 2.0, -40.95, 1.25, -15.2, '#2f5236'), box(0.06, 0.3, 1.6, -40.42, 0.95, -15.2, '#2f5236'));
    box3(-40.8, -9.6, 1.1, 1.15, 1.1); box3(-40.85, -9.6, 0.85, 0.85, 0.85, 1.15); crate(-38.7, -26.2, 0.9);
    for (let i = 0; i < 4; i++) D({ sph: true, r: 0.32, x: -41.0 + R(-0.1, 0.2), y: 0.24, z: -12.8 + i * 0.45, sy: 0.75, color: i % 2 ? '#1d1f22' : '#2b2e33', seg: 7 });
    pipe('+x', -41.5, -18.3, 11.4); pipe('-x', -38, -21.6, 13.6);
    manhole(-39.8, -19); grate(-39.6, -6.5, 1);

    // ===================== двор B и подворотня с площади =====================
    floor(-41.5, -6, -18, 2, 'hbSlab');
    // подворотня: проход под домом (z −4…0), арки на обоих концах, своды-балки, фонарь
    W(-18, 0, -12, 8, 11, ROSE); W(-18, -4, -12, 0, 6.6, SAND, 3.6); cornice(-18, -4, -12, 0, 10.2, wc(SAND, 0.93)); cornice(-18, 0, -12, 8, 11, wc(ROSE, 0.93));
    for (const x of [-18.05, -11.95]) {
      for (const s of [-1, 1]) D({ shape: true, pts: [[s * 2, 3.6], [0, 3.6], ['c', s * 1.1, 3.6, s * 2, 2.7, s * 2, 1.6]], d: 0.14, x, y: 0, z: -2, color: wc(SAND, 0.98), ry: 0, cs: 7 });
      // архивольт: каменная обводка арки и замковый камень
      for (let k = 0; k <= 8; k++) { const an = Math.PI * k / 8, px = Math.cos(an) * 1.98, py = 2.0 + Math.sin(an) * 1.58; D(box(0.14, 0.22, 0.42, x + (x < -15 ? -0.07 : 0.07), py, -2 + px, '#d8ccb6', an - HP, 0, 0)); }
      D(box(0.18, 0.5, 0.36, x + (x < -15 ? -0.09 : 0.09), 3.62, -2, '#cfc2aa'));
    }
    for (const z of [-3.9, -0.1]) for (const x of [-18, -12]) D(box(0.3, 1.6, 0.3, x + (x < -15 ? 0.15 : -0.15), 0.8, z, '#cbc2b2'));
    floor(-18, -4, -12, 0, 'pave', '#e8dcc8'); pendant(-15, 3.2, -2, 3.6);
    for (const xx of [-16.5, -15, -13.5]) D(box(0.2, 0.18, 4.0, xx, 3.5, -2, '#4a3a2e'));
    PD(3, '+z', -4, -15, 2.0, 2.2, 4.4); PD(4, '-z', 0, -16.4, 1.7, 1.4, 2.8); PD(7, '-x', -18, -5.2, 2.0, 1.4, 2.8);
    facade('+x', -12, 0.5, 7.5, 2, { balc: 0.3, band: '#dfb2a6', bands: true, pipes: [7.9] }); facade('+x', -12, -7.5, -4.5, 2, { band: '#dcc8a4' });
    shop('poster', '+x', -12, -6); shop('lit', '+x', -12, 6.2); PD(7, '+x', -12, 0.8, 2.2, 1.0, 2.0);
    // грузовик у склада, поддоны, бочки
    truck(-23.2, -0.4, 1, '#d8d2c4'); pallet(-36.4, -4.6, 2); pallet(-35.0, -4.8, 1, '#8fa4ae'); box3(-38.8, 0.6, 1.2, 1.15, 1.1); box3(-38.75, 0.62, 0.9, 0.9, 0.9, 1.15);
    a.barrel(-40.8, 1.1, '#2f5f8a'); a.barrel(-40.6, 0.2, '#8a2d22'); a.barrel(-19.0, -5.3, '#3b5f3a');
    lampPost(-33.5, -5.5, 5.4, 0); manhole(-30, -2.5); grate(-25.5, 1.4);

    // ===================== склад №3 — точка B =====================
    const WH = 8;
    B(-42, 2, -33, 2.5, WH, 'brick'); B(-28, 2, -18, 2.5, WH, 'brick'); B(-33, 2, -28, 2.5, WH - 3.6, 'brick', 3.6);
    B(-42, 21.5, -25.5, 22, WH, 'brick'); B(-21.5, 21.5, -18, 22, WH, 'brick'); B(-25.5, 21.5, -21.5, 22, WH - 3.6, 'brick', 3.6);
    B(-42, 2.5, -41.5, 21.5, WH, 'brick'); B(-18.5, 2.5, -18, 21.5, WH, 'brick');
    roof(-42, 2, -18, 22, WH, 3.2, 0.5, { along: 'x', gable: '#7a3f2e', col: '#d8b8a8', chim: false });
    floor(-41.5, 2.5, -18.5, 21.5, 'concrete', '#cfc8bc');
    // кирпичный карниз-пояс и бетонная перемычка над воротами
    for (const zz of [1.98, 22.02]) D(box(24.2, 0.22, 0.14, -30, WH - 0.4, zz, '#6a3a2a'), box(24.3, 0.12, 0.2, -30, WH - 0.24, zz, '#7a4434'));
    D(box(5.6, 0.4, 0.62, -30.5, 3.8, 2.25, '#a8a49a'), box(4.6, 0.4, 0.62, -23.5, 3.8, 21.75, '#a8a49a'));
    // поднятые рольставни в коробах над проёмами, жёлтые отбойники
    D(box(5.2, 0.5, 0.5, -30.5, 3.35, 2.25, '#8a9094'), box(4.2, 0.5, 0.5, -23.5, 3.35, 21.75, '#8a9094'));
    for (const [x, z] of [[-33.1, 2.25], [-27.9, 2.25]]) { D(box(0.14, 3.6, 0.6, x, 1.8, z, YEL)); for (let k = 0; k < 6; k++) H(box(0.15, 0.22, 0.61, x, 0.3 + k * 0.6, z, '#1d1d1d')); }
    for (const [x, z] of [[-25.6, 21.75], [-21.4, 21.75]]) { D(box(0.14, 3.6, 0.6, x, 1.8, z, YEL)); for (let k = 0; k < 6; k++) H(box(0.15, 0.22, 0.61, x, 0.3 + k * 0.6, z, '#1d1d1d')); }
    AD(24, '-z', 2, -30.5, 5.0, 4.2, 4.2, false, 2);
    // фермы под крышей, прогоны, световые фонари
    for (const x of [-37, -30, -23]) { D(box(0.25, 0.35, 19.5, x, WH - 0.2, 12, '#4a3a2e')); for (const s of [-1, 1]) D(stick([x, WH - 0.1, 12 + s * 9.7], [x, WH + 2.9, 12], 0.12, 0.12, '#4a3a2e', 5)); D(box(0.2, 3.0, 0.2, x, WH + 1.4, 12, '#4a3a2e')); for (const s of [-1, 1]) H(stick([x, WH - 0.1, 12 + s * 4.8], [x, WH + 1.45, 12], 0.06, 0.06, '#4a3a2e', 4)); }
    for (const z of [7, 12, 17]) H(box(23.4, 0.14, 0.14, -30, WH + 0.2 + Math.abs(z - 12) * 0.0, z, '#5a4a3e'));
    for (const x of [-37, -30, -23]) for (const z of [7, 17]) pendant(x, 5.6, z, WH);
    // окна под крышей: светящиеся промышленные, надписи
    for (const x of [-39.5, -36, -25, -21]) { AD(31, '-z', 2, x, 5.8, 1.4, 2.8, true); AD(31, '+z', 22, x, 5.8, 1.4, 2.8, true); wbox('-z', 2, x, 4.5, 1.5, 0.1, 0.16, '#a8a49a'); wbox('+z', 22, x, 4.5, 1.5, 0.1, 0.16, '#a8a49a'); }
    for (const z of [6, 12, 18]) { AD(31, '-x', -42, z, 5.8, 1.4, 2.8, true); }
    for (const x of [-39.5, -36, -25, -21]) { AD(30, '+z', 2.5, x, 5.8, 1.4, 2.8); AD(30, '-z', 21.5, x, 5.8, 1.4, 2.8); }
    PD(7, '+z', 22, -28, 2.2, 1.6, 3.2); PD(7, '+z', 2.5, -38, 2.4, 2.2, 4.4); PD(7, '-z', 21.5, -32, 2.4, 2.2, 4.4); PD(7, '-x', -18.5, 12, 2.4, 2.2, 4.4);
    PD(3, '-z', 2, -24.2, 2.1, 2.4, 4.8); shop('poster', '-z', 2, -38.5); PD(7, '-z', 2, -35.5, 2.2, 1.6, 3.2);
    // внутри: стеллажи, штабеля, погрузчик, контора мастера; ящики 1.0–1.25 м — на них можно запрыгнуть
    rack(-41.5, 4.5, -40.3, 16.5); rack(-36.4, 8.5, -35.2, 16.5); rack(-27.0, 12.0, -25.8, 18.6);
    box3(-31.2, 7.4, 1.3, 1.25, 1.3); box3(-31.15, 7.45, 1.0, 1.0, 1.0, 1.25); box3(-30.4, 16.2, 1.2, 1.2, 1.2); box3(-30.4, 16.2, 0.95, 0.95, 0.95, 1.2); crate(-29.1, 16.6, 1.0); crate(-22.2, 5.4, 1.2); crate(-21.0, 6.2, 0.9);
    pallet(-33.6, 12.6, 3); pallet(-33.6, 13.8, 2, '#8fa4ae'); pallet(-21.2, 18.2, 3, '#c25b3a'); pallet(-37.8, 4.4, 2);
    forklift(-23.0, 11.5, 1, true);
    cont(-31.5, 19.0, -25.5, 21.5, TEAL_C, null, -1);
    W(-41.5, 18, -37.5, 21.5, 2.8, '#e8ddc8'); D(box(4.2, 0.12, 3.7, -39.5, 2.86, 19.75, '#6f665c'));
    PD(1, '+x', -37.5, 19.75, 1.5, 1.6, 2.0, true); PD(2, '-z', 18, -38.6, 1.3, 1.1, 2.4);
    D(box(0.15, 0.012, 15, -38.0, 0.03, 12, YEL), box(0.15, 0.012, 15, -28.0, 0.03, 12, YEL), box(9.8, 0.012, 0.15, -33, 0.03, 4.5, YEL), box(9.8, 0.012, 0.15, -33, 0.03, 19.5, YEL));
    for (let k = 0; k < 6; k++) H(box(0.6, 0.013, 0.15, -32.5 + k * 1.2, 0.033, 3.2, k % 2 ? '#1d1d1d' : YEL, 0, 0.7, 0));
    a.letter('B', -30.4, 11.6, 4.2);
    hid(-44, 2, -42, 22, 8);
    a.stain(-23, 11.5, 3); a.stain(-30, 12, 3.2);

    // ===================== площадь (середина) =====================
    floor(-12, -8, 12, 8, 'pave', '#f3e4cc');
    for (let i = 0; i < 16; i++) { const an = i / 16 * Math.PI * 2; D(box(0.5, 0.012, 1.3, Math.cos(an) * 3.6, 0.031, Math.sin(an) * 3.6, '#c9b090', 0, -an, 0)); }
    D(cyl(4.4, 0.014, 0, 0.026, 0, '#d8c8a8', 0, 0, 0, 32));
    // памятник «Морякам»: ступенчатый постамент с профилями, бронзовый якорь с цепью — закрывает прострел середины
    B(-1.6, -1.6, 1.6, 1.6, 0.6, 'concrete', 0, { tint: '#d8d2c6' }); B(-1, -1, 1, 1, 2.4, 'concrete', 0.6, { tint: '#e2dcd0' });
    D(box(3.5, 0.14, 3.5, 0, 0.07, 0, '#b8b0a4'), box(2.24, 0.16, 2.24, 0, 0.68, 0, '#c8c0b2'), box(2.12, 0.1, 2.12, 0, 0.81, 0, '#d2cabc'));
    D(box(2.2, 0.12, 2.2, 0, 2.86, 0, '#c8c0b2'), box(2.36, 0.16, 2.36, 0, 3.0, 0, '#d8d0c2'), box(2.12, 0.08, 2.12, 0, 3.12, 0, '#bdb5a7'));
    D(cyl(0.14, 2.6, 0, 4.5, 0, BRONZE, 0, 0, 0, 10), box(1.4, 0.18, 0.18, 0, 5.4, 0, BRONZE), { sph: true, r: 0.12, x: -0.72, y: 5.4, z: 0, color: BRONZE, seg: 8 }, { sph: true, r: 0.12, x: 0.72, y: 5.4, z: 0, color: BRONZE, seg: 8 },
      { torus: true, r: 0.24, tube: 0.07, x: 0, y: 5.95, z: 0, color: BRONZE, seg: 12 });
    { const ap = []; for (let i = 0; i <= 8; i++) { const th = Math.PI + i / 8 * Math.PI; ap.push([Math.cos(th) * 0.8, 4.0 + Math.sin(th) * 0.75]); } for (let i = 0; i < 8; i++) D(stick([ap[i][0], ap[i][1], 0], [ap[i + 1][0], ap[i + 1][1], 0], 0.11, 0.11, BRONZE, 8)); }
    for (const s of [-1, 1]) D({ cyl: true, r: 0.02, r2: 0.2, h: 0.4, x: s * 0.78, y: 4.05, z: 0, rz: s * 0.6, color: BRONZE, seg: 6 });
    for (let i = 0; i < 9; i++) H({ torus: true, r: 0.08, tube: 0.025, x: 0.15 + i * 0.05, y: 5.2 - i * 0.22, z: 0.18, rx: i % 2 ? HP : 0, color: BRONZE, seg: 8 });
    H(box(1.2, 0.5, 0.04, 0, 1.6, -1.03, '#c9a24a'), box(1.2, 0.5, 0.04, 0, 1.6, 1.03, '#c9a24a'));
    for (const [x, z] of [[-1.25, -1.25], [1.25, -1.25], [-1.25, 1.25], [1.25, 1.25]]) D(cyl(0.12, 0.08, x, 0.64, z, '#4a4636', 0, 0, 0, 8));
    // киоск «Союзпечать»: стекло, козырёк, газеты
    hid(3.4, 1.6, 5.6, 3.6, 2.8);
    D(box(2.2, 2.3, 2.0, 4.5, 1.15, 2.6, '#3f7a5a'), box(2.6, 0.2, 2.4, 4.5, 2.45, 2.6, '#2c5a42'), box(2.7, 0.08, 2.5, 4.5, 2.58, 2.6, '#26503a'), box(1.6, 0.9, 0.04, 4.5, 1.4, 1.58, '#c8d4d6'), box(2.6, 0.4, 0.06, 4.5, 2.25, 1.4, '#c64a32'));
    D(box(1.7, 0.06, 0.24, 4.5, 0.95, 1.5, '#2c5a42'));
    for (let i = 0; i < 6; i++) H(box(0.22, 0.3, 0.02, 3.9 + (i % 3) * 0.4, 1.25 + Math.floor(i / 3) * 0.36, 1.55, ['#e86a5a', '#4a86c8', '#f2c94c'][i % 3]));
    // фруктовый лоток с навесом
    hid(-11.6, 1.2, -9.8, 5.2, 1.0);
    D(box(1.8, 0.85, 4.0, -10.7, 0.43, 3.2, '#7a5a3c'), box(1.9, 0.06, 4.1, -10.7, 0.88, 3.2, '#5a3a22'), cyl(0.05, 2.4, -9.8, 1.2, 1.2, WOOD, 0, 0, 0, 6), cyl(0.05, 2.4, -9.8, 1.2, 5.2, WOOD, 0, 0, 0, 6));
    a.awning(-12, 2.6, 3.2, 4.4, 1.9, '+x', TEAL);
    for (let i = 0; i < 6; i++) { D(box(0.7, 0.2, 0.55, -10.5, 1.0, 1.6 + i * 0.66, '#9c7a52')); for (let k = 0; k < 4; k++) H({ sph: true, r: 0.11, x: -10.5 + R(-0.25, 0.25), y: 1.17, z: 1.6 + i * 0.66 + R(-0.18, 0.18), color: ['#e8452a', '#f2a03a', '#7aa04a', '#f2d23a', '#c8321e', '#e9e3d0'][i], seg: 6 }); }
    // терраса кафе
    terrace(9.6, 5.4, '#f6efe2'); terrace(9.4, 3.5, '#c25b3a');
    a.awning(12, 3.1, 4.6, 6.2, 1.8, '-x', '#b0392b');
    tree(-9.2, -5.4, 1.05); tree(9.0, -5.6, 1.0); tree(-3.6, 6.5, 0.95);
    bench(-5.6, -6.9); bench(5.6, -6.9); bench(-9.4, 7.3);
    car(-7.2, 2.2, '#e6e0d0', 1);
    lampPost(-11.3, -6.6, 5.6, HP); lampPost(11.3, -6.8, 5.6, -HP);
    // гирлянда над площадью
    for (const [p0, p1] of [[[-12, 5.8, -6], [12, 5.8, 6]], [[-12, 5.8, 6], [12, 5.8, -6]]]) {
      wire(p0, p1, 0.9, 0.022);
      for (let i = 1; i < 12; i++) { const t = i / 12, s = Math.sin(t * Math.PI) * 0.9; H({ sph: true, r: 0.09, x: p0[0] + (p1[0] - p0[0]) * t, y: p0[1] - s - 0.1, z: p0[2] + (p1[2] - p0[2]) * t, color: '#fff3c8', seg: 6 }); }
    }
    manhole(6, -3); manhole(-5, 3); grate(0, 7.6);

    // ===================== кварталы вокруг площади =====================
    // юго-восток площади: гостиница «Чайка» (к средней улице)
    bld(-1, -22, 12, -8, 9.4, MINT, { roof: 2.4, along: 'x' });
    facade('-x', -1, -21.5, -8.5, 2, { balc: 0.35, band: '#c6d4bc', bands: true, pipes: [-8.2] }); facade('-z', -22, -0.5, 11.5, 2, { balc: 0.3, band: '#c6d4bc' }); facade('+z', -8, -0.5, 11.5, 2, { balc: 0.45, band: '#c6d4bc', bands: true, pipes: [-0.8, 11.8] });
    shop('door', '-x', -1, -11); shop('poster', '-x', -1, -14); shop('shutter', '-x', -1, -18.5); shop('win', '-z', -22, 3, { cell: 0 }); shop('door', '-z', -22, 7); shop('graffiti', '-z', -22, 10.2, { w: 2.0 });
    shop('lit', '+z', -8, 2); shop('door', '+z', -8, 5); shop('lit', '+z', -8, 8); a.awning(5, 3.0, -8, 7.2, 1.4, '+z', TEAL);
    walk(-1, -8, 11.6, -6.9, '+z');
    // северо-запад площади: дом с баром
    bld(-18, 8, 1, 22, 11.2, ROSE, { roof: 2.6, along: 'x' });
    facade('-z', 8, -11.5, 0.5, 2, { balc: 0.5, band: '#d9a898', bands: true, pipes: [0.8] }); facade('+x', 1, 8.5, 21.5, 2, { balc: 0.4, band: '#d9a898', bands: true }); facade('+z', 22, -17.5, 0.5, 2, { balc: 0.45, band: '#d9a898', bands: true });
    shop('lit', '-z', 8, -9); shop('door', '-z', 8, -6.5); shop('lit', '-z', 8, -4); shop('poster', '-z', 8, -1.2);
    a.awning(-6.5, 3.0, 8, 7.0, 1.4, '-z', '#b0392b');
    shop('shutter', '+x', 1, 11); shop('graffiti', '+x', 1, 15); shop('door', '+x', 1, 19.5);
    shop('door', '+z', 22, -15); shop('win', '+z', 22, -8, { cell: 3 }); shop('win', '+z', 22, -3, { cell: 3 }); shop('plaque', '+z', 22, -11.6);
    walk(-11.6, 6.9, 1, 8, '-z');
    // северо-восток: морвокзал (голубой, с часовой башенкой)
    bld(6, 8, 12, 10, 12.2, SKY); bld(6, 10, 24, 22, 12.2, SKY, { roof: 3.0, hip: true });
    facade('-x', 6, 8.5, 21.5, 2, { balc: 0.3, band: '#e8eef0', bands: true, fh: 3.6, lit: 0.3, hood: '#eef2f2' }); facade('-z', 8, 6.5, 11.5, 2, { band: '#e8eef0', bands: true, fh: 3.6, hood: '#eef2f2' });
    facade('+z', 22, 6.5, 23.5, 2, { band: '#e8eef0', bands: true, fh: 3.6, lit: 0.3, hood: '#eef2f2' }); facade('+x', 24, 10.5, 21.5, 2, { band: '#e8eef0', bands: true, fh: 3.6, lit: 0.3, hood: '#eef2f2' });
    shop('door', '-x', 6, 15); shop('win', '-x', 6, 11.5, { cell: 1 }); shop('win', '-x', 6, 18.5, { cell: 1 });
    shop('door', '+z', 22, 15); shop('win', '+z', 22, 10.5, { cell: 1 }); shop('win', '+z', 22, 19.5, { cell: 1 }); shop('poster', '+x', 24, 12.5); PD(6, '+x', 24, 17.5, 2.4, 2.0, 4.0);
    // башенка с часами и шпилем
    D(box(2.4, 2.4, 2.4, 15, 16.4, 16, '#e8eef0'), box(2.7, 0.2, 2.7, 15, 17.65, 16, '#cdd6d8'), box(2.6, 0.2, 2.6, 15, 15.25, 16, '#cdd6d8'), { cyl: true, r: 0.05, r2: 1.9, h: 1.8, x: 15, y: 18.65, z: 16, color: '#4a7a8a', seg: 4, ry: Math.PI / 4 }, cyl(0.04, 1.2, 15, 20.1, 16, '#c9a24a', 0, 0, 0, 5));
    for (const [n, c, t] of [['-x', 13.8, 16], ['+x', 16.2, 16], ['+z', 17.2, 15], ['-z', 14.8, 15]]) { const p = at(n, c, t, 0.02); D({ cyl: true, r: 0.8, h: 0.06, x: p[0], y: 16.5, z: p[1], color: '#f4f1ea', seg: 12, rx: isX(n) ? 0 : HP, rz: isX(n) ? HP : 0 }); H({ torus: true, r: 0.82, tube: 0.05, x: p[0], y: 16.5, z: p[1], ry: isX(n) ? HP : 0, color: '#c9a24a', seg: 16 }); D(box(isX(n) ? 0.03 : 0.06, 0.6, isX(n) ? 0.06 : 0.03, p[0] + NN[n][0] * 0.04, 16.7, p[1] + NN[n][1] * 0.04, '#1d1d1d'), box(isX(n) ? 0.03 : 0.4, 0.06, isX(n) ? 0.4 : 0.03, p[0] + NN[n][0] * 0.04 + (isX(n) ? 0 : 0.18), 16.5, p[1] + NN[n][1] * 0.04 + (isX(n) ? 0.18 : 0), '#1d1d1d')); }
    // средняя улица к спецназу: кованые ворота «мид», бочки, катушка
    B(1, 17.6, 1.7, 18.2, 3.0, 'concrete', 0, { tint: '#8a9a90' }); B(5.3, 17.6, 6, 18.2, 3.0, 'concrete', 0, { tint: '#8a9a90' });
    for (const x of [1.35, 5.65]) D(box(0.84, 0.16, 0.74, x, 3.08, 17.9, '#6f8078'), { sph: true, r: 0.18, x, y: 3.32, z: 17.9, color: '#6f8078', seg: 8 });
    D(box(0.06, 2.6, 1.6, 2.05, 1.3, 16.85, '#2f5a4a', 0, 0.3, 0), box(5.0, 0.12, 0.12, 3.5, 3.1, 17.9, '#2f5a4a'));
    for (let k = 0; k < 8; k++) H(box(0.03, 2.4, 0.03, 2.05 + Math.sin(0.3) * 0, 1.3, 16.15 + k * 0.2, '#2f5a4a'));
    hid(1.7, 16.0, 2.4, 17.6, 2.6);
    a.reel(4.6, 12.5); a.barrel(1.6, 9.0, '#8a2d22'); a.barrel(1.6, 9.8, '#2f5f8a'); crate(5.4, 20.6, 0.9);
    wallLamp('+x', 1, 13.5, 3.0); wallLamp('-x', 6, 20.5, 3.0);
    // кафе «Чайка»: вестибюль с площади, зал, выход на причал (короткая A)
    const CW = '#f2d7b0';
    W(12, -2, 12.4, 0.5, 3.6, CW); W(12, 2.5, 12.4, 10, 3.6, CW); W(12, 0.5, 12.4, 2.5, 1.0, CW, 2.6);
    W(12.4, -2, 16, -1.6, 3.6, CW); W(12.4, 9.6, 24, 10, 3.6, CW);
    W(23.6, 2.8, 24, 5.5, 3.6, CW); W(23.6, 7.5, 24, 9.6, 3.6, CW); W(23.6, 5.5, 24, 7.5, 1.0, CW, 2.6);
    W(16, -2, 24, 2.8, 3.6, '#e9dcc4');
    W(12, -2, 24, 10, 3.8, CREAM, 3.6); cornice(12, -2, 24, 10, 7.4, wc(CREAM, 0.94));
    band('-x', 12, -2.2, 10.2, 3.6, '#d9c3a8'); band('+x', 24, 2.6, 10.2, 3.6, '#d9c3a8');
    facade('-x', 12, -1.5, 7.5, 1, { balc: 0.6, step: 3.0, lit: 0.4, y0: 3.7 }); facade('+x', 24, 4.5, 9.5, 1, { lit: 0.4, y0: 3.7 });
    for (const f of FACES) if (f.n === '-x' && f.c === 12) f.skip.push([0.3, 2.7]); for (const f of FACES) if (f.n === '+x' && f.c === 24) f.skip.push([5.3, 7.7]);
    floor(12.4, -1.6, 16, 2.8, 'cotto'); floor(12.4, 2.8, 23.6, 9.6, 'cotto'); floor(12, 0.5, 12.4, 2.5, 'cotto'); floor(23.6, 5.5, 24, 7.5, 'cotto');
    AD(23, '-x', 12, 1.5, 3.2, 1.6, 3.2); shop('lit', '-x', 12, 4.2); shop('lit', '-x', 12, 6.6); PD(6, '-x', 12, -1.0, 2.0, 1.0, 2.0);
    for (const s of [-1, 1]) { wbox('-x', 12, 1.5 + s * 1.08, 1.35, 0.16, 2.7, 0.1, '#d8c4a4'); wbox('+x', 24, 6.5 + s * 1.08, 1.35, 0.16, 2.7, 0.1, '#d8c4a4'); }
    PD(6, '+x', 24, 9.0, 2.0, 1.4, 2.8);
    // зал: стойка, полки с бутылками, столики, диваны, лампы
    hid(16.6, 2.8, 22.6, 3.6, 1.05);
    D(box(6.0, 1.0, 0.8, 19.6, 0.5, 3.2, '#5a3a22'), box(6.1, 0.07, 0.9, 19.6, 1.04, 3.2, '#2a2420'), box(5.6, 0.06, 0.25, 19.6, 1.9, 2.92, '#5a3a22'), box(5.6, 0.06, 0.25, 19.6, 2.4, 2.92, '#5a3a22'));
    for (let i = 0; i < 18; i++) H(cyl(0.04, 0.3, 17.0 + i * 0.3, 2.1 + (i % 2) * 0.5, 2.92, ['#2f6a3a', '#7a3a1a', '#d8c87a', '#3a5a8a'][i % 4], 0, 0, 0, 6));
    for (let i = 0; i < 5; i++) { D(cyl(0.18, 0.05, 17.4 + i * 1.1, 0.75, 4.0, '#c25b3a', 0, 0, 0, 10), cyl(0.03, 0.72, 17.4 + i * 1.1, 0.37, 4.0, IRON, 0, 0, 0, 5)); }
    table(14.4, 8.4, 1.1, 0.9, '#7a5434'); chair(14.4, 7.7, 0); chair(13.6, 8.4, -HP);
    table(18.4, 8.6, 1.1, 0.8, '#7a5434'); chair(18.4, 7.9, 0); chair(19.3, 8.6, HP);
    hid(20.6, 9.0, 23.6, 9.6, 0.9); D(box(3.0, 0.45, 0.6, 22.1, 0.25, 9.3, '#8a2a2a'), box(3.0, 0.6, 0.15, 22.1, 0.75, 9.55, '#8a2a2a'));
    table(22.1, 8.4, 1.2, 0.7, '#7a5434');
    hid(12.4, 6.4, 13.0, 7.6, 1.2); D(box(0.5, 1.2, 1.1, 12.7, 0.6, 7.0, '#3a2a1a'), box(0.48, 0.4, 0.05, 12.7, 1.0, 6.44, '#d8c878'));
    pendant(14.4, 2.9, 8.2, 3.6); pendant(18.4, 2.9, 8.4, 3.6); pendant(19.6, 2.9, 4.6, 3.6); pendant(14.2, 2.9, 0.6, 3.6);
    PD(4, '+z', -1.6, 14.2, 1.8, 1.2, 2.4); PD(4, '-z', 9.6, 16.4, 1.8, 1.0, 2.0); FD(6, '-x', 23.6, 3.8, 1.7, 0.7, 1.4);
    D(box(1.4, 0.012, 2.6, 14.2, 0.03, 0.6, '#8a3a2c'));
    // стены зала: деревянная панель внизу, тёплая краска сверху
    for (const [n, c, t0, t1] of [['+x', 12.4, 2.8, 9.6], ['-z', 9.6, 12.4, 23.6], ['-x', 23.6, 7.5, 9.6]]) { const s = sg(n); if (isX(n)) B(s > 0 ? c : c - 0.03, t0 + 0.02, s > 0 ? c + 0.03 : c, t1 - 0.02, 1.1, 'planks', 0, { solid: false, tint: '#c8a070' }); else B(t0 + 0.02, s > 0 ? c : c - 0.03, t1 - 0.02, s > 0 ? c + 0.03 : c, 1.1, 'planks', 0, { solid: false, tint: '#c8a070' }); wbox(n, c + s * 0.03, (t0 + t1) / 2, 1.12, t1 - t0, 0.06, 0.04, '#5a3a22'); }

    // ===================== восток: холодильник, контора капитана, длинная A =====================
    B(12, -22, 34, -2, 8.2, 'corrug', 0, { tint: '#9ed2c8' });
    D(box(22.3, 0.3, 20.3, 23, 8.35, -12, '#7a8a88'), box(22.5, 0.12, 20.5, 23, 8.56, -12, '#5e6a68'));
    PD(6, '-z', -22, 32.6, 2.2, 1.0, 2.0);
    for (const z of [-19, -13, -7]) { PD(5, '+x', 34, z, 1.6, 3.2, 3.4); D(box(0.8, 0.12, 3.6, 34.4, 3.6, z, '#4a5054'), box(0.06, 0.6, 0.06, 34.75, 3.3, z - 1.7, '#3a3c3e'), box(0.06, 0.6, 0.06, 34.75, 3.3, z + 1.7, '#3a3c3e')); }
    AD(30, '+x', 34, -16, 5.4, 1.2, 2.4); AD(30, '+x', 34, -10, 5.4, 1.2, 2.4); PD(3, '+x', 34, -4.5, 2.1, 2.4, 4.8);
    PD(5, '-z', -22, 16, 1.6, 3.2, 3.4); PD(5, '-z', -22, 22, 1.6, 3.2, 3.4); PD(4, '-z', -22, 26.5, 1.7, 1.4, 2.8); PD(3, '-z', -22, 30.5, 2.1, 2.4, 4.8);
    PD(5, '-x', 12, -5.2, 1.6, 2.6, 3.0); AD(30, '-x', 12, -5.2, 5.2, 1.2, 2.4);
    // холодильные агрегаты на стене и трубы
    for (const z of [-20.5, -15.5]) { D(box(0.7, 1.3, 1.6, 34.35, 6.2, z, '#c8ccce'), cyl(0.5, 0.06, 34.72, 6.2, z, '#55595d', 0, 0, HP, 12)); H(cyl(0.06, 4.5, 34.25, 3.5, z + 0.9, '#9aa0a4', 0, 0, 0, 6)); }
    // контора капитана порта: кирпич, черепица, крыльцо
    B(24, -2, 34, 4, 4.6, 'brick'); roof(24, -2, 34, 4, 4.6, 1.8, 0.5, { along: 'x', gable: '#8a4a36', chim: true });
    PD(6, '+z', 4, 29, 2.3, 1.8, 3.6); shop('door', '+z', 4, 26); win('+z', 4, 32.2, 0.4, 16); win('+x', 34, 1, 0.4, 0); win('+x', 34, -1.2, 0.4, 17);
    wallLamp('+z', 4, 27.3, 2.8);
    // длинная A: контейнеры вразбежку, погрузчик, сети, бочки; ящики 1.0–1.25 м
    cont(37.5, -22, 40, -16, ORANGE_C, BLUE_C, -1); cont(34, -10, 36.5, -4, TEAL_C, null, 1); cont(40.5, -2, 43, 4, RED_C, null, 1);
    forklift(38.6, -8.2, -1); pallet(41.6, -12.6, 2); pallet(41.6, -11.4, 1, '#8fa4ae'); box3(35.2, -27.2, 1.3, 1.2, 1.2); box3(35.15, -27.15, 1.0, 0.95, 1.0, 1.2);
    a.barrel(42.6, -25, '#2f5f8a'); a.barrel(42.0, -25.6, '#8a2d22'); a.barrel(42.7, -26.0, '#2f5f8a');
    hid(34.3, -14.4, 35.5, -12.2, 0.9); D({ sph: true, r: 0.9, x: 34.9, y: 0.35, z: -13.3, sx: 0.7, sy: 0.45, sz: 1.3, color: '#3d5a5e', seg: 9, hs: 6 }); H({ sph: true, r: 0.5, x: 34.8, y: 0.65, z: -12.9, sy: 0.5, color: '#e8b04a', seg: 6 });
    for (let k = 0; k < 6; k++) H({ sph: true, r: 0.12, x: 34.6 + R(0, 0.6), y: 0.72, z: -13.9 + k * 0.25, color: '#e8a030', seg: 5 });
    lampPost(43.0, -20, 6, -HP); lampPost(43.0, -4, 6, -HP);
    // восточная улица от спавна налётчиков
    truck(18.6, -25.2, -1, '#9fc8d0'); crate(30.6, -23.4, 1.1); crate(31.7, -23.2, 0.8); lampPost(26, -27.5, 5.6, 0);
    a.tires(13.2, -23.1, 3);
    manhole(22, -24.5); grate(28, -26.6);

    // ===================== точка A: причал с портальным краном =====================
    // рельсы крана по причалу
    for (const lx of [27.5, 40.5]) { D(box(0.5, 0.014, 60, lx, 0.026, -2, '#4a4642')); for (const s of [-0.12, 0.12]) D(box(0.08, 0.05, 60, lx + s, 0.04, -2, '#6a6a6a')); }
    // портальный кран: решётчатые ноги (коробчатые стойки с раскосами), ригели, тележки колёс, кабина, стрела-ферма над водой
    const leg = (lx, lz) => {
      hid(lx - 0.5, lz - 0.5, lx + 0.5, lz + 0.5, 15);
      hid(lx - 0.6, lz - 1.5, lx + 0.6, lz + 1.5, 1.15);
      // ходовая тележка: рама на рельсе, колёса
      D(box(1.2, 0.9, 3.0, lx, 0.65, lz, CRANE_D), box(1.3, 0.12, 3.1, lx, 1.12, lz, '#2a2a2a'));
      for (const s of [-1.05, -0.35, 0.35, 1.05]) HD(cyl(0.3, 0.9, lx, 0.32, lz + s, '#2a2a2a', 0, 0, HP, 8));
      for (const s of [-1, 1]) H(box(1.22, 0.2, 0.22, lx, 0.9, lz + s * 1.5, '#1d1d1d'));
      // стойка: четыре пояса и раскосы
      for (const [ox, oz] of [[-0.42, -0.42], [0.42, -0.42], [-0.42, 0.42], [0.42, 0.42]]) D(box(0.16, 14.0, 0.16, lx + ox, 8.1, lz + oz, CRANE));
      for (let y = 1.2; y < 14.6; y += 1.7) {
        for (const s of [-1, 1]) { H(stick([lx - 0.42, y, lz + s * 0.42], [lx + 0.42, y + 1.7, lz + s * 0.42], 0.045, 0.045, CRANE, 4), stick([lx + s * 0.42, y, lz - 0.42], [lx + s * 0.42, y + 1.7, lz + 0.42], 0.045, 0.045, CRANE, 4)); }
        (Math.round(y * 10) % 34 === 12 ? D : H)(box(0.9, 0.08, 0.9, lx, y, lz, CRANE_D));
      }
      for (let k = 0; k < 5; k++) H(box(0.9, 0.2, 0.9, lx, 1.4 + k * 0.4, lz, k % 2 ? '#1d1d1d' : YEL));
    };
    for (const [lx, lz] of [[27.5, 8.5], [27.5, 20.5], [40.5, 8.5], [40.5, 20.5]]) leg(lx, lz);
    // ригели портала и связи между ногами
    for (const lz of [8.5, 20.5]) { D(box(14, 1.2, 1.2, 34, 15.2, lz, CRANE), box(14, 0.12, 1.3, 34, 14.58, lz, CRANE_D)); for (let k = 0; k < 6; k++) H(box(0.12, 1.0, 1.22, 28.5 + k * 2.2, 15.2, lz, CRANE_D)); }
    for (const lx of [27.5, 40.5]) { D(box(1.2, 1.2, 13.2, lx, 15.2, 14.5, CRANE)); D(stick([lx, 2.2, 8.5], [lx, 13.8, 20.5], 0.13, 0.13, CRANE_D, 6), stick([lx, 2.2, 20.5], [lx, 13.8, 8.5], 0.13, 0.13, CRANE_D, 6)); }
    // машинный дом, кабина оператора, А-рама
    D(box(5.2, 3.2, 4.2, 30.5, 17.4, 14.5, '#e8e4dc'), box(5.4, 0.2, 4.4, 30.5, 19.1, 14.5, '#b8b4ac'), box(5.0, 0.8, 0.05, 30.5, 17.8, 12.38, '#2a3540'));
    for (const s of [-1, 1]) D(stick([29, 15.8, 14.5 + s * 1.9], [34, 23.5, 14.5], 0.2, 0.16, CRANE, 5), stick([38, 15.8, 14.5 + s * 1.9], [34, 23.5, 14.5], 0.2, 0.16, CRANE, 5));
    D(box(0.6, 0.6, 1.2, 34, 23.5, 14.5, CRANE_D));
    // стрела над водой — ферма: два пояса, раскосы; оттяжки к А-раме
    const BX0 = 25, BX1 = 92, BY = 16.4;
    for (const s of [-1, 1]) { D(box(BX1 - BX0, 0.5, 0.4, (BX0 + BX1) / 2, BY, 14.5 + s * 0.85, CRANE), box(BX1 - BX0, 0.3, 0.3, (BX0 + BX1) / 2, BY + 1.5, 14.5 + s * 0.85, CRANE)); }
    for (let x = BX0 + 1; x < BX1; x += 3) { for (const s of [-1, 1]) H(stick([x, BY + 0.2, 14.5 + s * 0.85], [x + 1.5, BY + 1.45, 14.5 + s * 0.85], 0.06, 0.06, CRANE, 4), stick([x + 1.5, BY + 1.45, 14.5 + s * 0.85], [x + 3, BY + 0.2, 14.5 + s * 0.85], 0.06, 0.06, CRANE, 4)); (x % 6 < 3 ? D : H)(box(0.12, 0.12, 1.8, x, BY + 1.5, 14.5, CRANE_D)); }
    for (const s of [-1, 1]) D(stick([34, 23.5, 14.5 + s * 0.2], [62, BY + 1.6, 14.5 + s * 0.85], 0.05, 0.05, '#222', 4), stick([34, 23.5, 14.5 + s * 0.2], [86, BY + 1.6, 14.5 + s * 0.85], 0.05, 0.05, '#222', 4));
    // кабина оператора под стрелой и тележка с грузом над водой
    D(box(2.2, 2.0, 2.2, 45, BY - 1.5, 14.5, '#e8e4dc'), box(2.25, 0.9, 2.25, 45, BY - 1.2, 14.5, '#2a3a46'), box(3, 0.8, 2.4, 74, BY - 0.7, 14.5, CRANE_D));
    for (const s of [-0.5, 0.5]) D(box(0.05, 8.5, 0.05, 74 + s, BY - 5.2, 14.5, '#222'));
    D(box(6.1, 2.6, 2.5, 74, 7.2, 14.5, BLUE_C), box(6.2, 0.2, 2.6, 74, 8.6, 14.5, '#2a2a2a'));
    a.lamps.push([45, BY - 2.6, 14.5, 1.2], [30.5, 19.4, 12.2, 1.0]);
    // противовес и лестница к машинному дому
    D(box(2.8, 2.4, 3.0, 26.4, 17.2, 14.5, '#6c6f72'));
    for (let k = 0; k < 9; k++) H(box(0.6, 0.04, 0.04, 40.5, 1.8 + k * 1.4, 21.15, '#3a3c3e')); D(box(0.04, 13, 0.04, 40.25, 8.2, 21.15, '#3a3c3e'), box(0.04, 13, 0.04, 40.75, 8.2, 21.15, '#3a3c3e'));
    // контейнеры, погрузчик, ящики: 2.6 м — стенка, 1.0–1.25 м — запрыгнуть, штабели 2 м — с ящика рядом
    cont(30, 11, 36, 13.5, RED_C, TEAL_C, 1); cont(36.5, 15.5, 39, 21.5, BLUE_C, null, -1); cont(29.5, 18.5, 32, 24.5, ORANGE_C, BLUE_C, 1); cont(37.5, 4.5, 43.5, 7, TEAL_C, null, -1);
    forklift(33.6, 7.0, -1);
    box3(25.6, 14.4, 1.3, 1.25, 1.3); box3(25.65, 14.45, 1.0, 1.0, 1.0, 1.25); crate(24.4, 13.6, 0.9);
    crate(36.2, 9.6, 1.1); box3(41.8, 23.2, 1.3, 1.25, 1.3); box3(41.85, 23.2, 1.0, 1.0, 1.0, 1.25); crate(34.6, 23.6, 1.1);
    pallet(25.4, 9.4, 2, '#8fa4ae'); pallet(25.4, 10.6, 1);
    a.reel(42.3, 16.4); a.tires(26.0, 26.6, 2);
    // будка охраны у въезда со стороны спецназа: окна, козырёк, шлагбаум
    W(40.5, 25, 43.5, 27.6, 2.6, '#e8eef0'); D(box(3.5, 0.14, 3.1, 42, 2.68, 26.3, '#c64a32'), box(3.6, 0.06, 3.2, 42, 2.78, 26.3, '#a83a28'));
    PD(1, '-x', 40.5, 26.3, 1.5, 1.1, 1.2, true); PD(1, '-z', 25, 42, 1.5, 1.1, 1.2, true);
    D(box(4.6, 0.12, 0.12, 38.0, 1.0, 26.3, '#e04a3a', 0, 0, 0.15)); for (let k = 0; k < 4; k++) D(box(0.5, 0.125, 0.125, 36.5 + k * 1.1, 1.0 + (k * 1.1 - 1.5) * 0.15, 26.3, '#f4f1ea', 0, 0, 0.15)); D(box(0.3, 1.0, 0.3, 40.3, 0.5, 26.3, '#4a4c4e')); hid(40.15, 26.1, 40.5, 26.5, 1.1);
    a.letter('A', 34.0, 16.6, 4.4);
    lampPost(43.0, 12, 6, -HP);
    a.stain(33.6, 7, 3); a.stain(38.6, -8.2, 3);

    // ===================== спавн спецназа и северные улицы =====================
    floor(-12, 22, 12, 33, 'pave', '#efe2cc');
    bld(-12, 33, 12, 40, 11, CREAM, { roof: 2.8, along: 'x' });
    facade('-z', 33, -11.5, 11.5, 2, { balc: 0.35, band: '#dccab0', bands: true, pipes: [-11.8, 11.8] });
    shop('door', '-z', 33, -2); shop('door', '-z', 33, 2); shop('win', '-z', 33, -6, { cell: 0 }); shop('win', '-z', 33, 6, { cell: 0 }); shop('poster', '-z', 33, -9.5); shop('graffiti', '-z', 33, 9.5, { w: 2.0 });
    // портик морвокзала: колонны с базами и капителями, антаблемент
    D(box(6.2, 0.18, 1.5, 0, 3.15, 32.3, '#cfc8b8'), box(6.4, 0.1, 1.6, 0, 3.28, 32.3, '#e2dccc'));
    for (const x of [-3, 3]) { D(cyl(0.14, 2.7, x, 1.55, 31.7, '#ece4d4', 0, 0, 0, 12), box(0.42, 0.18, 0.42, x, 0.09, 31.7, '#d8d0c0'), box(0.36, 0.14, 0.36, x, 2.98, 31.7, '#d8d0c0')); }
    hid(-3.2, 31.5, -2.8, 31.9, 3); hid(2.8, 31.5, 3.2, 31.9, 3);
    tree(-10.0, 23.8, 1.0); tree(10.0, 23.8, 1.05); bench(-10.2, 27.6, 1); bench(10.2, 27.6, 1);
    car(-6.5, 23.7, '#2b3d5a'); lampPost(-11.3, 30.5, 5.6, HP); lampPost(11.3, 30.5, 5.6, -HP);
    manhole(4, 27); grate(-2, 23.4);
    // улица спецназа к складу (B)
    bld(-50, 27, -12, 40, 9.4, PEACH); bld(-50, 22, -30, 27, 9.4, SALMON, { roof: 2.2, along: 'z' });
    facade('-z', 27, -29.5, -12.5, 2, { balc: 0.4, band: '#dcc0a0', bands: true, pipes: [-12.2] }); facade('+x', -12, 27.5, 32.5, 2, { balc: 0.3, band: '#dcc0a0' }); facade('+x', -30, 22.5, 26.5, 2, { band: '#dcb09a' });
    shop('door', '-z', 27, -27); shop('shutter', '-z', 27, -22.5); shop('graffiti', '-z', 27, -18.5); shop('door', '-z', 27, -14.5); shop('wanted', '+x', -30, 24.5);
    pallet(-14.0, 23.0, 2); box3(-29.0, 23.0, 1.2, 1.15, 1.1); box3(-29.05, 23.05, 0.9, 0.9, 0.9, 1.15); a.barrel(-19.5, 26.2, '#3b5f3a'); lampPost(-19, 26.4, 5.4, Math.PI);
    walk(-29.5, 25.9, -12, 27, '-z');
    // улица спецназа к причалу (A)
    bld(12, 28, 24, 40, 10.2, OCHRE, { roof: 2.4, along: 'z' });
    B(24, 28, 44, 40, 8.6, 'corrug', 0, { tint: '#8fc6c0' }); D(box(20.3, 0.3, 12.3, 34, 8.75, 34, '#6a7a78'));
    facade('-z', 28, 12.5, 23.5, 2, { balc: 0.4, band: '#dcc49a', bands: true, pipes: [12.2] }); facade('-x', 12, 28.5, 32.5, 2, { band: '#dcc49a' });
    shop('door', '-z', 28, 15); shop('lit', '-z', 28, 19); shop('poster', '-z', 28, 22.6);
    PD(5, '-z', 28, 28, 1.6, 3.2, 3.4); PD(5, '-z', 28, 34, 1.6, 3.2, 3.4); PD(5, '-z', 28, 40, 1.6, 3.2, 3.4); AD(31, '-z', 28, 31, 5.4, 1.2, 2.4, true); AD(30, '-z', 28, 37, 5.4, 1.2, 2.4);
    PD(6, '-z', 28, 25.6, 2.4, 1.6, 3.2);
    car(17.8, 25.2, '#c25b3a'); crate(22.6, 23.0, 1.0); lampPost(18, 22.6, 5.4, 0);
    walk(12.5, 26.9, 23.6, 28, '-z');

    // ===================== провода между домами =====================
    wire([-18, 9.6, -12], [-6, 9.4, -12], 0.5); wire([-6, 8.8, -18], [-1, 8.6, -18], 0.3); wire([1, 9.8, 14], [6, 9.6, 14], 0.35); wire([12, 8.2, -25], [12, 8.8, -40], 0.1);
    wire([-38, 10.6, -22], [-38, 10.4, -28], 0.5); wire([-30, 8.4, 22], [-30, 8.8, 27], 0.3);

    // ===================== за пределами карты =====================
    // сухогруз у причала: корпус с наклонным форштевнем и транцем, ватерлиния, надстройка с мостиком, контейнеры на палубе
    D({ shape: true, pts: [[31, -1.6], [34, 7.5], [-33, 7.5], [-34, 9.5], [-37.5, 9.5], [-31, -1.6]], d: 15, x: 92, y: -1.3, z: -6, color: '#6b1f1a', cs: 1 });
    D({ shape: true, pts: [[31.95, 1.0], [31.05, -1.25], [-31.1, -1.25], [-32.55, 1.0]], d: 15.12, x: 92, y: -1.3, z: -6, color: '#1d1d1d', cs: 1 });
    D(box(15.1, 0.3, 66, 92, 6.35, -8, '#8a2a22'), box(14, 9, 9, 92, 10.6, -33, '#e8e4dc'), box(14.2, 1.2, 9.2, 92, 12.8, -33, '#2a3540'), box(16, 0.4, 3.6, 92, 15.3, -30.5, '#e8e4dc'), box(3, 6, 3, 92, 18.5, -35, '#c8c4bc'), box(3.2, 1.2, 3.2, 92, 21, -35, '#a33a2a'));
    for (let k = 0; k < 3; k++) D(box(14.1, 0.9, 9.1, 92, 7.6 + k * 2.9, -33, '#d8d4cc'), box(14.15, 0.5, 9.15, 92, 8.8 + k * 2.9, -33, '#33404c'));
    const cc = [BLUE_C, RED_C, TEAL_C, ORANGE_C, GREY_C, GREEN_C];
    for (let b = 0; b < 6; b++) for (let c = 0; c < 5; c++) { const n = 1 + Math.floor(R(0, 2.99)); for (let r = 0; r < n; r++) (r ? HD : D)(box(2.4, 2.55, 6.0, 87 + c * 2.5, 7.8 + r * 2.6, -22 + b * 6.4, cc[Math.floor(R(0, 5.99))])); }
    for (const z of [-16, 4]) { D(cyl(0.3, 10, 85.5, 11.5, z, '#d8c8a8', 0, 0, 0, 8), box(0.3, 0.3, 9, 87.5, 15, z, '#d8c8a8', 0, 0, 0.5)); }
    // портовые краны на том берегу
    for (const z of [-60, -38]) H(box(1.2, 30, 1.2, 120, 15, z - 6, '#c64a32'), box(1.2, 30, 1.2, 120, 15, z + 6, '#c64a32'), box(1.2, 30, 1.2, 132, 15, z - 6, '#c64a32'), box(1.2, 30, 1.2, 132, 15, z + 6, '#c64a32'),
      box(60, 2, 2, 110, 31, z, '#c64a32'), box(5, 4, 5, 126, 34, z, '#e8e4dc'), box(14, 1.2, 14, 126, 29.5, z, '#c64a32'));
    // маяк на скале
    H({ sph: true, r: 14, x: 150, y: -6, z: -95, color: '#5b5048', seg: 10, sy: 0.6 });
    for (let i = 0; i < 6; i++) H(cyl(2.6 - i * 0.18, 4, 150, 4 + i * 4, -95, i % 2 ? '#c8352a' : '#eeeae2', 0, 0, 0, 12, 2.6 - (i + 1) * 0.18));
    H(cyl(1.6, 2.4, 150, 29, -95, '#ffe7a0', 0, 0, 0, 10), { cyl: true, r: 0.2, r2: 2.2, h: 2.2, x: 150, y: 31.3, z: -95, color: '#2a2a2a', seg: 10 });
    a.lamps.push([150, 29, -95, 9]);
    // мол с маленьким маяком
    H(box(70, 2, 5, 80, -0.3, 58, '#8a8378'), cyl(1.2, 7, 112, 4, 58, '#e8e4dc', 0, 0, 0, 10), cyl(1.4, 1.2, 112, 8, 58, '#3fa04a', 0, 0, 0, 10));
    // крыши соседних кварталов: силуэт за домами по периметру
    for (let i = 0; i < 14; i++) {
      const side = i % 3, t = Math.floor(i / 3) / 4.6 + R(0, 0.12), w = R(7, 11), d = R(7, 10), hh = R(9, 15);
      const x = side === 0 ? -55 - R(0, 6) : -40 + t * 76, z = side === 0 ? -30 + t * 64 : side === 1 ? 45 + R(0, 5) : -46 - R(0, 5);
      const tint = [PEACH, CREAM, SALMON, OCHRE, ROSE][i % 5];
      H(box(w, hh, d, x, hh / 2, z, wc(tint, 0.9)), { shape: true, pts: [[-d / 2 - 0.4, 0], [0, 2.2], [d / 2 + 0.4, 0]], d: w + 0.8, x, y: hh, z, color: '#a8553a', cs: 1 });
      for (let k = 0; k < 3; k++) H(box(1.0, 1.6, 0.05, x - w / 3 + k * w / 3, hh * 0.6, z + (side === 2 ? d / 2 + 0.03 : -d / 2 - 0.03), R(0, 1) < 0.3 ? '#ffc46a' : '#2a3540'));
    }
    // мелочь на крышах: баки, антенны, трубы, кондиционеры
    for (const [x, z, h] of [[-28, -14, 13.8], [-22, -10, 13.8], [-32, 30, 9.4], [30, 34, 8.6], [-46, -10, 13.2], [20, -12, 8.2], [-46, -26, 11.6], [-35, -34, 10.4], [28, -34, 7.4]]) {
      D(cyl(0.6, 1.4, x, h + 1.05, z, '#b8b2a6', 0, 0, 0, 10), box(0.7, 1.2, 0.7, x - 1.6, h + 0.6, z - 1.0, '#9a6a52'));
      H(box(0.08, 2.6, 0.08, x + 1.4, h + 1.3, z + 0.6, '#3a3c3e'), box(1.2, 0.05, 0.05, x + 1.4, h + 2.4, z + 0.6, '#3a3c3e'), box(0.9, 0.5, 0.6, x + 0.4, h + 0.25, z - 1.8, '#dedcd6'));
    }
    // пятна, лужи у стен, световые круги под фонарями
    a.stain(-30.5, -1, 3); a.stain(-23, -0.4, 4); a.stain(18.6, -26.2, 3.5); a.stain(3.5, 14, 2.2); a.stain(-40, -20, 2.5);
    for (const l of a.lamps) if (!l[3]) a.pool(l[0], l[2], 6);
    a.gulls = 5;
    plinths();
    hbTrimLite(a);
  }
  // 2.0.1: «Порт» на низком/среднем — обратно к весу 12.0. Мелочь, которую с улицы почти не видно, остаётся только
  // на высоком качестве (hiOnly): плоские круги и доски на земле, обода бочек, подоконники/пороги/косяки дверей,
  // кондиционеры и поручни верхних этажей, мелочь на крышах; шины — тор только на высоком, на низком — цилиндр (a.lo).
  function hbTrimLite(a) {
    const flat = (p) => (p.cyl && p.h <= 0.04 && Math.max(p.r, p.r2 || 0) * Math.max(p.sx || 1, p.sz || 1) < 1.6) || (!p.cyl && !p.sph && !p.torus && !p.shape && p.h <= 0.02 && Math.max(p.w, p.d) < 2.5);
    const sz = (p) => p.cyl ? Math.max(2 * Math.max(p.r, p.r2 || 0) * Math.max(p.sx || 1, p.sz || 1), p.h * (p.sy || 1)) : p.sph ? 2 * p.r * Math.max(p.sx || 1, p.sy || 1, p.sz || 1) : p.torus ? 2 * (p.r + p.tube) : p.shape ? 9 : Math.max(p.w, p.h, p.d);
    for (const p of a.decor) {
      if (p.hiOnly) continue;
      const y = p.y || 0, c = p.color;
      let cut = flat(p);
      if (!cut && p.cyl && c === '#222' && p.h <= 0.06 && p.r > 0.29 && p.r < 0.33) cut = true; // обода бочек
      if (!cut && !p.cyl && !p.sph && !p.torus && !p.shape) {
        if (c === '#d8ccb2' && p.h > 2.4 && Math.min(p.w, p.d) < 0.12) cut = true; // косяки дверей
        else if (c === '#9e968a' && p.h <= 0.13 && y < 0.1) cut = true; // пороги
        else if (c === '#e2dacb' && p.h <= 0.08) cut = true; // подоконники
        else if (c === '#ddd3c2' && p.h <= 0.13 && y < 3) cut = true; // сандрики первого этажа
        else if (c === '#dedcd6' && y > 6) cut = true; // кондиционеры верхних этажей
        else if ((c === '#26282b' || c === '#3a3c3e') && y > 4 && Math.min(p.w, p.d) < 0.1 && p.h < 0.1 && Math.max(p.w, p.d) < 2.5) cut = true; // поручни балконов
        else if (c === '#dedcd6' && y > 4) cut = true; // кондиционеры
      }
      if (!cut && ((y > 7 && sz(p) < 1.5) || (y > 15 && sz(p) < 2.2) || (y > 4.2 && sz(p) < 0.5) || (y > 2.6 && sz(p) < 0.32))) cut = true; // мелочь на крышах, на кране и над головой
      if (!cut && (p.x > 47 || p.x < -47 || p.z > 37 || p.z < -37) && sz(p) < 3.2) cut = true; // мелочь дальнего фона (корпус корабля и краны остаются)
      if (!cut && p.cyl && (c === '#1a1a1a' || c === '#1c1c1c') && p.r >= 0.25 && p.r <= 0.55 && p.h <= 0.32 && (p.seg || 10) > 5) { cut = true; a.lo.push(Object.assign({}, p, { seg: 5 })); } // колёса — на низком 5 граней
      if (!cut && p.cyl && p.h <= 0.012) cut = true; // пятна на земле
      if (!cut && p.torus && c === '#1a1a1a' && p.r < 0.26) { cut = true; a.lo.push({ cyl: true, r: p.r + p.tube * 0.9, h: p.tube * 2, x: p.x, y, z: p.z, rx: p.rx, ry: p.ry, rz: p.rz, color: c, seg: 8 }); }
      if (!cut && p.torus && p.r > 0.28 && p.r < 0.36 && c === '#1b1b1b') { cut = true; a.lo.push({ cyl: true, r: p.r + p.tube * 0.9, h: p.tube * 2, x: p.x, y, z: p.z, color: c, seg: 8 }); } // шины
      if (cut) p.hiOnly = true;
    }
  }

  // ===================== «Сакура» =====================
  // плотный старый квартал весной. Три линии: длинная A (западная улица → двор храма), центр (переулок → мост через канал →
  // площадь; оттуда сквозь апартаменты к A и сквозь идзакаю к B), длинная B (восточная улица → крытый рынок).
  // Налётчики — у станции на юге, спецназ — у бани на севере. Всё проходимое — на уровне земли (ступенек нет).
  function layoutSakura(a) {
    const { B } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    // HD — деталь декора только для высокого качества (в упрощённом декоре низкого/среднего её нет)
    const HD = (...p) => { for (const q of p) { q.hiOnly = true; a.decor.push(q); } };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 5150; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    const pick = (arr) => arr[Math.floor(R(0, arr.length - 0.001))];
    // свои материалы «Сакуры» 2.0 (регистрируем здесь, общую таблицу не трогаем): решётка коси первого этажа
    if (!MAT_FACTORY.skMachiya) MAT_FACTORY.skMachiya = () => lam('skMachiya', null, 1.0);
    // палитра: тёмное дерево, бэнгара, белая и охристая штукатурка, серебристая черепица, киноварь
    const TIM = '#3b281b', TIM_L = '#5e432e', TIM_D = '#24180f', BEN = '#6a3222', VER = '#c63b22', STONE = '#8f8b83', STONE_D = '#6f6c66', IRON = '#2b2d30';
    const WHITE = '#f6f1e8', CREAM = '#f1e4cc', OCHRE = '#e8cfa2', ASH = '#e2ddd3', SAND = '#dcc8a6', TILE = '#ffffff', TILE2 = '#e8edf3', TILE3 = '#f3ebe2', COPPER = '#8fbcae';
    const SOF = '#3a2a1e', RIDGE = '#454b53', PINKS = ['#fff4f7', '#ffe4ec', '#fbd3e0', '#ffffff', '#f7c6d6'];
    const NN = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] };
    const isX = (n) => NN[n][0] !== 0, sg = (n) => NN[n][0] + NN[n][1];
    // точка на плоскости стены c (нормаль n): t — вдоль стены, o — вынос наружу
    const at = (n, c, t, o) => { const N = NN[n]; return N[0] ? [c + N[0] * (o || 0), t] : [t, c + N[1] * (o || 0)]; };
    // брус/доска на фасаде: центр вдоль стены t, высота y, длина len, сечение hh × dep (dep — вынос из стены)
    const wb = (n, c, t, y, len, hh, dep, col) => { const X = isX(n), p = at(n, c, t, dep / 2 - 0.01); return box(X ? dep : len, hh, X ? len : dep, p[0], y, p[1], col); };
    const wbox = (...q) => D(wb(...q)), wboxH = (...q) => HD(wb(...q));
    const W = (x0, z0, x1, z1, h, tint, y0, ch) => B(x0, z0, x1, z1, h, 'plaster', y0, { tint: tint || WHITE, ch: ch ? 1 : 0 });
    const floor = (x0, z0, x1, z1, mat, tint) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false, tint });
    const hid = (x0, z0, x1, z1, h, y0) => B(x0, z0, x1, z1, h, 'none', y0 || 0, { hidden: true });
    const box3 = (x, z, w, h, d, y0) => B(x - w / 2, z - d / 2, x + w / 2, z + d / 2, h, 'crate', y0 || 0, { uv: 'face' });
    // наклейки из атласа skAtlas: прямоугольники в пикселях 1024×1024
    const SA = {
      mushiko: [0, 0, 256, 128], shoji: [256, 0, 384, 128], shojiLit: [384, 0, 512, 128], koshiWin: [512, 0, 768, 128], aptWin: [768, 0, 896, 128], aptWinLit: [896, 0, 1024, 128],
      door: [0, 128, 128, 384], doorWood: [128, 128, 256, 384], aptDoor: [256, 128, 384, 384], vend: [384, 128, 512, 384],
      vsTea: [512, 128, 576, 384], vsRamen: [576, 128, 640, 384], vsSake: [640, 128, 704, 384], vsInn: [704, 128, 768, 384],
      norNavy: [768, 128, 896, 256], norRed: [896, 128, 1024, 256], norYu: [768, 256, 896, 384], norSoba: [896, 256, 1024, 384],
      hsSoba: [0, 384, 256, 448], hsIzakaya: [0, 448, 256, 512], hsTabako: [256, 384, 512, 448], hsSento: [256, 448, 512, 512], hsStation: [512, 384, 768, 448], hsStreet: [512, 448, 768, 512],
      grime: [768, 384, 1024, 512], fusuma: [0, 512, 256, 768], mailbox: [256, 512, 384, 768], ema: [384, 512, 512, 768], posters: [512, 512, 768, 768], lantern: [768, 512, 896, 768], mon: [896, 512, 1024, 640], streaks: [896, 640, 1024, 768],
      kuraWin: [0, 768, 128, 896], board: [128, 768, 384, 896], meter: [384, 768, 512, 896], plate: [512, 768, 640, 896], siteA: [640, 768, 768, 896], siteB: [768, 768, 896, 896]
    };
    const suv = (k) => { const r = SA[k], e = 0.0015; return [r[0] / 1024 + e, 1 - r[3] / 1024 + e, r[2] / 1024 - e, 1 - r[1] / 1024 - e]; };
    // наклейка на стену c с нормалью n; t — вдоль стены
    const DA = (k, n, c, t, y, w, h, off) => { const p = at(n, c, t, off || 0.004); a.decals.push({ x: p[0], y, z: p[1], w, h, n, atlas: 'skAtlas', lit: false, uv: suv(k) }); };
    const DX = (k, x, y, z, w, h, n) => a.decals.push({ x, y, z, w, h, n, atlas: 'skAtlas', lit: false, uv: suv(k) });

    // ---------- крыши: черепица (общий меш крыш) + толщина, подшивка, конёк с они-гавара, черепичная кромка свеса ----------
    // gable: «галочка» с толщиной th вдоль конька (её низ — тёмная подшивка свеса, торцы — ветровые доски);
    // hip: доски свеса по периметру и плоская подшивка; o.gable — цвет фронтона (треугольник стены с балкой и стойкой)
    const roof = (x0, z0, x1, z1, y, h, ov, o) => {
      o = o || {};
      const r = { X0: x0, X1: x1, Z0: z0, Z1: z1, y, h, ov, hip: !!o.hip, col: o.col || TILE, alongX: o.along ? o.along === 'x' : (x1 - x0) >= (z1 - z0) };
      a.roofs.push(r);
      const g = roofFrame(r), ax = r.alongX, P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa];
      const sl = h / g.hw0, ck = Math.sqrt(1 + sl * sl), th = o.th || 0.2, tv = th * ck, e = 0.025, len = g.A1 - g.A0;
      const rc = o.ridgeCol || RIDGE, sof = o.sof || SOF;
      const along = (l, hh, dd, aa, c, yy, col, list) => { const p = P(aa, c, yy); (list || a.decor).push(box(ax ? l : dd, hh, ax ? dd : l, p[0], p[1], p[2], col)); };
      // черепичная кромка свеса (валик концевых плиток)
      const roll = (c, a0, a1) => { const p = P((a0 + a1) / 2, c, g.ey - e - 0.035); D({ cyl: true, r: 0.075, h: a1 - a0, x: p[0], y: p[1], z: p[2], rx: ax ? 0 : HP, rz: ax ? HP : 0, color: rc, seg: 6, open: true }); };
      if (!r.hip) {
        // подшивка только под свесом (от кромки до стены: меньше перерисовки пикселей под черепицей) и ветровые доски на фронтонах
        const yw = y - e, xw = g.hw0;
        for (const sd of [-1, 1]) D({ shape: true, pts: [[sd * g.hw, g.ey - e], [sd * xw, yw], [sd * xw, yw - tv], [sd * g.hw, g.ey - e - tv]], d: len, x: ax ? g.mid : g.cc, y: 0, z: ax ? g.cc : g.mid, ry: ax ? 0 : HP, color: sof, cs: 1 });
        for (const aa of [g.A0 + 0.07, g.A1 - 0.07]) { const p = P(aa, g.cc, 0); D({ shape: true, pts: [[-g.hw, g.ey - e], [0, g.top - e], [g.hw, g.ey - e], [g.hw, g.ey - e - tv], [0, g.top - e - tv], [-g.hw, g.ey - e - tv]], d: 0.14, x: p[0], y: 0, z: p[2], ry: ax ? 0 : HP, color: sof, cs: 1 }); }
        roll(g.C0, g.A0, g.A1); roll(g.C1, g.A0, g.A1);
        // фронтоны: штукатурка, балка-затяжка и стойка; торцевые плитки по скату
        if (o.gable !== false) for (const [aw, s] of [[g.a0w, 1], [g.a1w, -1]]) {
          const p = P(aw + s * 0.07, g.cc, y);
          D({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: o.gable || WHITE, ry: ax ? 0 : HP, cs: 1 });
          const q = P(aw - s * 0.03, g.cc, y + 0.08); HD(box(ax ? 0.16 : g.hw0 * 2 + 0.1, 0.2, ax ? g.hw0 * 2 + 0.1 : 0.16, q[0], q[1], q[2], TIM));
          if (h > 1.1) { const k = P(aw - s * 0.03, g.cc, y + h * 0.42); HD(box(ax ? 0.14 : 0.16, h * 0.7, ax ? 0.16 : 0.14, k[0], k[1], k[2], TIM)); }
        }
        // конёк: гребень из плиток, круглая верхняя плитка, они-гавара на концах
        along(len + 0.1, 0.3, 0.34, g.mid, g.cc, g.top + 0.08, rc);
        { const p = P(g.mid, g.cc, g.top + 0.27); D({ cyl: true, r: 0.12, h: len + 0.2, x: p[0], y: p[1], z: p[2], rx: ax ? 0 : HP, rz: ax ? HP : 0, color: rc, seg: 6 }); }
        for (const aa of [g.A0 + 0.06, g.A1 - 0.06]) { const p = P(aa, g.cc, g.top + 0.18); D(box(ax ? 0.16 : 0.62, 0.64, ax ? 0.62 : 0.16, p[0], p[1], p[2], '#4c535c')); }
      } else {
        // доски свеса по периметру и подшивка
        along(len, tv, 0.08, g.mid, g.C0 + 0.04, g.ey - e - tv / 2, sof); along(len, tv, 0.08, g.mid, g.C1 - 0.04, g.ey - e - tv / 2, sof);
        for (const aa of [g.A0 + 0.04, g.A1 - 0.04]) { const p = P(aa, g.cc, g.ey - e - tv / 2); D(box(ax ? 0.08 : g.C1 - g.C0, tv, ax ? g.C1 - g.C0 : 0.08, p[0], p[1], p[2], sof)); }
        // подшивка свеса — кольцо из четырёх полос шириной в свес (а не плита на всю крышу)
        { const wv = ov + 0.1, yy = g.ey - e - tv + 0.02;
          for (const c of [g.C0 + wv / 2, g.C1 - wv / 2]) { const p = P(g.mid, c, yy); D(box(ax ? len - 0.1 : wv, 0.04, ax ? wv : len - 0.1, p[0], p[1], p[2], sof)); }
          for (const aa of [g.A0 + wv / 2, g.A1 - wv / 2]) { const p = P(aa, g.cc, yy); D(box(ax ? wv : g.C1 - g.C0 - 2 * wv, 0.04, ax ? g.C1 - g.C0 - 2 * wv : wv, p[0], p[1], p[2], sof)); } }
        roll(g.C0, g.A0, g.A1); roll(g.C1, g.A0, g.A1);
        for (const aa of [g.A0, g.A1]) { const p = P(aa, (g.C0 + g.C1) / 2, g.ey - e - 0.035); D({ cyl: true, r: 0.075, h: g.C1 - g.C0, x: p[0], y: p[1], z: p[2], rx: ax ? HP : 0, rz: ax ? 0 : HP, color: rc, seg: 6, open: true }); }
        // рёбра вальм и конёк
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) D(stick(P(aa, c, g.ey + 0.02), P(ra, g.cc, g.top + 0.05), 0.12, 0.1, rc, 5));
        if (g.ra1 - g.ra0 > 0.05) along(g.ra1 - g.ra0 + 0.3, 0.28, 0.3, (g.ra0 + g.ra1) / 2, g.cc, g.top + 0.06, rc);
        if (o.finial) {
          const p = P(g.mid, g.cc, g.top);
          D(cyl(0.1, o.finial, p[0], g.top + o.finial / 2, p[2], '#6b5a3a', 0, 0, 0, 8));
          if (o.finial > 3) for (let i = 0; i < 7; i++) D(cyl(0.46 - i * 0.03, 0.09, p[0], g.top + o.finial * (0.25 + i * 0.08), p[2], '#8a7448', 0, 0, 0, 8));
          D({ sph: true, r: o.finial > 3 ? 0.3 : 0.14, x: p[0], y: g.top + o.finial, z: p[2], color: '#c9a54a', seg: 8 });
        }
      }
      return g;
    };
    // навес хисаси над первым этажом вдоль фасада n (стена c, от t0 до t1): узкая двускатная полоса черепицы, внутренняя половина — в стене
    const hisashi = (n, c, t0, t1, y, dep, col) => {
      const X = isX(n), s = sg(n), hw = 0.15, sl = 0.5, e = 0.025, th = 0.16, tv = th * Math.sqrt(1 + sl * sl);
      const a0 = t0 + dep, a1 = t1 - dep, cin = c - s * 2 * hw;
      if (a1 - a0 < 0.1) return;
      const r = X ? { X0: Math.min(c, cin), X1: Math.max(c, cin), Z0: a0, Z1: a1 } : { X0: a0, X1: a1, Z0: Math.min(c, cin), Z1: Math.max(c, cin) };
      Object.assign(r, { y, h: hw * sl, ov: dep, hip: false, col: col || TILE, alongX: !X });
      a.roofs.push(r);
      const ey = y - dep * sl;
      const ry = n === '-z' ? 0 : n === '+z' ? Math.PI : n === '-x' ? HP : -HP, p = at(n, c, (t0 + t1) / 2);
      D({ shape: true, pts: [[-0.05, y + 0.05 * sl - e], [dep, ey - e], [dep, ey - e - tv], [-0.05, y + 0.05 * sl - e - tv]], d: t1 - t0, x: p[0], y: 0, z: p[1], ry, color: SOF, cs: 1 });
      const q = at(n, c, (t0 + t1) / 2, dep - 0.02);
      HD({ cyl: true, r: 0.07, h: t1 - t0, x: q[0], y: ey - e - 0.03, z: q[1], rx: X ? HP : 0, rz: X ? 0 : HP, color: RIDGE, seg: 6, open: true });
      // кронштейны (только высокое)
      const m = Math.max(2, Math.round((t1 - t0) / 1.8));
      for (let i = 0; i <= m; i++) { const t = t0 + 0.2 + (t1 - t0 - 0.4) * i / m, b = at(n, c, t, dep * 0.4); HD(box(X ? dep * 0.8 : 0.09, 0.1, X ? 0.09 : dep * 0.8, b[0], y - dep * 0.4 * sl - 0.2, b[1], TIM)); }
    };
    // ---------- дома ----------
    // машия: каменный цоколь, первый этаж — решётка коси (или штукатурка), второй — штукатурка с тёмным каркасом и окнами мусико-мадо,
    // навес хисаси над первым этажом, двускатная крыша с толщиной; o.f — фасады с деталями
    const mach = (x0, z0, x1, z1, o) => {
      o = o || {};
      const h = o.h || 5.8, one = !!o.one, lo = one ? h : (o.lo || 2.9), tint = o.tint || WHITE, col = o.col || pick([TILE, TILE2, TILE3, TILE]);
      B(x0, z0, x1, z1, 0.4, 'stonewall');
      if (one) W(x0, z0, x1, z1, h - 0.4, tint, 0.4);
      else {
        if (o.plain) { W(x0, z0, x1, z1, lo - 0.4, tint, 0.4); W(x0, z0, x1, z1, h - lo, tint, lo); } else B(x0, z0, x1, z1, h - 0.4, 'skMachiya', 0.4, { tint });
      }
      const fs = o.f || ['+x', '-x', '+z', '-z'], corners = new Set();
      for (const n of fs) {
        const X = isX(n), t0 = X ? z0 : x0, t1 = X ? z1 : x1, c = n === '+z' ? z1 : n === '-z' ? z0 : n === '+x' ? x1 : x0, len = t1 - t0, mid = (t0 + t1) / 2;
        const gh = one ? Math.min(h, 2.9) : lo;
        for (const t of [t0, t1]) corners.add(X ? c + ',' + t : t + ',' + c);
        // o.pf — фасады, где первый этаж оштукатурен (поверх решётки — тонкая штукатурка), с дверями и окнами
        if (o.pf && o.pf.includes(n) && !one && !o.plain) {
          const q0 = at(n, c, t0 + 0.12, 0), q1 = at(n, c, t1 - 0.12, 0.04);
          B(Math.min(q0[0], q1[0]), Math.min(q0[1], q1[1]), Math.max(q0[0], q1[0]), Math.max(q0[1], q1[1]), lo - 0.4, 'plaster', 0.4, { solid: false, tint: o.pfTint || CREAM });
          const k = Math.max(1, Math.round(len / 3.4));
          for (let i = 0; i < k; i++) { const t = t0 + len * (i + 0.5) / k, kind = (i + (o.pfPh || 0)) % 3; if (kind === 0) DA('doorWood', n, c, t, 1.2, 1.4, 2.2, 0.05); else if (kind === 1) { DA('koshiWin', n, c, t, 1.55, 2.0, 1.0, 0.05); wboxH(n, c, t, 1.02, 2.0, 0.07, 0.14, TIM_L); } else DA('shoji', n, c, t, 1.6, 1.2, 1.2, 0.05); }
          const k2 = Math.max(1, Math.round(len / 3.6)); for (let i = 1; i < k2; i++) wbox(n, c, t0 + len * i / k2, (lo + 0.4) / 2, 0.18, lo - 0.4, 0.1, TIM);
        }
        // балка над первым этажом; на оштукатуренном первом этаже — промежуточные столбы
        wbox(n, c, mid, gh - 0.11, len + 0.04, 0.22, 0.11, TIM);
        if (o.plain || one) { const k = Math.max(1, Math.round(len / 3.6)); for (let i = 1; i < k; i++) wbox(n, c, t0 + len * i / k, (gh + 0.4) / 2, 0.18, gh - 0.4, 0.07, TIM); }
        if (!one) {
          // второй этаж: балка под карнизом, окна мусико-мадо с подоконником
          wbox(n, c, mid, h - 0.1, len + 0.04, 0.18, 0.07, TIM);
          if (!o.noWin) {
            const wn = Math.max(1, Math.round(len / 4.4));
            for (let i = 0; i < wn; i++) { const t = t0 + len * (i + 0.5) / wn, wy = lo + (h - lo) * 0.56; DA(o.win || 'mushiko', n, c, t, wy, 2.0, 1.0); wboxH(n, c, t, wy - 0.52, 2.0, 0.07, 0.12, TIM_L); }
          }
          if (!o.noHi) hisashi(n, c, t0, t1, lo + 0.14, 0.9, col);
        } else if (!o.noWin && len > 3) DA('shoji', n, c, mid + len * 0.25, 1.9, 1.1, 1.1);
        // водосток из камня вдоль фасада
        if (!o.noGutter) { const g0 = at(n, c, t0, 0.02), g1 = at(n, c, t1, 0.5); B(Math.min(g0[0], g1[0]), Math.min(g0[1], g1[1]), Math.max(g0[0], g1[0]), Math.max(g0[1], g1[1]), 0.025, 'stonewall', 0, { solid: false, tint: '#a8a49a' }); }
      }
      // угловые столбы на всю высоту
      for (const k of corners) { const [cx, cz] = k.split(',').map(Number); D(box(0.24, h - 0.4, 0.24, cx + (cx > (x0 + x1) / 2 ? 0.03 : -0.03), (h + 0.4) / 2, cz + (cz > (z0 + z1) / 2 ? 0.03 : -0.03), TIM)); }
      return roof(x0, z0, x1, z1, h, o.rise || Math.min(2.2, Math.min(x1 - x0, z1 - z0) * 0.3), o.ov == null ? 0.75 : o.ov, { col, along: o.along, hip: !!o.hip, gable: o.gable || tint });
    };
    // фасад лавки: раздвижная дверь, норэн, вертикальная вывеска, фонарь (стена — плоскость x для ±x, z для ±z)
    const shop = (n, x, z, o) => {
      o = o || {};
      const X = isX(n), c = X ? x : z, t = X ? z : x, s = sg(n);
      DA(o.door || 'door', n, c, t, 1.2, 1.6, 2.2);
      if (o.noren !== false) {
        DA(o.noren || pick(['norNavy', 'norRed', 'norSoba', 'norNavy']), n, c, t, 1.92, 1.5, 0.82, 0.12);
        wbox(n, c, t, 2.36, 1.7, 0.05, 0.16, TIM_D);
      }
      if (o.sign !== false) { const sx = t + (o.signSide || 1) * 1.25; wbox(n, c, sx, 1.75, 0.56, 1.92, 0.05, TIM_D); DA(o.sign || pick(['vsTea', 'vsSake', 'vsInn', 'vsTea']), n, c, sx, 1.75, 0.46, 1.8, 0.055); }
      if (o.lan !== false) for (const dt of (o.red ? [-1.15, 1.15] : [-1.15])) { const p = at(n, c, t + dt, 0.5); lan(p[0], 2.15, p[1], o.lanCol || (o.red ? '#d63a26' : '#f3e2b8'), 2.62); }
      if (o.step !== false) { const p = at(n, c, t, 0.3); HD(box(X ? 0.5 : 1.7, 0.1, X ? 1.7 : 0.5, p[0], 0.05, p[1], '#a29d92')); }
    };
    // бумажный фонарь тётин (светится): бочонок, тёмные кольца, шнур
    const lan = (x, y, z, col, top) => {
      col = col || '#d63a26';
      D(cyl(0.22, 0.48, x, y, z, col, 0, 0, 0, 10)); HD(cyl(0.15, 0.05, x, y + 0.26, z, TIM_D, 0, 0, 0, 8), cyl(0.15, 0.05, x, y - 0.26, z, TIM_D, 0, 0, 0, 8), cyl(0.225, 0.03, x, y + 0.1, z, col, 0, 0, 0, 10), cyl(0.225, 0.03, x, y - 0.1, z, col, 0, 0, 0, 10));
      if (top && top > y + 0.35) D(box(0.035, top - y - 0.29, 0.035, x, (top + y + 0.29) / 2, z, '#1a1a1a'));
      a.lamps.push([x, y, z, 0.6]);
    };
    // сакура: короткий изогнутый ствол, ветви, крона из многих небольших облаков цветов (на низком/среднем — дешёвые, но круглые в сумме)
    const BARK = '#3a2a22', BARK2 = '#4a362c';
    // облако цветов: на высоком — с фактурой цветков (меш крон), на низком/среднем — гладкий эллипсоид 8×6 в общем упрощённом
    // декоре (у упрощённых крон общего конвейера всего 4 пояса — они гранёные); цвет — средний тон фактуры
    const LPINK = ['#ffc6d8', '#ffd2e0', '#ffbdd2', '#ffdbe7', '#ffc0d6'];
    const blob = (x, y, z, r, sy, lite) => {
      const ry = R(0, 6.28);
      L({ sph: true, r, x, y, z, sx: 1.12, sy: sy || 0.74, sz: 1.06, ry, color: pick(PINKS), seg: 10, hs: 7, hiOnly: true });
      if (lite !== false) a.lo.push({ sph: true, r: r * 1.04, x, y, z, sx: 1.12, sy: sy || 0.74, sz: 1.06, ry, color: pick(LPINK), seg: 8, hs: 5 });
    };
    const tree = (x, z, h, k, o) => {
      o = o || {}; k = k || 1; h = h || 5.4;
      const lean = R(0, 6.28), fh = h * 0.36, f = [x + Math.cos(lean) * 0.32 * k, fh, z + Math.sin(lean) * 0.32 * k];
      D(stick([x, 0, z], [x + Math.cos(lean) * 0.08, 0.7, z + Math.sin(lean) * 0.08], 0.34 * k, 0.27 * k, BARK, 7), stick([x + Math.cos(lean) * 0.08, 0.6, z + Math.sin(lean) * 0.08], f, 0.27 * k, 0.2 * k, BARK2, 7));
      const m = o.m || 4;
      for (let j = 0; j < m; j++) {
        const an = lean + j * 6.28 / m + R(-0.4, 0.4), out = R(1.5, 2.0) * k, up = h * R(0.6, 0.7);
        const e = [f[0] + Math.cos(an) * out, up, f[2] + Math.sin(an) * out];
        D(stick(f, e, 0.16 * k, 0.07 * k, BARK2, 5));
        if (j % 2 === 0) { const e2 = [e[0] + Math.cos(an + 0.8) * 0.8 * k, up + 0.5 * k, e[2] + Math.sin(an + 0.8) * 0.8 * k]; HD(stick(e, e2, 0.07 * k, 0.04 * k, BARK2, 4)); }
        if (o.dense) {
          // плотная гроздь мелких облаков с фактурой: и на низком/среднем силуэт пушистый, грани мелкие
          for (let i = 0; i < 5; i++) { const a3 = an + R(-1.6, 1.6), r3 = R(0.15, 0.95) * k; L({ sph: true, r: R(0.52, 0.64) * k, x: e[0] + Math.cos(a3) * r3, y: e[1] + R(-0.4, 0.45) * k, z: e[2] + Math.sin(a3) * r3, sx: 1.1, sy: 0.82, sz: 1.05, rx: R(-0.6, 0.6), rz: R(-0.6, 0.6), ry: R(0, 6.28), color: pick(PINKS), seg: 7, hs: 5 }); }
          continue;
        }
        blob(e[0], e[1] + 0.2 * k, e[2], R(1.1, 1.2) * k);
        const a2 = an + (j % 2 ? 1 : -1) * R(0.8, 1.1), rr = R(0.8, 1.0) * k;
        blob(e[0] + Math.cos(a2) * rr, e[1] - R(0.2, 0.45) * k, e[2] + Math.sin(a2) * rr, R(0.85, 0.98) * k, 0.68, j % 2 === 0);
      }
      if (o.dense) { for (let i = 0; i < 5; i++) { const a3 = i * 1.26 + R(-0.3, 0.3), r3 = (i ? R(0.7, 1.2) : 0) * k; L({ sph: true, r: R(0.58, 0.68) * k, x: f[0] + Math.cos(a3) * r3, y: h * R(0.82, 0.92), z: f[2] + Math.sin(a3) * r3, sx: 1.1, sy: 0.82, sz: 1.05, rx: R(-0.6, 0.6), rz: R(-0.6, 0.6), ry: R(0, 6.28), color: pick(PINKS), seg: 7, hs: 5 }); } }
      else {
      blob(f[0] + Math.cos(lean + 1.6) * 0.6 * k, h * 0.84, f[2] + Math.sin(lean + 1.6) * 0.6 * k, 1.15 * k, 0.7);
      blob(f[0] + Math.cos(lean - 1.6) * 0.6 * k, h * 0.8, f[2] + Math.sin(lean - 1.6) * 0.6 * k, 1.1 * k, 0.7);
      }
      if (o.solid !== false) hid(x - 0.3 * k, z - 0.3 * k, x + 0.3 * k, z + 0.3 * k, fh + 0.4);
      if (o.petals !== false) a.ground.push({ kind: 'petals', x, z, sz: 6.4 * k });
      a.trees.push({ x: f[0], y: h * 0.75, z: f[2], r: 2.6 * k, petals: o.fall !== false });
    };
    // торговый автомат лицом в сторону n
    const vend = (x, z, n, col) => {
      const X = isX(n), s = sg(n), w = 0.92, d = 0.78, hh = 1.86;
      hid(X ? x - d / 2 : x - w / 2, X ? z - w / 2 : z - d / 2, X ? x + d / 2 : x + w / 2, X ? z + w / 2 : z + d / 2, hh);
      D(box(X ? d : w, hh, X ? w : d, x, hh / 2, z, col || '#e8e8e4'), box(X ? d + 0.04 : w + 0.04, 0.1, X ? w + 0.04 : d + 0.04, x, hh + 0.05, z, IRON), box(X ? d + 0.02 : w + 0.02, 0.08, X ? w + 0.02 : d + 0.02, x, 0.04, z, '#3a3c3e'));
      DX('vend', X ? x + s * (d / 2 + 0.005) : x, 0.95, X ? z : z + s * (d / 2 + 0.005), w - 0.06, hh - 0.1, n);
    };
    // велосипед (rot: 0 — вдоль X, иначе вдоль Z): колёса — торы на высоком, диски на низком/среднем
    const bike = (x, z, rot, col) => {
      const c = rot ? 0 : 1, sn = rot ? 1 : 0, ry = rot ? HP : 0, P = (t, y) => [x + c * t, y, z + sn * t];
      col = col || '#b8352a';
      for (const t of [-0.52, 0.52]) { const p = P(t, 0.34); H({ torus: true, r: 0.31, tube: 0.03, x: p[0], y: p[1], z: p[2], ry, color: '#1d1d1d', seg: 12 }); a.lo.push({ cyl: true, r: 0.32, h: 0.04, x: p[0], y: p[1], z: p[2], rx: rot ? 0 : HP, rz: rot ? HP : 0, color: '#26272a', seg: 6 }); }
      D(stick(P(-0.52, 0.34), P(0, 0.36), 0.025, 0.025, col, 3), stick(P(0, 0.36), P(0.35, 0.78), 0.025, 0.025, col, 3), stick(P(-0.52, 0.34), P(-0.15, 0.78), 0.025, 0.025, col, 3),
        stick(P(-0.15, 0.78), P(0.35, 0.78), 0.025, 0.025, col, 3), stick(P(0.52, 0.34), P(0.42, 0.95), 0.022, 0.022, '#9aa0a6', 3));
      const hb = P(0.42, 0.98), sp = P(-0.18, 0.9), bk = P(0.62, 0.72);
      D(box(rot ? 0.5 : 0.04, 0.04, rot ? 0.04 : 0.5, hb[0], hb[1], hb[2], '#2a2a2a'), box(0.22, 0.06, 0.12, sp[0], sp[1], sp[2], '#1d1d1d', 0, ry, 0), box(rot ? 0.32 : 0.3, 0.2, rot ? 0.3 : 0.32, bk[0], bk[1], bk[2], '#9aa0a6'));
    };
    // бетонный столб ЛЭП: траверсы, изоляторы, трансформатор; возвращает точку крепления проводов
    const pole = (x, z, h, rot) => {
      h = h || 8.4;
      D(cyl(0.13, h, x, h / 2, z, '#aaa69d', 0, 0, 0, 7, 0.17), box(rot ? 0.12 : 1.9, 0.12, rot ? 1.9 : 0.12, x, h - 0.55, z, '#5c5a55'), box(rot ? 0.1 : 1.3, 0.1, rot ? 1.3 : 0.1, x, h - 1.25, z, '#5c5a55'));
      for (const t of [-0.8, 0, 0.8]) HD(cyl(0.05, 0.16, x + (rot ? 0 : t), h - 0.41, z + (rot ? t : 0), '#d8d4cc', 0, 0, 0, 5));
      if (R(0, 1) < 0.5) D(cyl(0.28, 0.85, x + (rot ? 0.4 : 0), h - 2.3, z + (rot ? 0 : 0.4), '#8d939a', 0, 0, 0, 7));
      HD(box(0.3, 0.42, 0.04, x, 2.3, z + (rot ? 0 : 0.15), '#f2efe6'), box(0.26, 0.06, 0.05, x, 2.42, z + (rot ? 0 : 0.155), '#1f4f8a'));
      hid(x - 0.18, z - 0.18, x + 0.18, z + 0.18, h);
      return [x, h - 0.4, z];
    };
    // провода с провисом (толщина 0.045 — видны и на среднем)
    const wire = (p, q, sag) => {
      const n = 3;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n, A = [p[0] + (q[0] - p[0]) * t0, p[1] + (q[1] - p[1]) * t0 - Math.sin(t0 * Math.PI) * sag, p[2] + (q[2] - p[2]) * t0];
        const Bq = [p[0] + (q[0] - p[0]) * t1, p[1] + (q[1] - p[1]) * t1 - Math.sin(t1 * Math.PI) * sag, p[2] + (q[2] - p[2]) * t1];
        D(G.limb(A, Bq, 0.045, '#1c1c1c'));
      }
    };
    const wires = (p, q, sag) => { for (const o of [-0.8, 0.8]) { const dx = Math.abs(q[0] - p[0]) > Math.abs(q[2] - p[2]) ? 0 : o, dz = dx ? 0 : o; wire([p[0] + dx, p[1], p[2] + dz], [q[0] + dx, q[1], q[2] + dz], sag || 0.6); } };
    // гирлянда фонарей между двумя точками
    const garland = (p, q, n, sag, cols) => {
      wire(p, q, sag);
      for (let i = 1; i < n; i++) { const t = i / n, y = p[1] + (q[1] - p[1]) * t - Math.sin(t * Math.PI) * sag; lan(p[0] + (q[0] - p[0]) * t, y - 0.42, p[2] + (q[2] - p[2]) * t, (cols || ['#d63a26', '#f3e2b8'])[i % 2], y); }
    };
    // бочка сакэ, кадка с растением, крыльцо
    const taru = (x, z, k) => { k = k || 1; hid(x - 0.36 * k, z - 0.36 * k, x + 0.36 * k, z + 0.36 * k, 0.7 * k); D(cyl(0.36 * k, 0.7 * k, x, 0.35 * k, z, '#d8c69a', 0, 0, 0, 9), cyl(0.37 * k, 0.06 * k, x, 0.62 * k, z, '#3a2a1a', 0, 0, 0, 9), cyl(0.37 * k, 0.06 * k, x, 0.1 * k, z, '#3a2a1a', 0, 0, 0, 9), box(0.04, 0.3 * k, 0.32 * k, x + 0.36 * k, 0.38 * k, z, pick(['#b02a1e', '#23326a', '#1d1d1d']))); };
    const pot = (x, z, k) => { k = k || 1; hid(x - 0.24 * k, z - 0.24 * k, x + 0.24 * k, z + 0.24 * k, 0.5 * k); D(cyl(0.24 * k, 0.36 * k, x, 0.18 * k, z, '#6b4a3a', 0, 0, 0, 8, 0.18 * k), { sph: true, r: 0.3 * k, x, y: 0.55 * k, z, sy: 0.8, color: '#4f7f36', seg: 7 }); };
    // ящики: обычный 0.9–1.3 м (запрыгнуть можно), с крышкой-рамкой; штабель — ящик на ящике
    const crate = (x, z, s, y0) => { box3(x, z, s, s, s, y0 || 0); };
    const stack = (x, z, s) => { crate(x, z, s); crate(x + 0.08, z - 0.05, s * 0.8, s); };
    // деревянный ящик с овощами у лавки (низкое укрытие 0.9)
    const crateLow = (x, z, w, d) => { B(x - w / 2, z - d / 2, x + w / 2, z + d / 2, 0.9, 'crate', 0, { uv: 'face' }); };
    // тележка (rot: 0 — вдоль X, иначе вдоль Z): ручки внутри коллизии
    const cart = (x, z, rot) => {
      const ax = !rot, ry = rot ? HP : 0, Lp = (lx, lz) => ax ? [x + lx, z + lz] : [x + lz, z + lx];
      D(box(2.2, 0.12, 1.2, x, 0.78, z, '#7a5434', 0, ry, 0));
      for (const s of [-1, 1]) { const p = Lp(0, s * 0.57); D(box(2.2, 0.3, 0.06, p[0], 0.98, p[1], '#6a4a2e', 0, ry, 0)); }
      for (const s of [-1, 1]) { const p = Lp(0.25, s * 0.72); H({ torus: true, r: 0.44, tube: 0.06, x: p[0], y: 0.46, z: p[1], ry, color: '#3a2a1e', seg: 14 }); a.lo.push({ cyl: true, r: 0.48, h: 0.07, x: p[0], y: 0.46, z: p[1], rx: ax ? HP : 0, rz: ax ? 0 : HP, color: '#3a2a1e', seg: 10 }); for (let k = 0; k < 3; k++) HD(box(0.84, 0.05, 0.05, p[0], 0.46, p[1], '#3a2a1e', 0, ry, k * Math.PI / 3)); }
      for (const s of [-1, 1]) { const a0 = Lp(-1.1, s * 0.45), a1 = Lp(-1.75, s * 0.45); D(stick([a0[0], 0.8, a0[1]], [a1[0], 0.55, a1[1]], 0.045, 0.04, '#6a4a2e', 4)); }
      const sk = ['#d8c8a0', '#cdbb8c', '#e2d4b0'];
      for (let i = 0; i < 4; i++) { const p = Lp(-0.7 + i * 0.47, (i % 2 ? 0.22 : -0.2)); D({ sph: true, r: 0.34, x: p[0], y: 1.05, z: p[1], sx: 1.2, sy: 0.6, sz: 0.8, ry: ry + i, color: sk[i % 3], seg: 7 }); }
      const hx = ax ? 1.8 : 0.78, hz = ax ? 0.78 : 1.8, ox = ax ? -0.3 : 0, oz = ax ? 0 : -0.3;
      hid(x + ox - hx, z + oz - hz, x + ox + hx, z + oz + hz, 1.2);
    };
    // бамбуковый забор (не выше 1.7 м, на просвет не стреляют): столбики, рейки, обвязка
    const bambooFence = (x0, z0, x1, z1, h) => {
      h = h || 1.75; const X = Math.abs(x1 - x0) >= Math.abs(z1 - z0), len = X ? x1 - x0 : z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      B(Math.min(x0, x1) - (X ? 0 : 0.06), Math.min(z0, z1) - (X ? 0.06 : 0), Math.max(x0, x1) + (X ? 0 : 0.06), Math.max(z0, z1) + (X ? 0.06 : 0), h, 'bamboo', 0, { tint: '#e8e2c8' });
      const n = Math.max(1, Math.round(Math.abs(len) / 1.8));
      for (let i = 0; i <= n; i++) { const t = i / n; D(cyl(0.06, h + 0.12, X ? x0 + len * t : cx, (h + 0.12) / 2, X ? cz : z0 + len * t, '#5a4a30', 0, 0, 0, 6)); }
      for (const yy of [0.5, h - 0.35]) D(box(X ? Math.abs(len) : 0.14, 0.07, X ? 0.14 : Math.abs(len), cx, yy, cz, '#3a2a1a'));
    };
    // каменный фонарь торо (большой — укрытие)
    const toro = (x, z, k) => {
      k = k || 1; const st = '#8e8b83', dk = '#77746c';
      D(box(0.8 * k, 0.24 * k, 0.8 * k, x, 0.12 * k, z, dk), cyl(0.3 * k, 0.18 * k, x, 0.33 * k, z, st, 0, 0, 0, 6),
        cyl(0.13 * k, 0.78 * k, x, 0.8 * k, z, st, 0, 0, 0, 8), box(0.66 * k, 0.16 * k, 0.66 * k, x, 1.26 * k, z, dk),
        box(0.46 * k, 0.42 * k, 0.46 * k, x, 1.55 * k, z, st), box(0.24 * k, 0.24 * k, 0.48 * k, x, 1.55 * k, z, '#ffdc96'), box(0.48 * k, 0.24 * k, 0.24 * k, x, 1.55 * k, z, '#ffdc96'),
        { cyl: true, r: 0.03, r2: 0.58 * k, h: 0.32 * k, x, y: 1.92 * k, z, color: dk, seg: 4, ry: Math.PI / 4 }, { sph: true, r: 0.1 * k, x, y: 2.13 * k, z, color: st, seg: 6 });
      a.lamps.push([x, 1.55 * k, z, 0.8 * k]);
      hid(x - 0.4 * k, z - 0.4 * k, x + 0.4 * k, z + 0.4 * k, 2.15 * k);
    };
    // ворота тории: w — пролёт, h — высота, rot — 0 (поперёк Z) или HP
    const torii = (x, z, w, h, rot, col) => {
      const c = col || VER, dx = rot ? 0 : 1, dz = rot ? 1 : 0, ry = rot ? HP : 0;
      for (const s of [-1, 1]) {
        const px = x + dx * s * w / 2, pz = z + dz * s * w / 2;
        D(cyl(0.2, h, px, h / 2, pz, c, 0, 0, 0, 10, 0.24), cyl(0.26, 0.45, px, 0.22, pz, '#1d1d1d', 0, 0, 0, 10));
        hid(px - 0.27, pz - 0.27, px + 0.27, pz + 0.27, h);
        D(box(1.4, 0.3, 0.52, x + dx * s * (w / 2 + 0.5), h + 0.42, z + dz * s * (w / 2 + 0.5), '#1d1d1d', rot ? -s * 0.12 : 0, ry, rot ? 0 : s * 0.12));
      }
      D(box(w + 0.6, 0.3, 0.52, x, h + 0.36, z, '#1d1d1d', 0, ry, 0), box(w + 1.6, 0.24, 0.42, x, h + 0.12, z, c, 0, ry, 0),
        box(w + 0.8, 0.22, 0.24, x, h - 0.85, z, c, 0, ry, 0), box(0.24, 0.7, 0.22, x, h - 0.4, z, c, 0, ry, 0),
        box(0.62, 0.78, 0.1, x, h - 0.4, z, '#24201c', 0, ry, 0), box(0.46, 0.6, 0.12, x, h - 0.4, z, '#d9b23a', 0, ry, 0));
    };

    // ===================== периметр =====================
    // запад: ряд маший вдоль длинной A (фасады на восток)
    mach(-42, -34, -38, -29, { h: 5.4, f: ['+z', '+x'], along: 'x', noWin: true });
    mach(-42, -29, -38, -16, { h: 5.9, f: ['+x'], along: 'z' }); shop('+x', -38, -24.5, { noren: 'norNavy', sign: 'vsTea' }); shop('+x', -38, -19.5, { sign: false, lan: false, door: 'doorWood', noren: false });
    mach(-42, -16, -38, -4, { h: 5.5, f: ['+x'], along: 'z', tint: CREAM, plain: true }); shop('+x', -38, -12.5, { noren: 'norRed', red: true, sign: 'vsSake' }); DA('koshiWin', '+x', -38, -7.2, 1.45, 2.2, 1.1); DA('doorWood', '+x', -38, -9.6, 1.2, 1.4, 2.2);
    mach(-42, -4, -38, 8, { h: 6.1, f: ['+x'], along: 'z' }); shop('+x', -38, -1, { noren: 'norSoba', sign: 'vsInn' }); DA('doorWood', '+x', -38, 4.5, 1.2, 1.5, 2.2);
    // храмовая ограда (запад храма): каменный низ, белая штукатурка, черепичный гребень
    B(-42, 8, -38, 34, 1.2, 'stonewall'); W(-41, 8, -38, 34, 2.2, WHITE, 1.2);
    roof(-41, 8, -38, 34, 3.4, 0.45, 0.35, { col: TILE2, along: 'z', gable: false, th: 0.14 });
    // юг: дома вдоль южной улицы
    mach(-38, -34, -26, -29, { h: 5.6, f: ['+z'], along: 'x', tint: CREAM }); shop('+z', -34.5, -29, { noren: 'norNavy' }); shop('+z', -29, -29, { sign: 'vsRamen', red: true, noren: 'norRed' });
    mach(-26, -34, -12, -29, { h: 6.0, f: ['+z', '+x'], along: 'x' }); shop('+z', -22, -29, { noren: 'norSoba', sign: 'vsTea' }); shop('+z', -16, -29, { sign: false, door: 'doorWood', noren: false, lan: false });
    mach(12, -34, 24, -29, { h: 5.8, f: ['+z', '-x'], along: 'x', tint: OCHRE, plain: true }); shop('+z', 15.5, -29, { noren: 'norRed', sign: 'vsSake' }); DA('koshiWin', '+z', -29, 20.8, 1.45, 2.2, 1.1);
    mach(24, -34, 38, -29, { h: 5.5, f: ['+z'], along: 'x' }); shop('+z', 28, -29, { noren: 'norNavy', sign: 'vsInn' }); shop('+z', 34, -29, { sign: false });
    mach(38, -34, 42, -29, { h: 5.5, f: ['+z', '-x'], along: 'x', tint: CREAM, noWin: true });
    // восток: дома вдоль длинной B (фасады на запад)
    mach(38, -29, 42, -14, { h: 5.7, f: ['-x'], along: 'z', tint: CREAM, plain: true }); shop('-x', 38, -25, { noren: 'norNavy', sign: 'vsTea' }); shop('-x', 38, -18.5, { sign: 'vsRamen', red: true, noren: 'norRed' });
    mach(38, -14, 42, 4, { h: 6.0, f: ['-x'], along: 'z' }); shop('-x', 38, -9.5, { noren: 'norSoba' }); DA('doorWood', '-x', 38, -3.5, 1.2, 1.5, 2.2); shop('-x', 38, 1, { sign: false, lan: false });
    mach(38, 4, 42, 26, { h: 5.6, f: ['-x'], along: 'z', tint: OCHRE });
    mach(38, 26, 42, 34, { h: 5.6, f: ['-x', '-z'], along: 'z', noWin: true });

    // ===================== юг: станция и спавн налётчиков =====================
    // станция: стена с окнами и вывеской, навес на столбах, часы, скамьи, автоматы
    B(-12, -34, 12, -32, 0.5, 'stonewall'); W(-12, -34, 12, -32, 3.9, CREAM, 0.5);
    roof(-12.4, -34, 12.4, -32, 4.4, 1.0, 0.45, { col: TILE2, along: 'x', gable: CREAM, th: 0.16 });
    for (const x of [-9, -3, 3, 9]) { DA('aptWin', '+z', -32, x, 2.4, 1.6, 1.4); wboxH('+z', -32, x, 1.66, 1.7, 0.07, 0.12, '#cfc8bb'); }
    DA('door', '+z', -32, 0, 1.2, 2.0, 2.4); DA('hsStation', '+z', -32, 0, 3.4, 3.2, 0.8, 0.05); wbox('+z', -32, 0, 3.4, 3.4, 0.95, 0.04, '#20150e');
    for (const x of [-10.5, -6, 6, 10.5]) { D(cyl(0.1, 3.05, x, 1.53, -30.4, TIM, 0, 0, 0, 8)); hid(x - 0.14, -30.54, x + 0.14, -30.26, 3.05); }
    D(box(23.4, 0.14, 2.3, 0, 3.12, -31.1, TIM_D), box(23.6, 0.05, 2.5, 0, 3.22, -31.1, '#5d636b'), box(23.6, 0.12, 0.06, 0, 3.16, -29.86, '#3a3c40'));
    D(cyl(0.36, 0.1, 0, 3.75, -31.95, '#f4f1ea', HP, 0, 0, 14), cyl(0.4, 0.06, 0, 3.75, -31.98, TIM_D, HP, 0, 0, 14)); HD(box(0.04, 0.26, 0.02, 0, 3.82, -31.88, '#1a1a1a'), box(0.2, 0.04, 0.02, 0.08, 3.75, -31.88, '#1a1a1a'));
    for (const x of [-7.5, 7.5]) { hid(x - 0.9, -31.9, x + 0.9, -31.4, 0.48); D(box(1.8, 0.07, 0.42, x, 0.45, -31.65, TIM_L), box(1.8, 0.45, 0.06, x, 0.72, -31.86, TIM_L), box(0.08, 0.42, 0.4, x - 0.8, 0.21, -31.65, IRON), box(0.08, 0.42, 0.4, x + 0.8, 0.21, -31.65, IRON)); }
    // клумбы с сакурой по краям площади (укрытие у выходов на южную улицу)
    for (const sx of [-1, 1]) { const cx = sx * 12.6, cz = -26.6; B(cx - 1.1, cz - 1.1, cx + 1.1, cz + 1.1, 0.55, 'stonewall', 0, { ch: 1 }); tree(cx, cz, 5.6, 0.95); }
    vend(-11.5, -24.6, '-z'); vend(-10.55, -24.6, '-z', '#c8302a');
    for (let i = 0; i < 3; i++) bike(4.6 + i * 0.75, -31.3, 1, ['#b8352a', '#2f6fae', '#e8e2d2'][i]);
    hid(4.1, -32, 6.5, -30.6, 1.0);
    // южная улица: столбы и провода, ящики, бочки, каменные фонари
    const pS = [pole(-30, -29.4, 8.4), pole(-14, -29.4, 8.6), pole(14, -29.4, 8.6), pole(30, -29.4, 8.4)];
    wires(pS[0], pS[1]); wires(pS[2], pS[3]); wires(pS[1], pS[2], 0.9);
    crate(-24.2, -25, 1.1); stack(23.5, -25, 1.2); taru(-30.5, -25, 1); taru(-29.8, -25.3, 0.9);
    toro(-7.3, -25.0, 0.8); toro(-0.7, -25.0, 0.8);

    // ===================== длинная A: западная улица =====================
    mach(-33, -24, -20, -19, { h: 5.6, f: ['-z', '+z', '-x'], along: 'x', tint: CREAM, pf: ['+z'] }); shop('-z', -29.5, -24, { noren: 'norNavy', sign: 'vsInn' }); shop('-z', -23.5, -24, { sign: 'vsRamen', red: true, noren: 'norRed' });
    mach(-20, -24, -6, -19, { h: 6.0, f: ['-z', '+z', '+x'], along: 'x' }); shop('-z', -16.5, -24, { noren: 'norSoba', sign: 'vsTea' }); shop('-z', -10, -24, { sign: false, door: 'doorWood', noren: false });
    mach(-33, -16, -24, -4, { h: 5.8, f: ['-x', '-z'], along: 'z' }); shop('-x', -33, -12, { noren: 'norRed', sign: 'vsSake' }); DA('doorWood', '-x', -33, -6.5, 1.2, 1.5, 2.2);
    // кура: высокий белый амбар с тёмным низом намако, окна с железными ставнями, герб
    B(-33, -4, -24, 8, 1.4, 'stonewall'); W(-33, -4, -24, 8, 4.4, WHITE, 1.4);
    roof(-33, -4, -24, 8, 5.8, 2.2, 0.7, { col: TILE, along: 'z', gable: WHITE, th: 0.26 });
    DA('kuraWin', '-x', -33, 2, 4.2, 1.3, 1.3); wbox('-x', -33, 2, 3.5, 1.5, 0.1, 0.14, '#e8e4da'); DA('kuraWin', '+z', 8, -28.5, 4.2, 1.3, 1.3); wbox('+z', 8, -28.5, 3.5, 1.5, 0.1, 0.14, '#e8e4da');
    DA('mon', '-x', -33, -1.5, 4.6, 0.9, 0.9);
    wbox('-x', -33, 2, 5.62, 12.2, 0.18, 0.1, TIM_D); wbox('+z', 8, -28.5, 5.62, 9.2, 0.18, 0.1, TIM_D); wbox('-x', -33, 2, 1.45, 12.1, 0.12, 0.1, '#e8e4da'); wbox('+z', 8, -28.5, 1.45, 9.1, 0.12, 0.1, '#e8e4da');
    // реквизит улицы: телега, ящики, автоматы, велосипеды, бочки, столбы, гирлянда
    cart(-35.8, -9.5, HP);
    stack(-34.0, -1.5, 1.2); crate(-37.2, 2.2, 1.0);
    vend(-37.55, -21.2, '+x', '#2f6fae'); vend(-37.55, -22.15, '+x');
    bike(-33.6, -14.2, 1, '#2f6fae'); bike(-33.6, -13.2, 1, '#e8e2d2'); hid(-33.9, -15, -33, -12.5, 1.0);
    taru(-37.4, -16.8); taru(-37.4, -17.6, 0.9); pot(-33.4, 6.6); pot(-37.6, 6.8, 1.1); pot(-33.4, -19.8);
    const pA = [pole(-37.5, -26, 8.4, 1), pole(-37.5, -10, 8.4, 1), pole(-37.5, 5.2, 8.2, 1)];
    wires(pA[0], pA[1]); wires(pA[1], pA[2]);
    garland([-38, 4.6, -5.5], [-33, 4.6, -5.5], 4, 0.4);
    // соединитель налётчиков (запад): бочка с водой, кадки, бамбуковый забор, фонари
    D(cyl(0.42, 0.9, -26.5, 0.45, -16.6, '#6a4a2e', 0, 0, 0, 10), cyl(0.43, 0.06, -26.5, 0.7, -16.6, IRON, 0, 0, 0, 10), cyl(0.36, 0.02, -26.5, 0.91, -16.6, '#2a4a50', 0, 0, 0, 10));
    hid(-26.95, -17.05, -26.05, -16.15, 0.92);
    pot(-20.5, -16.5); pot(-12.6, -18.5, 1.2); crate(-17.2, -18.4, 1.0);
    garland([-30, 4.4, -19], [-30, 4.4, -16], 2, 0.25); garland([-14, 4.4, -19], [-14, 4.4, -16], 2, 0.25);
    for (const [x, z] of [[-31.6, -16.45], [-27.8, -18.55], [-22.6, -16.45], [-9.2, -18.55]]) pot(x, z, 0.9);
    for (const x of [-24.6, -11.8]) { hid(x - 0.9, -18.95, x + 0.9, -18.5, 0.48); D(box(1.8, 0.07, 0.4, x, 0.45, -18.72, TIM_L), box(0.08, 0.42, 0.36, x - 0.8, 0.21, -18.72, TIM_D), box(0.08, 0.42, 0.36, x + 0.8, 0.21, -18.72, TIM_D)); }
    lan(-28.6, 2.3, -18.45, '#f3e2b8', 2.85); lan(-18.4, 2.3, -16.55, '#d63a26', 2.85);

    // ===================== центр: переулок, канал и мост =====================
    mach(-24, -16, -15, -6, { h: 5.6, f: ['-z', '+z'], along: 'x', tint: CREAM, pf: ['-z'], pfPh: 1 }); shop('-z', -19.5, -16, { sign: false, noren: 'norNavy' });
    mach(-15, -16, -6, -6, { h: 6.1, f: ['-z', '+z', '+x'], along: 'x' }); shop('+x', -6, -14.5, { noren: 'norRed', sign: 'vsSake' });
    // дом на канале: каменная стенка-набережная и белая надстройка
    B(-24, -6, -16, -2, 3.6, 'stonewall'); W(-24, -6, -16, -2, 2.4, WHITE, 3.6); roof(-24, -6, -16, -2, 6.0, 1.2, 0.5, { col: TILE2, along: 'x', th: 0.18 });
    DA('shoji', '+z', -2, -21, 4.8, 1.1, 1.1); DA('shoji', '+z', -2, -18.5, 4.8, 1.1, 1.1); wbox('+z', -2, -20, 3.62, 8.1, 0.16, 0.1, TIM);
    mach(-2, -24, 7, -13, { h: 5.9, f: ['-x', '+z', '-z'], along: 'z', tint: CREAM }); shop('-x', -2, -18.5, { noren: 'norSoba', sign: 'vsTea' }); shop('+z', 2.5, -13, { sign: 'vsRamen', red: true, noren: 'norRed' }); shop('-z', 2.5, -24, { noren: 'norNavy', sign: 'vsInn' });
    mach(7, -24, 14, -13, { h: 5.5, f: ['+z', '-z'], along: 'z', tint: OCHRE, plain: true }); shop('+z', 10.5, -13, { noren: 'norRed', sign: 'vsSake' });
    mach(14, -24, 17, -17, { h: 4.6, f: ['+x', '-z', '+z'], one: true, along: 'z' });
    mach(2, -10, 12, -6, { h: 4.6, f: ['-z', '+z'], one: true, along: 'x', tint: WHITE }); DA('doorWood', '-z', -10, 7, 1.2, 1.5, 2.2); DA('koshiWin', '-z', -10, 4.2, 1.5, 2.0, 1.0); DA('koshiWin', '-z', -10, 9.8, 1.5, 2.0, 1.0);
    mach(12, -10, 17, -2, { h: 5.6, f: ['-z', '-x'], along: 'z', tint: CREAM });
    // канал: каменные стенки, вода, мост; вода непроходима, но простреливается
    a.ground.push({ kind: 'pond', x: -2, z: -4, w: 28, d: 4 });
    for (const [x0, x1] of [[-16, -2.3], [2.3, 12]]) B(x0, -6, x1, -2, 1.3, 'none', 0, { hidden: true, nr: true });
    for (const zz of [-6.12, -1.88]) D(box(28, 0.14, 0.26, -2, 0.08, zz, STONE_D));
    // мост: каменный настил и перила-парапеты (низкое укрытие)
    B(-2.4, -6.4, -2, -1.6, 0.9, 'stonewall', 0, { ch: 1 }); B(2, -6.4, 2.4, -1.6, 0.9, 'stonewall', 0, { ch: 1 });
    B(-2, -6.2, 2, -1.8, 0.06, 'stonewall', 0, { solid: false });
    for (const x of [-2.2, 2.2]) for (const z of [-6.4, -1.6]) { D(box(0.5, 1.2, 0.5, x, 0.6, z, '#9a958b'), box(0.6, 0.1, 0.6, x, 1.25, z, '#7d796f'), { sph: true, r: 0.13, x, y: 1.4, z, sy: 1.4, color: '#7d796f', seg: 6 }); hid(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 1.5); }
    D(box(0.5, 0.08, 4.8, -2.2, 0.94, -4, '#7d796f'), box(0.5, 0.08, 4.8, 2.2, 0.94, -4, '#7d796f'));
    // площадь: низкий каменный парапет вдоль канала, автоматы, велосипеды, доска объявлений
    B(-8, -2, -2.4, -1.65, 0.75, 'stonewall', 0, { ch: 1 }); B(2.4, -2, 8, -1.65, 0.75, 'stonewall', 0, { ch: 1 });
    floor(-8, -1.65, 8, 10, 'stonewall', '#d8d2c6');
    vend(7.55, 6.6, '-x'); vend(7.55, 7.55, '-x', '#c8302a'); vend(7.55, 8.5, '-x', '#2f6fae');
    bike(-7.5, 5.6, 1, '#2f6fae'); bike(-7.5, 6.6, 1, '#b8352a'); bike(-7.5, 7.6, 1, '#e8e2d2'); hid(-7.9, 4.9, -7.0, 8.3, 1.0);
    // доска объявлений под черепичной крышей: закрывает прострел от моста к улице спецназа
    B(0.8, 7.2, 5.0, 7.55, 2.1, 'planks', 0, { tint: '#a08060' });
    for (const x of [0.85, 4.95]) D(box(0.16, 2.6, 0.16, x, 1.3, 7.37, TIM));
    roof(0.6, 7.05, 5.2, 7.7, 2.6, 0.3, 0.22, { col: TILE2, along: 'x', gable: false, th: 0.1 });
    DA('board', '-z', 7.2, 2.9, 1.25, 3.8, 1.5); DA('posters', '+z', 7.55, 2.9, 1.3, 3.4, 1.6);
    // сакура у канала: ветви над водой
    B(-7.2, -0.8, -5.0, 1.4, 0.5, 'stonewall', 0, { ch: 1 }); tree(-6.1, 0.3, 5.8, 1.0);
    tree(6.4, -0.6, 5.4, 0.9);
    toro(-3.2, 9.1, 0.85);
    // святилище хокора у моста: ломает прострел из переулка на мост
    {
      const x = -2.0, z = -9.6;
      B(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 0.5, 'stonewall', 0, { ch: 1 });
      D(box(1.0, 1.2, 0.9, x, 1.1, z, '#6a4a30'), box(0.6, 0.9, 0.06, x, 1.05, z + 0.46, '#2a1c14'));
      for (const [px, pz] of [[-0.6, -0.6], [0.6, -0.6], [-0.6, 0.6], [0.6, 0.6]]) D(box(0.1, 1.5, 0.1, x + px, 1.25, z + pz, VER));
      roof(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 1.95, 0.7, 0.3, { hip: true, col: TILE2, th: 0.1 });
      hid(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 2.3, 0.5); a.lamps.push([x, 1.0, z + 0.6, 0.6]);
    }
    const pM = [pole(-7.5, -1.2, 8.2), pole(7.4, 9.5, 8.2)]; wires(pM[0], pM[1], 0.8);
    garland([-8, 4.0, 9.6], [8, 4.0, -1.8], 7, 0.6);

    // ===================== апартаменты (сквозной проход площадь → двор храма) =====================
    {
      const x0 = -24, x1 = -8, z0 = -2, z1 = 8, hh = 6.2, T = 0.3, CT = 3.0, AP = CREAM;
      B(x0, z0, x1, z0 + T, 0.4, 'stonewall'); W(x0, z0, x1, z0 + T, hh - 0.4, AP, 0.4); // юг (к каналу)
      W(x0, z1 - T, -22.2, z1, hh, AP); W(-19.8, z1 - T, x1, z1, hh, AP); W(-22.2, z1 - T, -19.8, z1, hh - 2.35, AP, 2.35); // север, выход к храму
      W(x0, z0 + T, x0 + T, z1 - T, hh, AP); // запад
      W(x1 - T, z0 + T, x1, 2.0, hh, AP); W(x1 - T, 4.4, x1, z1 - T, hh, AP); W(x1 - T, 2.0, x1, 4.4, hh - 2.4, AP, 2.4); // восток, вход
      B(x0 + T, z0 + T, x1 - T, z1 - T, 0.22, 'planks', CT, { tint: '#e2c9a6' }); // деревянный потолок
      // перегородки коридора (z 2.0..4.4)
      const IW = '#ecd9b8';
      W(x0 + T, 1.8, -20.4, 2.0, CT, IW); W(-18.6, 1.8, -12.4, 2.0, CT, IW); W(-10.6, 1.8, x1 - T, 2.0, CT, IW);
      W(-20.4, 1.8, -18.6, 2.0, CT - 2.2, IW, 2.2); W(-12.4, 1.8, -10.6, 2.0, CT - 2.2, IW, 2.2);
      W(-16.1, z0 + T, -15.9, 1.8, CT, IW); // между южными комнатами
      W(x0 + T, 4.4, -22.2, 4.6, CT, IW); W(-19.8, 4.4, -13.4, 4.6, CT, IW); W(-11.6, 4.4, x1 - T, 4.6, CT, IW);
      W(-22.2, 4.4, -19.8, 4.6, CT - 2.2, IW, 2.2); W(-13.4, 4.4, -11.6, 4.6, CT - 2.2, IW, 2.2);
      W(-18.0, 4.6, -17.8, z1 - T, CT, IW); // холл | кухня
      for (const zz of [1.98, 4.42]) { const s2 = zz < 3 ? 1 : -1; D(box(15.4, 0.1, 0.05, -16, 2.2, zz + s2 * 0.03, TIM_L), box(15.4, 0.14, 0.05, -16, 0.07, zz + s2 * 0.03, TIM_D)); for (const x of [-23.6, -20.5, -18.5, -16, -12.5, -10.5, -8.4]) D(box(0.12, CT, 0.06, x, CT / 2, zz + s2 * 0.04, TIM_L)); }
      // полы: коридор и холл — доски, комнаты — татами
      floor(x0 + T, 2.0, x1 - T, 4.4, 'planks'); floor(x0 + T, 4.6, -18.0, z1 - T, 'planks'); floor(-17.8, 4.6, x1 - T, z1 - T, 'planks', '#d9c7a6');
      floor(x0 + T, z0 + T, -16.1, 1.8, 'planks', '#d8d09c'); floor(-15.9, z0 + T, x1 - T, 1.8, 'planks', '#d8d09c');
      // наружные пояса между этажами, окна, двери квартир второго этажа, галерея с перилами над каналом
      for (const [yy, hb] of [[CT + 0.1, 0.22], [hh - 0.1, 0.18]]) { D(box(16.12, hb, 0.12, -16, yy, z0 - 0.06, TIM), box(16.12, hb, 0.12, -16, yy, z1 + 0.06, TIM), box(0.12, hb, 10.12, x1 + 0.06, yy, 3, TIM)); }
      for (const x of [-21, -13]) { DA('aptWin', '-z', z0, x, 1.6, 1.4, 1.3); wboxH('-z', z0, x, 0.92, 1.5, 0.07, 0.12, '#cfc8bb'); }
      for (let i = 0; i < 4; i++) { const x = -22 + i * 4; DA('aptDoor', '-z', z0, x, CT + 1.22, 0.95, 2.1); DA(i % 2 ? 'aptWinLit' : 'aptWin', '-z', z0, x + 1.7, CT + 1.5, 1.1, 1.1); DA('meter', '-z', z0, x - 0.9, CT + 1.8, 0.4, 0.4); }
      D(box(16.4, 0.14, 1.3, -16, CT + 0.12, z0 - 0.65, '#bdb6aa'), box(16.4, 0.06, 0.06, -16, CT + 1.15, z0 - 1.27, '#d8d4cc'));
      for (let i = 0; i <= 16; i++) (i % 4 ? HD : D)(box(0.05, 1.0, 0.05, x0 - 0.1 + i * 1.0125, CT + 0.66, z0 - 1.27, '#d8d4cc'));
      D(box(16.4, 0.5, 0.03, -16, CT + 0.55, z0 - 1.28, '#c8c4bc'));
      for (let i = 0; i < 3; i++) { const x = -21.3 + i * 4.6; H(box(0.7, 0.5, 0.36, x, CT + 0.45, z0 - 0.5, '#e6e4de'), cyl(0.15, 0.04, x, CT + 0.45, z0 - 0.69, '#4a4c50', HP, 0, 0, 8)); }
      // бельё на галерее
      H(box(9, 0.03, 0.03, -16, CT + 2.25, z0 - 1.1, '#5a5a5a'));
      for (let i = 0; i < 6; i++) H(box(0.5, 0.62 - (i % 2) * 0.18, 0.03, -19.6 + i * 1.4, CT + 1.9, z0 - 1.1, ['#ffffff', '#7fa8d8', '#f2c94c', '#e88aa0', '#ffffff', '#9ac48a'][i]));
      // восточный фасад (на площадь): козырёк над входом, табличка, окна, почтовые ящики
      roof(x1 - 0.1, 1.6, x1 + 1.0, 4.8, 2.75, 0.22, 0.12, { col: TILE2, along: 'z', gable: false, th: 0.1 });
      DA('plate', '+x', x1, 0.6, 2.66, 0.7, 0.7);
      DA('aptWin', '+x', x1, 0, CT + 1.5, 1.4, 1.4); DA('aptWinLit', '+x', x1, 6.2, CT + 1.5, 1.4, 1.4); DA('shoji', '+x', x1, 6.3, 1.6, 1.4, 1.4); DA('shoji', '+x', x1, -0.2, 1.6, 1.3, 1.3);
      // северный фасад (к храму): окна, козырёк над выходом
      DA('aptWin', '+z', z1, -15, 1.6, 1.4, 1.3); DA('aptWin', '+z', z1, -11, 1.6, 1.4, 1.3);
      for (const x of [-22.5, -18, -13.5, -9.5]) DA(x === -18 ? 'aptWinLit' : 'aptWin', '+z', z1, x, CT + 1.6, 1.3, 1.3);
      roof(-22.6, z1 - 0.1, -19.4, z1 + 0.9, 2.7, 0.2, 0.12, { col: TILE2, along: 'x', gable: false, th: 0.1 });
      roof(x0, z0, x1, z1, hh, 1.6, 0.7, { col: TILE2, along: 'x', gable: AP });
      // внутри: генкан с полкой для обуви, почтовые ящики, комнаты с низкими столиками, подушками, лампами, фусума
      D(box(0.98, 0.08, 2.3, x1 - 0.81, 0.04, 3.2, '#9a968c'));
      hid(-11, 4.05, -9.2, 4.4, 1.1); D(box(1.8, 1.05, 0.35, -10.1, 0.53, 4.22, TIM_L), box(1.82, 0.04, 0.37, -10.1, 1.07, 4.22, TIM_D));
      D(box(0.35, 1.1, 1.8, -23.52, 1.45, 6.0, '#a8aeb2')); hid(-23.7, 5.1, -23.34, 6.9, 2.0, 0.9); DA('mailbox', '+x', -23.34, 6.0, 1.45, 1.7, 1.1);
      const room = (cx, cz, n) => {
        hid(cx - 0.55, cz - 0.4, cx + 0.55, cz + 0.4, 0.4);
        D(box(1.1, 0.06, 0.8, cx, 0.36, cz, '#5a3a24'), box(0.9, 0.3, 0.6, cx, 0.17, cz, TIM_D));
        for (const [ox, oz] of [[-0.9, 0], [0.9, 0], [0, 0.7]]) D(box(0.55, 0.1, 0.55, cx + ox, 0.07, cz + oz, pick(['#8a2a2a', '#23326a', '#6a5a2a'])));
        H(cyl(0.05, 0.08, cx - 0.2, 0.43, cz, '#e8e0d0', 0, 0, 0, 6), cyl(0.18, 0.04, cx + 0.15, 0.41, cz + 0.1, '#2a1c14', 0, 0, 0, 8), { sph: true, r: 0.06, x: cx + 0.15, y: 0.45, z: cz + 0.1, color: '#e8a040', seg: 5 });
        // напольный фонарь андон
        const lx = cx + (n ? 1.9 : -1.9), lz = cz - 0.6;
        hid(lx - 0.2, lz - 0.2, lx + 0.2, lz + 0.2, 0.7); D(box(0.32, 0.62, 0.32, lx, 0.33, lz, '#fbecc8'), box(0.38, 0.05, 0.38, lx, 0.66, lz, TIM_D), box(0.38, 0.05, 0.38, lx, 0.03, lz, TIM_D));
        a.lamps.push([lx, 0.4, lz, 0.55]);
      };
      room(-21.6, -0.3, 1); room(-13.6, -0.3, 1); room(-15.0, 6.6, 0);
      for (const x of [-22.4, -14.4, -9.4]) DA('fusuma', '-z', 1.8, x, 1.3, 1.8, 2.2);
      for (const x of [-22.4, -16.6, -14.6, -9.6]) DA('shoji', '+z', 2.0, x, 1.3, 1.4, 1.4);
      for (const x of [-16.2, -10.2]) DA('fusuma', '-z', 4.4, x, 1.3, 1.6, 2.2);
      DA('shoji', '+z', 4.6, -23.1, 1.3, 1.0, 1.0);
      D(box(0.04, 1.2, 0.5, -23.66, 1.5, -0.6, '#efe6d0'), box(0.03, 1.05, 0.38, -23.64, 1.5, -0.6, '#f6f2e6'));
      for (const x of [-21, -15.5, -10.5]) { D(cyl(0.2, 0.3, x, CT - 0.42, 3.2, '#fbecc8', 0, 0, 0, 8)); a.lamps.push([x, CT - 0.45, 3.2, 0.7]); }
    }

    // ===================== идзакая-раменная (сквозной проход площадь → рынок) =====================
    {
      const x0 = 8, x1 = 20, z0 = -2, z1 = 10, hh = 5.7, T = 0.3, CT = 3.1, IZ = WHITE;
      B(x0, z0, x1, z0 + T, 0.4, 'stonewall'); W(x0, z0, x1, z0 + T, hh - 0.4, IZ, 0.4); B(x0, z1 - T, x1, z1, 0.4, 'stonewall'); W(x0, z1 - T, x1, z1, hh - 0.4, IZ, 0.4);
      B(x0, z0 + T, x0 + T, 3.0, CT - 0.35, 'skMachiya'); B(x0, 5.0, x0 + T, z1 - T, CT - 0.35, 'skMachiya'); W(x0, 3.0, x0 + T, 5.0, 0.4, IZ, 2.35);
      B(x0, z0, x0 + T, z1, 0.4, 'plaster', CT - 0.35, { tint: TIM_L }); W(x0, z0, x0 + T, z1, hh - CT - 0.05, IZ, CT + 0.05);
      W(x1 - T, z0 + T, x1, 5.0, hh, IZ); W(x1 - T, 7.0, x1, z1 - T, hh, IZ); W(x1 - T, 5.0, x1, 7.0, hh - 2.35, IZ, 2.35);
      B(x0 + T, z0 + T, x1 - T, z1 - T, 0.22, 'planks', CT, { tint: '#d9b88c' });
      floor(x0 + T, z0 + T, x1 - T, z1 - T, 'planks', '#cdb08a');
      // западный фасад: тёмная решётка, красные фонари, норэн «そば» над входом, вывески
      D(box(0.1, 0.24, 12.1, x0 - 0.05, CT - 0.25, 4, TIM), box(0.1, 0.18, 12.1, x0 - 0.05, hh - 0.1, 4, TIM));
      for (const z of [z0, 1, 3, 5, 7, z1]) D(box(0.14, CT - 0.4, 0.16, x0 - 0.06, (CT - 0.4) / 2, z, TIM_D));
      DA('koshiWin', '-x', x0, 0.6, 1.5, 1.8, 0.9); DA('koshiWin', '-x', x0, 7.6, 1.5, 1.8, 0.9);
      DA('norSoba', '-x', x0, 4, 1.98, 1.9, 0.86, 0.12); D(box(0.05, 0.05, 2.1, x0 - 0.13, 2.42, 4, TIM_D));
      DA('vsRamen', '-x', x0, 5.75, 1.6, 0.46, 1.6, 0.03); DA('vsSake', '-x', x0, 2.25, 1.6, 0.46, 1.6, 0.03);
      lan(x0 - 0.6, 2.25, 2.55, '#d63a26', 2.75); lan(x0 - 0.6, 2.25, 5.45, '#d63a26', 2.75);
      hisashi('-x', x0, z0, z1, CT - 0.1, 0.95, TILE2);
      DA('hsIzakaya', '-x', x0, 4, CT + 0.55, 2.6, 0.65, 0.05);
      for (const z of [0, 8]) DA('shoji', '-x', x0, z, CT + 1.35, 1.3, 1.3);
      // восточный фасад (на рынок): норэн, вывеска, окна
      DA('norNavy', '+x', x1, 6, 1.98, 1.9, 0.86, 0.12); D(box(0.05, 0.05, 2.1, x1 + 0.13, 2.42, 6, TIM_D)); DA('vsTea', '+x', x1, 7.75, 1.6, 0.46, 1.6, 0.03); DA('shoji', '+x', x1, 1.5, 1.6, 1.3, 1.3);
      for (const z of [0, 4, 8]) DA('mushiko', '+x', x1, z, CT + 1.35, 1.8, 0.9);
      D(box(12.1, 0.2, 0.12, 14, CT + 0.05, z0 - 0.06, TIM), box(12.1, 0.2, 0.12, 14, CT + 0.05, z1 + 0.06, TIM), box(0.12, 0.2, 12.1, x1 + 0.06, CT + 0.05, 4, TIM));
      for (const x of [10, 14, 18]) DA('mushiko', '-z', z0, x, CT + 1.3, 1.8, 0.9);
      roof(x0, z0, x1, z1, hh, 1.8, 0.75, { col: TILE, along: 'x', gable: IZ });
      for (const zz of [z0 + T, z1 - T]) { const s2 = zz < 4 ? 1 : -1; D(box(11.4, 0.12, 0.05, 14, 2.1, zz + s2 * 0.03, TIM_L)); for (const x of [8.4, 11, 14, 17, 19.6]) D(box(0.14, CT, 0.06, x, CT / 2, zz + s2 * 0.04, TIM_L)); }
      D(box(11.4, 0.6, 0.04, 14, 0.3, z0 + T + 0.02, '#6a4a2e'));
      // стойка буквой Г, табуреты, кухня за стойкой
      B(10, 6.2, 17, 6.8, 1.05, 'planks'); B(16.4, 6.8, 17, z1 - T, 1.05, 'planks');
      D(box(7.2, 0.06, 0.8, 13.5, 1.08, 6.5, '#8a6440'), box(0.8, 0.06, 2.95, 16.7, 1.08, 8.3, '#8a6440'));
      for (let i = 0; i < 6; i++) { const x = 10.6 + i * 1.1; hid(x - 0.19, 5.56, x + 0.19, 5.94, 0.73); D(cyl(0.18, 0.06, x, 0.7, 5.75, '#7a2626', 0, 0, 0, 8), cyl(0.04, 0.68, x, 0.34, 5.75, IRON, 0, 0, 0, 5)); }
      hid(9.4, z1 - 0.95, 15.8, z1 - 0.3, 0.95); D(box(6.4, 0.9, 0.6, 12.6, 0.45, z1 - 0.62, '#9aa0a4'), box(6.4, 0.04, 0.62, 12.6, 0.92, z1 - 0.62, '#c4c8cc'));
      for (const x of [10.6, 12.2, 13.8]) D(cyl(0.26, 0.42, x, 1.15, z1 - 0.62, '#b8bcc0', 0, 0, 0, 10), cyl(0.27, 0.03, x, 1.37, z1 - 0.62, '#6a6e72', 0, 0, 0, 10));
      H({ sph: true, r: 0.3, x: 12.2, y: 1.7, z: z1 - 0.62, sy: 1.6, color: '#f4f2ee', seg: 6 });
      D(box(5.6, 0.04, 0.3, 12.6, 1.95, z1 - 0.46, TIM_L), box(5.6, 0.04, 0.3, 12.6, 2.4, z1 - 0.46, TIM_L));
      for (let i = 0; i < 12; i++) { const x = 10.1 + i * 0.42; D(cyl(0.05, 0.3, x, 2.12, z1 - 0.46, ['#2f5a3a', '#6a2a1a', '#f2ece0', '#3a3a6a'][i % 4], 0, 0, 0, 6)); if (i % 3 === 0) H(cyl(0.04, 0.26, x + 0.2, 2.55, z1 - 0.46, '#e8e0d0', 0, 0, 0, 6)); }
      for (const x of [11, 15]) DA('vsRamen', '-z', 6.8, x, 2.3, 0.4, 1.1, 0.03);
      DA('posters', '-z', z1 - T, 18.4, 1.7, 1.6, 1.4);
      // столы с табуретами
      for (const [tx, tz] of [[11, 0.9], [15.2, 0.9]]) {
        hid(tx - 0.9, tz - 0.55, tx + 0.9, tz + 0.55, 0.78);
        D(box(1.8, 0.07, 1.1, tx, 0.75, tz, '#6a4a2e'), box(1.6, 0.7, 0.08, tx, 0.36, tz, TIM_D));
        for (const sx of [-0.55, 0.55]) for (const sz of [-0.85, 0.85]) D(cyl(0.17, 0.45, tx + sx, 0.23, tz + sz, '#5a3a24', 0, 0, 0, 7));
        H(cyl(0.16, 0.08, tx - 0.3, 0.82, tz, '#e8e2d4', 0, 0, 0, 10), cyl(0.16, 0.08, tx + 0.35, 0.82, tz + 0.15, '#c8402a', 0, 0, 0, 10));
      }
      for (const x of [11, 13.5, 16]) lan(x, 2.45, 5.2, '#d63a26', CT);
      taru(18.9, 1.6, 0.9); stack(18.8, -1.0, 0.9);
    }

    // ===================== восток: блоки у длинной B =====================
    mach(17, -24, 25, -17, { h: 5.8, f: ['-z', '+z'], along: 'x', tint: CREAM, pf: ['+z'], pfPh: 2 }); shop('-z', 21, -24, { sign: 'vsRamen', red: true, noren: 'norRed' }); DA('doorWood', '+z', -17, 21, 1.2, 1.5, 2.2);
    mach(25, -24, 33, -17, { h: 5.4, f: ['-z', '+z', '+x'], along: 'x', plain: true, tint: OCHRE }); shop('-z', 29, -24, { noren: 'norSoba', sign: 'vsTea' }); shop('+x', 33, -20.5, { sign: false, noren: 'norRed' });
    mach(17, -14, 25, -2, { h: 6.0, f: ['-z', '-x'], along: 'z', tint: OCHRE }); shop('-z', 21, -14, { noren: 'norNavy', sign: 'vsInn' }); DA('doorWood', '-x', 17, -12, 1.2, 1.5, 2.2);
    mach(25, -14, 33, -2, { h: 5.6, f: ['-z', '+x'], along: 'z', pf: ['-z'], pfTint: OCHRE }); shop('+x', 33, -8.5, { noren: 'norNavy', sign: 'vsTea' }); shop('-z', 29.5, -14, { sign: 'vsSake', red: true, noren: 'norRed' });
    mach(20, -2, 33, 4, { h: 4.6, f: ['+z', '+x'], one: true, along: 'x', tint: CREAM }); DA('doorWood', '+z', 4, 31, 1.2, 1.5, 2.2); DA('koshiWin', '+z', 4, 25, 1.5, 2.0, 1.0); DA('koshiWin', '+z', 4, 28, 1.5, 2.0, 1.0);
    // восточный соединитель: ящики, бочки, автомат
    crate(15.6, -11.6, 1.0); taru(30.8, -16.4); taru(31.6, -16.4, 0.9); stack(25.6, -16.4, 1.0);
    vend(16.55, -15.3, '-x', '#2f6fae');
    garland([18, 4.4, -17], [18, 4.4, -14], 2, 0.25); garland([30, 4.4, -17], [30, 4.4, -14], 2, 0.25);
    // длинная B: святилище хокора в нише, бочки сакэ, ящики, тележка, столбы
    {
      const x = 36.6, z = -6.5;
      B(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 0.5, 'stonewall', 0, { ch: 1 });
      D(box(0.9, 1.2, 1.0, x, 1.1, z, '#6a4a30'), box(0.06, 0.9, 0.6, x - 0.46, 1.05, z, '#2a1c14'));
      for (const [px, pz] of [[-0.6, -0.6], [0.6, -0.6], [-0.6, 0.6], [0.6, 0.6]]) D(box(0.1, 1.5, 0.1, x + px, 1.25, z + pz, VER));
      roof(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 1.95, 0.7, 0.3, { hip: true, col: TILE2, th: 0.1 });
      hid(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 2.3, 0.5); a.lamps.push([x - 0.6, 1.0, z, 0.6]);
    }
    taru(34, -27.8, 1); taru(34, -27.0, 0.9); taru(34.7, -27.4, 1.05);
    stack(37.0, 0.6, 1.2); crate(34.0, -11.5, 1.0); bike(37.6, -21, 1, '#e8e2d2'); bike(37.6, -20, 1, '#2f6fae'); hid(37.3, -21.8, 38, -19.2, 1.0);
    cart(35.6, -1.8, HP);
    const pB = [pole(37.6, -26, 8.4, 1), pole(37.6, -12, 8.4, 1), pole(37.6, 3, 8.2, 1)];
    wires(pB[0], pB[1]); wires(pB[1], pB[2]);
    garland([33, 4.8, -20.5], [38, 4.8, -20.5], 4, 0.4);

    // ===================== точка B: крытый рынок =====================
    floor(20, 4, 38, 26, 'stonewall', '#cfc8ba');
    {
      const RX0 = 24, RX1 = 34, RZ0 = 6, RZ1 = 24, RY = 4.3;
      for (const x of [RX0, RX1]) for (const z of [6, 10.5, 15, 19.5, 24]) { D(box(0.26, RY, 0.26, x, RY / 2, z, TIM), box(0.34, 0.3, 0.34, x, 0.15, z, STONE)); hid(x - 0.17, z - 0.17, x + 0.17, z + 0.17, RY); }
      for (const x of [RX0, RX1]) D(box(0.22, 0.32, RZ1 - RZ0 + 0.4, x, RY - 0.12, (RZ0 + RZ1) / 2, TIM_D));
      for (const z of [6, 10.5, 15, 19.5, 24]) D(box(RX1 - RX0 + 0.3, 0.24, 0.2, (RX0 + RX1) / 2, RY - 0.08, z, TIM_D));
      roof(RX0, RZ0, RX1, RZ1, RY + 0.1, 1.6, 0.6, { col: TILE2, along: 'z', gable: false, th: 0.18 });
      // фронтоны рынка: решётчатые щиты над въездами, вывески
      for (const z of [RZ0 - 0.05, RZ1 + 0.05]) { D(box(5.4, 0.9, 0.12, 29, RY + 0.4, z, TIM_D), box(5.1, 0.72, 0.14, 29, RY + 0.4, z, '#c63b22')); DX('hsSoba', 29, RY + 0.4, z + (z < 15 ? -0.08 : 0.08), 3.6, 0.6, z < 15 ? '-z' : '+z'); }
      // гирлянды бумажных фонарей вдоль торговой улицы
      for (const z of [8.2, 12.7, 17.2, 21.7]) garland([RX0, RY - 0.25, z], [RX1, RY - 0.25, z], 5, 0.45, ['#f3e2b8', '#d63a26']);
    }
    // лавки-ятай: прилавок (укрытие, запрыгнуть можно), стойки, навес из ткани, товары
    const stall = (x0, z0, x1, z1, n, col, goods) => {
      B(x0, z0, x1, z1, 1.0, 'planks', 0, { tint: '#b89470' });
      const X = isX(n), s = sg(n);
      D(box(x1 - x0 + 0.1, 0.05, z1 - z0 + 0.1, (x0 + x1) / 2, 1.03, (z0 + z1) / 2, '#8a6440'));
      const bx = n === '+x' ? x0 + 0.1 : n === '-x' ? x1 - 0.1 : null, bz = n === '+z' ? z0 + 0.1 : n === '-z' ? z1 - 0.1 : null;
      const ends = !X ? [[x0 + 0.1, bz], [x1 - 0.1, bz]] : [[bx, z0 + 0.1], [bx, z1 - 0.1]];
      for (const [px, pz] of ends) D(box(0.1, 2.6, 0.1, px, 1.3, pz, TIM));
      const cx = (x0 + x1) / 2 + (X ? s * 0.25 : 0), cz = (z0 + z1) / 2 + (X ? 0 : s * 0.25);
      D(box(!X ? x1 - x0 + 0.5 : (x1 - x0) + 0.9, 0.05, !X ? (z1 - z0) + 0.9 : z1 - z0 + 0.5, cx, 2.45, cz, col, !X ? -s * 0.25 : 0, 0, !X ? 0 : s * 0.25));
      for (let i = 0; i < 4; i++) { const t = (i + 0.5) / 4; const px = !X ? x0 + (x1 - x0) * t : (n === '+x' ? x1 + 0.42 : x0 - 0.42), pz = !X ? (n === '+z' ? z1 + 0.42 : z0 - 0.42) : z0 + (z1 - z0) * t; D(box(!X ? (x1 - x0) / 4 - 0.04 : 0.03, 0.34, !X ? 0.03 : (z1 - z0) / 4 - 0.04, px, 2.12, pz, i % 2 ? col : '#f4ecd8')); }
      const gc = goods || ['#e8452a', '#f2a03a', '#7aa04a', '#e9e3d0', '#c8321e'];
      const k = Math.max(3, Math.round((!X ? x1 - x0 : z1 - z0) / 0.55));
      for (let i = 0; i < k; i++) {
        const t = (i + 0.5) / k, px = !X ? x0 + (x1 - x0) * t : (x0 + x1) / 2, pz = !X ? (z0 + z1) / 2 : z0 + (z1 - z0) * t;
        D(box(0.42, 0.12, 0.42, px, 1.12, pz, '#b8945e'));
        for (let j = 0; j < 3; j++) H({ sph: true, r: 0.075, x: px + R(-0.12, 0.12), y: 1.24, z: pz + R(-0.12, 0.12), color: gc[(i + j) % gc.length], seg: 5 });
        a.lo.push({ w: 0.36, h: 0.07, d: 0.36, x: px, y: 1.21, z: pz, color: gc[i % gc.length] });
      }
      lan(cx + (X ? s * 0.5 : 0), 2.0, cz + (X ? 0 : s * 0.5), '#f3e2b8', 2.42);
    };
    stall(24.6, 8.2, 26.8, 10.6, '+x', '#23326a'); stall(24.6, 15.8, 26.8, 18.2, '+x', '#7a2626', ['#f6eedb', '#ffd0d8', '#9ac48a']);
    stall(31.2, 11.6, 33.4, 14.0, '-x', '#2f4a3a', ['#d8a040', '#c8902a', '#f2ece0']); stall(31.2, 19.4, 33.4, 21.8, '-x', '#c63b22', ['#3a5a8a', '#e8e2d2', '#c8321e']);
    // ящики (запрыгнуть), бочки, автоматы
    stack(21.0, 12.0, 1.2); crate(22.0, 20.6, 1.1); taru(36.5, 8.4); taru(36.5, 9.2, 0.9); taru(37.2, 8.8);
    stack(36.4, 16.2, 1.2); crate(36.6, 17.6, 1.0); crate(29.0, 24.9, 1.0); crate(28.4, 13.0, 1.15); crate(29.6, 17.4, 0.95);
    vend(20.45, 16.6, '+x', '#c8302a'); vend(20.45, 17.55, '+x');
    // амбар-кура к северу от рынка
    B(26, 26, 38, 34, 1.3, 'stonewall'); W(26, 26, 38, 34, 4.6, WHITE, 1.3); roof(26, 26, 38, 34, 5.9, 2.2, 0.7, { col: TILE, along: 'x', gable: WHITE, th: 0.26 });
    wbox('-z', 26, 32, 5.72, 12.1, 0.16, 0.1, TIM_D); wbox('-z', 26, 32, 1.36, 12.1, 0.12, 0.1, '#e8e4da'); DA('mon', '-z', 26, 32, 4.2, 1.3, 1.3);
    DA('doorWood', '-z', 26, 29, 1.2, 1.6, 2.3); DA('doorWood', '-z', 26, 35.5, 1.2, 1.6, 2.3);
    // восточные лавки рынка (фасады на запад)
    shop('-x', 38, 9, { noren: 'norNavy', red: true, sign: 'vsSake' }); shop('-x', 38, 15.5, { sign: 'vsTea' }); shop('-x', 38, 21.5, { noren: 'norSoba', sign: 'vsInn' });
    a.letter('B', 29, 15, 4.2);
    // таблички «B» на стенах у входов на рынок
    DA('siteB', '-x', 38, 5.2, 2.6, 0.9, 0.9, 0.02); DA('siteB', '+x', 20, 4.2, 2.6, 0.8, 0.8, 0.02); DA('siteB', '-z', 26, 27.0, 2.6, 0.9, 0.9, 0.02);

    // ===================== северо-восток: квартал спецназа =====================
    B(6, 10, 13, 24, 1.3, 'stonewall'); W(6, 10, 13, 24, 4.3, WHITE, 1.3); roof(6, 10, 13, 24, 5.6, 2.0, 0.7, { col: TILE, along: 'z', gable: WHITE, th: 0.24 });
    DA('kuraWin', '-x', 6, 17, 4.0, 1.3, 1.3); wbox('-x', 6, 17, 3.3, 1.5, 0.1, 0.14, '#e8e4da'); wbox('-x', 6, 17, 5.42, 14.1, 0.16, 0.1, TIM_D); wbox('-x', 6, 17, 1.36, 14.1, 0.12, 0.1, '#e8e4da');
    mach(13, 10, 20, 24, { h: 5.8, f: ['+x', '+z'], along: 'z', tint: CREAM, pf: ['+x'], pfPh: 1 }); shop('+x', 20, 12.5, { noren: 'norRed', sign: 'vsSake' }); DA('doorWood', '+x', 20, 21, 1.2, 1.5, 2.2);
    mach(12, 29, 26, 34, { h: 5.4, f: ['-z', '+x'], along: 'x' }); shop('-z', 16, 29, { noren: 'norSoba', sign: 'vsTea' }); shop('-z', 22.5, 29, { sign: 'vsRamen', red: true, noren: 'norRed' });
    pot(19.4, 28.4); pot(12.6, 28.4, 1.1); taru(25.4, 27.2);

    // ===================== север: спавн спецназа у бани =====================
    // баня сэнто: высокий фасад, вальмовая крыша с медным гребнем, вход с норэн «ゆ», кирпичная труба
    W(-8, 10, 2, 24, 6.8, CREAM); B(-8, 10, 2, 24, 0.45, 'stonewall', 0, { solid: false });
    roof(-8, 10, 2, 24, 6.8, 2.6, 0.8, { col: TILE, along: 'z', hip: true, th: 0.26 });
    roof(-6.4, 23.9, 0.4, 25.2, 3.1, 0.5, 0.3, { col: TILE2, along: 'x', gable: false, th: 0.12 });
    DA('norYu', '+z', 24, -3, 2.02, 2.0, 0.95, 0.12); DA('door', '+z', 24, -3, 1.2, 2.0, 2.3); DA('hsSento', '+z', 24, -3, 4.7, 2.8, 0.7, 0.06); wbox('+z', 24, -3, 4.7, 3.0, 0.86, 0.05, '#20150e');
    DA('shoji', '+z', 24, 0.4, 4.2, 1.4, 1.3); DA('shoji', '+z', 24, -6.2, 4.2, 1.4, 1.3);
    for (const x of [-8, 2]) for (const z of [13.5, 18, 22]) DA('mushiko', x < 0 ? '-x' : '+x', x, z, 4.2, 1.8, 0.9);
    wbox('+z', 24, -3, 3.25, 10.1, 0.18, 0.1, TIM); wbox('-x', -8, 17, 3.25, 14.1, 0.18, 0.1, TIM); wbox('+x', 2, 17, 3.25, 14.1, 0.18, 0.1, TIM);
    D(box(1.6, 11.5, 1.6, -5.5, 5.75, 12.5, '#a0523a'), box(1.8, 0.3, 1.8, -5.5, 11.6, 12.5, '#6d3426'), box(1.7, 0.18, 1.7, -5.5, 9.2, 12.5, '#6d3426'));
    lan(-5.2, 2.3, 24.7, '#f3e2b8', 3.0); lan(-0.8, 2.3, 24.7, '#f3e2b8', 3.0);
    // дом и сад к западу от бани
    mach(-18, 8, -8, 23, { h: 5.6, f: ['-x', '+z', '-z'], along: 'z', tint: WHITE, pf: ['-x'] }); DA('doorWood', '+z', 23, -14, 1.2, 1.5, 2.2);
    // северный ряд за спавном
    mach(-12, 31, 0, 34, { h: 5.2, f: ['-z'], along: 'x', tint: CREAM }); shop('-z', -8, 31, { noren: 'norNavy', sign: 'vsInn' }); DA('doorWood', '-z', 31, -3, 1.2, 1.5, 2.2);
    mach(0, 31, 12, 34, { h: 5.6, f: ['-z'], along: 'x' }); shop('-z', 4, 31, { sign: 'vsRamen', red: true, noren: 'norRed' }); shop('-z', 9, 31, { noren: 'norSoba', sign: false });
    mach(-19, 28, -12, 34, { h: 5.4, f: ['-z', '+x'], along: 'z', tint: OCHRE });
    // улица спецназа к центру: тоннель из красных ворот тории
    for (let i = 0; i < 6; i++) {
      const z = 12.2 + i * 2.1, h = 3.0;
      for (const x of [2.45, 5.55]) { D(cyl(0.12, h, x, h / 2, z, VER, 0, 0, 0, 8), cyl(0.15, 0.32, x, 0.16, z, TIM_D, 0, 0, 0, 8)); hid(x - 0.15, z - 0.15, x + 0.15, z + 0.15, h); }
      D(box(4.1, 0.16, 0.3, 4, h + 0.2, z, TIM_D), box(3.9, 0.15, 0.22, 4, h - 0.02, z, VER), box(3.4, 0.12, 0.16, 4, h - 0.45, z, VER));
    }
    // спавн: колодец, скамьи, кадки, сакура
    {
      const x = -9.6, z = 27.8;
      B(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 0.85, 'stonewall', 0, { ch: 1 }); hid(x - 0.98, z - 0.8, x + 0.98, z + 0.8, 1.6, 0.85);
      D(box(1.5, 0.04, 1.5, x, 0.86, z, '#203a40'), box(0.12, 2.4, 0.12, x - 0.9, 1.2, z, TIM), box(0.12, 2.4, 0.12, x + 0.9, 1.2, z, TIM), cyl(0.05, 2.0, x, 2.2, z, TIM, 0, 0, HP, 6), cyl(0.18, 0.28, x, 1.5, z, '#6a4a2e', 0, 0, 0, 8));
      roof(x - 1.0, z - 0.9, x + 1.0, z + 0.9, 2.4, 0.6, 0.25, { along: 'x', gable: false, th: 0.1, col: TILE2 });
    }
    taru(10.6, 30.2); taru(11.3, 30.3, 0.9); pot(-11.4, 25.0); pot(11.3, 24.8, 1.1);
    for (const x of [-4, 4]) { hid(x - 0.9, 30.3, x + 0.9, 30.8, 0.48); D(box(1.8, 0.07, 0.42, x, 0.45, 30.55, TIM_L), box(0.08, 0.42, 0.4, x - 0.8, 0.21, 30.55, TIM_D), box(0.08, 0.42, 0.4, x + 0.8, 0.21, 30.55, TIM_D)); }
    tree(9.2, 26.4, 5.6, 0.95);
    const pN = [pole(-11.5, 30.6, 8.4), pole(11.6, 25.4, 8.4)]; wires(pN[0], pN[1], 0.9);

    // ===================== точка A: двор храма =====================
    floor(-38, 8, -18, 27, 'gravel'); floor(-26.6, 13.6, -22.6, 27, 'stonewall', '#d6d0c4');
    // главный зал хондо: каменная платформа, алые столбы, белые панели, крыша с медной черепицей
    B(-30, 27, -19, 34, 0.6, 'stonewall', 0, { ch: 1 });
    W(-29.2, 28.4, -19.8, 34, 4.2, WHITE, 0.6);
    for (const x of [-29.4, -27, -24.6, -22.2, -19.8]) D(box(0.32, 4.6, 0.32, x, 2.9, 28.25, VER));
    D(box(9.9, 0.3, 0.34, -24.6, 4.95, 28.25, VER), box(9.9, 0.2, 0.36, -24.6, 2.1, 28.25, VER));
    for (const x of [-28.2, -25.8, -23.4, -21]) DA('shoji', '-z', 28.4, x, 2.4, 1.9, 1.9);
    D(box(10.6, 0.12, 1.3, -24.6, 0.64, 27.7, TIM_L));
    roof(-30.5, 27.2, -18.5, 34, 5.2, 3.2, 1.6, { col: COPPER, along: 'x', hip: true, ridgeCol: '#3d5a50', sof: '#4a2a1e', th: 0.3 });
    // ящик для пожертвований, колокол со шнуром, верёвка симэнава
    B(-25.6, 26.4, -23.6, 27.2, 0.75, 'planks', 0, { tint: '#a08060' }); D(box(2.0, 0.08, 0.8, -24.6, 0.79, 26.8, TIM_D));
    for (let i = 0; i < 9; i++) HD(box(0.08, 0.04, 0.78, -25.5 + i * 0.23, 0.84, 26.8, '#2a1c14'));
    D(cyl(0.11, 9.6, -24.6, 4.5, 28.0, '#d8c48a', 0, 0, HP, 8), { sph: true, r: 0.2, x: -24.6, y: 4.1, z: 27.95, color: '#c9a640', seg: 7 }, cyl(0.04, 2.6, -24.6, 2.8, 27.95, '#c63b22', 0, 0, 0, 5));
    for (let i = 0; i < 5; i++) D(box(0.22, 0.48, 0.02, -27.2 + i * 1.3, 4.1, 27.92, '#ffffff'));
    // пагода (северо-запад): пять ярусов, шпиль сорин
    B(-38, 27, -31, 34, 0.6, 'stonewall', 0, { ch: 1 });
    {
      let py = 0.6;
      for (let i = 0; i < 5; i++) {
        const s = 5.0 - i * 0.55, hh = i ? 1.9 : 2.6, cx = -34.5, cz = 30.5;
        B(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, hh, 'plaster', py, { tint: i ? WHITE : '#f0e6d8', solid: i === 0 });
        for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) D(box(0.24, hh, 0.24, cx + sx * (s / 2 - 0.04), py + hh / 2, cz + sz * (s / 2 - 0.04), VER));
        D(box(s + 0.1, 0.16, s + 0.1, cx, py + hh - 0.1, cz, VER));
        if (i < 2) for (const n of ['-z', '+x']) { const X = isX(n), c = X ? cx + s / 2 : cz - s / 2; DA('fusuma', n, c, X ? cz : cx, py + hh * 0.45, s * 0.42, hh * 0.6); }
        py += hh;
        roof(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, py, 1.0, 1.5 - i * 0.08, { hip: true, col: TILE2, finial: i === 4 ? 5.6 : 0, th: 0.2 });
        py += 0.35;
      }
    }
    // стена между пагодой и залом
    W(-31, 27, -30, 34, 3.2, WHITE, 0, true); W(-38, 33.2, -31, 34, 3.2, WHITE, 0, true);
    // большие ворота-тории у входа с длинной A и каменные фонари
    torii(-35.5, 9.4, 4.6, 4.4, 0, VER);
    toro(-37.3, 11.3, 0.9); toro(-33.6, 11.3, 0.9);
    // пруд с карпами и каменной каймой (вода простреливается)
    a.ground.push({ kind: 'pond', x: -34.5, z: 19, w: 6.2, d: 6.4 });
    B(-37.9, 15.5, -31.1, 22.5, 1.3, 'none', 0, { hidden: true, nr: true });
    for (const [x0, z0, x1, z1] of [[-37.9, 15.5, -31.1, 15.8], [-37.9, 22.2, -31.1, 22.5], [-37.9, 15.8, -37.6, 22.2], [-31.4, 15.8, -31.1, 22.2]]) B(x0, z0, x1, z1, 0.32, 'stonewall', 0, { solid: false });
    for (const [x, z] of [[-37.7, 15.6], [-31.3, 15.6], [-37.7, 22.4], [-31.3, 22.4]]) D({ sph: true, r: 0.42, x, y: 0.26, z, sy: 0.7, ry: R(0, 3), color: '#8a877f', seg: 7 });
    D({ sph: true, r: 0.56, x: -36.4, y: 0.16, z: 21.0, sx: 1.25, sy: 0.8, ry: 1, color: '#7b7870', seg: 7 });
    // павильон для омовения тёдзуя: каменная чаша (укрытие), крыша на четырёх столбах
    B(-29.6, 11.6, -27.4, 12.8, 0.85, 'stonewall', 0, { ch: 1 }); D(box(2.0, 0.05, 1.0, -28.5, 0.88, 12.2, '#2a5a5e'));
    for (const [px, pz] of [[-30.1, 11.0], [-26.9, 11.0], [-30.1, 13.4], [-26.9, 13.4]]) { D(box(0.2, 2.7, 0.2, px, 1.35, pz, VER)); hid(px - 0.14, pz - 0.14, px + 0.14, pz + 0.14, 2.7); }
    roof(-30.3, 10.8, -26.7, 13.6, 2.75, 0.9, 0.35, { col: COPPER, along: 'x', ridgeCol: '#3d5a50', gable: '#f6f1e8', th: 0.14 });
    for (let i = 0; i < 3; i++) D(cyl(0.03, 0.4, -29.2 + i * 0.7, 1.0, 12.2, '#b8b56a', HP * 0.6, 0, 0, 4));
    // каменные фонари вдоль дороги к залу, комаину, стена эма, бочки сакэ, ящики подношений
    for (const z of [15.5, 21.0]) { toro(-28.1, z, 1.05); toro(-20.9, z, 1.05); }
    for (const x of [-27.2, -22.0]) { hid(x - 0.45, 24.6, x + 0.45, 25.6, 1.6); D(box(0.9, 0.7, 1.0, x, 0.35, 25.1, '#8a867e'), { sph: true, r: 0.42, x, y: 1.0, z: 25.1, sx: 0.9, sy: 1.1, color: '#9a968c', seg: 7 }, { sph: true, r: 0.28, x, y: 1.5, z: 24.85, color: '#9a968c', seg: 6 }); }
    {
      const X = -19.0, Z = 18.0, w = 3.6;
      D(box(0.3, 0.12, w, X, 1.85, Z, '#5a3c26'), box(0.08, 1.3, w, X, 1.15, Z, '#8a6a46'));
      for (const s of [-1, 1]) D(box(0.14, 1.9, 0.14, X, 0.95, Z + s * w / 2, '#4a3426'));
      DA('ema', '-x', X - 0.04, Z, 1.2, w - 0.2, 1.3); DA('ema', '+x', X + 0.04, Z, 1.2, w - 0.2, 1.3);
      roof(X - 0.5, Z - w / 2, X + 0.5, Z + w / 2, 1.95, 0.4, 0.3, { col: TILE2, along: 'z', gable: false, th: 0.1 });
      hid(X - 0.2, Z - w / 2, X + 0.2, Z + w / 2, 2.0);
    }
    for (const [x, z, k] of [[-37.2, 25.6, 1], [-36.5, 25.6, 0.95], [-36.85, 26.2, 0.9], [-31.4, 9.0, 1], [-30.7, 9.0, 0.9]]) taru(x, z, k);
    stack(-24.0, 9.3, 1.2); crate(-36.6, 13.2, 1.1); crate(-25.4, 19.4, 1.05); crate(-31.0, 25.0, 1.2);
    // большая сакура во дворе — главный акцент точки
    B(-22.6, 11.9, -20.4, 14.1, 0.5, 'stonewall', 0, { ch: 1 }); tree(-21.5, 13.0, 6.6, 1.15);
    tree(-30.2, 23.6, 5.8, 0.95);
    // флаги-нобори у зала
    for (const [x, col] of [[-29.6, VER], [-28.6, '#f6eedb'], [-20.6, '#f6eedb'], [-19.6, VER]]) D(cyl(0.04, 4.2, x, 2.1, 26.6, TIM, 0, 0, 0, 5), box(0.62, 2.6, 0.03, x + 0.3, 2.6, 26.6, col), box(0.62, 0.05, 0.05, x + 0.3, 3.92, 26.6, TIM));
    // проход спецназа: малые тории и фонари
    torii(-18.0, 25.0, 4.0, 3.5, HP, VER);
    lan(-16.6, 2.3, 22.8, '#f3e2b8'); lan(-13.6, 2.3, 22.8, '#f3e2b8');
    a.letter('A', -26.5, 18.2, 4.2);
    // таблички «A» у входов во двор храма
    DA('siteA', '+x', -38, 12.2, 2.4, 0.9, 0.9, 0.02); DA('siteA', '+z', 8, -21.0, 3.0, 0.9, 0.9, 0.02); DA('siteA', '-x', -18, 21.4, 2.6, 0.9, 0.9, 0.02);

    // ===================== за пределами (только высокое качество) =====================
    for (const [x0, z0, x1, z1, hh] of [[-60, -30, -48, -18, 6], [-58, -12, -47, 2, 5.4], [-60, 8, -48, 20, 6.2], [-56, 24, -46, 40, 5.6], [47, -32, 60, -20, 5.8], [48, -14, 58, 0, 6.4], [47, 6, 60, 18, 5.4], [48, 24, 58, 38, 6],
      [-30, -52, -16, -40, 5.8], [-10, -50, 6, -40, 6.2], [14, -52, 28, -40, 5.6], [-24, 40, -8, 52, 6], [6, 40, 22, 52, 5.8], [30, 40, 44, 54, 6.4]]) {
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, w = x1 - x0, d = z1 - z0, ax = w >= d;
      H(box(w, hh, d, cx, hh / 2, cz, R(0, 1) < 0.5 ? '#ebe4d6' : '#e2d8c4'), box(w, 1.6, d, cx, 1.0, cz, '#4a3526'));
      H({ shape: true, pts: [[-(ax ? d : w) / 2 - 0.6, 0], [0, 2.2], [(ax ? d : w) / 2 + 0.6, 0]], d: (ax ? w : d) + 1.2, x: cx, y: hh, z: cz, ry: ax ? 0 : HP, color: '#5d656e', cs: 1 });
    }
    for (const [x, z, r] of [[-50, 4, 3.2], [-52, -24, 3.6], [52, -6, 3.4], [50, 21, 3.0], [-4, 46, 3.6], [24, 44, 3.2], [-22, -46, 3.4], [8, -46, 3.0], [-38, 42, 3.6], [40, -42, 3.2]]) {
      H(cyl(0.3, 3, x, 1.5, z, '#3a2a20', 0, 0, 0, 6), { sph: true, r, x, y: 4.6, z, sx: 1.2, sy: 0.75, sz: 1.15, color: '#f6c8d6', seg: 8 }, { sph: true, r: r * 0.7, x: x + r * 0.6, y: 3.9, z: z - r * 0.3, sx: 1.1, sy: 0.75, color: '#fbdce6', seg: 7 });
    }
  }

  // ===================== «Полигон» (обучение) =====================
  function layoutRange(a) {
    const { B, crate, stack, lintel, barrel, lamp } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    B(-22, -18, 22, -17, 5, 'corrug'); B(-22, 17, 22, 18, 5, 'corrug'); B(-22, -17, -21, 17, 5, 'corrug'); B(21, -17, 22, 17, 5, 'corrug');
    for (const [x0, z0, x1, z1] of [[-22, -18, 22, -17], [-22, 17, 22, 18], [-22, -17, -21, 17], [21, -17, 22, 17]]) B(x0, z0, x1, z1, 0.9, 'hazard', 0, { solid: false });
    // полоса препятствий: коридор, барьер для прыжка, балка для приседа
    B(-5, -10.5, -4.5, 7, 2.6, 'concrete'); B(4.5, -10.5, 5, 7, 2.6, 'concrete');
    B(-4.5, -0.3, 4.5, 0.3, 0.9, 'hazard');
    lintel(-4.5, -5.5, 4.5, -4.5, 1.35, 2.6, 'metal');
    B(-5.2, -10.8, 5.2, 7.3, 0.3, 'roof', 2.6, { solid: false });
    B(-4.5, -10.5, 4.5, 7, 0.02, 'pave', 0, { solid: false });
    // стрельбище: дорожки и щиты за мишенями
    B(-9, -17, 9, -11, 0.02, 'pave', 0, { solid: false });
    for (const x of [-5, 0, 5]) { B(x - 1.3, -17, x + 1.3, -16.5, 2.4, 'planks'); B(x - 1.4, -17, x + 1.4, -16.4, 0.12, 'metal', 2.4); }
    B(-9.4, -16, -9, -11, 1.0, 'concrete'); B(9, -16, 9.4, -11, 1.0, 'concrete');
    a.sandbags(-6.5, -11.6, 3.2, 0, 2); a.sandbags(6.5, -11.6, 3.2, 0, 2);
    // яма для гранат: невысокая ограда, мишени внутри
    B(10, -14, 18, -13.6, 1.1, 'hazard'); B(10, -6.4, 18, -6, 1.1, 'hazard'); B(10, -14, 10.4, -6, 1.1, 'hazard'); B(17.6, -14, 18, -6, 1.1, 'hazard');
    B(10.4, -13.6, 17.6, -6.4, 0.02, 'sand', 0, { solid: false });
    a.tires(11.6, -12.6, 2); barrel(16.4, -7.4, '#8a2d22');
    // точка A
    B(-18, -14, -10, -6, 0.02, 'pave', 0, { solid: false });
    a.sandbags(-14, -5.2, 3, 0, 2); a.sandbags(-18.6, -10, 2.6, HP, 2);
    crate(-11, -13, 1.2); stack(-17, -13, 1.2);
    a.letter('A', -14, -10, 4.5);
    // двор у спавна: ящики, бочки, фонари, вышка
    crate(-9, 12, 1.2); stack(8, 13, 1.3); barrel(10, 10, '#2f5f8a'); barrel(10.7, 10.4, '#3b5f3a'); crate(-8, 4, 1.1); crate(12, 3, 1.2);
    a.tires(-16, 15, 3); a.tires(17, -2, 2);
    lamp(-8, -9, 6, HP); lamp(8, -9, 6, -HP); lamp(-16, 2, 6, 0); lamp(16, 8, 6, Math.PI);
    B(-20, 8, -16, 12, 3.2, 'contGreen'); B(16, -16, 20, -12, 2.6, 'contBlue');
    // смотровая вышка в юго-восточном углу
    for (const [x, z] of [[16, 14], [19.5, 14], [16, 16.5], [19.5, 16.5]]) a.D(cyl(0.12, 6, x, 3, z, '#4a4d50', 0, 0, 0, 8));
    a.D(box(4.3, 0.2, 3.3, 17.75, 6, 15.25, '#5a5d60'), box(4.3, 1.0, 0.1, 17.75, 6.6, 13.65, '#6a6d70'), box(0.1, 1.0, 3.3, 15.65, 6.6, 15.25, '#6a6d70'));
    B(15.6, 13.6, 19.9, 16.9, 7, 'none', 0, { hidden: true });
    detailRange(a);
  }
  function detailRange(a) {
    const D = a.decal;
    D(7, -21, 2.6, -8, 1.2, 2.4, '+x'); D(6, -21, 1.8, 10, 1.1, 2.2, '+x'); D(7, 21, 2.6, 4, 1.2, 2.4, '-x');
    D(6, 6, 1.8, 17, 1.1, 2.2, '-z'); D(7, -6, 2.6, 17, 1.2, 2.4, '-z'); D(6, 14, 1.8, -17, 1.1, 2.2, '+z'); D(7, -14, 2.6, -17, 1.2, 2.4, '+z');
    a.stain(0, 9, 2.4); a.stain(-14, -10, 2); a.stain(6, -8, 2.2);
    const p1 = a.pole(-12, 16.5, 7), p2 = a.pole(12, 16.5, 7); a.wire(p1, p2, 1.0);
  }

  // ===================== 2.0 (maps2): общие помощники «Перрона», «Пыльного квартала» и «Неоновой крыши» =====================
  // брусок со скруглёнными (скошенными) рёбрами: w — по X, h — по Y, d — по Z; c — размер фаски. ~60 треугольников
  function m2Bev(w, h, d, x, y, z, color, c, ry) {
    c = Math.min(c || 0.04, w * 0.3, h * 0.3, d * 0.3);
    const hu = d / 2 - c, hv = h / 2 - c, k = c * 0.7;
    return { shape: true, pts: [[-hu + k, -hv], [hu - k, -hv], [hu, -hv + k], [hu, hv - k], [hu - k, hv], [-hu + k, hv], [-hu, hv - k], [-hu, -hv + k]], d: w, bevel: c, bseg: 1, cs: 1, x, y, z, ry: ry || 0, color };
  }
  // рёбра-рейки деревянного ящика (8 брусков поверх коробки столкновения: стойки и верхний пояс)
  function m2CrateFrame(out, x0, y0, z0, x1, y1, z1, col, hiOut) {
    const t = 0.075, e = 0.014, box = G.geo.box, w = x1 - x0, h = y1 - y0, d = z1 - z0, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, cz = (z0 + z1) / 2;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) (hiOut || out).push(box(t, h, t, cx + sx * (w / 2 - t / 2 + e), cy, cz + sz * (d / 2 - t / 2 + e), col));
    const yy = y1 - t / 2 + e; // нижние рейки почти не видны — только верхний пояс (дешевле)
    for (const sz of [-1, 1]) out.push(box(w + 2 * e, t, t, cx, yy, cz + sz * (d / 2 - t / 2 + e), col));
    for (const sx of [-1, 1]) out.push(box(t, t, d - 2 * t + 2 * e, cx + sx * (w / 2 - t / 2 + e), yy, cz, col));
  }

  // ===================== «Неоновая крыша» (дуэль 1 на 1, id winter) =====================
  // Кровля небоскрёба ночью, 36×48 м. Центрально-симметрична: (x, z) ↔ (−x, −z). Спавны — во дворах между надстройками на торцах,
  // перед каждым — стеклянная перегородка (нет прострела спавн—спавн). Три полосы: западная (бар-контейнер), центр (киоск и бассейны —
  // можно запрыгнуть на бортик), восточная (кондиционеры и бак). Все коробки — по целым метрам: клетки навигации проходят ровно.
  function layoutNeon(a) {
    const box = G.geo.box, cyl = G.geo.cyl, B = a.B;
    const D = (...p) => a.D(...p);
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const hid = (x0, z0, x1, z1, h, y0, o) => B(x0, z0, x1, z1, h, 'none', y0 || 0, Object.assign({ hidden: true }, o || {}));
    const MAG = '#ff2f9a', CYA = '#22e6ff', AMB = '#ffb02e', VIO = '#9a5cff', DARK = '#1b1e2c', IRON = '#2c3042', STEEL = '#8e98ac';
    const FL = { NX: '-x', PX: '+x', NZ: '-z', PZ: '+z' };
    const mir = (n, s) => s > 0 ? n : ({ '+x': '-x', '-x': '+x', '+z': '-z', '-z': '+z' })[n];
    const DC = (cell, x, y, z, w, h, n) => a.decals.push({ cell, x, y, z, w, h, n, atlas: 'ntAtlas', lit: true });
    const glow = (x, z, sz, col, k) => a.ground.push({ kind: 'neon', x, z, sz, col, k: k || 1 });
    const crate = (cx, cz, s) => { B(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, s, 'planks', 0, { uv: 'face', tint: '#9c7a52' }); m2CrateFrame(a.decor, cx - s / 2, 0, cz - s / 2, cx + s / 2, s, cz + s / 2, '#4a3a30', a.hi); };
    void FL;
    // ---------- периметр: стены 4,2 м, на них светодиодные ленты, экран и вывеска ----------
    // 2.0: вместо глухих стен 4,2 м — парапет 1,05 м с перилами: с крыши виден ночной город.
    // Столкновение — прежнее (невидимый барьер по периметру той же высоты), прострела наружу нет.
    const WH = 4.2, PH = 1.05, RAIL = '#5d6478';
    for (const [x0, z0, x1, z1] of [[-19, -25, 19, -24], [-19, 24, 19, 25], [-19, -24, -18, 24], [18, -24, 19, 24]]) hid(x0, z0, x1, z1, WH);
    B(-18.4, 24, 18.4, 24.45, PH, 'ntConc', 0, { solid: false, tint: '#8f96b8' }); B(-18.4, -24.45, 18.4, -24, PH, 'ntConc', 0, { solid: false, tint: '#8f96b8' });
    B(-18.45, -24, -18, 24, PH, 'ntConc', 0, { solid: false, tint: '#8f96b8' }); B(18, -24, 18.45, 24, PH, 'ntConc', 0, { solid: false, tint: '#8f96b8' });
    D(box(36.9, 0.1, 0.62, 0, PH + 0.05, 24.2, '#3a3f58'), box(36.9, 0.1, 0.62, 0, PH + 0.05, -24.2, '#3a3f58'), box(0.62, 0.1, 48.4, -18.2, PH + 0.05, 0, '#3a3f58'), box(0.62, 0.1, 48.4, 18.2, PH + 0.05, 0, '#3a3f58'));
    // перила там, где край открыт (за надстройками их не видно); светодиодная лента по парапету
    const rail = (alongX, c, t0, t1) => {
      const L = t1 - t0, n = Math.max(1, Math.round(L / 1.6)), m = (t0 + t1) / 2;
      for (let i = 0; i <= n; i++) { const t = t0 + L * i / n; (i % 3 ? H : D)(alongX ? box(0.07, 1.05, 0.07, t, PH + 0.6, c, RAIL) : box(0.07, 1.05, 0.07, c, PH + 0.6, t, RAIL)); }
      D(alongX ? box(L, 0.07, 0.09, m, PH + 1.12, c, RAIL) : box(0.09, 0.07, L, c, PH + 1.12, m, RAIL));
      D(alongX ? box(L, 0.04, 0.05, m, PH + 0.6, c, RAIL) : box(0.05, 0.04, L, c, PH + 0.6, m, RAIL));
    };
    rail(true, 24.15, -9, 9); rail(true, -24.15, -9, 9); rail(false, -18.15, -17, 14); rail(false, 18.15, -14, 17);
    DC(1, 0, 0.62, 24, 18, 0.42, '-z'); DC(1, 0, 0.62, -24, 18, 0.42, '+z');
    DC(0, -18, 0.62, -1.5, 31, 0.42, '+x'); DC(0, 18, 0.62, 1.5, 31, 0.42, '-x');
    // небоскрёбы вокруг (одна прозрачная наклейка на сторону, видна на любом качестве; в дымке — как фон за картой)
    for (const [n, x, z, w, o] of [['-z', 0, 78, 300, 0], ['+z', 0, -78, 300, 0.37], ['+x', -70, 0, 320, 0.61], ['-x', 70, 0, 320, 0.13]]) {
      const k = w / 340;
      a.decals.push({ x, y: 4, z, w, h: 85, n, atlas: 'ntSkyline', lit: true, uv: [o, 0.002, o + k, 0.998] });
    }
    // ---------- всё остальное — центрально-симметрично ----------
    for (const s of [1, -1]) {
      const X = (v) => v * s, Z = (v) => v * s;
      const BB = (x0, z0, x1, z1, h, mat, y0, o) => B(X(x0), Z(z0), X(x1), Z(z1), h, mat, y0, o);
      const HH = (x0, z0, x1, z1, h, y0, o) => hid(Math.min(X(x0), X(x1)), Math.min(Z(z0), Z(z1)), Math.max(X(x0), X(x1)), Math.max(Z(z0), Z(z1)), h, y0, o);
      const DCs = (cell, x, y, z, w, h, n) => DC(cell, X(x), y, Z(z), w, h, mir(n, s));
      const L = (x, y, z, sz, col) => a.lamps.push([X(x), y, Z(z), sz, col]);
      const GL = (x, z, sz, col, k) => glow(X(x), Z(z), sz, col, k);
      // надстройки на торце: западная глубже, восточная — вытянута вдоль двора
      BB(-18, 14, -9, 24, 6.5, 'ntConc', 0, { tint: '#9aa6cc' });
      BB(9, 17, 18, 24, 6.5, 'ntConc', 0, { tint: '#b2a2d0' });
      for (const [x0, z0, x1, z1] of [[-18, 14, -9, 24], [9, 17, 18, 24]]) D(box(Math.abs(x1 - x0) + 0.5, 0.3, Math.abs(z1 - z0) + 0.5, X((x0 + x1) / 2), 6.65, Z((z0 + z1) / 2), IRON));
      // окна и неон на надстройках
      for (const x of [-16.6, -14.2, -11.8]) DCs(4, x, 4.5, 14, 1.5, 2.1, '-z');
      DCs(1, -13.5, 3.2, 14, 9, 0.6, '-z'); DCs(0, 13.5, 5.6, 17, 9, 0.6, '-z');
      DCs(6, 13.5, 3.3, 17, 6, 3, '-z');
      DCs(7, -9, 1.6, 19, 2.4, 2.4, '+x'); DCs(5, -9, 4.4, 19, 3, 1.5, '+x');
      DCs(4, 9, 4.5, 21, 1.5, 2.1, '-x'); DCs(4, 9, 4.5, 19, 1.5, 2.1, '-x');
      // перегородка перед спавном: стекло-бетон с бирюзовой лентой
      BB(-5, 12, 5, 13, 1.9, 'ntConc', 0, { tint: '#b4bedd' });
      DCs(1, 0, 1.55, 13, 10, 0.55, '+z'); DCs(1, 0, 1.55, 12, 10, 0.55, '-z');
      D(box(10.4, 0.16, 1.4, X(0), 1.98, Z(12.5), IRON));
      // вывеска и свет во дворе
      // 2.0: щит-билборд за парапетом на стальных стойках, сверху — прожекторы на кронштейнах
      D(box(8.2, 4.1, 0.24, X(0), 3.35, Z(24.66), DARK), box(8.4, 0.16, 0.4, X(0), 5.45, Z(24.66), IRON), box(8.4, 0.16, 0.4, X(0), 1.25, Z(24.66), IRON));
      for (const x of [-3.4, 3.4]) D(cyl(0.12, 1.3, X(x), 0.65, Z(24.7), IRON, 0, 0, 0, 8), box(0.14, 4.0, 0.14, X(x), 3.35, Z(24.84), IRON));
      DCs(3, 0, 3.35, 24.53, 7.6, 3.8, '-z');
      GL(0, 21.4, 11, MAG, 0.9); GL(-6, 17, 6, CYA, 0.5); GL(6, 17, 6, VIO, 0.5);
      for (const x of [-2.6, 2.6]) { D(box(0.08, 0.08, 0.9, X(x), 5.62, Z(24.2), IRON), box(0.42, 0.26, 0.36, X(x), 5.55, Z(23.75), '#2a2f44'), box(0.34, 0.03, 0.28, X(x), 5.41, Z(23.75), '#ffe8c0')); L(x, 5.3, 23.7, 1.4, AMB); }
      // бар-контейнер на западной полосе
      BB(-17, 6, -11, 9, 2.6, 'ntConc', 0, { tint: '#7a5a9a', ch: 1 });
      D(box(6.4, 0.2, 3.4, X(-14), 2.7, Z(7.5), IRON), box(6.6, 0.1, 0.16, X(-14), 2.0, Z(5.9), DARK));
      DCs(2, -14, 1.9, 6, 3.4, 1.7, '-z'); DCs(1, -14, 2.38, 6, 6, 0.4, '-z'); DCs(4, -11, 1.5, 7.5, 1.4, 1.5, '+x');
      DCs(4, -17, 1.5, 7.5, 1.4, 1.5, '-x'); DCs(4, -17, 1.5, 8.2, 1.4, 1.5, '-x');
      // 2.0: бар — морской контейнер: гофра на задней стенке, угловые стойки, рама по верху
      for (let x = -16.6; x < -11.2; x += 0.45) H(box(0.14, 2.3, 0.06, X(x), 1.25, Z(9.03), '#6a4a8a'));
      for (const x of [-17, -11]) for (const z of [6, 9]) D(box(0.2, 2.6, 0.2, X(x + (x < -14 ? 0.08 : -0.08)), 1.3, Z(z + (z < 7 ? 0.08 : -0.08)), '#3a2f52'));
      D(box(6.1, 0.16, 0.12, X(-14), 2.52, Z(9.02), '#3a2f52'), box(6.1, 0.16, 0.12, X(-14), 0.1, Z(9.02), '#3a2f52'));
      GL(-14, 4.2, 8, MAG, 0.85); L(-14, 2.6, 5.4, 2.4, MAG); L(-11.4, 2.3, 5.6, 1.4, AMB);
      for (const x of [-15.4, -14, -12.6]) D(cyl(0.24, 0.08, X(x), 0.78, Z(4.9), IRON, 0, 0, 0, 8), cyl(0.05, 0.74, X(x), 0.37, Z(4.9), IRON, 0, 0, 0, 5));
      // кондиционеры на восточной полосе
      BB(11, 3, 17, 6, 2.4, 'ntHvac');
      BB(14, 8, 17, 10, 1.4, 'ntHvac');
      D(box(5.6, 0.12, 2.6, X(14), 2.46, Z(4.5), '#6c7690'), cyl(0.6, 0.1, X(12.3), 2.55, Z(4.5), '#2a2f44', 0, 0, 0, 12), cyl(0.6, 0.1, X(15.7), 2.55, Z(4.5), '#2a2f44', 0, 0, 0, 12));
      D(cyl(0.1, 0.9, X(16.5), 2.9, Z(5.4), IRON, 0, 0, 0, 6));
      D(box(0.22, 0.12, 0.05, X(11.02), 1.9, Z(3.8), '#3dff9a'), box(0.22, 0.12, 0.05, X(11.02), 1.6, Z(3.8), '#ff3a3a'));
      GL(14, 2, 6, CYA, 0.45); L(11.2, 2.0, 2.6, 1.0, CYA);
      // водяной бак
      BB(11, 11, 14, 14, 3.6, 'none', 0, { hidden: true });
      D(cyl(1.45, 2.4, X(12.5), 2.5, Z(12.5), '#58667c', 0, 0, 0, 14), cyl(1.52, 0.14, X(12.5), 1.36, Z(12.5), IRON, 0, 0, 0, 14), cyl(1.52, 0.14, X(12.5), 3.64, Z(12.5), IRON, 0, 0, 0, 14), { cyl: true, r: 0.1, r2: 1.45, h: 0.4, x: X(12.5), y: 3.9, z: Z(12.5), color: '#4a566c', seg: 14 });
      for (const [dx, dz] of [[-1.2, -1.2], [1.2, -1.2], [-1.2, 1.2], [1.2, 1.2]]) D(box(0.14, 1.3, 0.14, X(12.5 + dx), 0.65, Z(12.5 + dz), IRON));
      H(box(0.06, 2.2, 0.06, X(13.9), 2.4, Z(12.5), '#9aa3b8'));
      DCs(1, 12.5, 1.1, 11, 2.8, 0.3, '-z');
      // ящики и бассейн в центре
      crate(X(-6.5), Z(10.5), 1); crate(X(7.5), Z(9.5), 1); crate(X(-2.5), Z(8.5), 1); crate(X(-1.5), Z(8.5), 1);
      BB(3, 3, 9, 4, 0.9, 'ntConc', 0, { tint: '#9aa6cc' }); BB(3, 7, 9, 8, 0.9, 'ntConc', 0, { tint: '#9aa6cc' });
      BB(3, 4, 4, 7, 0.9, 'ntConc', 0, { tint: '#9aa6cc' }); BB(8, 4, 9, 7, 0.9, 'ntConc', 0, { tint: '#9aa6cc' });
      HH(4, 4, 8, 7, 0.78, 0, { nr: true });
      a.ground.push({ kind: 'swim', x: X(6), y: 0.8, z: Z(5.5), w: 4, d: 3 });
      D(box(6.2, 0.1, 1.2, X(6), 0.95, Z(3.5), '#3a3f58'), box(6.2, 0.1, 1.2, X(6), 0.95, Z(7.5), '#3a3f58'));
      GL(6, 5.5, 11, CYA, 0.9); L(6, 1.4, 5.5, 3.2, CYA);
      // шезлонги у бассейна (низкие — можно перешагнуть)
      for (const [x, z, r] of [[1.5, 6.5, 0], [-1.0, 4.4, 0.5]]) { HH(x - 0.5, z - 1, x + 0.5, z + 1, 0.38); D(box(0.8, 0.12, 1.9, X(x), 0.3, Z(z), '#e9e3f5', 0, r * s, 0), box(0.8, 0.5, 0.1, X(x), 0.55, Z(z - 0.9), '#e9e3f5', 0.5)); }
      // огоньки на стойках перил (2.0: раньше висели в воздухе/внутри надстройки)
      L(-18.15, PH + 1.2, 9.6, 0.7, VIO); L(-18.15, PH + 1.2, -3.2, 0.7, CYA); L(18.15, PH + 1.2, 8, 0.7, MAG);
      // 2.0: крыши надстроек — мачта с красным огнём, спутниковая тарелка, вентиляционные грибки
      D(cyl(0.07, 5.6, X(-16.4), 6.65 + 2.8, Z(22.4), STEEL, 0, 0, 0, 6), box(1.3, 0.05, 0.05, X(-16.4), 9.2, Z(22.4), STEEL), box(0.9, 0.05, 0.05, X(-16.4), 10.6, Z(22.4), STEEL));
      for (const [dx, dz] of [[-0.9, -0.9], [0.9, -0.9], [0, 0.9]]) H(stick([X(-16.4), 9.6, Z(22.4)], [X(-16.4 + dx), 6.66, Z(22.4 + dz)], 0.012, 0.012, '#1a1d2a', 3));
      L(-16.4, 12.3, 22.4, 0.8, '#ff3030');
      D(box(0.5, 0.4, 0.5, X(15.4), 6.85, Z(21.2), IRON), { sph: true, r: 0.85, x: X(15.4), y: 7.55, z: Z(21.2), sy: 0.32, rx: s * 0.95, color: '#c8cede', seg: 12 }, stick([X(15.4), 7.4, Z(21.2)], [X(15.4), 8.0, Z(21.2 - 0.55)], 0.02, 0.02, IRON, 4));
      for (const [x, z] of [[-11.6, 16.2], [-13.6, 20.6], [11.4, 19.6]]) H(cyl(0.2, 0.55, X(x), 6.92, Z(z), '#4a5066', 0, 0, 0, 8), cyl(0.34, 0.1, X(x), 7.25, Z(z), '#5a6078', 0, 0, 0, 8));
      // решётки вентиляторов на кондиционере
      for (const x of [12.3, 15.7]) H({ torus: true, r: 0.5, tube: 0.03, x: X(x), y: 2.62, z: Z(4.5), rx: HP, color: '#8e98ac', seg: 14 }, { torus: true, r: 0.28, tube: 0.025, x: X(x), y: 2.62, z: Z(4.5), rx: HP, color: '#8e98ac', seg: 10 }, box(1.1, 0.03, 0.05, X(x), 2.63, Z(4.5), '#8e98ac'));
    }
    // ---------- центр: киоск-ди-джей, вывески «OPEN» и лента ----------
    B(-3, -1.5, 3, 1.5, 3.0, 'ntConc', 0, { tint: '#6e6aa8', ch: 1 });
    D(box(6.6, 0.22, 3.6, 0, 3.12, 0, IRON), box(5.6, 0.1, 2.6, 0, 3.28, 0, '#2a2f44'));
    for (const [z, n] of [[1.5, '+z'], [-1.5, '-z']]) { DC(5, 0, 1.9, z, 3.2, 1.6, n); DC(1, 0, 2.7, z, 6, 0.4, n); DC(4, -2.2, 1.0, z, 1.0, 1.2, n); DC(4, 2.2, 1.0, z, 1.0, 1.2, n); }
    for (const [x, n] of [[3, '+x'], [-3, '-x']]) { DC(6, x, 1.7, 0, 2.4, 1.8, n); DC(0, x, 2.7, 0, 3, 0.4, n); }
    glow(0, 3.2, 8, AMB, 0.8); glow(0, -3.2, 8, AMB, 0.8); glow(-3.8, 0, 6, VIO, 0.6); glow(3.8, 0, 6, MAG, 0.6);
    a.lamps.push([0, 3.5, 0, 2.6, VIO]);
    a.stain(-3, 1, 2.2); a.stain(5, -9, 2.4); a.stain(-8, 10, 2.0);
  }

  // ===================== «Перрон» (2 на 2, одна точка A) =====================
  // Осенняя пригородная станция, 54×76 м (12.0: карта переделана — на ~17 % просторнее, золотой час).
  // Юг — депо и спавн налётчиков, север — привокзальная площадь и спавн спецназа.
  // Точка A — платформа под навесом перед вокзалом. Три пути: длинный (восток: вдоль вагона на запасном пути и
  // коридор у багажного отделения), центр (через пакгауз со стеллажами и пути), короткий (запад: гаражи, водокачка, проход у кассы).
  // Проёмы — с целыми краями шириной ≥ 2 м: клетки навигации (центры на полуцелых) проходят ровно.
  function layoutPerron(a) {
    const box = G.geo.box, cyl = G.geo.cyl, B = a.B;
    // ящики — та же фактура досок, что у вагонов (один материал — меньше вызовов отрисовки)
    // 2.0: у ящика — рейки по рёбрам (видно, что это сколоченный ящик, а не кубик)
    const crate = (x, z, s, y0) => { B(x - s / 2, z - s / 2, x + s / 2, z + s / 2, s, 'prWagon', y0 || 0, { uv: 'face', tint: '#b8905c' }); m2CrateFrame(a.decor, x - s / 2, y0 || 0, z - s / 2, x + s / 2, (y0 || 0) + s, z + s / 2, '#6e4c2c', a.hi); };
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 7331; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    const hid = (x0, z0, x1, z1, h, y0, o) => B(x0, z0, x1, z1, h, 'none', y0 || 0, Object.assign({ hidden: true }, o || {}));
    // наклейка из атласа 4×4 (клетка 128×256); part: 1 — верхняя половина клетки, 2 — нижняя
    const DC = (cell, x, y, z, w, h, n, lit, part) => {
      const u0 = (cell % 4) * 0.25, v1 = 1 - Math.floor(cell / 4) * 0.25;
      let va = v1 - 0.25, vb = v1;
      if (part === 1) va = v1 - 0.125; else if (part === 2) vb = v1 - 0.125;
      a.decals.push({ cell, x, y, z, w, h, n, atlas: 'prAtlas', lit: !!lit, uv: [u0 + 0.002, va + 0.001, u0 + 0.248, vb - 0.001] });
    };
    const floor = (x0, z0, x1, z1, mat) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false });
    const SIL = { tint: '#d6d1c6' }; // силикатный (серо-белый) кирпич: забор, постаменты, рампа
    const MINT = '#a3d6c4', WHITE = '#fbf8f0', ROOF = '#557f68', RUST = '#a4543a', RUST2 = '#8f5a3c', TANK = '#3e4b55';
    const DARK = '#26282b', IRON = '#34373a', CAN = '#3e5b4c', BLUE = '#2f5f9e';
    const GOLD = ['#f0b631', '#e59a24', '#f6cc4a', '#d9822b', '#c9a43a'], PINE = ['#36502f', '#2f472a', '#3d5a34'];
    const LEAF = ['#e8a81e', '#d9861a', '#c96a18', '#b8541a', '#f0bc2c'];
    // стена вдоль X (толщина z0..z1) с проёмами [x0, x1, верх проёма]
    const wallX = (x0, x1, z0, z1, h, mat, doors, o) => {
      let c = x0;
      for (const [d0, d1, top] of doors || []) { if (d0 > c) B(c, z0, d0, z1, h, mat, 0, o); B(d0, z0, d1, z1, h - top, mat, top, o); c = d1; }
      if (x1 > c) B(c, z0, x1, z1, h, mat, 0, o);
    };
    const wallZ = (z0, z1, x0, x1, h, mat, doors, o) => {
      let c = z0;
      for (const [d0, d1, top] of doors || []) { if (d0 > c) B(x0, c, x1, d0, h, mat, 0, o); B(x0, d0, x1, d1, h - top, mat, top, o); c = d1; }
      if (z1 > c) B(x0, c, x1, z1, h, mat, 0, o);
    };
    // крыша (двускатная или вальмовая) в общий меш крыш, фактура — фальцевая кровля
    const roof = (x0, z0, x1, z1, y, h, ov, o) => {
      o = o || {};
      const r = { X0: x0, X1: x1, Z0: z0, Z1: z1, y, h, ov, hip: !!o.hip, col: o.col || ROOF, alongX: o.along ? o.along === 'x' : (x1 - x0) >= (z1 - z0) };
      a.roofs.push(r);
      const g = roofFrame(r), ax = r.alongX, P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa];
      const rc = shade(r.col, 0.7);
      for (const c of [g.C0, g.C1]) { const p = P(g.mid, c, g.ey - 0.05); D(box(ax ? g.A1 - g.A0 : 0.12, 0.12, ax ? 0.12 : g.A1 - g.A0, p[0], p[1], p[2], rc)); }
      if (g.ra1 - g.ra0 > 0.05) { const p = P((g.ra0 + g.ra1) / 2, g.cc, g.top + 0.03); D(box(ax ? g.ra1 - g.ra0 + 0.2 : 0.22, 0.12, ax ? 0.22 : g.ra1 - g.ra0 + 0.2, p[0], p[1], p[2], rc)); }
      if (r.hip) for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) D(stick(P(aa, c, g.ey + 0.03), P(ra, g.cc, g.top + 0.03), 0.07, 0.07, rc, 4));
      else for (const aa of [g.a0w + 0.05, g.a1w - 0.05]) { const p = P(aa, g.cc, y); D({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.1, x: p[0], y, z: p[2], color: o.gable || '#9a5a3e', ry: ax ? 0 : HP, cs: 1 }); }
    };
    // опавшие листья кучкой (только высокое качество)
    const leaves = (x, z, r, n) => { for (let i = 0; i < (n || 6); i++) { const an = R(0, 6.28), rr = R(0, r); H({ sph: true, r: R(0.18, 0.42), x: x + Math.cos(an) * rr, y: 0.03, z: z + Math.sin(an) * rr, sy: 0.12, sx: R(0.8, 1.4), ry: R(0, 3), color: LEAF[i % 5], seg: 6 }); } };
    // берёза: белый ствол с чёрными чёрточками и золотая крона
    const birch = (x, z, h, solid, far) => {
      h = h || R(7, 9.5);
      if (solid !== false) hid(x - 0.22, z - 0.22, x + 0.22, z + 0.22, 7); // 2.0: выше прыжка — на ствол не залезть
      const lx = R(-0.07, 0.07), lz = R(-0.07, 0.07), top = [x + lx * h, h * 0.82, z + lz * h];
      (far ? H : D)(stick([x, 0, z], top, 0.17, 0.07, '#ece7dc', 6));
      if (!far) {
        for (let i = 0; i < 7; i++) { const t = R(0.12, 0.62); H(box(R(0.14, 0.24), 0.05, 0.36, x + lx * h * t, h * 0.82 * t, z + lz * h * t, '#2a2826', 0, R(0, 3), 0)); }
        for (let i = 0; i < 3; i++) { const t = R(0.45, 0.7), an = R(0, 6.28); D(stick([x + lx * h * t, h * 0.82 * t, z + lz * h * t], [x + lx * h * t + Math.cos(an) * 1.5, h * 0.82 * t + 1.1, z + lz * h * t + Math.sin(an) * 1.5], 0.06, 0.03, '#e2ddd2', 4)); }
        leaves(x, z, 2.2, 7);
        a.trees.push({ x: top[0], y: h * 0.74, z: top[2], r: 2.2, petals: true });
      }
      const n = far ? 3 : 6, c0 = Math.abs(Math.round(x * 3 + z * 5));
      for (let k = 0; k < n; k++) {
        const an = k * 6.28 / n + R(-0.4, 0.4), rr = k ? R(0.9, 1.6) : 0;
        (far ? H : L)({ sph: true, r: R(0.95, 1.3) * (far ? 1.25 : 1), x: top[0] + Math.cos(an) * rr, y: h * (k ? R(0.6, 0.78) : 0.9), z: top[2] + Math.sin(an) * rr, sx: 0.95, sy: 1.45, sz: 0.95, ry: R(0, 3), color: GOLD[(k + c0) % 5], seg: far ? 6 : 8 });
      }
    };
    const pine = (x, z, h) => { h = h || R(9, 13); H(cyl(0.18, h * 0.4, x, h * 0.2, z, '#4a3626', 0, 0, 0, 5)); for (let k = 0; k < 3; k++) H({ cyl: true, r: 0.05, r2: h * (0.26 - k * 0.06), h: h * 0.42, x, y: h * (0.4 + k * 0.2), z, color: PINE[k], seg: 7 }); };
    // тележка (поворотная тележка вагона): рама, рессоры и четыре колеса; ax — вагон вдоль X
    const bogie = (bx, zc, ax) => {
      const P = (u, v) => ax !== false ? [bx + u, zc + v] : [bx + v, zc + u];
      const p0 = P(0, 0);
      D(box(ax !== false ? 2.5 : 1.9, 0.4, ax !== false ? 1.9 : 2.5, p0[0], 0.66, p0[1], '#2c2e30'));
      for (const s of [-1, 1]) for (const w of [-0.8, 0.8]) { const p = P(w, s * 0.76); D(cyl(0.46, 0.13, p[0], 0.46, p[1], '#3b3632', ax !== false ? HP : 0, 0, ax !== false ? 0 : HP, 10)); }
      for (const s of [-1, 1]) { const p = P(0, s * 0.98); H(box(ax !== false ? 0.9 : 0.12, 0.22, ax !== false ? 0.12 : 0.9, p[0], 0.62, p[1], '#4a4642'), box(ax !== false ? 0.5 : 0.1, 0.1, ax !== false ? 0.1 : 0.5, p[0], 0.84, p[1], '#4a4642')); }
    };
    // заклёпки рядами (только высокое качество): вдоль X на грани z, от x0 до x1
    const rivetsX = (x0, x1, z, y, n) => { for (let i = 0; i <= n; i++) H(box(0.05, 0.05, 0.04, x0 + (x1 - x0) * i / n, y, z, '#3a2c24')); };
    const rivetsZ = (z0, z1, x, y, n) => { for (let i = 0; i <= n; i++) H(box(0.04, 0.05, 0.05, x, y, z0 + (z1 - z0) * i / n, '#3a2c24')); };
    // сцепка и буфера на торце вагона (вдоль X, торец ex, направление s)
    const couplers = (ex, zc, s) => {
      for (const k of [-1, 1]) H(cyl(0.16, 0.36, ex + s * 0.05, 1.25, zc + k * 0.95, IRON, 0, 0, HP, 8), cyl(0.22, 0.05, ex + s * 0.24, 1.25, zc + k * 0.95, '#2a2c2e', 0, 0, HP, 10)); // 2.0: буфера — на высоком
      D(box(0.5, 0.18, 0.24, ex + s * 0.2, 1.05, zc, '#2a2c2e')); H(box(0.3, 0.3, 0.12, ex + s * 0.4, 1.05, zc, '#3a3836'));
    };
    // крытый товарный вагон вдоль X: двери на рельсах, рёбра, заклёпки, потёки ржавчины
    const boxcar = (x0, x1, zc, col) => {
      const z0 = zc - 1.5, z1 = zc + 1.5, cx = (x0 + x1) / 2, Lg = x1 - x0;
      hid(x0 + 0.3, z0 + 0.3, x1 - 0.3, z1 - 0.3, 1.15);
      B(x0, z0, x1, z1, 2.85, 'prWagon', 1.15, { tint: col });
      D(box(Lg + 0.12, 0.14, 3.14, cx, 4.07, zc, shade(col, 0.72)), box(Lg - 1.0, 0.1, 2.2, cx, 4.18, zc, shade(col, 0.66)));
      D(box(Lg - 0.3, 0.32, 2.7, cx, 1.0, zc, DARK), box(Lg - 5.4, 0.55, 2.3, cx, 0.62, zc, '#1c1d1f'));
      bogie(x0 + 2.0, zc); bogie(x1 - 2.0, zc);
      couplers(x0, zc, -1); couplers(x1, zc, 1);
      for (const [zz, n] of [[z0, '-z'], [z1, '+z']]) {
        DC(6, cx, 2.55, zz, 2.4, 2.6, n);
        DC(10, cx - Lg * 0.3, 3.0, zz, 1.4, 2.4, n); DC(10, cx + Lg * 0.32, 2.9, zz, 1.2, 2.2, n);
        const sz = n === '-z' ? -1 : 1;
        D(box(Lg - 0.6, 0.08, 0.1, cx, 3.95, zz + sz * 0.06, IRON), box(Lg - 0.6, 0.08, 0.1, cx, 1.22, zz + sz * 0.06, IRON));
        D(box(2.8, 0.1, 0.12, cx, 3.88, zz + sz * 0.08, '#1d1e20'));
        for (let k = 0; k <= Math.round(Lg / 1.6); k++) { const px = x0 + 0.3 + (Lg - 0.6) * k / Math.round(Lg / 1.6); if (Math.abs(px - cx) > 1.3) H(box(0.08, 2.7, 0.06, px, 2.57, zz + sz * 0.04, shade(col, 0.8))); }
        rivetsX(x0 + 0.4, x1 - 0.4, zz + sz * 0.07, 3.82, Math.round(Lg / 0.5)); rivetsX(x0 + 0.4, x1 - 0.4, zz + sz * 0.07, 1.32, Math.round(Lg / 0.5));
      }
      for (const ex of [x0 + 0.5, x1 - 0.5]) for (const zz of [z0 - 0.05, z1 + 0.05]) for (let k = 0; k < 5; k++) H(box(0.42, 0.04, 0.05, ex, 1.5 + k * 0.45, zz, IRON));
    };
    // цистерна вдоль X
    const tankcar = (x0, x1, zc) => {
      const cx = (x0 + x1) / 2, Lg = x1 - x0;
      hid(x0 + 0.2, zc - 1.42, x1 - 0.2, zc + 1.42, 3.9);
      D(cyl(1.38, Lg - 1.4, cx, 2.5, zc, TANK, 0, 0, HP, 16));
      for (const ex of [x0 + 0.7, x1 - 0.7]) D({ sph: true, r: 1.38, x: ex, y: 2.5, z: zc, sx: 0.3, color: TANK, seg: 14 });
      D(box(Lg - 1.6, 0.26, 2.82, cx, 1.95, zc, '#c8452e'), cyl(0.55, 0.55, cx, 3.95, zc, TANK, 0, 0, 0, 12), cyl(0.62, 0.08, cx, 4.24, zc, IRON, 0, 0, 0, 12));
      D(box(Lg - 0.2, 0.3, 2.5, cx, 1.05, zc, DARK), box(Lg - 5.4, 0.5, 2.1, cx, 0.62, zc, '#1c1d1f'));
      for (const bx of [x0 + 3, cx - 2.5, cx + 2.5, x1 - 3]) H({ torus: true, r: 1.4, tube: 0.04, x: bx, y: 2.5, z: zc, ry: HP, color: '#2a3238', seg: 16 });
      bogie(x0 + 2.0, zc); bogie(x1 - 2.0, zc);
      couplers(x0, zc, -1); couplers(x1, zc, 1);
      for (const s of [-1, 1]) DC(10, cx + s * 3, 2.6, zc + s * 1.39, 1.6, 2.2, s < 0 ? '-z' : '+z');
      // площадка у люка с перилами
      D(box(2.4, 0.06, 2.0, cx, 3.9, zc, IRON));
      for (const s of [-1, 1]) H(box(2.4, 0.05, 0.05, cx, 4.8, zc + s * 1.0, '#e0b23a'), box(0.05, 0.9, 0.05, cx - 1.2, 4.35, zc + s * 1.0, '#e0b23a'), box(0.05, 0.9, 0.05, cx + 1.2, 4.35, zc + s * 1.0, '#e0b23a'));
      for (let k = 0; k < 6; k++) H(box(0.04, 0.04, 0.5, x1 - 0.55, 1.4 + k * 0.42, zc, '#e0b23a'));
    };
    // платформа-лесовоз с двумя пачками брёвен
    const flatcar = (x0, x1, zc) => {
      const cx = (x0 + x1) / 2, Lg = x1 - x0;
      hid(x0 + 0.2, zc - 1.4, x1 - 0.2, zc + 1.4, 2.55);
      D(box(Lg, 0.3, 2.9, cx, 1.15, zc, '#5d3e2a'), box(Lg - 0.3, 0.3, 2.5, cx, 0.9, zc, DARK), box(Lg - 5.4, 0.45, 2.1, cx, 0.55, zc, '#1c1d1f'));
      bogie(x0 + 2.0, zc); bogie(x1 - 2.0, zc);
      couplers(x0, zc, -1); couplers(x1, zc, 1);
      const bl = (Lg - 1.0) / 2 - 0.2;
      for (const bx of [x0 + 0.5 + bl / 2, x1 - 0.5 - bl / 2]) {
        for (let r = 0; r < 3; r++) for (let i = 0; i < 4 - r; i++) {
          const zz = zc + (i - (3 - r) / 2) * 0.62, y = 1.6 + r * 0.54, c = ['#9a7a52', '#8a6c46', '#a8875c'][(i + r) % 3];
          D(cyl(0.3, bl - R(0, 0.3), bx + R(-0.12, 0.12), y, zz, c, 0, 0, HP, 8));
          H(cyl(0.24, 0.02, bx + bl / 2 + 0.01, y, zz, '#d8c09a', 0, 0, HP, 8));
        }
        for (const s of [-1, 1]) D(box(0.12, 1.5, 0.12, bx, 1.9, zc + s * 1.38, IRON));
        H(box(0.04, 0.04, 2.9, bx - 0.8, 3.15, zc, '#2a2a2a'), box(0.04, 0.04, 2.9, bx + 0.8, 3.15, zc, '#2a2a2a'));
      }
    };
    // рельсы (вдоль X) поверх балласта; шпалы объёмом — на высоком
    const railsX = (x0, x1, zc) => {
      for (const s of [-1, 1]) D(box(x1 - x0, 0.15, 0.09, (x0 + x1) / 2, 0.1, zc + s * 0.76, '#6d6a66'), box(x1 - x0, 0.03, 0.07, (x0 + x1) / 2, 0.19, zc + s * 0.76, '#c4c8cc'));
      for (let xx = x0 + 0.35; xx < x1; xx += 0.75) H(box(0.26, 0.08, 2.5, xx, 0.04, zc, R(0, 1) < 0.5 ? '#4a3c30' : '#3f3328'));
    };
    const railsZ = (z0, z1, xc) => {
      for (const s of [-1, 1]) D(box(0.09, 0.15, z1 - z0, xc + s * 0.76, 0.1, (z0 + z1) / 2, '#6d6a66'), box(0.07, 0.03, z1 - z0, xc + s * 0.76, 0.19, (z0 + z1) / 2, '#c4c8cc'));
      for (let zz = z0 + 0.3; zz < z1; zz += 0.75) D(box(2.5, 0.1, 0.26, xc, 0.05, zz, '#4a3c30'));
    };
    // чугунный фонарь: постамент, каннелированная опора, консоль, фонарь с тёплым стеклом
    const lampPost = (x, z, h, dir) => {
      hid(x - 0.15, z - 0.15, x + 0.15, z + 0.15, h);
      D(cyl(0.08, h, x, h / 2, z, CAN, 0, 0, 0, 6), cyl(0.18, 0.55, x, 0.27, z, CAN, 0, 0, 0, 8), cyl(0.12, 0.12, x, 0.62, z, '#2f463a', 0, 0, 0, 8));
      const dx = Math.sin(dir), dz = Math.cos(dir);
      D(box(0.08, 0.08, 0.9, x + dx * 0.4, h, z + dz * 0.4, CAN, 0, dir, 0), { cyl: true, r: 0.1, r2: 0.26, h: 0.2, x: x + dx * 0.85, y: h - 0.04, z: z + dz * 0.85, color: '#2e3b34', seg: 8 });
      D(box(0.24, 0.3, 0.24, x + dx * 0.85, h - 0.3, z + dz * 0.85, '#ffe3a0'));
      H(stick([x, h - 0.7, z], [x + dx * 0.5, h - 0.04, z + dz * 0.5], 0.025, 0.025, CAN, 4), { sph: true, r: 0.1, x, y: h + 0.1, z, color: CAN, seg: 6 });
      a.lamps.push([x + dx * 0.85, h - 0.3, z + dz * 0.85, 1.4]);
    };
    const bench = (x, z, rot) => {
      const ry = rot ? HP : 0;
      hid(x - (rot ? 0.3 : 0.9), z - (rot ? 0.9 : 0.3), x + (rot ? 0.3 : 0.9), z + (rot ? 0.9 : 0.3), 0.5);
      D(box(1.8, 0.07, 0.45, x, 0.45, z, '#8a5a34', 0, ry, 0), box(1.8, 0.35, 0.05, x - (rot ? 0.22 : 0), 0.72, z - (rot ? 0 : 0.22), '#8a5a34', 0, ry, 0));
      for (const s of [-0.75, 0.75]) D(box(0.07, 0.45, 0.45, x + (rot ? 0 : s), 0.22, z + (rot ? s : 0), IRON, 0, ry, 0));
      for (let k = 0; k < 3; k++) H(box(1.8, 0.012, 0.1, x - (rot ? -0.12 + k * 0.14 : 0), 0.49, z - (rot ? 0 : -0.12 + k * 0.14), '#6e4626', 0, ry, 0));
    };
    const bin = (x, z) => { hid(x - 0.22, z - 0.22, x + 0.22, z + 0.22, 0.75); D({ cyl: true, r: 0.24, r2: 0.18, h: 0.7, x, y: 0.35, z, color: '#4c6b5a', seg: 8 }); H(cyl(0.25, 0.04, x, 0.7, z, '#2f463a', 0, 0, 0, 8)); };

    // ---------- граница: бетонный забор, на путях — тупиковые упоры и сетка ----------
    const FH = 2.6;
    B(-27, -38, 27, -37.7, FH, 'prBrick', 0, SIL); B(-27, 37.7, 27, 38, FH, 'prBrick', 0, SIL);
    for (const [x0, x1] of [[-27, -26.7], [26.7, 27]]) { B(x0, -37.7, x1, -9, FH, 'prBrick', 0, SIL); B(x0, 9, x1, 37.7, FH, 'prBrick', 0, SIL); }
    // столбы забора (высокое) и бетонный слив по верху (2.0: на всех качествах — забор не выглядит плоской стеной)
    for (let x = -24; x <= 24; x += 4) for (const z of [-37.62, 37.62]) H(box(0.4, FH + 0.25, 0.16, x, (FH + 0.25) / 2, z, '#c8c2b6'));
    for (let z = -34; z <= 34; z += 4) if (Math.abs(z) > 9) for (const x of [-26.62, 26.62]) H(box(0.16, FH + 0.25, 0.4, x, (FH + 0.25) / 2, z, '#c8c2b6'));
    for (const z of [-37.85, 37.85]) D(box(54, 0.1, 0.44, 0, FH + 0.05, z, '#bdb7aa'));
    for (const x of [-26.85, 26.85]) for (const [z0, z1] of [[-37.7, -9], [9, 37.7]]) D(box(0.44, 0.1, z1 - z0, x, FH + 0.05, (z0 + z1) / 2, '#bdb7aa'));
    for (const sx of [-1, 1]) {
      const X = sx * 26.4;
      for (let zz = -8.8; zz <= 8.85; zz += 2.2) D(cyl(0.05, 2.4, X, 1.2, zz, '#5c6064', 0, 0, 0, 5));
      D(box(0.03, 2.2, 17.6, X, 1.2, 0, '#7d8186'));
      for (const zc of [-5, 5]) { D(box(0.8, 1.1, 2.6, X - sx * 0.45, 0.55, zc, '#b33a2a'), box(0.82, 0.22, 2.62, X - sx * 0.45, 0.75, zc, WHITE)); }
      hid(Math.min(X - sx * 0.85, X), -9, Math.max(X - sx * 0.85, X), 9, 2.4);
    }

    // ---------- юг: депо, склад шпал, двор налётчиков ----------
    B(-26.7, -37.7, -14, -27, 6.8, 'prBrick');
    roof(-26.7, -37.7, -14, -27, 6.8, 2.4, 0.4, { along: 'x', col: '#6f6a64', gable: '#7c3a26' });
    DC(2, -17.6, 2.8, -27, 3.4, 5.6, '+z'); DC(2, -23.2, 2.8, -27, 3.4, 5.6, '+z');
    DC(15, -14, 3.2, -30.2, 1.8, 3.6, '+x'); DC(15, -14, 3.2, -34.6, 1.8, 3.6, '+x');
    D(box(12.9, 0.26, 0.16, -20.35, 6.5, -26.95, '#7a3424'), box(0.16, 0.26, 10.9, -13.95, 6.5, -32.35, '#7a3424'));
    railsZ(-27, -21.5, -17.6); railsZ(-27, -23, -23.2);
    B(17, -37.7, 26.7, -29, 4.0, 'prBrick');
    D(box(10.0, 0.25, 9.0, 21.85, 4.12, -33.35, '#6a6560'));
    DC(1, 19.6, 1.3, -29, 2.6, 2.6, '+z'); DC(1, 23.4, 1.3, -29, 2.6, 2.6, '+z'); DC(4, 17, 1.5, -33, 2.6, 3.0, '-x');
    // штабель шпал и ящики у спавна
    hid(8.5, -36.4, 12, -34.6, 0.85);
    for (let r = 0; r < 3; r++) for (let i = 0; i < 6 - (r % 2); i++) D(box(3.3, 0.24, 0.26, 10.25, 0.13 + r * 0.26, -36.2 + i * 0.3 + (r % 2) * 0.15, ['#4b3a2c', '#3f3226', '#55412f'][(i + r) % 3]));
    crate(-10.5, -34.2, 1.2); crate(-11.4, -32.2, 0.9); crate(13.2, -27.2, 1.0);
    // гидроколонка у депо
    D(cyl(0.22, 3.2, -12, 1.6, -29.6, '#2f3a40', 0, 0, 0, 8), box(0.16, 0.16, 2.0, -12, 3.1, -28.7, '#2f3a40'), cyl(0.08, 0.6, -12, 2.8, -27.8, '#2f3a40', 0, 0, 0, 6));
    hid(-12.25, -29.85, -11.75, -29.35, 3.2);
    a.stain(2, -30, 3); a.stain(-7, -27.5, 2.4); a.stain(-17.6, -25, 2.6);
    leaves(4, -36.6, 1.6); leaves(-13, -36.8, 1.4);

    // ---------- центр: пакгауз (кирпич), двери юг/север/запад/восток; внутри стеллажи и погрузчик ----------
    const WH = 6.0;
    wallX(-9, 9, -23, -22.5, WH, 'prBrick', [[-6, -3, 3.2]]);
    wallX(-9, 9, -9.5, -9, WH, 'prBrick', [[5, 8, 3.2]]);
    wallZ(-22.5, -9.5, -9, -8.5, WH, 'prBrick', [[-17, -14, 3.2]]);
    wallZ(-22.5, -9.5, 8.5, 9, WH, 'prBrick', [[-21, -18, 3.2]]);
    floor(-8.5, -22.5, 8.5, -9.5, 'prTile');
    // 2.0: ворота пакгауза — стальная рама, направляющая и откатная створка у проёма (снаружи, вровень со стеной)
    for (const [ax, c, s, d0, d1, side] of [[true, -23, -1, -6, -3, -1], [true, -9, 1, 5, 8, -1], [false, -9, -1, -17, -14, -1], [false, 9, 1, -21, -18, 1]]) {
      const fc = '#4a4d50', lf = '#5d6a62', o = c + s * 0.06, m = (d0 + d1) / 2, w = d1 - d0;
      if (ax) {
        D(box(0.14, 3.2, 0.14, d0 - 0.07, 1.6, o, fc), box(0.14, 3.2, 0.14, d1 + 0.07, 1.6, o, fc), box(w + 0.28, 0.16, 0.16, m, 3.28, o, fc));
        D(box(w * 2 + 0.2, 0.1, 0.1, m + side * w * 0.5, 3.45, c + s * 0.1, '#2f3133'), box(w - 0.2, 3.15, 0.07, m + side * w, 1.62, c + s * 0.11, lf));
        for (const y of [0.9, 2.3]) D(box(w - 0.2, 0.08, 0.05, m + side * w, y, c + s * 0.15, '#4a554e'));
        for (let k = 1; k < 7; k++) H(box(0.05, 3.05, 0.03, m + side * w - (w - 0.2) / 2 + k * (w - 0.2) / 7, 1.62, c + s * 0.15, '#4f5b54'));
      } else {
        D(box(0.14, 3.2, 0.14, o, 1.6, d0 - 0.07, fc), box(0.14, 3.2, 0.14, o, 1.6, d1 + 0.07, fc), box(0.16, 0.16, w + 0.28, o, 3.28, m, fc));
        D(box(0.1, 0.1, w * 2 + 0.2, c + s * 0.1, 3.45, m + side * w * 0.5, '#2f3133'), box(0.07, 3.15, w - 0.2, c + s * 0.11, 1.62, m + side * w, lf));
        for (const y of [0.9, 2.3]) D(box(0.05, 0.08, w - 0.2, c + s * 0.15, y, m + side * w, '#4a554e'));
        for (let k = 1; k < 7; k++) H(box(0.03, 3.05, 0.05, c + s * 0.15, 1.62, m + side * w - (w - 0.2) / 2 + k * (w - 0.2) / 7, '#4f5b54'));
      }
    }
    roof(-9, -23, 9, -9, WH, 2.2, 0.45, { along: 'x', col: '#8a8780', gable: '#8a4028' });
    // стеллаж поперёк зала: ломает прострел южная дверь ↔ северная дверь (сплошная задняя стенка)
    const rack = (x0, x1, zc, seed) => {
      const h = 3.6, cx = (x0 + x1) / 2, Lg = x1 - x0;
      hid(x0, zc - 0.6, x1, zc + 0.6, h);
      D(box(Lg, h - 0.1, 0.05, cx, (h - 0.1) / 2, zc, '#6a5440'));
      const nb = Math.round(Lg / 2);
      for (let i = 0; i <= nb; i++) for (const s of [-1, 1]) D(box(0.1, h, 0.1, x0 + Lg * i / nb, h / 2, zc + s * 0.55, '#2f5a8a'));
      for (const y of [0.12, 1.25, 2.4, 3.5]) for (const s of [-1, 1]) D(box(Lg, 0.12, 0.08, cx, y, zc + s * 0.55, '#c86a2a'));
      for (const y of [0.18, 1.31, 2.46]) for (let i = 0; i < nb * 2; i++) {
        const s = (i + seed) % 2 ? 1 : -1, bx = x0 + 0.5 + i * (Lg - 1) / (nb * 2 - 1);
        if (R(0, 1) < 0.18) continue;
        const bw = R(0.6, 0.85), bh = R(0.5, 0.95), v = R(0, 1);
        D(box(bw, bh, R(0.45, 0.5), bx, y + bh / 2, zc + s * 0.3, v < 0.6 ? '#b88a54' : v < 0.85 ? '#a0744a' : '#7a8a6a'));
      }
    };
    rack(-4, 2.5, -16, 0);
    rack(-7.6, -4.6, -12.2, 1);
    // погрузчик
    {
      const x = -0.6, z = -19.4;
      hid(x - 0.75, z - 1.3, x + 0.75, z + 1.0, 2.2);
      D(box(1.3, 0.8, 1.9, x, 0.75, z, '#e0a226'), box(1.3, 0.35, 0.6, x, 1.2, z + 0.65, '#3a3a3a'), box(1.2, 0.12, 1.2, x, 2.2, z - 0.1, '#2a2a2a'));
      for (const s of [-1, 1]) D(box(0.08, 1.4, 0.08, x + s * 0.55, 1.5, z - 0.65, '#2a2a2a'), box(0.08, 1.4, 0.08, x + s * 0.55, 1.5, z + 0.5, '#2a2a2a'));
      D(box(0.12, 2.3, 0.12, x - 0.35, 1.25, z - 1.05, '#3a3a3a'), box(0.12, 2.3, 0.12, x + 0.35, 1.25, z - 1.05, '#3a3a3a'));
      D(box(0.18, 0.06, 1.1, x - 0.3, 0.1, z - 1.65, '#3a3a3a'), box(0.18, 0.06, 1.1, x + 0.3, 0.1, z - 1.65, '#3a3a3a'));
      for (const s of [-1, 1]) for (const w of [-0.6, 0.6]) D(cyl(0.3, 0.22, x + s * 0.62, 0.3, z + w, '#1c1c1c', 0, 0, HP, 10));
      D(box(0.5, 0.5, 0.06, x, 1.3, z - 0.1, '#2a3238'));
      hid(x - 0.65, z - 2.2, x + 0.65, z - 1.1, 0.14);
    }
    crate(4.6, -18.0, 1.3); crate(4.6, -18.0, 0.95, 1.3); crate(5.9, -19.2, 0.9);
    crate(-7.0, -20.8, 1.1); crate(6.8, -11.8, 1.0); crate(3.4, -11.2, 0.8);
    for (const [x, z] of [[3.3, -21.5], [-6.6, -21.6], [6.6, -14.2]]) { hid(x - 0.6, z - 0.5, x + 0.6, z + 0.5, 0.35); D(box(1.2, 0.14, 1.0, x, 0.07, z, '#8a6a46'), box(1.2, 0.14, 1.0, x, 0.21, z, '#7a5c3c')); }
    for (const [x, z] of [[-4.5, -16], [1.5, -16], [5, -12]]) { a.lamps.push([x, 4.7, z, 1.1]); D(cyl(0.3, 0.14, x, 4.85, z, '#2a2c2e', 0, 0, 0, 8), cyl(0.012, 0.9, x, 5.35, z, '#1a1a1a', 0, 0, 0, 3)); }
    // стропильные фермы под крышей (видны в проёмы)
    for (const x of [-5, 0, 5]) H(box(0.14, 0.18, 13.0, x, 5.85, -16, '#4a3a2c'), stick([x, 5.85, -22.4], [x, 7.4, -16], 0.06, 0.06, '#4a3a2c', 4), stick([x, 5.85, -9.6], [x, 7.4, -16], 0.06, 0.06, '#4a3a2c', 4));
    DC(14, -8.5, 2.0, -20.0, 2.6, 4.0, '+x'); DC(14, 8.5, 2.0, -14.0, 2.6, 4.0, '-x'); DC(14, 2.0, 2.0, -9.5, 2.6, 4.0, '-z');
    DC(4, -9, 1.6, -21.2, 2.4, 2.8, '-x'); DC(12, 6.5, 4.15, -9, 1.9, 1.9, '+z', false, 1); DC(12, -4.5, 4.15, -23, 1.9, 1.9, '-z', false, 1);
    DC(12, -9, 1.8, -11.5, 1.6, 1.6, '-x', false, 2);
    for (const x of [-0.5, 3.5, 7]) DC(9, x, 3.9, -23, 1.3, 2.6, '-z');
    for (const x of [-6.5, -3, 0.8]) DC(9, x, 3.9, -9, 1.3, 2.6, '+z');
    for (const z of [-20.8, -11.6]) DC(9, -9, 3.9, z, 1.3, 2.6, '-x');
    for (const z of [-14.5, -11.6]) DC(9, 9, 3.9, z, 1.3, 2.6, '+x');
    for (const [x, z, w, d] of [[0, -23.06, 18.2, 0.14], [0, -8.94, 18.2, 0.14], [-9.06, -16, 0.14, 14.2], [9.06, -16, 0.14, 14.2]]) D(box(w, 0.3, d, x, WH - 0.4, z, '#7a3424'), box(w, 0.12, d, x, WH - 0.9, z, '#7a3424'));
    // погрузочная рампа у северной стены пакгауза — низкая, на неё можно запрыгнуть
    B(-8.5, -9, -3, -8, 0.95, 'prBrick', 0, SIL);
    leaves(-8.2, -7.6, 1.2, 5);

    // ---------- запад: гаражи и проулок (короткий путь) ----------
    B(-26.7, -27, -20, -9.5, 3.0, 'prBrick');
    D(box(6.9, 0.22, 17.7, -23.35, 3.11, -18.25, '#5c5852'));
    for (let k = 0; k < 5; k++) DC(1, -20, 1.3, -25 + k * 3.4, 2.7, 2.5, '+x');
    DC(10, -20, 2.4, -14.9, 1.2, 1.6, '+x');
    // «Жигули» без колёс
    // 2.0: «копейка» — кузов профилем с арками колёс, остеклённый салон, хром, колёса (на капот и крышу можно запрыгнуть)
    {
      const X = -15.5, Z = -18, BODY = '#c9b07a';
      hid(X - 0.86, Z - 2.1, X + 0.86, Z + 2.1, 0.92); hid(X - 0.7, Z - 0.75, X + 0.7, Z + 1.05, 0.5, 0.92);
      const arch = (u0, u1) => [[u0, 0.3], ['q', u0, 0.66, (u0 + u1) / 2, 0.66], ['q', u1, 0.66, u1, 0.3]];
      D({ shape: true, pts: [[-2.04, 0.34], ...arch(-1.66, -0.94), ...arch(0.94, 1.66), [2.04, 0.34], [2.08, 0.58], [2.03, 0.84], [1.0, 0.9], [-1.2, 0.9], [-2.0, 0.86], [-2.08, 0.6]], d: 1.62, bevel: 0.04, bseg: 1, cs: 4, x: X, y: 0, z: Z, color: BODY });
      D({ shape: true, pts: [[-1.05, 0.88], [0.78, 0.88], [0.36, 1.34], [-0.82, 1.36]], d: 1.4, x: X, y: 0, z: Z, color: '#26303a', cs: 1 });
      D(m2Bev(1.42, 0.07, 1.2, X, 1.37, Z + 0.24, BODY, 0.03));
      for (const s of [-1, 1]) D(box(0.06, 0.48, 0.09, X + s * 0.705, 1.12, Z + 0.1, BODY), box(0.06, 0.6, 0.08, X + s * 0.705, 1.12, Z - 0.58, BODY, 0.75, 0, 0), box(0.06, 0.55, 0.08, X + s * 0.705, 1.12, Z + 0.95, BODY, -0.52, 0, 0));
      for (const s of [-1, 1]) D(m2Bev(1.68, 0.1, 0.1, X, 0.46, Z + s * 2.08, '#c8ccd0', 0.03), box(1.64, 0.025, 0.02, X, 0.62, Z + s * 2.06, '#9aa0a6'));
      for (const s of [-1, 1]) for (const k of [0.36, 0.6]) D(cyl(0.085, 0.04, X + s * k, 0.66, Z - 2.065, '#f2ead0', HP, 0, 0, 10));
      D(box(0.62, 0.14, 0.03, X, 0.66, Z - 2.065, '#2a2c2e'));
      for (const s of [-1, 1]) D(box(0.3, 0.12, 0.03, X + s * 0.6, 0.66, Z + 2.07, '#a8201a'));
      for (const s of [-1, 1]) for (const w of [-1.3, 1.3]) D(cyl(0.3, 0.18, X + s * 0.72, 0.28, Z + w, '#1c1c1c', 0, 0, HP, 14), cyl(0.17, 0.2, X + s * 0.72, 0.28, Z + w, '#b8bcc0', 0, 0, HP, 10));
    }
    // мусорные баки
    hid(-12.6, -25.5, -10.4, -24.1, 1.25);
    for (const x of [-12.0, -11.0]) D(box(0.95, 1.1, 1.3, x, 0.55, -24.8, '#3d6a52'), box(1.0, 0.1, 1.36, x, 1.15, -24.8, '#2b4a3a'));
    // северный конец проулка: бетонный забор с воротами у гаражей — из проулка точку не видно
    B(-20, -9.6, -15, -9.2, 2.6, 'prBrick', 0, SIL); B(-12, -9.6, -9, -9.2, 2.6, 'prBrick', 0, SIL);
    for (const x of [-15.05, -11.95]) D(box(0.3, 2.9, 0.4, x, 1.45, -9.4, '#8b8f86'));
    H(box(0.9, 1.9, 0.05, -14.4, 1.0, -8.9, '#3e5b4c', 0, -0.9, 0));
    DC(4, -17.5, 1.4, -9.6, 2.6, 2.8, '-z');
    crate(-17.6, -12.5, 1.0); crate(-11.5, -13, 1.1);
    a.stain(-14, -21, 2.6); leaves(-19.4, -10.4, 1.4);

    // ---------- восток: запасной путь с товарным вагоном (длинный путь) ----------
    railsZ(-28, -9, 17);
    {
      const x0 = 15.5, x1 = 18.5, z0 = -25, z1 = -12, cz = (z0 + z1) / 2, col = RUST, Lg = z1 - z0;
      hid(x0 + 0.3, z0 + 0.3, x1 - 0.3, z1 - 0.3, 1.15);
      B(x0, z0, x1, z1, 2.85, 'prWagon', 1.15, { tint: col });
      D(box(3.14, 0.14, Lg + 0.12, 17, 4.07, cz, shade(col, 0.72)), box(2.7, 0.32, Lg - 0.3, 17, 1.0, cz, DARK), box(2.3, 0.55, Lg - 5.4, 17, 0.62, cz, '#1c1d1f'));
      bogie(17, z0 + 2.0, false); bogie(17, z1 - 2.0, false);
      DC(6, x0, 2.55, cz, 2.4, 2.6, '-x'); DC(6, x1, 2.55, cz, 2.4, 2.6, '+x'); DC(4, x1, 2.4, cz - 4, 2.4, 2.6, '+x');
      DC(10, x0, 3.0, cz + 4, 1.4, 2.4, '-x'); DC(10, x1, 3.0, cz + 3.6, 1.4, 2.4, '+x');
      for (const [xx, s] of [[x0, -1], [x1, 1]]) { D(box(0.1, 0.08, Lg - 0.6, xx + s * 0.06, 3.95, cz, IRON), box(0.1, 0.08, Lg - 0.6, xx + s * 0.06, 1.22, cz, IRON)); rivetsZ(z0 + 0.4, z1 - 0.4, xx + s * 0.07, 3.82, 25); rivetsZ(z0 + 0.4, z1 - 0.4, xx + s * 0.07, 1.32, 25); }
      for (const ez of [z0, z1]) for (const k of [-1, 1]) H(cyl(0.16, 0.36, 17 + k * 0.95, 1.25, ez + (ez < cz ? -0.05 : 0.05), IRON, HP, 0, 0, 8));
    }
    crate(23.6, -17.6, 1.2); crate(24.2, -19.1, 0.9); crate(11.8, -14.6, 1.1); crate(11.6, -24.6, 1.0);
    B(22, -27.6, 25.5, -26.8, 1.0, 'prBrick', 0, SIL);
    // будка релейной на длинном
    B(23.4, -2.6, 26.7, 0.6, 2.6, 'prBrick');
    roof(23.4, -2.6, 26.7, 0.6, 2.6, 0.75, 0.3, { along: 'z', col: '#6f6a64', gable: '#7c3a26' });
    DC(12, 23.4, 1.5, -1, 1.4, 1.4, '-x', false, 2);
    D(box(0.95, 2.05, 0.06, 25.0, 1.03, 0.63, '#3e5b4c'), box(1.1, 0.12, 0.1, 25.0, 2.12, 0.64, '#7c3a26'), box(0.05, 0.05, 0.12, 25.35, 1.05, 0.68, '#c8c2b4'));
    leaves(25.4, -23, 1.6); a.stain(21, -20, 2.4);

    // ---------- пути: балласт, рельсы, вагоны ----------
    floor(-27, -6.6, 27, -3.4, 'prBallast'); floor(-27, 3.4, 27, 6.6, 'prBallast');
    railsX(-27, 27, -5); railsX(-27, 27, 5);
    boxcar(-26, -15.5, -5, RUST2);           // путь 1, запад
    boxcar(12, 22, -5, '#6f7a52');           // путь 1, восток (зелёный)
    tankcar(6, 18, 5);                        // путь 2, восток: цистерна прикрывает край платформы
    boxcar(-12.5, 0.5, 5, '#5b7389');        // путь 2, центр: между вагонами — проходы «центр» (x 0.5..6) и «запад» (x −17..−12.5)
    flatcar(-26, -17, 5);                     // путь 2, запад: лесовоз
    // мотодрезина на пути 1 перед пакгаузом — прикрывает выход из центра
    {
      const X = -4.8, Z = -5;
      hid(X - 2.3, Z - 1.1, X + 2.3, Z + 1.1, 2.5);
      D(box(4.4, 1.5, 2.2, X, 1.55, Z, '#e0a226'), box(2.0, 1.0, 2.0, X + 1.0, 2.8, Z, '#e0a226'), box(4.6, 0.12, 2.4, X, 0.75, Z, DARK), box(1.9, 0.6, 2.05, X + 1.0, 2.85, Z, '#2a3a44'), box(4.5, 0.2, 2.25, X, 1.1, Z, '#c03a2a'));
      for (const s of [-1, 1]) for (const w of [-1.4, 1.4]) D(cyl(0.38, 0.12, X + w, 0.4, Z + s * 0.76, '#3b3632', HP, 0, 0, 10));
      H(box(0.06, 0.06, 2.3, X - 2.25, 1.9, Z, '#2a2a2a'), cyl(0.12, 0.08, X + 2.32, 1.6, Z, '#fff2c0', 0, 0, HP, 8), box(2.2, 0.06, 2.1, X + 1.0, 3.33, Z, '#c08a1e'));
    }
    // между путями: релейный шкаф, штабель шпал (можно запрыгнуть), опоры контактной сети
    hid(-3.2, -1.2, -1.8, 0.2, 1.75); D(box(1.4, 1.7, 1.4, -2.5, 0.85, -0.5, '#9aa29a'), box(1.5, 0.08, 1.5, -2.5, 1.74, -0.5, '#7a827a'), box(0.04, 1.2, 0.9, -1.78, 0.9, -0.5, '#6a726a'));
    hid(-10.6, 0, -7.4, 1.4, 0.85);
    for (let r = 0; r < 3; r++) for (let i = 0; i < 5 - (r % 2); i++) D(box(3.2, 0.24, 0.27, -9.0, 0.13 + r * 0.26, 0.2 + i * 0.29 + (r % 2) * 0.14, ['#4b3a2c', '#3f3226', '#55412f'][(i + r) % 3]));
    // 2.0: штабель бетонных кабельных лотков у западного перехода — укрытие налётчикам на путях (на него можно запрыгнуть)
    hid(-16.2, -0.9, -13.8, 0.3, 1.0);
    for (let r = 0; r < 2; r++) for (let i = 0; i < 3; i++) {
      const z = -0.7 + i * 0.4 + (r ? 0.0 : 0), y = 0.25 + r * 0.5;
      D(m2Bev(2.36, 0.46, 0.38, -15.0, y, z, r ? '#b9b5ab' : '#aaa69c', 0.03), box(2.3, 0.06, 0.24, -15.0, y + 0.21, z, '#7d7a72'));
    }
    D(box(0.12, 0.08, 1.3, -15.6, 1.02, -0.3, '#4a3c30'), box(0.12, 0.08, 1.3, -14.4, 1.02, -0.3, '#4a3c30'));
    // будка поста ЭЦ напротив выхода из пакгауза: ломает прямой прострел дверь ↔ проход «центр»
    B(3, -1.6, 7.4, 1, 2.6, 'prBrick');
    roof(3, -1.6, 7.4, 1, 2.6, 0.85, 0.3, { along: 'x', col: '#6f6a64', gable: '#7c3a26' });
    DC(9, 4.2, 1.7, 1, 0.9, 1.6, '+z'); DC(9, 6.2, 1.7, 1, 0.9, 1.6, '+z'); DC(12, 3, 1.6, -0.3, 1.4, 1.4, '-x', false, 2);
    D(box(0.06, 2.05, 0.95, 7.43, 1.03, -0.3, '#3e5b4c'), box(0.1, 0.12, 1.1, 7.44, 2.12, -0.3, '#7c3a26'), box(0.12, 0.05, 0.05, 7.48, 1.05, 0.05, '#c8c2b4'));
    for (const x of [4.2, 6.2]) D(box(1.05, 0.08, 0.16, x, 0.86, 1.06, '#c8c2b4'), box(1.05, 0.12, 0.1, x, 2.56, 1.04, '#7c3a26'));
    for (const x of [-21, -7, 9.5, 21]) {
      hid(x - 0.17, -0.17, x + 0.17, 0.17, 7.2);
      D(cyl(0.14, 7.2, x, 3.6, 0, '#7f8a84', 0, 0, 0, 6), box(0.1, 0.12, 11.2, x, 6.3, 0, '#5d6662'), box(0.08, 0.08, 11.0, x, 5.7, 0, '#5d6662'));
      for (const s of [-1, 1]) D(box(0.06, 0.4, 0.06, x, 5.9, s * 5, '#4a5250'), cyl(0.07, 0.22, x, 6.45, s * 2.6, '#d9d2c0', 0, 0, 0, 6));
      H(cyl(0.22, 0.3, x, 0.15, 0, '#6a706c', 0, 0, 0, 8));
    }
    for (const zc of [-5, 5]) { D(box(54, 0.025, 0.025, 0, 5.55, zc, '#2a2a2a'), box(54, 0.025, 0.025, 0, 6.3, zc, '#2a2a2a')); }
    // светофор у западного прохода
    D(cyl(0.08, 4.2, -17.6, 2.1, 7.4, '#3a3d40', 0, 0, 0, 6), box(0.5, 1.3, 0.3, -17.6, 4.0, 7.4, '#1d1f21'));
    H(cyl(0.12, 0.06, -17.6, 4.35, 7.24, '#c8302a', HP, 0, 0, 8), cyl(0.12, 0.06, -17.6, 3.95, 7.24, '#2a3a2a', HP, 0, 0, 8));
    a.lamps.push([-17.6, 4.35, 7.2, 0.5, '#ff4a30']);
    hid(-17.8, 7.2, -17.4, 7.6, 4.2);
    leaves(-24, 1.2, 1.4); a.stain(14, 0, 3); a.stain(-14, -1, 2.4);

    // ---------- точка A: платформа с навесом ----------
    floor(-14, 7.4, 16, 22.4, 'prTile');
    // 2.0: кромка платформы — бетонные плиты со швами, белая полоса по краю, жёлтая линия безопасности
    for (let i = 0; i < 20; i++) D(box(1.47, 0.05, 0.62, -13.25 + i * 1.5, 0.025, 7.71, i % 2 ? '#c9c4b8' : '#bfbaae'));
    D(box(30, 0.056, 0.1, 1, 0.028, 7.44, '#f2efe6'), box(30, 0.012, 0.22, 1, 0.027, 8.2, '#e8c22a'));
    // билетный автомат у восточного края — ломает прострел вдоль кромки из коридора длинного
    // 2.0: терминал — корпус со скруглённым верхом, экран, клавиатура, лоток (столкновение — прежняя коробка)
    {
      const X = 10.7, Z = 9.4, Y0 = '#e2b41c';
      hid(10.2, 9.0, 11.2, 9.8, 2.1);
      D(m2Bev(1.04, 0.14, 0.84, X, 0.07, Z, '#2a2c2e', 0.03), m2Bev(0.96, 1.62, 0.76, X, 0.92, Z, Y0, 0.05), cyl(0.38, 0.96, X, 1.72, Z, Y0, 0, 0, HP, 16));
      D(box(0.8, 1.06, 0.03, X, 1.15, 9.015, '#c99e14'), box(0.5, 0.36, 0.03, X, 1.5, 9.0, '#16324e'), box(0.28, 0.2, 0.04, X - 0.12, 1.12, 8.998, '#34373a'), box(0.14, 0.035, 0.04, X + 0.2, 1.16, 8.995, '#111'));
      D(box(0.4, 0.12, 0.1, X, 0.7, 8.99, '#26282b'), box(0.98, 0.14, 0.78, X, 1.62, Z, '#1d4f8a'), box(0.02, 1.3, 0.12, 10.21, 1.0, Z - 0.2, '#c8302a'), box(0.02, 1.3, 0.12, 11.19, 1.0, Z - 0.2, '#c8302a'));
      a.lamps.push([X, 1.5, 8.94, 0.32, '#5ab8ff']);
    }
    // навес на четырёх колоннах: капители, кронштейны, балки, подвесные фонари
    for (const x of [-9, -3, 3, 9]) {
      hid(x - 0.2, 14.8, x + 0.2, 15.2, 4.0);
      D(cyl(0.15, 4.0, x, 2.0, 15, CAN, 0, 0, 0, 8), cyl(0.28, 0.35, x, 0.17, 15, '#2f463a', 0, 0, 0, 8), box(0.42, 0.18, 0.42, x, 3.86, 15, '#2f463a'), box(0.14, 0.24, 6.0, x, 3.98, 15, CAN));
      for (const s of [-1, 1]) D(stick([x, 3.0, 15], [x, 3.92, 15 + s * 2.0], 0.05, 0.05, CAN, 4));
      for (const s of [-1, 1]) H(stick([x, 3.45, 15], [x, 3.92, 15 + s * 1.0], 0.03, 0.03, CAN, 4), { torus: true, r: 0.22, tube: 0.025, x, y: 3.55, z: 15 + s * 0.55, ry: HP, color: CAN, seg: 10 });
      H(box(0.32, 0.06, 0.32, x, 0.37, 15, '#2a3a32'), box(0.3, 0.12, 0.3, x, 3.72, 15, '#2a3a32'));
    }
    a.roofs.push({ X0: -12, X1: 12, Z0: 12.2, Z1: 17.8, y: 4.05, h: 0.55, ov: 0.5, hip: false, col: '#4e7f66', alongX: true });
    D(box(24.4, 0.12, 0.14, 0, 4.0, 12.25, CAN), box(24.4, 0.12, 0.14, 0, 4.0, 17.75, CAN), box(24, 0.1, 0.1, 0, 4.08, 15, CAN));
    H(box(25, 0.14, 0.14, 0, 3.98, 11.72, '#3a4a42'), box(25, 0.14, 0.14, 0, 3.98, 18.28, '#3a4a42'));
    for (const x of [-12, 12]) H(cyl(0.05, 4.0, x + Math.sign(x) * 0.5, 2.0, 11.72, '#3a4a42', 0, 0, 0, 5));
    for (let x = -11; x <= 11; x += 1.1) H(box(0.04, 0.14, 0.5, x, 3.85, 12.0, '#e0d8c4'), box(0.04, 0.14, 0.5, x, 3.85, 18.0, '#e0d8c4'));
    for (const x of [-6, 0, 6]) { a.lamps.push([x, 3.3, 15, 1.2]); D({ cyl: true, r: 0.08, r2: 0.3, h: 0.24, x, y: 3.5, z: 15, color: '#2e3b34', seg: 8 }, { sph: true, r: 0.13, x, y: 3.36, z: 15, color: '#fff0c8', seg: 6 }, cyl(0.012, 0.42, x, 3.82, 15, '#1a1a1a', 0, 0, 0, 3)); }
    // вывеска «ПЕРРОН» под навесом, табло отправления, номер пути
    DC(7, -1.5, 3.25, 15.08, 2.4, 4.8, '+z', true); DC(7, -1.5, 3.25, 14.92, 2.4, 4.8, '-z', true);
    D(box(2.5, 0.65, 0.12, -1.5, 3.25, 15, '#1d4f8a'), cyl(0.01, 0.4, -2.5, 3.75, 15, '#1a1a1a', 0, 0, 0, 3), cyl(0.01, 0.4, -0.5, 3.75, 15, '#1a1a1a', 0, 0, 0, 3));
    DC(13, 6, 3.1, 15.07, 1.5, 1.5, '+z', true, 1); DC(13, 6, 3.1, 14.93, 1.5, 1.5, '-z', true, 1);
    D(box(1.5, 0.85, 0.12, 6, 3.12, 15, '#121518'));
    DC(13, -9, 2.4, 14.8, 0.9, 0.9, '-z', false, 2); DC(13, 9, 2.4, 14.8, 0.9, 0.9, '-z', false, 2);
    // багажная тележка с чемоданами (запрыгнуть)
    {
      const X = 2.6, Z = 10.6;
      hid(X - 1.3, Z - 0.7, X + 1.3, Z + 0.7, 1.0);
      D(box(2.6, 0.12, 1.4, X, 0.62, Z, '#5d6a72'), box(2.6, 0.5, 0.05, X, 0.9, Z - 0.68, '#5d6a72'), box(2.6, 0.5, 0.05, X, 0.9, Z + 0.68, '#5d6a72'));
      for (const s of [-1, 1]) for (const w of [-0.9, 0.9]) D(cyl(0.2, 0.08, X + w, 0.2, Z + s * 0.62, '#202224', HP, 0, 0, 8));
      D(box(0.9, 0.42, 0.6, X - 0.6, 0.9, Z - 0.1, '#7a3a2a'), box(0.7, 0.36, 0.5, X + 0.3, 0.87, Z + 0.1, '#2f4f6a'), box(0.6, 0.3, 0.45, X + 0.8, 0.84, Z - 0.3, '#6a5a3a'), box(0.5, 0.5, 0.4, X + 0.1, 1.29, Z, '#8a6a3a'));
      H(box(0.06, 0.06, 1.2, X - 1.45, 1.0, Z, '#3a3a3a'));
    }
    // почтовые ящики (запрыгнуть) и штабель с подступом
    crate(-5.6, 11.4, 1.0); crate(-6.8, 11.9, 0.8);
    crate(7.6, 13.0, 1.3); crate(7.65, 12.95, 0.9, 1.3); crate(9.1, 13.9, 0.9);
    // информационный щит с расписанием (сплошной) — укрытие на точке
    B(4.4, 17.6, 6.8, 18.2, 2.3, 'plaster', 0, { tint: '#1d4f8a', ch: 1 });
    DC(3, 5.6, 1.35, 17.6, 1.4, 2.8, '-z'); DC(3, 5.6, 1.35, 18.2, 1.4, 2.8, '+z');
    // касса у короткого входа
    B(-11.2, 17.6, -8.2, 20.8, 2.7, 'plaster', 0, { tint: '#9cc6e4', ch: 1 });
    D(box(3.4, 0.2, 3.6, -9.7, 2.8, 19.2, BLUE), box(1.4, 0.8, 0.05, -9.7, 1.5, 17.58, '#2a3a44'), box(1.6, 0.08, 0.3, -9.7, 1.08, 17.45, '#c8c2b4'));
    DC(11, -9.7, 2.25, 17.6, 1.3, 1.3, '-z', false, 1);
    // клумба с берёзой и скамейки
    B(-3.6, 18.4, -1.0, 20.6, 0.55, 'prBrick', 0, SIL);
    D(box(2.4, 0.06, 2.0, -2.3, 0.56, 19.5, '#4a3a2a'));
    for (let i = 0; i < 7; i++) D({ sph: true, r: 0.26, x: -3.2 + (i % 4) * 0.6, y: 0.66, z: 18.9 + Math.floor(i / 4) * 1.1, sy: 0.6, color: ['#c8402a', '#e8a030', '#9a3a6a'][i % 3], seg: 6 });
    birch(-2.3, 19.5, 7.5, false); hid(-2.5, 19.3, -2.1, 19.7, 7);
    bench(-6, 15.7); bench(0.6, 18.2); bin(-9.6, 13.6); bin(9.6, 16.2);
    lampPost(-12.6, 8.4, 4.6, 0); lampPost(13.4, 8.4, 4.6, 0);
    // восточный край платформы: стенд-указатель
    hid(14.2, 12.0, 14.8, 12.8, 2.2); D(box(0.5, 2.0, 0.6, 14.5, 1.0, 12.4, '#1d4f8a'), box(0.52, 1.4, 0.62, 14.5, 1.3, 12.4, '#f2f0ea'));
    DC(11, 14.2, 1.3, 12.4, 0.6, 0.6, '-x', false, 2);
    a.letter('A', 0, 12.4, 4.2);
    leaves(12.4, 21.2, 1.2, 5); leaves(-12.8, 21.4, 1.2, 5); leaves(-7.4, 9.0, 0.9, 4); leaves(6.6, 20.6, 1.0, 4);

    // ---------- запад от точки: стена короткого, водокачка, сквер ----------
    // 2.0: стена 2,75 м — с ящика у стены на неё больше не запрыгнуть (раньше 2,4 — «пиксельная» точка над точкой)
    B(-14.6, 9, -14, 16, 2.75, 'prBrick'); B(-14.6, 19, -14, 23, 2.75, 'prBrick');
    D(box(0.75, 0.12, 7.1, -14.3, 2.81, 12.5, '#7c3a26'), box(0.75, 0.12, 4.1, -14.3, 2.81, 21, '#7c3a26'));
    B(-14.7, 15.4, -13.9, 16.0, 3.05, 'prBrick'); B(-14.7, 19.0, -13.9, 19.6, 3.05, 'prBrick');
    for (const z of [15.7, 19.3]) D(box(0.96, 0.14, 0.76, -14.3, 3.12, z, '#7c3a26'), { sph: true, r: 0.16, x: -14.3, y: 3.33, z, color: '#d6d1c6', seg: 6 });
    // водокачка: кирпичная башня, клёпаный бак, лестница
    {
      const X = -21.4, Z = 13.4;
      B(-24.2, 10.6, -18.6, 16.2, 8.0, 'prBrick');
      D(cyl(3.5, 3.4, X, 9.75, Z, '#5e7466', 0, 0, 0, 16), cyl(3.62, 0.22, X, 8.1, Z, '#3e4c44', 0, 0, 0, 16), { cyl: true, r: 0.2, r2: 3.85, h: 1.9, x: X, y: 12.4, z: Z, color: '#4f6658', seg: 16 }, cyl(0.35, 0.5, X, 13.5, Z, '#3e4c44', 0, 0, 0, 8));
      for (let k = 0; k < 12; k++) { const an = k * 0.5236; H(box(0.12, 3.2, 0.05, X + Math.cos(an) * 3.52, 9.75, Z + Math.sin(an) * 3.52, '#4b5f53', 0, -an, 0)); }
      for (const y of [8.6, 10.9]) H({ torus: true, r: 3.53, tube: 0.05, x: X, y, z: Z, rx: HP, color: '#3e4c44', seg: 24 });
      DC(10, -18.6, 6.4, Z - 1.2, 1.4, 2.6, '+x'); DC(10, -18.6, 6.6, Z + 1.6, 1.2, 2.2, '+x');
      DC(15, -18.6, 4.4, Z, 1.6, 3.2, '+x'); DC(15, -21.4, 4.4, 16.2, 1.6, 3.2, '+z'); DC(15, -21.4, 4.4, 10.6, 1.6, 3.2, '-z');
      DC(2, -18.6, 1.6, Z, 1.6, 3.0, '+x');
      D(box(5.8, 0.2, 5.8, X, 7.9, Z, '#7a3424'), box(5.7, 0.16, 0.12, X, 1.0, 16.26, '#8b8f86'));
      for (let k = 0; k < 18; k++) H(box(0.5, 0.04, 0.04, -18.4, 0.5 + k * 0.45, Z + 2.2, '#2a2a2a'));
      H(box(0.04, 8.2, 0.04, -18.4, 4.1, Z + 1.95, '#2a2a2a'), box(0.04, 8.2, 0.04, -18.4, 4.1, Z + 2.45, '#2a2a2a'));
    }
    crate(-16.4, 9.8, 1.1); crate(-25.6, 18.4, 1.0);
    bench(-17.6, 21.6); birch(-25.2, 20.8, 8.5); birch(-16.4, 14.2, 8);
    // невысокая оградка сквера (перепрыгнуть) с калиткой
    hid(-26.7, 23.1, -21.5, 23.35, 0.95); hid(-19.5, 23.1, -16.5, 23.35, 0.95);
    for (const [x0, x1] of [[-26.7, -21.5], [-19.5, -16.5]]) { D(box(x1 - x0, 0.08, 0.08, (x0 + x1) / 2, 0.9, 23.22, '#2f463a'), box(x1 - x0, 0.06, 0.06, (x0 + x1) / 2, 0.45, 23.22, '#2f463a')); for (let k = 0, nk = Math.max(1, Math.round((x1 - x0) / 2.4)); k <= nk; k++) D(box(0.07, 0.94, 0.07, x0 + 0.04 + k * (x1 - x0 - 0.08) / nk, 0.47, 23.22, '#2f463a')); for (let x = x0 + 0.1; x < x1; x += 0.5) H(box(0.04, 0.9, 0.04, x, 0.45, 23.22, '#2f463a')); }
    leaves(-22.4, 8.2, 1.5); leaves(-15.4, 22.4, 1.0, 4);

    // ---------- восток от точки: багажное отделение и коридор длинного ----------
    B(16, 10, 26.7, 21, 4.4, 'plaster', 0, { tint: '#e9d4a6', ch: 1 });
    roof(16, 10, 26.7, 21, 4.4, 1.6, 0.5, { hip: true, col: '#7b5a48' });
    DC(8, 18.4, 2.3, 10, 1.4, 2.8, '-z'); DC(0, 21.6, 2.3, 10, 1.4, 2.8, '-z'); DC(3, 24.8, 1.6, 10, 1.4, 2.8, '-z'); DC(0, 16, 2.3, 15, 1.4, 2.8, '-x'); DC(2, 16, 1.6, 18.6, 1.6, 2.9, '-x');
    DC(0, 18, 2.3, 21, 1.4, 2.8, '+z'); DC(0, 22.4, 2.3, 21, 1.4, 2.8, '+z'); DC(10, 16, 3.0, 12.2, 1.0, 1.8, '-x');
    for (const [x, z, w, d] of [[21.35, 9.94, 10.9, 0.14], [21.35, 21.06, 10.9, 0.14], [15.94, 15.5, 0.14, 11.2]]) D(box(w, 0.24, d, x, 4.25, z, WHITE), box(w, 0.4, d, x, 0.2, z, '#8b8f86'));
    crate(25.6, 8.4, 1.0); crate(14.2, 22.2, 1.0);
    // почтовая тележка в коридоре длинного
    hid(21.2, 7.0, 23.4, 8.2, 1.1); D(box(2.2, 0.8, 1.2, 22.3, 0.7, 7.6, '#3a5a7a'), box(2.2, 0.1, 1.25, 22.3, 1.12, 7.6, '#2a3a4a'));
    for (const s of [-1, 1]) D(cyl(0.18, 0.08, 22.3 + s * 0.8, 0.18, 7.0, '#202224', HP, 0, 0, 8), cyl(0.18, 0.08, 22.3 + s * 0.8, 0.18, 8.2, '#202224', HP, 0, 0, 8));

    // ---------- вокзал (мятный, белые пилястры), зал ожидания внутри ----------
    const SZ0 = 23, SZ1 = 31, WW = 5.2, WC = 7.4, ST = { tint: MINT, ch: 1 };
    // южный фасад: две двери на платформу; центральная часть выше
    wallX(-16.5, -7, SZ0, SZ0 + 0.5, WW, 'plaster', [[-13, -11, 2.8]], ST);
    wallX(-7, 2, SZ0, SZ0 + 0.5, WC, 'plaster', [[-1, 2, 3.4]], ST);
    wallX(2, 10.5, SZ0, SZ0 + 0.5, WW, 'plaster', [], ST);
    // северный фасад: главный вход с площади
    wallX(-16.5, -7, SZ1 - 0.5, SZ1, WW, 'plaster', [], ST);
    wallX(-7, 2, SZ1 - 0.5, SZ1, WC, 'plaster', [[-5, -2, 3.4]], ST);
    wallX(2, 10.5, SZ1 - 0.5, SZ1, WW, 'plaster', [], ST);
    wallZ(SZ0 + 0.5, SZ1 - 0.5, -16.5, -16, WW, 'plaster', [], ST);
    wallZ(SZ0 + 0.5, SZ1 - 0.5, 10, 10.5, WW, 'plaster', [[26, 28, 2.8]], ST);
    // фронтонные стены центральной части над крыльями
    for (const x of [-7, 1.5]) B(x, SZ0 + 0.5, x + 0.5, SZ1 - 0.5, WC - WW, 'plaster', WW, ST);
    floor(-16, SZ0 + 0.5, 10, SZ1 - 0.5, 'prTile');
    roof(-16.8, SZ0 - 0.3, -6.7, SZ1 + 0.3, WW, 2.0, 0.4, { hip: true });
    roof(1.7, SZ0 - 0.3, 10.8, SZ1 + 0.3, WW, 2.0, 0.4, { hip: true });
    roof(-7.3, SZ0 - 0.3, 2.3, SZ1 + 0.3, WC, 2.6, 0.5, { hip: true });
    // карниз (двойной), цоколь и пилястры
    for (const [x0, x1, top] of [[-16.5, -7, WW], [-7, 2, WC], [2, 10.5, WW]]) for (const zf of [SZ0 - 0.06, SZ1 + 0.06]) {
      const zs = zf < 27 ? -1 : 1;
      D(box(x1 - x0 + 0.2, 0.22, 0.16, (x0 + x1) / 2, top - 0.15, zf, WHITE), box(x1 - x0 + 0.2, 0.1, 0.1, (x0 + x1) / 2, top - 0.42, zf, WHITE));
      H(box(x1 - x0 + 0.3, 0.08, 0.26, (x0 + x1) / 2, top - 0.02, zf + zs * 0.05, WHITE));
      for (let k = 0; k <= Math.round((x1 - x0) / 2.6); k++) { const px = x0 + (x1 - x0) * k / Math.round((x1 - x0) / 2.6); D(box(0.42, top - 0.6, 0.1, px, (top - 0.6) / 2 + 0.55, zf, WHITE)); H(box(0.56, 0.14, 0.16, px, top - 0.58, zf + zs * 0.02, WHITE)); }
      for (let px = x0 + 0.4; px < x1 - 0.2; px += 0.55) H(box(0.16, 0.12, 0.14, px, top - 0.3, zf + zs * 0.05, WHITE));
    }
    for (const zf of [SZ0 - 0.05, SZ1 + 0.05]) for (const [x0, x1] of zf < 27 ? [[-16.5, -13], [-11, -1], [2, 10.5]] : [[-16.5, -5], [-2, 10.5]]) D(box(x1 - x0, 0.55, 0.1, (x0 + x1) / 2, 0.27, zf, '#8b8f86'));
    for (const xf of [-16.56, 10.56]) D(box(0.16, 0.22, SZ1 - SZ0 + 0.2, xf, WW - 0.15, (SZ0 + SZ1) / 2, WHITE), box(0.1, 0.55, SZ1 - SZ0, xf, 0.27, (SZ0 + SZ1) / 2, '#8b8f86'));
    // окна: снаружи — с залом за стеклом (тёплый свет), изнутри — простые; подоконники и сандрики
    const win = (x, z, n, inner) => {
      DC(8, x, 2.4, z, 1.6, 3.2, n); if (inner) DC(0, x, 2.4, inner, 1.5, 3.0, n === '-z' ? '+z' : n === '+z' ? '-z' : n === '-x' ? '+x' : '-x');
      const s = n === '-z' || n === '-x' ? -1 : 1, ax = n === '-z' || n === '+z';
      H(box(ax ? 1.7 : 0.2, 0.08, ax ? 0.2 : 1.7, ax ? x : x + s * 0.1, 0.86, ax ? z + s * 0.1 : z, WHITE), box(ax ? 1.8 : 0.16, 0.1, ax ? 0.16 : 1.8, ax ? x : x + s * 0.08, 4.0, ax ? z + s * 0.08 : z, WHITE));
    };
    for (const x of [-9.4, -5, 5, 8.4]) win(x, SZ0, '-z', SZ0 + 0.5);
    for (const x of [-14.2, -11, -9.2]) win(x, SZ1, '+z', SZ1 - 0.5);
    for (const x of [0.4, 4.6, 8.0]) win(x, SZ1, '+z', SZ1 - 0.5);
    win(-16.5, 27, '-x', -16); win(10.5, 24.6, '+x', 10); win(10.5, 29.6, '+x', 10);
    DC(5, 0.5, 5.8, SZ1, 1.4, 2.8, '+z', true); DC(5, 0.5, 5.8, SZ0, 1.4, 2.8, '-z', true);
    DC(7, -3.5, 5.25, SZ1, 3.8, 7.6, '+z', true); DC(7, -4.5, 5.0, SZ0, 3.2, 6.4, '-z', true);
    DC(11, 0.5, 4.05, SZ0, 1.5, 1.5, '-z', false, 2); DC(11, -12, 3.4, SZ0, 1.3, 1.3, '-z', false, 1);
    DC(3, 3.6, 1.9, SZ0, 1.2, 2.4, '-z'); DC(4, -15.3, 1.5, SZ0, 2.0, 2.4, '-z');
    // внутри: стенд расписания в центре зала (не даёт прострела вход ↔ платформа), колонны, кассы, скамьи, люстры
    B(-4.0, 26.4, 0.8, 27.2, 2.4, 'plaster', 0, { tint: '#2a4a6a', ch: 1 });
    DC(13, -1.6, 1.75, 26.4, 1.8, 1.8, '-z', true, 1); DC(13, -1.6, 1.75, 27.2, 1.8, 1.8, '+z', true, 1);
    DC(3, -3.3, 1.2, 26.4, 0.9, 1.8, '-z'); DC(3, 0.1, 1.2, 27.2, 0.9, 1.8, '+z');
    for (const x of [-9.8, 6.2]) B(x - 0.4, 26.6, x + 0.4, 27.4, WW, 'plaster', 0, { tint: WHITE, ch: 1 });
    B(-16, 24.4, -14.8, 30, 1.1, 'plaster', 0, { tint: '#d8cbb0' });
    D(box(1.25, 0.06, 5.7, -15.4, 1.12, 27.2, '#7a5434'), box(0.05, 1.4, 5.6, -14.95, 1.9, 27.2, '#2a3a44'));
    for (const z of [25.4, 27.2, 29.0]) { D(box(0.06, 0.32, 1.2, -14.9, 2.7, z, '#1d4f8a')); H(box(0.4, 0.3, 0.4, -15.4, 1.3, z, '#3a3a3a')); }
    DC(11, -16, 3.5, 27.2, 1.4, 1.4, '+x', false, 1);
    bench(5.8, 24.6); bench(5.8, 29.4); bench(-10.4, 29.4); bench(-10.4, 24.6); bench(-6.4, 25.0); bin(-7.2, 30.1); bin(8.6, 27.0);
    for (const [x, y] of [[-11, 4.5], [-2, 6.3], [5.5, 4.5]]) { a.lamps.push([x, y, 27, 1.2]); D({ sph: true, r: 0.34, x, y, z: 27, color: '#fff6dc', seg: 8 }, cyl(0.012, 0.6, x, y + 0.45, 27, '#1a1a1a', 0, 0, 0, 3)); H({ torus: true, r: 0.5, tube: 0.03, x, y: y + 0.05, z: 27, rx: HP, color: '#b8902a', seg: 14 }); }
    // 2.0: зал — потолок с карнизом (не видно изнанки кровли), деревянные панели по низу стен
    D(box(9.0, 0.1, 7.0, -11.5, WW - 0.05, 27, '#f1ebdf'), box(8.0, 0.1, 7.0, 6.0, WW - 0.05, 27, '#f1ebdf'), box(8.5, 0.1, 7.0, -2.5, WC - 0.05, 27, '#f1ebdf'));
    for (const [x0, x1, y] of [[-16, -7, WW], [2, 10, WW], [-6.5, 1.5, WC]]) for (const zf of [23.56, 30.44]) D(box(x1 - x0, 0.16, 0.12, (x0 + x1) / 2, y - 0.18, zf, '#ddd4c2'));
    {
      const wains = (alongX, c, s, t0, t1, gaps) => {
        let segs = [[t0, t1]];
        for (const g of gaps) { const o = []; for (const [p0, p1] of segs) { if (g[1] <= p0 || g[0] >= p1) o.push([p0, p1]); else { if (g[0] > p0) o.push([p0, g[0]]); if (g[1] < p1) o.push([g[1], p1]); } } segs = o; }
        for (const [p0, p1] of segs) {
          const L = p1 - p0, m = (p0 + p1) / 2; if (L < 0.3) continue;
          D(alongX ? box(L, 0.95, 0.04, m, 0.475, c + s * 0.02, '#6a4a32') : box(0.04, 0.95, L, c + s * 0.02, 0.475, m, '#6a4a32'));
          D(alongX ? box(L, 0.07, 0.07, m, 0.98, c + s * 0.035, '#4a3222') : box(0.07, 0.07, L, c + s * 0.035, 0.98, m, '#4a3222'));
        }
      };
      wains(true, SZ0 + 0.5, 1, -14.8, 10, [[-13.1, -10.9], [-1.1, 2.1]]); wains(true, SZ1 - 0.5, -1, -14.8, 10, [[-5.1, -1.9]]);
      wains(false, 10, -1, SZ0 + 0.5, SZ1 - 0.5, [[25.9, 28.1]]);
    }
    // крыльцо и козырёк главного входа
    D(box(4.6, 0.12, 1.5, -3.5, 3.8, SZ1 + 0.75, WHITE), box(4.0, 0.1, 1.3, -3.5, 3.7, SZ1 + 0.7, ROOF));
    for (const s of [-1, 1]) D(cyl(0.1, 3.7, -3.5 + s * 2.1, 1.85, SZ1 + 1.3, WHITE, 0, 0, 0, 8));
    hid(-5.7, 32.2, -5.5, 32.4, 3.7); hid(-1.5, 32.2, -1.3, 32.4, 3.7);
    D(box(4.0, 0.12, 0.8, -3.5, 0.06, SZ1 + 0.4, '#a8a49a'));
    leaves(-8.6, 32.0, 1.0, 4); leaves(9.4, 32.4, 1.2, 5);

    // ---------- север: привокзальная площадь, памятник-паровоз ----------
    // клумба на площади — низкая
    B(-13, 34.2, -9, 35.6, 0.5, 'prBrick', 0, SIL);
    for (let i = 0; i < 6; i++) D({ sph: true, r: 0.32, x: -12.6 + i * 0.66, y: 0.6, z: 34.9, sy: 0.6, color: ['#c8402a', '#e8a030', '#f2d050'][i % 3], seg: 6 });
    // киоск «Печать»
    B(6.6, 33.4, 9.6, 35.8, 2.6, 'plaster', 0, { tint: '#8fb7e0', ch: 1 });
    D(box(3.2, 0.22, 2.7, 8.1, 2.71, 34.6, BLUE), box(2.0, 1.0, 0.05, 8.1, 1.55, 33.38, '#2a3a44'));
    H(box(2.2, 0.08, 0.3, 8.1, 1.0, 33.25, '#c8c2b4'));
    // остановка
    hid(-24.6, 35.6, -19.4, 36.3, 2.6);
    D(box(5.2, 0.1, 1.8, -22, 2.6, 35.6, '#4e7f66'), box(5.0, 1.8, 0.05, -22, 1.4, 36.25, '#9cc0d0'));
    for (const x of [-24.4, -19.6]) D(cyl(0.06, 2.6, x, 1.3, 36.1, CAN, 0, 0, 0, 6), cyl(0.06, 2.6, x, 1.3, 35.0, CAN, 0, 0, 0, 6));
    bench(-22, 35.9);
    // памятник-паровоз на постаменте
    {
      const X0 = 14, Zc = 34.6;
      B(13, 32.4, 26.4, 36.8, 0.7, 'prBrick', 0, SIL);
      hid(13.6, 32.9, 25.8, 36.3, 4.6, 0.7);
      const Y = 0.7, BLK = '#1f2124', RED = '#b3291f', BRASS = '#c8a040';
      D(cyl(0.95, 6.4, X0 + 4.6, Y + 2.25, Zc, BLK, 0, 0, HP, 14), cyl(1.0, 0.9, X0 + 1.5, Y + 2.25, Zc, '#2a2c2f', 0, 0, HP, 14));
      D({ shape: true, pts: [[0, 0.62], [0.16, 0.2], [0.6, 0.2], [0.24, -0.08], [0.38, -0.52], [0, -0.26], [-0.38, -0.52], [-0.24, -0.08], [-0.6, 0.2], [-0.16, 0.2]], d: 0.06, x: X0 + 1.02, y: Y + 2.25, z: Zc, color: RED, ry: 0, cs: 1 });
      D(cyl(0.3, 1.1, X0 + 1.6, Y + 3.6, Zc, BLK, 0, 0, 0, 10), cyl(0.38, 0.22, X0 + 1.6, Y + 4.2, Zc, BLK, 0, 0, 0, 10), { sph: true, r: 0.45, x: X0 + 4.2, y: Y + 3.15, z: Zc, sy: 0.9, color: BLK, seg: 10 }, { sph: true, r: 0.36, x: X0 + 6.0, y: Y + 3.1, z: Zc, sy: 0.9, color: BLK, seg: 10 });
      D(box(2.6, 2.6, 3.0, X0 + 8.9, Y + 2.6, Zc, BLK), box(2.9, 0.2, 3.3, X0 + 8.9, Y + 4.0, Zc, '#2a2c2f'));
      for (const s of [-1, 1]) D(box(1.2, 0.9, 0.05, X0 + 8.9, Y + 3.0, Zc + s * 1.52, '#3d5566'), box(7.2, 0.08, 0.5, X0 + 4.4, Y + 1.25, Zc + s * 1.25, '#2a2c2f'), box(7.6, 0.3, 0.06, X0 + 4.4, Y + 1.05, Zc + s * 1.48, RED));
      for (const s of [-1, 1]) for (const wx of [X0 + 2.9, X0 + 4.6, X0 + 6.3]) D(cyl(0.78, 0.12, wx, Y + 0.8, Zc + s * 1.15, RED, HP, 0, 0, 14), cyl(0.18, 0.16, wx, Y + 0.8, Zc + s * 1.2, '#d8d2c4', HP, 0, 0, 8));
      for (const s of [-1, 1]) D(box(3.6, 0.1, 0.08, X0 + 4.6, Y + 0.8, Zc + s * 1.24, '#c8c2b4'));
      // спицы колёс, дефлекторы, свисток, фонарь, поручни (высокое)
      for (const s of [-1, 1]) for (const wx of [X0 + 2.9, X0 + 4.6, X0 + 6.3]) for (let k = 0; k < 4; k++) H(box(1.4, 0.06, 0.03, wx, Y + 0.8, Zc + s * 1.23, RED, 0, 0, k * Math.PI / 4));
      for (const s of [-1, 1]) H(box(1.6, 1.4, 0.04, X0 + 1.4, Y + 2.4, Zc + s * 1.1, BLK), box(5.8, 0.04, 0.04, X0 + 4.6, Y + 2.9, Zc + s * 1.0, BRASS));
      H(cyl(0.06, 0.4, X0 + 5.2, Y + 3.5, Zc, BRASS, 0, 0, 0, 6), cyl(0.18, 0.26, X0 + 0.9, Y + 3.2, Zc, BLK, 0, 0, HP, 8), cyl(0.13, 0.04, X0 + 0.76, Y + 3.2, Zc, '#fff2c0', 0, 0, HP, 8));
      for (const s of [-1, 1]) H(box(0.9, 0.08, 0.06, X0 + 4.6, Y + 0.95, Zc + s * 1.32, '#c8c2b4', 0, 0, 0.35));
      D(box(0.3, 0.55, 2.9, X0 + 0.75, Y + 0.95, Zc, RED), { shape: true, pts: [[0, 0], [0.9, 0], [0, 0.7]], d: 2.2, x: X0 + 0.6, y: Y + 0.25, z: Zc, color: '#2a2c2f', ry: HP, cs: 1 });
      D(box(1.8, 0.7, 2.6, X0 + 6.8, Y + 0.9, Zc, '#2a2c2f'));
      for (const s of [-1, 1]) a.lamps.push([X0 + 0.8, Y + 1.8, Zc + s * 0.6, 0.45]);
      a.lamps.push([X0 + 0.7, Y + 3.2, Zc, 0.6]);
      DC(12, 13, 0.4, Zc, 0.7, 0.7, '-x', false, 1);
    }
    birch(12.2, 37.0, 8.8); birch(-11.4, 37.0, 8.2); birch(-25.2, 30.4, 9); birch(-19.6, 28.2, 7.6); birch(25.0, 25.6, 8.6);
    for (const [x, z] of [[-14.4, 33.8], [11.8, 30.0]]) lampPost(x, z, 4.8, x < 0 ? HP : -HP);
    bin(-8.4, 32.4); bin(5.4, 32.4); bench(-23.2, 26.8, true);
    crate(12.4, 28.4, 1.1);
    birch(-24.5, -24.5, 7.6); birch(24.6, -26.2, 8.2); birch(-24.0, 1.0, 8.4, true);
    birch(14.4, -28.6, 7.2);
    leaves(-2.4, 37.0, 1.4, 5); leaves(20, 31.6, 1.4, 5);

    // ---------- пейзаж за забором (только высокое качество) ----------
    // пятиэтажки
    for (const [cx, cz, w, d, rot] of [[-60, 20, 12, 36, 0], [64, -10, 12, 40, 0], [-6, 74, 44, 12, 1], [40, 72, 26, 12, 1], [-44, -72, 30, 12, 1]]) {
      const hh = 15;
      H(box(w, hh, d, cx, hh / 2, cz, '#d8d2c4'));
      const fx = rot ? 0 : (cx > 0 ? -w / 2 - 0.03 : w / 2 + 0.03), fz = rot ? (cz > 0 ? -d / 2 - 0.03 : d / 2 + 0.03) : 0;
      for (let f = 0; f < 5; f++) H(box(rot ? w - 1 : 0.06, 1.1, rot ? 0.06 : d - 1, cx + fx, 2.1 + f * 2.8, cz + fz, f === 2 ? '#c8a060' : '#4a5866'));
      H(box(w + 0.4, 0.5, d + 0.4, cx, hh + 0.25, cz, '#8b8680'));
    }
    // лес: берёзы и ели по кругу
    for (let i = 0; i < 30; i++) {
      const an = i / 30 * 6.283 + 0.1, rr = R(34, 46), x = Math.cos(an) * rr * 0.9, z = Math.sin(an) * rr * 1.12;
      if (Math.abs(z) < 12 && Math.abs(x) > 22) continue;
      if (i % 3) birch(x, z, R(9, 12), false, true); else pine(x, z);
    }
    // пути уходят за край карты
    for (const zc of [-5, 5]) for (const sx of [-1, 1]) {
      H(box(40, 0.02, 3.2, sx * 47, 0.01, zc, '#6e6860'));
      for (const s of [-1, 1]) H(box(40, 0.15, 0.09, sx * 47, 0.1, zc + s * 0.76, '#7d7a76'));
    }
    // водонапорная башня-силуэт, элеватор и ЛЭП вдали
    H(cyl(1.6, 16, 58, 8, 30, '#9a4a32', 0, 0, 0, 10), cyl(4.2, 4, 58, 17, 30, '#5e7466', 0, 0, 0, 12));
    H(box(10, 22, 8, -58, 11, -20, '#c8b89a'), box(4, 28, 4, -52, 14, -20, '#b8a88a'));
    for (const [x, z] of [[-66, -34], [-66, 12], [-64, 56]]) { H({ cyl: true, r: 0.3, r2: 2.4, h: 22, x, y: 11, z, color: '#6d7276', seg: 4 }, box(9, 0.4, 0.4, x, 19, z, '#6d7276')); }
  }

  // ===================== «Лагуна»: венецианский квартал на закате (2.0, рейтинг 2 на 2) =====================
  // 52×69 м, одна точка A — кампо у церкви. Вода — плоскость лагуны под всей картой (env.water, y = −0.9),
  // суша — плиты мостовой; каналы — просветы между набережными: непроходимы (невидимая стена), но простреливаются (nr).
  // Спецназ — север (рива у лагуны, портик палаццо), налётчики — юг (кампо у стеклодувной мастерской).
  // Маршруты: запад — калле → мост Овест → корте → сотопортего или угол у воды; восток — фондамента вдоль рио
  // с портиком → мост Эст; связка — мастерская «Форнаце» (двери на запад и восток, выход к воде напротив кампо).
  // Мосты пологие (настил 0.24 м — шаг вверх, а навигация ботов считает его полом); всё проходимое — на уровне земли.
  const LG_WL = -0.9;
  function layoutLagoon(a) {
    // материалы карты — регистрируются здесь, чтобы не трогать общую таблицу
    if (!MAT_FACTORY.lgPave) Object.assign(MAT_FACTORY, {
      lgPave: () => lam('lgPave', null, 1.0), lgPlaster: () => lam('lgPlaster', null, 0.45),
      lgBrick: () => lam('lgBrick', null, 1.3), lgIstria: () => lam('lgIstria', null, 0.7)
    });
    const box = G.geo.box, cyl = G.geo.cyl, B = a.B, WL = LG_WL;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const LO = (...p) => { for (const q of p) a.lo.push(q); };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 9157; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    const pick = (arr) => arr[Math.floor(R(0, arr.length - 0.001))];
    const hid = (x0, z0, x1, z1, h, y0) => B(x0, z0, x1, z1, h, 'none', y0 || 0, { hidden: true });
    // наклейка из атласа 4×4 (клетка 128×256); part: 1 — верхняя половина клетки, 2 — нижняя
    const DC = (cell, x, y, z, w, h, n, lit, part) => {
      const u0 = (cell % 4) * 0.25, v1 = 1 - Math.floor(cell / 4) * 0.25;
      let va = v1 - 0.25, vb = v1;
      if (part === 1) va = v1 - 0.125; else if (part === 2) vb = v1 - 0.125;
      a.decals.push({ cell, x, y, z, w, h, n, atlas: 'lgAtlas', lit: !!lit, uv: [u0 + 0.002, va + 0.001, u0 + 0.248, vb - 0.001] });
    };
    // стенка над водой (кирпич, полоса прилива, тина): лицом к воде n, вдоль грани от a0 до a1, c — координата грани
    const quayWall = (n, a0, a1, c, top) => {
      const ax = n === '+z' || n === '-z', len = a1 - a0, t = top == null ? -0.2 : top, h = t + 1.5;
      a.decals.push({ x: ax ? (a0 + a1) / 2 : c, y: t - h / 2, z: ax ? c : (a0 + a1) / 2, w: len, h, n, atlas: 'lgQuay', uv: [a0 / 1.7, 0, a1 / 1.7, 1] });
    };
    // кромка набережной из истрийского камня (верх — на уровне мостовой) и стенка под ней
    const coping = (n, a0, a1, c) => {
      const s = n === '+z' || n === '+x' ? 1 : -1, ax = n === '+z' || n === '-z';
      if (ax) B(a0, Math.min(c, c - s * 0.32), a1, Math.max(c, c - s * 0.32), 0.2, 'lgIstria', -0.2, { solid: false });
      else B(Math.min(c, c - s * 0.32), a0, Math.max(c, c - s * 0.32), a1, 0.2, 'lgIstria', -0.2, { solid: false });
      quayWall(n, a0, a1, c);
    };
    const pave = (x0, z0, x1, z1) => B(x0, z0, x1, z1, 0.02, 'lgPave', -0.02, { solid: false });
    // цоколь дома, встающего прямо из воды: мокрая кладка + полоса истрийского камня
    const wetBase = (n, a0, a1, c) => {
      quayWall(n, a0, a1, c, 0.15);
      const ax = n === '+z' || n === '-z', s = n === '+z' || n === '+x' ? 1 : -1;
      D(box(ax ? a1 - a0 : 0.1, 0.22, ax ? 0.1 : a1 - a0, ax ? (a0 + a1) / 2 : c + s * 0.05, 0.26, ax ? c + s * 0.05 : (a0 + a1) / 2, '#e2dccf'));
    };
    const IST = '#ece6d9', IST2 = '#d9d2c3', IRON = '#26292b', BRONZE = '#5a4a2e', GOLD = '#d4aa4c', WOOD = '#6a4a30', DKWOOD = '#3e2a1c';
    const TERRA = '#a8553a', GRN = '#2e5a3e';
    const PAL = ['#e2ad68', '#de967f', '#c46a50', '#efdcbc', '#e9c47c', '#e6a07c', '#c98c5c', '#e4b0a2', '#d9b98c'];
    const isX = (n) => n === '+x' || n === '-x';
    const sgn = (n) => (n === '+z' || n === '+x' ? 1 : -1);
    // точка на грани: n — сторона, c — координата грани, t — вдоль грани, off — наружу
    const at = (n, c, t, off) => isX(n) ? [c + sgn(n) * (off || 0), t] : [t, c + sgn(n) * (off || 0)];

    // ---------- детали фасада ----------
    // подоконник, цветочный ящик, балкон
    const sill = (n, c, t, y, w) => { const p = at(n, c, t, 0.1); H(box(isX(n) ? 0.2 : w, 0.08, isX(n) ? w : 0.2, p[0], y, p[1], IST)); };
    const flowers = (n, c, t, y, w) => {
      const p = at(n, c, t, 0.2);
      H(box(isX(n) ? 0.26 : w, 0.2, isX(n) ? w : 0.26, p[0], y + 0.1, p[1], '#8a4a2e'));
      const cols = ['#d8323a', '#e85a7a', '#f2f0ea', '#d8323a', '#c8306a'];
      for (let i = 0; i < 6; i++) { const tt = t - w / 2 + 0.12 + i * (w - 0.24) / 5, q = at(n, c, tt, 0.2 + R(-0.04, 0.04)); H({ sph: true, r: R(0.12, 0.17), x: q[0], y: y + 0.28 + R(0, 0.08), z: q[1], color: i % 2 ? '#4f7a3a' : cols[(i + Math.floor(t)) % 5], seg: 5, sy: 0.8 }); }
      for (let i = 0; i < 3; i++) { const tt = t - w / 2 + 0.25 + i * (w - 0.5) / 2, q = at(n, c, tt, 0.33); H({ sph: true, r: 0.1, x: q[0], y: y + 0.1, z: q[1], color: '#5f8a42', seg: 5, sy: 1.6 }); }
    };
    const balcony = (n, c, t, y, w) => {
      const dp = 0.6, p = at(n, c, t, dp / 2), pr = at(n, c, t, dp - 0.04), ax = !isX(n);
      D(box(ax ? w : dp, 0.14, ax ? dp : w, p[0], y, p[1], IST)); H(box(ax ? w + 0.06 : 0.07, 0.07, ax ? 0.07 : w + 0.06, pr[0], y + 0.95, pr[1], IST));
      for (const s of [-1, 1]) { const q = at(n, c, t + s * (w / 2 - 0.04), dp / 2); H(box(ax ? 0.07 : dp, 0.07, ax ? dp : 0.07, q[0], y + 0.95, q[1], IST)); }
      // балясины (высокое) или сплошной парапет (низкое и среднее)
      const nb = Math.round(w / 0.2);
      for (let i = 0; i <= nb; i++) { const q = at(n, c, t - w / 2 + 0.06 + i * (w - 0.12) / nb, dp - 0.04); H({ cyl: true, r: 0.035, r2: 0.05, h: 0.82, x: q[0], y: y + 0.48, z: q[1], color: IST2, seg: 5 }); }
      for (const s of [-1, 1]) for (let i = 1; i < 3; i++) { const q = at(n, c, t + s * (w / 2 - 0.04), i * dp / 3); H({ cyl: true, r: 0.035, r2: 0.05, h: 0.82, x: q[0], y: y + 0.48, z: q[1], color: IST2, seg: 5 }); }
      LO(box(ax ? w : 0.05, 0.9, ax ? 0.05 : w, pr[0], y + 0.52, pr[1], IST2));
      // консоли под плитой
      for (const s of [-1, 1]) { const q = at(n, c, t + s * (w / 2 - 0.25), 0.25); H(box(ax ? 0.14 : 0.42, 0.3, ax ? 0.42 : 0.14, q[0], y - 0.2, q[1], IST2)); }
    };
    // настенный фонарь на кронштейне
    const wallLamp = (n, c, t, y) => {
      const p = at(n, c, t, 0.32), b = at(n, c, t, 0.16);
      D(box(isX(n) ? 0.34 : 0.05, 0.05, isX(n) ? 0.05 : 0.34, b[0], y + 0.42, b[1], IRON), cyl(0.15, 0.36, p[0], y + 0.05, p[1], '#ffe2a6', 0, 0, 0, 6),
        { cyl: true, r: 0.03, r2: 0.2, h: 0.2, x: p[0], y: y + 0.33, z: p[1], color: IRON, seg: 6 }, cyl(0.1, 0.06, p[0], y - 0.16, p[1], IRON, 0, 0, 0, 6));
      a.lamps.push([p[0], y + 0.05, p[1], 0.9]);
    };
    // ряд окон по этажам: n — сторона, c — координата грани, a0..a1 — участок, y0 — низ первого окна, floors, gap — шаг
    const windows = (n, c, a0, a1, y0, floors, o) => {
      o = o || {};
      const gap = o.gap || 2.7, cnt = Math.max(1, Math.floor((a1 - a0) / gap)), st = (a1 - a0) / cnt;
      for (let f = 0; f < floors; f++) {
        const y = y0 + f * (o.fh || 3.0), noble = f === (o.noble == null ? 0 : o.noble);
        for (let i = 0; i < cnt; i++) {
          const t = a0 + st * (i + 0.5);
          if (o.skip && o.skip.some(([s0, s1]) => t > s0 - 0.8 && t < s1 + 0.8)) continue;
          const k = noble && o.gothic ? (R(0, 1) < 0.5 ? 0 : 6) : pick(o.kinds || [1, 1, 2, 7, 1, 2]);
          const w = k === 6 ? 1.5 : k === 7 ? 1.15 : 1.1, h = k === 7 ? 2.5 : 2.2;
          DC(k, isX(n) ? c : t, y + h / 2, isX(n) ? t : c, w, h, n);
          if (k !== 7) sill(n, c, t, y + 0.02, w + 0.2);
          if (k === 7 || (noble && R(0, 1) < (o.balc || 0.35))) balcony(n, c, t, y - 0.02, w + 0.5);
          else if (R(0, 1) < (o.fl || 0.3)) flowers(n, c, t, y + 0.06, w);
        }
      }
    };
    // карниз под кровлей и межэтажный пояс по сторонам faces
    const cornice = (x0, z0, x1, z1, y, faces, col) => {
      for (const n of faces) {
        const ax = !isX(n), c = n === '+z' ? z1 : n === '-z' ? z0 : n === '+x' ? x1 : x0, len = ax ? x1 - x0 : z1 - z0, mid = ax ? (x0 + x1) / 2 : (z0 + z1) / 2, s = sgn(n);
        D(box(ax ? len + 0.36 : 0.32, 0.2, ax ? 0.32 : len + 0.36, ax ? mid : c + s * 0.12, y - 0.1, ax ? c + s * 0.12 : mid, col || IST));
        H(box(ax ? len + 0.2 : 0.18, 0.14, ax ? 0.18 : len + 0.2, ax ? mid : c + s * 0.06, y - 0.27, ax ? c + s * 0.06 : mid, col || IST2));
        // модульоны под карнизом (высокое)
        const m = Math.floor(len / 0.9);
        for (let i = 0; i < m; i++) { const t = (ax ? x0 : z0) + 0.3 + i * (len - 0.6) / Math.max(1, m - 1); const p = at(n, c, t, 0.17); H(box(ax ? 0.1 : 0.26, 0.12, ax ? 0.26 : 0.1, p[0], y - 0.4, p[1], IST2)); }
      }
    };
    const band = (x0, z0, x1, z1, y, faces, col) => {
      for (const n of faces) {
        const ax = !isX(n), c = n === '+z' ? z1 : n === '-z' ? z0 : n === '+x' ? x1 : x0, len = ax ? x1 - x0 : z1 - z0, mid = ax ? (x0 + x1) / 2 : (z0 + z1) / 2, s = sgn(n);
        H(box(ax ? len + 0.08 : 0.1, 0.12, ax ? 0.1 : len + 0.08, ax ? mid : c + s * 0.04, y, ax ? c + s * 0.04 : mid, col || IST));
      }
    };
    // венецианская труба-воронка
    const chimney = (x, z, y) => {
      D(box(0.5, 1.5, 0.5, x, y + 0.75, z, '#a8553a'), { cyl: true, r: 0.46, r2: 0.2, h: 0.75, x, y: y + 1.85, z, color: '#b8654a', seg: 8 });
      H(cyl(0.5, 0.1, x, y + 2.25, z, '#7a3a26', 0, 0, 0, 8), box(0.56, 0.08, 0.56, x, y + 1.1, z, '#d8d0c0'));
    };
    // вальмовая крыша из коппо + коньки
    const roof = (x0, z0, x1, z1, y, rise, ov, o) => {
      o = o || {};
      const r = { X0: x0, X1: x1, Z0: z0, Z1: z1, y, h: rise, ov, hip: o.hip !== false, col: o.col || '#ffffff', alongX: o.along ? o.along === 'x' : (x1 - x0) >= (z1 - z0) };
      a.roofs.push(r);
      const g = roofFrame(r), ax = r.alongX, P = (aa, cc, yy) => ax ? [aa, yy, cc] : [cc, yy, aa], rc = '#8a4630';
      if (g.ra1 - g.ra0 > 0.05) { const p = P((g.ra0 + g.ra1) / 2, g.cc, g.top + 0.05); D({ cyl: true, r: 0.13, h: g.ra1 - g.ra0 + 0.2, x: p[0], y: p[1], z: p[2], color: rc, seg: 6, rx: ax ? 0 : HP, rz: ax ? HP : 0 }); }
      if (r.hip) for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const cc of [g.C0, g.C1]) H(stick(P(aa, cc, g.ey + 0.04), P(ra, g.cc, g.top + 0.05), 0.11, 0.11, rc, 5));
      else for (const aa of [g.a0w + 0.05, g.a1w - 0.05]) { const p = P(aa, g.cc, y); D({ shape: true, pts: [[-g.hw0, 0], [0, rise], [g.hw0, 0]], d: 0.1, x: p[0], y, z: p[2], color: o.gable || '#d9a87c', ry: ax ? 0 : HP, cs: 1 }); }
      // стропила под свесом (высокое)
      for (const cc of [g.C0, g.C1]) { const n0 = Math.floor((g.A1 - g.A0) / 1.1); for (let i = 1; i < n0; i++) { const aa = g.A0 + i * (g.A1 - g.A0) / n0, p = P(aa, (cc + g.cc) / 2 * 0 + (cc > g.cc ? cc - ov / 2 : cc + ov / 2), g.ey + 0.05 - 0.1); H(box(ax ? 0.08 : ov, 0.1, ax ? ov : 0.08, p[0], p[1], p[2], '#4a3020')); } }
    };
    // дом: штукатурка с оттенком, цоколь, карниз, крыша, трубы, окна на сторонах win
    const house = (x0, z0, x1, z1, h, col, o) => {
      o = o || {};
      B(x0, z0, x1, z1, h - (o.y0 || 0), 'lgPlaster', o.y0 || 0, { tint: col });
      const faces = o.faces || ['+x', '-x', '+z', '-z'];
      cornice(x0, z0, x1, z1, h, faces);
      if (o.band !== false) band(x0, z0, x1, z1, o.band || 4.0, faces);
      if (o.roof !== false) {
        const rise = Math.min(2.2, Math.min(x1 - x0, z1 - z0) * 0.24);
        roof(x0 - 0.05, z0 - 0.05, x1 + 0.05, z1 + 0.05, h + 0.02, rise, 0.55, { col: o.rcol || pick(['#ffffff', '#f2e2d6', '#e8d8cc']) });
        const nc = Math.max(1, Math.round((x1 - x0) * (z1 - z0) / 70));
        for (let i = 0; i < nc; i++) chimney(R(x0 + 0.8, x1 - 0.8), R(z0 + 0.8, z1 - 0.8), h + rise * 0.35);
      }
      for (const [n, a0, a1, fl, opt] of o.win || []) windows(n, n === '+z' ? z1 : n === '-z' ? z0 : n === '+x' ? x1 : x0, a0, a1, o.wy || 4.5, fl, opt);
    };
    // колонна истрийского камня (база, ствол, капитель); solid — с коллизией
    const column = (x, z, h, r, solid) => {
      r = r || 0.25;
      H({ torus: true, r: r * 1.05, tube: r * 0.2, x, y: 0.26, z, rx: HP, color: IST, seg: 12 });
      D(box(r * 2.5, 0.22, r * 2.5, x, 0.11, z, IST2),
        { cyl: true, r: r * 0.9, r2: r, h: h - 0.62, x, y: 0.22 + (h - 0.62) / 2, z, color: IST, seg: 12 },
        { cyl: true, r: r * 1.5, r2: r * 0.95, h: 0.24, x, y: h - 0.28, z, color: IST, seg: 12 }, box(r * 3.1, 0.16, r * 3.1, x, h - 0.08, z, IST2));
      H({ torus: true, r: r * 0.95, tube: r * 0.12, x, y: h - 0.42, z, rx: HP, color: IST2, seg: 12 });
      if (solid !== false) hid(x - r * 1.1, z - r * 1.1, x + r * 1.1, z + r * 1.1, h);
    };
    // аркада: сплошная стенка над арками от xa до xb (вдоль X), низ арок — пята spring, верх — top; bays — число пролётов
    // аркада: на высоком — 12 сегментов на арку, на низком/среднем — 5
    const arcadeX = (xa, xb, z, spring, top, bays, pier, d, col, rise) => { for (const NS of [12, 5]) arcX(xa, xb, z, spring, top, bays, pier, d, col, rise, NS); };
    const arcadeZ = (za, zb, x, spring, top, bays, pier, d, col, rise) => { for (const NS of [12, 5]) arcZ(za, zb, x, spring, top, bays, pier, d, col, rise, NS); };
    const arcX = (xa, xb, z, spring, top, bays, pier, d, col, rise, NS) => {
      const bw = (xb - xa) / bays, rr = (bw - pier) / 2, ri = rise || rr, pts = [[xa, top - spring]];
      pts.push([xa, 0]);
      for (let i = 0; i < bays; i++) {
        const l = xa + i * bw + pier / 2, rgt = l + rr * 2, m = l + rr;
        pts.push([l, 0]);
        for (let k = 1; k < NS; k++) { const an = Math.PI - k * Math.PI / NS; pts.push([m + Math.cos(an) * rr, Math.sin(an) * ri]); }
        pts.push([rgt, 0]);
      }
      pts.push([xb, 0], [xb, top - spring]);
      // ry = −π/2: x профиля → мировая X, выдавливание → Z
      (NS > 6 ? H : LO)({ shape: true, pts: pts.map(p => [p[0] - (xa + xb) / 2, p[1]]), d, x: (xa + xb) / 2, y: spring, z, color: col || IST, ry: -HP, cs: 1 });
    };
    const arcZ = (za, zb, x, spring, top, bays, pier, d, col, rise, NS) => {
      const bw = (zb - za) / bays, rr = (bw - pier) / 2, ri = rise || rr, pts = [[za, top - spring], [za, 0]];
      for (let i = 0; i < bays; i++) {
        const l = za + i * bw + pier / 2, m = l + rr;
        pts.push([l, 0]);
        for (let k = 1; k < NS; k++) { const an = Math.PI - k * Math.PI / NS; pts.push([m + Math.cos(an) * rr, Math.sin(an) * ri]); }
        pts.push([l + rr * 2, 0]);
      }
      pts.push([zb, 0], [zb, top - spring]);
      // ry = π: x профиля → мировая Z
      (NS > 6 ? H : LO)({ shape: true, pts: pts.map(p => [p[0] - (za + zb) / 2, p[1]]), d, x, y: spring, z: (za + zb) / 2, color: col || IST, ry: Math.PI, cs: 1 });
    };
    // арка в проёме a0..a1 под потолком top (на грани c, по оси ax): пята не ниже 2.2 м — голова проходит
    const archX = (a0, a1, c, top, d) => { const rr = (a1 - a0 + 0.4 - 0.2) / 2, ri = Math.min(rr, top - 0.14 - 2.2); arcadeX(a0 - 0.2, a1 + 0.2, c, top - 0.14 - ri, top, 1, 0.2, d || 0.14, IST, ri); };
    const archZ = (a0, a1, c, top, d) => { const rr = (a1 - a0 + 0.4 - 0.2) / 2, ri = Math.min(rr, top - 0.14 - 2.2); arcadeZ(a0 - 0.2, a1 + 0.2, c, top - 0.14 - ri, top, 1, 0.2, d || 0.14, IST, ri); };
    // фонарь на чугунном столбе
    const lampPost = (x, z, h) => {
      h = h || 3.4;
      hid(x - 0.16, z - 0.16, x + 0.16, z + 0.16, h);
      D(cyl(0.17, 0.5, x, 0.25, z, IRON, 0, 0, 0, 8), cyl(0.065, h - 0.5, x, (h + 0.5) / 2 - 0.1, z, IRON, 0, 0, 0, 6), cyl(0.12, 0.08, x, h - 0.32, z, IRON, 0, 0, 0, 8),
        cyl(0.2, 0.5, x, h, z, '#ffe2a6', 0, 0, 0, 6), { cyl: true, r: 0.04, r2: 0.27, h: 0.28, x, y: h + 0.39, z, color: IRON, seg: 6 }, cyl(0.12, 0.06, x, h - 0.27, z, IRON, 0, 0, 0, 6));
      H({ sph: true, r: 0.06, x, y: h + 0.58, z, color: IRON, seg: 5 }, { torus: true, r: 0.13, tube: 0.02, x, y: 0.62, z, rx: HP, color: IRON, seg: 8 });
      a.lamps.push([x, h, z, 1.3]);
    };
    // полосатая свая-палина в воде
    const palina = (x, z, h, c1, c2, cap) => {
      h = h || 3.2;
      const yb = WL - 0.4, yt = h - 0.4, bh = (yt - 0.1 - (WL + 0.5)) / 6;
      D(cyl(0.13, yt - yb, x, (yt + yb) / 2, z, '#3f3a30', 0, 0, 0, 6));
      LO(cyl(0.14, yt - 0.1 - (WL + 0.5), x, (yt - 0.1 + WL + 0.5) / 2, z, c1, 0, 0, 0, 6));
      for (let k = 0; k < 6; k++) H(cyl(0.142, bh * 0.92, x, WL + 0.5 + (k + 0.5) * bh, z, k % 2 ? c2 : c1, 0, 0, 0, 8));
      D({ sph: true, r: 0.17, x, y: yt + 0.12, z, sy: 1.3, color: cap || GOLD, seg: 6 });
    };
    // гондола: борта-полумесяцы, дно, сиденья, нос-«ферро»; dir — угол носа (0 — к +X), cover — синий чехол
    const gondola = (x, z, dir, cover) => {
      const c = Math.cos(dir), s = Math.sin(dir), P = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c], ry = dir;
      const y0 = WL - 0.12;
      const prof = [[-5.3, 0.86], ['q', -3.2, 0.42, 0, 0.45], ['q', 3.6, 0.47, 5.35, 1.22], [5.2, 1.08], ['q', 4.4, 0.02, 2.4, 0.0], [-2.4, 0.0], ['q', -4.6, 0.04, -5.3, 0.86]];
      for (const sz of [-0.6, 0.6]) { const p = P(0, sz); H({ shape: true, pts: prof, d: 0.07, x: p[0], y: y0, z: p[1], color: '#141414', ry: ry - HP, cs: 4 }); LO({ shape: true, pts: prof, d: 0.07, x: p[0], y: y0, z: p[1], color: '#141414', ry: ry - HP, cs: 2 }); }
      const pf = P(0, 0); D(box(8.2, 0.06, 1.16, pf[0], y0 + 0.2, pf[1], '#2a1c14', 0, ry, 0));
      for (const [lx, w] of [[4.4, 1.6], [-4.3, 1.5]]) { const p = P(lx, 0); D(box(w, 0.06, 1.2, p[0], y0 + 0.55 + (lx > 0 ? 0.12 : 0.06), p[1], '#141414', 0, ry, lx > 0 ? -0.12 : 0.1)); }
      if (cover) { const p = P(-0.2, 0); D(box(6.4, 0.18, 1.24, p[0], y0 + 0.5, p[1], '#2c4e8a', 0, ry, 0)); H(box(6.2, 0.04, 1.27, p[0], y0 + 0.42, p[1], '#1e3a6a', 0, ry, 0)); }
      else {
        for (const lx of [-1.2, 1.6]) { const p = P(lx, 0); D(box(0.7, 0.24, 1.12, p[0], y0 + 0.36, p[1], '#7a1e24', 0, ry, 0)); }
        const p = P(0.2, 0); H(box(1.4, 0.03, 1.0, p[0], y0 + 0.3, p[1], '#a02a2a', 0, ry, 0));
      }
      // ферро на носу и форкола на корме
      const pn = P(5.42, 0); D({ shape: true, pts: [[0, 0], [0.16, 0.0], [0.24, 0.62], [0.1, 0.78], [-0.02, 0.6]], d: 0.04, x: pn[0], y: y0 + 1.0, z: pn[1], color: '#d8dade', ry: ry - HP, cs: 1 });
      for (let k = 0; k < 6; k++) { const p = P(5.56, 0); H(box(0.18, 0.035, 0.03, p[0], y0 + 1.08 + k * 0.085, p[1], '#d8dade', 0, ry, 0)); }
      const pk = P(-3.9, 0.5); H(box(0.08, 0.7, 0.08, pk[0], y0 + 0.85, pk[1], '#5a3a22', 0, ry, 0.2));
    };
    // ящик с грузом (запрыгнуть)
    const crate = (x, z, s, y0) => B(x - s / 2, z - s / 2, x + s / 2, z + s / 2, s, 'crate', y0 || 0, { uv: 'face' });
    const barrel = (x, z) => {
      hid(x - 0.32, z - 0.32, x + 0.32, z + 0.32, 0.98);
      D({ cyl: true, r: 0.3, r2: 0.3, h: 0.96, x, y: 0.48, z, color: '#7a5434', seg: 10 }, cyl(0.315, 0.05, x, 0.18, z, IRON, 0, 0, 0, 10), cyl(0.315, 0.05, x, 0.78, z, IRON, 0, 0, 0, 10));
      H(cyl(0.27, 0.02, x, 0.97, z, '#5a3a22', 0, 0, 0, 10));
    };
    // каменная лавка
    const bench = (x, z, rot) => {
      const ry = rot ? HP : 0;
      hid(x - (rot ? 0.28 : 0.9), z - (rot ? 0.9 : 0.28), x + (rot ? 0.28 : 0.9), z + (rot ? 0.9 : 0.28), 0.48);
      D(box(1.8, 0.1, 0.5, x, 0.44, z, IST, 0, ry, 0));
      for (const s of [-0.7, 0.7]) D(box(0.16, 0.4, 0.4, x + (rot ? 0 : s), 0.2, z + (rot ? s : 0), IST2, 0, ry, 0));
    };
    // столик кафе с двумя-тремя стульями
    const table = (x, z, n) => {
      hid(x - 0.75, z - 0.75, x + 0.75, z + 0.75, 0.8);
      D(cyl(0.42, 0.04, x, 0.75, z, '#f0ece2', 0, 0, 0, 12), cyl(0.04, 0.72, x, 0.37, z, IRON, 0, 0, 0, 5), cyl(0.24, 0.03, x, 0.02, z, IRON, 0, 0, 0, 8));
      for (let i = 0; i < (n || 3); i++) {
        const an = i * 6.283 / (n || 3) + 0.6, cx = x + Math.cos(an) * 0.62, cz = z + Math.sin(an) * 0.62, ry = -an + HP;
        D(box(0.42, 0.05, 0.42, cx, 0.46, cz, '#7a5a3a', 0, ry, 0), box(0.42, 0.42, 0.05, cx + Math.cos(an) * 0.2, 0.68, cz + Math.sin(an) * 0.2, '#7a5a3a', 0, ry, 0));
        for (const [u, v] of [[-0.17, -0.17], [0.17, -0.17], [-0.17, 0.17], [0.17, 0.17]]) H(box(0.03, 0.44, 0.03, cx + u, 0.22, cz + v, IRON));
      }
    };
    // квадратный зонт кафе
    const parasol = (x, z, col) => {
      hid(x - 0.08, z - 0.08, x + 0.08, z + 0.08, 2.4);
      D(cyl(0.04, 2.5, x, 1.25, z, '#d8d2c4', 0, 0, 0, 5), { cyl: true, r: 0.06, r2: 1.75, h: 0.55, x, y: 2.62, z, color: '#efe6d2', seg: 4, ry: Math.PI / 4, open: true },
        { cyl: true, r: 0.06, r2: 1.75, h: 0.55, x, y: 2.6, z, color: '#bfb6a0', seg: 4, ry: Math.PI / 4 }, cyl(0.24, 0.1, x, 0.05, z, '#4a4a46', 0, 0, 0, 8));
      for (const [dx, dz, w, d] of [[0, 1.24, 2.5, 0.03], [0, -1.24, 2.5, 0.03], [1.24, 0, 0.03, 2.5], [-1.24, 0, 0.03, 2.5]]) D(box(w, 0.2, d, x + dx, 2.27, z + dz, col || '#b8392c'));
    };
    // ящик с цветами/кустами вдоль террасы (укрытие по пояс)
    const planter = (x, z, len, alongX) => {
      const w = alongX ? len : 0.62, d = alongX ? 0.62 : len;
      hid(x - w / 2, z - d / 2, x + w / 2, z + d / 2, 0.95);
      D(box(w, 0.6, d, x, 0.3, z, '#5a3e2a'), box(w + 0.06, 0.06, d + 0.06, x, 0.6, z, '#3e2a1c'));
      const n = Math.max(2, Math.round(len / 0.5));
      for (let i = 0; i < n; i++) { const t = -len / 2 + 0.25 + i * (len - 0.5) / (n - 1); L({ sph: true, r: 0.36, x: x + (alongX ? t : 0), y: 0.74, z: z + (alongX ? 0 : t), sy: 0.75, color: i % 3 === 1 ? '#c8486a' : '#4f7a36', seg: 7 }); }
    };
    // дерево (крона — листва, оттенок вершинами)
    const tree = (x, z, h, k) => {
      k = k || 1;
      hid(x - 0.25, z - 0.25, x + 0.25, z + 0.25, 3);
      D(stick([x, 0, z], [x + 0.2, h * 0.55, z - 0.1], 0.24 * k, 0.17 * k, '#6a5a48', 7));
      for (let i = 0; i < 4; i++) { const an = i * 1.57 + R(-0.3, 0.3); D(stick([x + 0.2, h * 0.5, z - 0.1], [x + Math.cos(an) * 1.6 * k, h * 0.75, z + Math.sin(an) * 1.6 * k], 0.12 * k, 0.06 * k, '#6a5a48', 5)); }
      const G2 = ['#5f7f3a', '#6b8a40', '#537236'];
      for (let i = 0; i < 6; i++) { const an = i * 1.05 + R(-0.3, 0.3), rr = i ? R(1.0, 1.7) * k : 0; L({ sph: true, r: R(1.3, 1.7) * k, x: x + Math.cos(an) * rr, y: h * (i ? R(0.68, 0.82) : 0.9), z: z + Math.sin(an) * rr, sx: 1.1, sy: 0.8, sz: 1.1, ry: R(0, 3), color: G2[i % 3], seg: 8 }); }
    };

    // =================== вода и набережные ===================
    // суша внутри границ: юг x −26..20, z −33..−1; север x −26..26, z 5..36 (без кромок у воды)
    pave(-26, -33, 19.68, -1.32);
    pave(-25.68, 5.32, 25.68, 35.68);
    // каналы: невидимая стена над водой (не пройти и не запрыгнуть), пули и взгляд — насквозь
    for (const [x0, x1] of [[-26, -23], [-19, 13], [17, 26]]) B(x0, -1, x1, 5, 4.5, 'none', 0, { nr: true });
    B(20, -33, 26, -1, 4.5, 'none', 0, { nr: true });
    // кромки набережных там, где к воде выходит мостовая
    coping('+z', -23, -17, -1); coping('+z', -3.5, 3.5, -1); coping('+z', 13, 20, -1);
    coping('+x', -33, -1.32, 20);
    coping('-z', -26, 18, 5);
    coping('-x', 5, 11, -26); coping('-x', 29, 36, -26); coping('+x', 29, 36, 26);
    coping('+z', -26, 26, 36);
    // дома, встающие из воды: мокрый цоколь
    wetBase('+z', -26, -23, -1); wetBase('+z', -17, -3.5, -1); wetBase('+z', 3.5, 13, -1);
    wetBase('-z', 18, 26, 5); wetBase('-x', 11, 29, -26);
    // тина и свет на воде у стен (высокое) — тёмная полоса у кромки
    // =================== мосты ===================
    // пологий каменный мост через рио (вдоль Z от −1 до 5): арка из кирпича с истрийским архивольтом, ступени, парапеты
    const bridge = (bx0, bx1) => {
      const xc = (bx0 + bx1) / 2, W = bx1 - bx0, zc = 2;
      // ступени и настил — твёрдые (ниже 0.3 м — навигация считает их полом)
      B(bx0 + 0.32, -2.1, bx1 - 0.32, -1.3, 0.12, 'lgIstria', 0);
      B(bx0 + 0.32, -1.3, bx1 - 0.32, 5.3, 0.24, 'lgBrick', 0);
      B(bx0 + 0.32, 5.3, bx1 - 0.32, 6.1, 0.12, 'lgIstria', 0);
      // парапеты (укрытие сидя), с белой плитой сверху
      for (const [p0, p1] of [[bx0, bx0 + 0.32], [bx1 - 0.32, bx1]]) {
        B(p0, -2.1, p1, 6.1, 1.12, 'lgBrick', 0);
        D(box(0.42, 0.1, 8.3, (p0 + p1) / 2, 1.17, zc, IST), box(0.4, 0.14, 8.25, (p0 + p1) / 2, 0.24, zc, IST2));
      }
      // пилоны на концах парапетов
      for (const z of [-2.1, 6.1]) for (const px of [bx0 + 0.16, bx1 - 0.16]) { hid(px - 0.23, z - 0.23, px + 0.23, z + 0.23, 1.3); D(box(0.46, 1.3, 0.46, px, 0.65, z, IST), box(0.54, 0.12, 0.54, px, 1.34, z, IST2)); H({ sph: true, r: 0.16, x: px, y: 1.52, z, color: IST, seg: 7 }); }
      // ребро ступеней
      for (const z of [-1.3, 5.3]) D(box(W - 0.66, 0.05, 0.08, xc, 0.245, z, IST));
      // арка (в плоскости ZY, выдавлена на ширину моста)
      const sp = 3.0, cr = -0.3, sy = WL + 0.05, bot = WL - 0.6, hw = 3.75;
      const pts = [[-hw, 0], [-hw, bot], [-sp, bot], [-sp, sy]];
      for (let k = 1; k < 12; k++) { const t = k / 12, an = Math.PI - t * Math.PI; pts.push([Math.cos(an) * sp, sy + Math.sin(an) * (cr - sy)]); }
      pts.push([sp, sy], [sp, bot], [hw, bot], [hw, 0]);
      D({ shape: true, pts, d: W - 0.04, x: xc, y: 0, z: zc, color: '#9a5038', ry: 0, cs: 1 });
      // архивольт истрийского камня на обоих фасадах моста
      const ring = [[-sp, sy]];
      for (let k = 1; k < 12; k++) { const t = k / 12, an = Math.PI - t * Math.PI; ring.push([Math.cos(an) * sp, sy + Math.sin(an) * (cr - sy)]); }
      ring.push([sp, sy], [sp + 0.3, sy]);
      for (let k = 11; k >= 1; k--) { const t = k / 12, an = Math.PI - t * Math.PI; ring.push([Math.cos(an) * (sp + 0.3), sy + Math.sin(an) * (cr + 0.24 - sy)]); }
      ring.push([-sp - 0.3, sy]);
      for (const xx of [bx0 - 0.01, bx1 + 0.01]) D({ shape: true, pts: ring, d: 0.06, x: xx, y: 0, z: zc, color: IST, ry: 0, cs: 1 });
      // ключевой камень
      for (const xx of [bx0 - 0.03, bx1 + 0.03]) D(box(0.06, 0.34, 0.44, xx, cr + 0.12, zc, IST2));
      // фонарь на мосту
      a.lamps.push([bx0 + 0.16, 1.9, -2.1, 0.9]);
      D(cyl(0.05, 0.5, bx0 + 0.16, 1.62, -2.1, IRON, 0, 0, 0, 5), cyl(0.15, 0.38, bx0 + 0.16, 1.98, -2.1, '#ffe2a6', 0, 0, 0, 6), { cyl: true, r: 0.03, r2: 0.21, h: 0.2, x: bx0 + 0.16, y: 2.27, z: -2.1, color: IRON, seg: 6 });
    };
    bridge(-23, -19); bridge(13, 17);

    // =================== север: рива у лагуны, портик, кампанила ===================
    // палаццо вдоль ривы: первый этаж — глухой корпус с проходами, перед ним портик на колоннах; верх — над портиком
    const PZ0 = 23, PZ1 = 29, PC = [-3, 1], PE = [7, 11], PH = 4.6;
    B(-26, PZ0, PC[0], 26, PH, 'lgPlaster', 0, { tint: '#e6d2b6' }); B(PC[1], PZ0, PE[0], 26, PH, 'lgPlaster', 0, { tint: '#e6d2b6' }); B(PE[1], PZ0, 26, 26, PH, 'lgPlaster', 0, { tint: '#e6d2b6' });
    // проходы: потолок сводом (арка на входах)
    for (const [p0, p1] of [PC, PE]) {
      for (const z of [PZ0, 26]) archX(p0, p1, z + (z === PZ0 ? -0.06 : 0.06), PH);
      D(box(p1 - p0, 0.2, 26 - PZ0, (p0 + p1) / 2, PH - 0.1, (PZ0 + 26) / 2, '#6a4a32'));
      for (let k = 0; k < 4; k++) H(box(p1 - p0, 0.14, 0.14, (p0 + p1) / 2, PH - 0.28, PZ0 + 0.4 + k * 0.75, '#4a3020'));
      a.lamps.push([(p0 + p1) / 2, 3.6, (PZ0 + 26) / 2, 0.8]); D(cyl(0.14, 0.3, (p0 + p1) / 2, 3.7, (PZ0 + 26) / 2, '#ffe2a6', 0, 0, 0, 6), cyl(0.01, 0.6, (p0 + p1) / 2, 4.2, (PZ0 + 26) / 2, IRON, 0, 0, 0, 3));
    }
    // верх палаццо: три дома разного цвета и высоты над портиком
    const PAL3 = [[-26, -10, 12.2, '#dfa08a', 2], [-10, 8, 14.6, '#efe2c8', 3], [8, 26, 12.0, '#e3b06c', 2]];
    for (const [x0, x1, h, col, fl] of PAL3) {
      house(x0, PZ0, x1, PZ1, h, col, { y0: PH, faces: ['+z', '-z'], band: 7.9, wy: 5.3,
        win: [['+z', x0 + 0.6, x1 - 0.6, fl, { gothic: x0 === -10, noble: 0, balc: 0.45, kinds: [1, 2, 0, 1, 7] }], ['-z', x0 + 0.6, x1 - 0.6, fl, { kinds: [1, 2, 1, 7], fl: 0.4 }]] });
      for (const z of [PZ0, PZ1]) D(box(x1 - x0, 0.3, 0.12, (x0 + x1) / 2, PH + 0.15, z + (z === PZ1 ? 0.06 : -0.06), IST));
    }
    // торцы палаццо у воды
    DC(4, -26, 1.8, 24.5, 2.4, 4.0, '-x'); DC(1, -26, 6.6, 26, 1.1, 2.2, '-x'); DC(1, -26, 9.8, 26, 1.1, 2.2, '-x');
    // портик: колонны, аркада, кессонный потолок
    const NB = 15, bw = 52 / NB;
    for (let i = 0; i <= NB; i++) { const x = -26 + i * bw; if (i === 0 || i === NB) continue; column(x, 28.62, 2.9, 0.26); }
    arcadeX(-26, 26, 28.62, 2.9, PH, NB, 0.62, 0.56, IST);
    D(box(52, 0.16, 0.7, 0, PH + 0.02, 28.62, IST2));
    D(box(52, 0.12, 3.0, 0, PH - 0.06, 27.5, '#d6c6a8'));
    for (let i = 0; i <= NB; i++) H(box(0.18, 0.18, 3.0, -26 + i * bw, PH - 0.2, 27.5, '#b8a888'));
    for (let i = 0; i < NB; i++) { const x = -26 + (i + 0.5) * bw; a.lamps.push([x, 3.75, 27.6, 0.7]); D(cyl(0.12, 0.26, x, 3.85, 27.6, '#ffe2a6', 0, 0, 0, 6), cyl(0.01, 0.6, x, 4.3, 27.6, IRON, 0, 0, 0, 3)); }
    // витрины и двери под портиком (задняя стена портика z = 26)
    const shopsN = [[-23.5, 14], [-19.5, 5], [-15.5, 3], [-11.5, 14], [-7, 5], [4, 3], [14, 5], [18, 15], [22.5, 3]];
    for (const [x, k] of shopsN) { DC(k, x, 1.75, 26, 1.7, 3.4, '+z', k === 5 || k === 14); }
    DC(10, -7, 3.9, 26, 1.6, 1.6, '+z', false, 1); DC(13, 14, 3.9, 26, 1.7, 1.7, '+z', false, 2);
    DC(14, 4, 1.75, PZ0, 1.7, 3.4, '-z', true); DC(3, 13.6, 1.6, PZ0, 1.5, 3.0, '-z'); DC(15, 16.2, 1.6, PZ0, 1.4, 2.8, '-z'); DC(12, 2.2, 3.6, PZ0, 1.3, 1.3, '-z', false, 1);
    // шахматная облицовка цоколя под портиком (высокое)
    for (let x = -25.5; x < 26; x += 1.0) if (!(x > PC[0] - 0.5 && x < PC[1] + 0.5) && !(x > PE[0] - 0.5 && x < PE[1] + 0.5)) H(box(0.5, 0.5, 0.04, x, 0.25, 26.02, '#cfc6b4'));
    // рива: фонари, скамьи, колонна со львом, кампанила
    for (const x of [-21, -10, 13, 24]) lampPost(x, 35.0, 3.6);
    bench(-6, 35.2); bench(4, 35.2);
    {
      const X = -15.5, Z = 32.8;
      B(X - 1.0, Z - 1.0, X + 1.0, Z + 1.0, 0.28, 'lgIstria', 0);
      B(X - 0.65, Z - 0.65, X + 0.65, Z + 0.65, 1.25, 'lgIstria', 0.28, { ch: 1 });
      hid(X - 0.42, Z - 0.42, X + 0.42, Z + 0.42, 9.2, 1.53);
      D({ cyl: true, r: 0.36, r2: 0.42, h: 9.2, x: X, y: 1.53 + 4.6, z: Z, color: '#9a8c80', seg: 14 }, cyl(0.6, 0.4, X, 10.9, Z, IST, 0, 0, 0, 12), box(1.1, 0.25, 1.1, X, 11.2, Z, IST2));
      // крылатый лев святого Марка
      D(box(1.0, 0.5, 0.42, X, 11.6, Z, BRONZE), { sph: true, r: 0.26, x: X + 0.5, y: 12.0, z: Z, color: BRONZE, seg: 7 });
      D({ shape: true, pts: [[0, 0], [0.9, 0.5], [0.6, 0.1], [0.9, 0.2], [0.3, -0.05]], d: 0.06, x: X - 0.1, y: 11.7, z: Z + 0.24, color: BRONZE, ry: -HP, cs: 1 }, { shape: true, pts: [[0, 0], [0.9, 0.5], [0.6, 0.1], [0.9, 0.2], [0.3, -0.05]], d: 0.06, x: X - 0.1, y: 11.7, z: Z - 0.24, color: BRONZE, ry: -HP, cs: 1 });
      H(box(0.12, 0.4, 0.12, X + 0.35, 11.2, Z + 0.12, BRONZE), box(0.12, 0.4, 0.12, X - 0.35, 11.2, Z - 0.12, BRONZE), { torus: true, r: 0.44, tube: 0.05, x: X, y: 1.62, z: Z, rx: HP, color: IST, seg: 12 });
    }
    // кампанила: кирпичный ствол с лопатками, звонница с арками, аттик, зелёный медный шпиль, ангел
    {
      const x0 = 18, x1 = 22, z0 = 30.4, z1 = 34.4, cx = 20, cz = 32.4, HS = 19;
      B(x0 - 0.25, z0 - 0.25, x1 + 0.25, z1 + 0.25, 1.1, 'lgIstria', 0, { ch: 1 });
      B(x0, z0, x1, z1, HS, 'lgBrick', 1.1);
      for (const [n, c] of [['+x', x1], ['-x', x0], ['+z', z1], ['-z', z0]]) for (const t of [-1.75, 0, 1.75]) { const p = at(n, c, (isX(n) ? cz : cx) + t, 0.06); D(box(isX(n) ? 0.12 : 0.42, HS - 1.4, isX(n) ? 0.42 : 0.12, p[0], 1.1 + (HS - 1.4) / 2, p[1], '#a85a40')); }
      D(box(4.5, 0.4, 4.5, cx, HS + 1.1 + 0.2, cz, IST));
      const BY = HS + 1.5, BH = 3.4;
      for (const [n, c] of [['+x', x1 - 0.2], ['-x', x0 + 0.2], ['+z', z1 - 0.2], ['-z', z0 + 0.2]]) {
        if (isX(n)) arcadeZ(z0, z1, c, BY + 2.0, BY + BH, 3, 0.36, 0.36, IST); else arcadeX(x0, x1, c, BY + 2.0, BY + BH, 3, 0.36, 0.36, IST);
      }
      for (const [px, pz] of [[x0 + 0.18, z0 + 0.18], [x1 - 0.18, z0 + 0.18], [x0 + 0.18, z1 - 0.18], [x1 - 0.18, z1 - 0.18]]) D(box(0.36, 2.0, 0.36, px, BY + 1.0, pz, IST));
      for (const t of [-2 / 3, 2 / 3]) for (const [n, c] of [['+x', x1 - 0.2], ['-x', x0 + 0.2], ['+z', z1 - 0.2], ['-z', z0 + 0.2]]) { const p = at(n, c, (isX(n) ? cz : cx) + t, 0); D(cyl(0.11, 2.0, p[0], BY + 1.0, p[1], IST, 0, 0, 0, 8)); }
      D({ cyl: true, r: 0.5, r2: 0.78, h: 1.1, x: cx, y: BY + 1.6, z: cz, color: '#8a6a32', seg: 12 }, box(4.1, 0.2, 4.1, cx, BY + 0.1, cz, '#8a8070'));
      const AY = BY + BH;
      D(box(4.4, 0.3, 4.4, cx, AY + 0.15, cz, IST2));
      B(x0 + 0.1, z0 + 0.1, x1 - 0.1, z1 - 0.1, 2.4, 'lgBrick', AY + 0.3, { solid: false });
      D(box(4.3, 0.3, 4.3, cx, AY + 2.85, cz, IST));
      // часы на аттике
      for (const [n, c] of [['-z', z0 + 0.1], ['-x', x0 + 0.1], ['+z', z1 - 0.1]]) { const p = at(n, c, isX(n) ? cz : cx, 0.04); D(cyl(0.75, 0.06, p[0], AY + 1.5, p[1], '#1d3a7a', isX(n) ? 0 : HP, 0, isX(n) ? HP : 0, 14)); const q = at(n, c, isX(n) ? cz : cx, 0.08); D(cyl(0.6, 0.03, q[0], AY + 1.5, q[1], GOLD, isX(n) ? 0 : HP, 0, isX(n) ? HP : 0, 14)); const r = at(n, c, isX(n) ? cz : cx, 0.1); D(cyl(0.5, 0.03, r[0], AY + 1.5, r[1], '#1d3a7a', isX(n) ? 0 : HP, 0, isX(n) ? HP : 0, 14)); H(box(isX(n) ? 0.03 : 0.06, 0.45, isX(n) ? 0.06 : 0.03, r[0], AY + 1.68, r[1], GOLD)); }
      D({ cyl: true, r: 0.05, r2: 3.05, h: 7.2, x: cx, y: AY + 3.0 + 3.6, z: cz, color: '#5e9078', seg: 4, ry: Math.PI / 4 });
      D({ sph: true, r: 0.3, x: cx, y: AY + 10.3, z: cz, color: GOLD, seg: 7 }, cyl(0.04, 0.9, cx, AY + 10.8, cz, GOLD, 0, 0, 0, 4));
      H({ cyl: true, r: 0.05, r2: 0.22, h: 0.8, x: cx, y: AY + 11.5, z: cz, color: GOLD, seg: 6 }, { sph: true, r: 0.12, x: cx, y: AY + 12.0, z: cz, color: GOLD, seg: 6 }, box(0.9, 0.3, 0.05, cx, AY + 11.75, cz, GOLD, 0, 0.6, 0));
      for (const [px, pz] of [[x0, z0], [x1, z0], [x0, z1], [x1, z1]]) H({ cyl: true, r: 0.02, r2: 0.22, h: 1.0, x: px, y: AY + 3.5, z: pz, color: '#5e9078', seg: 4 });
      DC(4, x0, 1.1 + 1.6, cz, 1.6, 3.0, '-x'); DC(8, cx, 9.0, z0, 2.0, 2.0, '-z', false, 2);
      for (const y of [6, 12]) for (const [n, c] of [['-x', x0], ['-z', z0], ['+z', z1]]) { const p = at(n, c, isX(n) ? cz : cx, 0); DC(1, isX(n) ? c : p[0], y, isX(n) ? p[1] : c, 0.6, 1.4, n); }
    }

    // =================== кампо (точка A) ===================
    // церковь: фасад из истрийского камня лицом на запад, кирпичный неф, купол со световым фонарём
    {
      const FX = 17.4;
      B(18, 5, 31, 23, 12.5, 'lgBrick', 0);
      B(FX, 8, 18, 20, 14.2, 'lgIstria', 0);
      cornice(18, 5, 31, 23, 12.5, ['-z', '+z']);
      wetBase('-z', 26, 31, 5);
      // ступени (ниже 0.3 м)
      B(16.5, 9, FX, 19, 0.14, 'lgIstria', 0); B(16.95, 9.4, FX, 18.6, 0.28, 'lgIstria', 0);
      // полуколонны, антаблемент, фронтон, портал, розетка
      for (const z of [8.9, 11.7, 16.3, 19.1]) {
        D({ cyl: true, r: 0.42, r2: 0.46, h: 10.6, x: FX - 0.12, y: 0.28 + 0.6 + 5.3, z, color: IST, seg: 12 }, box(1.2, 0.6, 1.2, FX - 0.12, 0.58, z, IST2),
          { cyl: true, r: 0.62, r2: 0.44, h: 0.7, x: FX - 0.12, y: 11.85, z, color: IST, seg: 12 });
        hid(FX - 0.72, z - 0.6, FX, z + 0.6, 11.5, 0.28);
        H({ torus: true, r: 0.47, tube: 0.07, x: FX - 0.12, y: 1.0, z, rx: HP, color: IST2, seg: 12 });
      }
      D(box(0.7, 0.9, 12.6, FX - 0.15, 12.65, 14, IST), box(0.86, 0.22, 12.9, FX - 0.2, 13.2, 14, IST2));
      D({ shape: true, pts: [[-6.6, 0], [0, 3.2], [6.6, 0]], d: 0.7, x: FX - 0.12, y: 13.3, z: 14, color: IST, ry: 0, cs: 1 });
      D({ shape: true, pts: [[-6.9, 0], [-6.6, 0], [0, 3.2], [6.6, 0], [6.9, 0], [0, 3.38]], d: 0.86, x: FX - 0.2, y: 13.3, z: 14, color: IST2, ry: 0, cs: 1 });
      DC(8, FX - 0.49, 14.45, 14, 1.5, 1.5, '-x', false, 2);
      DC(9, FX, 0.28 + 2.9, 14, 2.9, 5.8, '-x'); DC(8, FX, 8.8, 14, 3.0, 3.0, '-x', false, 1);
      DC(0, FX, 6.4, 10.3, 1.2, 2.4, '-x'); DC(0, FX, 6.4, 17.7, 1.2, 2.4, '-x');
      DC(13, FX, 2.3, 10.3, 1.1, 1.1, '-x', false, 1); DC(13, FX, 2.3, 17.7, 1.1, 1.1, '-x', false, 1);
      // статуи на фронтоне (высокое)
      for (const [z, y] of [[14, 16.5], [7.8, 13.4], [20.2, 13.4]]) H(cyl(0.22, 1.3, FX - 0.1, y + 0.65, z, '#dcd5c6', 0, 0, 0, 7), { sph: true, r: 0.18, x: FX - 0.1, y: y + 1.45, z, color: '#dcd5c6', seg: 6 }, box(0.5, 0.2, 0.5, FX - 0.1, y + 0.1, z, IST2));
      // боковые окна нефа (на кампо видна южная стена нефа над водой — z = 5)
      for (const x of [21, 24.5, 28]) DC(0, x, 8.0, 5, 1.3, 2.6, '-z');
      // купол на барабане и фонарь
      const DX = 26.5, DZ = 14;
      D(cyl(4.3, 3.0, DX, 14.0, DZ, '#d8cbb4', 0, 0, 0, 20), cyl(4.5, 0.3, DX, 15.6, DZ, IST, 0, 0, 0, 20), cyl(4.45, 0.4, DX, 12.6, DZ, IST, 0, 0, 0, 20));
      D({ sph: true, r: 4.2, x: DX, y: 15.7, z: DZ, sy: 1.12, color: '#7f8e90', seg: 20, hs: 10 });
      D(cyl(0.75, 1.6, DX, 21.2, DZ, IST, 0, 0, 0, 10), { sph: true, r: 0.8, x: DX, y: 22.0, z: DZ, sy: 0.9, color: '#7f8e90', seg: 10 }, cyl(0.05, 1.4, DX, 23.2, DZ, GOLD, 0, 0, 0, 4), { sph: true, r: 0.2, x: DX, y: 23.0, z: DZ, color: GOLD, seg: 6 });
      for (let k = 0; k < 10; k++) { const an = k * 0.628; H(box(0.18, 1.9, 0.3, DX + Math.cos(an) * 4.33, 14.0, DZ + Math.sin(an) * 4.33, IST, 0, -an, 0)); D(box(0.06, 1.1, 0.7, DX + Math.cos(an + 0.31) * 4.31, 14.0, DZ + Math.sin(an + 0.31) * 4.31, '#2a3640', 0, -an - 0.31, 0)); }
      for (let k = 0; k < 8; k++) { const an = k * 0.785; H(stick([DX + Math.cos(an) * 4.2, 15.75, DZ + Math.sin(an) * 4.2], [DX + Math.cos(an) * 0.8, 20.4, DZ + Math.sin(an) * 0.8], 0.09, 0.07, '#6f7e80', 4)); }
      roof(18, 5, 31, 23, 12.5, 2.6, 0.4, { hip: false, along: 'x', col: '#f2e2d6', gable: '#b8654a' });
    }
    // палаццо западной стороны кампо: «каза» с Г-образным сотопортего (проход из корте в кампо)
    {
      // твёрдые части первого этажа; над проходом — второй этаж и выше
      B(-15, 11, -11, 16, 10.2, 'lgPlaster', 0, { tint: '#d98e74' });
      B(-18, 19.5, -11, 23, 10.2, 'lgPlaster', 0, { tint: '#d98e74' });
      B(-18, 11, -15, 19.5, 10.2 - 3.4, 'lgPlaster', 3.4, { tint: '#d98e74' });
      B(-15, 16, -11, 19.5, 10.2 - 3.4, 'lgPlaster', 3.4, { tint: '#d98e74' });
      cornice(-18, 11, -11, 23, 10.2, ['+x', '-z']);
      band(-18, 11, -11, 23, 3.8, ['+x', '-z']);
      roof(-18.05, 10.95, -10.95, 23.05, 10.22, 1.8, 0.55, { col: '#f2e2d6' });
      chimney(-14, 14, 10.8); chimney(-16.5, 21, 10.8);
      windows('+x', -11, 11.4, 22.6, 4.5, 2, { kinds: [2, 1, 7, 0], noble: 0, balc: 0.5 });
      windows('-z', 11, -18, -11, 4.5, 2, { kinds: [1, 2, 1] });
      // своды прохода: деревянные балки и арки на входах
      D(box(3.0, 0.16, 8.5, -16.5, 3.32, 15.25, '#5a3c26'), box(4.0, 0.16, 3.5, -13, 3.32, 17.75, '#5a3c26'));
      for (let k = 0; k < 6; k++) H(box(3.0, 0.12, 0.12, -16.5, 3.18, 11.8 + k * 1.3, '#3e2a1c'));
      archX(-18, -15, 10.94, 3.4); archZ(16, 19.5, -10.94, 3.4);
      DC(11, -15, 2.6, 13.5, 1.0, 1.0, '-x', false, 1); DC(13, -18, 2.2, 15.0, 0.9, 0.9, '+x', false, 1);
      wallLamp('+x', -18, 17.5, 2.6);
      // лавка масок на кампо и витрина
      DC(14, -11, 1.7, 13.4, 1.6, 3.2, '+x', true); DC(3, -11, 1.7, 21.3, 1.5, 3.0, '+x');
      DC(12, -11, 6.0, 21.6, 1.6, 1.6, '+x', false, 1);
    }
    // северо-западный дом над водой (между корте и палаццо)
    house(-26, 11, -18, 23, 11.0, '#c97a5e', { faces: ['-x', '-z'], band: 4.2, win: [['-z', -25.4, -18.6, 2, { kinds: [1, 2, 0], fl: 0.5 }], ['-x', 11.6, 22.4, 2, { kinds: [1, 1, 2] }]] });
    DC(3, -21.5, 1.6, 11, 1.5, 3.0, '-z'); DC(15, -24.5, 1.6, 11, 1.6, 3.2, '-z'); DC(12, -19.6, 1.6, 11, 1.4, 1.4, '-z', false, 2);
    wallLamp('-z', 11, -23, 2.8);
    // корте Овест: бочки, ящики, лавка, причал гондол на западном канале
    crate(-13.6, 8.6, 1.2); crate(-13.4, 7.3, 0.9); barrel(-24.8, 10.2); barrel(-24.1, 10.5); crate(-25.0, 9.0, 0.9);
    bench(-20.5, 10.6);
    for (const z of [6.5, 9.5]) palina(-26.9, z, 3.0, '#f2efe6', '#c0392b');
    gondola(-28.0, 8.0, -HP, true);
    // кафе на северо-западе кампо: вывеска, навес, столики, зонты, ящики с цветами
    DC(5, -9.5, 1.75, 23, 1.7, 3.4, '-z', true); DC(5, -5.5, 1.75, 23, 1.7, 3.4, '-z', true); DC(10, -7.5, 3.95, 23, 1.7, 1.7, '-z', false, 1);
    a.awning(-7.5, 3.25, 23, 7.2, 1.6, '-z', '#2f5a4a');
    for (const x of [-10.5, -4.5]) { const p = [x, 22.1]; D(cyl(0.03, 1.4, p[0], 2.55, p[1] - 0.6, IRON, 0.5, 0, 0, 4)); }
    table(-9.2, 20.6, 3); table(-5.8, 20.4, 3); table(-7.6, 18.0, 2);
    parasol(-8.4, 19.6, '#8a2a2a'); parasol(-4.6, 19.4, '#2f5a4a');
    planter(-8.9, 16.6, 2.0, true); planter(-4.9, 16.6, 2.2, true);
    // колодец (вера да поццо) на ступенях
    {
      const X = -2.6, Z = 13.0;
      B(X - 1.4, Z - 1.4, X + 1.4, Z + 1.4, 0.14, 'lgIstria', 0); B(X - 1.0, Z - 1.0, X + 1.0, Z + 1.0, 0.28, 'lgIstria', 0);
      hid(X - 0.72, Z - 0.72, X + 0.72, Z + 0.72, 1.2);
      D(cyl(0.72, 0.85, X, 0.28 + 0.42, Z, IST, 0, 0, 0, 8), cyl(0.78, 0.1, X, 1.17, Z, IST2, 0, 0, 0, 8), cyl(0.52, 0.02, X, 1.22, Z, '#3a3a36', 0, 0, 0, 8));
      for (let k = 0; k < 8; k++) { const an = (k + 0.5) * 0.785; H(box(0.5, 0.42, 0.04, X + Math.cos(an) * 0.68, 0.72, Z + Math.sin(an) * 0.68, IST2, 0, -an + HP, 0)); }
      D(box(0.06, 0.06, 1.4, X - 0.6, 1.24, Z, BRONZE), box(1.4, 0.06, 0.06, X, 1.24, Z - 0.6, BRONZE));
      H({ sph: true, r: 0.14, x: X, y: 1.32, z: Z, color: BRONZE, seg: 6 });
    }
    // памятник на высоком пьедестале — центральное укрытие (ломает прострел с воды на проходы палаццо)
    {
      const X = 4.6, Z = 16.4;
      B(X - 1.3, Z - 1.3, X + 1.3, Z + 1.3, 0.28, 'lgIstria', 0, { ch: 1 });
      B(X - 0.95, Z - 0.95, X + 0.95, Z + 0.95, 2.42, 'lgIstria', 0.28, { ch: 1 });
      D(box(2.2, 0.24, 2.2, X, 2.82, Z, IST2), box(1.6, 0.22, 1.6, X, 0.56, Z, IST2));
      for (const [n, c] of [['-z', Z - 0.95], ['+z', Z + 0.95], ['-x', X - 0.95], ['+x', X + 0.95]]) { const p = at(n, c, isX(n) ? Z : X, 0.03), q = at(n, c, isX(n) ? Z : X, 0.05); D(box(isX(n) ? 0.04 : 1.1, 0.7, isX(n) ? 1.1 : 0.04, p[0], 1.7, p[1], '#7a6440'), box(isX(n) ? 0.04 : 0.9, 0.5, isX(n) ? 0.9 : 0.04, q[0], 1.7, q[1], '#8e7850')); }
      // бронзовая фигура: плащ, торс, голова, рука с мечом
      const S = '#4a5a4a';
      D({ cyl: true, r: 0.32, r2: 0.55, h: 1.5, x: X, y: 3.7, z: Z, color: S, seg: 9 }, { cyl: true, r: 0.36, r2: 0.3, h: 0.7, x: X, y: 4.75, z: Z, color: S, seg: 9 },
        { sph: true, r: 0.22, x: X, y: 5.32, z: Z, color: S, seg: 8 }, box(0.6, 0.12, 0.2, X - 0.3, 5.0, Z - 0.3, S, 0.3, 0, 0.6));
      D(stick([X + 0.3, 4.95, Z], [X + 0.75, 5.75, Z - 0.1], 0.08, 0.07, S, 5), stick([X + 0.75, 5.75, Z - 0.1], [X + 0.85, 6.6, Z - 0.15], 0.03, 0.03, '#6a6a5a', 4));
    }
    // газетный киоск-эдикола: укрытие в юго-западной части кампо
    {
      const X = -5.8, Z = 8.9;
      hid(X - 1.15, Z - 1.15, X + 1.15, Z + 1.15, 2.55);
      D(box(2.3, 2.3, 2.3, X, 1.15, Z, '#2c4a38'), box(2.9, 0.14, 2.9, X, 2.42, Z, '#1e3428'), { cyl: true, r: 0.2, r2: 1.75, h: 0.55, x: X, y: 2.76, z: Z, color: '#24402e', seg: 4, ry: Math.PI / 4 });
      D(box(2.32, 0.3, 2.32, X, 2.1, Z, '#e8dcc0'));
      for (const [n, c] of [['-z', Z - 1.15], ['+x', X + 1.15], ['-x', X - 1.15]]) for (let i = 0; i < 4; i++) { const p = at(n, c, (isX(n) ? Z : X) - 0.75 + i * 0.5, 0.03); D(box(isX(n) ? 0.04 : 0.36, 0.48, isX(n) ? 0.36 : 0.04, p[0], 1.35 + (i % 2) * 0.08, p[1], ['#c8302a', '#e8d04a', '#2a5aa8', '#f2f0ea'][i])); }
      DC(11, X + 1.15, 2.1, Z, 0.5, 0.5, '+x', false, 1);
    }
    // фруктовый прилавок под полосатым навесом (восток кампо)
    {
      const X = 12.6, Z = 13.6;
      hid(X - 1.7, Z - 0.6, X + 1.7, Z + 0.6, 1.05);
      D(box(3.4, 0.9, 1.2, X, 0.45, Z, '#6a4a30'), box(3.5, 0.08, 1.3, X, 0.94, Z, '#4a3020'));
      for (let i = 0; i < 5; i++) { const px = X - 1.35 + i * 0.68; D(box(0.6, 0.18, 0.5, px, 1.07, Z - 0.25, '#a8865a'), box(0.6, 0.18, 0.5, px, 1.07, Z + 0.28, '#a8865a'));
        const fc = ['#e8452a', '#f2a03a', '#7aa04a', '#f2d040', '#9a2a4a'][i];
        for (let k = 0; k < 4; k++) H({ sph: true, r: 0.09, x: px - 0.18 + (k % 2) * 0.36, y: 1.22, z: Z - 0.25 + (k > 1 ? 0.53 : 0), color: fc, seg: 5 });
        LO(box(0.52, 0.06, 0.42, px, 1.18, Z - 0.25, fc), box(0.52, 0.06, 0.42, px, 1.18, Z + 0.28, fc)); }
      for (const [dx, dz] of [[-1.65, -0.55], [1.65, -0.55], [-1.65, 0.55], [1.65, 0.55]]) D(cyl(0.04, 2.5, X + dx, 1.25, Z + dz, '#3a2a1e', 0, 0, 0, 5));
      a.awning(X, 2.55, Z + 0.55, 3.6, 1.6, '-z', '#b0392b');
      D(box(3.6, 0.06, 0.08, X, 2.52, Z + 0.55, '#3a2a1e'));
    }
    // ящики: у моста Эст и у портала церкви, у прохода PE
    crate(11.6, 7.6, 1.25); crate(11.66, 7.54, 0.9, 1.25); crate(10.2, 8.4, 0.9);
    crate(15.2, 21.7, 1.1); crate(13.9, 21.9, 0.85);
    crate(-1.2, 7.0, 1.0); barrel(0.2, 6.6);
    // флагштоки с бронзовыми основаниями
    for (const x of [-4.4, 12.6]) {
      hid(x - 0.45, 21.8, x + 0.45, 22.7, 1.0);
      D({ cyl: true, r: 0.36, r2: 0.48, h: 1.0, x, y: 0.5, z: 22.25, color: BRONZE, seg: 10 }, cyl(0.09, 10, x, 6.0, 22.25, '#7a2a1e', 0, 0, 0, 6), { sph: true, r: 0.16, x, y: 11.05, z: 22.25, color: GOLD, seg: 6 });
      H({ torus: true, r: 0.4, tube: 0.06, x, y: 0.85, z: 22.25, rx: HP, color: '#7a6a42', seg: 10 });
    }
    // фонари кампо
    lampPost(-10.3, 5.9, 3.4); lampPost(6.6, 6.0, 3.4);
    // гондолы и палины у кампо (в рио)
    for (const x of [-8, -4, 2, 6]) palina(x, 4.76, 3.0, '#f2efe6', x < 0 ? '#2a5aa8' : '#c0392b');
    gondola(-7.4, 3.92, 0, false); gondola(6.0, 3.92, Math.PI, true);
    // грузовая лодка-«топо» напротив пристани мастерской: груз под брезентом закрывает прямой прострел с воды на проходы палаццо
    {
      const X = 0.2, Z = 1.75, y0 = WL - 0.2;
      B(-3.6, 0.85, 3.9, 2.65, 1.95 - (WL + 0.3), 'none', WL + 0.3, { hidden: true });
      D({ shape: true, pts: [[-5.2, 0.75], [4.6, 0.75], [5.4, 0.95], [4.9, 0.25], [4.2, 0.0], [-4.8, 0.0], [-5.3, 0.3]], d: 2.5, x: X, y: y0, z: Z, color: '#3d5a66', ry: -HP, cs: 1 });
      D(box(10.2, 0.12, 2.56, X, y0 + 0.78, Z, '#e8e2d4'), box(9.6, 0.06, 2.3, X, y0 + 0.72, Z, '#5a4a3a'));
      // груз: ящики на поддонах, часть — под брезентом
      D(box(7.6, 0.29, 2.3, X + 0.15, -0.115, Z, '#6a4a2e'));
      for (let i = 0; i < 6; i++) for (const dz of [-0.56, 0.56]) {
        const cx = X - 3.0 + i * 1.22, cz = Z + dz;
        crate(cx, cz, 1.1, 0.03);
        if (i > 0 && i < 5 || dz < 0) crate(cx + 0.05, cz - Math.sign(dz) * 0.03, 0.92, 1.13);
      }
      D(box(3.9, 0.06, 2.42, X - 0.4, 2.1, Z, '#55663f'));
      for (const s of [-1, 1]) D(box(3.9, 1.0, 0.05, X - 0.4, 1.62, Z + s * 1.2, '#4d5e39'));
      H(box(0.03, 0.03, 2.5, X - 2.1, 2.14, Z, '#c8b890'), box(0.03, 0.03, 2.5, X + 1.3, 2.14, Z, '#c8b890'));
      D(box(1.4, 1.3, 1.6, X - 4.3, WL + 0.95, Z, '#e8e2d4'), box(1.5, 0.08, 1.7, X - 4.3, WL + 1.62, Z, '#2a3a44'), box(1.42, 0.4, 1.62, X - 4.3, WL + 1.2, Z, '#2a3a44'));
      H(cyl(0.03, 0.9, X - 4.6, WL + 2.1, Z, IRON, 0, 0, 0, 4), box(0.5, 0.3, 0.02, X - 4.35, WL + 2.4, Z, '#c0392b'));
      for (const dx of [-3.8, 3.6]) H({ torus: true, r: 0.22, tube: 0.07, x: X + dx, y: y0 + 0.55, z: Z + 1.3, ry: 0, color: '#d8d0c0', seg: 10 });
    }
    // таблички
    DC(11, -11, 2.6, 10.2, 1.0, 1.0, '+x', false, 1);
    a.letter('A', 3.5, 9.6, 4.4);

    // =================== юг: калле Овест, форнаце, фондамента Эст, кампо налётчиков ===================
    // блок A (запад) — высокие дома над каналом
    house(-26, -33, -23, -1, 11.0, '#d9a77a', { faces: ['+x', '+z'], band: 4.0, win: [['+x', -25.4, -1.6, 2, { kinds: [1, 2, 1, 7], fl: 0.45 }], ['+z', -25.8, -23.2, 2, { kinds: [1] }]] });
    // блок B — между калле и мастерской; сотопортего на уровне z −13..−10
    const BH2 = 10.4;
    B(-17, -26, -9, -13, BH2, 'lgPlaster', 0, { tint: '#e6c48a' });
    B(-17, -10, -9, -1, BH2, 'lgPlaster', 0, { tint: '#d88a6e' });
    B(-17, -13, -9, -10, BH2 - 3.3, 'lgPlaster', 3.3, { tint: '#e6c48a' });
    cornice(-17, -26, -9, -13, BH2, ['-x', '-z']); cornice(-17, -10, -9, -1, BH2, ['-x', '+z']);
    band(-17, -26, -9, -1, 3.9, ['-x']);
    roof(-17.05, -26.05, -8.95, -12.95, BH2 + 0.02, 1.8, 0.55, { col: '#f2e2d6' }); roof(-17.05, -13.05, -8.95, -0.95, BH2 + 0.02, 1.8, 0.55, { col: '#e8d8cc' });
    chimney(-12, -20, BH2 + 0.7); chimney(-14, -6, BH2 + 0.7);
    windows('-x', -17, -25.4, -13.6, 4.4, 2, { kinds: [1, 2, 7], fl: 0.5 }); windows('-x', -17, -9.4, -1.6, 4.4, 2, { kinds: [2, 1, 0], fl: 0.4 });
    windows('+z', -1, -16.6, -9.4, 4.6, 2, { kinds: [0, 6, 1] }); windows('-z', -26, -16.6, -9.4, 4.4, 2, { kinds: [1, 2] });
    D(box(8.0, 0.16, 3.0, -13, 3.22, -11.5, '#5a3c26')); for (let k = 0; k < 5; k++) H(box(0.12, 0.12, 3.0, -16.4 + k * 1.7, 3.08, -11.5, '#3e2a1c'));
    archZ(-13, -10, -17.06, 3.3);
    a.lamps.push([-13, 2.8, -11.5, 0.8]); D(cyl(0.13, 0.28, -13, 2.85, -11.5, '#ffe2a6', 0, 0, 0, 6));
    DC(11, -17, 2.6, -14.3, 1.0, 1.0, '-x', false, 2); DC(13, -17, 2.3, -6.0, 1.0, 1.0, '-x', false, 1);
    DC(3, -17, 1.6, -19.5, 1.5, 3.0, '-x'); DC(15, -17, 1.6, -4.0, 1.5, 3.0, '-x'); DC(12, -17, 1.9, -22.5, 1.5, 1.5, '-x', false, 1);
    DC(4, -13, 1.6, -1, 2.2, 3.6, '+z');
    wallLamp('-x', -17, -8.0, 2.8); wallLamp('+x', -23, -17.5, 2.8);
    // бельё над калле
    for (const [z, y] of [[-20.5, 6.6], [-7.5, 6.9]]) {
      a.wire([-23, y, z], [-17, y + 0.1, z], 0.35);
      const cols = ['#f2f0ea', '#c8302a', '#2a5aa8', '#e8c040', '#f2f0ea', '#7aa04a'];
      for (let i = 0; i < 6; i++) { const x = -22.3 + i * 0.95, sag = Math.sin((x + 23) / 6 * Math.PI) * 0.35; D(box(0.5, 0.62 + (i % 2) * 0.2, 0.02, x, y - sag - 0.36, z, cols[i])); }
    }
    crate(-21.6, -15.8, 1.2); crate(-18.4, -6.5, 1.05); crate(-18.6, -5.4, 0.8); barrel(-22.2, -9.2); barrel(-22.1, -8.4);
    // мастерская «Форнаце»: кирпичные стены с дверями, кровля на фермах, печь в центре, верстаки
    {
      const x0 = -9, x1 = 9, z0 = -19, z1 = -3.5, T = 0.4, WH = 6.2;
      // юг: дверь x 2..5; север: дверь x −1.5..1.5; запад и восток: двери z −13..−10
      B(x0, z0, 2, z0 + T, WH, 'lgBrick'); B(5, z0, x1, z0 + T, WH, 'lgBrick'); B(2, z0, 5, z0 + T, WH - 3.1, 'lgBrick', 3.1);
      B(x0, z1 - T, -1.5, z1, WH, 'lgBrick'); B(1.5, z1 - T, x1, z1, WH, 'lgBrick'); B(-1.5, z1 - T, 1.5, z1, WH - 3.1, 'lgBrick', 3.1);
      B(x0, z0 + T, x0 + T, -13, WH, 'lgBrick'); B(x0, -10, x0 + T, z1 - T, WH, 'lgBrick'); B(x0, -13, x0 + T, -10, WH - 3.1, 'lgBrick', 3.1);
      B(x1 - T, z0 + T, x1, -13, WH, 'lgBrick'); B(x1 - T, -10, x1, z1 - T, WH, 'lgBrick'); B(x1 - T, -13, x1, -10, WH - 3.1, 'lgBrick', 3.1);
      B(x0 + T, z0 + T, x1 - T, z1 - T, 0.02, 'lgIstria', -0.02, { solid: false });
      roof(x0 - 0.1, z0 - 0.1, x1 + 0.1, z1 + 0.1, WH, 2.4, 0.5, { hip: false, along: 'x', col: '#ffffff', gable: '#a8553a' });
      cornice(x0, z0, x1, z1, WH, ['-z', '+z'], '#d8cfc0');
      for (const x of [-4.5, 0, 4.5]) H(box(0.14, 0.2, z1 - z0 - 0.8, x, WH - 0.1, (z0 + z1) / 2, '#4a3020'), stick([x, WH - 0.1, z0 + 0.4], [x, WH + 2.2, (z0 + z1) / 2], 0.07, 0.07, '#4a3020', 4), stick([x, WH - 0.1, z1 - 0.4], [x, WH + 2.2, (z0 + z1) / 2], 0.07, 0.07, '#4a3020', 4));
      D(box(x1 - x0 - 0.8, 0.16, 0.16, 0, WH - 0.1, (z0 + z1) / 2, '#4a3020'));
      // арки дверей
      arcadeX(1.8, 5.2, z0 - 0.06, 3.1, 4.0, 1, 0.2, 0.14, IST, 0.7); arcadeX(-1.7, 1.7, z1 + 0.06, 3.1, 4.0, 1, 0.2, 0.14, IST, 0.7);
      // печь: кирпичный куб с куполом, огненные устья, труба сквозь крышу
      const FXc = -2.4, FZc = -11.5;
      B(FXc - 1.5, FZc - 1.5, FXc + 1.5, FZc + 1.5, 2.2, 'lgBrick', 0, { ch: 1 });
      D({ sph: true, r: 1.55, x: FXc, y: 2.2, z: FZc, sy: 0.55, color: '#8a4a36', seg: 10 }, cyl(0.45, 8.6, FXc, 2.2 + 4.3, FZc, '#9a5238', 0, 0, 0, 8), cyl(0.56, 0.3, FXc, 10.6, FZc, '#6a3a28', 0, 0, 0, 8));
      for (const [n, c] of [['+z', FZc + 1.5], ['-z', FZc - 1.5], ['+x', FXc + 1.5]]) { const p = at(n, c, isX(n) ? FZc : FXc, 0.02); D({ cyl: true, r: 0.36, h: 0.06, x: p[0], y: 1.05, z: p[1], color: '#ffb446', seg: 10, rx: isX(n) ? 0 : HP, rz: isX(n) ? HP : 0 }); a.lamps.push([p[0], 1.05, p[1], 1.0, '#ff8a2a']); }
      // верстаки, стеллажи с муранским стеклом, ящики, дрова
      const bench2 = (x, z, len, ax) => { hid(x - (ax ? len / 2 : 0.45), z - (ax ? 0.45 : len / 2), x + (ax ? len / 2 : 0.45), z + (ax ? 0.45 : len / 2), 0.95); D(box(ax ? len : 0.9, 0.1, ax ? 0.9 : len, x, 0.9, z, '#7a5434'), box(ax ? len - 0.2 : 0.7, 0.8, ax ? 0.7 : len - 0.2, x, 0.42, z, '#4a3424')); for (let i = 0; i < 4; i++) H({ sph: true, r: 0.09, x: x + (ax ? -len / 2 + 0.3 + i * (len - 0.6) / 3 : 0), y: 1.04, z: z + (ax ? 0 : -len / 2 + 0.3 + i * (len - 0.6) / 3), sy: 1.6, color: ['#1a8ac8', '#e8452a', '#2aa860', '#e8b020'][i], seg: 6 }); };
      bench2(4.5, -7.0, 2.6, true); bench2(-6.8, -6.0, 2.4, false); bench2(5.5, -15.6, 2.4, true);
      const rack = (x, z, len) => { hid(x - len / 2, z - 0.3, x + len / 2, z + 0.3, 2.2); D(box(len, 2.2, 0.06, x, 1.1, z, '#5a3c26')); for (const y of [0.5, 1.2, 1.9]) { D(box(len, 0.06, 0.55, x, y, z, '#6a4a2e')); for (let i = 0; i < 6; i++) H({ cyl: true, r: 0.07, r2: 0.12, h: 0.3, x: x - len / 2 + 0.25 + i * (len - 0.5) / 5, y: y + 0.18, z: z + 0.1, color: ['#1a8ac8', '#e8452a', '#2aa860', '#e8b020', '#a020a0', '#20b0c0'][(i + Math.round(y * 3)) % 6], seg: 6 }); } };
      rack(-6.0, -18.3, 3.6); rack(5.5, -4.4, 3.2); rack(0, -6.4, 3.8);
      crate(7.4, -12.4, 1.1); crate(-7.5, -14.8, 1.0); crate(-7.2, -16.2, 0.8);
      for (let r = 0; r < 3; r++) for (let i = 0; i < 5 - r; i++) D(cyl(0.16, 1.6, -3.3 + i * 0.34 + r * 0.17, 0.17 + r * 0.29, -17.9, ['#8a6a46', '#7a5a3a', '#9a7a52'][(i + r) % 3], 0, 0, HP, 7));
      hid(-3.6, -18.6, -1.5, -17.2, 0.95);
      for (const [x, z] of [[-6, -10], [5, -11.5], [0, -6.5]]) { a.lamps.push([x, 4.6, z, 1.0]); D(cyl(0.28, 0.14, x, 4.75, z, IRON, 0, 0, 0, 8), cyl(0.012, 1.3, x, 5.45, z, '#1a1a1a', 0, 0, 0, 3), { sph: true, r: 0.12, x, y: 4.6, z, color: '#fff0c8', seg: 6 }); }
      DC(13, 3.5, 4.2, z0, 2.2, 2.2, '-z', false, 2); DC(5, 7, 1.9, z0, 1.5, 3.0, '-z', true); DC(5, -6, 1.9, z0, 1.5, 3.0, '-z', true);
      DC(5, x0 + T, 1.9, -6.5, 1.4, 2.8, '+x', true); DC(14, x1 - T, 1.9, -16.5, 1.4, 2.8, '-x', true);
      // ворота мастерской к воде и пристань
      D(box(7.0, 0.1, 0.3, 0, 0.05, z1 + 0.15, IST));
    }
    // лодочные сараи по бокам пристани (встают из воды)
    house(-9, -3.5, -3.5, -1, 4.6, '#b07a5a', { faces: ['+z', '+x'], band: false, win: [] });
    house(3.5, -3.5, 9, -1, 4.6, '#b07a5a', { faces: ['+z', '-x'], band: false, win: [] });
    DC(4, -6.25, 1.5, -1, 2.4, 3.2, '+z'); DC(4, 6.25, 1.5, -1, 2.4, 3.2, '+z');
    for (const x of [-2.6, 2.6]) palina(x, -0.45, 2.8, '#f2efe6', '#2e6a4a');
    D(box(1.2, 0.5, 0.6, 2.2, 0.25, -2.6, '#5a3e2a')); hid(1.6, -2.9, 2.8, -2.3, 0.5);
    // блок C — восток от мастерской; портик вдоль фондаменты
    const CH = 10.4, PX = 16.2, PCX = 15.95;
    B(9, -26, 13, -13, CH, 'lgPlaster', 0, { tint: '#dca088' });
    B(9, -10, 13, -1, CH, 'lgPlaster', 0, { tint: '#e2c08a' });
    B(9, -13, 13, -10, CH - 3.3, 'lgPlaster', 3.3, { tint: '#dca088' });
    // второй этаж над портиком фондаменты (x 13..16.2), колонны по x = 15.95
    B(13, -24, PX, -4, CH - 3.9, 'lgPlaster', 3.9, { tint: '#e2c08a' });
    for (let k = 0; k <= 8; k++) column(PCX, -24 + k * 2.5 + (k === 0 ? 0.25 : k === 8 ? -0.25 : 0), 2.75, 0.2);
    arcadeZ(-24, -4, PCX, 2.75, 3.9, 8, 0.46, 0.44, IST);
    D(box(PX - 13, 0.12, 20, (13 + PX) / 2, 3.84, -14, '#d6c6a8'));
    cornice(9, -26, 13, -1, CH, ['-z', '+z']); cornice(13, -24, PX, -4, CH, ['+x', '-z', '+z']);
    roof(8.95, -26.05, 13.05, -0.95, CH + 0.02, 1.0, 0.5, { col: '#f2e2d6' }); roof(13, -24.05, PX + 0.05, -3.95, CH + 0.02, 0.8, 0.5, { col: '#e8d8cc' });
    chimney(11.0, -18, CH + 0.4); chimney(11.2, -7, CH + 0.4);
    windows('+x', PX, -23.6, -4.4, 4.6, 2, { kinds: [1, 2, 7, 0], noble: 0, balc: 0.4, fl: 0.5 });
    windows('+x', 13, -25.8, -24.2, 4.6, 2, { kinds: [1] }); windows('+x', 13, -3.8, -1.2, 4.6, 2, { kinds: [2] });
    windows('-z', -26, 9.4, 12.6, 4.4, 2, { kinds: [1, 2] });
    for (const [z, k] of [[-21.5, 5], [-17.5, 15], [-7.5, 14], [-4.8, 3]]) DC(k, 13, 1.65, z, 1.5, 3.0, '+x', k === 5 || k === 14);
    DC(3, 13, 1.6, -15.5, 1.4, 2.8, '+x'); DC(11, 13, 3.1, -14.5, 1.0, 1.0, '+x', false, 2);
    D(box(4.0, 0.16, 3.0, 11, 3.22, -11.5, '#5a3c26'));
    archZ(-13, -10, 13.06, 3.3); a.lamps.push([11, 2.8, -11.5, 0.8]); D(cyl(0.13, 0.28, 11, 2.85, -11.5, '#ffe2a6', 0, 0, 0, 6));
    for (let z = -22.75; z < -4; z += 5) { a.lamps.push([14.2, 3.4, z, 0.7]); D(cyl(0.12, 0.26, 14.2, 3.5, z, '#ffe2a6', 0, 0, 0, 6), cyl(0.01, 0.4, 14.2, 3.8, z, IRON, 0, 0, 0, 3)); }
    // фондамента Эст: ящики, бочки, лодка с овощами, палины, гондолы
    crate(18.6, -17.0, 1.2); crate(18.66, -16.94, 0.9, 1.2); crate(17.4, -16.6, 0.85);
    crate(18.8, -6.8, 1.0); barrel(19.0, -12.4); barrel(19.05, -11.6);
    lampPost(19.3, -25.0, 3.4); lampPost(19.3, -10.5, 3.4);
    for (const z of [-28, -21, -13, -4]) palina(20.7, z, 3.0, '#f2efe6', z % 2 ? '#c0392b' : '#2a5aa8');
    gondola(22.0, -26.2, HP, true); gondola(21.9, -8.6, -HP, false);
    // лодка-лавка с фруктами (бароне) у фондаменты
    {
      const X = 22.4, Z = -16.6;
      D({ shape: true, pts: [[-3.2, 0.7], [3.4, 0.75], [2.9, 0.0], [-2.8, 0.0]], d: 2.2, x: X, y: WL - 0.25, z: Z, color: '#3a5a6a', ry: Math.PI, cs: 1 });
      D(box(2.0, 0.06, 6.0, X, WL + 0.47, Z, '#5a3e2a'));
      for (let i = 0; i < 6; i++) { D(box(0.8, 0.26, 0.6, X - 0.45 + (i % 2) * 0.9, WL + 0.62, Z - 2.2 + Math.floor(i / 2) * 1.6, '#a8865a')); H({ sph: true, r: 0.12, x: X - 0.45 + (i % 2) * 0.9, y: WL + 0.82, z: Z - 2.2 + Math.floor(i / 2) * 1.6, color: ['#e8452a', '#f2a03a', '#7aa04a', '#f2d040', '#9a2a4a', '#e8452a'][i], seg: 5, sx: 2.5, sz: 1.8, sy: 0.5 }); }
      for (const [dx, dz] of [[-0.95, -2.8], [0.95, -2.8], [-0.95, 2.8], [0.95, 2.8]]) D(cyl(0.035, 2.0, X + dx, WL + 1.45, Z + dz, '#3a2a1e', 0, 0, 0, 4));
      D(box(2.3, 0.05, 6.2, X, WL + 2.45, Z, '#b0392b'), box(2.32, 0.24, 6.22, X, WL + 2.32, Z, '#efe6d2'));
    }
    // кампо налётчиков: колодец, деревья, скамьи, фонари; дома по южному краю
    {
      const X = 1.0, Z = -29.4;
      B(X - 1.1, Z - 1.1, X + 1.1, Z + 1.1, 0.2, 'lgIstria', 0);
      hid(X - 0.62, Z - 0.62, X + 0.62, Z + 0.62, 1.15);
      D(cyl(0.62, 0.8, X, 0.6, Z, '#ddd5c4', 0, 0, 0, 8), cyl(0.68, 0.1, X, 1.05, Z, IST2, 0, 0, 0, 8), cyl(0.45, 0.02, X, 1.1, Z, '#3a3a36', 0, 0, 0, 8));
    }
    tree(-14, -29.6, 7.5); tree(9, -30.2, 7.0, 0.9);
    bench(-10.5, -32.0); bench(5.5, -32.2); lampPost(-19.5, -27.2, 3.4); lampPost(-4.5, -26.8, 3.4); lampPost(12, -27.0, 3.4);
    crate(-21.4, -31.4, 1.1); crate(-20.2, -31.8, 0.85); crate(16.4, -30.4, 1.0);
    // южный край: фасады домов (граница карты)
    const SH = [[-26, -15, 10.4, '#d99a7c'], [-15, -4, 11.6, '#e9cf9a'], [-4, 7, 10.2, '#c8705a'], [7, 20, 11.2, '#e2b07a']];
    for (const [x0, x1, h, col] of SH) house(x0, -36, x1, -33, h, col, { faces: ['+z'], band: 4.0, win: [['+z', x0 + 0.5, x1 - 0.5, 2, { kinds: [1, 2, 7, 1, 0], fl: 0.45 }]] });
    for (const [x, k, lit] of [[-21, 3, false], [-17.5, 15], [-10, 5, true], [-6.5, 15], [-1, 3], [3.5, 14, true], [10, 3], [14.5, 15], [17.5, 5, true]]) DC(k, x, 1.6, -33, 1.5, 3.0, '+z', !!lit);
    DC(10, -10, 3.6, -33, 1.4, 1.4, '+z', false, 1); DC(11, 1, 2.8, -33, 1.0, 1.0, '+z', false, 2);
    a.awning(-10, 3.2, -33, 3.4, 1.4, '+z', '#2f5a4a'); a.awning(3.5, 3.2, -33, 3.0, 1.3, '+z', '#b0392b');
    // мост-дом через рио Эст на южной границе и торцы дворца
    house(20, -36, 30, -33, 10.6, '#cf8a68', { faces: ['+z', '-x'], band: 4.0, win: [['+z', 20.4, 25.6, 2, { kinds: [1, 2] }]] , y0: 2.6 });
    arcadeX(20, 26, -32.94, WL, 2.6, 1, 0.3, 0.14, IST);
    house(16, -50, 32, -44, 12.0, '#d8a888', { faces: ['+z'], band: false, win: [] });
    // фасады блоков к кампо налётчиков
    windows('-z', -26, -16.6, -9.4, 4.4, 1, { kinds: [1] });
    DC(15, -12.5, 1.6, -26, 1.5, 3.0, '-z'); DC(3, -15.0, 1.6, -26, 1.5, 3.0, '-z'); DC(15, 11, 1.6, -26, 1.5, 3.0, '-z');
    // восточный берег рио Эст (граница): дома встают из воды
    const EH = [[-33, -22, 11.4, '#e6b88a'], [-22, -12, 10.2, '#d48a70'], [-12, -1, 12.0, '#efd9b0']];
    for (const [z0, z1, h, col] of EH) { house(26, z0, 32, z1, h, col, { faces: ['-x'], band: 4.0, win: [['-x', z0 + 0.5, z1 - 0.5, 2, { kinds: [1, 2, 7, 0], fl: 0.5, balc: 0.5, noble: 0 }]] }); wetBase('-x', z0, z1, 26); }
    for (const z of [-27, -17, -6.5]) DC(4, 26, 1.0, z, 2.2, 3.0, '-x');

    // =================== за границей: западный канал, устья, лагуна и острова ===================
    // дома на дальнем берегу западного канала (видны из корте и с ривы)
    const WB = [[-1, 9, 10.8, '#e0a882'], [9, 19, 12.2, '#efd6a6'], [19, 29, 10.4, '#c9765a']];
    for (const [z0, z1, h, col] of WB) { house(-40, z0, -33, z1, h, col, { faces: ['+x'], band: 4.0, win: [['+x', z0 + 0.5, z1 - 0.5, 2, { kinds: [1, 2, 7, 0], fl: 0.5 }]] }); wetBase('+x', z0, z1, -33); }
    // устье у церкви: дом на дальнем берегу
    house(33, 23, 40, 36, 11.4, '#e4c08e', { faces: ['-x'], band: 4.0, win: [['-x', 23.5, 35.5, 2, { kinds: [1, 2, 0] }]] }); wetBase('-x', 23, 36, 33);
    house(26, -1, 34, 5, 9.6, '#d8987a', { faces: ['-x'], band: false, y0: 2.4, win: [] });
    arcadeZ(-1, 5, 25.94, WL, 2.4, 1, 0.3, 0.14, IST);
    house(-34, -1, -26, 5, 9.2, '#e0b080', { faces: ['+x'], band: false, y0: 2.4, win: [] });
    arcadeZ(-1, 5, -25.94, WL, 2.4, 1, 0.3, 0.14, IST);
    house(-40, -14, -26, -1, 10.6, '#d6a070', { faces: ['+x'], roof: true, win: [] });
    // гондолы у ривы (за кромкой), палины, пристань вапоретто
    for (let i = 0; i < 4; i++) { const x = -19 + i * 2.2; palina(x - 1.1, 37.0, 3.2, '#f2efe6', '#2a5aa8'); gondola(x, 41.6, HP, i % 2 === 0); }
    palina(-19 + 4 * 2.2 - 1.1, 37.0, 3.2, '#f2efe6', '#2a5aa8');
    {
      const X = 8, Z = 38.6;
      D(box(9.0, 0.5, 3.4, X, WL + 0.6, Z, '#3a3a38'), box(9.1, 0.12, 3.5, X, WL + 0.9, Z, '#e8c040'));
      D(box(7.0, 0.1, 2.6, X, 2.2 + WL + 0.9, Z, '#f2efe6'), box(7.2, 0.3, 2.8, X, 2.35 + WL + 0.9, Z, '#e8c040'));
      for (const dx of [-3.3, 3.3]) for (const dz of [-1.1, 1.1]) D(cyl(0.05, 2.2, X + dx, WL + 2.0, Z + dz, '#f2efe6', 0, 0, 0, 5));
      D(box(0.04, 1.4, 2.4, X - 3.4, WL + 1.7, Z, '#9ab8c8'), box(7.0, 1.4, 0.04, X, WL + 1.7, Z + 1.25, '#9ab8c8'));
      for (const dx of [-4.0, 4.0]) D(cyl(0.18, 3.0, X + dx, WL + 1.0, Z + 1.9, '#5a4a3a', 0, 0, 0, 6));
      D(box(2.0, 0.12, 1.2, X, 0.02, 36.7, '#4a3a2a'), box(2.1, 1.05, 0.06, X, 0.55, 36.14, IRON), box(0.08, 1.2, 0.08, X - 1.05, 0.6, 36.14, IRON), box(0.08, 1.2, 0.08, X + 1.05, 0.6, 36.14, IRON));
    }
    // острова на горизонте (только высокое качество): церковь с куполом и кампанилой, ряды домов, кипарисы
    {
      const isle = (cx, cz, w, d, hue) => { H(box(w, 1.6, d, cx, WL + 0.3, cz, '#7c7a62')); for (let i = 0; i < Math.floor(w / 7); i++) { const x = cx - w / 2 + 3 + i * 7 + R(-1, 1), h = R(7, 12); H(box(R(5, 7), h, R(6, 9), x, h / 2, cz + R(-2, 2), pick(hue))); H({ cyl: true, r: 0.1, r2: R(4.2, 5.2), h: 2.2, x, y: h + 1.1, z: cz, color: '#a0603e', seg: 4, ry: Math.PI / 4 }); } };
      const HUE = ['#d8b494', '#e2c8a4', '#c98c6c', '#e8d4b4', '#c4a48a'];
      isle(-60, 140, 70, 18, HUE); isle(45, 175, 60, 16, HUE); isle(-140, 90, 40, 14, HUE);
      // церковь острова
      const X = -40, Z = 132;
      H(box(16, 13, 20, X, 6.5, Z, '#ece6d9'), { shape: true, pts: [[-8, 0], [0, 4.5], [8, 0]], d: 1, x: X, y: 13, z: Z - 10.2, color: '#e2dccf', ry: -HP, cs: 1 });
      H(cyl(5.2, 4, X, 15, Z + 2, '#e2dccf', 0, 0, 0, 16), { sph: true, r: 5.3, x: X, y: 17, z: Z + 2, sy: 1.15, color: '#8a9898', seg: 16, hs: 8 }, cyl(0.9, 2.5, X, 24, Z + 2, '#ece6d9', 0, 0, 0, 8));
      H(box(4.6, 30, 4.6, X + 13, 15, Z + 4, '#c97a5a'), box(5.2, 4, 5.2, X + 13, 32, Z + 4, '#ece6d9'), { cyl: true, r: 0.1, r2: 3.6, h: 7, x: X + 13, y: 37.5, z: Z + 4, color: '#5e9078', seg: 4, ry: Math.PI / 4 });
      for (let i = 0; i < 9; i++) H({ cyl: true, r: 0.05, r2: R(1.0, 1.4), h: R(7, 10), x: X - 30 + i * 3.6, y: 4.5, z: Z + 6, color: '#2f4a32', seg: 6 });
    }
  }

  // ---------- описание карт ----------
  G.DUEL_MAP = 'winter';
  G.MAPS = {
    dust: {
      name: 'Пыльный квартал', sub: 'Полдень · старый город, мечеть и караван-сарай', scale: 1, bounds: { x0: -44, x1: 44, z0: -34, z1: 34 },
      layout: layoutDust, ground: { mat: 'dsGround', size: [112, 92], repeat: 5 }, lite: true, scatterHi: true,
      matScale: { dsStone: 3.4, dsAdobe: 3.6, flag: 3.2, cotto: 1.6, planks: 2.2, crate: 1, dsGround: 5 },
      blossomTex: 'leaves', blossomAmp: 0.15,
      env: {
        skyTop: '#3d7cc6', skyMid: '#86b2dc', skyHor: '#f1dcb4', skyLow: '#d8b886', fog: '#ecd6ac', fogNear: 60, fogFar: 230,
        hemiSky: '#e2eaff', hemiGround: '#b88c58', hemiI: 0.8, sun: '#ffe4b4', sunI: 1.18, sunPos: [42, 44, -26],
        sunSprite: [200, 120, -130], sunSpriteColor: '#fff2d2', sunSize: 46, clouds: '#fff6e6', cloudN: 6,
        dune: '#d8b27a', mount: '#c99e66', rock: '#a87a4a', mountH: 0.55, vmTint: '#ffeed4'
      },
      // 2.0: спавн налётчиков отодвинут к воротам на 1,3 м (12.0 и 2.0-симуляции: карта склонялась к налётчикам)
      spawnZones: [{ x0: -8, x1: 8, z0: 26.5, z1: 31.5, yaw: 0 }, { x0: -8, x1: 8, z0: -33.2, z1: -28.4, yaw: Math.PI }],
      sites: { A: { x0: 23, x1: 41, z0: 11, z1: 21 }, B: { x0: -37, x1: -22, z0: 1, z1: 15 } }
    },
    harbor: {
      name: 'Порт', sub: 'Закат · портовый квартал, апартаменты и причал', scale: 1, bounds: { x0: -44, x1: 44, z0: -34, z1: 34 },
      layout: layoutHarbor, ground: { mat: 'hbCobble', size: [98, 78], repeat: 4.8 }, lite: true,
      matScale: { hbPlaster: 4.2, brick: 3, corrug: 3, concrete: 4, metal: 2, planks: 2.2, pave: 2.6, cotto: 1.6, crate: 1, hbCont: 2.6, hbSlab: 5 },
      roofTex: 'coppo', blossomTex: 'leaves', blossomAmp: 0.13, scatterHi: true,
      env: {
        skyTop: '#2c3a72', skyHor: '#ffb07a', skyLow: '#b8806a', skyMid: '#c9708a', fog: '#e9a47f', fogNear: 55, fogFar: 230,
        hemiSky: '#b4bce6', hemiGround: '#b67a50', hemiI: 0.72, sun: '#ffb870', sunI: 1.15, sunPos: [58, 30, -22],
        sunSprite: [260, 48, -80], sunSpriteColor: '#ffd08a', sunSize: 70, clouds: '#ffc9a8', cloudN: 12,
        water: { level: -1.3, deep: '#1b2c4a', shallow: '#3d6880', sky: '#f2a283', x0: 44 }, vmTint: '#ffd9b0', noCity: true
      },
      spawnZones: [{ x0: -9, x1: 9, z0: 26.5, z1: 31.5, yaw: 0 }, { x0: -9, x1: 9, z0: -31.5, z1: -26.5, yaw: Math.PI }],
      sites: { A: { x0: 26, x1: 43, z0: 5, z1: 24 }, B: { x0: -40, x1: -20, z0: 4, z1: 20 } }
    },
    sakura: {
      name: 'Сакура', sub: 'Весна · старый квартал, храм и крытый рынок', scale: 1, bounds: { x0: -42, x1: 42, z0: -34, z1: 34 },
      layout: layoutSakura, ground: { mat: 'skGround', size: [100, 84], repeat: 6 }, lite: true, scatterHi: true, blossomAmp: 0.1, roofTex: 'skKawara',
      matScale: { stonewall: 2.6, plaster: 3.4, gravel: 4, planks: 2.4, tatami: 1.8, crate: 1, skMachiya: 5.8, bamboo: 2.4 },
      env: {
        skyTop: '#5d9ade', skyMid: '#a8c8ec', skyHor: '#fbe3ea', skyLow: '#e3c4ce', fog: '#f1dde4', fogNear: 55, fogFar: 200,
        hemiSky: '#f4f0ff', hemiGround: '#8d7c74', hemiI: 0.84, sun: '#fff0e0', sunI: 0.95, sunPos: [-34, 52, -26],
        sunSprite: [-150, 115, -170], sunSpriteColor: '#fff4e6', sunSize: 42, clouds: '#ffffff', cloudN: 10,
        mount: '#5f7d84', rock: '#45605a', mountH: 0.5, fuji: [20, 320], vmTint: '#fff0ec'
      },
      spawnZones: [{ x0: -9, x1: 9, z0: 25, z1: 30, yaw: 0 }, { x0: -9, x1: 9, z0: -31, z1: -26, yaw: Math.PI }],
      sites: { A: { x0: -32, x1: -20, z0: 12, z1: 25 }, B: { x0: 24, x1: 34, z0: 7, z1: 23 } }
    },
    winter: {
      name: 'Неоновая крыша', sub: 'Ночь · кровля небоскрёба · дуэли 1 на 1', scale: 1, bounds: { x0: -18, x1: 18, z0: -24, z1: 24 }, duel: true,
      layout: layoutNeon, ground: { mat: 'ntDeck', size: [40, 52], repeat: 8 }, lite: true, scatterHi: true,
      matScale: { ntConc: 3.4, ntHvac: 2.4, planks: 2.2 },
      env: {
        skyTop: '#070b2a', skyMid: '#2b2a72', skyHor: '#d0509e', skyLow: '#3d2656', fog: '#2d2458', fogNear: 30, fogFar: 125,
        hemiSky: '#9aa0ff', hemiGround: '#5a3d78', hemiI: 0.92, sun: '#b4c4ff', sunI: 0.86, sunPos: [-30, 48, 22],
        sunSprite: [-170, 120, 150], sunSpriteColor: '#dfe8ff', sunSize: 34, clouds: '#5a4a96', cloudN: 6,
        stars: 220, cityTex: 'ntCityWin', vmTint: '#c9d2ff'
      },
      spawnZones: [{ x0: -4, x1: 4, z0: 19.5, z1: 23, yaw: 0 }, { x0: -4, x1: 4, z0: -23, z1: -19.5, yaw: Math.PI }],
      sites: { A: { x0: -12, x1: -8, z0: 8, z1: 12 }, B: { x0: 8, x1: 12, z0: -12, z1: -8 } }
    },
    villa: {
      name: 'Перрон', sub: 'Осень · пригородная станция · 2 на 2', small: true, scale: 1, bounds: { x0: -27, x1: 27, z0: -38, z1: 38 },
      layout: layoutPerron, ground: { mat: 'prAsph', size: [58, 80], repeat: 4.5 }, lite: true,
      matScale: { prBrick: 2.6, prBallast: 2.8, prTile: 2.4, prWagon: 3.2, plaster: 3.4 },
      roofTex: 'prSeam', blossomTex: 'leaves', blossomAmp: 0.16, scatterHi: true, petalTex: 'prLeaf', petalCol: '#ffffff', petalSize: 0.24, petalHi: true,
      // золотой час: низкое тёплое солнце, медовая дымка, длинные тени
      env: {
        skyTop: '#3f66b0', skyMid: '#9bb6d8', skyHor: '#ffd29a', skyLow: '#e0b07c', fog: '#ecc89c', fogNear: 55, fogFar: 200,
        hemiSky: '#ffe6c8', hemiGround: '#946a42', hemiI: 0.76, sun: '#ffc27c', sunI: 1.22, sunPos: [42, 24, -30],
        sunSprite: [190, 56, -135], sunSpriteColor: '#ffdc98', sunSize: 58, clouds: '#ffdcb4', cloudN: 9,
        mount: '#7d6e48', rock: '#5d5e40', mountH: 0.75, vmTint: '#ffe2bc'
      },
      spawnZones: [{ x0: -6, x1: 4, z0: 32.8, z1: 35.8, yaw: 0 }, { x0: -6, x1: 6, z0: -36.6, z1: -32.4, yaw: Math.PI }],
      sites: { A: { x0: -12, x1: 13, z0: 8.6, z1: 21 } },
      // точки сбора налётчиков на трёх маршрутах: длинный (восток), пакгауз (центр), гаражи (запад)
      stages: [[21.5, -14.5], [-6.2, -19.2], [-14.5, -13.5]], stageWait: [5, 11],
      // закладка: у входов на платформу за укрытием от вокзала (ближайшая к точке сбора)
      plantSpots: [[0.5, 9.5], [-0.5, 10.5], [10.5, 12.5], [12.5, 10.5], [-2.5, 12.5], [9.5, 11.5]],
      // позиции спецназа: s — на точке, r — дальше (страхует обход и возвращает точку); [x, z, смотреть на x, z, вид]
      holds: [[6.2, 19.4, 4, 8, 's'], [-7.4, 21.6, -2, 9, 's'], [12.2, 18.6, 4, 9, 's'], [-12.6, 21.4, -12, 9, 's'],
        [-3.4, 28.8, 0.5, 23, 'r'], [-22, 19.5, -14, 17.5, 'r'], [8.2, 25.0, 4, 20, 'r'], [-12, 27.6, -12, 22, 'r']]
    },
    lagoon: {
      name: 'Лагуна', sub: 'Закат · каналы и мосты · 2 на 2', small: true, scale: 1, bounds: { x0: -26, x1: 26, z0: -33, z1: 36 },
      layout: layoutLagoon, ground: { none: true, mat: 'lgPave', size: [52, 69], repeat: 2.8 }, lite: true,
      // 2.0: вода под картой — всё, что вне суши (набережные с кромками и мосты), лагуна на уровне y; движок считает
      // пол y = 0 везде, а над водой пули, гранаты и выброшенное оружие спрашивают G.map.waterAt (клиент и сервер)
      wet: { y: LG_WL, land: [[-26, -33, 20, -1], [-26, 5, 26, 36], [-23, -2.1, -19, 6.1], [13, -2.1, 17, 6.1]] },
      matScale: { lgPave: 2.8, lgPlaster: 3.8, lgBrick: 2.0, lgIstria: 2.6, crate: 1 },
      roofTex: 'coppo', blossomTex: 'leaves', blossomAmp: 0.14,
      // закат над лагуной: низкое солнце с запада-северо-запада, медовая дымка, блики на воде
      env: {
        skyTop: '#3b5c9c', skyMid: '#a3b3cf', skyHor: '#ffcb8e', skyLow: '#e3a876', fog: '#e8c099', fogNear: 60, fogFar: 240,
        hemiSky: '#ffe0c0', hemiGround: '#8c6a4c', hemiI: 0.8, sun: '#ffc07a', sunI: 1.24, sunPos: [-44, 30, 20],
        sunSprite: [-205, 52, 92], sunSpriteColor: '#ffd68e', sunSize: 62, clouds: '#ffcfa8', cloudN: 10,
        mount: '#8e8aa0', rock: '#a8a2b4', mountH: 0.42,
        water: { level: LG_WL, deep: '#1c3a44', shallow: '#3e6a6c', sky: '#f0b888', x0: -450 }, vmTint: '#ffe0bc', noCity: true
      },
      spawnZones: [{ x0: -5, x1: 5, z0: 30.6, z1: 34.2, yaw: 0 }, { x0: -6, x1: 6, z0: -32.4, z1: -28.4, yaw: Math.PI }],
      sites: { A: { x0: -10.5, x1: 16.5, z0: 5.5, z1: 22.6 } },
      // точки сбора налётчиков: калле Овест (запад), мастерская (центр), фондамента Эст (восток)
      stages: [[-20, -11], [3, -12.5], [11.6, -11.5]], stageWait: [7, 15],
      // закладка за укрытиями у входов на кампо
      plantSpots: [[-8.2, 7.2], [-9.8, 15.4], [11.2, 9.4], [14.6, 11.6], [-2.6, 6.3], [8.6, 7.6]],
      // позиции спецназа: s — на точке, r — дальше (страхует обход и возвращает точку); [x, z, смотреть на x, z, вид]
      holds: [[1.8, 18.6, 14.5, 4.5, 's'], [-8.0, 21.6, -11.5, 17.5, 's'], [14.8, 16.2, 15, 4, 's'], [-3.0, 15.6, -14, 8, 's'], [15.4, 19.4, 8, 5, 's'],
        [-1.0, 24.6, 0, 12, 'r'], [9.0, 24.6, 10, 10, 'r'], [-16.5, 17.8, -16.5, 11.5, 'r']]
    },
    range: {
      name: 'Полигон', sub: 'Обучение', scale: 1, bounds: { x0: -21, x1: 21, z0: -17, z1: 17 }, hidden: true,
      layout: layoutRange, ground: { mat: 'asphalt', size: [44, 36], repeat: 6 },
      matScale: { corrug: 3, concrete: 3, roof: 3, pave: 4, metal: 2, hazard: 2, planks: 3, contGreen: 2.6, contBlue: 2.6, crate: 1, sand: 4 },
      env: {
        skyTop: '#4f8fd2', skyHor: '#dfe6ea', skyLow: '#b9b2a4', fog: '#d6d9d6', fogNear: 50, fogFar: 170,
        hemiSky: '#d6e6ff', hemiGround: '#8f8678', hemiI: 0.8, sun: '#fff3dc', sunI: 1.0, sunPos: [26, 58, 18],
        sunSprite: [110, 170, 60], sunSpriteColor: '#fff6dc', sunSize: 38, clouds: '#ffffff', cloudN: 9, dune: '#8f8a7e', mount: '#6f7a78', vmTint: '#fff4e4'
      },
      spawnZones: [{ x0: -2, x1: 2, z0: 12, z1: 15, yaw: 0 }, { x0: -2, x1: 2, z0: 12, z1: 15, yaw: 0 }],
      sites: { A: { x0: -18, x1: -10, z0: -14, z1: -6 } },
      // данные обучения: манекены [x, z, yaw], центр ямы, точка закладки
      tut: { dummies: [[-5, -16, Math.PI], [0, -16, Math.PI], [5, -16, Math.PI], [13, -9, HP], [15, -11, HP], [-12, 9, -HP]], pit: [14, -10], look: [-12, 9], site: { x0: -18, x1: -10, z0: -14, z1: -6 } }
    }
  };

  // ---------- материалы ----------
  const NM = [];
  // материал с рельефом: карта нормалей строится из яркости текстуры
  // 2.2 perf: карта нормалей нужна только «Высокому» (рельеф) — строим её при первом включении, а не при сборке
  // каждой карты на любом качестве (чтение пикселей холста + размытие + запись: заметная доля времени загрузки карты
  // на телефоне и лишние холсты в памяти). На «Высоком» — та же текстура, что и раньше
  const nmOf = (m) => m.userData.nm || (m.userData.nm = m.userData.nmF());
  const lam = (name, arg, ns) => {
    const m = new THREE.MeshLambertMaterial({ map: G.tex(name, arg), vertexColors: true });
    m.userData.nm = null; m.userData.nmF = () => G.normalTex(name, arg); m.userData.ns = ns || 1;
    if (G.settings.quality === 'high') { m.normalMap = nmOf(m); m.normalScale = new THREE.Vector2(m.userData.ns, m.userData.ns); }
    NM.push(m);
    if (G.vlitMat) G.vlitMat(m); // 2.1 perf: свет плоских граней — в вершинах (util.js; с картой нормалей — попиксельно, как раньше)
    return m;
  };
  const MAT_FACTORY = {
    wall: () => lam('wall', null, 1.3), stucco: () => lam('stucco', null, 0.7), concrete: () => lam('concrete', null, 0.8),
    roof: () => lam('roof', null, 1), pave: () => lam('pave', null, 1.2), metal: () => lam('metal', null, 0.9), crate: () => lam('crate', null, 1.2),
    contRed: () => lam('container', '#9c3b2c', 1.5), contBlue: () => lam('container', '#2f5d86', 1.5),
    contGreen: () => lam('container', '#4d6b3a', 1.5), contOrange: () => lam('container', '#c46a1f', 1.5),
    brick: () => lam('brick', null, 1.4), corrug: () => lam('corrug', '#7d8b95', 1.6), planks: () => lam('planks', null, 1.3),
    hazard: () => lam('hazard', null, 0.6), asphalt: () => lam('asphalt', null, 0.8), sand: () => lam('sand', null, 0.9),
    machiya: () => lam('machiya', null, 0.8), kura: () => lam('kura', null, 0.9), shrine: () => lam('shrine', null, 0.6),
    stonewall: () => lam('stonewall', null, 1.5), plaster: () => lam('plaster', null, 0.4), jpstone: () => lam('jpstone', null, 1.0),
    gravel: () => lam('gravel', null, 0.8), bamboo: () => lam('bamboo', null, 1.3), tatami: () => lam('tatami', null, 0.5),
    koshi: () => lam('koshi', null, 1.4), hedge: () => lam('hedge', null, 1.2),
    snow: () => lam('snow', null, 0.5),
    ntDeck: () => lam('ntDeck', null, 0.8), ntConc: () => lam('ntConc', null, 1.2), ntHvac: () => lam('ntHvac', null, 1.1),
    flag: () => lam('flag', null, 0.9), cotto: () => lam('cotto', null, 0.9),
    prBrick: () => lam('prBrick', null, 1.3), prBallast: () => lam('prBallast', null, 1.4),
    prTile: () => lam('prTile', null, 0.9), prWagon: () => lam('prWagon', null, 1.2), prAsph: () => lam('prAsph', null, 0.8)
  };
  G.mapDetail = (on) => {
    for (const m of NM) { m.normalMap = on ? nmOf(m) : null; if (on) m.normalScale = new THREE.Vector2(m.userData.ns, m.userData.ns); m.needsUpdate = true; }
  };
  // дальний фон за картой (горы, дюны, город, облака) — только на высоком качестве
  const BACKDROP = [], LITE = [];
  G.mapBackdrop = (on) => { for (const o of BACKDROP) o.visible = !!on; for (const o of LITE) o.visible = !on; };
  // упрощённая копия декора для низкого/среднего качества (карты с def.lite): меньше сегментов, без мелочи
  function litePart(p) {
    if (p.hiOnly) return null;
    const sx = p.sx || 1, sy = p.sy || 1, sz = p.sz || 1;
    if (p.cyl) {
      const r = Math.max(p.r, p.r2 != null ? p.r2 : p.r) * Math.max(sx, sz), seg = p.seg || 10, h = p.h * sy;
      if (r < 0.025 || (r < 0.03 && h < 0.6)) return null;
      const s = Math.min(seg, r < 0.1 ? 3 : r < 0.22 ? 4 : r < 0.6 ? Math.max(5, Math.round(seg * 0.55)) : Math.max(8, Math.round(seg * 0.7)));
      // тонкие длинные палки (стволы, ветви, коньки, гребни): торцы не видны — без крышек
      const open = p.open || (r < 0.3 && h > r * 2.5);
      return s === seg && open === !!p.open ? p : Object.assign({}, p, { seg: s, open });
    }
    if (p.sph) {
      const r = p.r * Math.max(sx, sy, sz), seg = p.seg || 10;
      if (r < 0.085) return null;
      // по высоте не меньше 4 поясов: иначе крона читается «ромбом»
      const s = Math.min(seg, r < 1.2 ? 5 : Math.max(6, Math.round(seg * 0.75)));
      return Object.assign({}, p, { seg: s, hs: r < 0.3 ? 3 : 4 });
    }
    if (p.torus) { const s = Math.max(8, Math.round((p.seg || 14) * 0.6)); return Object.assign({}, p, { seg: s }); }
    if (p.shape) return (p.cs || 5) > 3 ? Object.assign({}, p, { cs: 3 }) : p;
    if (p.w != null) { const d = [p.w, p.h, p.d].sort((a, b) => a - b); if (d[2] < 0.12 || d[1] < 0.04) return null; }
    return p;
  }
  const liteList = (list) => { const out = []; for (const p of list) { const q = litePart(p); if (q) out.push(q); } return out; };
  const matCache = {};
  const getMat = (k) => matCache[k] || (matCache[k] = MAT_FACTORY[k]());
  const _tc = new THREE.Color();

  function addBox(buf, b, scale) {
    const { x0, y0, z0, x1, y1, z1 } = b;
    const faces = [
      { n: [1, 0, 0], c: [[x1, y0, z0], [x1, y0, z1], [x1, y1, z1], [x1, y1, z0]] },
      { n: [-1, 0, 0], c: [[x0, y0, z1], [x0, y0, z0], [x0, y1, z0], [x0, y1, z1]] },
      { n: [0, 1, 0], c: [[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]] },
      { n: [0, -1, 0], c: [[x0, y0, z1], [x1, y0, z1], [x1, y0, z0], [x0, y0, z0]] },
      { n: [0, 0, 1], c: [[x1, y0, z1], [x0, y0, z1], [x0, y1, z1], [x1, y1, z1]] },
      { n: [0, 0, -1], c: [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0]] }
    ];
    for (const f of faces) {
      if (f.n[1] === -1 && y0 <= 0.001 && y0 >= -0.001) continue;
      if (y1 - y0 < 0.05 && f.n[1] !== 1) continue; // тонкие «наклейки» — только верх
      let c = f.c;
      const ax = c[1][0] - c[0][0], ay = c[1][1] - c[0][1], az = c[1][2] - c[0][2];
      const bx = c[2][0] - c[0][0], by = c[2][1] - c[0][1], bz = c[2][2] - c[0][2];
      const cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
      if (cx * f.n[0] + cy * f.n[1] + cz * f.n[2] < 0) c = [c[0], c[3], c[2], c[1]];
      const base = buf.pos.length / 3;
      for (const v of c) {
        buf.pos.push(v[0], v[1], v[2]);
        buf.nor.push(f.n[0], f.n[1], f.n[2]);
        let u, w;
        if (b.uv === 'face') {
          if (f.n[0] !== 0) { u = (v[2] - z0) / (z1 - z0); w = (v[1] - y0) / (y1 - y0); }
          else if (f.n[1] !== 0) { u = (v[0] - x0) / (x1 - x0); w = (v[2] - z0) / (z1 - z0); }
          else { u = (v[0] - x0) / (x1 - x0); w = (v[1] - y0) / (y1 - y0); }
        } else {
          if (f.n[0] !== 0) { u = v[2] / scale; w = v[1] / scale; }
          else if (f.n[1] !== 0) { u = v[0] / scale; w = v[2] / scale; }
          else { u = v[0] / scale; w = v[1] / scale; }
        }
        buf.uv.push(u, w);
        let ao = 1;
        if (f.n[1] === 0 && v[1] <= 0.01 && y0 <= 0.01) ao = 0.6;
        else if (f.n[1] === 0 && v[1] < 1.2 && y0 <= 0.01) ao = 0.6 + 0.4 * (v[1] / 1.2);
        if (f.n[1] === -1) ao = 0.72;
        buf.col.push(ao, ao, ao);
      }
      buf.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }

  // ---------- борьба с мерцанием совпадающих плоскостей (z-fighting) ----------
  // Если грань коробки лежит в той же плоскости, что и грань более ранней коробки (и смотрит туда же),
  // а материалы/развёртка отличаются — на телефоне они «дерутся» за пиксели. Сдвигаем такую грань
  // (только визуально, коллизии не меняются) на несколько миллиметров наружу, слоями.
  const ZSTEP = 0.009, ZEPS = 0.004;
  function deZFight(list) {
    const bucket = new Map(), out = [];
    const sides = (b, thin) => {
      const r = [{ k: 'py', ax: 1, s: 1, v: b.y1, a0: b.x0, a1: b.x1, b0: b.z0, b1: b.z1 }];
      if (!thin) r.push(
        { k: 'px', ax: 0, s: 1, v: b.x1, a0: b.y0, a1: b.y1, b0: b.z0, b1: b.z1 }, { k: 'nx', ax: 0, s: -1, v: b.x0, a0: b.y0, a1: b.y1, b0: b.z0, b1: b.z1 },
        { k: 'pz', ax: 2, s: 1, v: b.z1, a0: b.x0, a1: b.x1, b0: b.y0, b1: b.y1 }, { k: 'nz', ax: 2, s: -1, v: b.z0, a0: b.x0, a1: b.x1, b0: b.y0, b1: b.y1 });
      return r;
    };
    for (const b of list) {
      const thin = b.y1 - b.y0 < 0.05, off = {};
      const fs = sides(b, thin);
      for (const f of fs) {
        let layer = 0;
        const kk = Math.round(f.v / 0.01);
        for (let d = -1; d <= 1; d++) {
          const L = bucket.get(f.ax + '|' + f.s + '|' + (kk + d)); if (!L) continue;
          for (const q of L) {
            if (Math.abs(q.v - f.v) > ZEPS) continue;
            if (q.mat === b.mat && q.uv !== 'face' && b.uv !== 'face') continue;
            if (Math.min(q.a1, f.a1) - Math.max(q.a0, f.a0) <= 0.01 || Math.min(q.b1, f.b1) - Math.max(q.b0, f.b0) <= 0.01) continue;
            layer = Math.max(layer, q.layer + 1);
          }
        }
        if (layer) off[f.k] = layer * ZSTEP;
        f.layer = layer; f.mat = b.mat; f.uv = b.uv;
        const key = f.ax + '|' + f.s + '|' + kk;
        if (!bucket.has(key)) bucket.set(key, []);
        bucket.get(key).push(f);
      }
      if (Object.keys(off).length) {
        const nb = Object.assign({}, b);
        nb.x1 += off.px || 0; nb.x0 -= off.nx || 0; nb.y1 += off.py || 0; nb.z1 += off.pz || 0; nb.z0 -= off.nz || 0;
        out.push(nb);
      } else out.push(b);
    }
    return out;
  }
  // декоративные брусья/доски вровень со стеной — чуть «выдвигаем» из стены
  function unflushDecor(dec, list) {
    if (!dec || !dec.length) return;
    const planes = { 0: new Map(), 1: new Map(), 2: new Map() };
    const put = (ax, v, a0, a1, b0, b1, c) => { const k = Math.round(v / 0.01); if (!planes[ax].has(k)) planes[ax].set(k, []); planes[ax].get(k).push([v, a0, a1, b0, b1, c]); };
    const putBox = (b, c) => {
      put(0, b.x0, b.y0, b.y1, b.z0, b.z1, c); put(0, b.x1, b.y0, b.y1, b.z0, b.z1, c);
      put(2, b.z0, b.x0, b.x1, b.y0, b.y1, c); put(2, b.z1, b.x0, b.x1, b.y0, b.y1, c);
      put(1, b.y1, b.x0, b.x1, b.z0, b.z1, c);
    };
    for (const b of list) putBox(b, null);
    const hit = (ax, v, a0, a1, b0, b1, c) => {
      const k = Math.round(v / 0.01);
      for (let d = -1; d <= 1; d++) { const L = planes[ax].get(k + d); if (!L) continue;
        for (const q of L) if (q[5] !== c && Math.abs(q[0] - v) < ZEPS && Math.min(q[2], a1) - Math.max(q[1], a0) > 0.005 && Math.min(q[4], b1) - Math.max(q[3], b0) > 0.005) return true; }
      return false;
    };
    for (const d of dec) {
      if (d.cyl || d.sph || d.torus || d.shape || d.rx || d.ry || d.rz || d.w == null || d._uf) continue;
      let x0 = d.x - d.w / 2, x1 = d.x + d.w / 2, y0 = d.y - d.h / 2, y1 = d.y + d.h / 2, z0 = d.z - d.d / 2, z1 = d.z + d.d / 2;
      const c = d.color || '#fff';
      if (hit(0, x0, y0, y1, z0, z1, c) || hit(0, x1, y0, y1, z0, z1, c) || hit(2, z0, x0, x1, y0, y1, c) || hit(2, z1, x0, x1, y0, y1, c) || hit(1, y1, x0, x1, z0, z1, c)) {
        const e = Math.min(0.01, d.w * 0.2, d.d * 0.2);
        d.w += 2 * e; d.d += 2 * e; d.h += 0.012; d.y += 0.006; d._uf = true;
        x0 -= e; x1 += e; z0 -= e; z1 += e; y1 += 0.012;
      }
      putBox({ x0, x1, y0, y1, z0, z1 }, c);
    }
  }

  // ===================== реализм: фаски, карнизы, контактные тени, мелочи на земле =====================
  // какие грани коробки упираются в соседнюю коробку (там фаску не делаем — была бы щель)
  function computeAttach(list) {
    const idx = new Map();
    const add = (k, e) => { if (!idx.has(k)) idx.set(k, []); idx.get(k).push(e); };
    list.forEach((b, i) => {
      add('x' + Math.round(b.x0 * 50), [i, -1, b.x0, b.y0, b.y1, b.z0, b.z1]); add('x' + Math.round(b.x1 * 50), [i, 1, b.x1, b.y0, b.y1, b.z0, b.z1]);
      add('z' + Math.round(b.z0 * 50), [i, -1, b.z0, b.x0, b.x1, b.y0, b.y1]); add('z' + Math.round(b.z1 * 50), [i, 1, b.z1, b.x0, b.x1, b.y0, b.y1]);
      add('y' + Math.round(b.y1 * 50), [i, 1, b.y1, b.x0, b.x1, b.z0, b.z1]); add('y' + Math.round(b.y0 * 50), [i, -1, b.y0, b.x0, b.x1, b.z0, b.z1]);
    });
    const att = list.map(() => ({}));
    const near = (ax, v) => { const k = Math.round(v * 50), r = []; for (let d = -1; d <= 1; d++) { const L = idx.get(ax + (k + d)); if (L) r.push(...L); } return r; };
    list.forEach((b, i) => {
      const chk = (ax, s, v, a0, a1, c0, c1, key) => {
        for (const q of near(ax, v)) {
          if (q[0] === i || q[1] !== -s || Math.abs(q[2] - v) > 0.02) continue;
          if (Math.min(a1, q[4]) - Math.max(a0, q[3]) > 0.02 && Math.min(c1, q[6]) - Math.max(c0, q[5]) > 0.02) { att[i][key] = true; return; }
        }
        // грань утоплена внутрь другой коробки
        for (const o of list) {
          if (o === b) continue;
          if (ax === 'x' && o.x0 < v - 0.01 && o.x1 > v + 0.01 && o.y0 <= a0 + 0.01 && o.y1 >= Math.min(a1, a0 + 0.6) && o.z0 < c1 && o.z1 > c0 && Math.min(c1, o.z1) - Math.max(c0, o.z0) > 0.3) { att[i][key] = true; return; }
          if (ax === 'z' && o.z0 < v - 0.01 && o.z1 > v + 0.01 && o.y0 <= c0 + 0.01 && o.y1 >= Math.min(c1, c0 + 0.6) && o.x0 < a1 && o.x1 > a0 && Math.min(a1, o.x1) - Math.max(a0, o.x0) > 0.3) { att[i][key] = true; return; }
        }
      };
      chk('x', -1, b.x0, b.y0, b.y1, b.z0, b.z1, 'nx'); chk('x', 1, b.x1, b.y0, b.y1, b.z0, b.z1, 'px');
      chk('z', -1, b.z0, b.x0, b.x1, b.y0, b.y1, 'nz'); chk('z', 1, b.z1, b.x0, b.x1, b.y0, b.y1, 'pz');
      chk('y', 1, b.y1, b.x0, b.x1, b.z0, b.z1, 'py');
    });
    return att;
  }
  const _fv = new THREE.Vector3(), _fa = new THREE.Vector3(), _fb = new THREE.Vector3();
  // многоугольник с нормалью n (веер), мировая развёртка и запечённое затенение как в addBox
  function pushPoly(buf, vs, n, scale, y0, fb) {
    _fa.set(vs[1][0] - vs[0][0], vs[1][1] - vs[0][1], vs[1][2] - vs[0][2]);
    _fb.set(vs[2][0] - vs[0][0], vs[2][1] - vs[0][1], vs[2][2] - vs[0][2]);
    _fv.crossVectors(_fa, _fb);
    if (_fv.x * n[0] + _fv.y * n[1] + _fv.z * n[2] < 0) vs = vs.slice().reverse();
    const base = buf.pos.length / 3, ax = Math.abs(n[0]), ay = Math.abs(n[1]), az = Math.abs(n[2]);
    for (const v of vs) {
      buf.pos.push(v[0], v[1], v[2]); buf.nor.push(n[0], n[1], n[2]);
      let u, w;
      if (fb) {
        const fx = (v[0] - fb.x0) / (fb.x1 - fb.x0), fy = (v[1] - fb.y0) / (fb.y1 - fb.y0), fz = (v[2] - fb.z0) / (fb.z1 - fb.z0);
        if (ay >= ax && ay >= az) { u = fx; w = fz; } else if (ax >= az) { u = fz; w = fy; } else { u = fx; w = fy; }
      } else if (ay >= ax && ay >= az) { u = v[0] / scale; w = v[2] / scale; }
      else if (ax >= az) { u = v[2] / scale; w = v[1] / scale; }
      else { u = v[0] / scale; w = v[1] / scale; }
      buf.uv.push(u, w);
      let ao = 1;
      if (n[1] < -0.5) ao = 0.72;
      else if (n[1] < 0.5 && y0 <= 0.01) ao = v[1] <= 0.01 ? 0.6 : v[1] < 1.2 ? 0.6 + 0.4 * (v[1] / 1.2) : 1;
      buf.col.push(ao, ao, ao);
    }
    for (let i = 1; i < vs.length - 1; i++) buf.idx.push(base, base + i, base + i + 1);
  }
  const S2 = Math.SQRT1_2, S3 = 1 / Math.sqrt(3);
  // коробка с фасками на вертикальных и верхних рёбрах
  function addBoxCh(buf, b, scale, c) {
    const { x0, y0, z0, x1, y1, z1 } = b, yt = y1 - c, fb = b.uv === 'face' ? b : null;
    pushPoly(buf, [[x0 + c, y1, z0 + c], [x1 - c, y1, z0 + c], [x1 - c, y1, z1 - c], [x0 + c, y1, z1 - c]], [0, 1, 0], scale, y0, fb);
    pushPoly(buf, [[x1, y0, z0 + c], [x1, y0, z1 - c], [x1, yt, z1 - c], [x1, yt, z0 + c]], [1, 0, 0], scale, y0, fb);
    pushPoly(buf, [[x0, y0, z0 + c], [x0, y0, z1 - c], [x0, yt, z1 - c], [x0, yt, z0 + c]], [-1, 0, 0], scale, y0, fb);
    pushPoly(buf, [[x0 + c, y0, z1], [x1 - c, y0, z1], [x1 - c, yt, z1], [x0 + c, yt, z1]], [0, 0, 1], scale, y0, fb);
    pushPoly(buf, [[x0 + c, y0, z0], [x1 - c, y0, z0], [x1 - c, yt, z0], [x0 + c, yt, z0]], [0, 0, -1], scale, y0, fb);
    if (y0 > 0.001) pushPoly(buf, [[x0 + c, y0, z0], [x1 - c, y0, z0], [x1, y0, z0 + c], [x1, y0, z1 - c], [x1 - c, y0, z1], [x0 + c, y0, z1], [x0, y0, z1 - c], [x0, y0, z0 + c]], [0, -1, 0], scale, y0, fb);
    // вертикальные фаски
    for (const [sx, sz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
      const X = sx > 0 ? x1 : x0, Z = sz > 0 ? z1 : z0;
      pushPoly(buf, [[X, y0, Z - sz * c], [X - sx * c, y0, Z], [X - sx * c, yt, Z], [X, yt, Z - sz * c]], [sx * S2, 0, sz * S2], scale, y0, fb);
      pushPoly(buf, [[X, yt, Z - sz * c], [X - sx * c, yt, Z], [X - sx * c, y1, Z - sz * c]], [sx * S3, S3, sz * S3], scale, y0, fb);
    }
    // верхние фаски
    pushPoly(buf, [[x1, yt, z0 + c], [x1, yt, z1 - c], [x1 - c, y1, z1 - c], [x1 - c, y1, z0 + c]], [S2, S2, 0], scale, y0, fb);
    pushPoly(buf, [[x0, yt, z0 + c], [x0, yt, z1 - c], [x0 + c, y1, z1 - c], [x0 + c, y1, z0 + c]], [-S2, S2, 0], scale, y0, fb);
    pushPoly(buf, [[x0 + c, yt, z1], [x1 - c, yt, z1], [x1 - c, y1, z1 - c], [x0 + c, y1, z1 - c]], [0, S2, S2], scale, y0, fb);
    pushPoly(buf, [[x0 + c, yt, z0], [x1 - c, yt, z0], [x1 - c, y1, z0 + c], [x0 + c, y1, z0 + c]], [0, S2, -S2], scale, y0, fb);
  }
  const CH_MATS = { wall: 1, stucco: 1, brick: 1, concrete: 1, metal: 1, crate: 1, contRed: 1, contBlue: 1, contGreen: 1, contOrange: 1, corrug: 1, stonewall: 1, hedge: 2 };
  const chamferOf = (b, a) => {
    const k = b.ch || CH_MATS[b.mat]; if (!k || (b.uv === 'face' && b.mat !== 'crate')) return 0;
    const w = b.x1 - b.x0, d = b.z1 - b.z0, h = b.y1 - b.y0, m = Math.min(w, d, h);
    if (m < 0.1 || (!a.chAll && (m < 0.28 || a.px || a.nx || a.pz || a.nz))) return 0;
    if (b.base) return 0.03;
    return k === 2 ? Math.min(0.16, m * 0.2) : Math.min(0.055, m * 0.07);
  };
  // каменные/бетонные карнизы на высоких стенах
  const CAP = { wall: '#b6a27d', stucco: '#d5c4a2', brick: '#7c776f', concrete: '#a19f98', corrug: '#6d7277' };
  function wallCaps(list, att, out) {
    list.forEach((b, i) => {
      const col = CAP[b.mat], h = b.y1 - b.y0;
      if (!col || h < 1.6 || b.y0 > 0.3 || att[i].py || b.uv === 'face') return;
      const o = b.mat === 'corrug' ? 0.03 : 0.06, t = b.mat === 'corrug' ? 0.06 : 0.12;
      const w = b.x1 - b.x0 + (att[i].nx ? 0 : o) + (att[i].px ? 0 : o), d = b.z1 - b.z0 + (att[i].nz ? 0 : o) + (att[i].pz ? 0 : o);
      const cx = (b.x0 - (att[i].nx ? 0 : o) + b.x1 + (att[i].px ? 0 : o)) / 2, cz = (b.z0 - (att[i].nz ? 0 : o) + b.z1 + (att[i].pz ? 0 : o)) / 2;
      out.push({ w, h: t, d, x: cx, y: b.y1 + t / 2 - 0.001, z: cz, color: col });
      // тонкая полоска тени под карнизом
      if (b.mat !== 'corrug') out.push({ w: w - o * 0.6, h: 0.05, d: d - o * 0.6, x: cx, y: b.y1 - 0.02, z: cz, color: shade(col, 0.72) });
    });
  }
  const shade = (hex, k) => { const c = new THREE.Color(hex).multiplyScalar(k); return '#' + c.getHexString(); };
  // мягкие контактные тени у основания стен и ящиков
  function contactAO(list, att, group) {
    const P = [], C = [], I = [];
    const quad = (pts, al) => { const b = P.length / 3; for (let k = 0; k < 4; k++) { P.push(pts[k][0], 0.05, pts[k][1]); C.push(0, 0, 0, al[k]); } I.push(b, b + 2, b + 1, b, b + 3, b + 2); };
    list.forEach((b, i) => {
      const h = b.y1 - b.y0;
      if (b.y0 > 0.02 || h < 0.3 || b.mat === 'roof') return;
      const A = Math.min(0.5, 0.2 + h * 0.07), W = Math.min(1.1, 0.35 + h * 0.12), a = att[i];
      const { x0, x1, z0, z1 } = b;
      if (!a.pz) quad([[x0, z1], [x1, z1], [x1, z1 + W], [x0, z1 + W]], [A, A, 0, 0]);
      if (!a.nz) quad([[x1, z0], [x0, z0], [x0, z0 - W], [x1, z0 - W]], [A, A, 0, 0]);
      if (!a.px) quad([[x1, z1], [x1, z0], [x1 + W, z0], [x1 + W, z1]], [A, A, 0, 0]);
      if (!a.nx) quad([[x0, z0], [x0, z1], [x0 - W, z1], [x0 - W, z0]], [A, A, 0, 0]);
      // углы
      if (!a.pz && !a.px) quad([[x1, z1], [x1, z1 + W], [x1 + W * 0.8, z1 + W * 0.8], [x1 + W, z1]], [A, 0, 0, 0]);
      if (!a.pz && !a.nx) quad([[x0, z1], [x0 - W, z1], [x0 - W * 0.8, z1 + W * 0.8], [x0, z1 + W]], [A, 0, 0, 0]);
      if (!a.nz && !a.px) quad([[x1, z0], [x1 + W, z0], [x1 + W * 0.8, z0 - W * 0.8], [x1, z0 - W]], [A, 0, 0, 0]);
      if (!a.nz && !a.nx) quad([[x0, z0], [x0, z0 - W], [x0 - W * 0.8, z0 - W * 0.8], [x0 - W, z0]], [A, 0, 0, 0]);
    });
    if (!P.length) return;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(C, 4));
    g.setIndex(I); g.computeBoundingSphere();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
    m.renderOrder = -1; m.matrixAutoUpdate = false;
    group.add(m);
  }
  // пилястры и цоколь на длинных глухих стенах (только визуально, без коллизий)
  const PIER = { wall: { w: 0.75, p: 0.2, base: 'concrete' }, brick: { w: 0.7, p: 0.18, base: 'concrete' }, stucco: { w: 0.6, p: 0.12 }, corrug: { w: 0.16, p: 0.12, mat: 'metal', post: true } };
  function genTrims(list, api, bounds) {
    const out = [];
    const clash = (x0, x1, y0, y1, z0, z1, self) => {
      for (const o of list) if (o !== self && o.x0 < x1 && o.x1 > x0 && o.z0 < z1 && o.z1 > z0 && o.y0 < y1 && o.y1 > y0) return true;
      for (const d of api.decals) { const hw = d.w / 2 + 0.2; if (d.y - d.h / 2 < y1 && d.y + d.h / 2 > y0 && d.x > x0 - hw && d.x < x1 + hw && d.z > z0 - hw && d.z < z1 + hw) return true; }
      for (const a of api.awnings) { const hw = (a.w || 3) / 2 + 0.4; if (a.x > x0 - hw && a.x < x1 + hw && a.z > z0 - hw && a.z < z1 + hw) return true; }
      for (const d of api.decor) { const r = Math.max(d.w || 0, d.d || 0, (d.r || 0) * 2, 0.3) / 2 + 0.15; if (d.x > x0 - r && d.x < x1 + r && d.z > z0 - r && d.z < z1 + r && (d.y || 0) < y1 + 0.3) return true; }
      return false;
    };
    const inB = (x, z) => x > bounds.x0 && x < bounds.x1 && z > bounds.z0 && z < bounds.z1;
    for (const b of list) {
      const P = PIER[b.mat];
      if (!P || b.uv === 'face' || b.y0 > 0.02 || b.hidden || !b.solid) continue;
      const h = b.y1 - b.y0, lx = b.x1 - b.x0, lz = b.z1 - b.z0, alongX = lx >= lz, L = alongX ? lx : lz, T = alongX ? lz : lx;
      if (h < 2.2 || L < 6 || T > 2.6) continue;
      const n = Math.floor(L / (P.post ? 3.2 : 6.2)); if (n < 1) continue;
      const step = L / (n + 1);
      for (const side of [-1, 1]) {
        const face = alongX ? (side < 0 ? b.z0 : b.z1) : (side < 0 ? b.x0 : b.x1);
        const mid = alongX ? (b.x0 + b.x1) / 2 : (b.z0 + b.z1) / 2;
        if (!(alongX ? inB(mid, face + side * 1.2) : inB(face + side * 1.2, mid))) continue;
        const f0 = side > 0 ? face - 0.04 : face - P.p, f1 = side > 0 ? face + P.p : face + 0.04;
        for (let k = 1; k <= n; k++) {
          const c = (alongX ? b.x0 : b.z0) + k * step, a0 = c - P.w / 2, a1 = c + P.w / 2;
          const bx = alongX ? { x0: a0, x1: a1, z0: f0, z1: f1 } : { x0: f0, x1: f1, z0: a0, z1: a1 };
          // проверяем зону перед стеной чуть шире пилястры
          const tz = alongX ? [side > 0 ? face + 0.01 : face - P.p - 0.25, side > 0 ? face + P.p + 0.25 : face - 0.01] : null;
          const tx = alongX ? null : [side > 0 ? face + 0.01 : face - P.p - 0.25, side > 0 ? face + P.p + 0.25 : face - 0.01];
          const cx0 = alongX ? a0 - 0.1 : tx[0], cx1 = alongX ? a1 + 0.1 : tx[1], cz0 = alongX ? tz[0] : a0 - 0.1, cz1 = alongX ? tz[1] : a1 + 0.1;
          if (clash(cx0, cx1, 0, b.y1, cz0, cz1, b)) continue;
          out.push(Object.assign(bx, { y0: 0, y1: b.y1 - (P.post ? 0 : 0.0), mat: P.mat || b.mat, solid: false, hidden: false, uv: 'world', extra: true, back: alongX ? (side > 0 ? 'nz' : 'pz') : (side > 0 ? 'nx' : 'px') }));
        }
        // цоколь
        if (P.base) {
          const t = 0.07, hb = 0.42;
          const g0 = side > 0 ? face - 0.02 : face - t, g1 = side > 0 ? face + t : face + 0.02;
          const lo = alongX ? b.x0 : b.z0, hi = alongX ? b.x1 : b.z1;
          // режем цоколь на участки, где перед стеной ничего нет
          let segStart = null;
          const SEG = 1.0;
          for (let u = lo; u < hi + 1e-6; u += SEG) {
            const u1 = Math.min(hi, u + SEG);
            const cx0 = alongX ? u : (side > 0 ? face + 0.01 : face - 0.3), cx1 = alongX ? u1 : (side > 0 ? face + 0.3 : face - 0.01);
            const cz0 = alongX ? (side > 0 ? face + 0.01 : face - 0.3) : u, cz1 = alongX ? (side > 0 ? face + 0.3 : face - 0.01) : u1;
            const ok = !clash(cx0, cx1, 0, hb + 0.6, cz0, cz1, b) && u1 - u > 0.05;
            if (ok && segStart === null) segStart = u;
            if ((!ok || u1 >= hi - 1e-6) && segStart !== null) {
              const e = ok ? u1 : u;
              if (e - segStart > 0.8) out.push(Object.assign(alongX ? { x0: segStart, x1: e, z0: g0, z1: g1 } : { x0: g0, x1: g1, z0: segStart, z1: e },
                { y0: 0, y1: hb, mat: P.base, solid: false, hidden: false, uv: 'world', extra: true, base: true, back: alongX ? (side > 0 ? 'nz' : 'pz') : (side > 0 ? 'nx' : 'px') }));
              segStart = null;
            }
          }
        }
      }
    }
    return out;
  }

  // мелочи на земле: камешки, сухая трава, мусор, лужи
  let _seed = 1;
  const srnd = (a, b) => { _seed = (_seed * 16807) % 2147483647; return a + (_seed / 2147483647) * (b - a); };
  const SCATTER = {
    dust: { seed: 11, peb: 150, pebCol: ['#b09670', '#9a8260', '#c8b08a', '#a89474'], tuft: 50, tuftCol: ['#b8a45e', '#9f8c4c', '#8a9a4a'], rubble: 60, rubCol: ['#d8c098', '#c4a87c', '#b8693e', '#e6d4b0'] },
    harbor: { seed: 23, peb: 110, pebCol: ['#6c6a66', '#5a5956', '#7c7a74'], tuft: 45, tuftCol: ['#5e6a3c', '#4f5a33', '#6f7a46'], rubble: 50, rubCol: ['#8a5a44', '#6f6f6f', '#9c8c70', '#3d6b8c'], puddle: 14, oil: 8 },
    sakura: { seed: 37, peb: 90, pebCol: ['#8d8a82', '#7b7870', '#a19d93'], tuft: 70, tuftCol: ['#5f7a3a', '#6f8a44', '#4f6a30'], rubble: 0, rubCol: [] },
    winter: { seed: 61, peb: 50, pebCol: ['#5b6074', '#4a4f62', '#6d7388'], tuft: 0, tuftCol: [], rubble: 34, rubCol: ['#8a8fa8', '#c2506f', '#3fb4c8', '#d9a23c'], puddle: 16 },
    range: { seed: 5, peb: 40, pebCol: ['#77736c', '#66635d'], tuft: 20, tuftCol: ['#6a7440', '#596336'], rubble: 15, rubCol: ['#8a8a84', '#9c8c70'] },
    villa: { seed: 53, peb: 90, pebCol: ['#8a857c', '#77736b', '#9c968a', '#6a665f'], tuft: 80, puddle: 9, tuftCol: ['#c9a43a', '#b88a2c', '#8f8a46', '#d9b24a'], rubble: 40, rubCol: ['#e0a526', '#d9822b', '#b9611f', '#f0c24a', '#8a7a62'] }
  };
  function scatterGround(id, list, bounds, solids) {
    const cfg = SCATTER[id]; if (!cfg) return [];
    _seed = cfg.seed * 7919 + 1;
    const out = [], ground = list.filter(b => b.y0 < 0.02 && b.y1 - b.y0 > 0.3 && b.mat !== 'roof');
    const inside = (x, z, pad) => { for (const b of solids) if (b.y0 < 0.5 && x > b.x0 - pad && x < b.x1 + pad && z > b.z0 - pad && z < b.z1 + pad) return true; return false; };
    const inB = (x, z) => x > bounds.x0 + 0.5 && x < bounds.x1 - 0.5 && z > bounds.z0 + 0.5 && z < bounds.z1 - 0.5;
    // точка у основания случайной стены
    const atWall = () => {
      const b = ground[Math.floor(srnd(0, ground.length))]; if (!b) return null;
      const side = Math.floor(srnd(0, 4)), off = srnd(0.12, 0.7);
      let x, z;
      if (side === 0) { x = srnd(b.x0, b.x1); z = b.z1 + off; } else if (side === 1) { x = srnd(b.x0, b.x1); z = b.z0 - off; }
      else if (side === 2) { z = srnd(b.z0, b.z1); x = b.x1 + off; } else { z = srnd(b.z0, b.z1); x = b.x0 - off; }
      return inB(x, z) && !inside(x, z, 0.08) ? [x, z] : null;
    };
    const free = () => { const x = srnd(bounds.x0, bounds.x1), z = srnd(bounds.z0, bounds.z1); return inB(x, z) && !inside(x, z, 0.15) ? [x, z] : null; };
    const pick = (a) => a[Math.floor(srnd(0, a.length))];
    for (let i = 0; i < cfg.peb; i++) {
      const p = i % 3 ? free() : atWall(); if (!p) continue;
      const n = 1 + Math.floor(srnd(0, 3));
      for (let k = 0; k < n; k++) { const r = srnd(0.035, 0.11); out.push({ sph: true, r, x: p[0] + srnd(-0.25, 0.25), y: r * 0.25, z: p[1] + srnd(-0.25, 0.25), sy: srnd(0.4, 0.7), sx: srnd(0.8, 1.3), color: pick(cfg.pebCol), seg: 5, ry: srnd(0, 3) }); }
    }
    for (let i = 0; i < cfg.tuft; i++) {
      const p = i % 4 ? atWall() : free(); if (!p) continue;
      const col = pick(cfg.tuftCol), n = 4 + Math.floor(srnd(0, 4)), hh = srnd(0.16, 0.34);
      for (let k = 0; k < n; k++) { const an = srnd(0, 6.28), tl = srnd(0.15, 0.5); out.push({ cyl: true, r: 0, r2: 0.022, h: hh * srnd(0.7, 1.15), x: p[0] + Math.cos(an) * 0.05, y: hh * 0.45, z: p[1] + Math.sin(an) * 0.05, color: col, seg: 3, rx: Math.sin(an) * tl, rz: -Math.cos(an) * tl }); }
    }
    for (let i = 0; i < cfg.rubble; i++) {
      const p = atWall(); if (!p) continue;
      const s = srnd(0.06, 0.18);
      out.push({ w: s * srnd(0.8, 1.6), h: s * srnd(0.4, 0.8), d: s * srnd(0.7, 1.3), x: p[0], y: s * 0.25, z: p[1], color: pick(cfg.rubCol), ry: srnd(0, 3.14), rx: srnd(-0.25, 0.25) });
    }
    for (let i = 0; i < (cfg.puddle || 0); i++) {
      const p = free(); if (!p) continue;
      const r = srnd(0.6, 1.6);
      out.push({ cyl: true, r, h: 0.006, x: p[0], y: 0.045, z: p[1], color: '#2f3640', seg: 12, sx: 1, sz: srnd(0.5, 0.9), ry: srnd(0, 3.14), puddle: true });
    }
    for (let i = 0; i < (cfg.oil || 0); i++) {
      const p = free(); if (!p) continue;
      out.push({ cyl: true, r: srnd(0.3, 0.8), h: 0.004, x: p[0], y: 0.043, z: p[1], color: '#1f2226', seg: 9, sz: srnd(0.6, 1), ry: srnd(0, 3.14) });
    }
    return out;
  }

  // вода: дешёвый шейдер с бликами солнца
  function makeWater(env) {
    const W = env.water;
    const sd = new THREE.Vector3(env.sunSprite[0], env.sunSprite[1], env.sunSprite[2]).normalize();
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        t: { value: 0 }, deep: { value: new THREE.Color(W.deep) }, shallow: { value: new THREE.Color(W.shallow) },
        skyc: { value: new THREE.Color(W.sky) }, sunc: { value: new THREE.Color(env.sun) }, sund: { value: sd },
        fogc: { value: new THREE.Color(env.fog) }, fn: { value: env.fogNear * 1.3 }, ff: { value: env.fogFar * 1.6 }
      },
      vertexShader: 'varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
      fragmentShader: [
        'uniform float t; uniform vec3 deep, shallow, skyc, sunc, sund, fogc; uniform float fn, ff; varying vec3 vW;',
        'void main(){',
        ' vec2 p = vW.xz;',
        ' float a1 = p.x*0.31 + t*1.2, a2 = p.y*0.23 - t*0.9, a3 = (p.x+p.y)*0.83 + t*2.0, a4 = (p.x-p.y)*1.27 - t*1.6;',
        ' vec3 n = normalize(vec3(cos(a1)*0.11 + cos(a3)*0.09 + cos(a4)*0.07, 1.0, cos(a2)*0.1 + cos(a3)*0.09 - cos(a4)*0.07));',
        ' vec3 V = normalize(cameraPosition - vW);',
        ' float fres = pow(1.0 - max(dot(n, V), 0.0), 3.0);',
        ' float wv = 0.5 + 0.25*(sin(a3) + sin(a4));',
        ' vec3 col = mix(deep, shallow, wv*0.6);',
        ' col = mix(col, skyc, clamp(fres*1.1, 0.0, 0.85));',
        ' vec3 R = reflect(-V, n);',
        ' float s = pow(max(dot(R, sund), 0.0), 90.0);',
        ' col += sunc * s * 1.6;',
        ' float d = length(vW - cameraPosition);',
        ' col = mix(col, fogc, smoothstep(fn, ff, d));',
        ' gl_FragColor = vec4(col, 1.0);',
        '}'
      ].join('\n'),
      fog: false
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(900, 900, 1, 1), mat);
    m.rotation.x = -HP; m.position.set(W.x0 + 450, W.level, 0);
    m.userData.water = mat;
    return m;
  }

  function buildSky(group, env, bounds) {
    const skyGeo = new THREE.SphereGeometry(320, 32, 16);
    const cols = [], top = new THREE.Color(env.skyTop), hor = new THREE.Color(env.skyHor), low = new THREE.Color(env.skyLow);
    const mid = env.skyMid ? new THREE.Color(env.skyMid) : null;
    const pa = skyGeo.attributes.position;
    const sd = new THREE.Vector3(env.sunSprite[0], 0, env.sunSprite[2]).normalize();
    const glow = new THREE.Color(env.sunSpriteColor);
    for (let i = 0; i < pa.count; i++) {
      const vx = pa.getX(i), vy = pa.getY(i) / 320, vz = pa.getZ(i);
      let c;
      if (vy > 0) {
        if (mid) c = vy < 0.25 ? hor.clone().lerp(mid, vy / 0.25) : mid.clone().lerp(top, Math.pow((vy - 0.25) / 0.75, 0.7));
        else c = hor.clone().lerp(top, Math.pow(vy, 0.6));
      } else c = hor.clone().lerp(low, Math.min(1, -vy * 4));
      // свечение у солнца
      const hl = Math.hypot(vx, vz) || 1;
      const dot = (vx * sd.x + vz * sd.z) / hl;
      const g = Math.pow(Math.max(0, dot), 6) * Math.max(0, 1 - Math.abs(vy) * 2.2);
      c.lerp(glow, g * 0.55);
      cols.push(c.r, c.g, c.b);
    }
    skyGeo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
    const skyMat = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false });
    // небо — последним из непрозрачного и на дальней плоскости (xyww): закрашиваются только пиксели, где нет карты,
    // вместо полноэкранного прохода под всей сценой. Картинка та же: небо и раньше ничего не перекрывало (depthWrite: false)
    skyMat.onBeforeCompile = (sh) => { sh.vertexShader = sh.vertexShader.replace('#include <project_vertex>', '#include <project_vertex>\n\tgl_Position.z = gl_Position.w;'); };
    const sky = new THREE.Mesh(skyGeo, skyMat);
    sky.renderOrder = 100;
    group.add(sky);
    const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('dot'), color: env.sunSpriteColor, fog: false, depthWrite: false, transparent: true }));
    sun.position.set(env.sunSprite[0], env.sunSprite[1], env.sunSprite[2]); sun.scale.set(env.sunSize, env.sunSize, 1);
    sun.renderOrder = -1;
    group.add(sun);
    // облака — один меш из повёрнутых к центру квадов
    const n = env.cloudN, pos = [], uv = [], idx = [];
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + Math.random() * 0.3, r = 270, h = 30 + Math.random() * 50;
      const w = 70 + Math.random() * 60, hh = w * 0.32;
      const cx = Math.cos(ang) * r, cz = Math.sin(ang) * r, rx = -Math.sin(ang), rz = Math.cos(ang);
      const b = pos.length / 3;
      pos.push(cx - rx * w / 2, h - hh / 2, cz - rz * w / 2, cx + rx * w / 2, h - hh / 2, cz + rz * w / 2,
        cx + rx * w / 2, h + hh / 2, cz + rz * w / 2, cx - rx * w / 2, h + hh / 2, cz - rz * w / 2);
      uv.push(0, 0, 1, 0, 1, 1, 0, 1);
      idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
    }
    const cg = new THREE.BufferGeometry();
    cg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    cg.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    cg.setIndex(idx);
    const clouds = new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ map: G.tex('cloud'), color: env.clouds, transparent: true, depthWrite: false, fog: false, side: THREE.DoubleSide }));
    clouds.renderOrder = -1;
    const far = [clouds];
    // дальние горы и дюны / город
    if (env.dune || env.mount) far.push(mountains(env));
    else if (!env.noCity) far.push(city(env));
    if (env.stars) far.push(stars(env.stars));
    if (env.fuji) far.push(fuji(env));
    const hi = G.settings.quality === 'high';
    for (const o of far) { o.visible = hi; group.add(o); BACKDROP.push(o); }
  }

  // Фудзи: вогнутый конус со снежной шапкой, в дымке у горизонта
  function fuji(env) {
    const H = 135, R = 215, g = new THREE.ConeGeometry(R, H, 48, 10, true);
    const pa = g.attributes.position, col = [];
    const base = new THREE.Color('#5a7099'), haze = new THREE.Color(env.skyHor), snow = new THREE.Color('#f8f9ff'), shade = new THREE.Color('#b9c4dc');
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i), z = pa.getZ(i), y = pa.getY(i), ang = Math.atan2(z, x);
      const t = Math.min((y + H / 2) / H, 0.94);
      const r = R * Math.pow(1 - t, 1.75) * (1 + 0.025 * Math.sin(ang * 7 + t * 9));
      const hl = Math.hypot(x, z) || 1;
      pa.setXYZ(i, x / hl * r, t * H - 6, z / hl * r);
      const line = 0.7 + 0.06 * Math.sin(ang * 9) + 0.035 * Math.sin(ang * 23 + 1.3);
      let c;
      if (t > line) c = snow.clone().lerp(shade, Math.max(0, Math.sin(ang + 0.6)) * 0.45);
      else c = base.clone().lerp(haze, 0.12 + (1 - t) * 0.38);
      c.lerp(haze, 0.18);
      col.push(c.r, c.g, c.b);
    }
    // освещение «запечено» в цвета: неосвещённый материал не пересвечивает гору
    g.computeVertexNormals();
    const na = g.attributes.normal, L = new THREE.Vector3(env.sunPos[0], env.sunPos[1], env.sunPos[2]).normalize();
    for (let i = 0; i < pa.count; i++) {
      const d = Math.max(0, na.getX(i) * L.x + na.getY(i) * L.y + na.getZ(i) * L.z), k = 0.78 + d * 0.32;
      col[i * 3] = Math.min(1, col[i * 3] * k); col[i * 3 + 1] = Math.min(1, col[i * 3 + 1] * k); col[i * 3 + 2] = Math.min(1, col[i * 3 + 2] * k);
    }
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.translate(env.fuji[0], 0, env.fuji[1]);
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, fog: false }));
    m.matrixAutoUpdate = false; m.renderOrder = -1;
    return m;
  }

  // кольцо гор: низкополигональные конусы с изломанными склонами, дымка к горизонту
  function mountains(env) {
    const pos = [], col = [];
    const base = new THREE.Color(env.mount || '#8a6e50'), haze = new THREE.Color(env.skyHor), rock = new THREE.Color(env.rock || '#6e5a46');
    const ring = (n, r0, r1, h0, h1, hz) => {
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + Math.random() * 0.2, r = r0 + Math.random() * (r1 - r0);
        const h = h0 + Math.random() * (h1 - h0), rad = h * (1.6 + Math.random() * 1.2);
        const g = new THREE.ConeGeometry(rad, h, 7, 3, true);
        const pa = g.attributes.position;
        // одинаковый сдвиг для совпадающих вершин шва (колонка 7 = колонка 0)
        const J = []; for (let k = 0; k < 4 * 7; k++) J.push([1 + (Math.random() - 0.5) * 0.35, (Math.random() - 0.5) * h * 0.12]);
        for (let k = 0; k < pa.count; k++) {
          const row = Math.floor(k / 8), colm = (k % 8) % 7;
          if (row === 0) continue; // вершина
          const jj = J[row * 7 + colm];
          pa.setX(k, pa.getX(k) * jj[0]); pa.setZ(k, pa.getZ(k) * jj[0]); if (row < 3) pa.setY(k, pa.getY(k) + jj[1]);
        }
        const ng = g.toNonIndexed(); g.dispose();
        ng.translate(Math.cos(a) * r, h / 2 - 4, Math.sin(a) * r);
        const p = ng.attributes.position.array;
        for (let k = 0; k < p.length; k += 3) {
          pos.push(p[k], p[k + 1], p[k + 2]);
          const t = G.clamp((p[k + 1] + 4) / (h + 4), 0, 1);
          const c = base.clone().lerp(rock, t * 0.5).lerp(haze, hz - t * 0.1);
          col.push(c.r, c.g, c.b);
        }
        ng.dispose();
      }
    };
    const mh = env.mountH || 1;
    ring(16, 230, 260, 30 * mh, 56 * mh, 0.42);
    ring(22, 150, 175, 9 * mh, 20 * mh, 0.22);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, fog: false, flatShading: true }));
    m.matrixAutoUpdate = false;
    return m;
  }

  // звёздное небо: точки на куполе над горизонтом (только высокое качество)
  function stars(n) {
    const pos = [];
    for (let i = 0; i < n; i++) {
      const a = Math.random() * 6.283, y = 0.08 + Math.pow(Math.random(), 0.8) * 0.9, r = Math.sqrt(1 - y * y) * 300;
      pos.push(Math.cos(a) * r, y * 300, Math.sin(a) * r);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    const p = new THREE.Points(g, new THREE.PointsMaterial({ map: G.tex('dot'), size: 3.4, sizeAttenuation: false, color: '#dfe6ff', transparent: true, opacity: 0.85, depthWrite: false, fog: false }));
    p.frustumCulled = false; p.renderOrder = -1;
    return p;
  }
  // силуэт вечернего города с горящими окнами
  function city(env) {
    const pos = [], nor = [], uv = [], col = [];
    for (let i = 0; i < 42; i++) {
      const side = i % 3, t = (Math.floor(i / 3) + Math.random() * 0.8) / 14;
      const near = Math.random() < 0.4;
      const h = (near ? 14 : 24) + Math.random() * (near ? 16 : 34), w = 10 + Math.random() * 12, d = 10 + Math.random() * 10;
      const dist = near ? 85 + Math.random() * 20 : 120 + Math.random() * 45;
      let x, z;
      if (side === 0) { x = -dist; z = -150 + t * 300; }
      else if (side === 1) { x = -110 + t * 170; z = dist; }
      else { x = -110 + t * 170; z = -dist; }
      const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
      g.translate(x, h / 2 - 1, z);
      const p = g.attributes.position.array, n = g.attributes.normal.array, u = g.attributes.uv.array;
      const ou = Math.random(), ov = Math.random(), sh = 0.7 + Math.random() * 0.35;
      for (let k = 0; k < p.length / 3; k++) {
        const f = Math.floor(k / 6);
        pos.push(p[k * 3], p[k * 3 + 1], p[k * 3 + 2]); nor.push(n[k * 3], n[k * 3 + 1], n[k * 3 + 2]);
        if (f === 2 || f === 3) uv.push(0.004, 0.996);
        else uv.push(u[k * 2] * (f < 2 ? d : w) / 17 + ou, u[k * 2 + 1] * h / 30 + ov);
        const s = f === 0 || f === 4 ? sh : sh * 0.8;
        col.push(s, s * 0.96, s * 1.02);
      }
      g.dispose();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeBoundingSphere();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map: G.tex(env.cityTex || 'cityWin'), vertexColors: true }));
    m.matrixAutoUpdate = false;
    return m;
  }

  // ---------- наклейки, навесы, пальмы, пятна ----------
  const NRM = { '+x': [1, 0, 0], '-x': [-1, 0, 0], '+z': [0, 0, 1], '-z': [0, 0, -1] };
  function quads() { return { pos: [], nor: [], uv: [], idx: [] }; }
  function quad(q, c, r, u, w, h, uv, n) {
    const b = q.pos.length / 3;
    const hw = w / 2, hh = h / 2;
    const P = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
    for (const [a, bb] of P) { q.pos.push(c[0] + r[0] * a + u[0] * bb, c[1] + r[1] * a + u[1] * bb, c[2] + r[2] * a + u[2] * bb); q.nor.push(n[0], n[1], n[2]); }
    q.uv.push(uv[0], uv[1], uv[2], uv[1], uv[2], uv[3], uv[0], uv[3]);
    q.idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  }
  function qmesh(q, mat) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(q.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(q.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(q.uv, 2));
    g.setIndex(q.idx); g.computeBoundingSphere();
    const m = new THREE.Mesh(g, mat); m.matrixAutoUpdate = false; return m;
  }
  const cellUV = (i) => { const u0 = (i % 4) * 0.25, v1 = 1 - Math.floor(i / 4) * 0.5; return [u0 + 0.002, v1 - 0.5 + 0.002, u0 + 0.248, v1 - 0.002]; };
  function wallQuad(q, d) {
    const n = NRM[d.n], r = [n[2], 0, -n[0]];
    quad(q, [d.x + n[0] * 0.02, d.y, d.z + n[2] * 0.02], r, [0, 1, 0], d.w, d.h, d.uv || cellUV(d.cell), n);
  }
  // многоугольник крыши с плоской нормалью, повёрнутой вверх
  function poly(q, pts, uvs) {
    const a = pts[0], b = pts[1], c = pts[2];
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    if (ny < 0) { pts = pts.slice().reverse(); uvs = uvs.slice().reverse(); nx = -nx; ny = -ny; nz = -nz; }
    const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    const base = q.pos.length / 3;
    for (let i = 0; i < pts.length; i++) { q.pos.push(pts[i][0], pts[i][1], pts[i][2]); q.nor.push(nx, ny, nz); q.uv.push(uvs[i][0], uvs[i][1]); }
    for (let i = 1; i < pts.length - 1; i++) q.idx.push(base, base + i, base + i + 1);
  }
  function roofGeo(q, r) {
    const g = roofFrame(r), ax = r.alongX;
    const P = (aa, c, y) => ax ? [aa, y, c] : [c, y, aa];
    const T = 2.2, L = Math.hypot(g.hw, g.top - g.ey) / T, { A0, A1, C0, C1, ra0, ra1, cc, ey, top } = g;
    poly(q, [P(A0, C0, ey), P(A1, C0, ey), P(ra1, cc, top), P(ra0, cc, top)], [[A0 / T, 0], [A1 / T, 0], [ra1 / T, L], [ra0 / T, L]]);
    poly(q, [P(A1, C1, ey), P(A0, C1, ey), P(ra0, cc, top), P(ra1, cc, top)], [[A1 / T, 0], [A0 / T, 0], [ra0 / T, L], [ra1 / T, L]]);
    if (r.hip) {
      poly(q, [P(A0, C1, ey), P(A0, C0, ey), P(ra0, cc, top)], [[C1 / T, 0], [C0 / T, 0], [cc / T, L]]);
      poly(q, [P(A1, C0, ey), P(A1, C1, ey), P(ra1, cc, top)], [[C0 / T, 0], [C1 / T, 0], [cc / T, L]]);
    }
  }
  function buildDetails(group, api, def, anim) {
    const dg = {};
    for (const d of api.decals) { const k = d.atlas + (d.lit ? '|lit' : ''); (dg[k] = dg[k] || []).push(d); }
    for (const k in dg) {
      const q = quads(); dg[k].forEach(d => wallQuad(q, d));
      const lit = k.endsWith('|lit'), o = { map: G.tex(k.split('|')[0]), transparent: true, alphaTest: 0.1, polygonOffset: true, polygonOffsetFactor: -2 };
      const m = qmesh(q, lit ? new THREE.MeshBasicMaterial(o) : new THREE.MeshLambertMaterial(o));
      if (!lit) m.receiveShadow = true;
      group.add(m);
    }
    if (api.roofs.length) {
      // все крыши одним мешем: оттенок черепицы — в цвете вершин
      const q = quads(), col = [], c = new THREE.Color();
      for (const r of api.roofs) {
        const n0 = q.pos.length / 3; roofGeo(q, r); c.set(r.col);
        for (let i = n0; i < q.pos.length / 3; i++) col.push(c.r, c.g, c.b);
      }
      const rt = def.roofTex || 'kawara';
      const mat = new THREE.MeshLambertMaterial({ map: G.tex(rt), vertexColors: true, side: THREE.DoubleSide });
      mat.userData.nm = null; mat.userData.nmF = () => G.normalTex(rt); mat.userData.ns = 1.2; NM.push(mat);
      if (G.settings.quality === 'high') { mat.normalMap = nmOf(mat); mat.normalScale = new THREE.Vector2(1.2, 1.2); }
      const m = qmesh(q, mat); m.geometry.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      m.castShadow = true; m.receiveShadow = true; group.add(m);
    }
    for (const p of api.ground.filter(g => g.kind === 'pond')) {
      const q = quads();
      quad(q, [p.x, 0.035, p.z], [1, 0, 0], [0, 0, -1], p.w, p.d, [0, 0, p.w / 9, p.d / 9], [0, 1, 0]);
      const t = G.tex('pond').clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping;
      const m = qmesh(q, new THREE.MeshPhongMaterial({ map: t, shininess: 90, specular: 0x8899aa }));
      m.receiveShadow = true; group.add(m);
      if (anim) anim.ponds.push(t);
    }
    // вода бассейна и фонтанов: прямоугольники и круги, бирюза с бликами солнца, каустика медленно плывёт
    const sw = api.ground.filter(g => g.kind === 'swim');
    if (sw.length) {
      const q = quads();
      for (const p of sw) {
        if (p.r) {
          const b = q.pos.length / 3, n = 20;
          q.pos.push(p.x, p.y, p.z); q.nor.push(0, 1, 0); q.uv.push(p.x / 3, -p.z / 3);
          for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2, X = p.x + Math.cos(a) * p.r, Z = p.z + Math.sin(a) * p.r; q.pos.push(X, p.y, Z); q.nor.push(0, 1, 0); q.uv.push(X / 3, -Z / 3); }
          for (let i = 1; i <= n; i++) q.idx.push(b, b + i + 1, b + i);
        } else quad(q, [p.x, p.y, p.z], [1, 0, 0], [0, 0, -1], p.w, p.d, [(p.x - p.w / 2) / 3, -(p.z + p.d / 2) / 3, (p.x + p.w / 2) / 3, -(p.z - p.d / 2) / 3], [0, 1, 0]);
      }
      const t = G.tex('swim').clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping;
      const m = qmesh(q, new THREE.MeshPhongMaterial({ map: t, shininess: 120, specular: 0xa8e8ff }));
      m.receiveShadow = true; group.add(m);
      if (anim) anim.swim.push(t);
    }
    if (api.awnings.length) {
      const byCol = {};
      for (const a of api.awnings) (byCol[a.col || 'r'] = byCol[a.col || 'r'] || []).push(a);
      for (const col in byCol) {
        const q = quads();
        for (const a of byCol[col]) {
          const n = NRM[a.n], r = [n[2], 0, -n[0]];
          const slope = 0.42, dz = a.depth * Math.cos(slope), dy = a.depth * Math.sin(slope);
          const c = [a.x + n[0] * dz / 2, a.y - dy / 2, a.z + n[2] * dz / 2];
          const up = [n[0] * Math.cos(slope) * -1, Math.sin(slope), n[2] * Math.cos(slope) * -1];
          const len = Math.hypot(...up); up[0] /= len; up[1] /= len; up[2] /= len;
          const nn = [n[0] * Math.sin(slope), Math.cos(slope), n[2] * Math.sin(slope)];
          quad(q, c, r, up, a.w, a.depth, [0, 0, a.w / 2, 1], nn);
          a.supports = true;
        }
        const t = G.tex('awning', col === 'r' ? '#b0392b' : col).clone(); t.needsUpdate = true; t.wrapS = THREE.RepeatWrapping;
        const m = qmesh(q, new THREE.MeshLambertMaterial({ map: t, side: THREE.DoubleSide }));
        m.castShadow = true; m.receiveShadow = true; group.add(m);
      }
    }
    if (api.fronds.length) {
      const q = quads();
      for (const p of api.fronds) {
        for (let i = 0; i < p.n; i++) {
          const a = i / p.n * Math.PI * 2 + Math.random() * 0.3, dx = Math.cos(a), dz = Math.sin(a);
          const r = [-dz, 0, dx];
          // две части листа: вверх-наружу и вниз
          const l1 = 1.6, l2 = 1.7, up1 = 0.35, dn2 = -0.9;
          const c1 = [p.x + dx * l1 / 2, p.y + up1 / 2, p.z + dz * l1 / 2];
          const u1 = [dx, up1 / l1, dz]; const n1 = Math.hypot(...u1); u1[0] /= n1; u1[1] /= n1; u1[2] /= n1;
          quad(q, c1, r, u1, 0.75, l1 * 1.02, [0, 0, 1, 0.5], [0, 1, 0]);
          const c2 = [p.x + dx * (l1 + l2 / 2 * 0.8), p.y + up1 + dn2 / 2, p.z + dz * (l1 + l2 / 2 * 0.8)];
          const u2 = [dx * 0.8, dn2 / l2, dz * 0.8]; const n2 = Math.hypot(...u2); u2[0] /= n2; u2[1] /= n2; u2[2] /= n2;
          quad(q, c2, r, u2, 0.75, l2, [0, 0.5, 1, 1], [0, 1, 0]);
        }
      }
      const tex = G.tex('palm');
      // текстура листа лежит горизонтально: u — вдоль листа, v — поперёк
      for (let i = 0; i < q.uv.length; i += 2) { const t = q.uv[i]; q.uv[i] = q.uv[i + 1]; q.uv[i + 1] = t; }
      const m = qmesh(q, new THREE.MeshLambertMaterial({ map: tex, alphaTest: 0.35, side: THREE.DoubleSide }));
      m.castShadow = true; group.add(m);
    }
    // цветные отсветы неона на кровле: одним мешем, цвет — в вершинах, свет складывается
    const neon = api.ground.filter(g => g.kind === 'neon');
    if (neon.length) {
      const q = quads(), col = [], c = new THREE.Color();
      for (const g of neon) {
        quad(q, [g.x, 0.032, g.z], [1, 0, 0], [0, 0, -1], g.sz, g.sz, [0, 0, 1, 1], [0, 1, 0]);
        c.set(g.col); const k = g.k || 1; for (let i = 0; i < 4; i++) col.push(c.r * k, c.g * k, c.b * k);
      }
      const m = qmesh(q, new THREE.MeshBasicMaterial({ map: G.tex('ntSpot'), vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, polygonOffset: true, polygonOffsetFactor: -2 }));
      m.geometry.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      group.add(m);
    }
    for (const kind of ['stain', 'pool', 'petals']) {
      const list = api.ground.filter(g => g.kind === kind);
      if (!list.length) continue;
      const q = quads();
      for (const g of list) quad(q, [g.x, kind === 'pool' ? 0.025 : kind === 'petals' ? 0.03 : 0.018, g.z], [1, 0, 0], [0, 0, -1], g.sz, g.sz, [0, 0, 1, 1], [0, 1, 0]);
      const mat = kind === 'pool'
        ? new THREE.MeshBasicMaterial({ map: G.tex('pool'), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })
        : new THREE.MeshLambertMaterial({ map: G.tex(kind), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
      group.add(qmesh(q, mat));
    }
  }

  // ---------- broadphase столкновений (12.0) ----------
  // Равномерная сетка по XZ над твёрдыми коробками: в клетке — индексы коробок по возрастанию. Запрос берёт коробки
  // только из задетых клеток и проверяет их в том же порядке и той же арифметикой, что полный перебор, — результат
  // совпадает бит в бит (A/B-тест: 100 тыс. запросов на карту). Если игрока при разрешении столкновения вытолкнуло
  // за пределы опрошенной области, шаг пересчитывается полным перебором.
  const GCS = 4, GPAD = 1e-3;
  const AIR_STEP = 0.4; // 2.0: на сколько можно «подтянуться» в прыжке (прыжок ~1.1 м + 0.4 = ящики до ~1.45 м)
  function buildGrid(solids) {
    let x0 = Infinity, z0 = Infinity, x1 = -Infinity, z1 = -Infinity;
    for (const b of solids) { if (b.x0 < x0) x0 = b.x0; if (b.z0 < z0) z0 = b.z0; if (b.x1 > x1) x1 = b.x1; if (b.z1 > z1) z1 = b.z1; }
    if (!solids.length) { x0 = z0 = 0; x1 = z1 = 1; }
    const inv = 1 / GCS, nx = Math.max(1, Math.ceil((x1 - x0) * inv) + 1), nz = Math.max(1, Math.ceil((z1 - z0) * inv) + 1);
    const cx = (v) => { const c = Math.floor((v - x0) * inv); return c < 0 ? 0 : c >= nx ? nx - 1 : c; };
    const cz = (v) => { const c = Math.floor((v - z0) * inv); return c < 0 ? 0 : c >= nz ? nz - 1 : c; };
    const cnt = new Int32Array(nx * nz + 1);
    for (const b of solids) for (let j = cz(b.z0), j1 = cz(b.z1); j <= j1; j++) for (let i = cx(b.x0), i1 = cx(b.x1); i <= i1; i++) cnt[j * nx + i + 1]++;
    for (let k = 0; k < nx * nz; k++) cnt[k + 1] += cnt[k];
    const idx = new Int32Array(cnt[nx * nz]), fill = cnt.slice(0, nx * nz);
    solids.forEach((b, n) => { for (let j = cz(b.z0), j1 = cz(b.z1); j <= j1; j++) for (let i = cx(b.x0), i1 = cx(b.x1); i <= i1; i++) idx[fill[j * nx + i]++] = n; });
    return { x0, z0, x1, z1, nx, nz, inv, cx, cz, start: cnt, idx, mark: new Uint32Array(solids.length), stamp: 0, cand: new Int32Array(solids.length), n: 0, solids };
  }
  // кандидаты из прямоугольника клеток [i0..i1]×[j0..j1] — в grid.cand[0..n), по возрастанию индекса
  function gridAddRect(g, i0, i1, j0, j1) {
    const st = g.start, idx = g.idx, mark = g.mark, cand = g.cand, s = g.stamp;
    let n = g.n;
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const c = j * g.nx + i;
      for (let k = st[c], e = st[c + 1]; k < e; k++) { const b = idx[k]; if (mark[b] !== s) { mark[b] = s; cand[n++] = b; } }
    }
    g.n = n;
  }
  function gridBegin(g) { g.n = 0; if (++g.stamp > 0xfffffff0) { g.mark.fill(0); g.stamp = 1; } }
  function gridSort(g) { // вставками: кандидатов обычно десятки
    const a = g.cand, n = g.n;
    for (let i = 1; i < n; i++) { const v = a[i]; let j = i - 1; while (j >= 0 && a[j] > v) { a[j + 1] = a[j]; j--; } a[j + 1] = v; }
  }
  function gridRect(g, ax, az, bx, bz) {
    gridBegin(g); gridAddRect(g, g.cx(ax), g.cx(bx), g.cz(az), g.cz(bz)); gridSort(g);
  }
  // проверка одной коробки лучом — та же арифметика и тот же порядок операций, что в полном переборе (rayFull);
  // результат в _rt/_rn*; tmax ограничен текущим лучшим t, как там
  let _rt = 0, _rnx = 0, _rny = 0, _rnz = 0;
  function rayBox(b, ox, oy, oz, dx, dy, dz, ix, iy, iz, best) {
    let tmin = 0, tmax = best, nx = 0, ny = 0, nz = 0, t1, t2;
    if (Math.abs(dx) < 1e-9) { if (ox < b.x0 || ox > b.x1) return false; }
    else {
      t1 = (b.x0 - ox) * ix; t2 = (b.x1 - ox) * ix;
      if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
      if (t1 > tmin) { tmin = t1; nx = dx > 0 ? -1 : 1; ny = 0; nz = 0; }
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return false;
    }
    if (Math.abs(dy) < 1e-9) { if (oy < b.y0 || oy > b.y1) return false; }
    else {
      t1 = (b.y0 - oy) * iy; t2 = (b.y1 - oy) * iy;
      if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
      if (t1 > tmin) { tmin = t1; nx = 0; ny = dy > 0 ? -1 : 1; nz = 0; }
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return false;
    }
    if (Math.abs(dz) < 1e-9) { if (oz < b.z0 || oz > b.z1) return false; }
    else {
      t1 = (b.z0 - oz) * iz; t2 = (b.z1 - oz) * iz;
      if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
      if (t1 > tmin) { tmin = t1; nx = 0; ny = 0; nz = dz > 0 ? -1 : 1; }
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return false;
    }
    _rt = tmin; _rnx = nx; _rny = ny; _rnz = nz;
    return true;
  }

  // ---------- активная карта ----------
  const map = G.map = {
    id: null, def: null, boxes: [], solids: [], bounds: null, spawnZones: null, sites: null, groups: {}, built: {},
    // построить (один раз) и сделать активной
    load(id, scene) {
      const def = G.MAPS[id] || G.MAPS.dust;
      if (!this.built[id]) this.built[id] = this.build(id, def, scene);
      const data = this.built[id];
      for (const k in this.built) { const gr = this.built[k].group; gr.visible = (k === id); gr.matrixWorldAutoUpdate = gr.visible; } // скрытые карты не обходятся в updateMatrixWorld
      this.id = id; this.def = def; this.boxes = data.boxes; this.solids = data.solids;
      this.grid = data.grid || (data.grid = buildGrid(data.solids));
      this.bounds = data.bounds; this.spawnZones = data.spawnZones; this.sites = data.sites;
      this.water = data.water;
      this.lampSprites = data.lampSprites;
      this.anim = data.anim;
      return data;
    },
    build(id, def, scene) {
      const sc = def.scale || 1;
      const api = makeApi(sc);
      def.layout(api); G.map._api = api; G.map._lite = liteList;
      const R = (r) => ({ x0: r.x0 * sc, x1: r.x1 * sc, z0: r.z0 * sc, z1: r.z1 * sc });
      const bounds = R(def.bounds), sites = {}, spawnZones = def.spawnZones.map(z => Object.assign(R(z), { yaw: z.yaw }));
      for (const k in def.sites) sites[k] = R(def.sites[k]);
      const env = Object.assign({}, def.env);
      if (env.water) env.water = Object.assign({}, env.water, { x0: env.water.x0 * sc });
      const boxes = api.boxes, solids = boxes.filter(b => b.solid);
      // сервер: только геометрия столкновений, без графики
      if (G.HEADLESS) return { group: { visible: false }, boxes, solids, bounds, spawnZones, sites, water: null, lampSprites: null, anim: null };
      const group = new THREE.Group();
      const bufs = {};
      const vis = boxes.filter(b => !b.hidden && b.mat !== 'none');
      const trims = genTrims(vis, api, R(def.bounds));
      const rboxes = deZFight(vis.concat(trims));
      const att = computeAttach(rboxes.slice(0, vis.length)).concat(rboxes.slice(vis.length).map(b => ({ [b.back]: true, chAll: true })));
      let nCh = 0;
      rboxes.forEach((b, i) => {
        const k = b.mat;
        if (!bufs[k]) bufs[k] = { pos: [], nor: [], uv: [], col: [], idx: [] };
        const c = b.y1 - b.y0 < 0.05 ? 0 : chamferOf(b, att[i]);
        const c0 = bufs[k].col.length;
        if (c > 0.005) { addBoxCh(bufs[k], b, def.matScale[k] || 3, c); nCh++; } else addBox(bufs[k], b, def.matScale[k] || 3);
        if (b.extra && !b.base) { const col = bufs[k].col; for (let q = c0; q < col.length; q++) col[q] *= 0.9; }
        if (b.tint) { const col = bufs[k].col; _tc.set(b.tint); for (let q = c0; q < col.length; q += 3) { col[q] *= _tc.r; col[q + 1] *= _tc.g; col[q + 2] *= _tc.b; } }
      });
      unflushDecor(api.decor, rboxes); G.map._rboxes = rboxes; G.map._nCh = nCh; G.map._nTrim = trims.length;
      const nd0 = api.decor.length; wallCaps(rboxes, att, api.decor); G.map._nCaps = api.decor.length - nd0;
      contactAO(rboxes, att, group);
      const scat = scatterGround(id, rboxes, R(def.bounds), solids);
      for (const k in bufs) {
        const bf = bufs[k], geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(bf.pos, 3));
        geo.setAttribute('normal', new THREE.Float32BufferAttribute(bf.nor, 3));
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(bf.uv, 2));
        geo.setAttribute('color', new THREE.Float32BufferAttribute(bf.col, 3));
        geo.setIndex(bf.idx);
        geo.computeBoundingSphere();
        const m = new THREE.Mesh(geo, getMat(k));
        m.castShadow = true; m.receiveShadow = true; m.matrixAutoUpdate = false;
        group.add(m);
      }
      // земля (ground.none — карта целиком покрыта полами-коробками: без второго слоя под ними)
      if (!def.ground.none) {
      const gm = lam(def.ground.mat, null, 0.9);
      gm.vertexColors = false;
      const gtex = gm.map.clone(); gtex.needsUpdate = true; gm.map = gtex;
      const gsz = [def.ground.size[0] * sc, def.ground.size[1] * sc];
      // своя копия карты нормалей с повтором земли — тоже только когда понадобится
      const gnmF = gm.userData.nmF, gRep = [gsz[0] / def.ground.repeat, gsz[1] / def.ground.repeat];
      gm.userData.nm = null; gm.userData.nmF = () => { const t = gnmF().clone(); t.needsUpdate = true; t.repeat.set(gRep[0], gRep[1]); return t; };
      if (gm.normalMap) gm.normalMap = nmOf(gm);
      gtex.repeat.set(gRep[0], gRep[1]);
      // крупные пятна на земле — ломают повтор текстуры
      const gg = new THREE.PlaneGeometry(gsz[0], gsz[1], Math.ceil(gsz[0] / 2.2), Math.ceil(gsz[1] / 2.2));
      { const pa = gg.attributes.position.array, col = new Float32Array(pa.length);
        for (let i = 0; i < pa.length; i += 3) {
          const x = pa[i], y = pa[i + 1];
          const n1 = Math.sin(x * 0.11 + 1.7) * Math.cos(y * 0.093 - 0.6) + Math.sin(x * 0.047 - y * 0.061 + 2.1);
          const n2 = Math.sin(x * 0.31 + y * 0.27) * Math.cos(x * 0.23 - y * 0.35);
          const v = 0.95 + n1 * 0.035 + n2 * 0.02;
          col[i] = v * (1 + n2 * 0.015); col[i + 1] = v; col[i + 2] = v * (1 - n2 * 0.02);
        }
        gg.setAttribute('color', new THREE.BufferAttribute(col, 3)); }
      gm.vertexColors = true;
      const ground = new THREE.Mesh(gg, gm);
      gm.polygonOffset = true; gm.polygonOffsetFactor = 1; gm.polygonOffsetUnits = 2; // земля всегда «под» наклейками
      ground.rotation.x = -HP; ground.receiveShadow = true; ground.updateMatrix(); ground.matrixAutoUpdate = false;
      group.add(ground);
      }
      // декор (на картах с def.lite — ещё и упрощённая копия для низкого/среднего качества)
      const hiQ = G.settings.quality === 'high';
      if (api.decor.length) {
        const dm = new THREE.Mesh(G.geo.build(api.decor), G.getVCMat());
        dm.castShadow = true; dm.receiveShadow = true; dm.matrixAutoUpdate = false;
        group.add(dm);
        if (def.lite) {
          const lm = new THREE.Mesh(G.geo.build(liteList(api.decor).concat(api.lo)), G.getVCMat());
          lm.castShadow = true; lm.receiveShadow = true; lm.matrixAutoUpdate = false;
          group.add(lm); dm.visible = hiQ; lm.visible = !hiQ; BACKDROP.push(dm); LITE.push(lm);
        }
      }
      // мелкие детали и пейзаж за стенами — отдельным мешем, только на высоком качестве
      if (api.hi.length) {
        const hm = new THREE.Mesh(G.geo.build(api.hi), G.getVCMat());
        hm.receiveShadow = true; hm.matrixAutoUpdate = false; hm.visible = hiQ;
        group.add(hm); BACKDROP.push(hm);
      }
      // мелочи на земле (без отбрасывания теней — дёшево)
      if (scat.length) {
        const pud = scat.filter(p => p.puddle), rest = scat.filter(p => !p.puddle);
        if (rest.length) { const sm = new THREE.Mesh(G.geo.build(rest), G.getVCMat()); sm.receiveShadow = true; sm.matrixAutoUpdate = false; group.add(sm); if (def.scatterHi) { sm.visible = hiQ; BACKDROP.push(sm); } }
        if (pud.length) {
          const pm = new THREE.Mesh(G.geo.build(pud), new THREE.MeshPhongMaterial({ vertexColors: true, shininess: 90, specular: 0x8a8f99, transparent: true, opacity: 0.78, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
          pm.receiveShadow = true; pm.matrixAutoUpdate = false; group.add(pm);
        }
      }
      // кроны сакуры: фактура цветков, неровный силуэт
      if (api.blossoms.length) {
        const bmat = new THREE.MeshLambertMaterial({ map: G.tex(def.blossomTex || 'blossom'), vertexColors: true });
        const crown = (parts) => {
          const bg = G.geo.buildUV(parts, 0.55), pa = bg.attributes.position.array, na = bg.attributes.normal.array;
          for (let i = 0; i < pa.length; i += 3) {
            const h = Math.sin(pa[i] * 3.1 + pa[i + 1] * 5.7 + pa[i + 2] * 2.3) * Math.cos(pa[i] * 1.7 - pa[i + 2] * 4.1 + pa[i + 1]);
            const o = h * (def.blossomAmp || 0.28);
            pa[i] += na[i] * o; pa[i + 1] += na[i + 1] * o; pa[i + 2] += na[i + 2] * o;
          }
          bg.computeBoundingSphere();
          const bm = new THREE.Mesh(bg, bmat);
          bm.castShadow = true; bm.receiveShadow = true; bm.matrixAutoUpdate = false;
          group.add(bm);
          return bm;
        };
        const bm = crown(api.blossoms);
        if (def.lite) { const lm = crown(liteList(api.blossoms)); bm.visible = hiQ; lm.visible = !hiQ; BACKDROP.push(bm); LITE.push(lm); }
      }
      // нарисованные буквы точек
      for (const L of api.letters) {
        const p = new THREE.Mesh(new THREE.PlaneGeometry(L.size, L.size), new THREE.MeshLambertMaterial({ map: G.T.letter(L.ch), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
        p.rotation.set(-HP, 0, L.rotY); p.position.set(L.x, 0.04, L.z); p.receiveShadow = true;
        group.add(p);
      }
      const anim = { gulls: [], foam: null, ponds: [], petals: null, swim: [] };
      buildDetails(group, api, def, anim);
      // огни фонарей
      // свечение фонарей: одни точки с размером на вершину — один вызов отрисовки на все огни
      const lampSprites = [];
      if (api.lamps.length) {
        const n = api.lamps.length, lp = new Float32Array(n * 3), ls = new Float32Array(n), lc = new Float32Array(n * 3), lcc = new THREE.Color();
        // пятый элемент — цвет неонового огня (иначе тёплый свет лампы)
        api.lamps.forEach((l, i) => { lp[i * 3] = l[0]; lp[i * 3 + 1] = l[1]; lp[i * 3 + 2] = l[2]; ls[i] = l[3] || 1.8; if (l[4]) { lcc.set(l[4]); lc[i * 3] = lcc.r; lc[i * 3 + 1] = lcc.g; lc[i * 3 + 2] = lcc.b; } });
        const lg = new THREE.BufferGeometry();
        lg.setAttribute('position', new THREE.BufferAttribute(lp, 3)); lg.setAttribute('size', new THREE.BufferAttribute(ls, 1)); lg.setAttribute('tint', new THREE.BufferAttribute(lc, 3));
        lg.computeBoundingSphere();
        const lm = new THREE.ShaderMaterial({
          uniforms: { map: { value: G.tex('lampGlow') }, scale: { value: 500 } },
          vertexShader: 'attribute float size; attribute vec3 tint; varying vec3 vT; uniform float scale; void main(){ vT = tint; vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = size * scale / max(0.2, -mv.z); gl_Position = projectionMatrix * mv; }',
          fragmentShader: 'uniform sampler2D map; varying vec3 vT; void main(){ vec4 t = texture2D(map, gl_PointCoord); float k = step(0.001, vT.x + vT.y + vT.z); gl_FragColor = vec4(mix(t.rgb, vT * 1.15 + t.rgb * 0.22, k), t.a); }',
          transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
        });
        const lpts = new THREE.Points(lg, lm);
        const dbs = new THREE.Vector2();
        lpts.onBeforeRender = (r, sc2, cam) => { r.getDrawingBufferSize(dbs); lm.uniforms.scale.value = dbs.y / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov || 60) / 2)); };
        group.add(lpts); lampSprites.push(lpts);
      }
      buildSky(group, def.env, def.bounds);
      let water = null;
      // падающие лепестки сакуры
      // def.petalHi — частицы только на высоком качестве (листопад «Перрона»)
      const ptrees = def.petalHi && G.settings.quality !== 'high' ? [] : api.trees.filter(t => t.petals);
      if (ptrees.length) {
        const N = G.settings.quality === 'low' ? 140 : 320, pos = new Float32Array(N * 3), ph = new Float32Array(N), sp = new Float32Array(N);
        const spawn = (i, any) => {
          const t = ptrees[(Math.random() * ptrees.length) | 0], a = Math.random() * 6.28, rr = Math.sqrt(Math.random()) * t.r;
          pos[i * 3] = t.x + Math.cos(a) * rr; pos[i * 3 + 1] = any ? Math.random() * (t.y + 1) : t.y + Math.random() * 1.4; pos[i * 3 + 2] = t.z + Math.sin(a) * rr;
          ph[i] = Math.random() * 6.28; sp[i] = 0.35 + Math.random() * 0.45;
        };
        for (let i = 0; i < N; i++) spawn(i, true);
        const pg = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); attr.setUsage(THREE.DynamicDrawUsage);
        pg.setAttribute('position', attr);
        const pts = new THREE.Points(pg, new THREE.PointsMaterial({ map: G.tex(def.petalTex || 'petal'), size: def.petalSize || 0.28, sizeAttenuation: true, transparent: true, alphaTest: 0.3, depthWrite: false, color: def.petalCol || '#ffe3ec' }));
        pts.frustumCulled = false; group.add(pts);
        anim.petals = { pos, ph, sp, spawn, attr, n: N };
      }
      // снегопад над всей площадью (те же «лепестки», только белые и медленные)
      if (api.snowfall) {
        const bd = R(def.bounds), N = G.settings.quality === 'low' ? 260 : 600, pos = new Float32Array(N * 3), ph = new Float32Array(N), sp = new Float32Array(N);
        const spawn = (i, any) => {
          pos[i * 3] = bd.x0 + Math.random() * (bd.x1 - bd.x0); pos[i * 3 + 2] = bd.z0 + Math.random() * (bd.z1 - bd.z0);
          pos[i * 3 + 1] = any ? Math.random() * 14 : 12 + Math.random() * 3;
          ph[i] = Math.random() * 6.28; sp[i] = 0.7 + Math.random() * 0.8;
        };
        for (let i = 0; i < N; i++) spawn(i, true);
        const pg = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); attr.setUsage(THREE.DynamicDrawUsage);
        pg.setAttribute('position', attr);
        const pts = new THREE.Points(pg, new THREE.PointsMaterial({ map: G.tex('dot'), size: 0.13, sizeAttenuation: true, transparent: true, depthWrite: false, color: '#ffffff', opacity: 0.9 }));
        pts.frustumCulled = false; group.add(pts);
        anim.petals = { pos, ph, sp, spawn, attr, n: N, snow: true };
      }
      if (env.water) {
        const W = env.water;
        water = makeWater(env); group.add(water);
        // пена у стенки причала
        const fq = quads();
        quad(fq, [W.x0 + 0.7 * sc + 0.75, W.level + 0.04, 0], [0, 0, 1], [1, 0, 0], 190, 1.5, [0, 0, 40, 1], [0, 1, 0]);
        const ft = G.tex('foam').clone(); ft.needsUpdate = true;
        anim.foam = new THREE.MeshBasicMaterial({ map: ft, transparent: true, depthWrite: false, opacity: 0.7, color: '#fff3e8' });
        group.add(qmesh(fq, anim.foam));
      }
      // чайки над водой
      if (api.gulls) {
        const gm = new THREE.SpriteMaterial({ map: G.tex('gull'), color: '#fff0e4', transparent: true, depthWrite: false });
        for (let i = 0; i < api.gulls; i++) {
          const s = new THREE.Sprite(gm);
          s.userData = { cx: (50 + Math.random() * 26) * sc, cz: (-30 + Math.random() * 60) * sc, r: 6 + Math.random() * 12, h: 9 + Math.random() * 10,
            sp: (0.18 + Math.random() * 0.2) * (Math.random() < 0.5 ? -1 : 1), ph: Math.random() * 6.28, sz: 2.6 + Math.random() * 1.0 };
          group.add(s); anim.gulls.push(s);
        }
      }
      // 2.0 perf: вся графика карты неподвижна — матрицы считаются один раз (G.freezeStatic), three.js больше не
      // обходит её в updateMatrixWorld каждый кадр. Двигаются только чайки; что-то новое, что двигают в map.update,
      // помечайте userData.dynamic = true (иначе оно застынет на месте)
      G.freezeStatic(group, new Set(anim.gulls));
      if (G.freeAfterUpload) G.freeAfterUpload(group); // 2.2 perf: копии вершин в памяти JS после загрузки в видеопамять не нужны
      if (G.vlitCheck) G.vlitCheck(group); // 2.1 perf: вершинный свет только на проверенно плоских гранях
      group.visible = false;
      scene.add(group);
      return { group, boxes, solids, water, lampSprites, anim, bounds, sites, spawnZones };
    },
    update(dt, time) {
      if (this.water) this.water.userData.water.uniforms.t.value = time;
      const an = this.anim;
      if (!an) return;
      if (an.petals) {
        const P = an.petals, p = P.pos, w = Math.sin(time * 0.23) * 0.4 + 0.6, k0 = P.snow ? 0.35 : 1;
        for (let i = 0; i < P.n; i++) {
          const k = i * 3, f = P.ph[i];
          p[k + 1] -= P.sp[i] * dt;
          p[k] += (w * 0.7 + Math.sin(time * 1.6 + f) * 0.55) * dt * k0;
          p[k + 2] += (0.25 + Math.cos(time * 1.2 + f * 1.7) * 0.5) * dt * k0;
          if (p[k + 1] < 0.04) P.spawn(i, false);
        }
        P.attr.needsUpdate = true;
      }
      for (const t of an.ponds) { t.offset.x = Math.sin(time * 0.11) * 0.02; t.offset.y = Math.cos(time * 0.09) * 0.02; }
      if (an.swim) for (const t of an.swim) { t.offset.x = time * 0.016 + Math.sin(time * 0.4) * 0.01; t.offset.y = time * 0.011; }
      if (an.foam) { an.foam.map.offset.x = time * 0.025; an.foam.map.offset.y = Math.sin(time * 0.8) * 0.08; an.foam.opacity = 0.55 + 0.18 * Math.sin(time * 1.3); }
      for (let i = 0; i < an.gulls.length; i++) {
        const s = an.gulls[i], u = s.userData, a = u.ph + time * u.sp;
        s.position.set(u.cx + Math.cos(a) * u.r, u.h + Math.sin(time * 0.6 + u.ph) * 1.4, u.cz + Math.sin(a) * u.r);
        const f = Math.sin(time * (u.sp > 0 ? 8 : 9) + u.ph * 3);
        s.scale.set(u.sz, u.sz * 0.5 * (0.3 + 0.7 * Math.abs(f)), 1);
      }
    },
    // 2.0: точка (x, z) над открытой водой (каналы «Лагуны», лагуна за кромкой) → уровень воды, иначе null
    waterAt(x, z) {
      const w = this.def && this.def.wet;
      if (!w) return null;
      const L = w.land;
      for (let i = 0; i < L.length; i++) { const r = L[i]; if (x >= r[0] && x <= r[2] && z >= r[1] && z <= r[3]) return null; }
      return w.y;
    },
    inSite(x, z) {
      for (const k in this.sites) { const s = this.sites[k]; if (x > s.x0 && x < s.x1 && z > s.z0 && z < s.z1) return k; }
      return null;
    },

    ray(ox, oy, oz, dx, dy, dz, maxT) {
      const solids = this.solids, g = this.grid;
      if (!g || g.solids !== solids) return this.rayFull(ox, oy, oz, dx, dy, dz, maxT);
      this.nRay++;
      let best = maxT, hit = false, bi = -1, bnx = 0, bny = 0, bnz = 0;
      if (dy < -1e-6) {
        const t = -oy / dy;
        if (t > 0 && t < best) { best = t; hit = true; bnx = 0; bny = 1; bnz = 0; }
      }
      // Полный перебор берёт минимальный t, при равенстве — коробку с меньшим индексом (пол — раньше всех).
      // Здесь коробки идут в порядке клеток вдоль луча, поэтому то же правило записано явно; дальние клетки,
      // которые начинаются дальше найденного попадания, не проверяются вовсе.
      let t0 = 0, t1 = maxT;
      const X0 = g.x0 - GPAD, X1 = g.x1 + GPAD, Z0 = g.z0 - GPAD, Z1 = g.z1 + GPAD;
      let empty = false;
      if (Math.abs(dx) < 1e-9) { if (ox < X0 || ox > X1) empty = true; }
      else { let u = (X0 - ox) / dx, v = (X1 - ox) / dx; if (u > v) { const t = u; u = v; v = t; } if (u > t0) t0 = u; if (v < t1) t1 = v; }
      if (Math.abs(dz) < 1e-9) { if (oz < Z0 || oz > Z1) empty = true; }
      else { let u = (Z0 - oz) / dz, v = (Z1 - oz) / dz; if (u > v) { const t = u; u = v; v = t; } if (u > t0) t0 = u; if (v < t1) t1 = v; }
      if (!empty && t0 <= t1) {
        gridBegin(g);
        const st = g.start, idx = g.idx, mark = g.mark, stamp = g.stamp, nx = g.nx, nz = g.nz, inv = g.inv, gx0 = g.x0, gz0 = g.z0;
        const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
        const cell = (c) => {
          for (let k = st[c], e = st[c + 1]; k < e; k++) {
            const n = idx[k];
            if (mark[n] === stamp) continue;
            mark[n] = stamp;
            const b = solids[n];
            if (b.nr) continue; // вода бассейна: не пройти, но простреливается
            if (rayBox(b, ox, oy, oz, dx, dy, dz, ix, iy, iz, best) && (_rt < best || (_rt === best && n < bi))) { best = _rt; hit = true; bi = n; bnx = _rnx; bny = _rny; bnz = _rnz; }
          }
        };
        const CX = (v) => { const c = Math.floor((v - gx0) * inv); return c < 0 ? 0 : c >= nx ? nx - 1 : c; };
        const CZ = (v) => { const c = Math.floor((v - gz0) * inv); return c < 0 ? 0 : c >= nz ? nz - 1 : c; };
        const xa = ox + dx * t0, xb = ox + dx * t1, za = oz + dz * t0, zb = oz + dz * t1;
        if (Math.abs(dx) < 1e-9 && Math.abs(dz) < 1e-9) { // отвесный луч
          for (let j = CZ(Math.min(za, zb) - GPAD), j1 = CZ(Math.max(za, zb) + GPAD); j <= j1; j++)
            for (let i = CX(Math.min(xa, xb) - GPAD), i1 = CX(Math.max(xa, xb) + GPAD); i <= i1; i++) cell(j * nx + i);
        } else if (Math.abs(dx) >= Math.abs(dz)) {
          const lo = Math.min(xa, xb), hi = Math.max(xa, xb), k = dz / dx, sx = dx > 0 ? 1 : -1;
          let i = CX(sx > 0 ? lo - GPAD : hi + GPAD);
          const iEnd = CX(sx > 0 ? hi + GPAD : lo - GPAD);
          for (;; i += sx) {
            const cl = Math.max(lo, gx0 + i * GCS) - GPAD, cr = Math.min(hi, gx0 + (i + 1) * GCS) + GPAD;
            const z1 = oz + (cl - ox) * k, z2 = oz + (cr - ox) * k;
            for (let j = CZ(Math.min(z1, z2) - GPAD), j1 = CZ(Math.max(z1, z2) + GPAD); j <= j1; j++) cell(j * nx + i);
            if (i === iEnd) break;
            // следующая колонка начинается дальше найденного попадания — дальше проверять нечего
            const edge = gx0 + (sx > 0 ? i + 1 : i) * GCS;
            if (hit && (edge - sx * GPAD - ox) * ix > best + GPAD) break;
          }
        } else {
          const lo = Math.min(za, zb), hi = Math.max(za, zb), k = dx / dz, sz = dz > 0 ? 1 : -1;
          let j = CZ(sz > 0 ? lo - GPAD : hi + GPAD);
          const jEnd = CZ(sz > 0 ? hi + GPAD : lo - GPAD);
          for (;; j += sz) {
            const cl = Math.max(lo, gz0 + j * GCS) - GPAD, cr = Math.min(hi, gz0 + (j + 1) * GCS) + GPAD;
            const x1 = ox + (cl - oz) * k, x2 = ox + (cr - oz) * k;
            for (let i = CX(Math.min(x1, x2) - GPAD), i1 = CX(Math.max(x1, x2) + GPAD); i <= i1; i++) cell(j * nx + i);
            if (j === jEnd) break;
            const edge = gz0 + (sz > 0 ? j + 1 : j) * GCS;
            if (hit && (edge - sz * GPAD - oz) * iz > best + GPAD) break;
          }
        }
      }
      return hit ? { t: best, nx: bnx, ny: bny, nz: bnz } : null;
    },
    nRay: 0,
    clear(ax, ay, az, bx, by, bz) {
      const dx = bx - ax, dy = by - ay, dz = bz - az;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d < 0.01) return true;
      const h = this.ray(ax, ay, az, dx / d, dy / d, dz / d, d);
      return !h || h.t >= d - 0.05;
    },
    move(a, dx, dy, dz) {
      const solids = this.solids, g = this.grid, r = a.radius, h = a.height, step = 0.42, p = a.pos;
      if (!g || g.solids !== solids) return this.moveFull(a, dx, dy, dz);
      // 2.1: граница карты — сразу на шаг, а не в конце: раньше прижатого к краю карты возвращало обратно в ящик
      // у края уже после проверки опоры, и он проваливался сквозь ящик внутрь (фузз climbfuzz.js, «Лагуна»)
      { const bd = this.bounds; dx = G.clamp(p.x + dx, bd.x0 + r, bd.x1 - r) - p.x; dz = G.clamp(p.z + dz, bd.z0 + r, bd.z1 - r) - p.z; }
      const sx = p.x, sy = p.y, sz = p.z, sg = a.onGround, svy = a.vel.y;
      const air0 = !sg;
      // опрашиваемая область: весь путь за кадр плюс радиус
      const qx0 = Math.min(sx, sx + dx) - r, qx1 = Math.max(sx, sx + dx) + r, qz0 = Math.min(sz, sz + dz) - r, qz1 = Math.max(sz, sz + dz) + r;
      gridRect(g, qx0, qz0, qx1, qz1);
      const cand = g.cand, n = g.n;
      const prevY = p.y;
      let out = false;
      p.x += dx;
      for (let q = 0; q < n; q++) {
        const b = solids[cand[q]];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (a.onGround ? b.y1 - p.y <= step : b.y1 - p.y <= AIR_STEP && this.climbOK(a, b)) continue;
        if (dx > 0) p.x = b.x0 - r - 1e-4; else if (dx < 0) p.x = b.x1 + r + 1e-4;
        if (p.x - r < qx0 || p.x + r > qx1) { out = true; break; }
      }
      if (!out) {
        p.z += dz;
        for (let q = 0; q < n; q++) {
          const b = solids[cand[q]];
          if (p.y + h <= b.y0 || p.y >= b.y1) continue;
          if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
          if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
          if (a.onGround ? b.y1 - p.y <= step : b.y1 - p.y <= AIR_STEP && this.climbOK(a, b)) continue;
          if (dz > 0) p.z = b.z0 - r - 1e-4; else if (dz < 0) p.z = b.z1 + r + 1e-4;
          if (p.z - r < qz0 || p.z + r > qz1) { out = true; break; }
        }
      }
      if (out) { // вытолкнуло за опрошенные клетки — шаг заново полным перебором
        p.x = sx; p.y = sy; p.z = sz; a.onGround = sg; a.vel.y = svy;
        return this.moveFull(a, dx, dy, dz);
      }
      p.y += dy;
      a.onGround = false;
      if (p.y <= 0) { p.y = 0; if (a.vel.y < 0) a.vel.y = 0; a.onGround = true; }
      for (let q = 0; q < n; q++) {
        const b = solids[cand[q]];
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.y + h <= b.y0 || p.y >= b.y1) {
          if (Math.abs(p.y - b.y1) < 0.02 && a.vel.y <= 0) a.onGround = true;
          continue;
        }
        if (prevY >= b.y1 - step && a.vel.y <= 0.01) { p.y = b.y1; a.vel.y = 0; a.onGround = true; }
        else if (air0 && b.y1 - p.y <= AIR_STEP && this.climbOK(a, b)) { p.y = b.y1; a.vel.y = 0; a.onGround = true; } // в прыжке: подтянулся на край ящика
        else if (dy > 0 && b.y0 > prevY + 0.05) { p.y = b.y0 - h - 1e-3; a.vel.y = 0; } // 2.1: потолок — только коробка выше ног (ящик, в который «впустил» подъём, не выталкивает под пол)
        else { p.y = Math.max(p.y, b.y1); a.vel.y = 0; a.onGround = true; }
      }
      const bd = this.bounds;
      p.x = G.clamp(p.x, bd.x0 + r, bd.x1 - r);
      p.z = G.clamp(p.z, bd.z0 + r, bd.z1 - r);
    },
    blocked(x, z, r, maxY) {
      const solids = this.solids, g = this.grid;
      if (!g || g.solids !== solids) return this.blockedFull(x, z, r, maxY);
      maxY = maxY == null ? 1.7 : maxY;
      gridBegin(g); gridAddRect(g, g.cx(x - r - GPAD), g.cx(x + r + GPAD), g.cz(z - r - GPAD), g.cz(z + r + GPAD));
      const cand = g.cand, n = g.n;
      for (let q = 0; q < n; q++) {
        const b = solids[cand[q]];
        if (b.y0 > maxY || b.y1 < 0.3) continue;
        if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true;
      }
      const bd = this.bounds;
      return x < bd.x0 + r || x > bd.x1 - r || z < bd.z0 + r || z > bd.z1 - r;
    },
    // 2.0 perf: проходимость отрезка для сглаживания пути (nav.segClear): точки ax + dx·i/n, i = 1..n — то же, что
    // blocked(x, z, r) в каждой точке, но кандидатов из сетки собираем один раз на пачку из 8 точек, а не на каждую точку.
    // Проверка коробки та же (те же сравнения), набор кандидатов — надмножество, поэтому ответ совпадает бит в бит
    blockedSeg(ax, az, dx, dz, n, r) {
      const solids = this.solids, g = this.grid, bd = this.bounds;
      if (!g || g.solids !== solids) { for (let i = 1; i <= n; i++) { const t = i / n; if (this.blockedFull(ax + dx * t, az + dz * t, r)) return true; } return false; }
      for (let i0 = 1; i0 <= n; i0 += 8) {
        const i1 = Math.min(n, i0 + 7);
        const xa = ax + dx * (i0 / n), za = az + dz * (i0 / n), xb = ax + dx * (i1 / n), zb = az + dz * (i1 / n);
        gridBegin(g); gridAddRect(g, g.cx(Math.min(xa, xb) - r - GPAD), g.cx(Math.max(xa, xb) + r + GPAD), g.cz(Math.min(za, zb) - r - GPAD), g.cz(Math.max(za, zb) + r + GPAD));
        const cand = g.cand, nc = g.n;
        for (let i = i0; i <= i1; i++) {
          const t = i / n, x = ax + dx * t, z = az + dz * t;
          for (let q = 0; q < nc; q++) {
            const b = solids[cand[q]];
            if (b.y0 > 1.7 || b.y1 < 0.3) continue;
            if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true;
          }
          if (x < bd.x0 + r || x > bd.x1 - r || z < bd.z0 + r || z > bd.z1 - r) return true;
        }
      }
      return false;
    },
    // полный перебор — эталон для A/B-теста и запасной путь
    rayFull(ox, oy, oz, dx, dy, dz, maxT) {
      const solids = this.solids;
      let best = maxT, hit = false, bnx = 0, bny = 0, bnz = 0;
      if (dy < -1e-6) {
        const t = -oy / dy;
        if (t > 0 && t < best) { best = t; hit = true; bnx = 0; bny = 1; bnz = 0; }
      }
      const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (b.nr) continue; // вода бассейна: не пройти, но простреливается
        let tmin = 0, tmax = best, nx = 0, ny = 0, nz = 0, t1, t2;
        if (Math.abs(dx) < 1e-9) { if (ox < b.x0 || ox > b.x1) continue; }
        else {
          t1 = (b.x0 - ox) * ix; t2 = (b.x1 - ox) * ix;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = dx > 0 ? -1 : 1; ny = 0; nz = 0; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (Math.abs(dy) < 1e-9) { if (oy < b.y0 || oy > b.y1) continue; }
        else {
          t1 = (b.y0 - oy) * iy; t2 = (b.y1 - oy) * iy;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = 0; ny = dy > 0 ? -1 : 1; nz = 0; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (Math.abs(dz) < 1e-9) { if (oz < b.z0 || oz > b.z1) continue; }
        else {
          t1 = (b.z0 - oz) * iz; t2 = (b.z1 - oz) * iz;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = 0; ny = 0; nz = dz > 0 ? -1 : 1; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (tmin < best) { best = tmin; hit = true; bnx = nx; bny = ny; bnz = nz; }
      }
      return hit ? { t: best, nx: bnx, ny: bny, nz: bnz } : null;
    },
    clearFull(ax, ay, az, bx, by, bz) {
      const dx = bx - ax, dy = by - ay, dz = bz - az;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d < 0.01) return true;
      const h = this.rayFull(ax, ay, az, dx / d, dy / d, dz / d, d);
      return !h || h.t >= d - 0.05;
    },
    // 2.1: хватает ли места, чтобы выпрямиться до роста h (над головой нет коробки) — иначе боец остаётся присевшим.
    // Раньше, отпустив присед под низкой балкой («Полигон»), игрок «выстреливал» наверх балки: вертикальный проход
    // move() видел тело внутри коробки и ставил его на её верх
    fits(a, h) {
      const S = this.solids, p = a.pos, r = a.radius - 0.02;
      for (let i = 0; i < S.length; i++) {
        const b = S[i];
        if (p.x + r <= b.x0 || p.x - r >= b.x1 || p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.y + h <= b.y0 || p.y + 0.05 >= b.y1) continue;
        return false;
      }
      return true;
    },
    // 2.0: в прыжке можно подтянуться на ящик/уступ — если ноги не ниже его верха на AIR_STEP и сверху хватает места
    climbOK(a, b) {
      if (a.vel.y > 2.2) return false; // ещё быстро летим вверх — пусть сначала долетит
      const p = a.pos, r = a.radius, top = b.y1, hi = top + a.height, solids = this.solids;
      for (let i = 0; i < solids.length; i++) {
        const s = solids[i];
        if (s === b || s.y1 <= top + 0.01 || s.y0 >= hi) continue;
        if (p.x + r <= s.x0 || p.x - r >= s.x1 || p.z + r <= s.z0 || p.z - r >= s.z1) continue;
        return false;
      }
      return true;
    },
    moveFull(a, dx, dy, dz) {
      const solids = this.solids, r = a.radius, h = a.height, step = 0.42, p = a.pos;
      { const bd = this.bounds; dx = G.clamp(p.x + dx, bd.x0 + r, bd.x1 - r) - p.x; dz = G.clamp(p.z + dz, bd.z0 + r, bd.z1 - r) - p.z; } // 2.1: см. move
      const air0 = !a.onGround;
      const prevY = p.y;
      p.x += dx;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (a.onGround ? b.y1 - p.y <= step : b.y1 - p.y <= AIR_STEP && this.climbOK(a, b)) continue;
        if (dx > 0) p.x = b.x0 - r - 1e-4; else if (dx < 0) p.x = b.x1 + r + 1e-4;
      }
      p.z += dz;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (a.onGround ? b.y1 - p.y <= step : b.y1 - p.y <= AIR_STEP && this.climbOK(a, b)) continue;
        if (dz > 0) p.z = b.z0 - r - 1e-4; else if (dz < 0) p.z = b.z1 + r + 1e-4;
      }
      p.y += dy;
      a.onGround = false;
      if (p.y <= 0) { p.y = 0; if (a.vel.y < 0) a.vel.y = 0; a.onGround = true; }
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.y + h <= b.y0 || p.y >= b.y1) {
          if (Math.abs(p.y - b.y1) < 0.02 && a.vel.y <= 0) a.onGround = true;
          continue;
        }
        if (prevY >= b.y1 - step && a.vel.y <= 0.01) { p.y = b.y1; a.vel.y = 0; a.onGround = true; }
        else if (air0 && b.y1 - p.y <= AIR_STEP && this.climbOK(a, b)) { p.y = b.y1; a.vel.y = 0; a.onGround = true; } // в прыжке: подтянулся на край ящика
        else if (dy > 0 && b.y0 > prevY + 0.05) { p.y = b.y0 - h - 1e-3; a.vel.y = 0; } // 2.1: потолок — только коробка выше ног (ящик, в который «впустил» подъём, не выталкивает под пол)
        else { p.y = Math.max(p.y, b.y1); a.vel.y = 0; a.onGround = true; }
      }
      const bd = this.bounds;
      p.x = G.clamp(p.x, bd.x0 + r, bd.x1 - r);
      p.z = G.clamp(p.z, bd.z0 + r, bd.z1 - r);
    },
    blockedFull(x, z, r, maxY) {
      maxY = maxY == null ? 1.7 : maxY;
      const solids = this.solids;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (b.y0 > maxY || b.y1 < 0.3) continue;
        if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true;
      }
      const bd = this.bounds;
      return x < bd.x0 + r || x > bd.x1 - r || z < bd.z0 + r || z > bd.z1 - r;
    }
  };
})(window.G);
