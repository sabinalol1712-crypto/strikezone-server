'use strict';
/* Карты: описание, постройка геометрии, столкновения и лучи. Активная карта — G.map */
(function (G) {
  const HP = Math.PI / 2;

  // ---------- конструктор описания карты ----------
  // все координаты раскладки умножаются на масштаб карты sc (размеры ящиков, бочек, высоты — нет)
  function makeApi(sc) {
    sc = sc || 1;
    const S = (v) => v * sc;
    const api = { boxes: [], decor: [], lamps: [], letters: [], sc };
    const rawB = (x0, z0, x1, z1, h, mat, y0, opts) => {
      opts = opts || {};
      api.boxes.push({
        x0: Math.min(x0, x1), z0: Math.min(z0, z1), x1: Math.max(x0, x1), z1: Math.max(z0, z1),
        y0: y0 || 0, y1: (y0 || 0) + h, mat, solid: opts.solid !== false, hidden: !!opts.hidden, uv: opts.uv || 'world',
        // tint — оттенок штукатурки (один материал, разные цвета); nr — не задерживает пули и взгляд (вода); ch — фаска
        tint: opts.tint || null, nr: !!opts.nr, ch: opts.ch || 0
      });
    };
    api.B = (x0, z0, x1, z1, h, mat, y0, opts) => rawB(S(x0), S(z0), S(x1), S(z1), h, mat, y0, opts);
    api.crate = (cx, cz, s, y0) => rawB(S(cx) - s / 2, S(cz) - s / 2, S(cx) + s / 2, S(cz) + s / 2, s, 'crate', y0 || 0, { uv: 'face' });
    api.stack = (cx, cz, s) => { api.crate(cx, cz, s); api.crate(cx + 0.08 / sc, cz - 0.05 / sc, s * 0.8, s); };
    api.lintel = (x0, z0, x1, z1, yb, yt, mat) => api.B(x0, z0, x1, z1, yt - yb, mat, yb);
    // декор: позиция масштабируется; DS — ещё и размеры по X/Z (кран, корабль)
    api.D = (...parts) => { for (const p of parts) { p.x = S(p.x || 0); p.z = S(p.z || 0); api.decor.push(p); } };
    api.DS = (...parts) => { for (const p of parts) { p.x = S(p.x || 0); p.z = S(p.z || 0); if (p.w) p.w *= sc; if (p.d) p.d *= sc; api.decor.push(p); } };
    api.barrel = (x, z, color) => {
      x = S(x); z = S(z);
      rawB(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 0.95, 'none', 0, { hidden: true });
      api.decor.push(G.geo.cyl(0.3, 0.95, x, 0.475, z, color || '#2f5f8a', 0, 0, 0, 12));
      api.decor.push(G.geo.cyl(0.31, 0.05, x, 0.3, z, '#222'), G.geo.cyl(0.31, 0.05, x, 0.68, z, '#222'));
    };
    api.lamp = (x, z, h, armDir) => {
      x = S(x); z = S(z);
      const d = armDir || 0;
      api.decor.push(G.geo.cyl(0.09, h, x, h / 2, z, '#3a3d40', 0, 0, 0, 8));
      api.decor.push(G.geo.box(0.1, 0.1, 1.2, x + Math.sin(d) * 0.55, h, z + Math.cos(d) * 0.55, '#3a3d40', 0, d, 0));
      api.decor.push(G.geo.box(0.36, 0.14, 0.5, x + Math.sin(d) * 1.1, h - 0.08, z + Math.cos(d) * 1.1, '#2a2c2e', 0, d, 0));
      api.lamps.push([x + Math.sin(d) * 1.1, h - 0.2, z + Math.cos(d) * 1.1]);
      rawB(x - 0.12, z - 0.12, x + 0.12, z + 0.12, h, 'none', 0, { hidden: true });
    };
    api.letter = (ch, x, z, size, rotY) => api.letters.push({ ch, x: S(x), z: S(z), size: size || 5, rotY: rotY || 0 });
    // наклейка на стену из атласа фасадов: n — '+x' | '-x' | '+z' | '-z'
    api.decals = []; api.awnings = []; api.fronds = []; api.ground = []; api.roofs = []; api.trees = []; api.blossoms = [];
    // hi — мелкие детали и пейзаж за стенами: строятся отдельным мешем и видны только на высоком качестве
    api.hi = []; api.lo = [];
    api.decal = (cell, x, y, z, w, h, n, atlas) => api.decals.push({ cell, x: S(x), y, z: S(z), w, h, n, atlas: atlas || 'facade', lit: cell === 5 });
    api.awning = (x, y, z, w, depth, n, col) => api.awnings.push({ x: S(x), y, z: S(z), w: w * sc, depth, n, col });
    api.palm = (x, z, h) => {
      x = S(x); z = S(z); h = h || 6.5;
      rawB(x - 0.25, z - 0.25, x + 0.25, z + 0.25, h, 'none', 0, { hidden: true });
      const lean = Math.random() * 6.28, segs = 6;
      let px = x, pz = z, py = 0;
      for (let i = 0; i < segs; i++) {
        const t = i / segs, sh = h / segs;
        const ox = Math.cos(lean) * 0.12 * (i + 1) * t, oz = Math.sin(lean) * 0.12 * (i + 1) * t;
        api.decor.push(G.geo.cyl(0.2 - t * 0.06, sh * 1.02, x + ox, py + sh / 2, z + oz, i % 2 ? '#7a6248' : '#6a543c', 0, 0, 0, 8, 0.22 - t * 0.06));
        api.decor.push(G.geo.cyl(0.23 - t * 0.06, 0.08, x + ox, py + sh * 0.95, z + oz, '#5a4632', 0, 0, 0, 8));
        px = x + ox; pz = z + oz; py += sh;
      }
      api.fronds.push({ x: px, y: py, z: pz, n: 9 });
    };
    api.wire = (a, b, sag) => {
      a = [S(a[0]), a[1], S(a[2])]; b = [S(b[0]), b[1], S(b[2])];
      const n = 6;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n;
        const p0 = [a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0 - Math.sin(t0 * Math.PI) * sag, a[2] + (b[2] - a[2]) * t0];
        const p1 = [a[0] + (b[0] - a[0]) * t1, a[1] + (b[1] - a[1]) * t1 - Math.sin(t1 * Math.PI) * sag, a[2] + (b[2] - a[2]) * t1];
        api.decor.push(G.limb(p0, p1, 0.025, '#1c1c1c'));
      }
    };
    api.pole = (x, z, h) => {
      const X = S(x), Z = S(z);
      api.decor.push(G.geo.cyl(0.11, h, X, h / 2, Z, '#5a4430', 0, 0, 0, 8), G.geo.box(1.4, 0.1, 0.1, X, h - 0.4, Z, '#5a4430'));
      api.decor.push(G.geo.cyl(0.04, 0.12, X - 0.55, h - 0.3, Z, '#cfcfcf'), G.geo.cyl(0.04, 0.12, X + 0.55, h - 0.3, Z, '#cfcfcf'));
      rawB(X - 0.15, Z - 0.15, X + 0.15, Z + 0.15, h, 'none', 0, { hidden: true });
      return [x, h - 0.3, z];
    };
    api.sandbags = (x, z, len, rotY, rows) => {
      x = S(x); z = S(z); rows = rows || 2;
      const c = Math.cos(rotY), sn = Math.sin(rotY), n = Math.max(2, Math.round(len / 0.55));
      for (let r = 0; r < rows; r++) for (let i = 0; i < n - (r % 2); i++) {
        const o = -len / 2 + 0.28 + i * 0.55 + (r % 2) * 0.27;
        api.decor.push({ sph: true, r: 0.3, x: x + c * o, y: 0.13 + r * 0.22, z: z - sn * o, ry: rotY + (Math.random() - 0.5) * 0.12, sx: 0.98, sy: 0.46, sz: 0.72, color: ['#a8946a', '#9a865e', '#b09c72'][(i + r) % 3], seg: 9 });
      }
      const hx = Math.abs(c) * len / 2 + Math.abs(sn) * 0.3, hz = Math.abs(sn) * len / 2 + Math.abs(c) * 0.3;
      rawB(x - hx, z - hz, x + hx, z + hz, rows * 0.24 + 0.1, 'none', 0, { hidden: true });
    };
    api.tires = (x, z, n) => { x = S(x); z = S(z); for (let i = 0; i < n; i++) api.decor.push({ torus: true, r: 0.32, tube: 0.13, x, y: 0.13 + i * 0.25, z, rx: Math.PI / 2, color: '#1b1b1b', seg: 12 }); rawB(x - 0.45, z - 0.45, x + 0.45, z + 0.45, n * 0.25 + 0.05, 'none', 0, { hidden: true }); };
    api.reel = (x, z) => { x = S(x); z = S(z); api.decor.push(G.geo.cyl(0.6, 0.08, x, 0.6, z - 0.4, '#8a6a42', Math.PI / 2), G.geo.cyl(0.6, 0.08, x, 0.6, z + 0.4, '#8a6a42', Math.PI / 2), G.geo.cyl(0.3, 0.8, x, 0.6, z, '#2a2a2a', Math.PI / 2)); rawB(x - 0.6, z - 0.45, x + 0.6, z + 0.45, 1.2, 'none', 0, { hidden: true }); };
    api.stain = (x, z, sz) => api.ground.push({ kind: 'stain', x: S(x), z: S(z), sz: sz || 2 });
    api.pool = (x, z, sz) => api.ground.push({ kind: 'pool', x: S(x), z: S(z), sz: sz || 5 });
    jpApi(api, S, rawB, sc);
    return api;
  }

  // ---------- японский квартал: крыши, деревья, фонари, ворота ----------
  const _qa = new THREE.Quaternion(), _ea = new THREE.Euler(), _va = new THREE.Vector3(), _upv = new THREE.Vector3(0, 1, 0);
  // цилиндр между двумя точками (ветви, стебли, коньки вальм)
  function stick(a, b, r0, r1, color, seg) {
    _va.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const len = _va.length(); _va.normalize();
    _qa.setFromUnitVectors(_upv, _va); _ea.setFromQuaternion(_qa);
    return { cyl: true, r: r1, r2: r0, h: len, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, color, rx: _ea.x, ry: _ea.y, rz: _ea.z, seg: seg || 6 };
  }
  const rnd = (a, b) => a + Math.random() * (b - a);
  const PINK = ['#ffffff', '#fff2f6', '#ffe8ef', '#f8e2ea', '#fff8fa'];

  function jpApi(api, S, rawB, sc) {
    const box = G.geo.box, cyl = G.geo.cyl, dec = api.decor;
    // черепичная крыша над стенами (x0..x1, z0..z1) с верхом стен y: подъём h и свес ov — в метрах
    // opt: hip — вальмовая, col — оттенок черепицы, gable — цвет фронтона, along — 'x'|'z'
    api.roof = (x0, z0, x1, z1, y, h, ov, opt) => {
      opt = opt || {}; ov = ov == null ? 0.8 : ov;
      const X0 = S(Math.min(x0, x1)), X1 = S(Math.max(x0, x1)), Z0 = S(Math.min(z0, z1)), Z1 = S(Math.max(z0, z1));
      const ax = opt.along ? opt.along === 'x' : (X1 - X0) >= (Z1 - Z0);
      const r = { X0, X1, Z0, Z1, y, h, ov, hip: !!opt.hip, col: opt.col || '#ffffff', alongX: ax };
      api.roofs.push(r);
      const g = roofFrame(r);
      const P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa];
      const rc = opt.ridgeCol || '#2a2e34', trim = '#2b2622';
      const along = (len, hh, dd, aa, c, yy, col) => { const p = P(aa, c, yy); dec.push(box(ax ? len : dd, hh, ax ? dd : len, p[0], p[1], p[2], col)); };
      // доски свеса
      along(g.A1 - g.A0, 0.13, 0.1, g.mid, g.C0, g.ey - 0.05, trim); along(g.A1 - g.A0, 0.13, 0.1, g.mid, g.C1, g.ey - 0.05, trim);
      // конёк
      if (g.ra1 - g.ra0 > 0.05) along(g.ra1 - g.ra0 + 0.25, 0.26, 0.3, (g.ra0 + g.ra1) / 2, g.cc, g.top + 0.05, rc);
      if (!r.hip) {
        // фронтоны и концевые плитки они-гавара
        for (const aa of [g.a0w + 0.07, g.a1w - 0.07]) {
          const p = P(aa, g.cc, y);
          dec.push({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: opt.gable || '#e9e2d4', ry: ax ? 0 : HP, cs: 1 });
        }
        for (const aa of [g.A0 + 0.12, g.A1 - 0.12]) { const p = P(aa, g.cc, g.top + 0.12); dec.push(box(ax ? 0.26 : 0.36, 0.44, ax ? 0.36 : 0.26, p[0], p[1], p[2], rc)); }
        // торцевые доски вдоль скатов
        for (const aa of [g.A0, g.A1]) for (const s of [-1, 1]) dec.push(stick(P(aa, g.cc + s * g.hw, g.ey - 0.02), P(aa, g.cc, g.top), 0.07, 0.07, trim, 4));
      } else {
        for (const aa of [g.A0, g.A1]) { const p = P(aa, g.cc, g.ey - 0.05); dec.push(box(ax ? 0.1 : g.C1 - g.C0, 0.13, ax ? g.C1 - g.C0 : 0.1, p[0], p[1], p[2], trim)); }
        // рёбра вальм
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) dec.push(stick(P(aa, c, g.ey + 0.02), P(ra, g.cc, g.top + 0.06), 0.11, 0.09, rc, 5));
        if (opt.finial) { const p = P(g.mid, g.cc, g.top); dec.push(cyl(0.12, opt.finial, p[0], g.top + opt.finial / 2, p[2], '#6b5a3a', 0, 0, 0, 8)); if (opt.finial > 3) for (let i = 0; i < 7; i++) dec.push({ torus: true, r: 0.5 - i * 0.04, tube: 0.07, x: p[0], y: g.top + opt.finial * (0.25 + i * 0.08), z: p[2], rx: HP, color: '#8a7448', seg: 10 });
          dec.push({ sph: true, r: opt.finial > 3 ? 0.32 : 0.14, x: p[0], y: g.top + opt.finial, z: p[2], color: '#c9a54a', seg: 8 }); }
      }
    };
    // сакура: ствол, развилка, ветви и облака цветов; лепестки падают вокруг
    api.sakura = (x, z, h, k, far) => {
      const X = S(x), Z = S(z); h = h || 6; k = k || 1;
      const lean = Math.random() * 6.28, fh = h * 0.36;
      const fork = [X + Math.cos(lean) * 0.35 * k, fh, Z + Math.sin(lean) * 0.35 * k];
      dec.push(stick([X, 0, Z], [X, 0.6, Z], 0.42 * k, 0.32 * k, '#3a2a20', 7), stick([X, 0.5, Z], fork, 0.32 * k, 0.22 * k, '#4a3428', 7));
      const m = 4 + (Math.random() < 0.5 ? 1 : 0);
      const blob = (p, r) => api.blossoms.push({ sph: true, r, x: p[0], y: p[1], z: p[2], sx: 1.15, sy: 0.74, sz: 1.1, ry: Math.random() * 3, color: PINK[(Math.random() * PINK.length) | 0], seg: far ? 6 : 8 });
      for (let j = 0; j < m; j++) {
        const ang = lean + j * 6.28 / m + rnd(-0.35, 0.35), out = rnd(1.5, 2.3) * k, up = h * rnd(0.6, 0.72);
        const end = [fork[0] + Math.cos(ang) * out, up, fork[2] + Math.sin(ang) * out];
        dec.push(stick(fork, end, 0.2 * k, 0.09 * k, '#4a3428'));
        const midp = [(fork[0] + end[0]) / 2, (fork[1] + end[1]) / 2, (fork[2] + end[2]) / 2];
        const a2 = ang + rnd(-0.7, 0.7), end2 = [midp[0] + Math.cos(a2) * 1.4 * k, up + rnd(-0.6, 0.4), midp[2] + Math.sin(a2) * 1.4 * k];
        dec.push(stick(midp, end2, 0.1 * k, 0.05 * k, '#4a3428', 5));
        blob(end, rnd(1.25, 1.6) * k); blob(end2, rnd(1.0, 1.3) * k);
        blob([end[0] + Math.cos(ang) * 0.9 * k, end[1] - 0.7 * k, end[2] + Math.sin(ang) * 0.9 * k], rnd(0.8, 1.05) * k);
      }
      blob([fork[0], h * 0.86, fork[2]], 1.75 * k); blob([fork[0] + 0.6, h * 0.76, fork[2] - 0.5], 1.4 * k);
      if (!far) {
        rawB(X - 0.32 * k, Z - 0.32 * k, X + 0.32 * k, Z + 0.32 * k, fh + 0.3, 'none', 0, { hidden: true });
        api.ground.push({ kind: 'petals', x: X, z: Z, sz: 6.5 * k });
      }
      api.trees.push({ x: fork[0], y: h * 0.72, z: fork[2], r: 2.6 * k, petals: !far });
    };
    // каменный фонарь торо
    api.toro = (x, z, k) => {
      const X = S(x), Z = S(z); k = k || 1;
      const st = '#8e8b83', dk = '#77746c';
      dec.push(box(0.78 * k, 0.22 * k, 0.78 * k, X, 0.11 * k, Z, dk), cyl(0.3 * k, 0.18 * k, X, 0.31 * k, Z, st, 0, 0, 0, 6),
        cyl(0.13 * k, 0.78 * k, X, 0.79 * k, Z, st, 0, 0, 0, 8), box(0.64 * k, 0.16 * k, 0.64 * k, X, 1.25 * k, Z, dk),
        box(0.44 * k, 0.42 * k, 0.44 * k, X, 1.54 * k, Z, st), box(0.22 * k, 0.22 * k, 0.46 * k, X, 1.54 * k, Z, '#ffdc96'), box(0.46 * k, 0.22 * k, 0.22 * k, X, 1.54 * k, Z, '#ffdc96'),
        { cyl: true, r: 0.03, r2: 0.56 * k, h: 0.32 * k, x: X, y: 1.91 * k, z: Z, color: dk, seg: 4, ry: Math.PI / 4 }, { sph: true, r: 0.1 * k, x: X, y: 2.12 * k, z: Z, color: st, seg: 6 });
      api.lamps.push([X, 1.54 * k, Z, 0.8 * k]);
      rawB(X - 0.39 * k, Z - 0.39 * k, X + 0.39 * k, Z + 0.39 * k, 2.15 * k, 'none', 0, { hidden: true });
    };
    // бумажный фонарь тётин на шнуре (координаты x,z — в масштабе карты, y — в метрах)
    api.chochin = (x, y, z, col, top) => {
      const X = S(x), Z = S(z), t = Math.max(top || 0, y + 0.6);
      dec.push(cyl(0.01, t - y - 0.3, X, (t + y + 0.3) / 2, Z, '#1a1a1a', 0, 0, 0, 4), { sph: true, r: 0.24, x: X, y, z: Z, sy: 1.3, color: col || '#d6402a', seg: 7 },
        cyl(0.13, 0.06, X, y + 0.3, Z, '#1d1d1d', 0, 0, 0, 6), cyl(0.13, 0.06, X, y - 0.3, Z, '#1d1d1d', 0, 0, 0, 6));
      api.lamps.push([X, y, Z, 1.0]);
    };
    // ворота тории: w — пролёт (в масштабе карты), h — высота в метрах, rot — 0 (поперёк Z) или HP
    api.torii = (x, z, w, h, rot, col) => {
      const X = S(x), Z = S(z), W = S(w), c = col || '#c8321e', dx = rot ? 0 : 1, dz = rot ? 1 : 0, ry = rot ? HP : 0;
      for (const s of [-1, 1]) {
        const px = X + dx * s * W / 2, pz = Z + dz * s * W / 2;
        dec.push(cyl(0.21, h, px, h / 2, pz, c, 0, 0, 0, 12, 0.25), cyl(0.27, 0.5, px, 0.25, pz, '#1d1d1d', 0, 0, 0, 12));
        rawB(px - 0.28, pz - 0.28, px + 0.28, pz + 0.28, h, 'none', 0, { hidden: true });
        // приподнятые концы верхней балки
        dec.push(box(1.5, 0.3, 0.55, X + dx * s * (W / 2 + 0.55), h + 0.42, Z + dz * s * (W / 2 + 0.55), '#1d1d1d', rot ? -s * 0.12 : 0, ry, rot ? 0 : s * 0.12));
      }
      dec.push(box(W + 0.6, 0.3, 0.55, X, h + 0.36, Z, '#1d1d1d', 0, ry, 0), box(W + 1.7, 0.24, 0.44, X, h + 0.12, Z, c, 0, ry, 0),
        box(W + 0.9, 0.22, 0.24, X, h - 0.85, Z, c, 0, ry, 0), box(0.24, 0.7, 0.22, X, h - 0.4, Z, c, 0, ry, 0),
        box(0.62, 0.78, 0.1, X, h - 0.4, Z, '#24201c', 0, ry, 0), box(0.46, 0.6, 0.12, X, h - 0.4, Z, '#d9b23a', 0, ry, 0));
    };
    // горбатый мост вдоль X: ступени-столкновения + изогнутый настил и перила
    api.bridge = (xc, zc, len) => {
      const L = S(len), X = S(xc), Z = S(zc), Wd = 2.4;
      for (const [f0, f1, hh] of [[0, 0.15, 0.3], [0.15, 0.3, 0.6], [0.3, 0.7, 0.85], [0.7, 0.85, 0.6], [0.85, 1, 0.3]])
        rawB(X - L / 2 + f0 * L, Z - Wd / 2, X - L / 2 + f1 * L, Z + Wd / 2, hh, 'none', 0, { hidden: true });
      const yAt = (t) => 0.06 + 0.82 * Math.min(1, Math.sin(Math.PI * t) * 1.25);
      const N = 14, xAt = (t) => X - L / 2 + t * L;
      for (let i = 0; i < N; i++) {
        const t0 = i / N, t1 = (i + 1) / N, x0 = xAt(t0), x1 = xAt(t1), y0 = yAt(t0), y1 = yAt(t1);
        const ang = Math.atan2(y1 - y0, x1 - x0), ln = Math.hypot(x1 - x0, y1 - y0);
        dec.push(box(ln + 0.04, 0.14, Wd, (x0 + x1) / 2, (y0 + y1) / 2 - 0.07, Z, i % 2 ? '#7a4e30' : '#86583a', 0, 0, ang));
        for (const s of [-1, 1]) {
          dec.push(box(ln + 0.02, 0.08, 0.1, (x0 + x1) / 2, (y0 + y1) / 2 + 0.85, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, ang));
          if (i % 2 === 0) dec.push(cyl(0.06, 0.9, x0, y0 + 0.43, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, 0, 6));
        }
      }
      for (const t of [0, 1]) for (const s of [-1, 1]) dec.push(cyl(0.08, 1.0, xAt(t), 0.5, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, 0, 8), { sph: true, r: 0.12, x: xAt(t), y: 1.08, z: Z + s * (Wd / 2 - 0.06), sy: 1.4, color: '#b58a3a', seg: 8 });
      for (const t of [0.3, 0.5, 0.7]) for (const s of [-1, 1]) dec.push(cyl(0.11, yAt(t), xAt(t), yAt(t) / 2, Z + s * (Wd / 2 - 0.3), '#4a3426', 0, 0, 0, 8));
    };
    // пруд с карпами: вода на земле и каменная кайма
    api.pond = (x0, z0, x1, z1) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.ground.push({ kind: 'pond', x: (X0 + X1) / 2, z: (Z0 + Z1) / 2, w: X1 - X0, d: Z1 - Z0 });
      const per = 2 * (X1 - X0 + Z1 - Z0), n = Math.round(per / 0.75);
      for (let i = 0; i < n; i++) {
        let t = i / n * per, px, pz;
        if (t < X1 - X0) { px = X0 + t; pz = Z0; } else if ((t -= X1 - X0) < Z1 - Z0) { px = X1; pz = Z0 + t; }
        else if ((t -= Z1 - Z0) < X1 - X0) { px = X1 - t; pz = Z1; } else { t -= X1 - X0; px = X0; pz = Z1 - t; }
        const v = 92 + Math.random() * 34 | 0;
        dec.push({ sph: true, r: rnd(0.32, 0.46), x: px + rnd(-0.1, 0.1), y: 0.04, z: pz + rnd(-0.1, 0.1), sy: 0.55, ry: Math.random() * 3, color: `rgb(${v},${v - 2},${v - 8})`, seg: 7 });
      }
    };
    api.rock = (x, z, s) => {
      const X = S(x), Z = S(z);
      dec.push({ sph: true, r: s * 0.62, x: X, y: s * 0.18, z: Z, sx: 1.25, sy: 0.8, sz: 1.0, ry: Math.random() * 3, color: '#7b7870', seg: 7 },
        { sph: true, r: s * 0.38, x: X + s * 0.45, y: s * 0.08, z: Z - s * 0.3, sy: 0.7, ry: Math.random() * 3, color: '#6d6b64', seg: 6 });
      rawB(X - s * 0.62, Z - s * 0.55, X + s * 0.62, Z + s * 0.55, s * 0.62, 'none', 0, { hidden: true });
    };
    // пирамида бочек сакэ (rot: 0 — вдоль X, HP — вдоль Z), лицом в сторону face (+1/-1)
    api.taru = (x, z, n, rot, face) => {
      const X = S(x), Z = S(z), dx = rot ? 0 : 1, dz = rot ? 1 : 0, f = face || 1;
      const lab = ['#b02a1e', '#23326a', '#f2ece0', '#1d1d1d'];
      for (let r = 0; r < n; r++) for (let i = 0; i < n - r; i++) {
        const o = (i - (n - r - 1) / 2) * 0.7, px = X + dx * o, pz = Z + dz * o, y = r * 0.66 + 0.33;
        dec.push(cyl(0.34, 0.64, px, y, pz, '#dccb9c', 0, 0, 0, 9), cyl(0.35, 0.05, px, y + 0.26, pz, '#3a2a1a', 0, 0, 0, 9), cyl(0.35, 0.05, px, y - 0.26, pz, '#3a2a1a', 0, 0, 0, 9));
        dec.push(box(rot ? 0.03 : 0.34, 0.34, rot ? 0.34 : 0.03, px + (rot ? f * 0.335 : 0), y, pz + (rot ? 0 : f * 0.335), lab[(r * 3 + i) % 4]));
      }
      const hl = n * 0.35 + 0.02;
      rawB(X - (dx ? hl : 0.36), Z - (dz ? hl : 0.36), X + (dx ? hl : 0.36), Z + (dz ? hl : 0.36), n * 0.66, 'none', 0, { hidden: true });
    };
    // ручная тележка (rot: 0 — вдоль X, HP — вдоль Z)
    api.cart = (x, z, rot) => {
      const X = S(x), Z = S(z), ax = !rot, ry = rot ? HP : 0;
      const L = (lx, lz) => ax ? [X + lx, Z + lz] : [X + lz, Z - lx];
      dec.push(box(2.4, 0.12, 1.3, X, 0.78, Z, '#7a5434', 0, ry, 0));
      for (const s of [-1, 1]) { const p = L(0, s * 0.62); dec.push(box(2.4, 0.3, 0.06, p[0], 0.98, p[1], '#6a4a2e', 0, ry, 0)); }
      for (const s of [-1, 1]) {
        const p = L(0.2, s * 0.76);
        dec.push({ torus: true, r: 0.46, tube: 0.06, x: p[0], y: 0.46, z: p[1], ry, color: '#3a2a1e', seg: 16 });
        for (let k = 0; k < 4; k++) dec.push(box(0.9, 0.05, 0.05, p[0], 0.46, p[1], '#3a2a1e', 0, ry, k * Math.PI / 4));
      }
      for (const s of [-1, 1]) { const a0 = L(-1.2, s * 0.5), a1 = L(-2.5, s * 0.5); dec.push(stick([a0[0], 0.8, a0[1]], [a1[0], 0.35, a1[1]], 0.05, 0.04, '#6a4a2e', 5)); }
      const sk = ['#d8c8a0', '#cdbb8c', '#e2d4b0'];
      for (let i = 0; i < 4; i++) { const p = L(-0.75 + i * 0.5, (i % 2 ? 0.25 : -0.2)); dec.push({ sph: true, r: 0.36, x: p[0], y: 1.06, z: p[1], sx: 1.2, sy: 0.6, sz: 0.8, ry: ry + i, color: sk[i % 3], seg: 8 }); }
      const hx = ax ? 1.3 : 0.8, hz = ax ? 0.8 : 1.3;
      rawB(X - hx, Z - hz, X + hx, Z + hz, 1.3, 'none', 0, { hidden: true });
    };
    // лавка-ятай: прилавок, стойки, навес-крыша, занавес норэн
    api.stall = (x0, z0, x1, z1, face, col) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.B(x0, z0, x1, z1, 1.05, 'planks');
      for (const [px, pz] of [[X0 + 0.1, Z0 + 0.1], [X1 - 0.1, Z0 + 0.1], [X0 + 0.1, Z1 - 0.1], [X1 - 0.1, Z1 - 0.1]]) dec.push(cyl(0.07, 2.5, px, 1.25, pz, '#5a3c26', 0, 0, 0, 6));
      api.roof(x0 - 0.1, z0 - 0.1, x1 + 0.1, z1 + 0.1, 2.5, 0.7, 0.35, { col: '#b8a089', gable: '#5a3c26' });
      const fz = face > 0 ? Z1 + 0.05 : Z0 - 0.05, w = X1 - X0, n = Math.max(2, Math.round(w / 0.9));
      for (let i = 0; i < n; i++) dec.push(box(w / n - 0.06, 0.7, 0.03, X0 + (i + 0.5) * w / n, 2.12, fz, col || '#23326a'));
      const goods = ['#e8452a', '#f2a03a', '#e9e3d0', '#7aa04a', '#c8321e'];
      for (let i = 0; i < 6; i++) dec.push({ sph: true, r: 0.12, x: X0 + 0.4 + Math.random() * (w - 0.8), y: 1.12, z: (Z0 + Z1) / 2 + rnd(-0.3, 0.3), color: goods[i % 5], seg: 6 });
      dec.push(box(0.5, 0.18, 0.35, X0 + w * 0.3, 1.14, (Z0 + Z1) / 2, '#3a2a1e'), box(0.4, 0.22, 0.4, X0 + w * 0.7, 1.16, (Z0 + Z1) / 2 + 0.1, '#7a5a3a'));
    };
    // беседка азумая с вальмовой крышей
    api.pavilion = (x, z, s) => {
      const X = S(x), Z = S(z), hs = S(s) / 2;
      api.B(x - s / 2, z - s / 2, x + s / 2, z + s / 2, 0.25, 'planks');
      for (const [px, pz] of [[X - hs + 0.25, Z - hs + 0.25], [X + hs - 0.25, Z - hs + 0.25], [X - hs + 0.25, Z + hs - 0.25], [X + hs - 0.25, Z + hs - 0.25]]) {
        dec.push(cyl(0.12, 2.5, px, 1.5, pz, '#6a4a30', 0, 0, 0, 8));
        rawB(px - 0.16, pz - 0.16, px + 0.16, pz + 0.16, 2.75, 'none', 0, { hidden: true });
      }
      rawB(X - 0.9, Z - 0.3, X + 0.9, Z + 0.3, 0.7, 'none', 0, { hidden: true });
      dec.push(box(1.8, 0.08, 0.6, X, 0.68, Z, '#7a5434'), box(0.1, 0.42, 0.5, X - 0.8, 0.46, Z, '#5a3c26'), box(0.1, 0.42, 0.5, X + 0.8, 0.46, Z, '#5a3c26'));
      api.roof(x - s / 2, z - s / 2, x + s / 2, z + s / 2, 2.75, 1.5, 0.55, { hip: true, col: '#d4d8de', finial: 0.5 });
    };
    // двухэтажная машия: цоколь, решётка первого этажа, штукатурка с балками наверху, навес между этажами, главная крыша
    // o: h — высота, rise — подъём крыши, face — сторона фасада ('+z'|'-z'|'+x'|'-x'), shop — вывеска/норэн, solid:false — декорация за оградой
    api.house2 = (x0, z0, x1, z1, o) => {
      o = o || {}; const h = o.h || 5.6, lo = 2.5, X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      const sopt = o.solid === false ? { solid: false } : null;
      api.B(x0, z0, x1, z1, 0.3, 'stonewall', 0, sopt);
      api.B(x0, z0, x1, z1, lo - 0.3, 'koshi', 0.3, sopt);
      api.B(x0, z0, x1, z1, h - lo, 'plaster', lo, sopt);
      // горизонтальные балки и столбы
      const beam = '#3a2a1e';
      for (const yy of [lo + 0.05, h - 0.12]) {
        dec.push(box(X1 - X0 + 0.16, 0.22, 0.16, (X0 + X1) / 2, yy, Z0 - 0.04, beam), box(X1 - X0 + 0.16, 0.22, 0.16, (X0 + X1) / 2, yy, Z1 + 0.04, beam));
        dec.push(box(0.16, 0.22, Z1 - Z0 + 0.16, X0 - 0.04, yy, (Z0 + Z1) / 2, beam), box(0.16, 0.22, Z1 - Z0 + 0.16, X1 + 0.04, yy, (Z0 + Z1) / 2, beam));
      }
      const nx = Math.max(1, Math.round((X1 - X0) / 3.2)), nz = Math.max(1, Math.round((Z1 - Z0) / 3.2));
      for (let i = 0; i <= nx; i++) { const px = X0 + (X1 - X0) * i / nx; dec.push(box(0.16, h - lo, 0.1, px, (h + lo) / 2, Z0 - 0.05, beam), box(0.16, h - lo, 0.1, px, (h + lo) / 2, Z1 + 0.05, beam)); }
      for (let i = 0; i <= nz; i++) { const pz = Z0 + (Z1 - Z0) * i / nz; dec.push(box(0.1, h - lo, 0.16, X0 - 0.05, (h + lo) / 2, pz, beam), box(0.1, h - lo, 0.16, X1 + 0.05, (h + lo) / 2, pz, beam)); }
      // навес хисаси над первым этажом и главная крыша
      api.roof(x0, z0, x1, z1, lo + 0.25, 0.42, 0.95, { col: o.col || '#ffffff', ridgeCol: '#30343a' });
      api.roof(x0, z0, x1, z1, h, o.rise || 2.2, o.ov == null ? 1.0 : o.ov, { col: o.col || '#ffffff', gable: '#e9e2d4', hip: !!o.hip });
      // окна верхнего этажа (сёдзи) по длинным сторонам
      const long = (X1 - X0) >= (Z1 - Z0);
      const n = Math.max(1, Math.round((long ? X1 - X0 : Z1 - Z0) / 4));
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n;
        if (long) { const px = X0 + (X1 - X0) * t; api.decals.push({ cell: 1, x: px, y: lo + 1.55, z: Z0, w: 1.6, h: 1.5, n: '-z', atlas: 'jp' }, { cell: 1, x: px, y: lo + 1.55, z: Z1, w: 1.6, h: 1.5, n: '+z', atlas: 'jp' }); }
        else { const pz = Z0 + (Z1 - Z0) * t; api.decals.push({ cell: 1, x: X0, y: lo + 1.55, z: pz, w: 1.6, h: 1.5, n: '-x', atlas: 'jp' }, { cell: 1, x: X1, y: lo + 1.55, z: pz, w: 1.6, h: 1.5, n: '+x', atlas: 'jp' }); }
      }
    };
    // энгава: приподнятая деревянная веранда вдоль стены дома (x0..x1 по X при n='+z'/'-z'), со столбами и перилами
    api.veranda = (x0, z0, x1, z1, n) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.B(x0, z0, x1, z1, 0.4, 'planks');
      const along = n === '+z' || n === '-z', edge = n === '+z' ? Z1 : n === '-z' ? Z0 : n === '+x' ? X1 : X0;
      const len = along ? X1 - X0 : Z1 - Z0, m = Math.max(2, Math.round(len / 2.2));
      for (let i = 0; i <= m; i++) {
        const t = i / m, px = along ? X0 + len * t : edge, pz = along ? edge : Z0 + len * t;
        dec.push(cyl(0.07, 0.95, px, 0.85, pz, '#5a3c26', 0, 0, 0, 6));
      }
      const cx = along ? (X0 + X1) / 2 : edge, cz = along ? edge : (Z0 + Z1) / 2;
      dec.push(box(along ? len : 0.08, 0.07, along ? 0.08 : len, cx, 1.28, cz, '#6a4a30'), box(along ? len : 0.05, 0.05, along ? 0.05 : len, cx, 0.86, cz, '#6a4a30'));
      // ступенька
      const sx = along ? (X0 + X1) / 2 : edge + (n === '+x' ? 0.35 : -0.35), sz = along ? edge + (n === '+z' ? 0.35 : -0.35) : (Z0 + Z1) / 2;
      rawB(sx - (along ? 0.8 : 0.3), sz - (along ? 0.3 : 0.8), sx + (along ? 0.8 : 0.3), sz + (along ? 0.3 : 0.8), 0.2, 'stonewall', 0);
    };
    // каменная лестница на платформу: dir — направление подъёма ('+z' и т.д.), w — ширина, top — высота платформы
    api.stairs = (x, z, dir, w, top) => {
      const X = S(x), Z = S(z), W = S(w), n = Math.max(1, Math.round(top / 0.4)), dx = dir === '+x' ? 1 : dir === '-x' ? -1 : 0, dz = dir === '+z' ? 1 : dir === '-z' ? -1 : 0;
      for (let i = 0; i < n; i++) {
        const hh = top * (i + 1) / n, d0 = i * 0.45, d1 = (n - 0) * 0.45;
        const ax = X + dx * d0, az = Z + dz * d0, bx = X + dx * d1, bz = Z + dz * d1;
        rawB(Math.min(ax, bx) - (dx ? 0 : W / 2), Math.min(az, bz) - (dz ? 0 : W / 2), Math.max(ax, bx) + (dx ? 0 : W / 2), Math.max(az, bz) + (dz ? 0 : W / 2), hh, 'stonewall', 0);
      }
    };
    // живая изгородь (с проходами, если даны gaps — массив [z0,z1] или [x0,x1] пропусков по длинной оси)
    api.hedge = (x0, z0, x1, z1, h, gaps) => {
      const along = Math.abs(x1 - x0) >= Math.abs(z1 - z0);
      let segs = [[along ? x0 : z0, along ? x1 : z1]];
      for (const g of gaps || []) { const out = []; for (const [a0, a1] of segs) { if (g[1] <= a0 || g[0] >= a1) out.push([a0, a1]); else { if (g[0] > a0) out.push([a0, g[0]]); if (g[1] < a1) out.push([g[1], a1]); } } segs = out; }
      for (const [a0, a1] of segs) {
        if (along) api.B(a0, z0, a1, z1, h || 1.25, 'hedge'); else api.B(x0, a0, x1, a1, h || 1.25, 'hedge');
        const n = Math.max(1, Math.round(S(a1 - a0) / 1.1));
        for (let i = 0; i < n; i++) {
          const t = (i + 0.5) / n, px = along ? S(a0 + (a1 - a0) * t) : S((x0 + x1) / 2), pz = along ? S((z0 + z1) / 2) : S(a0 + (a1 - a0) * t);
          dec.push({ sph: true, r: 0.62, x: px, y: (h || 1.25) - 0.05, z: pz, sx: along ? 1.1 : 0.75, sy: 0.5, sz: along ? 0.75 : 1.1, color: i % 2 ? '#4f7a36' : '#5a8a3c', seg: 7 });
        }
      }
    };
    // деревянный забор с перекладинами
    api.fence = (x0, z0, x1, z1) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1), along = Math.abs(X1 - X0) >= Math.abs(Z1 - Z0), len = along ? X1 - X0 : Z1 - Z0;
      const n = Math.max(1, Math.round(len / 1.6)), cx = (X0 + X1) / 2, cz = (Z0 + Z1) / 2;
      for (let i = 0; i <= n; i++) { const t = i / n; dec.push(box(0.12, 1.2, 0.12, along ? X0 + len * t : cx, 0.6, along ? cz : Z0 + len * t, '#4a3426')); }
      for (const yy of [0.5, 1.0]) dec.push(box(along ? len : 0.06, 0.1, along ? 0.06 : len, cx, yy, cz, '#6a4a30'));
      rawB(Math.min(X0, X1) - 0.06, Math.min(Z0, Z1) - 0.06, Math.max(X0, X1) + 0.06, Math.max(Z0, Z1) + 0.06, 1.2, 'none', 0, { hidden: true });
    };
    api.bench = (x, z, rot) => {
      const X = S(x), Z = S(z), ry = rot ? HP : 0;
      dec.push(box(1.8, 0.08, 0.5, X, 0.45, Z, '#7a5434', 0, ry, 0), box(0.12, 0.42, 0.42, X + (rot ? 0 : 0.75), 0.21, Z + (rot ? 0.75 : 0), '#4a3426', 0, ry, 0), box(0.12, 0.42, 0.42, X - (rot ? 0 : 0.75), 0.21, Z - (rot ? 0.75 : 0), '#4a3426', 0, ry, 0));
      dec.push(box(1.5, 0.05, 0.4, X, 0.52, Z, '#b02a1e', 0, ry, 0));
      const hx = rot ? 0.28 : 0.92, hz = rot ? 0.92 : 0.28;
      rawB(X - hx, Z - hz, X + hx, Z + hz, 0.5, 'none', 0, { hidden: true });
    };
    // горшок с растением
    api.pot = (x, z, k) => {
      const X = S(x), Z = S(z); k = k || 1;
      dec.push(cyl(0.22 * k, 0.32 * k, X, 0.16 * k, Z, '#6b4a3a', 0, 0, 0, 8, 0.17 * k));
      for (let i = 0; i < 4; i++) dec.push({ sph: true, r: 0.2 * k, x: X + rnd(-0.1, 0.1) * k, y: 0.42 * k + i * 0.06, z: Z + rnd(-0.1, 0.1) * k, sx: 1.2, sy: 0.7, color: i % 2 ? '#4f8a3a' : '#5f9a42', seg: 6 });
      rawB(X - 0.24 * k, Z - 0.24 * k, X + 0.24 * k, Z + 0.24 * k, 0.5 * k, 'none', 0, { hidden: true });
    };
    // каменная чаша цукубай с бамбуковым желобом
    api.basin = (x, z) => {
      const X = S(x), Z = S(z);
      dec.push({ sph: true, r: 0.48, x: X, y: 0.3, z: Z, sy: 0.7, color: '#767a74', seg: 9 }, cyl(0.3, 0.04, X, 0.6, Z, '#2a5a5e', 0, 0, 0, 10));
      dec.push(cyl(0.05, 1.0, X + 0.5, 0.5, Z, '#b8b56a', 0, 0, 0, 6), cyl(0.04, 0.5, X + 0.3, 0.95, Z, '#b8b56a', 0, 0, HP, 6));
      for (let i = 0; i < 4; i++) dec.push({ sph: true, r: 0.14, x: X + rnd(-0.8, 0.8), y: 0.06, z: Z + rnd(-0.8, 0.8), sy: 0.5, color: '#7e8278', seg: 6 });
      rawB(X - 0.5, Z - 0.5, X + 0.5, Z + 0.5, 0.7, 'none', 0, { hidden: true });
    };
    // бумажный зонт вагаса, раскрытый (стоит или лежит)
    api.wagasa = (x, z, col, tilt) => {
      const X = S(x), Z = S(z), c = col || '#c8321e';
      dec.push({ cyl: true, r: 0.02, r2: 1.05, h: 0.32, x: X, y: 1.9, z: Z, color: c, seg: 16, rz: tilt || 0 }, cyl(0.025, 1.9, X, 0.95, Z, '#5a3c26', 0, 0, tilt || 0, 6));
      for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; dec.push(box(0.02, 0.012, 1.0, X + Math.cos(an) * 0.5, 1.75, Z + Math.sin(an) * 0.5, '#f2e6c8', 0, -an + HP, 0)); }
      rawB(X - 0.15, Z - 0.15, X + 0.15, Z + 0.15, 1.9, 'none', 0, { hidden: true });
    };
    // колокол на деревянной раме
    api.bell = (x, z) => {
      const X = S(x), Z = S(z);
      api.B(x - 1.1, z - 1.1, x + 1.1, z + 1.1, 0.45, 'stonewall');
      for (const [px, pz] of [[X - 0.85, Z - 0.85], [X + 0.85, Z - 0.85], [X - 0.85, Z + 0.85], [X + 0.85, Z + 0.85]]) { dec.push(cyl(0.11, 3.0, px, 1.95, pz, '#5a3c26', 0, 0, 0, 8)); rawB(px - 0.14, pz - 0.14, px + 0.14, pz + 0.14, 3.5, 'none', 0, { hidden: true }); }
      dec.push(box(2.2, 0.2, 0.2, X, 3.45, Z - 0.85, '#5a3c26'), box(2.2, 0.2, 0.2, X, 3.45, Z + 0.85, '#5a3c26'), box(0.2, 0.2, 2.0, X, 3.45, Z, '#5a3c26'));
      dec.push({ cyl: true, r: 0.42, r2: 0.3, h: 1.0, x: X, y: 2.4, z: Z, color: '#4b5a3a', seg: 14 }, cyl(0.1, 0.4, X, 3.1, Z, '#3a2a1e', 0, 0, 0, 6), cyl(0.44, 0.06, X, 1.9, Z, '#3f4a30', 0, 0, 0, 14));
      dec.push(cyl(0.12, 1.6, X + 1.4, 2.6, Z, '#6a4a30', 0, 0, HP, 8));
      api.roof(x - 1.3, z - 1.3, x + 1.3, z + 1.3, 3.55, 1.0, 0.5, { hip: true, col: '#8cbcaa', ridgeCol: '#3d5a50' });
      rawB(X - 0.45, Z - 0.45, X + 0.45, Z + 0.45, 3.0, 'none', 0, { hidden: true });
    };
    // стена с табличками эма (укрытие)
    api.emaWall = (x, z, w, rot) => {
      const X = S(x), Z = S(z), W = S(w), ry = rot ? HP : 0;
      dec.push(box(W, 0.12, 0.3, X, 1.85, Z, '#5a3c26', 0, ry, 0), box(W, 1.3, 0.08, X, 1.15, Z, '#8a6a46', 0, ry, 0));
      for (const s of [-1, 1]) dec.push(box(0.14, 1.9, 0.14, X + (rot ? 0 : s * W / 2), 0.95, Z + (rot ? s * W / 2 : 0), '#4a3426'));
      const n = Math.max(2, Math.round(W / 0.5));
      for (let i = 0; i < n; i++) for (let r = 0; r < 2; r++) for (const sd of [-1, 1]) { const t = (i + 0.5) / n - 0.5, px = X + (rot ? 0 : t * W), pz = Z + (rot ? t * W : 0); dec.push(box(0.34, 0.28, 0.04, px + (rot ? sd * 0.06 : 0), 1.3 - r * 0.34, pz + (rot ? 0 : sd * 0.06), ['#c8a06a', '#d8b27a', '#b89060'][(i + r) % 3], 0, ry, 0)); }
      api.roof(x - (rot ? 0.5 : w / 2), z - (rot ? w / 2 : 0.5), x + (rot ? 0.5 : w / 2), z + (rot ? w / 2 : 0.5), 1.95, 0.4, 0.3, { col: '#d4d8de', along: rot ? 'z' : 'x' });
      rawB(X - (rot ? 0.2 : W / 2), Z - (rot ? W / 2 : 0.2), X + (rot ? 0.2 : W / 2), Z + (rot ? W / 2 : 0.2), 2.0, 'none', 0, { hidden: true });
    };
    // маленькое придорожное святилище хокора
    api.hokora = (x, z, rot) => {
      const X = S(x), Z = S(z), ry = rot ? HP : 0;
      api.B(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 0.5, 'stonewall');
      dec.push(box(1.0, 1.2, 0.9, X, 1.1, Z, '#6a4a30', 0, ry, 0), box(0.6, 0.9, 0.06, X + (rot ? 0.46 : 0), 1.05, Z + (rot ? 0 : 0.46), '#2a1c14', 0, ry, 0));
      dec.push(box(0.1, 1.5, 0.1, X - 0.6, 1.25, Z - 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X + 0.6, 1.25, Z - 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X - 0.6, 1.25, Z + 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X + 0.6, 1.25, Z + 0.6, '#c8321e'));
      api.roof(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 1.95, 0.7, 0.35, { hip: true, col: '#d4d8de' });
      rawB(X - 0.55, Z - 0.5, X + 0.55, Z + 0.5, 2.2, 'none', 0, { hidden: true });
      api.lamps.push([X, 1.0, Z + (rot ? 0 : 0.6), 0.6]);
    };
    // колодец с крышей
    api.well = (x, z) => {
      const X = S(x), Z = S(z);
      api.B(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 0.85, 'stonewall');
      dec.push(box(2.0, 0.04, 2.0, X, 0.86, Z, '#203a40'), cyl(0.08, 2.4, X - 1.0, 1.2, Z, '#5a3c26', 0, 0, 0, 6), cyl(0.08, 2.4, X + 1.0, 1.2, Z, '#5a3c26', 0, 0, 0, 6), cyl(0.05, 2.2, X, 2.25, Z, '#5a3c26', 0, 0, HP, 6), cyl(0.2, 0.3, X, 1.6, Z, '#6a4a2e'), box(0.28, 0.3, 0.28, X + 0.3, 1.0, Z + 0.3, '#5a3c26'));
      api.roof(x - 1.1, z - 1.1, x + 1.1, z + 1.1, 2.4, 0.7, 0.3, { along: 'x' });
    };
    // куст бамбука
    api.bamboo = (x, z, n) => {
      const X = S(x), Z = S(z);
      const cols = ['#7f9c3c', '#8aa645', '#6f8e34', '#94a84e'];
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.28, rr = Math.random() * 0.7, px = X + Math.cos(a) * rr, pz = Z + Math.sin(a) * rr, h = rnd(4.5, 6.8);
        const tx = px + rnd(-0.4, 0.4), tz = pz + rnd(-0.4, 0.4);
        dec.push(stick([px, 0, pz], [tx, h, tz], 0.06, 0.045, cols[i % 4], 6));
        for (let k = 0; k < 4; k++) {
          const t = 0.55 + k * 0.13, lx = px + (tx - px) * t, lz = pz + (tz - pz) * t;
          dec.push({ sph: true, r: 0.5, x: lx + rnd(-0.3, 0.3), y: h * t, z: lz + rnd(-0.3, 0.3), sx: 0.35, sy: 0.12, sz: 1.0, rx: rnd(-0.4, 0.4), ry: Math.random() * 6.28, color: k % 2 ? '#5f8a32' : '#6f9a3a', seg: 6 });
        }
      }
      rawB(X - 0.75, Z - 0.75, X + 0.75, Z + 0.75, 3, 'none', 0, { hidden: true });
    };
  }

  // размеры крыши: стены, свесы, конёк
  function roofFrame(r) {
    const ax = r.alongX;
    const a0w = ax ? r.X0 : r.Z0, a1w = ax ? r.X1 : r.Z1, c0w = ax ? r.Z0 : r.X0, c1w = ax ? r.Z1 : r.X1;
    const cc = (c0w + c1w) / 2, hw0 = (c1w - c0w) / 2, sl = r.h / hw0, ov = r.ov;
    const A0 = a0w - ov, A1 = a1w + ov, C0 = c0w - ov, C1 = c1w + ov, hw = hw0 + ov, mid = (A0 + A1) / 2;
    return {
      a0w, a1w, cc, hw0, hw, A0, A1, C0, C1, mid, ey: r.y - ov * sl, top: r.y + r.h,
      ra0: r.hip ? Math.min(A0 + hw, mid) : A0, ra1: r.hip ? Math.max(A1 - hw, mid) : A1
    };
  }

  // ===================== «Пыльный квартал» =====================
  function layoutDust(a) {
    const { B, crate, stack, lintel } = a;
    B(-41, -33, 41, -32, 7, 'wall'); B(-41, 32, 41, 33, 7, 'wall');
    B(-41, -32, -40, 32, 7, 'wall'); B(40, -32, 41, 32, 7, 'wall');
    for (const zc of [14, -14]) {
      const z0 = zc - 0.5, z1 = zc + 0.5;
      B(-40, z0, -30, z1, 5, 'wall'); B(-25, z0, -3, z1, 5, 'wall'); B(3, z0, 25, z1, 5, 'wall'); B(30, z0, 40, z1, 5, 'wall');
      lintel(-30, z0, -25, z1, 3.6, 5, 'wall'); lintel(-3, z0, 3, z1, 3.6, 5, 'wall'); lintel(25, z0, 30, z1, 3.6, 5, 'wall');
    }
    for (const xc of [-12, 12]) {
      const x0 = xc - 0.5, x1 = xc + 0.5;
      B(x0, -13.5, x1, -2.5, 5, 'wall'); B(x0, 2.5, x1, 13.5, 5, 'wall'); lintel(x0, -2.5, x1, 2.5, 3.6, 5, 'wall');
    }
    // дом
    B(-36, 6.4, -29, 7, 4.2, 'stucco'); B(-26, 6.4, -18, 7, 4.2, 'stucco'); lintel(-29, 6.4, -26, 7, 2.8, 4.2, 'stucco');
    B(-36, -7, -29, -6.4, 4.2, 'stucco'); B(-26, -7, -18, -6.4, 4.2, 'stucco'); lintel(-29, -7, -26, -6.4, 2.8, 4.2, 'stucco');
    B(-36, -7, -35.4, 7, 4.2, 'stucco');
    B(-18.6, -7, -18, -4, 4.2, 'stucco'); B(-18.6, -4, -18, -1.5, 1.1, 'stucco'); lintel(-18.6, -4, -18, -1.5, 2.2, 4.2, 'stucco');
    B(-18.6, 1.5, -18, 7, 4.2, 'stucco'); lintel(-18.6, -1.5, -18, 1.5, 2.8, 4.2, 'stucco');
    B(-36.3, -7.3, -17.7, 7.3, 0.4, 'roof', 4.2);
    B(-35.4, -0.3, -31, 0.3, 1.1, 'stucco');
    crate(-33.6, -4.6, 1.2); stack(-20.2, 4.8, 1.3); crate(-24, -4.8, 1.0);
    B(-30, 2.6, -27.5, 3.8, 0.85, 'metal');
    crate(-15, -9.5, 1.3); crate(-15.7, 9.2, 1.2); crate(-14.2, 4.5, 1.0);
    crate(-38.5, -2, 1.1); crate(-38.4, 10.5, 1.2);
    // центр
    B(-1.5, -1.5, 1.5, 1.5, 2.6, 'concrete'); B(-7, 4.5, -4, 5.3, 1.1, 'concrete'); B(4, -5.3, 7, -4.5, 1.1, 'concrete');
    stack(-7, -7, 1.4); stack(7, 7, 1.4); crate(8.5, -10.5, 1.2); crate(-8.5, 10.5, 1.2); crate(-2.2, 10.8, 1.0); crate(2.2, -10.8, 1.0);
    // контейнеры
    B(17, 3, 19.5, 9, 2.6, 'contRed'); B(26, -5, 32, -2.5, 2.6, 'contBlue'); B(26, -5, 32, -2.5, 2.6, 'contRed', 2.6);
    B(33, 4, 35.5, 10, 2.6, 'contGreen'); B(20, -11, 22.5, -5.5, 2.6, 'contBlue'); B(35, -9, 40, -6.5, 2.6, 'contGreen');
    crate(15, -3, 1.2); stack(25, 6, 1.3); crate(29, 10, 1.0); crate(37.5, -1, 1.2); B(23, -10.4, 27, -9.6, 1.0, 'concrete'); crate(14.5, 11, 1.1);
    // север (спецназ) + точки A/B
    B(-14, 21, 14, 31.5, 0.02, 'pave', 0, { solid: false });
    B(-40, 24, -30, 32, 5, 'stucco'); B(-40.2, 23.8, -29.8, 32, 0.3, 'roof', 5);
    B(30, 22, 40, 32, 4.5, 'wall');
    crate(-20, 18, 1.3); crate(-27.5, 19, 1.2); B(-3, 18.6, 3, 19.4, 1.1, 'concrete');
    crate(27.5, 19, 1.2); stack(18, 25, 1.3); crate(-12, 27, 1.2); crate(-22, 27.5, 1.1);
    B(6, 24, 8.5, 30, 2.8, 'metal'); B(6.1, 30, 8.4, 31.7, 2.0, 'metal');
    stack(-35, 19, 1.3); B(-33, 21.6, -29, 22.4, 1.1, 'concrete');
    B(33, 16, 39, 18.5, 2.6, 'contBlue'); crate(22, 17, 1.2);
    a.letter('A', -30, 18.5, 4.5); a.letter('B', 26, 17, 4.5);
    // юг (налётчики)
    B(-14, -31.5, 14, -21, 0.02, 'pave', 0, { solid: false });
    B(30, -32, 40, -24, 5, 'stucco'); B(29.8, -32, 40.2, -23.8, 0.3, 'roof', 5);
    B(-40, -32, -30, -22, 4.5, 'wall');
    crate(20, -18, 1.3); crate(27.5, -19, 1.2); B(-3, -19.4, 3, -18.6, 1.1, 'concrete');
    crate(-27.5, -19, 1.2); stack(-18, -25, 1.3); crate(12, -27, 1.2); crate(22, -27.5, 1.1);
    B(-8.5, -30, -6, -24, 2.8, 'metal'); B(-8.4, -31.7, -6.1, -30, 2.0, 'metal');
    // дополнительные укрытия на увеличенной карте
    crate(-6, 8.5, 1.1); crate(6, -8.5, 1.1); B(-25, 9.6, -21, 10.4, 1.1, 'concrete'); B(21, -10.4, 25, -9.6, 1.1, 'concrete');
    stack(-27.5, 27.5, 1.2); stack(27.5, -27.5, 1.2); crate(16.5, 18, 1.0); crate(-16.5, -18, 1.0);
    detailDust(a);
  }

  // фасады, навесы, пальмы, провода — только визуальные детали (+ мешки с песком как укрытия)
  function detailDust(a) {
    const D = a.decal;
    // дом: окна, ставни, вывеска кафе
    D(0, -33, 2.3, 7, 1.5, 3, '+z'); D(3, -21.5, 2.3, 7, 1.5, 3, '+z'); D(4, -23.6, 3.0, 7, 2.2, 4.4, '+z');
    D(1, -33, 2.1, -7, 1.6, 3.2, '-z'); D(0, -22, 2.3, -7, 1.5, 3, '-z'); D(6, -24.7, 1.9, -7, 1.1, 2.2, '-z');
    D(3, -36, 2.3, -3, 1.5, 3, '-x'); D(0, -36, 2.3, 3.5, 1.5, 3, '-x');
    D(6, -18, 1.9, -5.6, 1.1, 2.2, '+x'); D(1, -18, 2.1, 4.3, 1.6, 3.2, '+x');
    a.awning(-27.5, 3.15, 7, 3.8, 1.3, '+z', '#b0392b');
    a.awning(-18, 3.05, 0, 3.6, 1.2, '+x', '#2f6f8a');
    // здания у спавнов
    D(1, -37.5, 2.5, 24, 1.6, 3.2, '-z'); D(0, -33, 2.6, 24, 1.5, 3, '-z'); D(2, -30, 1.6, 28.5, 1.6, 3.2, '+x'); D(3, -30, 2.6, 25.6, 1.5, 3, '+x');
    a.awning(-35.2, 4.1, 24, 8.4, 1.4, '-z', '#2f6f8a');
    D(1, 37.5, 2.5, -24, 1.6, 3.2, '+z'); D(0, 33, 2.6, -24, 1.5, 3, '+z'); D(2, 30, 1.6, -28.5, 1.6, 3.2, '-x'); D(3, 30, 2.6, -25.6, 1.5, 3, '-x');
    a.awning(35.2, 4.1, -24, 8.4, 1.4, '+z', '#b0392b');
    D(7, 33, 3.4, 22, 1.2, 2.4, '-z'); D(6, 36.5, 1.8, 22, 1.1, 2.2, '-z');
    D(7, -33, 3.4, -22, 1.2, 2.4, '+z'); D(6, -36.5, 1.8, -22, 1.1, 2.2, '+z');
    // плакаты и решётки на стенах кварталов
    for (const zc of [14, -14]) {
      const s = zc > 0 ? 1 : -1;
      D(6, -15, 1.8, zc + 0.5 * s, 1.1, 2.2, s > 0 ? '+z' : '-z'); D(7, 18, 3.6, zc + 0.5 * s, 1.2, 2.4, s > 0 ? '+z' : '-z');
      D(7, -36, 3.6, zc - 0.5 * s, 1.2, 2.4, s > 0 ? '-z' : '+z'); D(6, 8, 1.8, zc - 0.5 * s, 1.1, 2.2, s > 0 ? '-z' : '+z');
    }
    D(6, 12.5, 1.8, 8, 1.1, 2.2, '+x'); D(6, -12.5, 1.8, -8, 1.1, 2.2, '-x');
    D(3, -40, 3.4, -20, 1.5, 3, '+x'); D(1, 40, 3.4, 0, 1.6, 3.2, '-x'); D(3, 40, 3.4, 8, 1.5, 3, '-x'); D(0, -40, 3.4, 18, 1.5, 3, '+x');
    D(1, -20, 3.6, 32, 1.6, 3.2, '-z'); D(1, 20, 3.6, -32, 1.6, 3.2, '+z');
    // пальмы
    a.palm(-11, 23.5, 6.8); a.palm(11.2, 22, 6.2); a.palm(-11.5, -23.2, 6.4); a.palm(12, -22.5, 7);
    a.palm(-38, -11.5, 6.6); a.palm(38, 12.6, 6.4); a.palm(-37.8, 12.4, 5.8);
    // столбы и провода
    const p1 = a.pole(-16, 30.8, 7.6), p2 = a.pole(16, 30.8, 7.6), p3 = a.pole(16, -30.8, 7.6), p4 = a.pole(-16, -30.8, 7.6);
    a.wire(p1, p2, 1.1); a.wire(p1, [-30, 4.7, 28], 0.5); a.wire(p2, [30, 4.3, 27], 0.5);
    a.wire(p3, p4, 1.1); a.wire(p3, [30, 4.7, -28], 0.5); a.wire(p4, [-30, 4.3, -27], 0.5);
    // мешки с песком на точках
    a.sandbags(-25, 21.6, 3, 0, 2); a.sandbags(-37.2, 16.6, 2.2, Math.PI / 2, 2);
    a.sandbags(31, 20.6, 2.8, 0, 2); a.sandbags(19.2, 19.6, 2.2, Math.PI / 2, 2);
    // пятна и разбитые бочки
    a.stain(-27, 3.2, 2.5); a.stain(0, -6, 3); a.stain(24, -1, 2.2); a.stain(-5, 26, 2.4); a.stain(6, -27, 2.6);
    a.barrel(-38.6, -5.2, '#8a5a2a'); a.barrel(38.4, -12.6, '#3b5f3a'); a.barrel(23.6, 9.6, '#8a2d22');
  }

  // ===================== «Гавань»: портовый квартал на закате =====================
  // 88×68 м, три линии. Налётчики — юг (рыбный рынок), спецназ — север (площадь у морвокзала).
  // B — склад №3 (запад): через подъезд жилого дома, западный проулок с бельём или подворотню с площади.
  // A — причал с портальным краном (восток): длинная — вдоль набережной, короткая — через кафе «Чайка».
  // Проёмы центрированы на полуцелых координатах — там центры клеток навигационной сетки (шаг 1 м).
  function layoutHarbor(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 9157; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    const PL = new THREE.Color('#ebe5d9'), wc = (t, k) => '#' + new THREE.Color(t).multiply(PL).multiplyScalar(k || 1).getHexString();
    // бирюзовые контейнеры — свой материал (регистрируем здесь, чтобы не трогать общую таблицу)
    if (!MAT_FACTORY.hbTeal) MAT_FACTORY.hbTeal = () => lam('container', '#2c7a74', 1.5);
    const CREAM = '#f7e6c4', PEACH = '#f6c49c', SALMON = '#eba083', OCHRE = '#efc07a', ROSE = '#ecb4a6', SKY = '#c4d6da', SAND = '#f0dcb4', MINT = '#cfe0c4';
    const IRON = '#26282b', WOOD = '#6b4a2e', WOOD_L = '#9c7350', TEAL = '#2f7f7a', TERRA = '#b65a33', TERRA_D = '#8a3f22', YEL = '#e2a72a', BRONZE = '#4f4636';
    const NN = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] };
    const isX = (n) => NN[n][0] !== 0;
    // точка на плоскости стены c (нормаль n), t — вдоль стены, o — вынос наружу
    const at = (n, c, t, o) => { const N = NN[n]; return N[0] ? [c + N[0] * (o || 0), t] : [t, c + N[1] * (o || 0)]; };
    const wbox = (n, c, t, y, len, hh, dep, col, list) => { const X = isX(n), p = at(n, c, t, dep / 2); (list || a.decor).push(box(X ? dep : len, hh, X ? len : dep, p[0], y, p[1], col)); };
    const PD = (cell, n, c, t, y, w, h, lit) => { const p = at(n, c, t); a.decals.push({ cell, x: p[0], y, z: p[1], w, h, n, atlas: 'port', lit: !!lit }); };
    const FD = (cell, n, c, t, y, w, h, lit) => { const p = at(n, c, t); a.decals.push({ cell, x: p[0], y, z: p[1], w, h, n, atlas: 'facade', lit: !!lit }); };
    const W = (x0, z0, x1, z1, h, tint, y0) => B(x0, z0, x1, z1, h, 'plaster', y0, { tint, ch: 1 });
    const floor = (x0, z0, x1, z1, mat, tint) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false, tint });
    const hid = (x0, z0, x1, z1, h) => B(x0, z0, x1, z1, h, 'none', 0, { hidden: true });

    // ---------- помощники ----------
    // карниз плоской крыши: плита чуть шире стен и тёмная кровля поверх
    const cornice = (x0, z0, x1, z1, y, col) => {
      D(box(x1 - x0 + 0.34, 0.34, z1 - z0 + 0.34, (x0 + x1) / 2, y + 0.17, (z0 + z1) / 2, col),
        box(x1 - x0 + 0.18, 0.1, z1 - z0 + 0.18, (x0 + x1) / 2, y - 0.04, (z0 + z1) / 2, '#6f665c'));
      if (x1 - x0 > 1.2 && z1 - z0 > 1.2) D(box(x1 - x0 - 0.3, 0.04, z1 - z0 - 0.3, (x0 + x1) / 2, y + 0.35, (z0 + z1) / 2, '#7a7068'));
    };
    // межэтажный пояс вдоль фасада
    const band = (n, c, t0, t1, y, col) => wbox(n, c, (t0 + t1) / 2, y, t1 - t0, 0.16, 0.1, col);
    // черепичная крыша (коппо): вальмовая или двускатная с фронтонами под цвет стены
    const roof = (x0, z0, x1, z1, y, h, ov, o) => {
      o = o || {};
      const r = { X0: x0, X1: x1, Z0: z0, Z1: z1, y, h, ov, hip: !!o.hip, col: o.col || '#ffffff', alongX: o.along ? o.along === 'x' : (x1 - x0) >= (z1 - z0) };
      a.roofs.push(r);
      const g = roofFrame(r), ax = r.alongX, P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa], RC = o.ridge || '#a3482a', ED = TERRA_D;
      for (const c of [g.C0, g.C1]) { const p = P(g.mid, c, g.ey - 0.05); D(box(ax ? g.A1 - g.A0 : 0.13, 0.12, ax ? 0.13 : g.A1 - g.A0, p[0], p[1], p[2], ED)); }
      if (g.ra1 - g.ra0 > 0.05) { const p = P((g.ra0 + g.ra1) / 2, g.cc, g.top + 0.02); D(cyl(0.14, g.ra1 - g.ra0 + 0.3, p[0], p[1], p[2], RC, ax ? 0 : HP, 0, ax ? HP : 0, 6)); }
      if (r.hip) {
        for (const aa of [g.A0, g.A1]) { const p = P(aa, g.cc, g.ey - 0.05); D(box(ax ? 0.13 : g.C1 - g.C0, 0.12, ax ? g.C1 - g.C0 : 0.13, p[0], p[1], p[2], ED)); }
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) D(stick(P(aa, c, g.ey + 0.03), P(ra, g.cc, g.top + 0.04), 0.12, 0.12, RC, 5));
      } else {
        for (const aa of [g.a0w + 0.06, g.a1w - 0.06]) { const p = P(aa, g.cc, y); D({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: o.gable || '#e8dcc6', ry: ax ? 0 : HP, cs: 1 }); }
        for (const aa of [g.A0, g.A1]) for (const s of [-1, 1]) D(stick(P(aa, g.cc + s * g.hw, g.ey - 0.02), P(aa, g.cc, g.top), 0.1, 0.1, RC, 5));
      }
    };
    // дом-массив: штукатурка с тоном, плоская крыша с карнизом или черепичная
    const bld = (x0, z0, x1, z1, h, tint, o) => {
      o = o || {};
      W(x0, z0, x1, z1, h, tint);
      if (o.roof) roof(x0, z0, x1, z1, h, o.roof, 0.45, { hip: o.hip, along: o.along, gable: wc(tint) });
      else cornice(x0, z0, x1, z1, h, wc(tint, 0.94));
    };
    // балкон с крашеным профлистом (как в старых портовых домах)
    const BALC = ['#3f8a86', '#c25b3a', '#e4d8bc', '#6f8796', '#c79a45', '#8fb8a6'];
    const balcony = (n, c, t, y, w) => {
      const col = BALC[Math.floor(R(0, BALC.length - 0.01))], X = isX(n);
      wbox(n, c, t, y, w + 0.12, 0.16, 1.0, '#cfc8b8');
      const f = at(n, c, t, 0.97); D(box(X ? 0.05 : w, 0.92, X ? w : 0.05, f[0], y + 0.55, f[1], col));
      for (const s of [-1, 1]) { const q = at(n, c, t + s * (w / 2 - 0.03), 0.5); D(box(X ? 0.95 : 0.05, 0.92, X ? 0.05 : 0.95, q[0], y + 0.55, q[1], col)); }
      const r = at(n, c, t, 0.98); D(box(X ? 0.09 : w + 0.08, 0.06, X ? w + 0.08 : 0.09, r[0], y + 1.04, r[1], '#3a3c3e'));
      if (R(0, 1) < 0.55) {
        for (let k = 0; k < 3; k++) { const q = at(n, c, t - w / 2 + 0.4 + k * (w - 0.8) / 2, 1.06); H(box(X ? 0.2 : 0.42, 0.18, X ? 0.42 : 0.2, q[0], y + 1.16, q[1], TERRA), { sph: true, r: 0.2, x: q[0], y: y + 1.34, z: q[1], sy: 0.7, color: k % 2 ? '#4f8a3a' : '#e0302c', seg: 5 }); }
      } else {
        const p0 = at(n, c, t - w / 2 + 0.1, 0.6), p1 = at(n, c, t + w / 2 - 0.1, 0.6);
        H(stick([p0[0], y + 1.9, p0[1]], [p1[0], y + 1.9, p1[1]], 0.012, 0.012, '#dddddd', 3));
        for (let k = 0; k < 3; k++) { const q = at(n, c, t - w / 2 + 0.45 + k * 0.58, 0.6); H(box(X ? 0.03 : 0.42, 0.5 + (k % 2) * 0.15, X ? 0.42 : 0.03, q[0], y + 1.6 - (k % 2) * 0.07, q[1], ['#f4f1ea', '#4a86c8', '#e86a5a', '#f2c94c'][(k + Math.floor(R(0, 3.99))) % 4])); }
      }
    };
    const acUnit = (n, c, t, y) => {
      const X = isX(n); wbox(n, c, t, y, 0.8, 0.55, 0.32, '#dedcd6');
      const p = at(n, c, t + 0.12, 0.33); H(cyl(0.19, 0.02, p[0], y, p[1], '#55595d', X ? 0 : HP, 0, X ? HP : 0, 8));
    };
    // жилой фасад: ряды окон по этажам (часть светится тёплым), балконы, кондиционеры
    const facade = (n, c, t0, t1, nf, o) => {
      o = o || {};
      const fh = o.fh || 3.2, y0 = o.y0 != null ? o.y0 : 3.4, step = o.step || 3.2, cnt = Math.max(1, Math.round((t1 - t0) / step)), sp = (t1 - t0) / cnt;
      for (let f = 0; f < nf; f++) for (let i = 0; i < cnt; i++) {
        const t = t0 + (i + 0.5) * sp, yb = y0 + f * fh, lit = R(0, 1) < (o.lit == null ? 0.2 : o.lit);
        PD(lit ? 1 : 0, n, c, t, yb + 1.45, 1.15, 2.3, lit);
        const r = R(0, 1);
        if (o.balc && r < o.balc && f < nf) balcony(n, c, t, yb + 0.1, 2.0);
        else if (r > 0.78 && o.ac !== false) acUnit(n, c, t + sp * 0.38, yb + 2.0);
      }
      if (o.band) band(n, c, t0 - 0.2, t1 + 0.2, y0 - 0.05, o.band);
    };
    // первый этаж: витрина/дверь/рольставня/афиши/граффити
    const shop = (kind, n, c, t, o) => {
      o = o || {};
      if (kind === 'door') PD(2, n, c, t, 1.5, 1.5, 3.0);
      else if (kind === 'shutter') PD(5, n, c, t, 1.5, 2.6, 3.0);
      else if (kind === 'poster') PD(4, n, c, t, 1.7, 1.4, 2.8);
      else if (kind === 'graffiti') PD(3, n, c, t, 2.1, o.w || 2.4, (o.w || 2.4) * 2);
      else if (kind === 'win') FD(o.cell != null ? o.cell : 0, n, c, t, 1.75, 1.2, 2.4, o.cell === 5);
      else if (kind === 'lit') PD(1, n, c, t, 1.7, 1.3, 2.6, true);
      else if (kind === 'vent') FD(7, n, c, t, o.y || 2.6, 0.9, 1.8);
      else if (kind === 'wanted') FD(6, n, c, t, 1.6, 1.0, 2.0);
    };
    // провод/бельевая верёвка с провисом (толщина — чтобы не пропадала на низком качестве)
    const wire = (p0, p1, sag, r) => {
      const n = 4;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n, f = (t) => [p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag, p0[2] + (p1[2] - p0[2]) * t];
        D(stick(f(t0), f(t1), r || 0.026, r || 0.026, '#2a2a2a', 3));
      }
    };
    const CLOTH = ['#f4f1ea', '#4a86c8', '#e86a5a', '#f2c94c', '#8fc0a0', '#d98ab0', '#ffffff', '#3f5f8a'];
    // бельё на верёвке поперёк проулка
    const laundry = (p0, p1, sag) => {
      wire(p0, p1, sag);
      const len = Math.hypot(p1[0] - p0[0], p1[2] - p0[2]), n = Math.max(2, Math.floor(len / 0.75)), ry = Math.atan2(-(p1[2] - p0[2]), p1[0] - p0[0]);
      for (let i = 0; i < n; i++) {
        if (R(0, 1) < 0.25) continue;
        const t = (i + 0.5) / n, y = p0[1] + (p1[1] - p0[1]) * t - Math.sin(t * Math.PI) * sag, hh = R(0.45, 0.85), ww = R(0.35, 0.6);
        D(box(ww, hh, 0.04, p0[0] + (p1[0] - p0[0]) * t, y - hh / 2 - 0.02, p0[2] + (p1[2] - p0[2]) * t, CLOTH[Math.floor(R(0, 7.99))], 0, ry, 0));
      }
    };
    // дерево-платан в круглой кадке: ствол, крона из листвы
    const tree = (x, z, k) => {
      k = k || 1;
      hid(x - 0.75, z - 0.75, x + 0.75, z + 0.75, 0.5); hid(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 3);
      D(cyl(0.75, 0.45, x, 0.22, z, '#8c8478', 0, 0, 0, 10), cyl(0.68, 0.04, x, 0.45, z, '#4a3a2a', 0, 0, 0, 10));
      D(stick([x, 0.4, z], [x + 0.15, 2.6 * k, z - 0.1], 0.2, 0.15, '#7d7466', 6), stick([x + 0.15, 2.4 * k, z - 0.1], [x + 0.9, 3.6 * k, z + 0.3], 0.12, 0.08, '#7d7466', 5), stick([x + 0.15, 2.4 * k, z - 0.1], [x - 0.8, 3.7 * k, z - 0.4], 0.12, 0.08, '#7d7466', 5));
      L({ sph: true, r: 1.7 * k, x: x + 0.1, y: 4.2 * k, z, sx: 1.2, sy: 0.8, sz: 1.15, ry: R(0, 3), color: '#6f9a46', seg: 8 },
        { sph: true, r: 1.2 * k, x: x + 1.0, y: 3.7 * k, z: z + 0.4, sy: 0.8, color: '#7aa64e', seg: 7 }, { sph: true, r: 1.15 * k, x: x - 0.9, y: 3.8 * k, z: z - 0.4, sy: 0.8, color: '#5f8a3e', seg: 7 });
    };
    // фонарь у стены
    const wallLamp = (n, c, t, y) => {
      const p = at(n, c, t, 0.35), q = at(n, c, t, 0.18);
      D(box(isX(n) ? 0.36 : 0.05, 0.05, isX(n) ? 0.05 : 0.36, q[0], y + 0.3, q[1], IRON), box(0.22, 0.3, 0.22, p[0], y, p[1], '#f7e2a8'),
        { cyl: true, r: 0.03, r2: 0.19, h: 0.16, x: p[0], y: y + 0.23, z: p[1], color: IRON, seg: 4, ry: Math.PI / 4 });
      a.lamps.push([p[0], y, p[1], 0.9]);
    };
    // скамья
    const bench = (x, z, rot) => {
      const X = !rot; hid(x - (X ? 0.9 : 0.3), z - (X ? 0.3 : 0.9), x + (X ? 0.9 : 0.3), z + (X ? 0.3 : 0.9), 0.5);
      D(box(X ? 1.8 : 0.45, 0.07, X ? 0.45 : 1.8, x, 0.45, z, WOOD_L), box(X ? 1.8 : 0.06, 0.4, X ? 0.06 : 1.8, x + (X ? 0 : 0.22), 0.72, z + (X ? 0.22 : 0), WOOD_L));
      for (const s of [-0.75, 0.75]) D(box(X ? 0.08 : 0.42, 0.44, X ? 0.42 : 0.08, x + (X ? s : 0), 0.22, z + (X ? 0 : s), IRON));
    };
    // бочки, поддоны, мешки
    const pallet = (x, z, n, col) => {
      hid(x - 0.6, z - 0.5, x + 0.6, z + 0.5, 0.15 + n * 0.32);
      D(box(1.2, 0.14, 1.0, x, 0.07, z, '#9c7a52'));
      for (let i = 0; i < n; i++) D(box(1.1, 0.3, 0.9, x, 0.3 + i * 0.32, z, col || (i % 2 ? '#c69a62' : '#b98a52')));
      H(box(1.12, 0.04, 0.05, x, 0.3 + (n - 1) * 0.32, z + 0.46, '#e8e0cc'));
    };
    // погрузчик (вдоль x, вилы к -x при dir=-1)
    const forklift = (x, z, dir, rot) => {
      const s = dir || 1, P = (lx, lz) => rot ? [x - lz, z + lx * s] : [x + lx * s, z + lz], ry = rot ? HP : 0;
      if (rot) hid(x - 0.75, z - 1.6, x + 0.75, z + 1.6, 2.2); else hid(x - 1.6, z - 0.75, x + 1.6, z + 0.75, 2.2);
      let p = P(0.3, 0); D(box(1.8, 0.9, 1.2, p[0], 0.75, p[1], YEL, 0, ry, 0)); p = P(0.75, 0); D(box(0.6, 0.6, 1.1, p[0], 1.4, p[1], '#c48f22', 0, ry, 0));
      for (const lz of [-0.55, 0.55]) { p = P(-0.25, lz); D(box(0.08, 1.2, 0.08, p[0], 1.8, p[1], IRON, 0, ry, 0)); p = P(0.75, lz); D(box(0.08, 1.2, 0.08, p[0], 1.8, p[1], IRON, 0, ry, 0)); }
      p = P(0.25, 0); D(box(1.2, 0.08, 1.2, p[0], 2.42, p[1], IRON, 0, ry, 0));
      p = P(-0.65, 0); D(box(0.12, 2.1, 0.9, p[0], 1.1, p[1], '#3a3c3e', 0, ry, 0));
      for (const lz of [-0.3, 0.3]) { p = P(-1.15, lz); D(box(0.9, 0.06, 0.14, p[0], 0.2, p[1], '#3a3c3e', 0, ry, 0)); }
      for (const [lx, lz] of [[-0.25, -0.62], [-0.25, 0.62], [0.95, -0.62], [0.95, 0.62]]) { p = P(lx, lz); D(cyl(0.28, 0.22, p[0], 0.28, p[1], '#1c1c1c', rot ? 0 : HP, 0, rot ? HP : 0, 10)); }
      p = P(0.6, 0); D(box(0.3, 0.06, 0.4, p[0], 1.55, p[1], '#2a2a2a', 0, ry, 0));
    };
    // грузовичок (вдоль x, кабина к +x при dir=1)
    const truck = (x, z, dir, col) => {
      const s = dir || 1;
      hid(x - 3.2, z - 1.15, x + 3.2, z + 1.15, 2.9);
      D(box(4.4, 2.5, 2.2, x - s * 0.95, 1.65, z, col || '#e9e4da'), box(1.7, 1.6, 2.1, x + s * 2.25, 1.2, z, '#c64a32'), box(0.9, 0.9, 2.1, x + s * 2.55, 2.25, z, '#c64a32'),
        box(0.05, 0.7, 1.8, x + s * 3.0, 2.15, z, '#24323e'), box(6.3, 0.3, 2.0, x, 0.45, z, '#2a2a2a'), box(0.1, 0.3, 2.2, x + s * 3.12, 0.75, z, '#cfd3d6'));
      for (const lx of [-2.3, -1.4, 2.0]) for (const lz of [-1.0, 1.0]) D(cyl(0.45, 0.3, x + s * lx, 0.45, z + lz, '#1a1a1a', HP, 0, 0, 12));
      for (const lz of [-0.75, 0.75]) D({ sph: true, r: 0.12, x: x + s * 3.08, y: 0.95, z: z + lz, sx: 0.5, color: '#fff3d0', seg: 6 });
    };
    // машина «Волга» (вдоль x)
    const car = (x, z, col, rot) => {
      const ry = rot ? HP : 0, P = (lx, lz) => rot ? [x - lz, z + lx] : [x + lx, z + lz];
      if (rot) hid(x - 0.95, z - 2.4, x + 0.95, z + 2.4, 1.45); else hid(x - 2.4, z - 0.95, x + 2.4, z + 0.95, 1.45);
      let p;
      D(box(4.7, 0.62, 1.8, x, 0.62, z, col, 0, ry, 0)); p = P(-0.2, 0); D(box(2.5, 0.55, 1.62, p[0], 1.2, p[1], col, 0, ry, 0));
      p = P(-0.2, 0); D(box(2.3, 0.42, 1.66, p[0], 1.2, p[1], '#25313b', 0, ry, 0));
      for (const lx of [-1.5, 1.5]) for (const lz of [-0.82, 0.82]) { p = P(lx, lz); D(cyl(0.33, 0.22, p[0], 0.33, p[1], '#1a1a1a', rot ? 0 : HP, 0, rot ? HP : 0, 10)); }
      for (const lx of [-2.36, 2.36]) { p = P(lx, 0); D(box(0.08, 0.14, 1.8, p[0], 0.5, p[1], '#d9dde0', 0, ry, 0)); }
      for (const lz of [-0.6, 0.6]) { p = P(2.36, lz); D({ sph: true, r: 0.11, x: p[0], y: 0.72, z: p[1], sx: 0.5, color: '#fff6d8', seg: 6 }); }
      D({ cyl: true, r: 1, h: 0.01, x, y: 0.025, z, sx: rot ? 1.0 : 2.5, sz: rot ? 2.5 : 1.0, color: '#3a332c', seg: 10 });
    };
    // стопка контейнеров: k1, k2 — материалы ярусов (null — нет)
    const cont = (x0, z0, x1, z1, k1, k2) => { B(x0, z0, x1, z1, 2.6, k1); if (k2) B(x0, z0, x1, z1, 2.6, k2, 2.6); };
    // швартовая тумба
    const bollard = (x, z) => D(cyl(0.2, 0.55, x, 0.28, z, '#2b2b2b', 0, 0, 0, 8), cyl(0.28, 0.08, x, 0.58, z, '#2b2b2b', 0, 0, 0, 8));
    // стеллаж склада вдоль z: каркас и паллеты с грузом на трёх ярусах
    const rack = (x0, z0, x1, z1) => {
      B(x0, z0, x1, z1, 3.4, 'none', 0, { hidden: true });
      const cx = (x0 + x1) / 2, d = x1 - x0, len = z1 - z0, n = Math.max(1, Math.round(len / 2.6)), bay = len / n;
      for (let i = 0; i <= n; i++) for (const sx of [x0 + 0.05, x1 - 0.05]) D(box(0.08, 3.4, 0.08, sx, 1.7, z0 + i * bay, '#2f5d86'));
      for (const y of [0.15, 1.3, 2.45]) for (const sx of [x0 + 0.05, x1 - 0.05]) D(box(0.1, 0.12, len, sx, y, (z0 + z1) / 2, '#e07a28'));
      for (let i = 0; i < n; i++) for (let lv = 0; lv < 3; lv++) {
        if (R(0, 1) < 0.12) continue;
        const zc = z0 + (i + 0.5) * bay, hh = R(0.7, 0.95), col = ['#c69a62', '#b98a52', '#e8e2d4', '#8fa4ae', '#c25b3a'][Math.floor(R(0, 4.99))];
        D(box(d - 0.25, hh, bay - 0.35, cx, 0.22 + lv * 1.15 + hh / 2, zc, col));
      }
      D(box(d - 0.1, 0.03, len, cx, 3.38, (z0 + z1) / 2, '#6d7175'));
    };
    // висячая лампа склада/кафе
    const pendant = (x, y, z, top) => {
      D({ cyl: true, r: 0.08, r2: 0.36, h: 0.3, x, y, z, color: '#3d4a44', seg: 8 }, cyl(0.012, top - y, x, (top + y) / 2 + 0.15, z, '#1a1a1a', 0, 0, 0, 3));
      a.lamps.push([x, y - 0.18, z, 1.1]);
    };
    // мебель (коллизия — невидимая коробка)
    const sofa = (x, z, rot, col) => {
      const X = !rot; hid(x - (X ? 1.0 : 0.45), z - (X ? 0.45 : 1.0), x + (X ? 1.0 : 0.45), z + (X ? 0.45 : 1.0), 0.85);
      D(box(X ? 2.0 : 0.9, 0.42, X ? 0.9 : 2.0, x, 0.25, z, col), box(X ? 2.0 : 0.22, 0.5, X ? 0.22 : 2.0, x + (X ? 0 : rot * 0.34), 0.62, z + (X ? 0.34 : 0), col));
      for (const s of [-1, 1]) D(box(X ? 0.2 : 0.9, 0.62, X ? 0.9 : 0.2, x + (X ? s * 0.9 : 0), 0.34, z + (X ? 0 : s * 0.9), col));
      H(box(X ? 0.5 : 0.18, 0.4, X ? 0.18 : 0.5, x + (X ? -0.45 : rot * 0.18), 0.65, z + (X ? 0.2 : -0.45), '#f2c94c'));
    };
    const table = (x, z, w, d, col) => {
      hid(x - w / 2, z - d / 2, x + w / 2, z + d / 2, 0.78);
      D(box(w, 0.07, d, x, 0.75, z, col || WOOD_L));
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) D(box(0.07, 0.72, 0.07, x + sx * (w / 2 - 0.08), 0.36, z + sz * (d / 2 - 0.08), WOOD));
    };
    const chair = (x, z, ry, col) => {
      D(box(0.44, 0.05, 0.44, x, 0.46, z, col || WOOD, 0, ry, 0), box(0.44, 0.5, 0.05, x - Math.sin(ry) * 0.2, 0.72, z - Math.cos(ry) * 0.2, col || WOOD, 0, ry, 0));
      H(box(0.05, 0.44, 0.05, x, 0.22, z, '#3a2a1a'));
    };
    // столик кафе с зонтом
    const terrace = (x, z, col) => {
      hid(x - 0.45, z - 0.45, x + 0.45, z + 0.45, 0.78);
      D(cyl(0.45, 0.04, x, 0.76, z, '#f4f1ea', 0, 0, 0, 10), cyl(0.04, 0.74, x, 0.37, z, IRON, 0, 0, 0, 5), cyl(0.22, 0.04, x, 0.02, z, IRON, 0, 0, 0, 8));
      D(cyl(0.03, 2.4, x, 1.2, z, '#e9e3d6', 0, 0, 0, 5), { cyl: true, r: 0.06, r2: 1.35, h: 0.45, x, y: 2.42, z, color: col, seg: 8 });
      for (let i = 0; i < 3; i++) { const an = i * 2.1 + 0.4; chair(x + Math.cos(an) * 0.75, z + Math.sin(an) * 0.75, -an - HP, '#2a2c2e'); }
    };

    // ===================== периметр и набережная =====================
    hid(44, -34, 46, 34, 8);
    B(44, -34, 44.7, 34, 1.4, 'concrete', -1.4, { solid: false });
    floor(34, -34, 44, 4, 'concrete', '#e6dccb'); floor(24, 4, 44, 28, 'concrete', '#e6dccb');
    // кромка причала: брус-отбойник, тумбы, жёлто-чёрная разметка
    D(box(0.3, 0.22, 68, 43.85, 0.11, 0, '#4a3a2c'), box(0.06, 0.012, 68, 43.4, 0.03, 0, YEL));
    for (const z of [-29, -23, -17, -11, -5, 13, 19, 25]) bollard(43.2, z);
    for (let z = -30; z <= 30; z += 7.5) H({ torus: true, r: 0.36, tube: 0.15, x: 44.85, y: -0.55, z, ry: HP, color: '#1b1b1b', seg: 10 });
    for (const z of [-12, 16]) { D({ torus: true, r: 0.3, tube: 0.075, x: 43.7, y: 1.05, z, ry: HP, color: '#e8531f', seg: 12 }, box(0.08, 1.4, 0.08, 43.7, 0.7, z - 0.42, '#ddd'), box(0.08, 1.4, 0.08, 43.7, 0.7, z + 0.42, '#ddd')); hid(43.6, z - 0.5, 43.8, z + 0.5, 1.4); }

    // ===================== юг: рыбный рынок, спавн налётчиков =====================
    // рыночный зал из кирпича за спавном
    B(-12, -40, 12, -32.5, 7.6, 'brick'); roof(-12, -40, 12, -32.5, 7.6, 2.8, 0.5, { along: 'x', gable: '#8a4a36', col: '#f0d8c8' });
    for (const x of [-9, -3, 3, 9]) FD(5, '+z', -32.5, x, 4.9, 1.6, 3.2, true);
    PD(2, '+z', -32.5, 0, 1.5, 1.8, 3.2); FD(6, '+z', -32.5, -6, 1.7, 1.0, 2.0); PD(4, '+z', -32.5, 5.6, 1.7, 1.4, 2.8);
    a.awning(-6, 3.0, -32.5, 5.0, 1.5, '+z', '#2f7f7a'); a.awning(6, 3.0, -32.5, 5.0, 1.5, '+z', '#b0392b');
    // прилавки с рыбой
    for (const x0 of [-8.5, 3.5]) {
      hid(x0, -32.5, x0 + 5, -31.3, 0.95);
      D(box(5, 0.9, 1.2, x0 + 2.5, 0.45, -31.9, '#7a5a3c'), box(5.1, 0.08, 1.3, x0 + 2.5, 0.94, -31.9, '#cfd6d8'));
      for (let i = 0; i < 5; i++) { D(box(0.8, 0.14, 0.6, x0 + 0.55 + i * 0.98, 1.02, -31.85, '#3a6a8a')); for (let k = 0; k < 3; k++) H({ sph: true, r: 0.12, x: x0 + 0.4 + i * 0.98 + k * 0.15, y: 1.12, z: -31.85 + R(-0.15, 0.15), sx: 2.2, sy: 0.5, color: ['#b8c4cc', '#d88a6a', '#9aa8b0'][k], seg: 5 }); }
    }
    // дома южного ряда
    bld(-44, -40, -27, -28, 10.4, PEACH); bld(-27, -40, -12, -28, 8.6, CREAM, { roof: 2.4, along: 'x' });
    bld(12, -40, 23, -28, 9.2, SALMON, { roof: 2.2, along: 'x' }); bld(23, -40, 34, -28, 7.4, OCHRE);
    facade('+z', -28, -43, -27.5, 2, { balc: 0.45, band: '#d9c3a8' }); facade('+z', -28, -26.5, -12.5, 1, { balc: 0.3, band: '#e0d2b8' });
    facade('+z', -28, 12.5, 22.5, 1, { balc: 0.35, band: '#d8b49c' }); facade('+z', -28, 23.5, 33.5, 1, { lit: 0.35 });
    shop('shutter', '+z', -28, -40); shop('door', '+z', -28, -36.5); shop('poster', '+z', -28, -33); shop('graffiti', '+z', -28, -30, { w: 2.2 });
    shop('door', '+z', -28, -22.5); shop('win', '+z', -28, -19, { cell: 3 }); shop('shutter', '+z', -28, -15);
    shop('shutter', '+z', -28, 15); shop('door', '+z', -28, 19); shop('poster', '+z', -28, 21.6); shop('win', '+z', -28, 26, { cell: 0 }); shop('door', '+z', -28, 29.5); shop('graffiti', '+z', -28, 32);
    a.awning(15, 3.0, -28, 3.2, 1.3, '+z', '#2f7f7a');
    // спавн налётчиков: ящики с рыбой, мотороллер, бочки
    stack(-10.6, -30.6, 1.1); crate(10.7, -23.4, 1.0); crate(-10.6, -23.5, 0.9); crate(9.8, -31.6, 0.9);
    a.barrel(11.2, -31.2, '#2f5f8a'); a.barrel(11.2, -30.3, '#8a2d22');
    a.lamp(-11.3, -27.2, 5.6, HP); a.lamp(11.3, -27.2, 5.6, -HP);
    // южный конец набережной: стенка из контейнеров
    cont(34, -34, 40, -31.5, 'contRed', 'hbTeal'); cont(40, -34, 44, -31.5, 'contOrange');

    // ===================== улица к апартаментам (запад) =====================
    // квартал между апартаментами и средней улицей
    bld(-18, -22, -6, -8, 10.2, SAND, { roof: 2.4, along: 'z' }); bld(-18, -8, -12, -4, 10.2, SAND);
    facade('-z', -22, -17.5, -6.5, 2, { balc: 0.5, band: '#dcc8a4' }); facade('+x', -6, -21.5, -8.5, 2, { balc: 0.3, band: '#dcc8a4' });
    shop('shutter', '-z', -22, -15); shop('door', '-z', -22, -10.5); shop('poster', '-z', -22, -8);
    shop('win', '+x', -6, -19.5, { cell: 3 }); shop('door', '+x', -6, -16.5); shop('graffiti', '+x', -6, -13.5); shop('shutter', '+x', -6, -10.5);
    a.awning(-6, 3.0, -16.5, 2.6, 1.2, '+x', '#b0392b');
    car(-20.5, -26.6, '#7aa0b8'); bench(-14.5, -27.4); a.lamp(-24, -27.5, 5.6, 0);
    D(box(1.8, 1.3, 1.2, -33.5, 0.65, -27.3, '#3f6a4a'), box(1.9, 0.1, 1.3, -33.5, 1.33, -27.3, '#2f5236')); hid(-34.4, -27.9, -32.6, -26.7, 1.35); // мусорный бак

    // ===================== жилой дом с подъездом (апартаменты) =====================
    const AW = '#e6b49a', AU = PEACH;
    // первый этаж: наружные стены 0.4, проёмы: подъезд (юг), выход во двор (север)
    W(-38, -22, -29.5, -21.6, 3.4, AW); W(-27.5, -22, -18, -21.6, 3.4, AW);
    W(-38, -6.4, -29.5, -6, 3.4, AW); W(-27.5, -6.4, -18, -6, 3.4, AW);
    W(-38, -21.6, -37.6, -6.4, 3.4, AW); W(-18.4, -21.6, -18, -6.4, 3.4, AW);
    W(-29.5, -22, -27.5, -21.6, 0.8, AW, 2.6); W(-29.5, -6.4, -27.5, -6, 0.8, AW, 2.6);
    // глухие подсобки по бокам вестибюля
    W(-37.6, -21.6, -32, -15.8, 3.4, '#efe2cc'); W(-24.4, -21.6, -18.4, -15.8, 3.4, '#efe2cc');
    // перегородки: вестибюль | коридор | две квартиры
    W(-32, -16.2, -30, -15.8, 3.4, '#efe2cc'); W(-27, -16.2, -24.4, -15.8, 3.4, '#efe2cc');
    W(-30.4, -15.8, -30, -12.3, 3.4, '#efe2cc'); W(-30.4, -10.7, -30, -6.4, 3.4, '#efe2cc'); W(-30.4, -12.3, -30, -10.7, 0.8, '#efe2cc', 2.6);
    W(-27, -15.8, -26.6, -9.3, 3.4, '#efe2cc'); W(-27, -7.7, -26.6, -6.4, 3.4, '#efe2cc'); W(-27, -9.3, -26.6, -7.7, 0.8, '#efe2cc', 2.6);
    // этажи над первым — один массив; плита пола между этажами снаружи — пояс
    W(-38, -22, -18, -6, 10.4, AU, 3.4); cornice(-38, -22, -18, -6, 13.8, wc(AU, 0.93));
    band('-z', -22, -38.2, -17.8, 3.4, '#d8c6ac'); band('+z', -6, -38.2, -17.8, 3.4, '#d8c6ac'); band('-x', -38, -22.2, -5.8, 3.4, '#d8c6ac');
    facade('-z', -22, -37.5, -18.5, 3, { balc: 0.55 }); facade('+z', -6, -37.5, -18.5, 3, { balc: 0.55 }); facade('-x', -38, -21.5, -6.5, 3, { balc: 0.4 });
    // полы внутри
    floor(-30, -21.6, -24.4, -16.2, 'pave', '#f2ece0'); floor(-30, -16.2, -27, -6.4, 'pave', '#f2ece0');
    floor(-37.6, -15.8, -30.4, -6.4, 'planks', '#f0d6b8'); floor(-26.6, -15.8, -18.4, -6.4, 'planks', '#f6dcc0');
    floor(-29.5, -22, -27.5, -21.6, 'pave', '#f2ece0'); floor(-29.5, -6.4, -27.5, -6, 'pave', '#f2ece0');
    // подъезд снаружи: козырёк, дверь-створка, табличка
    D(box(3.2, 0.14, 1.4, -28.5, 3.0, -22.7, '#cfc8b8'), box(0.08, 3.0, 0.08, -30, 1.5, -23.3, IRON), box(0.08, 3.0, 0.08, -27, 1.5, -23.3, IRON));
    D(box(0.06, 2.4, 0.95, -29.4, 1.2, -22.1, '#5a3a22', 0, 0.9, 0)); H(box(0.4, 0.28, 0.03, -26.9, 2.0, -22.03, '#2a5ea8'));
    PD(7, '-z', -22, -25.6, 2.2, 1.2, 2.4); shop('graffiti', '-z', -22, -34.5, { w: 2.0 }); shop('poster', '-z', -22, -20.2);
    // вестибюль: лестница наверх (декор), почтовые ящики, лампа, батарея, фикус
    hid(-32, -21.6, -30.5, -16.2, 3.4);
    for (let i = 0; i < 9; i++) D(box(1.4, 0.36 * (i + 1), 0.52, -31.3, 0.18 * (i + 1), -21.3 + i * 0.52, i % 2 ? '#a8998a' : '#b4a593'), box(1.42, 0.05, 0.08, -31.3, 0.36 * (i + 1) - 0.02, -21.56 + i * 0.52, '#5a4636'));
    D(stick([-30.58, 0.1, -21.56], [-30.58, 3.3, -16.9], 0.12, 0.12, '#5a4636', 4));
    for (let i = 0; i < 4; i++) D(box(0.05, 1.0, 0.05, -30.55, 0.36 * (i * 2 + 1) + 0.5, -21.3 + i * 1.04, IRON));
    D(stick([-30.55, 1.36, -21.3], [-30.55, 4.24, -17.14], 0.03, 0.03, '#5a3a22', 4));
    D(box(0.2, 0.9, 1.6, -24.5, 1.5, -19.2, '#6f7a80')); for (let r = 0; r < 3; r++) for (let k = 0; k < 4; k++) H(box(0.03, 0.22, 0.32, -24.39, 1.2 + r * 0.28, -19.8 + k * 0.4, '#8c979d'));
    D(box(0.12, 0.6, 1.0, -24.45, 0.5, -17.2, '#e6e2d8')); PD(4, '-x', -24.435, -17.4, 1.9, 0.9, 1.8);
    D(cyl(0.22, 0.4, -25.0, 0.2, -21.1, TERRA, 0, 0, 0, 8)); L({ sph: true, r: 0.42, x: -25.0, y: 0.9, z: -21.1, sy: 1.3, color: '#4f8a3a', seg: 6 }); hid(-25.3, -21.4, -24.7, -20.8, 1.2);
    pendant(-27.2, 2.9, -19, 3.4); pendant(-28.5, 2.9, -11, 3.4);
    // коридор: двери квартир (открытые створки), выключатели, коврик
    D(box(0.85, 2.2, 0.05, -30.85, 1.1, -12.25, '#7a5434'), box(0.85, 2.2, 0.05, -26.15, 1.1, -9.25, '#7a5434'));
    D(box(1.6, 0.012, 2.2, -28.5, 0.03, -20, '#8a3a2c'));
    // западная квартира: гостиная + кухня
    sofa(-36.9, -13.4, -1, '#4a6a8a'); table(-34.9, -13.4, 0.8, 1.1, '#7a5434');
    D(box(1.9, 0.012, 2.8, -35.3, 0.03, -13.4, '#b8563e'), box(1.6, 0.014, 2.4, -35.3, 0.031, -13.4, '#d8a070'));
    hid(-33.4, -15.8, -31.0, -15.3, 1.9); D(box(2.4, 1.9, 0.45, -32.2, 0.95, -15.55, '#5a3a22')); for (let k = 0; k < 3; k++) for (let i = 0; i < 8; i++) H(box(0.07, R(0.3, 0.42), 0.28, -33.2 + i * 0.28, 0.45 + k * 0.6, -15.5, ['#8a2a2a', '#2a4a6a', '#3a5a32', '#c8a050'][(i + k) % 4]));
    hid(-31.0, -14.6, -30.4, -13.2, 1.1); D(box(0.5, 0.5, 1.3, -30.7, 0.25, -13.9, '#3a2a1a'), box(0.08, 0.6, 1.1, -30.75, 0.85, -13.9, '#111418'));
    hid(-37.6, -7.0, -33.6, -6.4, 0.95); D(box(4.0, 0.9, 0.6, -35.6, 0.45, -6.7, '#d8d4ca'), box(4.0, 0.05, 0.62, -35.6, 0.92, -6.7, '#8a6a4a'), box(2.6, 0.7, 0.35, -36.3, 2.1, -6.6, '#d8d4ca'));
    hid(-33.5, -7.1, -32.8, -6.4, 1.8); D(box(0.7, 1.8, 0.7, -33.15, 0.9, -6.75, '#eeeeea'));
    table(-33.6, -9.2, 1.1, 0.8, '#c8a878'); chair(-33.6, -8.6, Math.PI); chair(-34.4, -9.2, -HP); chair(-32.8, -9.2, HP);
    for (const z of [-13.5, -9]) { PD(0, '+x', -37.565, z, 1.7, 1.1, 2.2); PD(0, '-x', -38, z, 1.7, 1.1, 2.2); }
    pendant(-34.8, 2.8, -12.5, 3.4); D(box(1.1, 0.75, 0.04, -32.0, 1.7, -6.43, '#c8b88a')); H(box(0.9, 0.55, 0.02, -32.0, 1.7, -6.45, '#6a8aa8'));
    // восточная квартира: спальня + столовая
    hid(-20.8, -15.4, -18.4, -12.8, 0.6); D(box(2.3, 0.45, 2.5, -19.6, 0.3, -14.1, '#e8e0d0'), box(0.1, 1.0, 2.5, -18.5, 0.6, -14.1, '#6a4a2e'), box(2.0, 0.08, 2.3, -19.7, 0.56, -14.1, '#c25b6a'));
    H(box(0.5, 0.15, 0.7, -18.9, 0.62, -14.6, '#f4f1ea'), box(0.5, 0.15, 0.7, -18.9, 0.62, -13.6, '#f4f1ea'));
    hid(-24.6, -15.8, -22.0, -15.2, 2.1); D(box(2.6, 2.1, 0.6, -23.3, 1.05, -15.5, '#8a6a46'), box(0.02, 1.9, 0.02, -23.3, 1.05, -15.19, '#3a2a1a'));
    table(-22.5, -9.6, 1.4, 0.9, '#9c7350'); chair(-22.5, -8.9, Math.PI, '#c25b3a'); chair(-22.5, -10.3, 0, '#c25b3a'); chair(-23.4, -9.6, -HP, '#c25b3a');
    hid(-19.2, -9.0, -18.4, -7.2, 0.9); D(box(0.8, 0.9, 1.8, -18.8, 0.45, -8.1, '#d8d4ca'), box(0.82, 0.05, 1.82, -18.8, 0.92, -8.1, '#5a5a5a'));
    hid(-26.6, -14.6, -25.9, -13.0, 1.1); D(box(0.6, 1.1, 1.6, -26.25, 0.55, -13.8, '#6a7a5a'));
    D(box(2.4, 0.012, 1.8, -22.5, 0.03, -12.6, '#2f6f8a'));
    for (const x of [-24.5, -20.5]) { PD(0, '-z', -6.435, x, 1.7, 1.1, 2.2); }
    pendant(-22.5, 2.8, -9.6, 3.4); pendant(-20.5, 2.8, -13.5, 3.4);
    H(box(0.9, 0.6, 0.03, -20.5, 1.8, -15.74, '#d8b878'));
    for (const [x, l] of [[-35.5, 1], [-32.2, 0], [-24.5, 1], [-20.5, 0]]) PD(l ? 1 : 0, '+z', -6, x, 1.7, 1.1, 2.2, !!l);
    // отделка: обои/краска тонкими панелями штукатурки (тот же меш), плинтус и поручень-раскладка
    const skin = (n, c, t0, t1, y0, y1, tint) => {
      const s = NN[n][0] + NN[n][1], a0 = t0 + 0.02, a1 = t1 - 0.02, c0 = s > 0 ? c : c - 0.03, c1 = s > 0 ? c + 0.03 : c;
      if (isX(n)) B(c0, a0, c1, a1, y1 - y0, 'plaster', y0, { solid: false, tint }); else B(a0, c0, a1, c1, y1 - y0, 'plaster', y0, { solid: false, tint });
    };
    const trim = (n, c, t0, t1, y, hh, col) => wbox(n, c + (NN[n][0] + NN[n][1]) * 0.03, (t0 + t1) / 2, y, t1 - t0, hh, 0.04, col);
    // подъезд и коридор: классика — низ стен крашеный бирюзовым, сверху побелка, деревянная раскладка
    const ENT = [['+z', -21.6, -30.5, -29.5], ['+z', -21.6, -27.5, -24.4], ['-x', -24.4, -21.6, -16.2], ['-z', -16.2, -27, -24.4],
      ['+x', -30, -15.8, -12.3], ['+x', -30, -10.7, -6.4], ['-x', -27, -15.8, -9.3], ['-x', -27, -7.7, -6.4]];
    for (const [n, c, t0, t1] of ENT) { skin(n, c, t0, t1, 0, 1.25, '#5f9d93'); trim(n, c, t0, t1, 1.27, 0.06, '#4a3424'); }
    // западная квартира — тёплые охристые обои, восточная — мятные; тёмный деревянный плинтус
    const FL1 = [['+x', -37.6, -15.8, -6.4], ['-x', -30.4, -15.8, -12.3], ['-x', -30.4, -10.7, -6.4], ['+z', -15.8, -37.6, -30.4], ['-z', -6.4, -37.6, -30.4]];
    const FL2 = [['+x', -26.6, -15.8, -9.3], ['+x', -26.6, -7.7, -6.4], ['-x', -18.4, -15.8, -6.4], ['+z', -15.8, -26.6, -18.4], ['-z', -6.4, -26.6, -18.4]];
    for (const [L2, tint] of [[FL1, '#f0c890'], [FL2, '#b8d8c8']]) for (const [n, c, t0, t1] of L2) { skin(n, c, t0, t1, 0, 3.4, tint); trim(n, c, t0, t1, 0.07, 0.14, '#4a3424'); trim(n, c, t0, t1, 3.32, 0.12, '#f4eee2'); }
    // светлый потолок по всему первому этажу (нижняя грань тонкой панели)
    B(-37.6, -21.6, -18.4, -6.4, 0.02, 'plaster', 3.36, { solid: false, tint: '#fff4e2' });
    // картины, часы, ковёр у двери, цветы на подоконнике
    D(box(0.05, 0.8, 1.1, -37.53, 1.75, -11.2, '#6a4a2e'), box(0.05, 0.62, 0.92, -37.5, 1.75, -11.2, '#d98a4a'));
    H(box(0.05, 0.3, 0.5, -37.49, 1.8, -11.35, '#3f7f9a'), box(0.05, 0.22, 0.3, -37.49, 1.62, -10.95, '#f2d06a'));
    D(box(0.9, 0.62, 0.05, -22.6, 1.8, -15.73, '#6a4a2e'), box(0.74, 0.48, 0.05, -22.6, 1.8, -15.7, '#7aa8c8'));
    D(cyl(0.22, 0.05, -18.47, 2.3, -10.8, '#f4f1ea', 0, 0, HP, 12)); H(box(0.02, 0.16, 0.02, -18.5, 2.36, -10.8, '#1d1d1d'), box(0.02, 0.02, 0.12, -18.5, 2.3, -10.75, '#1d1d1d'));
    D(box(1.4, 0.012, 3.0, -22.4, 0.032, -9.6, '#a8443a'), box(1.1, 0.014, 2.6, -22.4, 0.034, -9.6, '#e8c890'));

    // ===================== западный проулок с бельём =====================
    bld(-50, -34, -41.5, -18, 11.6, SALMON); bld(-50, -18, -41.5, -6, 13.2, CREAM); bld(-50, -6, -41.5, 2, 9.2, OCHRE, { roof: 2, along: 'z' });
    facade('+x', -41.5, -27.5, -18.5, 2, { balc: 0.25, band: '#d9b49c' }); facade('+x', -41.5, -17.5, -6.5, 3, { balc: 0.25 }); facade('+x', -41.5, -5.5, 1.5, 1, { lit: 0.4 });
    shop('graffiti', '+x', -41.5, -24.5, { w: 2.6 }); shop('door', '+x', -41.5, -20.5); shop('poster', '+x', -41.5, -14); shop('graffiti', '-x', -38, -17.5, { w: 2.2 }); shop('vent', '-x', -38, -11.5);
    shop('door', '+x', -41.5, -9.5); shop('wanted', '+x', -41.5, -3.5);
    for (const [z, y] of [[-25.5, 5.2], [-21.5, 8.4], [-17.5, 5.6], [-13.5, 8.8], [-9.5, 5.0]]) laundry([-41.5, y, z - 0.3], [-38, y + 0.3, z + 0.4], 0.45);
    wire([-41.5, 10.2, -27], [-38, 10.4, -8], 0.6);
    hid(-41.5, -16.2, -40.4, -14.2, 1.3); D(box(1.0, 1.2, 1.9, -40.95, 0.6, -15.2, '#3f6a4a'), box(1.1, 0.1, 2.0, -40.95, 1.25, -15.2, '#2f5236'));
    stack(-40.8, -9.6, 1.0); crate(-38.7, -26.2, 0.9);
    for (let i = 0; i < 4; i++) D({ sph: true, r: 0.32, x: -41.0 + R(-0.1, 0.2), y: 0.24, z: -12.8 + i * 0.45, sy: 0.75, color: i % 2 ? '#1d1f22' : '#2b2e33', seg: 6 });
    D(cyl(0.07, 11.6, -41.35, 5.8, -18.3, '#6d7175', 0, 0, 0, 6), cyl(0.07, 13.8, -38.15, 6.9, -21.6, '#6d7175', 0, 0, 0, 6));

    // ===================== двор B и подворотня с площади =====================
    floor(-41.5, -6, -18, 2, 'concrete', '#d6cec2');
    // подворотня: проход под домом (z −4…0), арка на обоих концах
    W(-18, 0, -12, 8, 11, ROSE); W(-18, -4, -12, 0, 6.6, SAND, 3.6); cornice(-18, -4, -12, 0, 10.2, wc(SAND, 0.94)); cornice(-18, 0, -12, 8, 11, wc(ROSE, 0.94));
    for (const x of [-18.05, -11.95]) for (const sg of [-1, 1]) D({ shape: true, pts: [[sg * 2, 3.6], [0, 3.6], ['c', sg * 1.1, 3.6, sg * 2, 2.7, sg * 2, 1.6]], d: 0.12, x, y: 0, z: -2, color: wc(SAND, 0.98), ry: 0, cs: 5 });
    floor(-18, -4, -12, 0, 'pave', '#e8dcc8'); pendant(-15, 3.2, -2, 3.6);
    PD(3, '+z', -4, -15, 2.0, 2.2, 4.4); PD(4, '-z', 0, -16.4, 1.7, 1.4, 2.8); PD(7, '-x', -18, -5.2 + 0.0, 2.0, 1.4, 2.8);
    facade('+x', -12, 0.5, 7.5, 2, { balc: 0.3 }); facade('+x', -12, -7.5, -4.5, 2, {});
    shop('poster', '+x', -12, -6); shop('lit', '+x', -12, 6.2); PD(7, '+x', -12, 0.8 + 0.0, 2.2, 1.0, 2.0);
    // грузовик у склада, поддоны, бочки
    truck(-23.2, -0.4, 1, '#d8d2c4'); pallet(-36.4, -4.6, 2); pallet(-35.0, -4.8, 1, '#8fa4ae'); stack(-38.8, 0.6, 1.1);
    a.barrel(-40.8, 1.1, '#2f5f8a'); a.barrel(-40.6, 0.2, '#8a2d22'); a.barrel(-19.0, -5.3, '#3b5f3a');
    a.lamp(-33.5, -5.5, 5.4, 0);

    // ===================== склад №3 — точка B =====================
    const WH = 8;
    B(-42, 2, -33, 2.5, WH, 'brick'); B(-28, 2, -18, 2.5, WH, 'brick'); B(-33, 2, -28, 2.5, WH - 3.6, 'brick', 3.6);
    B(-42, 21.5, -25.5, 22, WH, 'brick'); B(-21.5, 21.5, -18, 22, WH, 'brick'); B(-25.5, 21.5, -21.5, 22, WH - 3.6, 'brick', 3.6);
    B(-42, 2.5, -41.5, 21.5, WH, 'brick'); B(-18.5, 2.5, -18, 21.5, WH, 'brick');
    roof(-42, 2, -18, 22, WH, 3.2, 0.45, { along: 'x', gable: '#7a3f2e', col: '#d8b8a8' });
    floor(-41.5, 2.5, -18.5, 21.5, 'concrete', '#cfc8bc');
    // поднятые рольставни над проёмами
    D(box(5.2, 0.5, 0.5, -30.5, 3.4, 2.25, '#8a9094'), box(4.2, 0.5, 0.5, -23.5, 3.4, 21.75, '#8a9094'));
    for (const [x, z] of [[-33.1, 2.25], [-27.9, 2.25]]) D(box(0.14, 3.6, 0.6, x, 1.8, z, YEL));
    for (const [x, z] of [[-25.6, 21.75], [-21.4, 21.75]]) D(box(0.14, 3.6, 0.6, x, 1.8, z, YEL));
    // фермы под крышей
    for (const x of [-37, -30, -23]) { D(box(0.25, 0.35, 19.5, x, WH - 0.2, 12, '#4a3a2e')); for (const s of [-1, 1]) D(stick([x, WH - 0.1, 12 + s * 9.7], [x, WH + 2.9, 12], 0.12, 0.12, '#4a3a2e', 4)); D(box(0.2, 3.0, 0.2, x, WH + 1.4, 12, '#4a3a2e')); }
    for (const x of [-37, -30, -23]) for (const z of [7, 17]) pendant(x, 5.6, z, WH);
    // окна под крышей и надписи
    for (const x of [-39.5, -36, -25, -21]) { FD(5, '-z', 2, x, 5.6, 1.4, 2.8, true); FD(5, '+z', 22, x, 5.6, 1.4, 2.8, true); }
    for (const z of [6, 12, 18]) FD(5, '-x', -42, z, 5.6, 1.4, 2.8, true);
    PD(7, '-z', 2, -35.5, 2.2, 1.6, 3.2); PD(7, '+z', 22, -28, 2.2, 1.6, 3.2); PD(7, '+z', 2.5, -38, 2.4, 2.2, 4.4); PD(7, '-z', 21.5, -32, 2.4, 2.2, 4.4); PD(7, '-x', -18.5, 12, 2.4, 2.2, 4.4);
    PD(3, '-z', 2, -24.2, 2.1, 2.4, 4.8); shop('poster', '-z', 2, -38.5);
    // внутри: стеллажи, штабеля, погрузчик, контора мастера
    rack(-41.5, 4.5, -40.3, 16.5); rack(-36.4, 8.5, -35.2, 16.5); rack(-27.0, 12.0, -25.8, 18.6);
    stack(-31.2, 7.4, 1.3); stack(-30.4, 16.2, 1.2); crate(-29.1, 16.6, 1.0); crate(-22.2, 5.4, 1.2); crate(-21.0, 6.2, 0.9);
    pallet(-33.6, 12.6, 3); pallet(-33.6, 13.8, 2, '#8fa4ae'); pallet(-21.2, 18.2, 3, '#c25b3a'); pallet(-37.8, 4.4, 2);
    forklift(-23.0, 11.5, 1, true);
    cont(-31.5, 19.0, -25.5, 21.5, 'hbTeal');
    W(-41.5, 18, -37.5, 21.5, 2.8, '#e8ddc8'); D(box(4.2, 0.12, 3.7, -39.5, 2.86, 19.75, '#6f665c'));
    PD(1, '+x', -37.5, 19.75, 1.5, 1.6, 2.0, true); PD(2, '-z', 18, -38.6, 1.3, 1.1, 2.4);
    D(box(0.15, 0.012, 15, -38.0, 0.03, 12, YEL), box(0.15, 0.012, 15, -28.0, 0.03, 12, YEL), box(9.8, 0.012, 0.15, -33, 0.03, 4.5, YEL), box(9.8, 0.012, 0.15, -33, 0.03, 19.5, YEL));
    a.letter('B', -30.4, 11.6, 4.2);
    hid(-44, 2, -42, 22, 8);

    // ===================== площадь (середина) =====================
    floor(-12, -8, 12, 8, 'pave', '#f3e4cc');
    for (let i = 0; i < 16; i++) { const an = i / 16 * Math.PI * 2; D(box(0.5, 0.012, 1.3, Math.cos(an) * 3.6, 0.031, Math.sin(an) * 3.6, '#c9b090', 0, -an, 0)); }
    // памятник «Морякам»: пьедестал с якорем — закрывает прострел середины
    B(-1.6, -1.6, 1.6, 1.6, 0.6, 'concrete'); B(-1, -1, 1, 1, 2.4, 'concrete', 0.6);
    D(box(2.3, 0.2, 2.3, 0, 3.1, 0, '#b3ada2'), cyl(0.14, 2.6, 0, 4.5, 0, BRONZE, 0, 0, 0, 8), box(1.4, 0.18, 0.18, 0, 5.4, 0, BRONZE),
      { torus: true, r: 0.24, tube: 0.07, x: 0, y: 5.95, z: 0, color: BRONZE, seg: 10 });
    { const ap = []; for (let i = 0; i <= 6; i++) { const th = Math.PI + i / 6 * Math.PI; ap.push([Math.cos(th) * 0.8, 4.0 + Math.sin(th) * 0.75]); } for (let i = 0; i < 6; i++) D(stick([ap[i][0], ap[i][1], 0], [ap[i + 1][0], ap[i + 1][1], 0], 0.11, 0.11, BRONZE, 6)); }
    for (const s of [-1, 1]) D({ cyl: true, r: 0.02, r2: 0.2, h: 0.4, x: s * 0.78, y: 4.05, z: 0, rz: s * 0.6, color: BRONZE, seg: 6 });
    H(box(1.2, 0.5, 0.04, 0, 1.6, -1.03, '#c9a24a'), box(1.2, 0.5, 0.04, 0, 1.6, 1.03, '#c9a24a'));
    // киоск
    hid(3.4, 1.6, 5.6, 3.6, 2.8);
    D(box(2.2, 2.3, 2.0, 4.5, 1.15, 2.6, '#3f7a5a'), box(2.6, 0.2, 2.4, 4.5, 2.45, 2.6, '#2c5a42'), box(1.6, 0.9, 0.04, 4.5, 1.4, 1.58, '#f1e6c8'), box(2.6, 0.4, 0.06, 4.5, 2.25, 1.4, '#c64a32'));
    for (let i = 0; i < 6; i++) H(box(0.22, 0.3, 0.02, 3.9 + (i % 3) * 0.4, 1.25 + Math.floor(i / 3) * 0.36, 1.55, ['#e86a5a', '#4a86c8', '#f2c94c'][i % 3]));
    // фруктовый лоток с навесом
    hid(-11.6, 1.2, -9.8, 5.2, 1.0);
    D(box(1.8, 0.9, 4.0, -10.7, 0.45, 3.2, '#7a5a3c'), cyl(0.05, 2.4, -9.8, 1.2, 1.2, WOOD, 0, 0, 0, 5), cyl(0.05, 2.4, -9.8, 1.2, 5.2, WOOD, 0, 0, 0, 5));
    a.awning(-12, 2.6, 3.2, 4.4, 1.9, '+x', '#2f7f7a');
    for (let i = 0; i < 6; i++) { D(box(0.7, 0.2, 0.55, -10.5, 1.0, 1.6 + i * 0.66, '#9c7a52')); for (let k = 0; k < 4; k++) H({ sph: true, r: 0.11, x: -10.5 + R(-0.25, 0.25), y: 1.17, z: 1.6 + i * 0.66 + R(-0.18, 0.18), color: ['#e8452a', '#f2a03a', '#7aa04a', '#f2d23a', '#c8321e', '#e9e3d0'][i], seg: 5 }); }
    // терраса кафе
    terrace(9.6, 5.4, '#f6efe2'); terrace(9.4, 2.3 + 1.2, '#c25b3a');
    a.awning(12, 3.1, 4.6, 6.2, 1.8, '-x', '#b0392b');
    tree(-9.2, -5.4, 1.05); tree(9.0, -5.6, 1.0); tree(-3.6, 6.5, 0.95);
    bench(-5.6, -6.9); bench(5.6, -6.9); bench(-9.4, 7.3);
    car(-7.2, 2.2, '#e6e0d0', 1);
    a.lamp(-11.3, -6.6, 5.6, HP); a.lamp(11.3, -6.8, 5.6, -HP);
    // гирлянда над площадью
    for (const [p0, p1] of [[[-12, 5.8, -6], [12, 5.8, 6]], [[-12, 5.8, 6], [12, 5.8, -6]]]) {
      wire(p0, p1, 0.9, 0.022);
      for (let i = 1; i < 12; i++) { const t = i / 12, s = Math.sin(t * Math.PI) * 0.9; H({ sph: true, r: 0.08, x: p0[0] + (p1[0] - p0[0]) * t, y: p0[1] - s - 0.1, z: p0[2] + (p1[2] - p0[2]) * t, color: '#fff3c8', seg: 4 }); }
    }

    // ===================== кварталы вокруг площади =====================
    // юго-восток площади: гостиница «Чайка» (к средней улице)
    bld(-1, -22, 12, -8, 9.4, MINT, { roof: 2.4, along: 'x' });
    facade('-x', -1, -21.5, -8.5, 2, { balc: 0.35, band: '#c6d4bc' }); facade('-z', -22, -0.5, 11.5, 2, { balc: 0.3, band: '#c6d4bc' }); facade('+z', -8, -0.5, 11.5, 2, { balc: 0.45, band: '#c6d4bc' });
    shop('door', '-x', -1, -11); shop('poster', '-x', -1, -14); shop('shutter', '-x', -1, -18.5); shop('win', '-z', -22, 3, { cell: 0 }); shop('door', '-z', -22, 7); shop('graffiti', '-z', -22, 10.2, { w: 2.0 });
    shop('lit', '+z', -8, 2); shop('door', '+z', -8, 5); shop('lit', '+z', -8, 8); a.awning(5, 3.0, -8, 7.2, 1.4, '+z', '#2f7f7a');
    // северо-запад площади: дом с баром
    bld(-18, 8, 1, 22, 11.2, ROSE, { roof: 2.6, along: 'x' });
    facade('-z', 8, -11.5, 0.5, 2, { balc: 0.5, band: '#d9a898' }); facade('+x', 1, 8.5, 21.5, 2, { balc: 0.4, band: '#d9a898' }); facade('+z', 22, -17.5, 0.5, 2, { balc: 0.45, band: '#d9a898' });
    shop('lit', '-z', 8, -9); shop('door', '-z', 8, -6.5); shop('lit', '-z', 8, -4); shop('poster', '-z', 8, -1.2);
    a.awning(-6.5, 3.0, 8, 7.0, 1.4, '-z', '#b0392b');
    shop('shutter', '+x', 1, 11); shop('graffiti', '+x', 1, 15); shop('door', '+x', 1, 19.5);
    shop('door', '+z', 22, -15); shop('win', '+z', 22, -8, { cell: 3 }); shop('win', '+z', 22, -3, { cell: 3 });
    // северо-восток: морвокзал (голубой, с часами)
    bld(6, 8, 12, 10, 12.2, SKY); bld(6, 10, 24, 22, 12.2, SKY, { roof: 3.0, hip: true });
    facade('-x', 6, 8.5, 21.5, 2, { balc: 0.3, band: '#e8eef0', fh: 3.6, lit: 0.3 }); facade('-z', 8, 6.5, 11.5, 2, { band: '#e8eef0', fh: 3.6 });
    facade('+z', 22, 6.5, 23.5, 2, { band: '#e8eef0', fh: 3.6, lit: 0.3 }); facade('+x', 24, 10.5, 21.5, 2, { band: '#e8eef0', fh: 3.6, lit: 0.3 });
    shop('door', '-x', 6, 15); shop('win', '-x', 6, 11.5, { cell: 1 }); shop('win', '-x', 6, 18.5, { cell: 1 });
    shop('door', '+z', 22, 15); shop('win', '+z', 22, 10.5, { cell: 1 }); shop('win', '+z', 22, 19.5, { cell: 1 }); shop('poster', '+x', 24, 12.5); PD(6, '+x', 24, 17.5, 2.4, 2.0, 4.0);
    D(box(2.4, 2.4, 2.4, 15, 16.4, 16, '#e8eef0'), { cyl: true, r: 0.05, r2: 1.9, h: 1.8, x: 15, y: 18.5, z: 16, color: '#4a7a8a', seg: 4, ry: Math.PI / 4 });
    for (const [n, c, t] of [['-x', 13.8, 16], ['+x', 16.2, 16], ['+z', 17.2, 15], ['-z', 14.8, 15]]) { const p = at(n, c, t, 0.02); D({ cyl: true, r: 0.8, h: 0.06, x: p[0], y: 16.5, z: p[1], color: '#f4f1ea', seg: 14, rx: isX(n) ? 0 : HP, rz: isX(n) ? HP : 0 }); H(box(isX(n) ? 0.03 : 0.06, 0.6, isX(n) ? 0.06 : 0.03, p[0] + NN[n][0] * 0.04, 16.7, p[1] + NN[n][1] * 0.04, '#1d1d1d'), box(isX(n) ? 0.03 : 0.4, 0.06, isX(n) ? 0.4 : 0.03, p[0] + NN[n][0] * 0.04 + (isX(n) ? 0 : 0.18), 16.5, p[1] + NN[n][1] * 0.04 + (isX(n) ? 0.18 : 0), '#1d1d1d')); }
    // средняя улица к спецназу: ворота «мид», бочки, катушка
    B(1, 17.6, 1.7, 18.2, 3.0, 'concrete', 0, { tint: '#6f8078' }); B(5.3, 17.6, 6, 18.2, 3.0, 'concrete', 0, { tint: '#6f8078' });
    D(box(0.08, 2.6, 1.6, 2.05, 1.3, 16.85, '#2f5a4a', 0, 0.3, 0), box(5.0, 0.3, 0.3, 3.5, 3.15, 17.9, '#2f5a4a')); hid(1.7, 16.0, 2.4, 17.6, 2.6);
    a.reel(4.6, 12.5); a.barrel(1.6, 9.0, '#8a2d22'); a.barrel(1.6, 9.8, '#2f5f8a'); crate(5.4, 20.6, 0.9);
    wallLamp('+x', 1, 13.5, 3.0); wallLamp('-x', 6, 20.5, 3.0);
    // кафе «Чайка»: вестибюль с площади, зал, выход на причал (короткая A)
    const CW = '#f2d7b0';
    W(12, -2, 12.4, 0.5, 3.6, CW); W(12, 2.5, 12.4, 10, 3.6, CW); W(12, 0.5, 12.4, 2.5, 1.0, CW, 2.6);
    W(12.4, -2, 16, -1.6, 3.6, CW); W(12.4, 9.6, 24, 10, 3.6, CW);
    W(23.6, 2.8, 24, 5.5, 3.6, CW); W(23.6, 7.5, 24, 9.6, 3.6, CW); W(23.6, 5.5, 24, 7.5, 1.0, CW, 2.6);
    W(16, -2, 24, 2.8, 3.6, '#e9dcc4');
    W(12, -2, 24, 10, 3.8, CREAM, 3.6); cornice(12, -2, 24, 10, 7.4, wc(CREAM, 0.94));
    band('-x', 12, -2.2, 8, 3.6, '#d9c3a8');
    facade('-x', 12, -1.5, 7.5, 1, { balc: 0.6, step: 3.0, lit: 0.4 }); facade('+x', 24, 4.5, 9.5, 1, { lit: 0.4 });
    floor(12.4, -1.6, 16, 2.8, 'cotto'); floor(12.4, 2.8, 23.6, 9.6, 'cotto'); floor(12, 0.5, 12.4, 2.5, 'cotto'); floor(23.6, 5.5, 24, 7.5, 'cotto');
    FD(4, '-x', 12, 1.5, 3.25, 1.6, 3.2); shop('lit', '-x', 12, 4.2); shop('lit', '-x', 12, 6.6); PD(6, '-x', 12, -1.0, 2.0, 1.0, 2.0);
    PD(6, '+x', 24, 9.0, 2.0, 1.4, 2.8);
    // зал: стойка, полки с бутылками, столики, диваны, лампы
    hid(16.6, 2.8, 22.6, 3.6, 1.05);
    D(box(6.0, 1.0, 0.8, 19.6, 0.5, 3.2, '#5a3a22'), box(6.1, 0.07, 0.9, 19.6, 1.04, 3.2, '#2a2420'), box(5.6, 0.06, 0.25, 19.6, 1.9, 2.92, '#5a3a22'), box(5.6, 0.06, 0.25, 19.6, 2.4, 2.92, '#5a3a22'));
    for (let i = 0; i < 18; i++) H(cyl(0.04, 0.3, 17.0 + i * 0.3, 2.1 + (i % 2) * 0.5, 2.92, ['#2f6a3a', '#7a3a1a', '#d8c87a', '#3a5a8a'][i % 4], 0, 0, 0, 5));
    for (let i = 0; i < 5; i++) { D(cyl(0.18, 0.05, 17.4 + i * 1.1, 0.75, 4.0, '#c25b3a', 0, 0, 0, 8)); H(cyl(0.03, 0.72, 17.4 + i * 1.1, 0.37, 4.0, IRON, 0, 0, 0, 4)); }
    table(14.4, 8.4, 1.1, 0.9, '#7a5434'); chair(14.4, 7.7, 0); chair(13.6, 8.4, -HP);
    table(18.4, 8.6, 1.1, 0.8, '#7a5434'); chair(18.4, 7.9, 0); chair(19.3, 8.6, HP);
    hid(20.6, 9.0, 23.6, 9.6, 0.9); D(box(3.0, 0.45, 0.6, 22.1, 0.25, 9.3, '#8a2a2a'), box(3.0, 0.6, 0.15, 22.1, 0.75, 9.55, '#8a2a2a'));
    table(22.1, 8.4, 1.2, 0.7, '#7a5434');
    hid(12.4, 6.4, 13.0, 7.6, 1.2); D(box(0.5, 1.2, 1.1, 12.7, 0.6, 7.0, '#3a2a1a'), box(0.48, 0.4, 0.05, 12.7, 1.0, 6.44, '#d8c878'));
    pendant(14.4, 2.9, 8.2, 3.6); pendant(18.4, 2.9, 8.4, 3.6); pendant(19.6, 2.9, 4.6, 3.6); pendant(14.2, 2.9, 0.6, 3.6);
    PD(4, '+z', -1.6, 14.2, 1.8, 1.2, 2.4); PD(4, '-z', 9.6, 16.4, 1.8, 1.0, 2.0); FD(6, '-x', 23.6, 3.8, 1.7, 0.7, 1.4);
    D(box(1.4, 0.012, 2.6, 14.2, 0.03, 0.6, '#8a3a2c'));

    // ===================== восток: холодильник, контора капитана, длинная A =====================
    B(12, -22, 34, -2, 8.2, 'corrug', 0, { tint: '#9ed2c8' }); PD(6, '-z', -22, 32.6, 2.2, 1.0, 2.0);
    for (const z of [-19, -13, -7]) { PD(5, '+x', 34, z, 1.6, 3.2, 3.4); D(box(0.8, 0.12, 3.6, 34.4, 3.6, z, '#4a5054')); }
    FD(7, '+x', 34, -16, 5.2, 1.2, 2.4); FD(7, '+x', 34, -10, 5.2, 1.2, 2.4); PD(3, '+x', 34, -4.5, 2.1, 2.4, 4.8);
    PD(5, '-z', -22, 16, 1.6, 3.2, 3.4); PD(5, '-z', -22, 22, 1.6, 3.2, 3.4); PD(4, '-z', -22, 26.5, 1.7, 1.4, 2.8); PD(3, '-z', -22, 30.5, 2.1, 2.4, 4.8);
    PD(5, '-x', 12, -5.2, 1.6, 2.6, 3.0); FD(7, '-x', 12, -5.2, 5.0, 1.2, 2.4);
    // контора капитана порта
    B(24, -2, 34, 4, 4.6, 'brick'); roof(24, -2, 34, 4, 4.6, 1.8, 0.45, { along: 'x', gable: '#8a4a36' });
    PD(6, '+z', 4, 29, 2.3, 1.8, 3.6); PD(2, '+z', 4, 26, 1.5, 1.4, 2.8); FD(1, '+z', 4, 32.2, 1.9, 1.1, 2.2); FD(1, '+x', 34, 1, 1.9, 1.1, 2.2); FD(1, '+x', 34, -1.2 + 0.0, 1.9, 1.1, 2.2);
    wallLamp('+z', 4, 27.3, 2.8);
    // длинная A: контейнеры вразбежку, погрузчик, сети, бочки
    cont(37.5, -22, 40, -16, 'contOrange', 'contBlue'); cont(34, -10, 36.5, -4, 'hbTeal'); cont(40.5, -2, 43, 4, 'contRed');
    forklift(38.6, -8.2, -1); pallet(41.6, -12.6, 2); pallet(41.6, -11.4, 1, '#8fa4ae'); stack(35.2, -27.2, 1.2);
    a.barrel(42.6, -25, '#2f5f8a'); a.barrel(42.0, -25.6, '#8a2d22'); a.barrel(42.7, -26.0, '#2f5f8a');
    hid(34.3, -14.4, 35.5, -12.2, 0.9); D({ sph: true, r: 0.9, x: 34.9, y: 0.35, z: -13.3, sx: 0.7, sy: 0.45, sz: 1.3, color: '#3d5a5e', seg: 7 }); H({ sph: true, r: 0.5, x: 34.8, y: 0.65, z: -12.9, sy: 0.5, color: '#e8b04a', seg: 6 });
    a.lamp(43.0, -20, 6, -HP); a.lamp(43.0, -4, 6, -HP);
    // восточная улица от спавна налётчиков
    truck(18.6, -26.2, -1, '#9fc8d0'); crate(30.6, -23.4, 1.1); crate(31.7, -23.2, 0.8); a.lamp(26, -27.5, 5.6, 0);
    a.tires(13.2, -23.1, 3);

    // ===================== точка A: причал с краном =====================
    // портальный кран: четыре ноги (укрытия), ригели, кабина, стрела над водой
    for (const [lx, lz] of [[27.5, 8.5], [27.5, 20.5], [40.5, 8.5], [40.5, 20.5]]) {
      hid(lx - 0.5, lz - 0.5, lx + 0.5, lz + 0.5, 15);
      D(box(1.0, 14.6, 1.0, lx, 7.3, lz, YEL), box(1.3, 0.5, 1.3, lx, 0.25, lz, '#3a3c3e'));
      H(box(1.02, 0.5, 1.02, lx, 1.0, lz, IRON), box(1.02, 0.5, 1.02, lx, 2.0, lz, IRON));
    }
    for (const lz of [8.5, 20.5]) D(box(14, 1.2, 1.2, 34, 15.2, lz, YEL));
    for (const lx of [27.5, 40.5]) { D(box(1.2, 1.2, 13.2, lx, 15.2, 14.5, YEL)); D(stick([lx, 2, 8.5], [lx, 13, 20.5], 0.12, 0.12, '#c48f22', 4), stick([lx, 2, 20.5], [lx, 13, 8.5], 0.12, 0.12, '#c48f22', 4)); }
    D(box(4, 2.8, 3.6, 34, 17.2, 14.5, '#d99a1b'), box(3.6, 1.2, 0.05, 34, 17.4, 12.68, '#2a3540'), box(56, 1.1, 1.8, 62, 16.3, 14.5, YEL), box(8, 1.1, 1.8, 30, 16.3, 14.5, YEL), box(2.5, 2.2, 2.6, 27.2, 17.4, 14.5, '#6c6f72'));
    D(stick([34, 18.6, 14.5], [56, 16.9, 14.5], 0.06, 0.06, '#222', 3), stick([34, 18.6, 14.5], [80, 16.9, 14.5], 0.06, 0.06, '#222', 3), box(0.05, 8, 0.05, 74, 12.3, 14.5, '#222'), box(6, 2.6, 2.5, 74, 7.0, 14.5, '#2f5d86'));
    D(box(0.3, 0.012, 24, 27.5, 0.032, 16, '#3a3c3e'), box(0.3, 0.012, 59.5, 40.5, 0.032, -1.75, '#3a3c3e'));
    // контейнеры, погрузчик, ящики
    cont(30, 11, 36, 13.5, 'contRed', 'hbTeal'); cont(36.5, 15.5, 39, 21.5, 'contBlue'); cont(29.5, 18.5, 32, 24.5, 'contOrange', 'contBlue'); cont(37.5, 4.5, 43.5, 7, 'hbTeal');
    forklift(33.6, 7.0, -1); stack(25.6, 14.4, 1.2); crate(36.2, 9.6, 1.1); stack(42.4, 23.2, 1.3); crate(34.6, 23.6, 1.1); pallet(25.4, 9.4, 2, '#8fa4ae'); pallet(25.4, 10.6, 1);
    a.reel(42.4, 19.4); a.tires(26.0, 26.6, 2);
    // будка охраны у въезда со стороны спецназа
    W(40.5, 25, 43.5, 27.6, 2.6, '#e8eef0'); D(box(3.4, 0.14, 3.0, 42, 2.67, 26.3, '#c64a32')); PD(1, '-x', 40.5, 26.3, 1.5, 1.1, 1.2, true); PD(1, '-z', 25, 42, 1.5, 1.1, 1.2, true);
    D(box(4.6, 0.12, 0.12, 38.0, 1.0, 26.3, '#e04a3a', 0, 0, 0.15)); hid(40.3, 26.1, 40.5, 26.5, 1.1);
    a.letter('A', 34.0, 16.6, 4.4);
    a.lamp(43.0, 12, 6, -HP); a.lamp(43.0, 22, 6, -HP);

    // ===================== спавн спецназа и северные улицы =====================
    floor(-12, 22, 12, 33, 'pave', '#efe2cc');
    bld(-12, 33, 12, 40, 11, CREAM, { roof: 2.8, along: 'x' });
    facade('-z', 33, -11.5, 11.5, 2, { balc: 0.35, band: '#dccab0' });
    shop('door', '-z', 33, -2); shop('door', '-z', 33, 2); shop('win', '-z', 33, -6, { cell: 0 }); shop('win', '-z', 33, 6, { cell: 0 }); shop('poster', '-z', 33, -9.5); shop('graffiti', '-z', 33, 9.5, { w: 2.0 });
    D(box(6.2, 0.16, 1.4, 0, 3.1, 32.3, '#cfc8b8')); for (const x of [-3, 3]) D(cyl(0.12, 3.0, x, 1.5, 31.7, '#e8e0d0', 0, 0, 0, 8)); hid(-3.15, 31.55, -2.85, 31.85, 3); hid(2.85, 31.55, 3.15, 31.85, 3);
    tree(-10.0, 23.8, 1.0); tree(10.0, 23.8, 1.05); bench(-10.2, 27.6, 1); bench(10.2, 27.6, 1);
    car(-6.5, 23.7, '#2b3d5a'); a.lamp(-11.3, 30.5, 5.6, HP); a.lamp(11.3, 30.5, 5.6, -HP);
    // улица спецназа к складу (B)
    bld(-50, 27, -12, 40, 9.4, PEACH); bld(-50, 22, -30, 27, 9.4, SALMON, { roof: 2.2, along: 'z' });
    facade('-z', 27, -29.5, -12.5, 2, { balc: 0.4, band: '#dcc0a0' }); facade('+x', -12, 27.5, 32.5, 2, { balc: 0.3 }); facade('+x', -30, 22.5, 26.5, 2, {});
    shop('door', '-z', 27, -27); shop('shutter', '-z', 27, -22.5); shop('graffiti', '-z', 27, -18.5); shop('door', '-z', 27, -14.5); shop('wanted', '+x', -30, 24.5);
    pallet(-14.0, 23.0, 2); stack(-29.0, 23.0, 1.1); a.barrel(-19.5, 26.2, '#3b5f3a'); a.lamp(-19, 26.4, 5.4, Math.PI);
    // улица спецназа к причалу (A)
    bld(12, 28, 24, 40, 10.2, OCHRE, { roof: 2.4, along: 'z' });
    B(24, 28, 44, 40, 8.6, 'corrug', 0, { tint: '#8fc6c0' });
    facade('-z', 28, 12.5, 23.5, 2, { balc: 0.4, band: '#dcc49a' }); facade('-x', 12, 28.5, 32.5, 2, {});
    shop('door', '-z', 28, 15); shop('lit', '-z', 28, 19); shop('poster', '-z', 28, 22.6);
    PD(5, '-z', 28, 28, 1.6, 3.2, 3.4); PD(5, '-z', 28, 34, 1.6, 3.2, 3.4); PD(5, '-z', 28, 40, 1.6, 3.2, 3.4); FD(7, '-z', 28, 31, 5.4, 1.2, 2.4); FD(7, '-z', 28, 37, 5.4, 1.2, 2.4);
    PD(6, '-z', 28, 25.6, 2.4, 1.6, 3.2);
    car(17.8, 26.4, '#c25b3a'); crate(22.6, 23.0, 1.0); a.lamp(18, 22.6, 5.4, 0);

    // ===================== провода между домами =====================
    wire([-18, 9.6, -12], [-6, 9.4, -12], 0.5); wire([-6, 8.8, -18], [-1, 8.6, -18], 0.3); wire([1, 9.8, 14], [6, 9.6, 14], 0.35); wire([12, 8.2, -25], [12, 8.8, -40], 0.1);
    wire([-38, 10.6, -22], [-38, 10.4, -28], 0.5); wire([-30, 8.4, 22], [-30, 8.8, 27], 0.3);

    // ===================== за пределами карты =====================
    // корабль на рейде (корпус и надстройка видны всегда; контейнеры и маяк — на высоком)
    D(box(16, 7, 64, 92, 1.5, -6, '#6b1f1a'), box(16.2, 1.2, 64.2, 92, -1.2, -6, '#1d1d1d'), box(11.3, 7, 11.3, 92, 1.5, 26, '#6b1f1a', 0, Math.PI / 4, 0),
      box(14, 9, 9, 92, 9.5, -33, '#e8e4dc'), box(14.2, 1.2, 9.2, 92, 11.5, -33, '#2a3540'), box(3, 6, 3, 92, 16.5, -35, '#c8c4bc'), box(3.2, 1.2, 3.2, 92, 19, -35, '#a33a2a'));
    const cc = ['#2f5d86', '#9c3b2c', '#2c7a74', '#c46a1f', '#7a7f84'];
    for (let i = 0; i < 18; i++) D(box(2.5, 2.6, 6, 87 + (i % 3) * 3.3 - 1, 6.3 + Math.floor(i / 9) * 2.6, -24 + (i % 9) * 5.5 - (i % 3), cc[(i * 7) % 5]));
    // портовые краны на том берегу
    for (const z of [-60, -38]) H(box(1.2, 30, 1.2, 120, 15, z - 6, '#c64a32'), box(1.2, 30, 1.2, 120, 15, z + 6, '#c64a32'), box(1.2, 30, 1.2, 132, 15, z - 6, '#c64a32'), box(1.2, 30, 1.2, 132, 15, z + 6, '#c64a32'),
      box(60, 2, 2, 110, 31, z, '#c64a32'), box(5, 4, 5, 126, 34, z, '#e8e4dc'), box(14, 1.2, 14, 126, 29.5, z, '#c64a32'));
    // маяк на скале
    H({ sph: true, r: 14, x: 150, y: -6, z: -95, color: '#5b5048', seg: 10, sy: 0.6 });
    for (let i = 0; i < 6; i++) H(cyl(2.6 - i * 0.18, 4, 150, 4 + i * 4, -95, i % 2 ? '#c8352a' : '#eeeae2', 0, 0, 0, 12, 2.6 - (i + 1) * 0.18));
    H(cyl(1.6, 2.4, 150, 29, -95, '#ffe7a0', 0, 0, 0, 10), { cyl: true, r: 0.2, r2: 2.2, h: 2.2, x: 150, y: 31.3, z: -95, color: '#2a2a2a', seg: 10 });
    a.lamps.push([150, 29, -95, 9]);
    // мол с маленьким маяком
    H(box(70, 2, 5, 80, -0.3, 58, '#8a8378'), cyl(1.2, 7, 112, 4, 58, '#e8e4dc', 0, 0, 0, 10), cyl(1.4, 1.2, 112, 8, 58, '#3fa04a', 0, 0, 0, 10));
    // крыши соседних кварталов: силуэт за домами по периметру
    for (let i = 0; i < 14; i++) {
      const side = i % 3, t = Math.floor(i / 3) / 4.6 + R(0, 0.12), w = R(7, 11), d = R(7, 10), hh = R(9, 15);
      const x = side === 0 ? -55 - R(0, 6) : -40 + t * 76, z = side === 0 ? -30 + t * 64 : side === 1 ? 45 + R(0, 5) : -46 - R(0, 5);
      const tint = [PEACH, CREAM, SALMON, OCHRE, ROSE][i % 5];
      H(box(w, hh, d, x, hh / 2, z, wc(tint, 0.9)), { shape: true, pts: [[-d / 2 - 0.4, 0], [0, 2.2], [d / 2 + 0.4, 0]], d: w + 0.8, x, y: hh, z, color: '#a8553a', cs: 1 });
      for (let k = 0; k < 3; k++) H(box(1.0, 1.6, 0.05, x - w / 3 + k * w / 3, hh * 0.6, z + (side === 2 ? d / 2 + 0.03 : -d / 2 - 0.03), R(0, 1) < 0.3 ? '#ffc46a' : '#2a3540'));
    }
    // мелочь на крышах: баки, антенны, трубы
    for (const [x, z, h] of [[-28, -14, 13.8], [-22, -10, 13.8], [-32, 30, 9.4], [30, 34, 8.6], [-46, -10, 13.2], [20, -12, 8.2], [-46, -26, 11.6], [-35, -34, 10.4], [28, -34, 7.4]]) {
      H(cyl(0.6, 1.4, x, h + 1.05, z, '#b8b2a6', 0, 0, 0, 8), box(0.08, 2.6, 0.08, x + 1.4, h + 1.3, z + 0.6, '#3a3c3e'), box(1.2, 0.05, 0.05, x + 1.4, h + 2.4, z + 0.6, '#3a3c3e'));
      D(box(0.7, 1.2, 0.7, x - 1.6, h + 0.6, z - 1.0, '#9a6a52'));
    }
    // пятна, лужи у стен, световые круги под фонарями
    a.stain(-30.5, -1, 3); a.stain(-23, -0.4, 4); a.stain(38.6, -8.2, 3); a.stain(33.6, 7, 3); a.stain(-23, 11.5, 3); a.stain(18.6, -26.2, 3.5); a.stain(-30, 12, 3.2); a.stain(3.5, 14, 2.2); a.stain(-40, -20, 2.5);
    for (const l of a.lamps) if (!l[3]) a.pool(l[0], l[2], 6);
    a.gulls = 4;
  }

  // ===================== «Сакура» =====================
  // плотный старый квартал весной. Три линии: длинная A (западная улица → двор храма), центр (переулок → мост через канал →
  // площадь; оттуда сквозь апартаменты к A и сквозь идзакаю к B), длинная B (восточная улица → крытый рынок).
  // Налётчики — у станции на юге, спецназ — у бани на севере. Всё проходимое — на уровне земли (ступенек нет).
  function layoutSakura(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 5150; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    // палитра: тёмное дерево, белая штукатурка, серая черепица, киноварь, розовые цветы, тёплые фонари
    const TIM = '#3a281c', TIM_L = '#5e432e', TIM_D = '#261a12', VER = '#c63b22', STONE = '#8f8b83', STONE_D = '#6f6c66', PAPER = '#f6eedb', IRON = '#2b2d30';
    const WHITE = '#f6f1e8', CREAM = '#f1e5cf', OCHRE = '#ead2a8', ASH = '#e2ddd3', CLAY = '#e4c39a', TILE = '#e9edf2', TILE2 = '#d9dfe6', COPPER = '#8fbcae';
    const PINKS = ['#fff4f7', '#ffe4ec', '#fbd3e0', '#ffffff', '#f7c6d6'];
    const NN = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] };
    const W = (x0, z0, x1, z1, h, tint, y0) => B(x0, z0, x1, z1, h, 'plaster', y0, { tint: tint || WHITE });
    const lintel = (x0, z0, x1, z1, yb, yt, tint) => B(x0, z0, x1, z1, yt - yb, 'plaster', yb, { tint: tint || WHITE });
    const floor = (x0, z0, x1, z1, mat, tint) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false, tint });
    const hid = (x0, z0, x1, z1, h, y0) => B(x0, z0, x1, z1, h, 'none', y0 || 0, { hidden: true });
    const DC = (cell, x, y, z, w, h, n) => a.decals.push({ cell, x, y, z, w, h, n, atlas: 'skjp', lit: false });
    // точка на фасаде: сторона n, вдоль стены — t, отступ от стены — o
    const fp = (n, x, z, o) => [x + NN[n][0] * o, z + NN[n][1] * o];

    // ---------- помощники ----------
    // машия: каменный цоколь, решётка кодзи (или штукатурка) внизу, штукатурка с балками наверху, навес хисаси, черепичная крыша
    // o: h — высота стен, one — одноэтажный, tint, plain — первый этаж тоже штукатурка, rise/ov/along/hip/col — крыша, f — видимые стороны
    const mach = (x0, z0, x1, z1, o) => {
      o = o || {};
      const h = o.h || 5.8, one = !!o.one, lo = one ? h : 2.75, tint = o.tint || WHITE, col = o.col || ['#ffffff', '#e4ecf6', '#f6e4d2', '#dfe6ec', '#f0ece6'][(R(0, 5) | 0)];
      B(x0, z0, x1, z1, 0.32, 'stonewall');
      if (one) W(x0, z0, x1, z1, h - 0.32, tint, 0.32);
      else {
        if (o.plain) W(x0, z0, x1, z1, lo - 0.32, tint, 0.32); else B(x0, z0, x1, z1, lo - 0.32, 'koshi', 0.32);
        W(x0, z0, x1, z1, h - lo, tint, lo);
      }
      const fs = o.f || ['+x', '-x', '+z', '-z'];
      for (const n of fs) {
        const ax = n === '+z' || n === '-z', len = ax ? x1 - x0 : z1 - z0, c = ax ? (x0 + x1) / 2 : (z0 + z1) / 2;
        const e = n === '+z' ? z1 : n === '-z' ? z0 : n === '+x' ? x1 : x0, s = NN[n][0] + NN[n][1];
        const bx = (yy, hh, t) => D(box(ax ? len + 0.12 : t, hh, ax ? t : len + 0.12, ax ? c : e + s * t / 2, yy, ax ? e + s * t / 2 : c, TIM));
        if (!one) { bx(lo + 0.05, 0.2, 0.14); }
        const y0 = one ? 0.32 : lo, k = Math.max(1, Math.round(len / 4.4));
        for (let i = 0; i <= k; i++) {
          const t = (ax ? x0 : z0) + len * i / k;
          D(box(ax ? 0.15 : 0.09, h - y0, ax ? 0.09 : 0.15, ax ? t : e + s * 0.045, (h + y0) / 2, ax ? e + s * 0.045 : t, TIM));
        }
        // окна второго этажа
        if (!one && !o.noWin) {
          const m = Math.max(1, Math.round(len / 4.2));
          for (let i = 0; i < m; i++) { const t = (ax ? x0 : z0) + len * (i + 0.5) / m; DC((i + (o.wph || 0)) % 2 ? 1 : 0, ax ? t : e, lo + (h - lo) * 0.52, ax ? e : t, 1.5, 1.6 * Math.min(1, (h - lo) / 2.6), n); }
        }
      }
      if (!one) a.roofs.push({ X0: x0, X1: x1, Z0: z0, Z1: z1, y: lo + 0.24, h: 0.4, ov: 0.8, hip: true, col, alongX: (x1 - x0) >= (z1 - z0) });
      a.roof(x0, z0, x1, z1, h, o.rise || Math.min(2.4, (Math.min(x1 - x0, z1 - z0)) * 0.3), o.ov == null ? 0.85 : o.ov, { col, along: o.along, hip: !!o.hip, gable: o.gable || tint, ridgeCol: '#2c3036', finial: o.finial });
    };
    // фасад лавки на первом этаже: дверь, норэн, вывеска, фонари под навесом
    const shop = (n, x, z, o) => {
      o = o || {};
      const ax = n === '+z' || n === '-z', s = NN[n][0] + NN[n][1], ry = ax ? 0 : HP;
      DC(3, x, 1.32, z, 1.9, 2.4, n);
      const nc = o.noren || ['#23326a', '#7a2626', '#2f4a3a', '#3a3a3a'][(R(0, 4) | 0)];
      for (let j = 0; j < 2; j++) { const t = (j - 0.5) * 0.9; D(box(0.86, 0.86, 0.03, ax ? x + t : x + s * 0.14, 2.12, ax ? z + s * 0.14 : z + t, nc, 0, ry, 0)); }
      D(box(ax ? 1.9 : 0.06, 0.06, ax ? 0.06 : 1.9, ax ? x : x + s * 0.16, 2.56, ax ? z + s * 0.16 : z, TIM_D));
      if (o.sign !== false) { const p = ax ? [x + 1.45, z] : [x, z + 1.45]; DC(o.sign || 2, p[0], 1.7, p[1], 0.62, 1.25, n); }
      if (o.lan !== false) for (const t of (o.red ? [-1.25, 1.25] : [-1.25])) { const p = ax ? [x + t, z + s * 0.55] : [x + s * 0.55, z + t]; lan(p[0], 2.2, p[1], o.lanCol || (o.red ? '#d63a26' : '#f3e2b8'), 2.62); }
    };
    // бумажный фонарь тётин на шнуре (светится)
    const lan = (x, y, z, col, top) => {
      col = col || '#d63a26';
      D(cyl(0.22, 0.5, x, y, z, col, 0, 0, 0, 10), box(0.27, 0.06, 0.27, x, y + 0.27, z, TIM_D, 0, 0.4, 0)); H(box(0.27, 0.06, 0.27, x, y - 0.27, z, TIM_D, 0, 0.4, 0));
      // шнур тоньше 4 см — в упрощённом декоре (низкое/среднее) не строится
      if (top && top > y + 0.35) D(box(0.035, top - y - 0.31, 0.035, x, (top + y + 0.31) / 2, z, '#1a1a1a'));
      a.lamps.push([x, y, z, 0.95]);
    };
    // сакура: низкий ствол, 3 ветви, облака цветов (дешёвые крупные шары с фактурой цветков)
    const tree = (x, z, h, k, o) => {
      o = o || {}; k = k || 1; h = h || 5.4;
      const lean = R(0, 6.28), fh = h * 0.38, f = [x + Math.cos(lean) * 0.3 * k, fh, z + Math.sin(lean) * 0.3 * k];
      D(stick([x, 0, z], [x, 0.55, z], 0.36 * k, 0.28 * k, '#3a2a20', 7), stick([x, 0.5, z], f, 0.28 * k, 0.2 * k, '#45312a', 7));
      const m = o.m || 3;
      for (let j = 0; j < m; j++) {
        const an = lean + j * 6.28 / m + R(-0.4, 0.4), out = R(1.5, 2.1) * k, up = h * R(0.62, 0.74);
        const e = [f[0] + Math.cos(an) * out, up, f[2] + Math.sin(an) * out];
        D(stick(f, e, 0.17 * k, 0.08 * k, '#45312a', 5));
        L({ sph: true, r: R(1.35, 1.65) * k, x: e[0], y: e[1] + 0.15, z: e[2], sx: 1.18, sy: 0.74, sz: 1.12, ry: R(0, 3), color: PINKS[(R(0, 5) | 0)], seg: 16 });
        L({ sph: true, r: R(1.02, 1.15) * k, x: e[0] + Math.cos(an) * 0.95 * k, y: e[1] - 0.55 * k, z: e[2] + Math.sin(an) * 0.95 * k, sx: 1.2, sy: 0.75, sz: 1.15, ry: R(0, 3), color: PINKS[(R(0, 5) | 0)], seg: 14 });
      }
      L({ sph: true, r: 1.75 * k, x: f[0], y: h * 0.84, z: f[2], sx: 1.2, sy: 0.72, sz: 1.2, ry: R(0, 3), color: PINKS[1], seg: 16 });
      if (o.solid !== false) hid(x - 0.3 * k, z - 0.3 * k, x + 0.3 * k, z + 0.3 * k, fh + 0.4);
      if (o.petals !== false) a.ground.push({ kind: 'petals', x, z, sz: 6.2 * k });
      a.trees.push({ x: f[0], y: h * 0.75, z: f[2], r: 2.5 * k, petals: o.fall !== false });
    };
    // торговый автомат лицом в сторону n
    const vend = (x, z, n, col) => {
      const ax = n === '+z' || n === '-z', s = NN[n][0] + NN[n][1];
      const w = 0.92, d = 0.78, hh = 1.86;
      hid(ax ? x - w / 2 : x - d / 2, ax ? z - d / 2 : z - w / 2, ax ? x + w / 2 : x + d / 2, ax ? z + d / 2 : z + w / 2, hh);
      D(box(ax ? w : d, hh, ax ? d : w, x, hh / 2, z, col || '#e8e8e4'), box(ax ? w + 0.04 : d + 0.04, 0.1, ax ? d + 0.04 : w + 0.04, x, hh + 0.05, z, IRON));
      DC(5, ax ? x : x + s * (d / 2), 0.95, ax ? z + s * (d / 2) : z, w - 0.04, hh - 0.08, n);
    };
    // велосипед (rot: 0 — вдоль X, иначе вдоль Z)
    const bike = (x, z, rot, col) => {
      const c = rot ? 0 : 1, sn = rot ? 1 : 0, ry = rot ? HP : 0, P = (t, y) => [x + c * t, y, z + sn * t];
      col = col || '#b8352a';
      for (const t of [-0.52, 0.52]) { const p = P(t, 0.34); H({ torus: true, r: 0.31, tube: 0.03, x: p[0], y: p[1], z: p[2], ry, color: '#1d1d1d', seg: 12 }); a.lo.push({ cyl: true, r: 0.32, h: 0.04, x: p[0], y: p[1], z: p[2], rx: rot ? 0 : HP, rz: rot ? HP : 0, color: '#26272a', seg: 9 }); }
      D(stick(P(-0.52, 0.34), P(0, 0.36), 0.025, 0.025, col, 4), stick(P(0, 0.36), P(0.35, 0.78), 0.025, 0.025, col, 4), stick(P(-0.52, 0.34), P(-0.15, 0.78), 0.025, 0.025, col, 4),
        stick(P(-0.15, 0.78), P(0.35, 0.78), 0.025, 0.025, col, 4), stick(P(0.52, 0.34), P(0.42, 0.95), 0.022, 0.022, '#9aa0a6', 4), stick(P(0, 0.36), P(-0.18, 0.86), 0.025, 0.025, col, 4));
      const hb = P(0.42, 0.98), sp = P(-0.18, 0.9), bk = P(0.62, 0.72);
      D(box(rot ? 0.5 : 0.04, 0.04, rot ? 0.04 : 0.5, hb[0], hb[1], hb[2], '#2a2a2a'), box(0.22, 0.06, 0.12, sp[0], sp[1], sp[2], '#1d1d1d', 0, ry, 0), box(rot ? 0.32 : 0.3, 0.2, rot ? 0.3 : 0.32, bk[0], bk[1], bk[2], '#9aa0a6'));
    };
    // столб ЛЭП: бетонный столб, траверсы, изоляторы, трансформатор; возвращает точку крепления проводов
    const pole = (x, z, h, rot) => {
      h = h || 8.4; const ry = rot ? HP : 0;
      D(cyl(0.13, h, x, h / 2, z, '#a9a59c', 0, 0, 0, 8, 0.17), box(rot ? 0.12 : 1.9, 0.12, rot ? 1.9 : 0.12, x, h - 0.55, z, '#5c5a55'), box(rot ? 0.12 : 1.4, 0.1, rot ? 1.4 : 0.12, x, h - 1.25, z, '#5c5a55'));
      for (const t of [-0.8, 0, 0.8]) D(cyl(0.05, 0.16, x + (rot ? 0 : t), h - 0.42, z + (rot ? t : 0), '#d8d4cc', 0, 0, 0, 5));
      if (R(0, 1) < 0.6) D(cyl(0.28, 0.85, x + (rot ? 0.38 : 0), h - 2.3, z + (rot ? 0 : 0.38), '#8d939a', 0, 0, 0, 8));
      hid(x - 0.18, z - 0.18, x + 0.18, z + 0.18, h);
      return [x, h - 0.4, z];
    };
    // провода: провисающие ломаные (толщина 0.045 — видны и на среднем качестве)
    const wire = (p, q, sag) => {
      const n = 4;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n, A = [p[0] + (q[0] - p[0]) * t0, p[1] + (q[1] - p[1]) * t0 - Math.sin(t0 * Math.PI) * sag, p[2] + (q[2] - p[2]) * t0];
        const Bq = [p[0] + (q[0] - p[0]) * t1, p[1] + (q[1] - p[1]) * t1 - Math.sin(t1 * Math.PI) * sag, p[2] + (q[2] - p[2]) * t1];
        D(G.limb(A, Bq, 0.045, '#1c1c1c'));
      }
    };
    const wires = (p, q, sag) => { for (const o of [-0.8, 0.8]) { const dx = Math.abs(q[0] - p[0]) > Math.abs(q[2] - p[2]) ? 0 : o, dz = dx ? 0 : o; wire([p[0] + dx, p[1], p[2] + dz], [q[0] + dx, q[1], q[2] + dz], sag || 0.6); } };
    // гирлянда фонарей между двумя точками
    const garland = (p, q, n, sag, cols) => {
      wire(p, q, sag);
      for (let i = 1; i < n; i++) { const t = i / n, y = p[1] + (q[1] - p[1]) * t - Math.sin(t * Math.PI) * sag; lan(p[0] + (q[0] - p[0]) * t, y - 0.42, p[2] + (q[2] - p[2]) * t, (cols || ['#d63a26', '#f3e2b8'])[i % 2], y); }
    };
    // ящики, бочки сакэ, кадки
    const taru = (x, z, k) => { k = k || 1; hid(x - 0.36 * k, z - 0.36 * k, x + 0.36 * k, z + 0.36 * k, 0.7 * k); D(cyl(0.36 * k, 0.7 * k, x, 0.35 * k, z, '#d8c69a', 0, 0, 0, 9), cyl(0.37 * k, 0.06 * k, x, 0.62 * k, z, '#3a2a1a', 0, 0, 0, 9, null), cyl(0.37 * k, 0.06 * k, x, 0.1 * k, z, '#3a2a1a', 0, 0, 0, 9), box(0.04, 0.3 * k, 0.32 * k, x + 0.36 * k, 0.38 * k, z, ['#b02a1e', '#23326a', '#1d1d1d'][(R(0, 3) | 0)])); };
    const pot = (x, z, k) => { k = k || 1; hid(x - 0.24 * k, z - 0.24 * k, x + 0.24 * k, z + 0.24 * k, 0.5 * k); D(cyl(0.24 * k, 0.36 * k, x, 0.18 * k, z, '#6b4a3a', 0, 0, 0, 8, 0.18 * k), { sph: true, r: 0.3 * k, x, y: 0.55 * k, z, sy: 0.8, color: '#4f7f36', seg: 7 }); };
    // крыльцо-плита у двери (декор, без столкновения)
    const step = (x0, z0, x1, z1) => D(box(x1 - x0, 0.08, z1 - z0, (x0 + x1) / 2, 0.04, (z0 + z1) / 2, '#9a968c'));

    // ===================== периметр и задники =====================
    // запад: ряд маший вдоль длинной A (фасады на восток)
    mach(-42, -34, -38, -29, { h: 5.4, f: ['+z', '+x'], along: 'x' });
    mach(-42, -29, -38, -16, { h: 5.9, f: ['+x'], along: 'z' }); shop('+x', -38, -24.5, { noren: '#23326a' }); shop('+x', -38, -19.5, { sign: false, lan: false });
    mach(-42, -16, -38, -4, { h: 5.5, f: ['+x'], along: 'z', tint: CREAM, wph: 1 }); shop('+x', -38, -12.5, { noren: '#7a2626', red: true }); DC(3, -38, 1.32, -7, 1.9, 2.4, '+x');
    mach(-42, -4, -38, 8, { h: 6.1, f: ['+x'], along: 'z' }); shop('+x', -38, -1, { noren: '#2f4a3a' }); DC(3, -38, 1.32, 4.5, 1.9, 2.4, '+x');
    // храмовая ограда (запад и север храма)
    W(-42, 8, -38, 34, 1.3, ASH, 0); W(-41, 8, -38, 34, 2.4, WHITE, 1.3);
    a.roof(-41, 8, -38, 34, 3.7, 0.5, 0.35, { col: TILE2, along: 'z', ridgeCol: '#30343a' });
    // юг: дома вдоль южной улицы
    mach(-38, -34, -26, -29, { h: 5.6, f: ['+z'], along: 'x', tint: CREAM }); shop('+z', -34.5, -29); shop('+z', -29, -29, { sign: 6, red: true });
    mach(-26, -34, -12, -29, { h: 6.0, f: ['+z', '+x'], along: 'x' }); shop('+z', -22, -29, { noren: '#23326a' }); shop('+z', -16, -29, { sign: false });
    mach(12, -34, 24, -29, { h: 5.8, f: ['+z', '-x'], along: 'x', tint: OCHRE, wph: 1 }); shop('+z', 15.5, -29, { noren: '#7a2626' }); shop('+z', 21, -29, { sign: false, lan: false });
    mach(24, -34, 38, -29, { h: 5.5, f: ['+z'], along: 'x' }); shop('+z', 28, -29, { noren: '#2f4a3a' }); shop('+z', 34, -29);
    mach(38, -34, 42, -29, { h: 5.5, f: ['+z', '-x'], along: 'x', tint: CREAM });
    // восток: дома вдоль длинной B (фасады на запад)
    mach(38, -29, 42, -14, { h: 5.7, f: ['-x'], along: 'z', tint: CREAM }); shop('-x', 38, -25, { noren: '#23326a' }); shop('-x', 38, -18.5, { sign: 6, red: true });
    mach(38, -14, 42, 4, { h: 6.0, f: ['-x'], along: 'z' }); shop('-x', 38, -9.5, { noren: '#7a2626' }); DC(3, 38, 1.32, -3.5, 1.9, 2.4, '-x'); shop('-x', 38, 1, { sign: false });
    mach(38, 4, 42, 26, { h: 5.6, f: ['-x'], along: 'z', tint: OCHRE, wph: 1 });
    mach(38, 26, 42, 34, { h: 5.6, f: ['-x', '-z'], along: 'z' });

    // ===================== юг: станция и спавн налётчиков =====================
    // маленькая станция: стена с окнами, навес на столбах, часы, скамьи
    W(-12, -34, 12, -32, 4.4, CREAM); B(-12, -34, 12, -32, 0.5, 'stonewall');
    a.roof(-12.5, -34, 12.5, -32, 4.4, 1.2, 0.5, { col: TILE2, along: 'x' });
    for (const x of [-9, -3, 3, 9]) DC(1, x, 2.3, -32, 1.6, 1.7, '+z');
    DC(3, 0, 1.32, -32, 2.2, 2.6, '+z');
    for (const x of [-10.5, -6, 6, 10.5]) { D(cyl(0.1, 3.1, x, 1.55, -30.4, TIM, 0, 0, 0, 8)); hid(x - 0.14, -30.54, x + 0.14, -30.26, 3.1); }
    D(box(23.4, 0.14, 2.3, 0, 3.15, -31.1, TIM_D), box(23.6, 0.06, 2.5, 0, 3.26, -31.1, '#5d636b', 0.06));
    D(cyl(0.38, 0.1, 0, 3.75, -31.95, '#f4f1ea', HP, 0, 0, 14), cyl(0.42, 0.06, 0, 3.75, -31.98, TIM_D, HP, 0, 0, 14), box(0.04, 0.26, 0.02, 0, 3.82, -31.88, '#1a1a1a'), box(0.2, 0.04, 0.02, 0.08, 3.75, -31.88, '#1a1a1a'));
    D(box(2.6, 0.5, 0.06, 0, 2.95, -31.9, '#f4f1ea'), box(2.4, 0.08, 0.04, 0, 2.95, -31.86, '#2a5a9a'));
    for (const x of [-7.5, 7.5]) { hid(x - 0.9, -31.9, x + 0.9, -31.4, 0.48); D(box(1.8, 0.07, 0.42, x, 0.45, -31.65, TIM_L), box(1.8, 0.5, 0.06, x, 0.72, -31.85, TIM_L), box(0.08, 0.42, 0.4, x - 0.8, 0.21, -31.65, IRON), box(0.08, 0.42, 0.4, x + 0.8, 0.21, -31.65, IRON)); }
    // клумбы с сакурой по краям площади (укрытие у выходов на южную улицу)
    for (const sx of [-1, 1]) {
      const cx = sx * 12.6, cz = -26.6;
      B(cx - 1.1, cz - 1.1, cx + 1.1, cz + 1.1, 0.55, 'stonewall');
      tree(cx, cz, 5.6, 0.95);
    }
    vend(-11.5, -24.6, '-z'); vend(-10.55, -24.6, '-z', '#c8302a');
    for (let i = 0; i < 3; i++) bike(4.6 + i * 0.75, -32.3 + 0.0, 1, ['#b8352a', '#2f6fae', '#e8e2d2'][i]);
    hid(4.1, -32, 6.5, -31.3, 1.0);
    // южная улица: столбы и провода
    const pS = [pole(-30, -29.4, 8.4), pole(-14, -29.4, 8.6), pole(14, -29.4, 8.6), pole(30, -29.4, 8.4)];
    wires(pS[0], pS[1]); wires(pS[2], pS[3]); wires(pS[1], pS[2], 0.9);
    crate(-24.2, -25, 1.1); stack(23.5, -25, 1.2); taru(-30.5, -25, 1); taru(-29.8, -25.3, 0.9);
    a.toro(-7.3, -25.0, 0.8); a.toro(-0.7, -25.0, 0.8);

    // ===================== длинная A: западная улица =====================
    // южный ряд между улицами (лавки на юг, задние стены на соединитель)
    mach(-33, -24, -20, -19, { h: 5.6, f: ['-z', '+z', '-x'], along: 'x', tint: CREAM }); shop('-z', -29.5, -24, { noren: '#23326a' }); shop('-z', -23.5, -24, { sign: 6, red: true });
    mach(-20, -24, -6, -19, { h: 6.0, f: ['-z', '+z', '+x'], along: 'x' }); shop('-z', -16.5, -24, { noren: '#2f4a3a' }); shop('-z', -10, -24, { sign: false });
    // западный блок: машия и амбар-кура
    mach(-33, -16, -24, -4, { h: 5.8, f: ['-x', '-z'], along: 'z', wph: 1 }); shop('-x', -33, -12, { noren: '#7a2626' }); DC(3, -33, 1.32, -6.5, 1.9, 2.4, '-x');
    // кура: высокий белый амбар с тёмным низом и гербом
    B(-33, -4, -24, 8, 1.4, 'stonewall'); W(-33, -4, -24, 8, 4.4, WHITE, 1.4); a.roof(-33, -4, -24, 8, 5.8, 2.2, 0.7, { col: TILE, along: 'z', gable: WHITE });
    for (const [x, z, n] of [[-33, 2, '-x'], [-28.5, 8, '+z']]) { const ax = n === '+z'; D(box(ax ? 1.5 : 0.08, 1.5, ax ? 0.08 : 1.5, x + (ax ? 0 : -0.04), 4.2, z + (ax ? 0.04 : 0), TIM_D), box(ax ? 1.2 : 0.1, 1.2, ax ? 0.1 : 1.2, x + (ax ? 0 : -0.05), 4.2, z + (ax ? 0.05 : 0), '#f2ece0')); }
    D(box(0.12, 0.18, 12.2, -33.06, 5.65, 2, TIM_D), box(9.2, 0.18, 0.12, -28.5, 5.65, 8.06, TIM_D));
    // реквизит улицы: телега, ящики, автоматы, велосипеды, столбы
    a.cart(-35.8, -9.5, HP);
    stack(-34.0, -1.5, 1.2); crate(-37.2, 2.2, 1.0);
    vend(-37.55, -21.2, '+x', '#2f6fae'); vend(-37.55, -22.15, '+x');
    bike(-33.6, -14.2, 1, '#2f6fae'); bike(-33.6, -13.2, 1, '#e8e2d2'); hid(-33.9, -15, -33, -12.5, 1.0);
    taru(-37.4, -16.8); taru(-37.4, -17.6, 0.9); pot(-33.4, 6.6); pot(-37.6, 6.8, 1.1); pot(-33.4, -19.8);
    const pA = [pole(-37.5, -26, 8.4, 1), pole(-37.5, -10, 8.4, 1), pole(-37.5, 5.2, 8.2, 1)];
    wires(pA[0], pA[1]); wires(pA[1], pA[2]);
    garland([-38, 4.6, -5.5], [-33, 4.6, -5.5], 4, 0.4);
    // соединитель налётчиков (запад): бочка с водой, кадки, бамбуковый забор
    D(cyl(0.42, 0.9, -26.5, 0.45, -16.6, '#6a4a2e', 0, 0, 0, 10), cyl(0.43, 0.06, -26.5, 0.7, -16.6, IRON, 0, 0, 0, 10), cyl(0.36, 0.02, -26.5, 0.91, -16.6, '#2a4a50', 0, 0, 0, 10));
    hid(-26.95, -17.05, -26.05, -16.15, 0.92);
    pot(-20.5, -16.5); pot(-12.6, -18.5, 1.2); crate(-17.2, -18.4, 1.0);

    // ===================== центр: переулок, канал и мост =====================
    // дома между переулком и каналом
    mach(-24, -16, -15, -6, { h: 5.6, f: ['-z', '+z'], along: 'x', tint: CREAM, wph: 1 }); shop('-z', -19.5, -16, { sign: false, noren: '#23326a' });
    mach(-15, -16, -6, -6, { h: 6.1, f: ['-z', '+z', '+x'], along: 'x' }); shop('+x', -6, -14.5, { noren: '#7a2626' });
    B(-24, -6, -16, -2, 3.6, 'stonewall'); W(-24, -6, -16, -2, 2.4, WHITE, 3.6); a.roof(-24, -6, -16, -2, 6.0, 1.2, 0.5, { col: TILE2, along: 'x' });
    mach(-2, -24, 7, -13, { h: 5.9, f: ['-x', '+z', '-z'], along: 'z', tint: CREAM }); shop('-x', -2, -18.5, { noren: '#2f4a3a' }); shop('+z', 2.5, -13, { sign: 6, red: true }); shop('-z', 2.5, -24, { noren: '#23326a' });
    mach(7, -24, 14, -13, { h: 5.5, f: ['+z', '-z'], along: 'z', tint: OCHRE }); shop('+z', 10.5, -13, { noren: '#7a2626' });
    mach(14, -24, 17, -17, { h: 5.0, f: ['+x', '-z', '+z'], one: true, along: 'z' });
    mach(2, -10, 12, -6, { h: 4.6, f: ['-z', '+z'], one: true, along: 'x', tint: WHITE }); DC(3, 7, 1.32, -10, 1.9, 2.4, '-z'); DC(1, 4.5, 2.2, -10, 1.5, 1.5, '-z'); DC(1, 9.5, 2.2, -10, 1.5, 1.5, '-z');
    mach(12, -10, 17, -2, { h: 5.6, f: ['-z', '-x'], along: 'z', tint: CREAM, noWin: false });
    // канал: каменные стенки, вода, мост; вода непроходима, но простреливается
    a.ground.push({ kind: 'pond', x: -2, z: -4, w: 28, d: 4 });
    for (const [x0, x1] of [[-16, -2.3], [2.3, 12]]) B(x0, -6, x1, -2, 1.3, 'none', 0, { hidden: true, nr: true });
    for (const zz of [-6.12, -1.88]) D(box(28, 0.12, 0.24, -2, 0.1, zz, STONE_D));
    // мост: каменный настил и перила (низкое укрытие)
    B(-2.4, -6.4, -2, -1.6, 0.9, 'stonewall'); B(2, -6.4, 2.4, -1.6, 0.9, 'stonewall');
    B(-2, -6.2, 2, -1.8, 0.06, 'stonewall', 0, { solid: false });
    for (const x of [-2.2, 2.2]) for (const z of [-6.4, -1.6]) D(box(0.5, 1.25, 0.5, x, 0.62, z, '#9a958b'), box(0.6, 0.1, 0.6, x, 1.28, z, '#7d796f'), { sph: true, r: 0.13, x, y: 1.42, z, sy: 1.4, color: '#7d796f', seg: 6 });
    D(box(0.5, 0.08, 4.8, -2.2, 0.93, -4, '#7d796f'), box(0.5, 0.08, 4.8, 2.2, 0.93, -4, '#7d796f'));
    // площадь: низкий каменный парапет вдоль канала, автоматы, велосипеды, доска объявлений
    B(-8, -2, -2.4, -1.65, 0.75, 'stonewall'); B(2.4, -2, 8, -1.65, 0.75, 'stonewall');
    floor(-8, -1.65, 8, 10, 'stonewall', '#d8d2c6');
    vend(7.55, 6.6, '-x'); vend(7.55, 7.55, '-x', '#c8302a'); vend(7.55, 8.5, '-x', '#2f6fae');
    bike(-7.5, 5.6, 1, '#2f6fae'); bike(-7.5, 6.6, 1, '#b8352a'); bike(-7.5, 7.6, 1, '#e8e2d2'); hid(-7.9, 4.9, -7.0, 8.3, 1.0);
    // доска объявлений под крышей: закрывает прострел от моста к улице спецназа
    B(0.8, 7.2, 5.0, 7.55, 2.1, 'planks');
    for (const x of [0.9, 4.9]) D(cyl(0.09, 2.7, x, 1.35, 7.37, TIM, 0, 0, 0, 6));
    a.roof(0.6, 7.0, 5.2, 7.75, 2.65, 0.35, 0.25, { col: TILE2, along: 'x' });
    for (let i = 0; i < 8; i++) { const x = 1.2 + i * 0.47 + R(-0.05, 0.05), y = R(1.0, 1.8); D(box(0.34, 0.44, 0.012, x, y, 7.16, ['#f4f1ea', '#f2d8a0', '#e8e2d2', '#ffd0d8'][i % 4]), box(0.34, 0.44, 0.012, x, y, 7.59, ['#f4f1ea', '#e8e2d2', '#f2d8a0'][i % 3])); }
    // сакура у канала: ветви над водой
    B(-7.2, -0.8, -5.0, 1.4, 0.5, 'stonewall'); tree(-6.1, 0.3, 5.8, 1.0);
    tree(6.4, -0.6, 5.4, 0.9, { solid: true });
    a.toro(-3.2, 9.1, 0.85);
    // святилище хокора у моста: ломает прострел из переулка на мост
    a.hokora(-2.0, -9.6, false);
    const pM = [pole(-7.5, -1.2, 8.2), pole(7.4, 9.5, 8.2)]; wires(pM[0], pM[1], 0.8); wire([pM[0][0], pM[0][1] - 0.85, pM[0][2]], [-8, 5.2, 4], 0.4);
    garland([-8, 4.0, 9.6], [8, 4.0, -1.8], 7, 0.6);

    // ===================== апартаменты (сквозной проход площадь → двор храма) =====================
    // двухэтажный дом с квартирами: вход с площади, коридор, комнаты с татами, холл с почтовыми ящиками, выход к храму
    {
      const x0 = -24, x1 = -8, z0 = -2, z1 = 8, hh = 6.2, T = 0.3, CT = 3.0, AP = CREAM;
      W(x0, z0, x1, z0 + T, hh, AP); // юг (к каналу)
      W(x0, z1 - T, -22.2, z1, hh, AP); W(-19.8, z1 - T, x1, z1, hh, AP); lintel(-22.2, z1 - T, -19.8, z1, 2.35, hh, AP); // север, выход к храму
      W(x0, z0 + T, x0 + T, z1 - T, hh, AP); // запад
      W(x1 - T, z0 + T, x1, 2.0, hh, AP); W(x1 - T, 4.4, x1, z1 - T, hh, AP); lintel(x1 - T, 2.0, x1, 4.4, 2.4, hh, AP); // восток, вход
      B(x0 + T, z0 + T, x1 - T, z1 - T, 0.22, 'planks', CT, { tint: '#e2c9a6' }); // деревянный потолок
      // перегородки коридора (z 2.0..4.4)
      const IW = '#ecd9b8';
      W(x0 + T, 1.8, -20.4, 2.0, CT, IW); W(-18.6, 1.8, -12.4, 2.0, CT, IW); W(-10.6, 1.8, x1 - T, 2.0, CT, IW);
      lintel(-20.4, 1.8, -18.6, 2.0, 2.2, CT, IW); lintel(-12.4, 1.8, -10.6, 2.0, 2.2, CT, IW);
      W(-16.1, z0 + T, -15.9, 1.8, CT, IW); // между южными комнатами
      W(x0 + T, 4.4, -22.2, 4.6, CT, IW); W(-19.8, 4.4, -13.4, 4.6, CT, IW); W(-11.6, 4.4, x1 - T, 4.6, CT, IW);
      lintel(-22.2, 4.4, -19.8, 4.6, 2.2, CT, IW); lintel(-13.4, 4.4, -11.6, 4.6, 2.2, CT, IW);
      W(-18.0, 4.6, -17.8, z1 - T, CT, IW); // холл | кухня
      for (const zz of [1.98, 4.42]) { const s2 = zz < 3 ? 1 : -1; D(box(15.4, 0.1, 0.05, -16, 2.2, zz + s2 * 0.03, TIM_L), box(15.4, 0.14, 0.05, -16, 0.07, zz + s2 * 0.03, TIM_D)); for (const x of [-23.6, -20.5, -18.5, -16, -12.5, -10.5, -8.4]) D(box(0.12, CT, 0.06, x, CT / 2, zz + s2 * 0.04, TIM_L)); }
      // полы: коридор и холл — доски, комнаты — татами
      floor(x0 + T, 2.0, x1 - T, 4.4, 'planks'); floor(x0 + T, 4.6, -18.0, z1 - T, 'planks'); floor(-17.8, 4.6, x1 - T, z1 - T, 'planks', '#d9c7a6');
      floor(x0 + T, z0 + T, -16.1, 1.8, 'tatami'); floor(-15.9, z0 + T, x1 - T, 1.8, 'tatami');
      // наружные балки, окна, двери квартир второго этажа, галерея с перилами над каналом
      for (const [yy, hb] of [[CT + 0.1, 0.22], [hh - 0.1, 0.18]]) { D(box(16.12, hb, 0.12, -16, yy, z0 - 0.06, TIM), box(16.12, hb, 0.12, -16, yy, z1 + 0.06, TIM), box(0.12, hb, 10.12, x1 + 0.06, yy, 3, TIM)); }
      for (const x of [-21, -13]) DC(1, x, 1.6, z0, 1.6, 1.5, '-z');
      for (let i = 0; i < 4; i++) { const x = -22 + i * 4; DC(4, x, CT + 1.25, z0, 0.95, 2.1, '-z'); DC(1, x + 1.7, CT + 1.5, z0, 1.1, 1.1, '-z'); }
      D(box(16.4, 0.14, 1.3, -16, CT + 0.12, z0 - 0.65, '#bdb6aa'), box(16.4, 0.06, 0.06, -16, CT + 1.15, z0 - 1.27, '#d8d4cc'));
      for (let i = 0; i <= 16; i++) D(box(0.05, 1.0, 0.05, x0 - 0.1 + i * 1.0125, CT + 0.66, z0 - 1.27, '#d8d4cc'));
      for (let i = 0; i < 3; i++) { const x = -21.3 + i * 4.6; H(box(0.7, 0.5, 0.36, x, CT + 0.45, z0 - 0.5, '#e6e4de'), cyl(0.15, 0.04, x, CT + 0.45, z0 - 0.69, '#4a4c50', HP, 0, 0, 8)); }
      // бельё на галерее
      H(box(9, 0.03, 0.03, -16, CT + 2.25, z0 - 1.1, '#5a5a5a'));
      for (let i = 0; i < 6; i++) H(box(0.5, 0.62 - (i % 2) * 0.18, 0.03, -19.6 + i * 1.4, CT + 1.9, z0 - 1.1, ['#ffffff', '#7fa8d8', '#f2c94c', '#e88aa0', '#ffffff', '#9ac48a'][i]));
      // восточный фасад (на площадь): козырёк над входом, табличка, окна, наружная лестница
      a.roof(x1 - 0.1, 1.6, x1 + 1.0, 4.8, 2.75, 0.22, 0.12, { col: TILE2, along: 'z' });
      D(box(0.06, 0.5, 1.6, x1 + 0.04, 2.66, 0.6, '#f4f1ea'), box(0.04, 0.3, 1.3, x1 + 0.07, 2.66, 0.6, '#2a5a9a'));
      DC(1, x1, CT + 1.5, 0, 1.4, 1.4, '+x'); DC(1, x1, CT + 1.5, 6.2, 1.4, 1.4, '+x'); DC(0, x1, 1.6, 6.3, 1.5, 1.4, '+x'); DC(1, x1, 1.6, -0.2, 1.3, 1.3, '+x');
      // северный фасад (к храму): окна, дверь выхода, ящики-цветники
      DC(1, -15, 1.6, z1, 1.5, 1.4, '+z'); DC(1, -11, 1.6, z1, 1.5, 1.4, '+z');
      for (const x of [-22.5, -18, -13.5, -9.5]) DC(1, x, CT + 1.6, z1, 1.4, 1.4, '+z');
      a.roof(-22.6, z1 - 0.1, -19.4, z1 + 0.9, 2.7, 0.2, 0.12, { col: TILE2, along: 'x' });
      a.roof(x0, z0, x1, z1, hh, 1.6, 0.7, { col: TILE2, along: 'x', gable: AP });
      // внутри: генкан с полкой для обуви, почтовые ящики, комнаты с низкими столиками, подушками, лампами, фусума
      step(x1 - 1.3, 2.05, x1 - 0.32, 4.35);
      hid(-11, 4.05, -9.2, 4.4, 1.1); D(box(1.8, 1.05, 0.35, -10.1, 0.53, 4.22, TIM_L), box(1.82, 0.04, 0.37, -10.1, 1.07, 4.22, TIM_D));
      D(box(0.35, 1.1, 1.8, -23.52, 1.45, 6.0, '#a8aeb2'));
      for (let r = 0; r < 3; r++) for (let k = 0; k < 4; k++) D(box(0.02, 0.28, 0.36, -23.33, 1.12 + r * 0.33, 5.37 + k * 0.42, '#d6dadc'));
      const room = (cx, cz, n) => {
        hid(cx - 0.55, cz - 0.4, cx + 0.55, cz + 0.4, 0.4);
        D(box(1.1, 0.06, 0.8, cx, 0.36, cz, '#5a3a24'), box(0.08, 0.32, 0.08, cx - 0.48, 0.17, cz - 0.33, TIM_D), box(0.08, 0.32, 0.08, cx + 0.48, 0.17, cz - 0.33, TIM_D), box(0.08, 0.32, 0.08, cx - 0.48, 0.17, cz + 0.33, TIM_D), box(0.08, 0.32, 0.08, cx + 0.48, 0.17, cz + 0.33, TIM_D));
        for (const [ox, oz] of [[-0.9, 0], [0.9, 0], [0, 0.7]]) D(box(0.55, 0.1, 0.55, cx + ox, 0.07, cz + oz, ['#8a2a2a', '#23326a', '#6a5a2a'][(R(0, 3) | 0)]));
        H(cyl(0.05, 0.08, cx - 0.2, 0.43, cz, '#e8e0d0', 0, 0, 0, 6), cyl(0.18, 0.04, cx + 0.15, 0.41, cz + 0.1, '#2a1c14', 0, 0, 0, 8), { sph: true, r: 0.06, x: cx + 0.15, y: 0.45, z: cz + 0.1, color: '#e8a040', seg: 5 });
        // напольный фонарь андон
        const lx = cx + (n ? 1.9 : -1.9), lz = cz - 0.6;
        D(box(0.32, 0.62, 0.32, lx, 0.33, lz, '#fbecc8'), box(0.38, 0.05, 0.38, lx, 0.66, lz, TIM_D), box(0.38, 0.05, 0.38, lx, 0.03, lz, TIM_D));
        a.lamps.push([lx, 0.4, lz, 0.55]);
      };
      room(-21.6, -0.3, 1); room(-13.6, -0.3, 1); room(-15.0, 6.6, 1);
      // фусума и сёдзи на перегородках, свиток в нише токонома
      for (const x of [-22.4, -14.4, -9.4]) DC(7, x, 1.3, 1.8, 1.7, 2.3, '-z');
      for (const x of [-22.4, -16.6, -14.6, -9.6]) DC(1, x, 1.3, 2.0, 1.4, 2.3, '+z');
      for (const x of [-16.2, -10.2]) DC(7, x, 1.3, 4.4, 1.6, 2.3, '-z');
      DC(1, -23.1, 1.3, 4.6, 1.0, 2.3, '+z');
      D(box(0.04, 1.2, 0.5, -23.66, 1.5, -0.6, '#efe6d0'), box(0.03, 1.05, 0.38, -23.64, 1.5, -0.6, '#f6f2e6'));
      H(box(0.02, 0.5, 0.18, -23.63, 1.7, -0.6, '#3a5a3a'));
      // потолочные бумажные лампы в коридоре
      for (const x of [-21, -15.5, -10.5]) { D(cyl(0.2, 0.3, x, CT - 0.42, 3.2, '#fbecc8', 0, 0, 0, 8), cyl(0.012, 0.25, x, CT - 0.13, 3.2, '#1a1a1a', 0, 0, 0, 4)); a.lamps.push([x, CT - 0.45, 3.2, 0.7]); }
    }

    // ===================== идзакая-раменная (сквозной проход площадь → рынок) =====================
    {
      const x0 = 8, x1 = 20, z0 = -2, z1 = 10, hh = 5.7, T = 0.3, CT = 3.1, IZ = WHITE;
      W(x0, z0, x1, z0 + T, hh, IZ); W(x0, z1 - T, x1, z1, hh, IZ);
      W(x0, z0 + T, x0 + T, 3.0, CT - 0.35, IZ); W(x0, 5.0, x0 + T, z1 - T, CT - 0.35, IZ); lintel(x0, 3.0, x0 + T, 5.0, 2.35, CT - 0.35, IZ);
      B(x0, z0, x0 + T, z1, 0.4, 'koshi', CT - 0.35); W(x0, z0, x0 + T, z1, hh - CT - 0.05, IZ, CT + 0.05);
      W(x1 - T, z0 + T, x1, 5.0, hh, IZ); W(x1 - T, 7.0, x1, z1 - T, hh, IZ); lintel(x1 - T, 5.0, x1, 7.0, 2.35, hh, IZ);
      B(x0 + T, z0 + T, x1 - T, z1 - T, 0.22, 'planks', CT, { tint: '#d9b88c' });
      floor(x0 + T, z0 + T, x1 - T, z1 - T, 'planks', '#cdb08a');
      // западный фасад: тёмная решётка и красные фонари, норэн над входом
      D(box(0.1, 0.24, 12.1, x0 - 0.05, CT - 0.25, 4, TIM), box(0.1, 0.18, 12.1, x0 - 0.05, hh - 0.1, 4, TIM));
      for (const z of [z0, 1, 3, 5, 7, z1]) D(box(0.12, CT - 0.4, 0.15, x0 - 0.05, (CT - 0.4) / 2, z, TIM_D));
      DC(0, x0, 1.5, 0.6, 1.7, 1.4, '-x'); DC(0, x0, 1.5, 7.6, 1.7, 1.4, '-x'); DC(6, x0, 1.6, 5.75, 0.62, 1.4, '-x'); DC(6, x0, 1.6, 2.25, 0.62, 1.4, '-x');
      for (let j = 0; j < 4; j++) D(box(0.03, 0.82, 0.46, x0 - 0.12, 1.98, 3.3 + j * 0.47, '#a8261c'));
      D(box(0.05, 0.05, 2.1, x0 - 0.13, 2.42, 4, TIM_D));
      lan(x0 - 0.6, 2.25, 2.55, '#d63a26', 2.75); lan(x0 - 0.6, 2.25, 5.45, '#d63a26', 2.75);
      a.roof(x0 - 1.1, z0, x0 + 0.1, z1, CT - 0.2, 0.35, 0.15, { col: TILE2, along: 'z' });
      for (const z of [0, 4, 8]) DC(1, x0, CT + 1.25, z, 1.4, 1.3, '-x');
      // восточный фасад (на рынок): норэн, вывеска, окна
      for (let j = 0; j < 4; j++) D(box(0.03, 0.82, 0.46, x1 + 0.12, 1.98, 5.3 + j * 0.47, '#23326a'));
      D(box(0.05, 0.05, 2.1, x1 + 0.13, 2.42, 6, TIM_D)); DC(6, x1, 1.6, 7.7, 0.62, 1.4, '+x'); DC(1, x1, 1.6, 1.5, 1.4, 1.3, '+x');
      for (const z of [0, 4, 8]) DC(0, x1, CT + 1.35, z, 1.4, 1.3, '+x');
      D(box(12.1, 0.2, 0.12, 14, CT + 0.05, z0 - 0.06, TIM), box(12.1, 0.2, 0.12, 14, CT + 0.05, z1 + 0.06, TIM), box(0.12, 0.2, 12.1, x1 + 0.06, CT + 0.05, 4, TIM));
      for (const x of [10, 14, 18]) DC(1, x, CT + 1.3, z0, 1.4, 1.3, '-z');
      a.roof(x0, z0, x1, z1, hh, 1.8, 0.75, { col: TILE, along: 'x', gable: IZ });
      for (const zz of [z0 + T, z1 - T]) { const s2 = zz < 4 ? 1 : -1; D(box(11.4, 0.12, 0.05, 14, 2.1, zz + s2 * 0.03, TIM_L)); for (const x of [8.4, 11, 14, 17, 19.6]) D(box(0.14, CT, 0.06, x, CT / 2, zz + s2 * 0.04, TIM_L)); }
      D(box(11.4, 0.6, 0.04, 14, 0.3, z0 + T + 0.02, '#6a4a2e'));
      // стойка буквой Г, табуреты, кухня за стойкой
      B(10, 6.2, 17, 6.8, 1.05, 'planks'); B(16.4, 6.8, 17, z1 - T, 1.05, 'planks');
      D(box(7.2, 0.06, 0.8, 13.5, 1.08, 6.5, '#8a6440'), box(0.8, 0.06, 2.95, 16.7, 1.08, 8.3, '#8a6440'));
      for (let i = 0; i < 6; i++) { const x = 10.6 + i * 1.1; D(cyl(0.18, 0.06, x, 0.7, 5.75, '#7a2626', 0, 0, 0, 8), cyl(0.04, 0.68, x, 0.34, 5.75, IRON, 0, 0, 0, 5)); }
      hid(9.4, z1 - 0.95, 15.8, z1 - 0.3, 0.95); D(box(6.4, 0.9, 0.6, 12.6, 0.45, z1 - 0.62, '#9aa0a4'), box(6.4, 0.04, 0.62, 12.6, 0.92, z1 - 0.62, '#c4c8cc'));
      for (const x of [10.6, 12.2, 13.8]) D(cyl(0.26, 0.42, x, 1.15, z1 - 0.62, '#b8bcc0', 0, 0, 0, 10), cyl(0.27, 0.03, x, 1.37, z1 - 0.62, '#6a6e72', 0, 0, 0, 10));
      H({ sph: true, r: 0.3, x: 12.2, y: 1.7, z: z1 - 0.62, sy: 1.6, color: '#f4f2ee', seg: 6 });
      D(box(5.6, 0.04, 0.3, 12.6, 1.95, z1 - 0.46, TIM_L), box(5.6, 0.04, 0.3, 12.6, 2.4, z1 - 0.46, TIM_L));
      for (let i = 0; i < 12; i++) { const x = 10.1 + i * 0.42; D(cyl(0.05, 0.3, x, 2.12, z1 - 0.46, ['#2f5a3a', '#6a2a1a', '#f2ece0', '#3a3a6a'][i % 4], 0, 0, 0, 6)); if (i % 3 === 0) H(cyl(0.04, 0.26, x + 0.2, 2.55, z1 - 0.46, '#e8e0d0', 0, 0, 0, 6)); }
      for (const x of [11, 15]) DC(6, x, 2.3, 6.8, 0.5, 1.1, '-z');
      for (const x of [9.6, 11.2, 12.8, 14.4, 16]) H(box(0.42, 0.3, 0.02, x + 0.5, 2.55, 6.52, ['#f4ecd8', '#f2d8a0'][x % 2 | 0]));
      // столы с табуретами
      for (const [tx, tz] of [[11, 0.9], [15.2, 0.9]]) {
        hid(tx - 0.9, tz - 0.55, tx + 0.9, tz + 0.55, 0.78);
        D(box(1.8, 0.07, 1.1, tx, 0.75, tz, '#6a4a2e'), box(1.6, 0.7, 0.08, tx, 0.36, tz, TIM_D));
        for (const sx of [-0.55, 0.55]) for (const sz of [-0.85, 0.85]) D(cyl(0.17, 0.45, tx + sx, 0.23, tz + sz, '#5a3a24', 0, 0, 0, 7));
        H(cyl(0.16, 0.08, tx - 0.3, 0.82, tz, '#e8e2d4', 0, 0, 0, 10), cyl(0.16, 0.08, tx + 0.35, 0.82, tz + 0.15, '#c8402a', 0, 0, 0, 10), box(0.02, 0.02, 0.24, tx - 0.25, 0.86, tz, '#c9a26a'));
      }
      // красные фонари над стойкой
      for (const x of [11, 13.5, 16]) lan(x, 2.45, 5.2, '#d63a26', CT);
      // кадка с рисом и ящики пива у восточного входа
      taru(18.9, 1.6, 0.9); stack(18.8, -1.0, 0.9);
      DC(2, 17.8, 1.6, 9.7, 0.62, 1.3, '-z');
    }

    // ===================== восток: блоки у длинной B =====================
    mach(17, -24, 25, -17, { h: 5.8, f: ['-z', '+z'], along: 'x', tint: CREAM }); shop('-z', 21, -24, { sign: 6, red: true }); DC(3, 21, 1.32, -17, 1.9, 2.4, '+z');
    mach(25, -24, 33, -17, { h: 5.4, f: ['-z', '+z', '+x'], along: 'x' }); shop('-z', 29, -24, { noren: '#2f4a3a' }); shop('+x', 33, -20.5, { sign: false, noren: '#7a2626' });
    mach(17, -14, 25, -2, { h: 6.0, f: ['-z', '-x'], along: 'z', tint: OCHRE }); shop('-z', 21, -14, { noren: '#23326a' }); DC(3, 17, 1.32, -12, 1.9, 2.4, '-x');
    mach(25, -14, 33, -2, { h: 5.6, f: ['-z', '+x'], along: 'z' }); shop('+x', 33, -8.5, { noren: '#23326a' }); shop('-z', 29.5, -14, { sign: 6, red: true });
    mach(20, -2, 33, 4, { h: 5.0, f: ['+z', '+x'], one: true, along: 'x', tint: CREAM }); DC(3, 31, 1.32, 4, 1.9, 2.4, '+z'); DC(1, 25, 2.0, 4, 1.4, 1.3, '+z'); DC(1, 28, 2.0, 4, 1.4, 1.3, '+z');
    // восточный соединитель: телега, ящики
    crate(15.6, -11.6, 1.0); taru(30.8, -16.4); taru(31.6, -16.4, 0.9); stack(25.6, -16.4, 1.0);
    vend(16.55, -15.3, '-x', '#2f6fae');
    // длинная B: святилище хокора в нише, бочки сакэ, ящики, столбы
    a.hokora(36.6, -6.5, true); taru(34, -27.8, 1); taru(34, -27.0, 0.9); taru(34.7, -27.4, 1.05);
    stack(37.0, 0.6, 1.2); crate(34.0, -11.5, 1.0); bike(37.6, -21, 1, '#e8e2d2'); bike(37.6, -20, 1, '#2f6fae'); hid(37.3, -21.8, 38, -19.2, 1.0);
    a.cart(35.6, -1.8, HP);
    const pB = [pole(37.6, -26, 8.4, 1), pole(37.6, -12, 8.4, 1), pole(37.6, 3, 8.2, 1)];
    wires(pB[0], pB[1]); wires(pB[1], pB[2]);
    garland([33, 4.8, -20.5], [38, 4.8, -20.5], 4, 0.4);

    // ===================== точка B: крытый рынок =====================
    floor(20, 4, 38, 26, 'stonewall', '#cfc8ba');
    {
      const RX0 = 24, RX1 = 34, RZ0 = 6, RZ1 = 24, RY = 4.3;
      for (const x of [RX0, RX1]) for (const z of [6, 10.5, 15, 19.5, 24]) { D(cyl(0.14, RY, x, RY / 2, z, TIM, 0, 0, 0, 8)); hid(x - 0.2, z - 0.2, x + 0.2, z + 0.2, RY); }
      for (const x of [RX0, RX1]) D(box(0.2, 0.3, RZ1 - RZ0 + 0.4, x, RY - 0.1, (RZ0 + RZ1) / 2, TIM_D));
      for (const z of [6, 10.5, 15, 19.5, 24]) D(box(RX1 - RX0 + 0.3, 0.22, 0.18, (RX0 + RX1) / 2, RY - 0.05, z, TIM_D));
      a.roof(RX0, RZ0, RX1, RZ1, RY + 0.1, 1.5, 0.6, { col: '#d8dde4', along: 'z' });
      // гирлянды бумажных фонарей вдоль торговой улицы
      for (const z of [8.2, 12.7, 17.2, 21.7]) garland([RX0, RY - 0.2, z], [RX1, RY - 0.2, z], 5, 0.45, ['#f3e2b8', '#d63a26']);
      // вывески над входами рынка
      for (const z of [RZ0 - 0.05, RZ1 + 0.05]) { D(box(5.2, 0.9, 0.12, 29, RY + 0.35, z, TIM_D), box(4.9, 0.7, 0.14, 29, RY + 0.35, z, '#c63b22')); for (let i = 0; i < 4; i++) D(box(0.5, 0.5, 0.16, 27.4 + i * 1.07, RY + 0.35, z, '#f6eedb')); }
    }
    // лавки-ятай: прилавок (укрытие), стойки, навес, товары
    const stall = (x0, z0, x1, z1, n, col, goods) => {
      B(x0, z0, x1, z1, 1.0, 'planks');
      const ax = n === '+z' || n === '-z', s = NN[n][0] + NN[n][1];
      D(box(x1 - x0 + 0.1, 0.05, z1 - z0 + 0.1, (x0 + x1) / 2, 1.03, (z0 + z1) / 2, '#8a6440'));
      const bx = n === '+x' ? x0 + 0.1 : n === '-x' ? x1 - 0.1 : null, bz = n === '+z' ? z0 + 0.1 : n === '-z' ? z1 - 0.1 : null;
      const ends = ax ? [[x0 + 0.1, bz], [x1 - 0.1, bz]] : [[bx, z0 + 0.1], [bx, z1 - 0.1]];
      for (const [px, pz] of ends) D(cyl(0.06, 2.6, px, 1.3, pz, TIM, 0, 0, 0, 6));
      // наклонный навес из ткани
      const cx = (x0 + x1) / 2 + (ax ? 0 : s * 0.25), cz = (z0 + z1) / 2 + (ax ? s * 0.25 : 0);
      D(box(ax ? x1 - x0 + 0.5 : (x1 - x0) + 0.9, 0.05, ax ? (z1 - z0) + 0.9 : z1 - z0 + 0.5, cx, 2.45, cz, col, ax ? -s * 0.25 : 0, 0, ax ? 0 : s * 0.25));
      for (let i = 0; i < 4; i++) { const t = (i + 0.5) / 4; const px = ax ? x0 + (x1 - x0) * t : (n === '+x' ? x1 + 0.42 : x0 - 0.42), pz = ax ? (n === '+z' ? z1 + 0.42 : z0 - 0.42) : z0 + (z1 - z0) * t; D(box(ax ? (x1 - x0) / 4 - 0.04 : 0.03, 0.34, ax ? 0.03 : (z1 - z0) / 4 - 0.04, px, 2.12, pz, i % 2 ? col : '#f4ecd8')); }
      const gc = goods || ['#e8452a', '#f2a03a', '#7aa04a', '#e9e3d0', '#c8321e'];
      const k = Math.max(3, Math.round((ax ? x1 - x0 : z1 - z0) / 0.55));
      for (let i = 0; i < k; i++) {
        const t = (i + 0.5) / k, px = ax ? x0 + (x1 - x0) * t : (x0 + x1) / 2, pz = ax ? (z0 + z1) / 2 : z0 + (z1 - z0) * t;
        D(box(0.42, 0.12, 0.42, px, 1.12, pz, '#b8945e'));
        for (let j = 0; j < 3; j++) H({ sph: true, r: 0.075, x: px + R(-0.12, 0.12), y: 1.24, z: pz + R(-0.12, 0.12), color: gc[(i + j) % gc.length], seg: 5 });
        L2.push({ w: 0.36, h: 0.07, d: 0.36, x: px, y: 1.21, z: pz, color: gc[i % gc.length] });
      }
    };
    const L2 = [];
    stall(24.6, 8.2, 26.8, 10.6, '+x', '#23326a'); stall(24.6, 15.8, 26.8, 18.2, '+x', '#7a2626', ['#f6eedb', '#ffd0d8', '#9ac48a']);
    stall(31.2, 11.6, 33.4, 14.0, '-x', '#2f4a3a', ['#d8a040', '#c8902a', '#f2ece0']); stall(31.2, 19.4, 33.4, 21.8, '-x', '#c63b22', ['#3a5a8a', '#e8e2d2', '#c8321e']);
    a.lo.push(...L2);
    // ящики, бочки, тележка; амбар-кура и лавки на севере
    stack(21.0, 12.0, 1.2); crate(22.0, 20.6, 1.1); taru(36.5, 8.4); taru(36.5, 9.2, 0.9); taru(37.2, 8.8);
    stack(36.4, 16.2, 1.2); crate(36.6, 17.6, 1.0); crate(29.0, 24.9, 1.0);
    vend(20.45, 16.6, '+x', '#c8302a'); vend(20.45, 17.55, '+x');
    B(26, 26, 38, 34, 1.3, 'stonewall'); W(26, 26, 38, 34, 4.6, WHITE, 1.3); a.roof(26, 26, 38, 34, 5.9, 2.2, 0.7, { col: TILE, along: 'x', gable: WHITE });
    D(box(12.12, 0.16, 0.12, 32, 5.7, 25.94, TIM_D), box(1.6, 1.6, 0.08, 32, 4.2, 25.96, TIM_D), box(1.3, 1.3, 0.1, 32, 4.2, 25.95, '#f2ece0'), box(0.5, 0.5, 0.12, 32, 4.2, 25.93, '#c63b22'));
    DC(3, 29, 1.32, 26, 1.9, 2.4, '-z'); DC(3, 35.5, 1.32, 26, 1.9, 2.4, '-z');
    // восточные лавки рынка (фасады на запад)
    shop('-x', 38, 9, { noren: '#23326a', red: true }); shop('-x', 38, 15.5, { sign: 6 }); shop('-x', 38, 21.5, { noren: '#2f4a3a' });
    a.letter('B', 29, 15, 4.2);

    // ===================== северо-восток: квартал спецназа =====================
    // амбар и дом между улицей спецназа и рынком
    B(6, 10, 13, 24, 1.3, 'stonewall'); W(6, 10, 13, 24, 4.3, WHITE, 1.3); a.roof(6, 10, 13, 24, 5.6, 2.0, 0.7, { col: TILE, along: 'z', gable: WHITE });
    D(box(0.08, 1.4, 1.4, 5.96, 4.0, 17, TIM_D), box(0.1, 1.1, 1.1, 5.95, 4.0, 17, '#f2ece0'));
    mach(13, 10, 20, 24, { h: 5.8, f: ['+x', '+z'], along: 'z', tint: CREAM }); shop('+x', 20, 12.5, { noren: '#7a2626' }); DC(3, 20, 1.32, 21, 1.9, 2.4, '+x');
    mach(12, 29, 26, 34, { h: 5.4, f: ['-z', '+x'], along: 'x' }); shop('-z', 16, 29, { noren: '#2f4a3a' }); shop('-z', 22.5, 29, { sign: 6, red: true });
    pot(19.4, 28.4); pot(12.6, 28.4, 1.1); taru(25.4, 27.2);

    // ===================== север: спавн спецназа у бани =====================
    // баня сэнто: высокий фасад с вальмовой крышей, вход с норэн «ゆ», кирпичная труба
    W(-8, 10, 2, 24, 6.8, CREAM); B(-8, 10, 2, 24, 0.4, 'stonewall', 0, { solid: false });
    a.roof(-8, 10, 2, 24, 6.8, 2.6, 0.8, { col: TILE, along: 'z', hip: true });
    a.roof(-6.4, 23.9, 0.4, 25.2, 3.1, 0.5, 0.3, { col: TILE2, along: 'x' });
    for (let j = 0; j < 4; j++) D(box(0.48, 0.9, 0.03, -4.4 + j * 0.53, 2.1, 24.16, j % 2 ? '#7a2626' : '#23326a'));
    DC(3, -3, 1.32, 24, 2.2, 2.6, '+z'); DC(1, 0.4, 4.2, 24, 1.4, 1.3, '+z'); DC(1, -6.2, 4.2, 24, 1.4, 1.3, '+z');
    // вывеска бани: герб-ромб на светлой доске
    D(box(1.1, 1.1, 0.08, -3, 4.6, 24.06, TIM_D), box(0.9, 0.9, 0.1, -3, 4.6, 24.06, '#f6eedb'), box(0.5, 0.5, 0.12, -3, 4.6, 24.1, '#c63b22', 0, 0, Math.PI / 4), box(0.24, 0.24, 0.14, -3, 4.6, 24.1, '#f6eedb', 0, 0, Math.PI / 4));
    D(box(1.6, 11.5, 1.6, -5.5, 5.75, 12.5, '#a0523a'), box(1.8, 0.3, 1.8, -5.5, 11.6, 12.5, '#6d3426'), box(1.7, 0.18, 1.7, -5.5, 9.2, 12.5, '#6d3426'));
    for (const x of [-8, 2]) DC(0, x, 4.0, 18, 1.5, 1.4, x < 0 ? '-x' : '+x');
    lan(-5.2, 2.3, 24.7, '#f3e2b8', 3.0); lan(-0.8, 2.3, 24.7, '#f3e2b8', 3.0);
    // дом и сад к западу от бани
    mach(-18, 8, -8, 23, { h: 5.6, f: ['-x', '+z', '-z'], along: 'z', tint: WHITE, wph: 1 }); DC(3, -14, 1.32, 23, 1.9, 2.4, '+z'); DC(1, -18, 1.6, 12.5, 1.4, 1.3, '-x'); DC(1, -18, 1.6, 18.5, 1.4, 1.3, '-x');
    // северный ряд за спавном
    mach(-12, 31, 0, 34, { h: 5.2, f: ['-z'], along: 'x', tint: CREAM }); shop('-z', -8, 31, { noren: '#23326a' }); DC(3, -3, 1.32, 31, 1.9, 2.4, '-z');
    mach(0, 31, 12, 34, { h: 5.6, f: ['-z'], along: 'x', wph: 1 }); shop('-z', 4, 31, { sign: 6, red: true }); shop('-z', 9, 31, { noren: '#2f4a3a', sign: false });
    mach(-19, 28, -12, 34, { h: 5.4, f: ['-z', '+x'], along: 'z', tint: OCHRE });
    // улица спецназа к центру: тоннель из красных ворот тории
    for (let i = 0; i < 6; i++) {
      const z = 12.2 + i * 2.1, h = 3.0;
      for (const x of [2.45, 5.55]) { D(cyl(0.12, h, x, h / 2, z, VER, 0, 0, 0, 8), cyl(0.15, 0.32, x, 0.16, z, TIM_D, 0, 0, 0, 8)); hid(x - 0.15, z - 0.15, x + 0.15, z + 0.15, h); }
      D(box(4.1, 0.16, 0.3, 4, h + 0.2, z, TIM_D), box(3.9, 0.15, 0.22, 4, h - 0.02, z, VER), box(3.4, 0.12, 0.16, 4, h - 0.45, z, VER));
    }
    // спавн: колодец, скамьи, кадки, столб с фонарём
    a.well(-9.6, 27.8); taru(10.6, 30.2); taru(11.3, 30.3, 0.9); pot(-11.4, 25.0); pot(11.3, 24.8, 1.1);
    for (const x of [-4, 4]) { hid(x - 0.9, 30.3, x + 0.9, 30.8, 0.48); D(box(1.8, 0.07, 0.42, x, 0.45, 30.55, TIM_L), box(0.08, 0.42, 0.4, x - 0.8, 0.21, 30.55, TIM_D), box(0.08, 0.42, 0.4, x + 0.8, 0.21, 30.55, TIM_D)); }
    tree(9.2, 26.4, 5.6, 0.95);
    const pN = [pole(-11.5, 30.6, 8.4), pole(11.6, 25.4, 8.4)]; wires(pN[0], pN[1], 0.9);

    // ===================== точка A: двор храма =====================
    floor(-38, 8, -18, 27, 'gravel'); floor(-26.6, 13.6, -22.6, 27, 'stonewall', '#d6d0c4');
    // главный зал хондо: каменная платформа, алые столбы, белые панели, крыша с медной черепицей
    B(-30, 27, -19, 34, 0.6, 'stonewall');
    W(-29.2, 28.4, -19.8, 34, 4.2, WHITE, 0.6);
    for (const x of [-29.4, -27, -24.6, -22.2, -19.8]) D(box(0.32, 4.6, 0.32, x, 2.9, 28.25, VER));
    D(box(9.9, 0.3, 0.34, -24.6, 4.95, 28.25, VER), box(9.9, 0.2, 0.36, -24.6, 2.1, 28.25, VER));
    for (const x of [-28.2, -25.8, -23.4, -21]) DC(1, x, 2.4, 28.4, 1.9, 2.6, '-z');
    D(box(10.6, 0.12, 1.3, -24.6, 0.64, 27.7, TIM_L));
    a.roof(-30.5, 27.2, -18.5, 34, 5.2, 3.2, 1.6, { col: COPPER, along: 'x', hip: true, ridgeCol: '#3d5a50' });
    // ящик для пожертвований, колокол со шнуром, верёвка симэнава
    B(-25.6, 26.4, -23.6, 27.2, 0.75, 'planks'); D(box(2.0, 0.08, 0.8, -24.6, 0.79, 26.8, TIM_D));
    for (let i = 0; i < 9; i++) D(box(0.08, 0.04, 0.78, -25.5 + i * 0.23, 0.84, 26.8, '#2a1c14'));
    D(cyl(0.11, 9.6, -24.6, 4.5, 28.0, '#d8c48a', 0, 0, HP, 8), { sph: true, r: 0.2, x: -24.6, y: 4.1, z: 27.95, color: '#c9a640', seg: 7 }, cyl(0.04, 2.6, -24.6, 2.8, 27.95, '#c63b22', 0, 0, 0, 5));
    for (let i = 0; i < 5; i++) D(box(0.22, 0.48, 0.02, -27.2 + i * 1.3, 4.1, 27.92, '#ffffff'));
    // пагода (северо-запад): пять ярусов, верхний шпиль сорин
    B(-38, 27, -31, 34, 0.6, 'stonewall');
    {
      let py = 0.6;
      for (let i = 0; i < 5; i++) {
        const s = 5.0 - i * 0.55, hh = i ? 1.9 : 2.6, cx = -34.5, cz = 30.5;
        B(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, hh, 'plaster', py, { tint: i ? WHITE : '#f0e6d8', solid: i === 0 });
        for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) D(box(0.24, hh, 0.24, cx + sx * (s / 2 - 0.04), py + hh / 2, cz + sz * (s / 2 - 0.04), VER));
        D(box(s + 0.1, 0.16, s + 0.1, cx, py + hh - 0.1, cz, VER));
        py += hh;
        a.roof(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, py, 1.0, 1.55 - i * 0.08, { hip: true, col: TILE2, finial: i === 4 ? 5.6 : 0 });
        py += 0.35;
      }
    }
    // стена между пагодой и залом
    W(-31, 27, -30, 34, 3.2, WHITE); W(-38, 33.2, -31, 34, 3.2, WHITE);
    // большие ворота-тории у входа с длинной A и малые у прохода спецназа
    a.torii(-35.5, 9.4, 4.6, 4.4, 0, VER);
    a.toro(-37.3, 11.3, 0.9); a.toro(-33.6, 11.3, 0.9);
    // пруд с карпами и каменной каймой (вода простреливается)
    a.ground.push({ kind: 'pond', x: -34.5, z: 19, w: 6.2, d: 6.4 });
    B(-37.6, 15.8, -31.4, 22.2, 1.3, 'none', 0, { hidden: true, nr: true });
    for (const [x0, z0, x1, z1] of [[-37.9, 15.5, -31.1, 15.8], [-37.9, 22.2, -31.1, 22.5], [-37.9, 15.8, -37.6, 22.2], [-31.4, 15.8, -31.1, 22.2]]) B(x0, z0, x1, z1, 0.32, 'stonewall');
    for (const [x, z] of [[-37.7, 15.6], [-31.3, 15.6], [-37.7, 22.4], [-31.3, 22.4]]) D({ sph: true, r: 0.42, x, y: 0.26, z, sy: 0.7, ry: R(0, 3), color: '#8a877f', seg: 7 });
    a.rock(-36.4, 21.0, 0.9);
    // павильон для омовения тёдзуя: каменная чаша (укрытие), крыша на четырёх столбах
    B(-29.6, 11.6, -27.4, 12.8, 0.85, 'stonewall'); D(box(2.0, 0.05, 1.0, -28.5, 0.88, 12.2, '#2a5a5e'));
    for (const [px, pz] of [[-30.1, 11.0], [-26.9, 11.0], [-30.1, 13.4], [-26.9, 13.4]]) { D(cyl(0.11, 2.7, px, 1.35, pz, VER, 0, 0, 0, 8)); hid(px - 0.14, pz - 0.14, px + 0.14, pz + 0.14, 2.7); }
    a.roof(-30.3, 10.8, -26.7, 13.6, 2.75, 0.9, 0.35, { col: COPPER, along: 'x', ridgeCol: '#3d5a50' });
    for (let i = 0; i < 3; i++) D(cyl(0.03, 0.4, -29.2 + i * 0.7, 1.0, 12.2, '#b8b56a', HP * 0.6, 0, 0, 5));
    // каменные фонари вдоль дороги к залу, комаину, стена эма, бочки сакэ
    for (const z of [15.5, 21.0]) { a.toro(-28.1, z, 1.05); a.toro(-20.9, z, 1.05); }
    for (const x of [-27.2, -22.0]) { hid(x - 0.45, 24.6, x + 0.45, 25.6, 1.6); D(box(0.9, 0.7, 1.0, x, 0.35, 25.1, '#8a867e'), { sph: true, r: 0.42, x, y: 1.0, z: 25.1, sx: 0.9, sy: 1.1, color: '#9a968c', seg: 7 }, { sph: true, r: 0.28, x, y: 1.5, z: 24.85, color: '#9a968c', seg: 6 }); }
    a.emaWall(-19.0, 18.0, 3.6, true);
    for (const [x, z, k] of [[-37.2, 25.6, 1], [-36.5, 25.6, 0.95], [-36.85, 26.2, 0.9], [-31.4, 9.0, 1], [-30.7, 9.0, 0.9]]) taru(x, z, k);
    stack(-24.0, 9.3, 1.2); crate(-36.6, 13.2, 1.1);
    // большая сакура во дворе — главный акцент точки
    B(-22.6, 11.9, -20.4, 14.1, 0.5, 'stonewall'); tree(-21.5, 13.0, 6.6, 1.15);
    tree(-30.2, 23.6, 5.8, 0.95);
    // флаги-нобори у зала
    for (const [x, col] of [[-29.6, VER], [-28.6, '#f6eedb'], [-20.6, '#f6eedb'], [-19.6, VER]]) D(cyl(0.04, 4.2, x, 2.1, 26.6, TIM, 0, 0, 0, 5), box(0.62, 2.6, 0.03, x + 0.3, 2.6, 26.6, col), box(0.62, 0.05, 0.05, x + 0.3, 3.92, 26.6, TIM));
    // проход спецназа: малые тории и фонари
    a.torii(-18.0, 25.0, 4.0, 3.5, HP, VER);
    lan(-16.6, 2.3, 22.8, '#f3e2b8'); lan(-13.6, 2.3, 22.8, '#f3e2b8');
    a.letter('A', -26.5, 18.2, 4.2);

    // ===================== за пределами (только высокое качество) =====================
    // крыши соседних кварталов, далёкие сакуры и холмы
    for (const [x0, z0, x1, z1, hh] of [[-60, -30, -48, -18, 6], [-58, -12, -47, 2, 5.4], [-60, 8, -48, 20, 6.2], [-56, 24, -46, 40, 5.6], [47, -32, 60, -20, 5.8], [48, -14, 58, 0, 6.4], [47, 6, 60, 18, 5.4], [48, 24, 58, 38, 6],
      [-30, -52, -16, -40, 5.8], [-10, -50, 6, -40, 6.2], [14, -52, 28, -40, 5.6], [-24, 40, -8, 52, 6], [6, 40, 22, 52, 5.8], [30, 40, 44, 54, 6.4]]) {
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, w = x1 - x0, d = z1 - z0, ax = w >= d;
      H(box(w, hh, d, cx, hh / 2, cz, R(0, 1) < 0.5 ? '#ebe4d6' : '#e2d8c4'), box(w, 1.6, d, cx, 1.0, cz, '#4a3526'));
      H({ shape: true, pts: [[-(ax ? d : w) / 2 - 0.6, 0], [0, 2.2], [(ax ? d : w) / 2 + 0.6, 0]], d: (ax ? w : d) + 1.2, x: cx, y: hh, z: cz, ry: ax ? 0 : HP, color: '#5d656e', cs: 1 });
    }
    for (const [x, z, r] of [[-50, 4, 3.2], [-52, -24, 3.6], [52, -6, 3.4], [50, 21, 3.0], [-4, 46, 3.6], [24, 44, 3.2], [-22, -46, 3.4], [8, -46, 3.0], [-38, 42, 3.6], [40, -42, 3.2]]) {
      H(cyl(0.3, 3, x, 1.5, z, '#3a2a20', 0, 0, 0, 6), { sph: true, r, x, y: 4.6, z, sx: 1.2, sy: 0.75, sz: 1.15, color: '#f6c8d6', seg: 8 }, { sph: true, r: r * 0.7, x: x + r * 0.6, y: 3.9, z: z - r * 0.3, sx: 1.1, sy: 0.75, color: '#fbdce6', seg: 7 });
    }
  }

  // ===================== «Полигон» (обучение) =====================
  function layoutRange(a) {
    const { B, crate, stack, lintel, barrel, lamp } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    B(-22, -18, 22, -17, 5, 'corrug'); B(-22, 17, 22, 18, 5, 'corrug'); B(-22, -17, -21, 17, 5, 'corrug'); B(21, -17, 22, 17, 5, 'corrug');
    for (const [x0, z0, x1, z1] of [[-22, -18, 22, -17], [-22, 17, 22, 18], [-22, -17, -21, 17], [21, -17, 22, 17]]) B(x0, z0, x1, z1, 0.9, 'hazard', 0, { solid: false });
    // полоса препятствий: коридор, барьер для прыжка, балка для приседа
    B(-5, -10.5, -4.5, 7, 2.6, 'concrete'); B(4.5, -10.5, 5, 7, 2.6, 'concrete');
    B(-4.5, -0.3, 4.5, 0.3, 0.9, 'hazard');
    lintel(-4.5, -5.5, 4.5, -4.5, 1.35, 2.6, 'metal');
    B(-5.2, -10.8, 5.2, 7.3, 0.3, 'roof', 2.6, { solid: false });
    B(-4.5, -10.5, 4.5, 7, 0.02, 'pave', 0, { solid: false });
    // стрельбище: дорожки и щиты за мишенями
    B(-9, -17, 9, -11, 0.02, 'pave', 0, { solid: false });
    for (const x of [-5, 0, 5]) { B(x - 1.3, -17, x + 1.3, -16.5, 2.4, 'planks'); B(x - 1.4, -17, x + 1.4, -16.4, 0.12, 'metal', 2.4); }
    B(-9.4, -16, -9, -11, 1.0, 'concrete'); B(9, -16, 9.4, -11, 1.0, 'concrete');
    a.sandbags(-6.5, -11.6, 3.2, 0, 2); a.sandbags(6.5, -11.6, 3.2, 0, 2);
    // яма для гранат: невысокая ограда, мишени внутри
    B(10, -14, 18, -13.6, 1.1, 'hazard'); B(10, -6.4, 18, -6, 1.1, 'hazard'); B(10, -14, 10.4, -6, 1.1, 'hazard'); B(17.6, -14, 18, -6, 1.1, 'hazard');
    B(10.4, -13.6, 17.6, -6.4, 0.02, 'sand', 0, { solid: false });
    a.tires(11.6, -12.6, 2); barrel(16.4, -7.4, '#8a2d22');
    // точка A
    B(-18, -14, -10, -6, 0.02, 'pave', 0, { solid: false });
    a.sandbags(-14, -5.2, 3, 0, 2); a.sandbags(-18.6, -10, 2.6, HP, 2);
    crate(-11, -13, 1.2); stack(-17, -13, 1.2);
    a.letter('A', -14, -10, 4.5);
    // двор у спавна: ящики, бочки, фонари, вышка
    crate(-9, 12, 1.2); stack(8, 13, 1.3); barrel(10, 10, '#2f5f8a'); barrel(10.7, 10.4, '#3b5f3a'); crate(-8, 4, 1.1); crate(12, 3, 1.2);
    a.tires(-16, 15, 3); a.tires(17, -2, 2);
    lamp(-8, -9, 6, HP); lamp(8, -9, 6, -HP); lamp(-16, 2, 6, 0); lamp(16, 8, 6, Math.PI);
    B(-20, 8, -16, 12, 3.2, 'contGreen'); B(16, -16, 20, -12, 2.6, 'contBlue');
    // смотровая вышка в юго-восточном углу
    for (const [x, z] of [[16, 14], [19.5, 14], [16, 16.5], [19.5, 16.5]]) a.D(cyl(0.12, 6, x, 3, z, '#4a4d50', 0, 0, 0, 8));
    a.D(box(4.3, 0.2, 3.3, 17.75, 6, 15.25, '#5a5d60'), box(4.3, 1.0, 0.1, 17.75, 6.6, 13.65, '#6a6d70'), box(0.1, 1.0, 3.3, 15.65, 6.6, 15.25, '#6a6d70'));
    B(15.6, 13.6, 19.9, 16.9, 7, 'none', 0, { hidden: true });
    detailRange(a);
  }
  function detailRange(a) {
    const D = a.decal;
    D(7, -21, 2.6, -8, 1.2, 2.4, '+x'); D(6, -21, 1.8, 10, 1.1, 2.2, '+x'); D(7, 21, 2.6, 4, 1.2, 2.4, '-x');
    D(6, 6, 1.8, 17, 1.1, 2.2, '-z'); D(7, -6, 2.6, 17, 1.2, 2.4, '-z'); D(6, 14, 1.8, -17, 1.1, 2.2, '+z'); D(7, -14, 2.6, -17, 1.2, 2.4, '+z');
    a.stain(0, 9, 2.4); a.stain(-14, -10, 2); a.stain(6, -8, 2.2);
    const p1 = a.pole(-12, 16.5, 7), p2 = a.pole(12, 16.5, 7); a.wire(p1, p2, 1.0);
  }

  // ===================== «Зимний двор» (дуэли 1 на 1) =====================
  // компактная симметричная площадь: фонтан во льду, два спуска к спавнам, рынок и поленница по бокам
  function layoutWinter(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl, D = (...p) => a.D(...p);
    const SNOW = '#f2f6fb', SNOW2 = '#e4ebf3', IRON = '#2a2d31', WOODD = '#4a3020';
    // снежная «подушка» поверх детали: чуть шире, со скруглением
    const cap = (x0, z0, x1, z1, y, t) => {
      t = t || 0.16;
      D(box(x1 - x0 + 0.12, t, z1 - z0 + 0.12, (x0 + x1) / 2, y + t / 2, (z0 + z1) / 2, SNOW));
      D({ sph: true, r: 1, sx: (x1 - x0) / 2 + 0.04, sy: t * 0.9, sz: (z1 - z0) / 2 + 0.04, x: (x0 + x1) / 2, y: y + t, z: (z0 + z1) / 2, color: SNOW, seg: 10 });
    };
    const stoneWall = (x0, z0, x1, z1, h) => { B(x0, z0, x1, z1, h, 'stonewall'); cap(x0, z0, x1, z1, h, 0.18); };
    const drift = (x, z, sx, sz, h) => D({ sph: true, r: 1, sx, sy: h, sz, x, y: 0, z, color: Math.random() < 0.5 ? SNOW : SNOW2, seg: 12 });
    // ель: тёмные ярусы и снег на каждом
    const pine = (x, z, h) => {
      h = h || 7;
      B(x - 0.35, z - 0.35, x + 0.35, z + 0.35, h, 'none', 0, { hidden: true });
      D(cyl(0.22, 1.4, x, 0.7, z, '#3b2a1e', 0, 0, 0, 7));
      const tiers = 4;
      for (let i = 0; i < tiers; i++) {
        const t = i / tiers, r = 2.1 * (1 - t * 0.68), y0 = 1.0 + i * (h - 1.6) / tiers, th = (h - 1.0) / tiers * 1.35;
        D({ cyl: true, r: 0.05, r2: r, h: th, x, y: y0 + th / 2, z, color: i % 2 ? '#1f3b2b' : '#25442f', seg: 9 });
        D({ cyl: true, r: 0.04, r2: r * 0.78, h: th * 0.5, x, y: y0 + th * 0.78, z, color: SNOW, seg: 9 });
      }
      D({ sph: true, r: 0.18, x, y: h + 0.05, z, color: SNOW, seg: 8 });
      drift(x, z, 1.6, 1.4, 0.32);
    };
    // фонарь на кованом столбе: тёплый свет и пятно на снегу
    const lantern = (x, z) => {
      B(x - 0.15, z - 0.15, x + 0.15, z + 0.15, 3.2, 'none', 0, { hidden: true });
      D(cyl(0.1, 3.0, x, 1.5, z, IRON, 0, 0, 0, 8), cyl(0.2, 0.25, x, 0.12, z, IRON, 0, 0, 0, 8));
      D(box(0.42, 0.06, 0.42, x, 3.04, z, IRON), box(0.34, 0.5, 0.34, x, 3.32, z, '#ffd9a0'), box(0.46, 0.08, 0.46, x, 3.6, z, IRON),
        { cyl: true, r: 0.02, r2: 0.3, h: 0.22, x, y: 3.74, z, color: IRON, seg: 4, ry: Math.PI / 4 }, box(0.3, 0.06, 0.3, x, 3.88, z, SNOW));
      a.lamps.push([x, 3.32, z, 2.2]);
      a.pool(x, z, 5.5);
    };
    // дом по краю площади: стены, светящиеся окна, дверь, снежная двускатная крыша, труба
    const house = (x0, z0, x1, z1, mat, inner) => {
      const h = 7.2;
      B(x0, z0, x1, z1, h, mat);
      const w = x1 - x0, l = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      D({ shape: true, pts: [[-w / 2 - 0.55, 0], [0, 2.5], [w / 2 + 0.55, 0]], d: l + 0.9, x: cx, y: h, z: cz, ry: HP, color: SNOW, cs: 1 });
      D(box(0.18, 0.22, l + 0.9, x0 - 0.5, h - 0.05, cz, WOODD), box(0.18, 0.22, l + 0.9, x1 + 0.5, h - 0.05, cz, WOODD));
      D(box(0.9, 1.8, 0.9, cx + w * 0.18, h + 1.7, z0 + l * 0.3, '#5c4a40'), box(1.04, 0.2, 1.04, cx + w * 0.18, h + 2.65, z0 + l * 0.3, SNOW));
      // окна и дверь на стороне площади
      const xf = inner > 0 ? x1 : x0, n = inner > 0 ? '+x' : '-x';
      for (let zz = z0 + 2; zz <= z1 - 1.5; zz += 3.2) {
        a.decal(5, xf, 5.0, zz, 1.3, 1.9, n);
        if (Math.abs(zz - cz) < 1.7) a.decal(2, xf, 1.45, zz, 1.5, 2.9, n); else a.decal(5, xf, 2.0, zz, 1.3, 1.9, n);
        D(box(0.3, 0.12, 1.5, xf + inner * 0.15, 4.0, zz, SNOW));
      }
      drift(xf + inner * 0.35, cz, 0.8, l / 2, 0.35);
    };
    // ---------- периметр ----------
    B(-19, -27, 19, -26, 6, 'stonewall'); B(-19, 26, 19, 27, 6, 'stonewall');
    B(-19, -26, -18, 26, 6, 'stonewall'); B(18, -26, 19, 26, 6, 'stonewall');
    for (const [x0, z0, x1, z1] of [[-19, -27, 19, -26], [-19, 26, 19, 27], [-19, -26, -18, 26], [18, -26, 19, 26]]) cap(x0, z0, x1, z1, 6, 0.25);
    // всё остальное — центрально-симметрично: (x, z) и (-x, -z)
    for (const s of [1, -1]) {
      const X = (v) => v * s, Z = (v) => v * s, R = s > 0 ? 0 : Math.PI;
      const BB = (x0, z0, x1, z1, h, mat, y0, o) => B(X(x0), Z(z0), X(x1), Z(z1), h, mat, y0, o);
      const SW = (x0, z0, x1, z1, h) => stoneWall(Math.min(X(x0), X(x1)), Math.min(Z(z0), Z(z1)), Math.max(X(x0), X(x1)), Math.max(Z(z0), Z(z1)), h);
      // дома: штукатурка у одного спавна, кирпич у другого
      house(Math.min(X(-18), X(-13)), Math.min(Z(8), Z(25.9)), Math.max(X(-18), X(-13)), Math.max(Z(8), Z(25.9)), 'plaster', s);
      house(Math.min(X(13), X(18)), Math.min(Z(13), Z(25.9)), Math.max(X(13), X(18)), Math.max(Z(13), Z(25.9)), 'brick', -s);
      // арка ворот на торце: столбы, свод, тёмные створки
      D(box(1.0, 4.6, 0.9, X(-2.9), 2.3, Z(25.6), '#6f6a66'), box(1.0, 4.6, 0.9, X(2.9), 2.3, Z(25.6), '#6f6a66'),
        box(6.8, 1.0, 1.0, 0, 4.9, Z(25.6), '#6f6a66'), box(7.0, 0.22, 1.2, 0, 5.5, Z(25.6), SNOW),
        box(4.6, 3.8, 0.12, 0, 1.9, Z(25.45), '#3c2618'), box(0.08, 3.6, 0.14, 0, 1.9, Z(25.4), '#1c120b'),
        box(0.12, 0.12, 0.2, X(-0.4), 1.8, Z(25.3), '#b08a40'), box(0.12, 0.12, 0.2, X(0.4), 1.8, Z(25.3), '#b08a40'));
      // навес над спавном
      for (const xx of [-3.6, 3.6]) { BB(xx - 0.12, 21.3, xx + 0.12, 21.6, 3.3, 'none', 0, { hidden: true }); D(box(0.22, 3.3, 0.22, X(xx), 1.65, Z(21.45), WOODD)); }
      D(box(8.2, 0.16, 4.4, 0, 3.38, Z(23.4), '#5a3a26', 0.08 * s), box(8.4, 0.2, 4.6, 0, 3.55, Z(23.4), SNOW, 0.08 * s), box(8.4, 0.12, 0.2, 0, 3.22, Z(21.3), WOODD));
      // низкие каменные стенки перед спавном
      SW(-7.5, 16.6, -2.6, 17.3, 1.15); SW(2.6, 16.6, 7.5, 17.3, 1.15);
      // дорожка к фонтану
      BB(-1.6, 6.2, 1.6, 25, 0.02, 'jpstone', 0, { solid: false });
      // рынок: прилавок с навесом и ящики
      BB(-11.8, 10.4, -8.4, 11.5, 1.05, 'planks');
      D(box(3.6, 0.1, 1.3, X(-10.1), 1.08, Z(10.95), SNOW2));
      for (const xx of [-11.7, -8.5]) D(box(0.14, 2.6, 0.14, X(xx), 1.3, Z(11.45), WOODD));
      a.awning(X(-10.1), 2.75, Z(11.45), 3.6, 1.6, s > 0 ? '-z' : '+z', '#2f5d86');
      stack(X(-12.3), Z(7.2), 1.15); crate(X(-7.8), Z(13.8), 1.1);
      D(box(1.2, 0.14, 1.2, X(-12.3), 1.22, Z(7.2), SNOW), box(1.0, 0.12, 1.0, X(-12.24), 2.15, Z(7.15), SNOW));
      // поленница
      BB(6.6, 4.0, 10.2, 5.3, 1.1, 'none', 0, { hidden: true });
      for (let r = 0; r < 3; r++) for (let i = 0; i < 9 - r; i++) D(cyl(0.2, 1.25, X(6.95 + i * 0.4 + r * 0.2), 0.22 + r * 0.36, Z(4.65), i % 3 ? '#7a5634' : '#8a6440', HP, 0, 0, 8));
      D(box(3.8, 0.14, 1.4, X(8.4), 1.18, Z(4.65), SNOW));
      // каменная стенка у фонтана и бочки
      SW(7.2, 0.9, 10.2, 1.6, 1.1);
      a.barrel(X(10.6), Z(11.8), '#5b3a2a'); a.barrel(X(11.3), Z(12.4), '#3f4f5f');
      D(cyl(0.32, 0.08, X(10.6), 1.0, Z(11.8), SNOW, 0, 0, 0, 12), cyl(0.32, 0.08, X(11.3), 1.0, Z(12.4), SNOW, 0, 0, 0, 12));
      crate(X(6.4), Z(10.2), 1.2); D(box(1.3, 0.14, 1.3, X(6.4), 1.27, Z(10.2), SNOW));
      // ели и фонари
      pine(X(-15.6), Z(2.4), 7.5); pine(X(15.8), Z(7.0), 6.5);
      lantern(X(-4.6), Z(4.6)); lantern(X(4.6), Z(4.6)); lantern(X(-12.4), Z(17.6));
      // сугробы вдоль стен
      drift(X(-8), Z(25.6), 4.5, 0.9, 0.5); drift(X(9), Z(25.6), 3.5, 0.8, 0.45); drift(X(-17.6), Z(-1), 0.7, 4, 0.5); drift(X(17.5), Z(9.5), 0.6, 2.5, 0.4);
      a.stain(X(-3), Z(12), 2.2);
    }
    // ---------- фонтан во льду ----------
    stoneWall(-2.6, -2.6, 2.6, 2.6, 0.8);
    D(box(4.6, 0.06, 4.6, 0, 0.84, 0, '#bfe0ee'));
    B(-0.6, -0.6, 0.6, 0.6, 2.3, 'stonewall');
    D(cyl(1.1, 0.25, 0, 2.42, 0, '#6f6a66', 0, 0, 0, 16), cyl(1.15, 0.12, 0, 2.6, 0, SNOW, 0, 0, 0, 16));
    // ледяная скульптура: сосульки и шар
    for (let i = 0; i < 10; i++) { const an = i / 10 * Math.PI * 2; D({ cyl: true, r: 0.11, r2: 0.01, h: 0.6 + (i % 3) * 0.2, x: Math.cos(an) * 1.0, y: 2.0 - (i % 3) * 0.1, z: Math.sin(an) * 1.0, color: '#d6f0fa', seg: 6, rx: Math.PI }); }
    D({ sph: true, r: 0.55, x: 0, y: 3.2, z: 0, color: '#cdeefa', seg: 12 }, { cyl: true, r: 0.12, r2: 0.3, h: 0.5, x: 0, y: 2.75, z: 0, color: '#9fc8d8', seg: 10 });
    B(-6.2, -6.2, 6.2, 6.2, 0.02, 'jpstone', 0, { solid: false });
    a.snowfall = true;
  }

  // ===================== «Вилла» (2 на 2, одна точка A) =====================
  // юг — въезд и спавн налётчиков; три пути к точке: лимонный сад и дом (запад), двор с фонтаном (центр),
  // переулок (восток); точка A — терраса с бассейном и перголой; север — спавн спецназа у главного дома
  function layoutVilla(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    const D = (...p) => { for (const q of p) a.decor.push(q); };
    const H = (...p) => { for (const q of p) a.hi.push(q); };
    const L = (...p) => { for (const q of p) a.blossoms.push(q); };
    let sd = 4242; const R = (lo, hi) => { sd = (sd * 16807) % 2147483647; return lo + (sd / 2147483647) * (hi - lo); };
    const CREAM = '#fbf0dc', WHITE = '#ffffff', OCHRE = '#f7d9a8', PINK = '#f8dfd4', SAND = '#f6e6c6', LIME = '#fff8ea';
    const TERRA = '#b65a33', TERRA_D = '#8a3f22', BLUE = '#2f6fae', IRON = '#2a2a2d', WOOD = '#6b4a2e', WOOD_L = '#9c7350';
    const STONE = '#e2d6bd', STONE_L = '#efe6d2', CHROME = '#d9dee2';
    const OLIVE = ['#bfca9f', '#aebd8e', '#c9d1ab'], LEMON = ['#5f9e44', '#4f8c3a', '#6cab4d'], CYP = ['#4a6a3c', '#3f5c34', '#527444'];
    const BOUG = ['#ef3fa2', '#dc2f8f', '#ff62b4', '#cc2580'], VINE = ['#7aa94e', '#6a9a42', '#86b45a'];
    const PL = new THREE.Color('#ebe5d9');
    const wc = (t) => '#' + new THREE.Color(t).multiply(PL).getHexString(); // цвет «как у стены» для декора
    const W = (x0, z0, x1, z1, h, tint, y0) => B(x0, z0, x1, z1, h, 'plaster', y0, { tint, ch: 1 });
    const lintel = (x0, z0, x1, z1, yb, yt, tint) => B(x0, z0, x1, z1, yt - yb, 'plaster', yb, { tint });
    const floor = (x0, z0, x1, z1, mat, tint) => B(x0, z0, x1, z1, 0.02, mat, 0, { solid: false, tint });
    const DC = (cell, x, y, z, w, h, n) => a.decals.push({ cell, x, y, z, w, h, n, atlas: 'med', lit: false });
    const NN = { '+x': [1, 0], '-x': [-1, 0], '+z': [0, 1], '-z': [0, -1] };

    // ---------- детали-помощники ----------
    // терракотовый гребень на стене: плита и полукруглая черепица
    const coping = (x0, z0, x1, z1, y) => {
      const ax = (x1 - x0) >= (z1 - z0), Ln = ax ? x1 - x0 : z1 - z0, T = ax ? z1 - z0 : x1 - x0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      D(box(ax ? Ln + 0.1 : T + 0.16, 0.08, ax ? T + 0.16 : Ln + 0.1, cx, y + 0.04, cz, TERRA_D),
        cyl(Math.min(0.15, T * 0.3), Ln + 0.06, cx, y + 0.1, cz, TERRA, ax ? 0 : HP, 0, ax ? HP : 0, 6));
    };
    // черепичная крыша: вальмовая или двускатная с фронтонами под цвет стены
    const roof = (x0, z0, x1, z1, y, h, ov, o) => {
      o = o || {};
      const r = { X0: x0, X1: x1, Z0: z0, Z1: z1, y, h, ov, hip: !!o.hip, col: o.col || '#ffffff', alongX: o.along ? o.along === 'x' : (x1 - x0) >= (z1 - z0) };
      a.roofs.push(r);
      const g = roofFrame(r), ax = r.alongX, P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa], RC = '#a3482a';
      for (const c of [g.C0, g.C1]) { const p = P(g.mid, c, g.ey - 0.05); D(box(ax ? g.A1 - g.A0 : 0.13, 0.12, ax ? 0.13 : g.A1 - g.A0, p[0], p[1], p[2], TERRA_D)); }
      if (g.ra1 - g.ra0 > 0.05) { const p = P((g.ra0 + g.ra1) / 2, g.cc, g.top + 0.02); D(cyl(0.14, g.ra1 - g.ra0 + 0.3, p[0], p[1], p[2], RC, ax ? 0 : HP, 0, ax ? HP : 0, 6)); }
      if (r.hip) {
        for (const aa of [g.A0, g.A1]) { const p = P(aa, g.cc, g.ey - 0.05); D(box(ax ? 0.13 : g.C1 - g.C0, 0.12, ax ? g.C1 - g.C0 : 0.13, p[0], p[1], p[2], TERRA_D)); }
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) D(stick(P(aa, c, g.ey + 0.03), P(ra, g.cc, g.top + 0.04), 0.12, 0.12, RC, 5));
      } else {
        for (const aa of [g.a0w + 0.06, g.a1w - 0.06]) { const p = P(aa, g.cc, y); D({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: o.gable || wc(CREAM), ry: ax ? 0 : HP, cs: 1 }); }
        for (const aa of [g.A0, g.A1]) for (const s of [-1, 1]) D(stick(P(aa, g.cc + s * g.hw, g.ey - 0.02), P(aa, g.cc, g.top), 0.1, 0.1, RC, 5));
      }
    };
    // арка: углы проёма шириной w (вдоль оси along) с верхом top, у плоскости стены (cx, cz)
    const arch = (cx, cz, along, w, top, col) => {
      const r = w / 2, s = top - r, k = 0.5523 * r;
      for (const sg of [-1, 1]) D({ shape: true, pts: [[sg * r, top], [0, top], ['c', sg * k, top, sg * r, s + k, sg * r, s]], d: 0.14, x: cx, y: 0, z: cz, color: col, ry: along === 'x' ? -HP : 0, cs: 6 });
    };
    // бугенвиллея: свисающая «наклейка» на стене и пышные кусты поверху
    const boug = (x, z, n, w, top, hang) => {
      DC(6, x, top - hang / 2, z, w, hang, n);
      const N = NN[n], ux = N[0] ? 0 : 1, uz = N[0] ? 1 : 0, k = Math.max(2, Math.round(w / 0.75));
      for (let i = 0; i < k; i++) {
        const t = (i + 0.5) / k - 0.5;
        L({ sph: true, r: R(0.34, 0.48), x: x + ux * t * w + N[0] * 0.22, y: top + R(-0.15, 0.1), z: z + uz * t * w + N[1] * 0.22, sx: 1.2, sy: 0.75, sz: 1.2, color: i % 3 === 1 ? VINE[i % 3] : BOUG[i % 4], seg: 6 });
      }
    };
    // олива: узловатый ствол, серебристая крона
    const olive = (x, z, k, solid) => {
      k = k || 1;
      if (solid !== false) B(x - 0.3 * k, z - 0.3 * k, x + 0.3 * k, z + 0.3 * k, 2.4 * k, 'none', 0, { hidden: true });
      const lean = R(0, 6.28), f = [x + Math.cos(lean) * 0.3 * k, 1.15 * k, z + Math.sin(lean) * 0.3 * k];
      D(stick([x, 0, z], [x, 0.5 * k, z], 0.36 * k, 0.27 * k, '#5d5446', 7), stick([x, 0.45 * k, z], f, 0.26 * k, 0.19 * k, '#6b6150', 7));
      for (let j = 0; j < 3; j++) {
        const an = lean + j * 2.09 + R(-0.4, 0.4), e = [f[0] + Math.cos(an) * 1.15 * k, R(2.0, 2.4) * k, f[2] + Math.sin(an) * 1.15 * k];
        D(stick(f, e, 0.14 * k, 0.08 * k, '#6b6150', 5));
        L({ sph: true, r: R(1.0, 1.2) * k, x: e[0], y: e[1] + 0.3 * k, z: e[2], sx: 1.25, sy: 0.62, sz: 1.15, ry: R(0, 3), color: OLIVE[j % 3], seg: 8 });
      }
      L({ sph: true, r: 1.3 * k, x: f[0], y: 2.95 * k, z: f[2], sx: 1.2, sy: 0.6, sz: 1.2, ry: R(0, 3), color: OLIVE[1], seg: 8 });
      for (let i = 0; i < 10; i++) { const an = R(0, 6.28); H({ sph: true, r: 0.05, x: f[0] + Math.cos(an) * R(0.6, 1.8) * k, y: R(2.1, 2.7) * k, z: f[2] + Math.sin(an) * R(0.6, 1.8) * k, color: '#3a3b2a', seg: 4 }); }
    };
    // терракотовый горшок
    const potShape = (x, z, k, col) => {
      D(cyl(0.5 * k, 0.7 * k, x, 0.35 * k, z, col || TERRA, 0, 0, 0, 10, 0.37 * k), cyl(0.56 * k, 0.12 * k, x, 0.74 * k, z, col || TERRA, 0, 0, 0, 10, 0.52 * k));
    };
    // лимон в кадке
    const lemon = (x, z, k) => {
      k = k || 1;
      B(x - 0.46 * k, z - 0.46 * k, x + 0.46 * k, z + 0.46 * k, 0.78 * k, 'none', 0, { hidden: true });
      potShape(x, z, k);
      D(stick([x, 0.72 * k, z], [x, 1.5 * k, z], 0.07 * k, 0.05 * k, '#6a5440', 5));
      L({ sph: true, r: 0.78 * k, x, y: 1.95 * k, z, sy: 0.9, color: LEMON[0], seg: 8 }, { sph: true, r: 0.48 * k, x: x + 0.36 * k, y: 1.66 * k, z: z - 0.24 * k, color: LEMON[2], seg: 6 });
      for (let i = 0; i < 6; i++) { const an = R(0, 6.28), el = R(-0.5, 0.6), rr = 0.8 * k; H({ sph: true, r: 0.08 * k, x: x + Math.cos(an) * Math.cos(el) * rr, y: 1.95 * k + Math.sin(el) * rr * 0.9, z: z + Math.sin(an) * Math.cos(el) * rr, sy: 1.25, color: '#f7d63a', seg: 4 }); }
    };
    // кипарис: высокий узкий силуэт
    const cypress = (x, z, h, solid) => {
      h = h || 8;
      if (solid !== false) B(x - 0.4, z - 0.4, x + 0.4, z + 0.4, 3, 'none', 0, { hidden: true });
      D(cyl(0.13, 0.9, x, 0.45, z, '#4a3a2a', 0, 0, 0, 6));
      L({ sph: true, r: 1, x, y: h * 0.3, z, sx: 0.95, sy: h * 0.27, sz: 0.95, color: CYP[0], seg: 8 },
        { cyl: true, r: 0.06, r2: 0.9, h: h * 0.62, x: x + 0.05, y: h * 0.62, z, color: CYP[1], seg: 8 });
    };
    // амфора
    const amphora = (x, z, k, col) => {
      k = k || 1; col = col || '#c56d40';
      B(x - 0.32 * k, z - 0.32 * k, x + 0.32 * k, z + 0.32 * k, 0.95 * k, 'none', 0, { hidden: true });
      D({ sph: true, r: 0.34 * k, x, y: 0.52 * k, z, sy: 1.3, color: col, seg: 9 }, cyl(0.11 * k, 0.3 * k, x, 0.98 * k, z, col, 0, 0, 0, 8, 0.16 * k),
        cyl(0.16 * k, 0.06 * k, x, 1.14 * k, z, col, 0, 0, 0, 8));
      for (const s of [-1, 1]) H(stick([x + s * 0.27 * k, 0.8 * k, z], [x + s * 0.24 * k, 1.04 * k, z], 0.025 * k, 0.025 * k, col, 4), stick([x + s * 0.24 * k, 1.04 * k, z], [x + s * 0.1 * k, 1.06 * k, z], 0.025 * k, 0.025 * k, col, 4));
    };
    // цветочный горшок (герань / лаванда) — мелочь, только на высоком качестве
    const flowers = (x, z, k, col, y0) => {
      k = k || 1; y0 = y0 || 0;
      H(cyl(0.2 * k, 0.3 * k, x, y0 + 0.15 * k, z, TERRA, 0, 0, 0, 7, 0.15 * k), { sph: true, r: 0.22 * k, x, y: y0 + 0.38 * k, z, sy: 0.7, color: '#4f7f34', seg: 6 });
      for (let i = 0; i < 5; i++) H({ sph: true, r: 0.07 * k, x: x + R(-0.15, 0.15) * k, y: y0 + R(0.42, 0.5) * k, z: z + R(-0.15, 0.15) * k, color: col || '#e0302c', seg: 4 });
    };
    // фонарь на стене
    const lantern = (x, y, z, n) => {
      const N = NN[n];
      D(box(N[0] ? 0.4 : 0.05, 0.05, N[0] ? 0.05 : 0.4, x + N[0] * 0.2, y + 0.25, z + N[1] * 0.2, IRON),
        box(0.2, 0.3, 0.2, x + N[0] * 0.38, y, z + N[1] * 0.38, '#f3dfa8'), { cyl: true, r: 0.02, r2: 0.17, h: 0.14, x: x + N[0] * 0.38, y: y + 0.22, z: z + N[1] * 0.38, color: IRON, seg: 4, ry: Math.PI / 4 },
        box(0.24, 0.04, 0.24, x + N[0] * 0.38, y - 0.16, z + N[1] * 0.38, IRON));
    };
    // каменная скамья (укрытие по колено)
    const bench = (x0, z0, x1, z1) => B(x0, z0, x1, z1, 0.46, 'flag');
    // шезлонг вдоль z, спинка к +z
    const lounger = (x, z) => {
      B(x - 0.38, z - 1.0, x + 0.38, z + 1.0, 0.5, 'none', 0, { hidden: true });
      D(box(0.74, 0.07, 1.96, x, 0.3, z, '#f4f1ea'), box(0.66, 0.09, 1.25, x, 0.38, z - 0.32, '#e9eef1'), box(0.66, 0.09, 0.72, x, 0.62, z + 0.68, '#e9eef1', -0.62));
      D(box(0.5, 0.012, 1.0, x, 0.43, z - 0.3, BLUE), box(0.5, 0.012, 0.18, x, 0.436, z - 0.55, '#ffffff'));
      for (const sx of [-0.3, 0.3]) for (const sz of [-0.85, 0.85]) D(box(0.05, 0.27, 0.05, x + sx, 0.135, z + sz, CHROME));
    };
    // зонт от солнца
    const parasol = (x, z, col, rim) => {
      B(x - 0.08, z - 0.08, x + 0.08, z + 0.08, 2.3, 'none', 0, { hidden: true });
      D(cyl(0.035, 2.5, x, 1.25, z, '#e9e3d6', 0, 0, 0, 6), cyl(0.3, 0.1, x, 0.05, z, '#cfc6b4', 0, 0, 0, 8),
        { cyl: true, r: 0.06, r2: 1.3, h: 0.45, x, y: 2.48, z, color: col || '#f6efe2', seg: 10 }, { cyl: true, r: 1.3, h: 0.14, x, y: 2.19, z, color: rim || BLUE, seg: 10, open: true },
        { sph: true, r: 0.07, x, y: 2.76, z, color: '#e9e3d6', seg: 5 });
    };
    // чаша фонтана из колец-коробок: стенки — укрытие, вода — непроходима, но простреливается
    const fountain = (x, z) => {
      const r = 2.0, n = 16;
      for (let i = 0; i < n; i++) { const an = (i + 0.5) / n * Math.PI * 2; D(box(0.34, 0.66, 2 * r * Math.sin(Math.PI / n) + 0.04, x + Math.cos(an) * (r - 0.17), 0.33, z + Math.sin(an) * (r - 0.17), STONE, 0, -an, 0)); }
      D({ torus: true, r: r - 0.16, tube: 0.16, x, y: 0.68, z, rx: HP, color: STONE_L, seg: 18 });
      a.ground.push({ kind: 'swim', x, z, r: r - 0.3, y: 0.52 });
      const q = r * 0.72;
      for (const [x0, z0, x1, z1] of [[-q, -r, q, -q], [-q, q, q, r], [-r, -q, -q, q], [q, -q, r, q]]) B(x + x0, z + z0, x + x1, z + z1, 0.7, 'none', 0, { hidden: true });
      B(x - q, z - q, x + q, z + q, 1.25, 'none', 0, { hidden: true, nr: true });
      B(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 2.5, 'none', 0, { hidden: true });
      D(cyl(0.3, 1.5, x, 1.15, z, STONE, 0, 0, 0, 10, 0.42), { cyl: true, r: 0.95, r2: 0.22, h: 0.36, x, y: 2.05, z, color: STONE_L, seg: 14 },
        cyl(0.86, 0.03, x, 2.22, z, '#58c2d6', 0, 0, 0, 14), cyl(0.13, 0.5, x, 2.45, z, STONE, 0, 0, 0, 8, 0.2), { sph: true, r: 0.2, x, y: 2.8, z, color: STONE_L, seg: 8 },
        cyl(0.05, 0.3, x, 2.32, z, '#bfeaf2', 0, 0, 0, 6));
      // струи из верхней чаши: дугой вниз в бассейн
      for (let i = 0; i < 4; i++) {
        const an = i * HP + 0.4, c = Math.cos(an), sn = Math.sin(an), P = [[0.86, 2.17], [1.04, 2.1], [1.2, 1.62], [1.3, 0.58]];
        for (let k = 0; k < 3; k++) D(stick([x + c * P[k][0], P[k][1], z + sn * P[k][0]], [x + c * P[k + 1][0], P[k + 1][1], z + sn * P[k + 1][0]], 0.03 + k * 0.006, 0.03 + (k + 1) * 0.006, '#cdeff5', 5));
      }
    };
    // трёхколёсный грузовичок «Апе» (вдоль z, кабина к +z) с ящиками лимонов
    const ape = (x, z) => {
      B(x - 0.78, z - 1.75, x + 0.78, z + 1.65, 1.6, 'none', 0, { hidden: true });
      const C = '#8ec2d8';
      D(box(1.3, 1.1, 1.05, x, 1.0, z + 1.05, C), { sph: true, r: 0.62, x, y: 0.95, z: z + 1.35, sx: 1.05, sy: 0.85, sz: 0.55, color: C, seg: 10 },
        box(1.34, 0.08, 1.1, x, 1.58, z + 1.0, '#eeeae0'), box(1.06, 0.48, 0.04, x, 1.2, z + 1.6, '#2a3a46', -0.15), box(0.04, 0.5, 0.6, x - 0.66, 1.2, z + 1.0, '#2a3a46'), box(0.04, 0.5, 0.6, x + 0.66, 1.2, z + 1.0, '#2a3a46'),
        { sph: true, r: 0.09, x, y: 0.95, z: z + 1.68, color: '#fff6d8', seg: 6 }, box(1.45, 0.12, 2.1, x, 0.66, z - 0.62, '#6e5236'), box(1.45, 0.12, 0.3, x, 0.42, z + 0.4, '#3a3a3a'));
      for (const s of [-1, 1]) D(box(0.06, 0.38, 2.1, x + s * 0.7, 0.9, z - 0.62, '#8a6a46'));
      D(box(1.45, 0.38, 0.06, x, 0.9, z - 1.66, '#8a6a46'));
      D(cyl(0.27, 0.16, x, 0.27, z + 1.45, '#1d1d1d', 0, 0, HP, 10), cyl(0.27, 0.16, x - 0.62, 0.27, z - 1.0, '#1d1d1d', 0, 0, HP, 10), cyl(0.27, 0.16, x + 0.62, 0.27, z - 1.0, '#1d1d1d', 0, 0, HP, 10));
      for (const [ox, oz] of [[-0.33, -1.15], [0.33, -1.15], [-0.33, -0.3]]) {
        D(box(0.6, 0.34, 0.75, x + ox, 0.9, z + oz, '#b88a52'));
        D(box(0.52, 0.04, 0.66, x + ox, 1.06, z + oz, '#e8c43a'));
        for (let i = 0; i < 5; i++) H({ sph: true, r: 0.1, x: x + ox + R(-0.2, 0.2), y: 1.12, z: z + oz + R(-0.26, 0.26), sy: 1.2, color: '#f6d23a', seg: 4 });
      }
    };
    // «Фиат 500» (вдоль z)
    const fiat = (x, z) => {
      B(x - 0.78, z - 1.5, x + 0.78, z + 1.5, 1.35, 'none', 0, { hidden: true });
      const C = '#a9d6c8';
      D({ sph: true, r: 1, x, y: 0.62, z, sx: 0.76, sy: 0.42, sz: 1.5, color: C, seg: 10 }, box(1.48, 0.42, 2.6, x, 0.55, z, C), { sph: true, r: 1, x, y: 1.0, z: z + 0.15, sx: 0.66, sy: 0.42, sz: 0.92, color: C, seg: 10 },
        box(1.36, 0.3, 1.25, x, 1.12, z + 0.15, '#2b3742'), box(1.0, 0.06, 0.9, x, 1.42, z + 0.15, '#3a3633'),
        box(1.5, 0.08, 0.1, x, 0.42, z - 1.48, CHROME), box(1.5, 0.08, 0.1, x, 0.42, z + 1.48, CHROME),
        { sph: true, r: 0.12, x: x - 0.5, y: 0.75, z: z - 1.4, sz: 0.5, color: '#fff6d8', seg: 6 }, { sph: true, r: 0.12, x: x + 0.5, y: 0.75, z: z - 1.4, sz: 0.5, color: '#fff6d8', seg: 6 });
      for (const sx of [-0.66, 0.66]) for (const sz of [-0.95, 0.95]) D(cyl(0.27, 0.2, x + sx, 0.27, z + sz, '#1c1c1c', 0, 0, HP, 10), cyl(0.15, 0.22, x + sx, 0.27, z + sz, CHROME, 0, 0, HP, 8));
    };
    // винная бочка на подставке (ось вдоль z)
    const cask = (x, z) => {
      B(x - 0.6, z - 0.62, x + 0.6, z + 0.62, 1.35, 'none', 0, { hidden: true });
      D(cyl(0.58, 1.1, x, 0.75, z, '#7a4c2c', HP, 0, 0, 12), cyl(0.5, 1.14, x, 0.75, z, '#5a3820', HP, 0, 0, 12));
      for (const o of [-0.3, 0.3]) H(cyl(0.6, 0.06, x, 0.75, z + o, '#3a3a3a', HP, 0, 0, 12));
      D(box(1.1, 0.18, 0.15, x, 0.09, z - 0.4, WOOD), box(1.1, 0.18, 0.15, x, 0.09, z + 0.4, WOOD));
    };
    // виноградная пергола: столбы, балки, стропила и лоза
    const pergola = (xs, zs, h) => {
      const x0 = Math.min(...xs), x1 = Math.max(...xs), z0 = Math.min(...zs), z1 = Math.max(...zs);
      for (const px of xs) for (const pz of zs) {
        W(px - 0.2, pz - 0.2, px + 0.2, pz + 0.2, h, CREAM);
        D(box(0.5, 0.12, 0.5, px, h + 0.02, pz, STONE_L));
        for (let k = 0; k < 4; k++) D(stick([px + 0.22 * Math.cos(k * 1.7), k * h / 4, pz + 0.22 * Math.sin(k * 1.7)], [px + 0.22 * Math.cos(k * 1.7 + 1.7), (k + 1) * h / 4, pz + 0.22 * Math.sin(k * 1.7 + 1.7)], 0.04, 0.035, '#5c4a2e', 4));
      }
      for (const px of xs) D(box(0.2, 0.26, z1 - z0 + 0.8, px, h + 0.21, (z0 + z1) / 2, WOOD));
      for (let zz = z0 - 0.3; zz <= z1 + 0.31; zz += 0.62) D(box(x1 - x0 + 0.8, 0.1, 0.08, (x0 + x1) / 2, h + 0.39, zz, WOOD_L));
      for (let gx = x0 + 0.4; gx <= x1 - 0.2; gx += 1.6) for (let gz = z0 + 0.2; gz <= z1; gz += 1.7) {
        if (R(0, 1) < 0.22) continue;
        L({ sph: true, r: R(0.85, 1.15), x: gx + R(-0.3, 0.3), y: h + 0.55, z: gz + R(-0.3, 0.3), sx: 1.1, sy: 0.3, sz: 1.1, ry: R(0, 3), color: VINE[Math.floor(R(0, 2.99))], seg: 6 });
        if (R(0, 1) < 0.6) H({ sph: true, r: 0.12, x: gx + R(-0.5, 0.5), y: h + 0.15, z: gz + R(-0.5, 0.5), sy: 1.5, color: '#5b2c5e', seg: 5 });
      }
    };

    // ===================== периметр =====================
    W(-21, -29, 21, -28, 4.4, CREAM); W(-21, 28, 21, 29, 4.4, CREAM); W(-21, -28, -20, 28, 4.4, CREAM); W(20, -28, 21, 28, 4.4, CREAM);
    coping(-21, -29, 21, -28, 4.4); coping(-21, 28, 21, 29, 4.4); coping(-21, -28, -20, 28, 4.4); coping(20, -28, 21, 28, 4.4);

    // ===================== юг: въезд, спавн налётчиков =====================
    floor(-12, -28, 13, -18, 'sand', '#fff1dc'); floor(-20, -21, -12, -18, 'sand', '#fff1dc'); floor(13, -22, 20, -18, 'sand', '#fff1dc');
    // сарай (юго-запад)
    W(-20, -28, -12, -21, 4.2, OCHRE); roof(-20, -28, -12, -21, 4.2, 1.5, 0.45, { along: 'x', gable: wc(OCHRE) });
    DC(4, -16.4, 1.5, -21, 3.0, 3.0, '+z'); DC(0, -13.4, 2.5, -21, 1.0, 2.0, '+z'); DC(1, -12, 2.3, -24.5, 1.1, 2.2, '+x');
    boug(-19.2, -21, '+z', 1.4, 4.1, 2.6); lantern(-14.5, 2.9, -21, '+z');
    // склад (юго-восток)
    W(13, -28, 20, -22, 3.8, WHITE); roof(13, -28, 20, -22, 3.8, 1.2, 0.4, { hip: true });
    DC(2, 16.5, 1.3, -22, 1.4, 2.6, '+z'); DC(1, 14.4, 2.1, -22, 1.0, 2.0, '+z'); DC(1, 18.6, 2.1, -22, 1.0, 2.0, '+z'); DC(0, 13, 2.1, -25, 1.0, 2.0, '-x');
    DC(5, 15.5, 2.2, -22, 0.45, 0.9, '+z'); lantern(17.6, 2.8, -22, '+z');
    // ворота в южной стене: столбы с вазонами, синие створки, бугенвиллея поверху
    W(-3.3, -28, -2.5, -27.4, 4.9, CREAM); W(2.5, -28, 3.3, -27.4, 4.9, CREAM);
    for (const gx of [-2.9, 2.9]) D(box(0.95, 0.12, 0.75, gx, 4.96, -27.7, STONE_L), { sph: true, r: 0.3, x: gx, y: 5.3, z: -27.7, sy: 0.85, color: TERRA, seg: 8 }, cyl(0.2, 0.1, gx, 5.6, -27.7, TERRA, 0, 0, 0, 8));
    DC(7, 0, 1.75, -28, 4.9, 3.5, '+z'); boug(0, -28, '+z', 4.6, 4.45, 1.3);
    ape(-9.3, -24.4);
    olive(8.4, -25.4, 1.1);
    a.barrel(11.9, -23.3, '#7a4a2a'); a.barrel(12.3, -24.2, '#5e3e26'); a.barrel(11.4, -24.1, '#7a4a2a');
    stack(-5.4, -19.8, 1.2); crate(5.0, -19.8, 1.15); crate(-11.0, -19.5, 1.1);
    amphora(-18.8, -20.0, 1.15); amphora(-18.0, -19.4, 0.9);
    cypress(-19.2, -18.8, 8.2); cypress(19.2, -21.2, 8.6);

    // ===================== запад: лимонный сад =====================
    floor(-20, -18, -16.3, 4.5, 'sand', '#f7e2bf'); floor(-13.7, -18, -10, 4.5, 'sand', '#f7e2bf'); floor(-16.3, -18, -13.7, 4.5, 'cotto');
    B(-20, -16, -18.6, 2.6, 0.55, 'flag');
    for (let z = -15.2; z < 2.2; z += 1.25) L({ sph: true, r: 0.55, x: -19.3 + R(-0.1, 0.1), y: 0.72, z, sx: 1.0, sy: 0.55, sz: 1.25, color: z % 2.5 < 1.25 ? '#a494d0' : '#9484c2', seg: 6 });
    cypress(-19.3, -11.2, 8.4); cypress(-19.3, -3.4, 8.8);
    for (const lz of [-13.4, -7.9, -2.4]) { lemon(-17.2, lz, 1.0); lemon(-12.8, lz, 1.0); }
    bench(-10.8, -6.9, -10, -4.7); amphora(-10.6, -0.6, 1.2); amphora(-10.65, 0.35, 0.95); amphora(-19.2, 3.6, 1.0);
    cypress(-17.6, 3.3, 8.0); cypress(-12.4, 3.4, 7.6);

    // ===================== дом садовника (между садом и двором) =====================
    W(-10, -18.4, -6, -12.4, 5.2, PINK); W(-10, -10, -6, 4.5, 5.2, PINK); lintel(-10, -12.4, -6, -10, 2.6, 5.2, PINK);
    floor(-10, -12.4, -6, -10, 'cotto');
    roof(-10, -18.4, -6, 4.5, 5.2, 1.6, 0.45, { along: 'z', gable: wc(PINK) });
    arch(-5.93, -11.2, 'z', 2.4, 2.6, wc(PINK)); arch(-10.07, -11.2, 'z', 2.4, 2.6, wc(PINK));
    for (const z of [-14.3, -6.6, -1.6]) DC(0, -6, 3.8, z, 1.0, 2.0, '+x');
    DC(1, -6, 1.6, -6.6, 1.0, 2.0, '+x'); DC(2, -6, 1.3, 1.6, 1.3, 2.6, '+x'); DC(5, -6, 1.8, -4.2, 0.45, 0.9, '+x');
    boug(-6, -14.4, '+x', 2.0, 5.1, 2.8);
    for (const z of [-14.3, -6.2, 0.6]) DC(0, -10, 3.8, z, 1.0, 2.0, '-x');
    DC(3, -10, 1.7, -6.2, 1.1, 2.3, '-x'); boug(-10, 0.6, '-x', 1.8, 5.1, 2.4);

    // ===================== центр: двор с фонтаном =====================
    floor(-3.2, -9.7, 3.2, -3.3, 'cotto');
    floor(-6, -18, 6, -9.7, 'flag'); floor(-6, -9.7, -3.2, -3.3, 'flag'); floor(3.2, -9.7, 6, -3.3, 'flag'); floor(-6, -3.3, 6, 4, 'flag'); floor(2.2, 4, 5.4, 4.5, 'cotto');
    fountain(0, -6.5);
    // южная ограда двора с воротами: со спавна видно только узкую полосу двора
    W(-6, -18.4, -2, -17.8, 2.7, CREAM); W(2, -18.4, 6, -17.8, 2.7, CREAM); coping(-6, -18.4, -2, -17.8, 2.7); coping(2, -18.4, 6, -17.8, 2.7);
    W(-2.5, -18.6, -1.9, -17.6, 3.3, CREAM); W(1.9, -18.6, 2.5, -17.6, 3.3, CREAM);
    for (const gx of [-2.2, 2.2]) D(box(0.8, 0.1, 1.15, gx, 3.35, -18.1, STONE_L), { sph: true, r: 0.26, x: gx, y: 3.62, z: -18.1, sy: 0.85, color: TERRA, seg: 8 }, cyl(0.17, 0.1, gx, 3.88, -18.1, TERRA, 0, 0, 0, 8));
    boug(-4.0, -17.8, '+z', 2.6, 2.75, 1.6); boug(4.2, -18.4, '-z', 2.4, 2.75, 1.6);
    lemon(-4.4, -15.6, 1.05); lemon(4.4, -15.6, 1.05); lemon(-4.3, 2.4, 1.0); lemon(0.6, 2.6, 0.95);
    bench(-6, -3.9, -5.3, -1.6); bench(5.3, -4.6, 6, -2.3);
    a.wire([-6, 4.6, -15.5], [6, 4.6, -2.5], 0.7); a.wire([-6, 4.6, -2.5], [6, 4.6, -15.5], 0.7);
    for (let i = 1; i < 8; i++) {
      const t = i / 8, s = Math.sin(t * Math.PI) * 0.7;
      D({ sph: true, r: 0.07, x: -6 + 12 * t, y: 4.5 - s, z: -15.5 + 13 * t, color: '#fff3c8', seg: 4 }, { sph: true, r: 0.07, x: -6 + 12 * t, y: 4.5 - s, z: -2.5 - 13 * t, color: '#fff3c8', seg: 4 });
    }
    flowers(-5.4, -10.4, 1.0, '#e0302c'); flowers(-5.4, -9.4, 0.9, '#ff6f9a'); flowers(5.4, -0.4, 1.0, '#e0302c');
    // стена с аркой — проход двор → точка A
    W(-6, 4, 2.2, 5, 4.4, CREAM); W(5.4, 4, 6, 5, 4.4, CREAM); lintel(2.2, 4, 5.4, 5, 3.4, 4.4, CREAM);
    coping(-6, 4, 6, 5, 4.4);
    arch(3.8, 3.93, 'x', 3.2, 3.4, wc(CREAM)); arch(3.8, 5.07, 'x', 3.2, 3.4, wc(CREAM));
    boug(-2.2, 4, '-z', 3.4, 4.45, 2.6); boug(-1.2, 5, '+z', 2.6, 4.45, 2.2);
    lantern(1.6, 2.9, 4, '-z'); DC(5, -4.4, 2.2, 4, 0.5, 1.0, '-z');

    // ===================== винодельня (между двором и переулком) =====================
    W(6, -18, 14, -16, 5.6, OCHRE); W(6, -5, 14, 4.5, 5.6, OCHRE);
    W(6, -16, 6.5, -12.2, 5.6, OCHRE); W(6, -9.8, 6.5, -5, 5.6, OCHRE); lintel(6, -12.2, 6.5, -9.8, 2.6, 5.6, OCHRE);
    W(13.5, -16, 14, -12.2, 5.6, OCHRE); W(13.5, -9.8, 14, -5, 5.6, OCHRE); lintel(13.5, -12.2, 14, -9.8, 2.6, 5.6, OCHRE);
    B(6.5, -16, 13.5, -5, 0.3, 'plaster', 3.9, { tint: LIME });
    floor(6, -12.2, 14, -9.8, 'cotto'); floor(6.5, -16, 13.5, -12.2, 'cotto'); floor(6.5, -9.8, 13.5, -5, 'cotto');
    roof(6, -18, 14, 4.5, 5.6, 1.8, 0.45, { along: 'z', gable: wc(OCHRE) });
    arch(5.93, -11, 'z', 2.4, 2.6, wc(OCHRE)); arch(14.07, -11, 'z', 2.4, 2.6, wc(OCHRE));
    for (const cx of [7.6, 9.3, 11.0, 12.7]) cask(cx, -15.2);
    cask(7.6, -5.8); cask(9.3, -5.8);
    B(9.3, -11.3, 10.9, -9.7, 0.95, 'none', 0, { hidden: true });
    D(box(1.7, 0.08, 1.7, 10.1, 0.92, -10.5, WOOD_L), box(1.5, 0.86, 1.5, 10.1, 0.44, -10.5, '#7a5634'));
    for (let i = 0; i < 5; i++) D(cyl(0.045, 0.3, 9.6 + i * 0.25, 1.11, -10.5 + (i % 2) * 0.3, '#244a2a', 0, 0, 0, 6));
    B(11.6, -6.4, 13.3, -5.2, 0.9, 'none', 0, { hidden: true }); D(box(1.7, 0.9, 1.2, 12.45, 0.45, -5.8, '#7a5634'), box(1.7, 0.05, 1.2, 12.45, 0.92, -5.8, WOOD_L));
    H({ torus: true, r: 0.5, tube: 0.03, x: 10, y: 3.0, z: -10.5, rx: HP, color: IRON, seg: 10 }, cyl(0.015, 0.85, 10, 3.45, -10.5, IRON, 0, 0, 0, 4));
    for (const z of [-14.3, -7.4, -1.6, 2.2]) DC(0, 6, 4.1, z, 1.0, 2.0, '-x');
    DC(3, 6, 1.7, -1.6, 1.1, 2.3, '-x'); DC(3, 6, 1.7, 2.2, 1.1, 2.3, '-x'); DC(3, 6, 1.8, -17, 1.0, 2.0, '-x'); DC(5, 6, 3.4, -11, 0.5, 1.0, '-x');
    a.awning(6, 2.95, -11, 3.0, 1.2, '-x', BLUE);
    for (const z of [-14.2, -7.2, -1.5, 2.8]) DC(1, 14, 4.1, z, 1.0, 2.0, '+x');
    DC(0, 14, 1.8, 2.8, 1.0, 2.0, '+x'); boug(14, -2.2, '+x', 2.0, 5.5, 3.0);
    DC(0, 8.2, 3.9, 4.5, 1.0, 2.0, '+z'); DC(0, 11.8, 3.9, 4.5, 1.0, 2.0, '+z'); boug(10, 4.5, '+z', 2.2, 5.5, 2.6);
    DC(4, 10, 1.4, -18, 1.8, 2.8, '-z'); DC(1, 7.6, 2.2, -18, 0.9, 1.8, '-z'); DC(1, 12.4, 2.2, -18, 0.9, 1.8, '-z');

    // ===================== восток: переулок =====================
    floor(14, -18, 18.6, 13, 'flag'); floor(13.2, 6.8, 14, 10, 'flag');
    W(18.6, -18, 20, 13, 6.0, PINK); roof(18.6, -18, 20, 13, 6.0, 0.7, 0.4, { along: 'z', gable: wc(PINK) });
    for (const z of [-14.5, -8.5, -3, 3, 9]) DC(0, 18.6, 4.4, z, 1.0, 2.0, '-x');
    DC(2, 18.6, 1.3, -14.5, 1.3, 2.6, '-x'); DC(2, 18.6, 1.3, 9, 1.3, 2.6, '-x'); DC(1, 18.6, 1.7, -8.5, 1.0, 2.0, '-x'); DC(1, 18.6, 1.7, 3, 1.0, 2.0, '-x');
    DC(5, 18.6, 1.8, -5.6, 0.45, 0.9, '-x'); boug(18.6, -11.4, '-x', 2.2, 6.0, 3.2); boug(18.6, 6.2, '-x', 2.0, 6.0, 3.0);
    lantern(18.6, 2.9, -12.8, '-x'); lantern(18.6, 2.9, 7.4, '-x');
    // балкон
    D(box(0.7, 0.12, 2.0, 18.25, 3.2, -3, STONE_L), box(0.05, 0.05, 2.0, 17.92, 3.95, -3, IRON), box(0.6, 0.05, 0.05, 18.27, 3.95, -3.98, IRON), box(0.6, 0.05, 0.05, 18.27, 3.95, -2.02, IRON));
    for (let i = 0; i < 9; i++) D(box(0.025, 0.7, 0.025, 17.92, 3.6, -3.9 + i * 0.225, IRON));
    flowers(18.3, -3.6, 0.8, '#e0302c', 3.26); flowers(18.3, -2.4, 0.8, '#ff6f9a', 3.26);
    // настенный фонтанчик
    D(box(0.2, 0.9, 0.9, 18.5, 1.25, -5.6 + 3.2, STONE), { sph: true, r: 0.42, x: 18.3, y: 0.55, z: -2.4, sy: 0.55, sx: 0.7, color: STONE_L, seg: 8 }, cyl(0.03, 0.2, 18.25, 1.25, -2.4, '#b08a40', 0, 0, HP, 5));
    B(18.0, -2.85, 18.6, -1.95, 0.75, 'none', 0, { hidden: true });
    // мопед, кадки с бугенвиллеей, ящики, скамья
    B(18.3, -10.4, 18.8, -8.6, 1.1, 'none', 0, { hidden: true });
    D(box(0.36, 0.5, 1.2, 18.55, 0.55, -9.5, '#d84a3a'), { sph: true, r: 0.42, x: 18.55, y: 0.62, z: -9.85, sx: 0.5, sz: 1.0, color: '#d84a3a', seg: 8 },
      cyl(0.2, 0.1, 18.55, 0.2, -10.15, '#1d1d1d', 0, 0, HP, 10), cyl(0.2, 0.1, 18.55, 0.2, -8.8, '#1d1d1d', 0, 0, HP, 10),
      box(0.3, 0.12, 0.55, 18.55, 0.86, -9.7, '#3a2a22'), stick([18.55, 0.4, -8.8], [18.55, 1.05, -8.75], 0.03, 0.03, CHROME, 5), box(0.6, 0.04, 0.04, 18.55, 1.07, -8.75, CHROME));
    for (const [px, pz] of [[18.0, -16.6], [14.6, -4.8]]) {
      B(px - 0.5, pz - 0.5, px + 0.5, pz + 0.5, 0.82, 'none', 0, { hidden: true }); potShape(px, pz, 1.05);
      L({ sph: true, r: 0.7, x: px, y: 1.2, z: pz, sy: 0.75, color: BOUG[1], seg: 7 }, { sph: true, r: 0.45, x: px + 0.3, y: 1.55, z: pz - 0.2, color: BOUG[2], seg: 6 }, { sph: true, r: 0.42, x: px - 0.3, y: 1.4, z: pz + 0.25, color: VINE[1], seg: 6 });
    }
    stack(17.8, 1.4, 1.15); crate(14.75, -15.0, 1.0); bench(17.9, -7.0, 18.6, -5.0);
    // бельё на верёвке и арка из бугенвиллеи над переулком
    a.wire([14, 4.1, -7.6], [18.6, 4.3, -6.4], 0.35);
    for (let i = 0; i < 4; i++) { const t = (i + 0.7) / 4.6; D(box(0.04, 0.7 - (i % 2) * 0.2, 0.55, 14 + 4.6 * t, 3.65 - Math.sin(t * Math.PI) * 0.32 + (i % 2) * 0.1, -7.6 + 1.2 * t, ['#ffffff', '#4a86c8', '#f2c94c', '#e86a5a'][i], 0, -0.26, 0)); }
    D(box(4.6, 0.3, 0.36, 16.3, 4.15, 0.6, STONE_L));
    for (let i = 0; i < 7; i++) L({ sph: true, r: R(0.35, 0.5), x: 14.4 + i * 0.66, y: 4.35 + R(-0.1, 0.1), z: 0.6 + R(-0.2, 0.2), sx: 1.2, sy: 0.75, color: i % 3 === 2 ? VINE[0] : BOUG[i % 4], seg: 6 });
    // садовая стена точки A с калиткой
    W(13.2, 4.5, 14, 6.8, 2.9, CREAM); W(13.2, 10, 14, 13, 2.9, CREAM); coping(13.2, 4.5, 14, 6.8, 2.9); coping(13.2, 10, 14, 13, 2.9);
    D(box(0.5, 0.28, 3.8, 13.6, 3.04, 8.4, STONE_L));
    for (let i = 0; i < 6; i++) L({ sph: true, r: R(0.32, 0.46), x: 13.6 + R(-0.2, 0.2), y: 3.25, z: 6.6 + i * 0.72, sx: 1.1, sy: 0.75, color: i % 3 === 1 ? VINE[2] : BOUG[i % 4], seg: 6 });
    DC(6, 14, 1.9, 5.7, 1.6, 2.0, '+x'); DC(6, 13.2, 1.9, 11.4, 1.6, 2.0, '-x');
    for (let i = 0; i < 7; i++) D(box(0.025, 1.9, 0.025, 14.1 + i * 0.12, 0.95, 10.06 + i * 0.1, IRON));
    D(box(0.9, 0.04, 0.04, 14.45, 1.85, 10.4, IRON, 0, -0.69, 0), box(0.9, 0.04, 0.04, 14.45, 0.15, 10.4, IRON, 0, -0.69, 0));

    // ===================== северо-восток: домик у бассейна и лимонария =====================
    W(13, 13, 20, 21, 4.0, WHITE); roof(13, 13, 20, 21, 4.0, 1.3, 0.45, { hip: true });
    DC(2, 13, 1.3, 17, 1.3, 2.6, '-x'); DC(0, 13, 2.1, 14.7, 1.0, 2.0, '-x'); DC(0, 13, 2.1, 19.3, 1.0, 2.0, '-x');
    a.awning(13, 2.85, 17, 2.4, 1.2, '-x', BLUE); DC(1, 16.4, 2.0, 13, 1.0, 2.0, '-z'); boug(14.3, 13, '-z', 1.6, 3.9, 2.4);
    W(13, 21, 20, 28, 5.2, SAND); roof(13, 21, 20, 28, 5.2, 1.6, 0.45, { hip: true });
    DC(3, 13, 2.4, 22.6, 1.5, 3.4, '-x'); DC(3, 13, 2.4, 26.6, 1.5, 3.4, '-x'); DC(2, 13, 1.3, 24.6, 1.3, 2.6, '-x');
    lemon(12.2, 22.6, 0.9); lemon(12.2, 26.6, 0.9);

    // ===================== западное крыло: дом-проход сад → точка A =====================
    W(-20, 4.5, -16.2, 5, 7, WHITE); W(-13.8, 4.5, -9, 5, 7, WHITE); lintel(-16.2, 4.5, -13.8, 5, 2.6, 7, WHITE);
    W(-20, 13.5, -14.2, 14, 7, WHITE); W(-11.8, 13.5, -9, 14, 7, WHITE); lintel(-14.2, 13.5, -11.8, 14, 2.6, 7, WHITE);
    W(-20, 5, -19.5, 13.5, 7, WHITE);
    W(-9.5, 5, -9, 7.8, 7, WHITE); W(-9.5, 10.2, -9, 13.5, 7, WHITE); lintel(-9.5, 7.8, -9, 10.2, 2.6, 7, WHITE);
    B(-19.5, 5, -9.5, 13.5, 0.3, 'plaster', 3.6, { tint: LIME });
    floor(-19.5, 5, -9.5, 13.5, 'cotto'); floor(-16.2, 4.5, -13.8, 5, 'cotto'); floor(-14.2, 13.5, -11.8, 14, 'cotto'); floor(-9.5, 7.8, -9, 10.2, 'cotto');
    roof(-20, 4.5, -9, 14, 7, 2.3, 0.5, { hip: true });
    arch(-15, 4.43, 'x', 2.4, 2.6, wc(WHITE)); arch(-15, 5.07, 'x', 2.4, 2.6, wc(LIME)); arch(-13, 13.43, 'x', 2.4, 2.6, wc(LIME)); arch(-13, 14.07, 'x', 2.4, 2.6, wc(WHITE));
    arch(-8.93, 9, 'z', 2.4, 2.6, wc(WHITE)); arch(-9.57, 9, 'z', 2.4, 2.6, wc(LIME));
    // фасады
    for (const x of [-18.2, -11]) { DC(0, x, 5.2, 4.5, 1.1, 2.2, '-z'); DC(3, x, 1.8, 4.5, 1.2, 2.5, '-z'); }
    DC(0, -15, 5.2, 4.5, 1.1, 2.2, '-z'); boug(-16.6, 4.5, '-z', 1.3, 6.8, 3.4);
    for (const z of [6.3, 12.2]) DC(0, -9, 5.2, z, 1.1, 2.2, '+x');
    DC(1, -9, 1.7, 6.3, 0.9, 1.9, '+x'); DC(1, -9, 1.7, 12.2, 0.9, 1.9, '+x'); boug(-9, 9, '+x', 1.5, 6.8, 3.8); lantern(-9, 2.9, 7.3, '+x');
    for (const x of [-18, -16, -10.4]) DC(0, x, 5.2, 14, 1.1, 2.2, '+z');
    DC(3, -17.2, 1.8, 14, 1.2, 2.5, '+z');
    // внутри: камин, длинный стол, книжный шкаф, люстра
    B(-19.5, 8.3, -18.9, 10.7, 3.6, 'plaster', 0, { tint: CREAM });
    D(box(0.06, 1.0, 1.4, -18.87, 0.6, 9.5, '#1a1410'), box(0.32, 0.12, 2.7, -18.75, 1.4, 9.5, WOOD), box(0.1, 1.25, 1.8, -18.86, 0.62, 9.5, STONE));
    D(box(0.04, 0.9, 1.25, -18.84, 0.6, 9.5, '#1a1410'), cyl(0.08, 0.9, -19.1, 0.2, 9.5, '#5a3a22', HP, 0, 0, 6), { sph: true, r: 0.18, x: -19.05, y: 0.3, z: 9.5, sy: 0.6, color: '#ff8a3a', seg: 6 });
    B(-15.6, 8.4, -12.4, 9.8, 0.78, 'none', 0, { hidden: true });
    D(box(3.3, 0.1, 1.5, -14, 0.74, 9.1, WOOD), box(0.12, 0.7, 1.3, -15.4, 0.35, 9.1, '#5a3a22'), box(0.12, 0.7, 1.3, -12.6, 0.35, 9.1, '#5a3a22'));
    for (const bz of [7.95, 10.25]) { B(-15.4, bz - 0.25, -12.6, bz + 0.25, 0.46, 'none', 0, { hidden: true }); D(box(2.8, 0.08, 0.45, -14, 0.44, bz, WOOD), box(0.1, 0.4, 0.4, -15.2, 0.2, bz, '#5a3a22'), box(0.1, 0.4, 0.4, -12.8, 0.2, bz, '#5a3a22')); }
    D(box(2.6, 0.012, 3.4, -14, 0.03, 9.1, '#8a3a2c'), box(2.2, 0.014, 3.0, -14, 0.031, 9.1, '#a8574a'));
    H(cyl(0.05, 0.28, -14.8, 0.93, 9.0, '#244a2a', 0, 0, 0, 6), cyl(0.05, 0.28, -13.3, 0.93, 9.3, '#5a2030', 0, 0, 0, 6), { sph: true, r: 0.25, x: -14, y: 0.86, z: 9.1, sy: 0.4, color: '#e8e0d0', seg: 8 });
    for (let i = 0; i < 5; i++) H({ sph: true, r: 0.075, x: -14 + R(-0.12, 0.12), y: 0.92, z: 9.1 + R(-0.12, 0.12), sy: 1.2, color: '#f6d23a', seg: 5 });
    H({ torus: true, r: 0.55, tube: 0.03, x: -14, y: 2.85, z: 9.1, rx: HP, color: IRON, seg: 10 }, cyl(0.015, 0.75, -14, 3.22, 9.1, IRON, 0, 0, 0, 4));
    B(-19.5, 12.95, -15.6, 13.5, 2.6, 'none', 0, { hidden: true });
    D(box(3.9, 2.6, 0.5, -17.55, 1.3, 13.22, '#5a3a22'));
    for (let sh = 0; sh < 4; sh++) {
      D(box(3.7, 0.05, 0.42, -17.55, 0.35 + sh * 0.6, 13.15, '#7a5634'));
      for (let i = 0; i < 12; i++) H(box(0.08, R(0.35, 0.48), 0.32, -19.3 + i * 0.3 + R(-0.04, 0.04), 0.58 + sh * 0.6, 13.12, ['#8a2a2a', '#2a4a6a', '#3a5a32', '#c8a050', '#5a3a5a'][(i + sh) % 5]));
    }
    amphora(-18.9, 5.7, 1.1); amphora(-10.2, 12.8, 1.0);
    DC(3, -15, 1.9, 13.5, 1.2, 2.4, '-z'); DC(5, -9.5, 1.9, 6.4, 0.6, 1.2, '-x'); DC(3, -18.2, 1.9, 5, 1.2, 2.4, '+z'); DC(3, -11, 1.9, 5, 1.2, 2.4, '+z');

    // ===================== точка A: терраса с бассейном и перголой =====================
    // пол террасы — без участка под бассейном (там вода и бортик)
    floor(-9, 4.5, 13.2, 8.8, 'cotto'); floor(-9, 8.8, 1, 13.4, 'cotto'); floor(10, 8.8, 13.2, 13.4, 'cotto'); floor(-9, 13.4, 13.2, 17.2, 'cotto');
    // бассейн
    B(1, 8.8, 10, 9.2, 0.16, 'flag'); B(1, 13, 10, 13.4, 0.16, 'flag'); B(1, 9.2, 1.4, 13, 0.16, 'flag'); B(9.6, 9.2, 10, 13, 0.16, 'flag');
    B(1.4, 9.2, 9.6, 13, 1.25, 'none', 0, { hidden: true, nr: true });
    a.ground.push({ kind: 'swim', x: 5.5, z: 11.1, w: 8.2, d: 3.8, y: 0.1 });
    for (const lx of [8.55, 9.15]) D(stick([lx, 0.1, 9.5], [lx, 0.72, 9.5], 0.022, 0.022, CHROME, 5), stick([lx, 0.72, 9.5], [lx, 0.86, 9.2], 0.022, 0.022, CHROME, 5), stick([lx, 0.86, 9.2], [lx, 0.74, 8.92], 0.022, 0.022, CHROME, 5), stick([lx, 0.74, 8.92], [lx, 0.16, 8.86], 0.022, 0.022, CHROME, 5));
    D({ torus: true, r: 0.42, tube: 0.13, x: 3.6, y: 0.13, z: 11.8, rx: HP, color: '#f27fa5', seg: 10 }, { torus: true, r: 0.36, tube: 0.12, x: 6.9, y: 0.12, z: 10.3, rx: HP, color: '#f6f2ea', seg: 10 });
    // пергола с длинным столом
    pergola([-7.6, -2.8], [6.2, 11, 15.8], 2.9);
    B(-6.0, 8.4, -4.4, 12.6, 0.78, 'none', 0, { hidden: true });
    D(box(1.6, 0.08, 4.3, -5.2, 0.74, 10.5, WOOD_L), box(1.4, 0.7, 0.1, -5.2, 0.35, 8.6, WOOD), box(1.4, 0.7, 0.1, -5.2, 0.35, 12.4, WOOD), box(1.3, 0.012, 4.1, -5.2, 0.785, 10.5, '#f2efe6'), box(0.5, 0.014, 4.1, -5.2, 0.792, 10.5, BLUE));
    for (const cz of [9.0, 10.5, 12.0]) for (const s of [-1, 1]) {
      const cx = -5.2 + s * 1.05;
      B(cx - 0.24, cz - 0.24, cx + 0.24, cz + 0.24, 0.48, 'none', 0, { hidden: true });
      D(box(0.46, 0.05, 0.46, cx, 0.46, cz, '#f0ece2'), box(0.06, 0.5, 0.46, cx + s * 0.2, 0.72, cz, '#f0ece2'), box(0.44, 0.44, 0.04, cx, 0.22, cz - 0.2, '#e4ded2'), box(0.44, 0.44, 0.04, cx, 0.22, cz + 0.2, '#e4ded2'));
    }
    H(cyl(0.05, 0.3, -5.4, 0.94, 9.6, '#244a2a', 0, 0, 0, 6), cyl(0.05, 0.3, -5.0, 0.94, 11.6, '#5a2030', 0, 0, 0, 6), { sph: true, r: 0.24, x: -5.2, y: 0.86, z: 10.6, sy: 0.4, color: '#e9e4d8', seg: 8 });
    for (let i = 0; i < 6; i++) H({ sph: true, r: 0.075, x: -5.2 + R(-0.12, 0.12), y: 0.92, z: 10.6 + R(-0.12, 0.12), sy: 1.2, color: i % 2 ? '#f6d23a' : '#ef9a2a', seg: 5 });
    // шезлонги, зонты, бар с грилем, кадка с оливой, ящики, амфоры
    lounger(2.6, 15.2); lounger(5.0, 15.2); lounger(7.4, 15.2);
    parasol(3.8, 15.9, '#f6efe2', BLUE); parasol(8.6, 15.9, '#f6efe2', '#e0582c');
    B(11.8, 13.6, 12.95, 15.9, 1.0, 'flag'); D(box(0.95, 0.08, 1.1, 12.37, 1.04, 15.1, '#3a3a3a'), box(0.85, 0.02, 1.0, 12.37, 1.09, 15.1, '#1e1e1e'));
    H(box(0.3, 0.25, 0.3, 12.3, 1.13, 14.0, '#e8e0d0'), cyl(0.05, 0.3, 12.6, 1.15, 14.2, '#244a2a', 0, 0, 0, 6));
    B(10.6, 5.3, 12.6, 7.3, 0.85, 'flag'); olive(11.6, 6.3, 0.95, false);
    stack(8.7, 6.0, 1.2); crate(-1.6, 6.2, 1.1); amphora(11.6, 11.0, 1.2); amphora(12.1, 11.8, 0.9); amphora(-8.4, 5.7, 1.0);
    for (const [fx, fz] of [[-8.6, 14.6], [-8.6, 15.4], [0.4, 16.7], [10.3, 16.8]]) flowers(fx, fz, 1.0, fx < 0 ? '#9a7ad0' : '#e0302c');
    a.letter('A', -0.8, 11.5, 3.0);
    // стенка-экран с настенным фонтаном напротив арки: из арки не простреливается вся терраса, выход — налево или направо
    W(1.4, 7.2, 6.2, 7.8, 2.6, CREAM); coping(1.4, 7.2, 6.2, 7.8, 2.6);
    B(3.0, 7.8, 4.6, 8.12, 0.62, 'flag');
    D({ sph: true, r: 0.3, x: 3.8, y: 1.55, z: 7.83, sz: 0.35, color: STONE_L, seg: 10 }, { sph: true, r: 0.12, x: 3.8, y: 1.5, z: 7.92, sz: 0.6, color: STONE, seg: 6 },
      cyl(0.035, 0.22, 3.8, 1.38, 8.0, '#b08a40', HP, 0, 0, 5), stick([3.8, 1.38, 8.1], [3.8, 0.62, 8.0], 0.03, 0.04, '#bfeaf2', 5), box(1.5, 0.03, 0.26, 3.8, 0.6, 7.96, '#58c2d6'));
    DC(5, 3.8, 1.6, 7.2, 0.6, 1.2, '-z'); boug(2.4, 7.2, '-z', 1.6, 2.6, 1.6); boug(5.4, 7.8, '+z', 1.4, 2.6, 1.4);
    // высокая лавровая изгородь между точкой и спавном спецназа: проходы по краям, без прострела насквозь
    B(-2.4, 17.2, 9.2, 17.8, 2.3, 'hedge'); B(12.4, 17.2, 13, 17.8, 2.3, 'hedge');
    for (let hx = -2.1; hx < 9.0; hx += 0.95) L({ sph: true, r: 0.55, x: hx + R(-0.1, 0.1), y: 2.25, z: 17.5, sx: 1.0, sy: 0.55, sz: 0.75, color: '#4a7a36', seg: 6, hiOnly: true });

    // ===================== розарий (между западным крылом и главным домом) =====================
    floor(-20, 14, -16, 19, 'sand', '#f7e2bf'); floor(-14, 14, -9, 19, 'sand', '#f7e2bf'); floor(-9, 17.2, -5, 19, 'sand', '#f7e2bf'); floor(-16, 14, -14, 19, 'cotto');
    B(-19.5, 14, -16.6, 14.8, 0.4, 'flag'); B(-11.4, 14, -9.6, 14.8, 0.4, 'flag');
    for (let i = 0; i < 6; i++) L({ sph: true, r: 0.38, x: -19.2 + i * 0.5, y: 0.65, z: 14.4, sy: 0.75, color: ['#f05a7a', '#ffffff', '#e8405a', '#ff9ab0'][i % 4], seg: 6 });
    for (let i = 0; i < 4; i++) L({ sph: true, r: 0.36, x: -11.2 + i * 0.5, y: 0.65, z: 14.4, sy: 0.75, color: ['#e8405a', '#ff9ab0', '#ffffff'][i % 3], seg: 6 });
    B(-15.5, 16.3, -14.5, 17.3, 1.15, 'flag');
    D({ sph: true, r: 0.45, x: -15, y: 1.55, z: 16.8, sy: 0.75, color: STONE_L, seg: 10 }, cyl(0.42, 0.12, -15, 1.83, 16.8, STONE_L, 0, 0, 0, 10), cyl(0.14, 0.25, -15, 1.25, 16.8, STONE_L, 0, 0, 0, 8));
    L({ sph: true, r: 0.42, x: -15, y: 2.05, z: 16.8, sy: 0.7, color: BOUG[2], seg: 6 });
    bench(-12.2, 18.1, -9.8, 18.7);
    cypress(-19.3, 17.3, 8.0); cypress(-8.4, 14.6, 7.6);

    // ===================== главный дом (северо-запад) =====================
    W(-20, 21.5, -5, 28, 8.2, OCHRE); roof(-20, 21.5, -5, 28, 8.2, 2.4, 0.6, { hip: true });
    const cols = [-18, -14.4, -10.8, -7.2];
    for (const cx of cols) W(cx - 0.25, 19, cx + 0.25, 19.5, 3.4, CREAM);
    W(-5.5, 19, -5, 19.5, 3.4, CREAM);
    B(-20, 19, -5, 21.5, 0.4, 'plaster', 3.4, { tint: CREAM });
    floor(-20, 19, -5, 21.5, 'cotto');
    const spans = [[-20, -18.25], [-17.75, -14.65], [-14.15, -11.05], [-10.55, -7.45], [-6.95, -5.5]];
    for (const [s0, s1] of spans) arch((s0 + s1) / 2, 18.93, 'x', s1 - s0, 3.4, wc(CREAM));
    D(box(15, 0.08, 0.1, -12.5, 4.62, 19.05, STONE_L), box(15, 0.06, 0.08, -12.5, 3.86, 19.05, STONE_L));
    for (let bx = -19.7; bx < -5.1; bx += 0.42) H(box(0.09, 0.72, 0.09, bx, 4.22, 19.05, STONE_L));
    a.lo.push(box(14.6, 0.72, 0.05, -12.5, 4.22, 19.05, '#d9d0bc'));
    flowers(-6.1, 19.3, 0.8, '#e0302c');
    for (const x of cols) DC(0, x, 5.9, 21.5, 1.15, 2.3, '-z');
    DC(2, -16.2, 1.35, 21.5, 1.4, 2.7, '-z'); DC(2, -9, 1.35, 21.5, 1.4, 2.7, '-z'); DC(0, -12.6, 1.9, 21.5, 1.0, 2.0, '-z'); DC(5, -19.2, 1.9, 21.5, 0.5, 1.0, '-z');
    lemon(-19.35, 21.0, 0.75); lemon(-5.95, 20.6, 0.82);
    DC(0, -5, 5.9, 23.4, 1.1, 2.2, '+x'); DC(0, -5, 5.9, 26.4, 1.1, 2.2, '+x'); DC(1, -5, 1.8, 23.4, 1.0, 2.0, '+x'); DC(2, -5, 1.35, 26.4, 1.3, 2.6, '+x');
    boug(-5, 22.2, '+x', 1.2, 8.0, 4.4); lantern(-5, 2.9, 25.2, '+x');
    D(box(0.8, 3.0, 0.8, -16.4, 10.1, 25.6, wc(OCHRE)), box(1.0, 0.12, 1.0, -16.4, 11.65, 25.6, TERRA_D), box(0.8, 3.0, 0.8, -8.2, 10.1, 24.2, wc(OCHRE)), box(1.0, 0.12, 1.0, -8.2, 11.65, 24.2, TERRA_D));
    for (const [cx, cz] of [[-16.4, 25.6], [-8.2, 24.2]]) D(cyl(0.12, 0.7, cx - 0.2, 11.77, cz, TERRA, 0, 0, HP, 6), cyl(0.12, 0.7, cx + 0.2, 11.77, cz, TERRA, 0, 0, HP, 6));

    // ===================== север: спавн спецназа =====================
    floor(-5, 17.2, 13, 28, 'sand', '#fff2dc');
    olive(3.2, 24.8, 1.25);
    fiat(9.0, 24.6);
    cypress(-3.6, 27.1, 8.6); cypress(0.6, 27.2, 9.2); cypress(6.6, 27.1, 8.8);
    bench(-4.4, 17.9, -2.2, 18.5); amphora(-4.4, 27.2, 1.1);
    // плоская тень под машинами (на низком качестве теней нет)
    D({ cyl: true, r: 1, h: 0.01, x: 9.0, y: 0.025, z: 24.6, sx: 0.78, sz: 1.45, color: '#6d5c48', seg: 10 }, { cyl: true, r: 1, h: 0.01, x: -9.3, y: 0.025, z: -24.5, sx: 0.8, sz: 1.75, color: '#6d5c48', seg: 10 });

    // ===================== 11.4: цоколи, балконы, мозаика, укрытия =====================
    // каменный цоколь по низу длинной стены (плитняк, без коллизии) с терракотовым пояском
    const vlPlinth = (x0, z0, x1, z1, h) => {
      h = h || 0.95; const ax = (x1 - x0) >= (z1 - z0);
      B(x0, z0, x1, z1, h, 'flag', 0, { solid: false, tint: '#e9dcc2' });
      D(box(ax ? x1 - x0 : x1 - x0 + 0.05, 0.07, ax ? z1 - z0 + 0.05 : z1 - z0, (x0 + x1) / 2, h + 0.035, (z0 + z1) / 2, TERRA_D));
    };
    vlPlinth(-12.1, -28, -3.2, -27.9); vlPlinth(3.2, -28, 13.1, -27.9);
    vlPlinth(-5.1, 27.9, 13.1, 28); vlPlinth(-20, -21.1, -19.9, 4.6); vlPlinth(-20, 13.9, -19.9, 21.6); vlPlinth(19.9, -22.1, 20, -17.9);
    // балкон с кованой решёткой и ящиком герани под окном (n — куда смотрит фасад)
    const vlBalc = (x, y, z, n, w) => {
      const N = NN[n], ux = N[0] ? 0 : 1, uz = N[0] ? 1 : 0, dp = 0.72, cx = x + N[0] * dp / 2, cz = z + N[1] * dp / 2;
      const fx = x + N[0] * (dp - 0.05), fz = z + N[1] * (dp - 0.05);
      D(box(ux ? w : dp, 0.14, uz ? w : dp, cx, y, cz, STONE_L)); H(box(ux ? w - 0.1 : 0.06, 0.06, uz ? w - 0.1 : 0.06, fx + N[0] * 0.03, y - 0.1, fz + N[1] * 0.03, TERRA_D));
      for (const sg of [-1, 1]) H(box(ux ? 0.14 : dp * 0.8, 0.32, uz ? 0.14 : dp * 0.8, cx + ux * sg * (w / 2 - 0.2) - N[0] * 0.06, y - 0.22, cz + uz * sg * (w / 2 - 0.2) - N[1] * 0.06, STONE));
      D(box(ux ? w : 0.05, 0.05, uz ? w : 0.05, fx, y + 0.86, fz, IRON));
      for (const sg of [-1, 1]) H(box(ux ? 0.05 : dp, 0.05, uz ? 0.05 : dp, x + ux * sg * (w / 2 - 0.03) + N[0] * dp / 2, y + 0.86, z + uz * sg * (w / 2 - 0.03) + N[1] * dp / 2, IRON));
      const k = Math.round(w / 0.18);
      for (let i = 0; i <= k; i++) { const t = -w / 2 + 0.05 + i * (w - 0.1) / k; H(box(0.025, 0.78, 0.025, fx + ux * t, y + 0.46, fz + uz * t, IRON)); }
      D(box(ux ? w * 0.82 : 0.2, 0.18, uz ? w * 0.82 : 0.2, fx + N[0] * 0.1, y + 0.98, fz + N[1] * 0.1, TERRA));
      const m = Math.max(2, Math.round(w / 0.45));
      // на низком/среднем — одна зелёная «подушка» в ящике, цветы герани — только на высоком
      L({ sph: true, r: 0.2, x: fx + N[0] * 0.1, y: y + 1.1, z: fz + N[1] * 0.1, sx: ux ? w * 2 : 1.2, sy: 0.75, sz: uz ? w * 2 : 1.2, color: '#4f7f34', seg: 6 });
      for (let i = 0; i < m * 3; i++) {
        const t = ((i + 0.5) / (m * 3) - 0.5) * w * 0.8;
        H({ sph: true, r: R(0.09, 0.13), x: fx + ux * t + N[0] * R(0.05, 0.2), y: y + R(1.2, 1.3), z: fz + uz * t + N[1] * R(0.05, 0.2), color: ['#e0302c', '#ff6f9a', '#d42438', '#ff4a5a'][i % 4], seg: 4 });
      }
    };
    vlBalc(8.2, 2.86, 4.5, '+z', 1.7); vlBalc(11.8, 2.86, 4.5, '+z', 1.7);
    vlBalc(18.6, 3.36, 9, '-x', 1.6); vlBalc(18.6, 3.36, -14.5, '-x', 1.6);
    vlBalc(-9, 4.06, 6.3, '+x', 1.6); vlBalc(-9, 4.06, 12.2, '+x', 1.6);
    vlBalc(-5, 4.76, 23.4, '+x', 1.6); vlBalc(-5, 4.76, 26.4, '+x', 1.6);
    // кадка-клумба из камня с майоликой: укрытие по пояс
    const vlPlanter = (x0, z0, x1, z1, h, flw) => {
      B(x0, z0, x1, z1, h, 'flag', 0, { tint: '#efe2c6' });
      D(box(x1 - x0 + 0.12, 0.08, z1 - z0 + 0.12, (x0 + x1) / 2, h + 0.04, (z0 + z1) / 2, TERRA_D));
      const n = Math.max(2, Math.round((x1 - x0) / 0.55));
      for (let i = 0; i < n; i++) L({ sph: true, r: 0.3, x: x0 + (i + 0.5) * (x1 - x0) / n, y: h + 0.18, z: (z0 + z1) / 2 + R(-0.08, 0.08), sx: 1.15, sy: 0.6, sz: 1.0, color: flw[i % flw.length], seg: 5 });
    };
    // спавн налётчиков: стенка-клумба с живой изгородью за воротами двора — от арки точки A спавн не простреливается
    B(-3.0, -21.3, 1.6, -20.4, 0.9, 'flag', 0, { tint: '#efe2c6' });
    B(-2.85, -21.2, 1.45, -20.5, 1.1, 'hedge', 0.9);
    D(box(4.72, 0.08, 1.02, -0.7, 0.94, -20.85, TERRA_D));
    for (let hx = -2.6; hx < 1.4; hx += 0.8) L({ sph: true, r: 0.5, x: hx + R(-0.1, 0.1), y: 1.98, z: -20.85, sx: 0.95, sy: 0.5, sz: 0.85, color: '#4a7a36', seg: 6, hiOnly: true });
    for (const lx of [-2.2, 0.8]) for (let i = 0; i < 4; i++) H({ sph: true, r: 0.07, x: lx + R(-0.5, 0.5), y: R(1.3, 1.9), z: -20.45 - (i % 2) * 0.8, sy: 1.25, color: '#f7d63a', seg: 4 });
    DC(5, -1.9, 0.48, -21.3, 0.42, 0.84, '-z'); DC(5, 0.5, 0.48, -21.3, 0.42, 0.84, '-z'); DC(5, -0.7, 0.48, -20.4, 0.42, 0.84, '+z');
    // точка A: клумба с лавандой между перголой и шезлонгами — укрытие от западного прохода спецназа
    vlPlanter(-1.2, 14.6, 0.6, 15.3, 0.95, ['#a494d0', '#9484c2', '#b6a6dc']);
    // майоликовая рамка вокруг буквы A и угловые плитки
    { const cx = -0.8, cz = 11.5, hs = 1.75, w = 0.2, Y = 0.028;
      for (const s of [-1, 1]) D(box(2 * hs + w, 0.012, w, cx, Y, cz + s * hs, BLUE), box(w, 0.012, 2 * hs - w, cx + s * hs, Y, cz, BLUE));
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) D(box(0.42, 0.014, 0.42, cx + sx * hs, Y + 0.002, cz + sz * hs, '#f2c52a'), box(0.22, 0.016, 0.22, cx + sx * hs, Y + 0.004, cz + sz * hs, '#f4efe4'));
      for (let i = 0; i < 14; i++) { const t = -hs + 0.25 + i * (2 * hs - 0.5) / 13; for (const s of [-1, 1]) H(box(0.09, 0.016, 0.09, cx + t, Y + 0.003, cz + s * hs, '#f4efe4', 0, Math.PI / 4), box(0.09, 0.016, 0.09, cx + s * hs, Y + 0.003, cz + t, '#f4efe4', 0, Math.PI / 4)); }
    }
    // мозаичное кольцо вокруг фонтана во дворе
    for (let i = 0; i < 28; i++) { const an = i / 28 * Math.PI * 2; H(box(0.34, 0.012, 0.34, Math.cos(an) * 2.55, 0.027, -6.5 + Math.sin(an) * 2.55, i % 2 ? '#f4efe4' : BLUE, 0, -an + Math.PI / 4, 0)); }
    for (let i = 0; i < 14; i++) { const an = (i + 0.5) / 14 * Math.PI * 2; H(box(0.22, 0.012, 0.22, Math.cos(an) * 2.95, 0.027, -6.5 + Math.sin(an) * 2.95, '#f2c52a', 0, -an + Math.PI / 4, 0)); }
    // бассейн: голубая мозаика по бортику
    for (const [x0, z0, x1, z1] of [[1.26, 9.06, 9.74, 9.2], [1.26, 13, 9.74, 13.14], [1.26, 9.2, 1.4, 13], [9.6, 9.2, 9.74, 13]]) D(box(x1 - x0, 0.012, z1 - z0, (x0 + x1) / 2, 0.166, (z0 + z1) / 2, '#3f8fc8'));
    // стены CT-спавна и двора налётчиков: бугенвиллея, фонари, лимоны в кадках
    boug(2.6, 28, '-z', 2.2, 4.4, 2.2); boug(10.6, 28, '-z', 1.8, 4.4, 1.9); lantern(-1.4, 3.1, 28, '-z'); lantern(4.6, 2.9, 28, '-z');
    lemon(-1.5, 27.1, 0.9); lemon(11.7, 27.0, 0.9);
    boug(-8.2, -28, '+z', 2.4, 4.4, 2.0); boug(8.6, -28, '+z', 2.0, 4.4, 1.8); lantern(-6.0, 2.9, -28, '+z'); lantern(6.0, 2.9, -28, '+z');
    // пергола: свисающие плети лозы и фонарики (только высокое качество)
    for (const px of [-7.6, -2.8]) for (let zz = 6.6; zz < 15.6; zz += 1.3) H(stick([px + R(-0.3, 0.3), 3.25, zz], [px + R(-0.3, 0.3), R(2.2, 2.6), zz + R(-0.2, 0.2)], 0.05, 0.03, VINE[1], 4));
    for (const lz of [8.6, 12.4]) H(cyl(0.012, 0.4, -5.2, 3.0, lz, IRON, 0, 0, 0, 3), box(0.18, 0.24, 0.18, -5.2, 2.7, lz, '#f3dfa8'), box(0.22, 0.03, 0.22, -5.2, 2.83, lz, IRON));

    // ===================== за стенами (только высокое качество) =====================
    // холм с сухой травой, кипарисы и соседние домики с черепичными крышами
    { const ring = []; for (let i = 0; i < 24; i++) { const an = i / 24 * Math.PI * 2; ring.push([Math.cos(an) * 150, Math.sin(an) * 150]); }
      H({ shape: true, pts: ring, holes: [[[-28.6, -20.6], [28.6, -20.6], [28.6, 20.6], [-28.6, 20.6]]], d: 0.1, x: 0, y: -0.05, z: 0, rz: HP, color: '#a59c68', cs: 1 }); }
    for (let i = 0; i < 26; i++) {
      const an = i / 26 * Math.PI * 2 + R(-0.1, 0.1), rr = R(27, 46), x = Math.cos(an) * rr * 0.95, z = Math.sin(an) * rr * 1.1, h = R(8, 13);
      H(cyl(0.15, 1.0, x, 0.5, z, '#4a3a2a', 0, 0, 0, 5), { sph: true, r: 1, x, y: h * 0.5 + 0.3, z, sx: R(0.9, 1.2), sy: h * 0.5, sz: 1, color: '#3b5a32', seg: 8 });
    }
    for (let i = 0; i < 14; i++) {
      const an = i / 14 * Math.PI * 2 + 0.2, rr = R(32, 52), x = Math.cos(an) * rr, z = Math.sin(an) * rr * 1.1;
      H({ sph: true, r: R(1.8, 2.6), x, y: 2.2, z, sy: 0.6, color: '#8f9c74', seg: 7 }, cyl(0.25, 1.6, x, 0.8, z, '#5d5446', 0, 0, 0, 5));
    }
    for (const [cx, cz, w, d, hh] of [[-31, -6, 8, 6, 6], [30, -21, 7, 6, 5.5], [-25, 33, 9, 7, 6.5], [25, 34, 8, 6, 5], [-4, -37, 9, 6, 6], [33, 9, 6, 8, 5.5], [-34, 14, 6, 7, 6]]) {
      H(box(w, hh, d, cx, hh / 2, cz, wc(R(0, 1) < 0.5 ? WHITE : CREAM)),
        { shape: true, pts: [[-d / 2 - 0.35, 0], [0, 1.7], [d / 2 + 0.35, 0]], d: w + 0.6, x: cx, y: hh, z: cz, color: '#b4603a', cs: 1 });
      H(box(0.9, 1.6, 0.04, cx, 1.6, cz + d / 2 + 0.02, BLUE), box(0.9, 1.0, 0.04, cx - w * 0.3, hh - 1.6, cz + d / 2 + 0.02, '#2a3a46'));
    }
  }

  // ---------- описание карт ----------
  G.DUEL_MAP = 'winter';
  G.MAPS = {
    dust: {
      name: 'Пыльный квартал', sub: 'Полдень · пустынный город', scale: 1.35, bounds: { x0: -40, x1: 40, z0: -32, z1: 32 },
      layout: layoutDust, ground: { mat: 'sand', size: [82, 66], repeat: 5 },
      matScale: { wall: 4, stucco: 3, concrete: 3, roof: 3, pave: 4, metal: 2, contRed: 2.6, contBlue: 2.6, contGreen: 2.6, crate: 1 },
      env: {
        skyTop: '#5d93cf', skyHor: '#e3e6df', skyLow: '#cdbb98', fog: '#d9d6c8', fogNear: 55, fogFar: 175,
        hemiSky: '#d6e6ff', hemiGround: '#9a7d55', hemiI: 0.78, sun: '#fff0d2', sunI: 0.95, sunPos: [30, 55, 20],
        sunSprite: [120, 160, 70], sunSpriteColor: '#fff4d6', sunSize: 40, clouds: '#ffffff', cloudN: 10, dune: '#c2a77a',
        vmTint: '#fff2dc'
      },
      spawnZones: [{ x0: -13, x1: 13, z0: 21.5, z1: 30.5, yaw: 0 }, { x0: -13, x1: 13, z0: -30.5, z1: -21.5, yaw: Math.PI }],
      sites: { A: { x0: -39, x1: -21, z0: 15.2, z1: 23.5 }, B: { x0: 17, x1: 39, z0: 15.2, z1: 21.5 } }
    },
    harbor: {
      name: 'Порт', sub: 'Закат · портовый квартал, апартаменты и причал', scale: 1, bounds: { x0: -44, x1: 44, z0: -34, z1: 34 },
      layout: layoutHarbor, ground: { mat: 'hbCobble', size: [104, 84], repeat: 3.2 }, lite: true,
      matScale: { plaster: 3.4, brick: 3, corrug: 3, concrete: 4, metal: 2, planks: 2.2, pave: 2.6, cotto: 1.6, crate: 1, contRed: 2.6, contBlue: 2.6, contOrange: 2.6, hbTeal: 2.6 },
      roofTex: 'coppo', blossomTex: 'leaves', blossomAmp: 0.13, scatterHi: true,
      env: {
        skyTop: '#2c3a72', skyHor: '#ffb07a', skyLow: '#b8806a', skyMid: '#c9708a', fog: '#e9a47f', fogNear: 55, fogFar: 230,
        hemiSky: '#b4bce6', hemiGround: '#b67a50', hemiI: 0.72, sun: '#ffb870', sunI: 1.15, sunPos: [58, 30, -22],
        sunSprite: [260, 48, -80], sunSpriteColor: '#ffd08a', sunSize: 70, clouds: '#ffc9a8', cloudN: 12,
        water: { level: -1.3, deep: '#1b2c4a', shallow: '#3d6880', sky: '#f2a283', x0: 44 }, vmTint: '#ffd9b0', noCity: true
      },
      spawnZones: [{ x0: -9, x1: 9, z0: 26.5, z1: 31.5, yaw: 0 }, { x0: -9, x1: 9, z0: -31.5, z1: -26.5, yaw: Math.PI }],
      sites: { A: { x0: 26, x1: 43, z0: 5, z1: 24 }, B: { x0: -40, x1: -20, z0: 4, z1: 20 } }
    },
    sakura: {
      name: 'Сакура', sub: 'Весна · старый квартал, 5 на 5', scale: 1, bounds: { x0: -42, x1: 42, z0: -34, z1: 34 },
      layout: layoutSakura, ground: { mat: 'jpstone', size: [100, 84], repeat: 4 }, lite: true, scatterHi: true, blossomAmp: 0.17,
      matScale: { stonewall: 2.6, plaster: 3.4, gravel: 4, planks: 2.4, tatami: 1.8, crate: 1 },
      env: {
        skyTop: '#5d9ade', skyMid: '#a8c8ec', skyHor: '#fbe3ea', skyLow: '#e3c4ce', fog: '#f1dde4', fogNear: 55, fogFar: 200,
        hemiSky: '#f4f0ff', hemiGround: '#8d7c74', hemiI: 0.84, sun: '#fff0e0', sunI: 0.95, sunPos: [-34, 52, -26],
        sunSprite: [-150, 115, -170], sunSpriteColor: '#fff4e6', sunSize: 42, clouds: '#ffffff', cloudN: 10,
        mount: '#5f7d84', rock: '#45605a', mountH: 0.5, fuji: [20, 320], vmTint: '#fff0ec'
      },
      spawnZones: [{ x0: -9, x1: 9, z0: 25, z1: 30, yaw: 0 }, { x0: -9, x1: 9, z0: -31, z1: -26, yaw: Math.PI }],
      sites: { A: { x0: -32, x1: -20, z0: 12, z1: 25 }, B: { x0: 24, x1: 34, z0: 7, z1: 23 } }
    },
    winter: {
      name: 'Зимний двор', sub: 'Снегопад · дуэли 1 на 1', scale: 1, bounds: { x0: -18, x1: 18, z0: -26, z1: 26 }, duel: true,
      layout: layoutWinter, ground: { mat: 'snow', size: [40, 56], repeat: 6 },
      matScale: { stonewall: 3, plaster: 3.4, brick: 3, planks: 3, jpstone: 4, crate: 1 },
      env: {
        skyTop: '#6f8fb8', skyMid: '#a9bfd8', skyHor: '#e9eef4', skyLow: '#d5dde6', fog: '#dde4ec', fogNear: 36, fogFar: 140,
        hemiSky: '#e4ecff', hemiGround: '#a9b3c0', hemiI: 0.92, sun: '#ffdcb4', sunI: 0.82, sunPos: [-35, 30, 22],
        sunSprite: [-180, 70, 120], sunSpriteColor: '#ffe6c8', sunSize: 46, clouds: '#f6f8fb', cloudN: 14,
        mount: '#9aa8ba', rock: '#7c8a9c', mountH: 0.9, vmTint: '#eef2ff'
      },
      spawnZones: [{ x0: -4, x1: 4, z0: 20.5, z1: 24, yaw: 0 }, { x0: -4, x1: 4, z0: -24, z1: -20.5, yaw: Math.PI }],
      sites: { A: { x0: -12, x1: -8, z0: 8, z1: 12 }, B: { x0: 8, x1: 12, z0: -12, z1: -8 } }
    },
    villa: {
      name: 'Вилла', sub: 'Средиземноморье · 2 на 2', small: true, scale: 1, bounds: { x0: -20, x1: 20, z0: -28, z1: 28 },
      layout: layoutVilla, ground: { mat: 'flag', size: [44, 60], repeat: 3.2, none: true }, lite: true,
      matScale: { plaster: 3.4, flag: 2.6, cotto: 1.6, sand: 4, hedge: 2, crate: 1 },
      roofTex: 'coppo', blossomTex: 'leaves', blossomAmp: 0.13, scatterHi: true,
      env: {
        skyTop: '#2f74cf', skyMid: '#7fb2ea', skyHor: '#f8e4c8', skyLow: '#e9d2ae', fog: '#f3e2c8', fogNear: 60, fogFar: 210,
        hemiSky: '#d2e4ff', hemiGround: '#b98f62', hemiI: 0.74, sun: '#ffd9a6', sunI: 1.12, sunPos: [-36, 33, -20],
        sunSprite: [-180, 92, -100], sunSpriteColor: '#fff0d2', sunSize: 44, clouds: '#fff7ec', cloudN: 5,
        mount: '#73906c', rock: '#948f76', mountH: 0.95, vmTint: '#ffe8cc'
      },
      spawnZones: [{ x0: -3, x1: 8.5, z0: 21.5, z1: 26.2, yaw: 0 }, { x0: -6, x1: 6, z0: -26.6, z1: -22.6, yaw: Math.PI }],
      sites: { A: { x0: -8.5, x1: 12.5, z0: 5.2, z1: 16.8 } },
      // точки сбора налётчиков на трёх маршрутах к единственной точке: сад, двор, переулок
      stages: [[-14.8, -3.2], [0, -12.5], [16.3, -0.4]]
    },
    range: {
      name: 'Полигон', sub: 'Обучение', scale: 1, bounds: { x0: -21, x1: 21, z0: -17, z1: 17 }, hidden: true,
      layout: layoutRange, ground: { mat: 'asphalt', size: [44, 36], repeat: 6 },
      matScale: { corrug: 3, concrete: 3, roof: 3, pave: 4, metal: 2, hazard: 2, planks: 3, contGreen: 2.6, contBlue: 2.6, crate: 1, sand: 4 },
      env: {
        skyTop: '#4f8fd2', skyHor: '#dfe6ea', skyLow: '#b9b2a4', fog: '#d6d9d6', fogNear: 50, fogFar: 170,
        hemiSky: '#d6e6ff', hemiGround: '#8f8678', hemiI: 0.8, sun: '#fff3dc', sunI: 1.0, sunPos: [26, 58, 18],
        sunSprite: [110, 170, 60], sunSpriteColor: '#fff6dc', sunSize: 38, clouds: '#ffffff', cloudN: 9, dune: '#8f8a7e', mount: '#6f7a78', vmTint: '#fff4e4'
      },
      spawnZones: [{ x0: -2, x1: 2, z0: 12, z1: 15, yaw: 0 }, { x0: -2, x1: 2, z0: 12, z1: 15, yaw: 0 }],
      sites: { A: { x0: -18, x1: -10, z0: -14, z1: -6 } },
      // данные обучения: манекены [x, z, yaw], центр ямы, точка закладки
      tut: { dummies: [[-5, -16, Math.PI], [0, -16, Math.PI], [5, -16, Math.PI], [13, -9, HP], [15, -11, HP], [-12, 9, -HP]], pit: [14, -10], look: [-12, 9], site: { x0: -18, x1: -10, z0: -14, z1: -6 } }
    }
  };

  // ---------- материалы ----------
  const NM = [];
  // материал с рельефом: карта нормалей строится из яркости текстуры
  const lam = (name, arg, ns) => {
    const m = new THREE.MeshLambertMaterial({ map: G.tex(name, arg), vertexColors: true });
    m.userData.nm = G.normalTex(name, arg); m.userData.ns = ns || 1;
    if (G.settings.quality === 'high') { m.normalMap = m.userData.nm; m.normalScale = new THREE.Vector2(m.userData.ns, m.userData.ns); }
    NM.push(m);
    return m;
  };
  const MAT_FACTORY = {
    wall: () => lam('wall', null, 1.3), stucco: () => lam('stucco', null, 0.7), concrete: () => lam('concrete', null, 0.8),
    roof: () => lam('roof', null, 1), pave: () => lam('pave', null, 1.2), metal: () => lam('metal', null, 0.9), crate: () => lam('crate', null, 1.2),
    contRed: () => lam('container', '#9c3b2c', 1.5), contBlue: () => lam('container', '#2f5d86', 1.5),
    contGreen: () => lam('container', '#4d6b3a', 1.5), contOrange: () => lam('container', '#c46a1f', 1.5),
    brick: () => lam('brick', null, 1.4), corrug: () => lam('corrug', '#7d8b95', 1.6), planks: () => lam('planks', null, 1.3),
    hazard: () => lam('hazard', null, 0.6), asphalt: () => lam('asphalt', null, 0.8), sand: () => lam('sand', null, 0.9),
    machiya: () => lam('machiya', null, 0.8), kura: () => lam('kura', null, 0.9), shrine: () => lam('shrine', null, 0.6),
    stonewall: () => lam('stonewall', null, 1.5), plaster: () => lam('plaster', null, 0.4), jpstone: () => lam('jpstone', null, 1.0),
    gravel: () => lam('gravel', null, 0.8), bamboo: () => lam('bamboo', null, 1.3), tatami: () => lam('tatami', null, 0.5),
    koshi: () => lam('koshi', null, 1.4), hedge: () => lam('hedge', null, 1.2),
    snow: () => lam('snow', null, 0.5),
    flag: () => lam('flag', null, 0.9), cotto: () => lam('cotto', null, 0.9)
  };
  G.mapDetail = (on) => {
    for (const m of NM) { m.normalMap = on ? m.userData.nm : null; if (on) m.normalScale = new THREE.Vector2(m.userData.ns, m.userData.ns); m.needsUpdate = true; }
  };
  // дальний фон за картой (горы, дюны, город, облака) — только на высоком качестве
  const BACKDROP = [], LITE = [];
  G.mapBackdrop = (on) => { for (const o of BACKDROP) o.visible = !!on; for (const o of LITE) o.visible = !on; };
  // упрощённая копия декора для низкого/среднего качества (карты с def.lite): меньше сегментов, без мелочи
  function litePart(p) {
    if (p.hiOnly) return null;
    const sx = p.sx || 1, sy = p.sy || 1, sz = p.sz || 1;
    if (p.cyl) {
      const r = Math.max(p.r, p.r2 != null ? p.r2 : p.r) * Math.max(sx, sz), seg = p.seg || 10, h = p.h * sy;
      if (r < 0.025 || (r < 0.03 && h < 0.6)) return null;
      const s = Math.min(seg, r < 0.1 ? 3 : r < 0.22 ? 4 : r < 0.6 ? Math.max(5, Math.round(seg * 0.55)) : Math.max(8, Math.round(seg * 0.7)));
      // тонкие длинные палки (стволы, ветви, коньки, гребни): торцы не видны — без крышек
      const open = p.open || (r < 0.3 && h > r * 2.5);
      return s === seg && open === !!p.open ? p : Object.assign({}, p, { seg: s, open });
    }
    if (p.sph) {
      const r = p.r * Math.max(sx, sy, sz), seg = p.seg || 10;
      if (r < 0.085) return null;
      // по высоте не меньше 4 поясов: иначе крона читается «ромбом»
      const s = Math.min(seg, r < 1.2 ? 5 : Math.max(6, Math.round(seg * 0.75)));
      return Object.assign({}, p, { seg: s, hs: r < 0.3 ? 3 : 4 });
    }
    if (p.torus) { const s = Math.max(8, Math.round((p.seg || 14) * 0.6)); return Object.assign({}, p, { seg: s }); }
    if (p.shape) return (p.cs || 5) > 3 ? Object.assign({}, p, { cs: 3 }) : p;
    if (p.w != null) { const d = [p.w, p.h, p.d].sort((a, b) => a - b); if (d[2] < 0.12 || d[1] < 0.04) return null; }
    return p;
  }
  const liteList = (list) => { const out = []; for (const p of list) { const q = litePart(p); if (q) out.push(q); } return out; };
  const matCache = {};
  const getMat = (k) => matCache[k] || (matCache[k] = MAT_FACTORY[k]());
  const _tc = new THREE.Color();

  function addBox(buf, b, scale) {
    const { x0, y0, z0, x1, y1, z1 } = b;
    const faces = [
      { n: [1, 0, 0], c: [[x1, y0, z0], [x1, y0, z1], [x1, y1, z1], [x1, y1, z0]] },
      { n: [-1, 0, 0], c: [[x0, y0, z1], [x0, y0, z0], [x0, y1, z0], [x0, y1, z1]] },
      { n: [0, 1, 0], c: [[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]] },
      { n: [0, -1, 0], c: [[x0, y0, z1], [x1, y0, z1], [x1, y0, z0], [x0, y0, z0]] },
      { n: [0, 0, 1], c: [[x1, y0, z1], [x0, y0, z1], [x0, y1, z1], [x1, y1, z1]] },
      { n: [0, 0, -1], c: [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0]] }
    ];
    for (const f of faces) {
      if (f.n[1] === -1 && y0 <= 0.001 && y0 >= -0.001) continue;
      if (y1 - y0 < 0.05 && f.n[1] !== 1) continue; // тонкие «наклейки» — только верх
      let c = f.c;
      const ax = c[1][0] - c[0][0], ay = c[1][1] - c[0][1], az = c[1][2] - c[0][2];
      const bx = c[2][0] - c[0][0], by = c[2][1] - c[0][1], bz = c[2][2] - c[0][2];
      const cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
      if (cx * f.n[0] + cy * f.n[1] + cz * f.n[2] < 0) c = [c[0], c[3], c[2], c[1]];
      const base = buf.pos.length / 3;
      for (const v of c) {
        buf.pos.push(v[0], v[1], v[2]);
        buf.nor.push(f.n[0], f.n[1], f.n[2]);
        let u, w;
        if (b.uv === 'face') {
          if (f.n[0] !== 0) { u = (v[2] - z0) / (z1 - z0); w = (v[1] - y0) / (y1 - y0); }
          else if (f.n[1] !== 0) { u = (v[0] - x0) / (x1 - x0); w = (v[2] - z0) / (z1 - z0); }
          else { u = (v[0] - x0) / (x1 - x0); w = (v[1] - y0) / (y1 - y0); }
        } else {
          if (f.n[0] !== 0) { u = v[2] / scale; w = v[1] / scale; }
          else if (f.n[1] !== 0) { u = v[0] / scale; w = v[2] / scale; }
          else { u = v[0] / scale; w = v[1] / scale; }
        }
        buf.uv.push(u, w);
        let ao = 1;
        if (f.n[1] === 0 && v[1] <= 0.01 && y0 <= 0.01) ao = 0.6;
        else if (f.n[1] === 0 && v[1] < 1.2 && y0 <= 0.01) ao = 0.6 + 0.4 * (v[1] / 1.2);
        if (f.n[1] === -1) ao = 0.72;
        buf.col.push(ao, ao, ao);
      }
      buf.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }

  // ---------- борьба с мерцанием совпадающих плоскостей (z-fighting) ----------
  // Если грань коробки лежит в той же плоскости, что и грань более ранней коробки (и смотрит туда же),
  // а материалы/развёртка отличаются — на телефоне они «дерутся» за пиксели. Сдвигаем такую грань
  // (только визуально, коллизии не меняются) на несколько миллиметров наружу, слоями.
  const ZSTEP = 0.009, ZEPS = 0.004;
  function deZFight(list) {
    const bucket = new Map(), out = [];
    const sides = (b, thin) => {
      const r = [{ k: 'py', ax: 1, s: 1, v: b.y1, a0: b.x0, a1: b.x1, b0: b.z0, b1: b.z1 }];
      if (!thin) r.push(
        { k: 'px', ax: 0, s: 1, v: b.x1, a0: b.y0, a1: b.y1, b0: b.z0, b1: b.z1 }, { k: 'nx', ax: 0, s: -1, v: b.x0, a0: b.y0, a1: b.y1, b0: b.z0, b1: b.z1 },
        { k: 'pz', ax: 2, s: 1, v: b.z1, a0: b.x0, a1: b.x1, b0: b.y0, b1: b.y1 }, { k: 'nz', ax: 2, s: -1, v: b.z0, a0: b.x0, a1: b.x1, b0: b.y0, b1: b.y1 });
      return r;
    };
    for (const b of list) {
      const thin = b.y1 - b.y0 < 0.05, off = {};
      const fs = sides(b, thin);
      for (const f of fs) {
        let layer = 0;
        const kk = Math.round(f.v / 0.01);
        for (let d = -1; d <= 1; d++) {
          const L = bucket.get(f.ax + '|' + f.s + '|' + (kk + d)); if (!L) continue;
          for (const q of L) {
            if (Math.abs(q.v - f.v) > ZEPS) continue;
            if (q.mat === b.mat && q.uv !== 'face' && b.uv !== 'face') continue;
            if (Math.min(q.a1, f.a1) - Math.max(q.a0, f.a0) <= 0.01 || Math.min(q.b1, f.b1) - Math.max(q.b0, f.b0) <= 0.01) continue;
            layer = Math.max(layer, q.layer + 1);
          }
        }
        if (layer) off[f.k] = layer * ZSTEP;
        f.layer = layer; f.mat = b.mat; f.uv = b.uv;
        const key = f.ax + '|' + f.s + '|' + kk;
        if (!bucket.has(key)) bucket.set(key, []);
        bucket.get(key).push(f);
      }
      if (Object.keys(off).length) {
        const nb = Object.assign({}, b);
        nb.x1 += off.px || 0; nb.x0 -= off.nx || 0; nb.y1 += off.py || 0; nb.z1 += off.pz || 0; nb.z0 -= off.nz || 0;
        out.push(nb);
      } else out.push(b);
    }
    return out;
  }
  // декоративные брусья/доски вровень со стеной — чуть «выдвигаем» из стены
  function unflushDecor(dec, list) {
    if (!dec || !dec.length) return;
    const planes = { 0: new Map(), 1: new Map(), 2: new Map() };
    const put = (ax, v, a0, a1, b0, b1, c) => { const k = Math.round(v / 0.01); if (!planes[ax].has(k)) planes[ax].set(k, []); planes[ax].get(k).push([v, a0, a1, b0, b1, c]); };
    const putBox = (b, c) => {
      put(0, b.x0, b.y0, b.y1, b.z0, b.z1, c); put(0, b.x1, b.y0, b.y1, b.z0, b.z1, c);
      put(2, b.z0, b.x0, b.x1, b.y0, b.y1, c); put(2, b.z1, b.x0, b.x1, b.y0, b.y1, c);
      put(1, b.y1, b.x0, b.x1, b.z0, b.z1, c);
    };
    for (const b of list) putBox(b, null);
    const hit = (ax, v, a0, a1, b0, b1, c) => {
      const k = Math.round(v / 0.01);
      for (let d = -1; d <= 1; d++) { const L = planes[ax].get(k + d); if (!L) continue;
        for (const q of L) if (q[5] !== c && Math.abs(q[0] - v) < ZEPS && Math.min(q[2], a1) - Math.max(q[1], a0) > 0.005 && Math.min(q[4], b1) - Math.max(q[3], b0) > 0.005) return true; }
      return false;
    };
    for (const d of dec) {
      if (d.cyl || d.sph || d.torus || d.shape || d.rx || d.ry || d.rz || d.w == null || d._uf) continue;
      let x0 = d.x - d.w / 2, x1 = d.x + d.w / 2, y0 = d.y - d.h / 2, y1 = d.y + d.h / 2, z0 = d.z - d.d / 2, z1 = d.z + d.d / 2;
      const c = d.color || '#fff';
      if (hit(0, x0, y0, y1, z0, z1, c) || hit(0, x1, y0, y1, z0, z1, c) || hit(2, z0, x0, x1, y0, y1, c) || hit(2, z1, x0, x1, y0, y1, c) || hit(1, y1, x0, x1, z0, z1, c)) {
        const e = Math.min(0.01, d.w * 0.2, d.d * 0.2);
        d.w += 2 * e; d.d += 2 * e; d.h += 0.012; d.y += 0.006; d._uf = true;
        x0 -= e; x1 += e; z0 -= e; z1 += e; y1 += 0.012;
      }
      putBox({ x0, x1, y0, y1, z0, z1 }, c);
    }
  }

  // ===================== реализм: фаски, карнизы, контактные тени, мелочи на земле =====================
  // какие грани коробки упираются в соседнюю коробку (там фаску не делаем — была бы щель)
  function computeAttach(list) {
    const idx = new Map();
    const add = (k, e) => { if (!idx.has(k)) idx.set(k, []); idx.get(k).push(e); };
    list.forEach((b, i) => {
      add('x' + Math.round(b.x0 * 50), [i, -1, b.x0, b.y0, b.y1, b.z0, b.z1]); add('x' + Math.round(b.x1 * 50), [i, 1, b.x1, b.y0, b.y1, b.z0, b.z1]);
      add('z' + Math.round(b.z0 * 50), [i, -1, b.z0, b.x0, b.x1, b.y0, b.y1]); add('z' + Math.round(b.z1 * 50), [i, 1, b.z1, b.x0, b.x1, b.y0, b.y1]);
      add('y' + Math.round(b.y1 * 50), [i, 1, b.y1, b.x0, b.x1, b.z0, b.z1]); add('y' + Math.round(b.y0 * 50), [i, -1, b.y0, b.x0, b.x1, b.z0, b.z1]);
    });
    const att = list.map(() => ({}));
    const near = (ax, v) => { const k = Math.round(v * 50), r = []; for (let d = -1; d <= 1; d++) { const L = idx.get(ax + (k + d)); if (L) r.push(...L); } return r; };
    list.forEach((b, i) => {
      const chk = (ax, s, v, a0, a1, c0, c1, key) => {
        for (const q of near(ax, v)) {
          if (q[0] === i || q[1] !== -s || Math.abs(q[2] - v) > 0.02) continue;
          if (Math.min(a1, q[4]) - Math.max(a0, q[3]) > 0.02 && Math.min(c1, q[6]) - Math.max(c0, q[5]) > 0.02) { att[i][key] = true; return; }
        }
        // грань утоплена внутрь другой коробки
        for (const o of list) {
          if (o === b) continue;
          if (ax === 'x' && o.x0 < v - 0.01 && o.x1 > v + 0.01 && o.y0 <= a0 + 0.01 && o.y1 >= Math.min(a1, a0 + 0.6) && o.z0 < c1 && o.z1 > c0 && Math.min(c1, o.z1) - Math.max(c0, o.z0) > 0.3) { att[i][key] = true; return; }
          if (ax === 'z' && o.z0 < v - 0.01 && o.z1 > v + 0.01 && o.y0 <= c0 + 0.01 && o.y1 >= Math.min(c1, c0 + 0.6) && o.x0 < a1 && o.x1 > a0 && Math.min(a1, o.x1) - Math.max(a0, o.x0) > 0.3) { att[i][key] = true; return; }
        }
      };
      chk('x', -1, b.x0, b.y0, b.y1, b.z0, b.z1, 'nx'); chk('x', 1, b.x1, b.y0, b.y1, b.z0, b.z1, 'px');
      chk('z', -1, b.z0, b.x0, b.x1, b.y0, b.y1, 'nz'); chk('z', 1, b.z1, b.x0, b.x1, b.y0, b.y1, 'pz');
      chk('y', 1, b.y1, b.x0, b.x1, b.z0, b.z1, 'py');
    });
    return att;
  }
  const _fv = new THREE.Vector3(), _fa = new THREE.Vector3(), _fb = new THREE.Vector3();
  // многоугольник с нормалью n (веер), мировая развёртка и запечённое затенение как в addBox
  function pushPoly(buf, vs, n, scale, y0, fb) {
    _fa.set(vs[1][0] - vs[0][0], vs[1][1] - vs[0][1], vs[1][2] - vs[0][2]);
    _fb.set(vs[2][0] - vs[0][0], vs[2][1] - vs[0][1], vs[2][2] - vs[0][2]);
    _fv.crossVectors(_fa, _fb);
    if (_fv.x * n[0] + _fv.y * n[1] + _fv.z * n[2] < 0) vs = vs.slice().reverse();
    const base = buf.pos.length / 3, ax = Math.abs(n[0]), ay = Math.abs(n[1]), az = Math.abs(n[2]);
    for (const v of vs) {
      buf.pos.push(v[0], v[1], v[2]); buf.nor.push(n[0], n[1], n[2]);
      let u, w;
      if (fb) {
        const fx = (v[0] - fb.x0) / (fb.x1 - fb.x0), fy = (v[1] - fb.y0) / (fb.y1 - fb.y0), fz = (v[2] - fb.z0) / (fb.z1 - fb.z0);
        if (ay >= ax && ay >= az) { u = fx; w = fz; } else if (ax >= az) { u = fz; w = fy; } else { u = fx; w = fy; }
      } else if (ay >= ax && ay >= az) { u = v[0] / scale; w = v[2] / scale; }
      else if (ax >= az) { u = v[2] / scale; w = v[1] / scale; }
      else { u = v[0] / scale; w = v[1] / scale; }
      buf.uv.push(u, w);
      let ao = 1;
      if (n[1] < -0.5) ao = 0.72;
      else if (n[1] < 0.5 && y0 <= 0.01) ao = v[1] <= 0.01 ? 0.6 : v[1] < 1.2 ? 0.6 + 0.4 * (v[1] / 1.2) : 1;
      buf.col.push(ao, ao, ao);
    }
    for (let i = 1; i < vs.length - 1; i++) buf.idx.push(base, base + i, base + i + 1);
  }
  const S2 = Math.SQRT1_2, S3 = 1 / Math.sqrt(3);
  // коробка с фасками на вертикальных и верхних рёбрах
  function addBoxCh(buf, b, scale, c) {
    const { x0, y0, z0, x1, y1, z1 } = b, yt = y1 - c, fb = b.uv === 'face' ? b : null;
    pushPoly(buf, [[x0 + c, y1, z0 + c], [x1 - c, y1, z0 + c], [x1 - c, y1, z1 - c], [x0 + c, y1, z1 - c]], [0, 1, 0], scale, y0, fb);
    pushPoly(buf, [[x1, y0, z0 + c], [x1, y0, z1 - c], [x1, yt, z1 - c], [x1, yt, z0 + c]], [1, 0, 0], scale, y0, fb);
    pushPoly(buf, [[x0, y0, z0 + c], [x0, y0, z1 - c], [x0, yt, z1 - c], [x0, yt, z0 + c]], [-1, 0, 0], scale, y0, fb);
    pushPoly(buf, [[x0 + c, y0, z1], [x1 - c, y0, z1], [x1 - c, yt, z1], [x0 + c, yt, z1]], [0, 0, 1], scale, y0, fb);
    pushPoly(buf, [[x0 + c, y0, z0], [x1 - c, y0, z0], [x1 - c, yt, z0], [x0 + c, yt, z0]], [0, 0, -1], scale, y0, fb);
    if (y0 > 0.001) pushPoly(buf, [[x0 + c, y0, z0], [x1 - c, y0, z0], [x1, y0, z0 + c], [x1, y0, z1 - c], [x1 - c, y0, z1], [x0 + c, y0, z1], [x0, y0, z1 - c], [x0, y0, z0 + c]], [0, -1, 0], scale, y0, fb);
    // вертикальные фаски
    for (const [sx, sz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
      const X = sx > 0 ? x1 : x0, Z = sz > 0 ? z1 : z0;
      pushPoly(buf, [[X, y0, Z - sz * c], [X - sx * c, y0, Z], [X - sx * c, yt, Z], [X, yt, Z - sz * c]], [sx * S2, 0, sz * S2], scale, y0, fb);
      pushPoly(buf, [[X, yt, Z - sz * c], [X - sx * c, yt, Z], [X - sx * c, y1, Z - sz * c]], [sx * S3, S3, sz * S3], scale, y0, fb);
    }
    // верхние фаски
    pushPoly(buf, [[x1, yt, z0 + c], [x1, yt, z1 - c], [x1 - c, y1, z1 - c], [x1 - c, y1, z0 + c]], [S2, S2, 0], scale, y0, fb);
    pushPoly(buf, [[x0, yt, z0 + c], [x0, yt, z1 - c], [x0 + c, y1, z1 - c], [x0 + c, y1, z0 + c]], [-S2, S2, 0], scale, y0, fb);
    pushPoly(buf, [[x0 + c, yt, z1], [x1 - c, yt, z1], [x1 - c, y1, z1 - c], [x0 + c, y1, z1 - c]], [0, S2, S2], scale, y0, fb);
    pushPoly(buf, [[x0 + c, yt, z0], [x1 - c, yt, z0], [x1 - c, y1, z0 + c], [x0 + c, y1, z0 + c]], [0, S2, -S2], scale, y0, fb);
  }
  const CH_MATS = { wall: 1, stucco: 1, brick: 1, concrete: 1, metal: 1, crate: 1, contRed: 1, contBlue: 1, contGreen: 1, contOrange: 1, corrug: 1, stonewall: 1, hedge: 2 };
  const chamferOf = (b, a) => {
    const k = b.ch || CH_MATS[b.mat]; if (!k || (b.uv === 'face' && b.mat !== 'crate')) return 0;
    const w = b.x1 - b.x0, d = b.z1 - b.z0, h = b.y1 - b.y0, m = Math.min(w, d, h);
    if (m < 0.1 || (!a.chAll && (m < 0.28 || a.px || a.nx || a.pz || a.nz))) return 0;
    if (b.base) return 0.03;
    return k === 2 ? Math.min(0.16, m * 0.2) : Math.min(0.055, m * 0.07);
  };
  // каменные/бетонные карнизы на высоких стенах
  const CAP = { wall: '#b6a27d', stucco: '#d5c4a2', brick: '#7c776f', concrete: '#a19f98', corrug: '#6d7277' };
  function wallCaps(list, att, out) {
    list.forEach((b, i) => {
      const col = CAP[b.mat], h = b.y1 - b.y0;
      if (!col || h < 1.6 || b.y0 > 0.3 || att[i].py || b.uv === 'face') return;
      const o = b.mat === 'corrug' ? 0.03 : 0.06, t = b.mat === 'corrug' ? 0.06 : 0.12;
      const w = b.x1 - b.x0 + (att[i].nx ? 0 : o) + (att[i].px ? 0 : o), d = b.z1 - b.z0 + (att[i].nz ? 0 : o) + (att[i].pz ? 0 : o);
      const cx = (b.x0 - (att[i].nx ? 0 : o) + b.x1 + (att[i].px ? 0 : o)) / 2, cz = (b.z0 - (att[i].nz ? 0 : o) + b.z1 + (att[i].pz ? 0 : o)) / 2;
      out.push({ w, h: t, d, x: cx, y: b.y1 + t / 2 - 0.001, z: cz, color: col });
      // тонкая полоска тени под карнизом
      if (b.mat !== 'corrug') out.push({ w: w - o * 0.6, h: 0.05, d: d - o * 0.6, x: cx, y: b.y1 - 0.02, z: cz, color: shade(col, 0.72) });
    });
  }
  const shade = (hex, k) => { const c = new THREE.Color(hex).multiplyScalar(k); return '#' + c.getHexString(); };
  // мягкие контактные тени у основания стен и ящиков
  function contactAO(list, att, group) {
    const P = [], C = [], I = [];
    const quad = (pts, al) => { const b = P.length / 3; for (let k = 0; k < 4; k++) { P.push(pts[k][0], 0.05, pts[k][1]); C.push(0, 0, 0, al[k]); } I.push(b, b + 2, b + 1, b, b + 3, b + 2); };
    list.forEach((b, i) => {
      const h = b.y1 - b.y0;
      if (b.y0 > 0.02 || h < 0.3 || b.mat === 'roof') return;
      const A = Math.min(0.5, 0.2 + h * 0.07), W = Math.min(1.1, 0.35 + h * 0.12), a = att[i];
      const { x0, x1, z0, z1 } = b;
      if (!a.pz) quad([[x0, z1], [x1, z1], [x1, z1 + W], [x0, z1 + W]], [A, A, 0, 0]);
      if (!a.nz) quad([[x1, z0], [x0, z0], [x0, z0 - W], [x1, z0 - W]], [A, A, 0, 0]);
      if (!a.px) quad([[x1, z1], [x1, z0], [x1 + W, z0], [x1 + W, z1]], [A, A, 0, 0]);
      if (!a.nx) quad([[x0, z0], [x0, z1], [x0 - W, z1], [x0 - W, z0]], [A, A, 0, 0]);
      // углы
      if (!a.pz && !a.px) quad([[x1, z1], [x1, z1 + W], [x1 + W * 0.8, z1 + W * 0.8], [x1 + W, z1]], [A, 0, 0, 0]);
      if (!a.pz && !a.nx) quad([[x0, z1], [x0 - W, z1], [x0 - W * 0.8, z1 + W * 0.8], [x0, z1 + W]], [A, 0, 0, 0]);
      if (!a.nz && !a.px) quad([[x1, z0], [x1 + W, z0], [x1 + W * 0.8, z0 - W * 0.8], [x1, z0 - W]], [A, 0, 0, 0]);
      if (!a.nz && !a.nx) quad([[x0, z0], [x0, z0 - W], [x0 - W * 0.8, z0 - W * 0.8], [x0 - W, z0]], [A, 0, 0, 0]);
    });
    if (!P.length) return;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(C, 4));
    g.setIndex(I); g.computeBoundingSphere();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
    m.renderOrder = -1; m.matrixAutoUpdate = false;
    group.add(m);
  }
  // пилястры и цоколь на длинных глухих стенах (только визуально, без коллизий)
  const PIER = { wall: { w: 0.75, p: 0.2, base: 'concrete' }, brick: { w: 0.7, p: 0.18, base: 'concrete' }, stucco: { w: 0.6, p: 0.12 }, corrug: { w: 0.16, p: 0.12, mat: 'metal', post: true } };
  function genTrims(list, api, bounds) {
    const out = [];
    const clash = (x0, x1, y0, y1, z0, z1, self) => {
      for (const o of list) if (o !== self && o.x0 < x1 && o.x1 > x0 && o.z0 < z1 && o.z1 > z0 && o.y0 < y1 && o.y1 > y0) return true;
      for (const d of api.decals) { const hw = d.w / 2 + 0.2; if (d.y - d.h / 2 < y1 && d.y + d.h / 2 > y0 && d.x > x0 - hw && d.x < x1 + hw && d.z > z0 - hw && d.z < z1 + hw) return true; }
      for (const a of api.awnings) { const hw = (a.w || 3) / 2 + 0.4; if (a.x > x0 - hw && a.x < x1 + hw && a.z > z0 - hw && a.z < z1 + hw) return true; }
      for (const d of api.decor) { const r = Math.max(d.w || 0, d.d || 0, (d.r || 0) * 2, 0.3) / 2 + 0.15; if (d.x > x0 - r && d.x < x1 + r && d.z > z0 - r && d.z < z1 + r && (d.y || 0) < y1 + 0.3) return true; }
      return false;
    };
    const inB = (x, z) => x > bounds.x0 && x < bounds.x1 && z > bounds.z0 && z < bounds.z1;
    for (const b of list) {
      const P = PIER[b.mat];
      if (!P || b.uv === 'face' || b.y0 > 0.02 || b.hidden || !b.solid) continue;
      const h = b.y1 - b.y0, lx = b.x1 - b.x0, lz = b.z1 - b.z0, alongX = lx >= lz, L = alongX ? lx : lz, T = alongX ? lz : lx;
      if (h < 2.2 || L < 6 || T > 2.6) continue;
      const n = Math.floor(L / (P.post ? 3.2 : 6.2)); if (n < 1) continue;
      const step = L / (n + 1);
      for (const side of [-1, 1]) {
        const face = alongX ? (side < 0 ? b.z0 : b.z1) : (side < 0 ? b.x0 : b.x1);
        const mid = alongX ? (b.x0 + b.x1) / 2 : (b.z0 + b.z1) / 2;
        if (!(alongX ? inB(mid, face + side * 1.2) : inB(face + side * 1.2, mid))) continue;
        const f0 = side > 0 ? face - 0.04 : face - P.p, f1 = side > 0 ? face + P.p : face + 0.04;
        for (let k = 1; k <= n; k++) {
          const c = (alongX ? b.x0 : b.z0) + k * step, a0 = c - P.w / 2, a1 = c + P.w / 2;
          const bx = alongX ? { x0: a0, x1: a1, z0: f0, z1: f1 } : { x0: f0, x1: f1, z0: a0, z1: a1 };
          // проверяем зону перед стеной чуть шире пилястры
          const tz = alongX ? [side > 0 ? face + 0.01 : face - P.p - 0.25, side > 0 ? face + P.p + 0.25 : face - 0.01] : null;
          const tx = alongX ? null : [side > 0 ? face + 0.01 : face - P.p - 0.25, side > 0 ? face + P.p + 0.25 : face - 0.01];
          const cx0 = alongX ? a0 - 0.1 : tx[0], cx1 = alongX ? a1 + 0.1 : tx[1], cz0 = alongX ? tz[0] : a0 - 0.1, cz1 = alongX ? tz[1] : a1 + 0.1;
          if (clash(cx0, cx1, 0, b.y1, cz0, cz1, b)) continue;
          out.push(Object.assign(bx, { y0: 0, y1: b.y1 - (P.post ? 0 : 0.0), mat: P.mat || b.mat, solid: false, hidden: false, uv: 'world', extra: true, back: alongX ? (side > 0 ? 'nz' : 'pz') : (side > 0 ? 'nx' : 'px') }));
        }
        // цоколь
        if (P.base) {
          const t = 0.07, hb = 0.42;
          const g0 = side > 0 ? face - 0.02 : face - t, g1 = side > 0 ? face + t : face + 0.02;
          const lo = alongX ? b.x0 : b.z0, hi = alongX ? b.x1 : b.z1;
          // режем цоколь на участки, где перед стеной ничего нет
          let segStart = null;
          const SEG = 1.0;
          for (let u = lo; u < hi + 1e-6; u += SEG) {
            const u1 = Math.min(hi, u + SEG);
            const cx0 = alongX ? u : (side > 0 ? face + 0.01 : face - 0.3), cx1 = alongX ? u1 : (side > 0 ? face + 0.3 : face - 0.01);
            const cz0 = alongX ? (side > 0 ? face + 0.01 : face - 0.3) : u, cz1 = alongX ? (side > 0 ? face + 0.3 : face - 0.01) : u1;
            const ok = !clash(cx0, cx1, 0, hb + 0.6, cz0, cz1, b) && u1 - u > 0.05;
            if (ok && segStart === null) segStart = u;
            if ((!ok || u1 >= hi - 1e-6) && segStart !== null) {
              const e = ok ? u1 : u;
              if (e - segStart > 0.8) out.push(Object.assign(alongX ? { x0: segStart, x1: e, z0: g0, z1: g1 } : { x0: g0, x1: g1, z0: segStart, z1: e },
                { y0: 0, y1: hb, mat: P.base, solid: false, hidden: false, uv: 'world', extra: true, base: true, back: alongX ? (side > 0 ? 'nz' : 'pz') : (side > 0 ? 'nx' : 'px') }));
              segStart = null;
            }
          }
        }
      }
    }
    return out;
  }

  // мелочи на земле: камешки, сухая трава, мусор, лужи
  let _seed = 1;
  const srnd = (a, b) => { _seed = (_seed * 16807) % 2147483647; return a + (_seed / 2147483647) * (b - a); };
  const SCATTER = {
    dust: { seed: 11, peb: 240, pebCol: ['#a08c6a', '#8f7b5c', '#b7a17c', '#9a8a70'], tuft: 80, tuftCol: ['#b8a45e', '#9f8c4c', '#c4b070'], rubble: 70, rubCol: ['#c9b48c', '#b39d76', '#d8c7a0'] },
    harbor: { seed: 23, peb: 110, pebCol: ['#6c6a66', '#5a5956', '#7c7a74'], tuft: 45, tuftCol: ['#5e6a3c', '#4f5a33', '#6f7a46'], rubble: 50, rubCol: ['#8a5a44', '#6f6f6f', '#9c8c70', '#3d6b8c'], puddle: 14, oil: 8 },
    sakura: { seed: 37, peb: 90, pebCol: ['#8d8a82', '#7b7870', '#a19d93'], tuft: 70, tuftCol: ['#5f7a3a', '#6f8a44', '#4f6a30'], rubble: 0, rubCol: [] },
    range: { seed: 5, peb: 40, pebCol: ['#77736c', '#66635d'], tuft: 20, tuftCol: ['#6a7440', '#596336'], rubble: 15, rubCol: ['#8a8a84', '#9c8c70'] },
    villa: { seed: 41, peb: 80, pebCol: ['#d2c3a2', '#bfae8a', '#e0d3b6', '#a99878'], tuft: 70, tuftCol: ['#9aa35a', '#8a9448', '#b4ab62'], rubble: 20, rubCol: ['#c46d42', '#d8cdb4', '#b05a34'] }
  };
  function scatterGround(id, list, bounds, solids) {
    const cfg = SCATTER[id]; if (!cfg) return [];
    _seed = cfg.seed * 7919 + 1;
    const out = [], ground = list.filter(b => b.y0 < 0.02 && b.y1 - b.y0 > 0.3 && b.mat !== 'roof');
    const inside = (x, z, pad) => { for (const b of solids) if (b.y0 < 0.5 && x > b.x0 - pad && x < b.x1 + pad && z > b.z0 - pad && z < b.z1 + pad) return true; return false; };
    const inB = (x, z) => x > bounds.x0 + 0.5 && x < bounds.x1 - 0.5 && z > bounds.z0 + 0.5 && z < bounds.z1 - 0.5;
    // точка у основания случайной стены
    const atWall = () => {
      const b = ground[Math.floor(srnd(0, ground.length))]; if (!b) return null;
      const side = Math.floor(srnd(0, 4)), off = srnd(0.12, 0.7);
      let x, z;
      if (side === 0) { x = srnd(b.x0, b.x1); z = b.z1 + off; } else if (side === 1) { x = srnd(b.x0, b.x1); z = b.z0 - off; }
      else if (side === 2) { z = srnd(b.z0, b.z1); x = b.x1 + off; } else { z = srnd(b.z0, b.z1); x = b.x0 - off; }
      return inB(x, z) && !inside(x, z, 0.08) ? [x, z] : null;
    };
    const free = () => { const x = srnd(bounds.x0, bounds.x1), z = srnd(bounds.z0, bounds.z1); return inB(x, z) && !inside(x, z, 0.15) ? [x, z] : null; };
    const pick = (a) => a[Math.floor(srnd(0, a.length))];
    for (let i = 0; i < cfg.peb; i++) {
      const p = i % 3 ? free() : atWall(); if (!p) continue;
      const n = 1 + Math.floor(srnd(0, 3));
      for (let k = 0; k < n; k++) { const r = srnd(0.035, 0.11); out.push({ sph: true, r, x: p[0] + srnd(-0.25, 0.25), y: r * 0.25, z: p[1] + srnd(-0.25, 0.25), sy: srnd(0.4, 0.7), sx: srnd(0.8, 1.3), color: pick(cfg.pebCol), seg: 5, ry: srnd(0, 3) }); }
    }
    for (let i = 0; i < cfg.tuft; i++) {
      const p = i % 4 ? atWall() : free(); if (!p) continue;
      const col = pick(cfg.tuftCol), n = 4 + Math.floor(srnd(0, 4)), hh = srnd(0.16, 0.34);
      for (let k = 0; k < n; k++) { const an = srnd(0, 6.28), tl = srnd(0.15, 0.5); out.push({ cyl: true, r: 0, r2: 0.022, h: hh * srnd(0.7, 1.15), x: p[0] + Math.cos(an) * 0.05, y: hh * 0.45, z: p[1] + Math.sin(an) * 0.05, color: col, seg: 3, rx: Math.sin(an) * tl, rz: -Math.cos(an) * tl }); }
    }
    for (let i = 0; i < cfg.rubble; i++) {
      const p = atWall(); if (!p) continue;
      const s = srnd(0.06, 0.18);
      out.push({ w: s * srnd(0.8, 1.6), h: s * srnd(0.4, 0.8), d: s * srnd(0.7, 1.3), x: p[0], y: s * 0.25, z: p[1], color: pick(cfg.rubCol), ry: srnd(0, 3.14), rx: srnd(-0.25, 0.25) });
    }
    for (let i = 0; i < (cfg.puddle || 0); i++) {
      const p = free(); if (!p) continue;
      const r = srnd(0.6, 1.6);
      out.push({ cyl: true, r, h: 0.006, x: p[0], y: 0.045, z: p[1], color: '#2f3640', seg: 12, sx: 1, sz: srnd(0.5, 0.9), ry: srnd(0, 3.14), puddle: true });
    }
    for (let i = 0; i < (cfg.oil || 0); i++) {
      const p = free(); if (!p) continue;
      out.push({ cyl: true, r: srnd(0.3, 0.8), h: 0.004, x: p[0], y: 0.043, z: p[1], color: '#1f2226', seg: 9, sz: srnd(0.6, 1), ry: srnd(0, 3.14) });
    }
    return out;
  }

  // вода: дешёвый шейдер с бликами солнца
  function makeWater(env) {
    const W = env.water;
    const sd = new THREE.Vector3(env.sunSprite[0], env.sunSprite[1], env.sunSprite[2]).normalize();
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        t: { value: 0 }, deep: { value: new THREE.Color(W.deep) }, shallow: { value: new THREE.Color(W.shallow) },
        skyc: { value: new THREE.Color(W.sky) }, sunc: { value: new THREE.Color(env.sun) }, sund: { value: sd },
        fogc: { value: new THREE.Color(env.fog) }, fn: { value: env.fogNear * 1.3 }, ff: { value: env.fogFar * 1.6 }
      },
      vertexShader: 'varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
      fragmentShader: [
        'uniform float t; uniform vec3 deep, shallow, skyc, sunc, sund, fogc; uniform float fn, ff; varying vec3 vW;',
        'void main(){',
        ' vec2 p = vW.xz;',
        ' float a1 = p.x*0.31 + t*1.2, a2 = p.y*0.23 - t*0.9, a3 = (p.x+p.y)*0.83 + t*2.0, a4 = (p.x-p.y)*1.27 - t*1.6;',
        ' vec3 n = normalize(vec3(cos(a1)*0.11 + cos(a3)*0.09 + cos(a4)*0.07, 1.0, cos(a2)*0.1 + cos(a3)*0.09 - cos(a4)*0.07));',
        ' vec3 V = normalize(cameraPosition - vW);',
        ' float fres = pow(1.0 - max(dot(n, V), 0.0), 3.0);',
        ' float wv = 0.5 + 0.25*(sin(a3) + sin(a4));',
        ' vec3 col = mix(deep, shallow, wv*0.6);',
        ' col = mix(col, skyc, clamp(fres*1.1, 0.0, 0.85));',
        ' vec3 R = reflect(-V, n);',
        ' float s = pow(max(dot(R, sund), 0.0), 90.0);',
        ' col += sunc * s * 1.6;',
        ' float d = length(vW - cameraPosition);',
        ' col = mix(col, fogc, smoothstep(fn, ff, d));',
        ' gl_FragColor = vec4(col, 1.0);',
        '}'
      ].join('\n'),
      fog: false
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(900, 900, 1, 1), mat);
    m.rotation.x = -HP; m.position.set(W.x0 + 450, W.level, 0);
    m.userData.water = mat;
    return m;
  }

  function buildSky(group, env, bounds) {
    const skyGeo = new THREE.SphereGeometry(320, 32, 16);
    const cols = [], top = new THREE.Color(env.skyTop), hor = new THREE.Color(env.skyHor), low = new THREE.Color(env.skyLow);
    const mid = env.skyMid ? new THREE.Color(env.skyMid) : null;
    const pa = skyGeo.attributes.position;
    const sd = new THREE.Vector3(env.sunSprite[0], 0, env.sunSprite[2]).normalize();
    const glow = new THREE.Color(env.sunSpriteColor);
    for (let i = 0; i < pa.count; i++) {
      const vx = pa.getX(i), vy = pa.getY(i) / 320, vz = pa.getZ(i);
      let c;
      if (vy > 0) {
        if (mid) c = vy < 0.25 ? hor.clone().lerp(mid, vy / 0.25) : mid.clone().lerp(top, Math.pow((vy - 0.25) / 0.75, 0.7));
        else c = hor.clone().lerp(top, Math.pow(vy, 0.6));
      } else c = hor.clone().lerp(low, Math.min(1, -vy * 4));
      // свечение у солнца
      const hl = Math.hypot(vx, vz) || 1;
      const dot = (vx * sd.x + vz * sd.z) / hl;
      const g = Math.pow(Math.max(0, dot), 6) * Math.max(0, 1 - Math.abs(vy) * 2.2);
      c.lerp(glow, g * 0.55);
      cols.push(c.r, c.g, c.b);
    }
    skyGeo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
    const sky = new THREE.Mesh(skyGeo, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false }));
    sky.renderOrder = -2;
    group.add(sky);
    const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('dot'), color: env.sunSpriteColor, fog: false, depthWrite: false, transparent: true }));
    sun.position.set(env.sunSprite[0], env.sunSprite[1], env.sunSprite[2]); sun.scale.set(env.sunSize, env.sunSize, 1);
    sun.renderOrder = -1;
    group.add(sun);
    // облака — один меш из повёрнутых к центру квадов
    const n = env.cloudN, pos = [], uv = [], idx = [];
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + Math.random() * 0.3, r = 270, h = 30 + Math.random() * 50;
      const w = 70 + Math.random() * 60, hh = w * 0.32;
      const cx = Math.cos(ang) * r, cz = Math.sin(ang) * r, rx = -Math.sin(ang), rz = Math.cos(ang);
      const b = pos.length / 3;
      pos.push(cx - rx * w / 2, h - hh / 2, cz - rz * w / 2, cx + rx * w / 2, h - hh / 2, cz + rz * w / 2,
        cx + rx * w / 2, h + hh / 2, cz + rz * w / 2, cx - rx * w / 2, h + hh / 2, cz - rz * w / 2);
      uv.push(0, 0, 1, 0, 1, 1, 0, 1);
      idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
    }
    const cg = new THREE.BufferGeometry();
    cg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    cg.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    cg.setIndex(idx);
    const clouds = new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ map: G.tex('cloud'), color: env.clouds, transparent: true, depthWrite: false, fog: false, side: THREE.DoubleSide }));
    clouds.renderOrder = -1;
    const far = [clouds];
    // дальние горы и дюны / город
    if (env.dune || env.mount) far.push(mountains(env));
    else if (!env.noCity) far.push(city(env));
    if (env.fuji) far.push(fuji(env));
    const hi = G.settings.quality === 'high';
    for (const o of far) { o.visible = hi; group.add(o); BACKDROP.push(o); }
  }

  // Фудзи: вогнутый конус со снежной шапкой, в дымке у горизонта
  function fuji(env) {
    const H = 135, R = 215, g = new THREE.ConeGeometry(R, H, 48, 10, true);
    const pa = g.attributes.position, col = [];
    const base = new THREE.Color('#5a7099'), haze = new THREE.Color(env.skyHor), snow = new THREE.Color('#f8f9ff'), shade = new THREE.Color('#b9c4dc');
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i), z = pa.getZ(i), y = pa.getY(i), ang = Math.atan2(z, x);
      const t = Math.min((y + H / 2) / H, 0.94);
      const r = R * Math.pow(1 - t, 1.75) * (1 + 0.025 * Math.sin(ang * 7 + t * 9));
      const hl = Math.hypot(x, z) || 1;
      pa.setXYZ(i, x / hl * r, t * H - 6, z / hl * r);
      const line = 0.7 + 0.06 * Math.sin(ang * 9) + 0.035 * Math.sin(ang * 23 + 1.3);
      let c;
      if (t > line) c = snow.clone().lerp(shade, Math.max(0, Math.sin(ang + 0.6)) * 0.45);
      else c = base.clone().lerp(haze, 0.12 + (1 - t) * 0.38);
      c.lerp(haze, 0.18);
      col.push(c.r, c.g, c.b);
    }
    // освещение «запечено» в цвета: неосвещённый материал не пересвечивает гору
    g.computeVertexNormals();
    const na = g.attributes.normal, L = new THREE.Vector3(env.sunPos[0], env.sunPos[1], env.sunPos[2]).normalize();
    for (let i = 0; i < pa.count; i++) {
      const d = Math.max(0, na.getX(i) * L.x + na.getY(i) * L.y + na.getZ(i) * L.z), k = 0.78 + d * 0.32;
      col[i * 3] = Math.min(1, col[i * 3] * k); col[i * 3 + 1] = Math.min(1, col[i * 3 + 1] * k); col[i * 3 + 2] = Math.min(1, col[i * 3 + 2] * k);
    }
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.translate(env.fuji[0], 0, env.fuji[1]);
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, fog: false }));
    m.matrixAutoUpdate = false; m.renderOrder = -1;
    return m;
  }

  // кольцо гор: низкополигональные конусы с изломанными склонами, дымка к горизонту
  function mountains(env) {
    const pos = [], col = [];
    const base = new THREE.Color(env.mount || '#8a6e50'), haze = new THREE.Color(env.skyHor), rock = new THREE.Color(env.rock || '#6e5a46');
    const ring = (n, r0, r1, h0, h1, hz) => {
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + Math.random() * 0.2, r = r0 + Math.random() * (r1 - r0);
        const h = h0 + Math.random() * (h1 - h0), rad = h * (1.6 + Math.random() * 1.2);
        const g = new THREE.ConeGeometry(rad, h, 7, 3, true);
        const pa = g.attributes.position;
        // одинаковый сдвиг для совпадающих вершин шва (колонка 7 = колонка 0)
        const J = []; for (let k = 0; k < 4 * 7; k++) J.push([1 + (Math.random() - 0.5) * 0.35, (Math.random() - 0.5) * h * 0.12]);
        for (let k = 0; k < pa.count; k++) {
          const row = Math.floor(k / 8), colm = (k % 8) % 7;
          if (row === 0) continue; // вершина
          const jj = J[row * 7 + colm];
          pa.setX(k, pa.getX(k) * jj[0]); pa.setZ(k, pa.getZ(k) * jj[0]); if (row < 3) pa.setY(k, pa.getY(k) + jj[1]);
        }
        const ng = g.toNonIndexed(); g.dispose();
        ng.translate(Math.cos(a) * r, h / 2 - 4, Math.sin(a) * r);
        const p = ng.attributes.position.array;
        for (let k = 0; k < p.length; k += 3) {
          pos.push(p[k], p[k + 1], p[k + 2]);
          const t = G.clamp((p[k + 1] + 4) / (h + 4), 0, 1);
          const c = base.clone().lerp(rock, t * 0.5).lerp(haze, hz - t * 0.1);
          col.push(c.r, c.g, c.b);
        }
        ng.dispose();
      }
    };
    const mh = env.mountH || 1;
    ring(16, 230, 260, 30 * mh, 56 * mh, 0.42);
    ring(22, 150, 175, 9 * mh, 20 * mh, 0.22);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, fog: false, flatShading: true }));
    m.matrixAutoUpdate = false;
    return m;
  }

  // силуэт вечернего города с горящими окнами
  function city(env) {
    const pos = [], nor = [], uv = [], col = [];
    for (let i = 0; i < 42; i++) {
      const side = i % 3, t = (Math.floor(i / 3) + Math.random() * 0.8) / 14;
      const near = Math.random() < 0.4;
      const h = (near ? 14 : 24) + Math.random() * (near ? 16 : 34), w = 10 + Math.random() * 12, d = 10 + Math.random() * 10;
      const dist = near ? 85 + Math.random() * 20 : 120 + Math.random() * 45;
      let x, z;
      if (side === 0) { x = -dist; z = -150 + t * 300; }
      else if (side === 1) { x = -110 + t * 170; z = dist; }
      else { x = -110 + t * 170; z = -dist; }
      const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
      g.translate(x, h / 2 - 1, z);
      const p = g.attributes.position.array, n = g.attributes.normal.array, u = g.attributes.uv.array;
      const ou = Math.random(), ov = Math.random(), sh = 0.7 + Math.random() * 0.35;
      for (let k = 0; k < p.length / 3; k++) {
        const f = Math.floor(k / 6);
        pos.push(p[k * 3], p[k * 3 + 1], p[k * 3 + 2]); nor.push(n[k * 3], n[k * 3 + 1], n[k * 3 + 2]);
        if (f === 2 || f === 3) uv.push(0.004, 0.996);
        else uv.push(u[k * 2] * (f < 2 ? d : w) / 17 + ou, u[k * 2 + 1] * h / 30 + ov);
        const s = f === 0 || f === 4 ? sh : sh * 0.8;
        col.push(s, s * 0.96, s * 1.02);
      }
      g.dispose();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeBoundingSphere();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map: G.tex('cityWin'), vertexColors: true }));
    m.matrixAutoUpdate = false;
    return m;
  }

  // ---------- наклейки, навесы, пальмы, пятна ----------
  const NRM = { '+x': [1, 0, 0], '-x': [-1, 0, 0], '+z': [0, 0, 1], '-z': [0, 0, -1] };
  function quads() { return { pos: [], nor: [], uv: [], idx: [] }; }
  function quad(q, c, r, u, w, h, uv, n) {
    const b = q.pos.length / 3;
    const hw = w / 2, hh = h / 2;
    const P = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
    for (const [a, bb] of P) { q.pos.push(c[0] + r[0] * a + u[0] * bb, c[1] + r[1] * a + u[1] * bb, c[2] + r[2] * a + u[2] * bb); q.nor.push(n[0], n[1], n[2]); }
    q.uv.push(uv[0], uv[1], uv[2], uv[1], uv[2], uv[3], uv[0], uv[3]);
    q.idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  }
  function qmesh(q, mat) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(q.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(q.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(q.uv, 2));
    g.setIndex(q.idx); g.computeBoundingSphere();
    const m = new THREE.Mesh(g, mat); m.matrixAutoUpdate = false; return m;
  }
  const cellUV = (i) => { const u0 = (i % 4) * 0.25, v1 = 1 - Math.floor(i / 4) * 0.5; return [u0 + 0.002, v1 - 0.5 + 0.002, u0 + 0.248, v1 - 0.002]; };
  function wallQuad(q, d) {
    const n = NRM[d.n], r = [n[2], 0, -n[0]];
    quad(q, [d.x + n[0] * 0.02, d.y, d.z + n[2] * 0.02], r, [0, 1, 0], d.w, d.h, cellUV(d.cell), n);
  }
  // многоугольник крыши с плоской нормалью, повёрнутой вверх
  function poly(q, pts, uvs) {
    const a = pts[0], b = pts[1], c = pts[2];
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    if (ny < 0) { pts = pts.slice().reverse(); uvs = uvs.slice().reverse(); nx = -nx; ny = -ny; nz = -nz; }
    const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    const base = q.pos.length / 3;
    for (let i = 0; i < pts.length; i++) { q.pos.push(pts[i][0], pts[i][1], pts[i][2]); q.nor.push(nx, ny, nz); q.uv.push(uvs[i][0], uvs[i][1]); }
    for (let i = 1; i < pts.length - 1; i++) q.idx.push(base, base + i, base + i + 1);
  }
  function roofGeo(q, r) {
    const g = roofFrame(r), ax = r.alongX;
    const P = (aa, c, y) => ax ? [aa, y, c] : [c, y, aa];
    const T = 2.2, L = Math.hypot(g.hw, g.top - g.ey) / T, { A0, A1, C0, C1, ra0, ra1, cc, ey, top } = g;
    poly(q, [P(A0, C0, ey), P(A1, C0, ey), P(ra1, cc, top), P(ra0, cc, top)], [[A0 / T, 0], [A1 / T, 0], [ra1 / T, L], [ra0 / T, L]]);
    poly(q, [P(A1, C1, ey), P(A0, C1, ey), P(ra0, cc, top), P(ra1, cc, top)], [[A1 / T, 0], [A0 / T, 0], [ra0 / T, L], [ra1 / T, L]]);
    if (r.hip) {
      poly(q, [P(A0, C1, ey), P(A0, C0, ey), P(ra0, cc, top)], [[C1 / T, 0], [C0 / T, 0], [cc / T, L]]);
      poly(q, [P(A1, C0, ey), P(A1, C1, ey), P(ra1, cc, top)], [[C0 / T, 0], [C1 / T, 0], [cc / T, L]]);
    }
  }
  function buildDetails(group, api, def, anim) {
    const dg = {};
    for (const d of api.decals) { const k = d.atlas + (d.lit ? '|lit' : ''); (dg[k] = dg[k] || []).push(d); }
    for (const k in dg) {
      const q = quads(); dg[k].forEach(d => wallQuad(q, d));
      const lit = k.endsWith('|lit'), o = { map: G.tex(k.split('|')[0]), transparent: true, alphaTest: 0.1, polygonOffset: true, polygonOffsetFactor: -2 };
      const m = qmesh(q, lit ? new THREE.MeshBasicMaterial(o) : new THREE.MeshLambertMaterial(o));
      if (!lit) m.receiveShadow = true;
      group.add(m);
    }
    if (api.roofs.length) {
      // все крыши одним мешем: оттенок черепицы — в цвете вершин
      const q = quads(), col = [], c = new THREE.Color();
      for (const r of api.roofs) {
        const n0 = q.pos.length / 3; roofGeo(q, r); c.set(r.col);
        for (let i = n0; i < q.pos.length / 3; i++) col.push(c.r, c.g, c.b);
      }
      const rt = def.roofTex || 'kawara';
      const mat = new THREE.MeshLambertMaterial({ map: G.tex(rt), vertexColors: true, side: THREE.DoubleSide });
      mat.userData.nm = G.normalTex(rt); mat.userData.ns = 1.2; NM.push(mat);
      if (G.settings.quality === 'high') { mat.normalMap = mat.userData.nm; mat.normalScale = new THREE.Vector2(1.2, 1.2); }
      const m = qmesh(q, mat); m.geometry.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      m.castShadow = true; m.receiveShadow = true; group.add(m);
    }
    for (const p of api.ground.filter(g => g.kind === 'pond')) {
      const q = quads();
      quad(q, [p.x, 0.035, p.z], [1, 0, 0], [0, 0, -1], p.w, p.d, [0, 0, p.w / 9, p.d / 9], [0, 1, 0]);
      const t = G.tex('pond').clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping;
      const m = qmesh(q, new THREE.MeshPhongMaterial({ map: t, shininess: 90, specular: 0x8899aa }));
      m.receiveShadow = true; group.add(m);
      if (anim) anim.ponds.push(t);
    }
    // вода бассейна и фонтанов: прямоугольники и круги, бирюза с бликами солнца, каустика медленно плывёт
    const sw = api.ground.filter(g => g.kind === 'swim');
    if (sw.length) {
      const q = quads();
      for (const p of sw) {
        if (p.r) {
          const b = q.pos.length / 3, n = 20;
          q.pos.push(p.x, p.y, p.z); q.nor.push(0, 1, 0); q.uv.push(p.x / 3, -p.z / 3);
          for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2, X = p.x + Math.cos(a) * p.r, Z = p.z + Math.sin(a) * p.r; q.pos.push(X, p.y, Z); q.nor.push(0, 1, 0); q.uv.push(X / 3, -Z / 3); }
          for (let i = 1; i <= n; i++) q.idx.push(b, b + i + 1, b + i);
        } else quad(q, [p.x, p.y, p.z], [1, 0, 0], [0, 0, -1], p.w, p.d, [(p.x - p.w / 2) / 3, -(p.z + p.d / 2) / 3, (p.x + p.w / 2) / 3, -(p.z - p.d / 2) / 3], [0, 1, 0]);
      }
      const t = G.tex('swim').clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping;
      const m = qmesh(q, new THREE.MeshPhongMaterial({ map: t, shininess: 120, specular: 0xa8e8ff }));
      m.receiveShadow = true; group.add(m);
      if (anim) anim.swim.push(t);
    }
    if (api.awnings.length) {
      const byCol = {};
      for (const a of api.awnings) (byCol[a.col || 'r'] = byCol[a.col || 'r'] || []).push(a);
      for (const col in byCol) {
        const q = quads();
        for (const a of byCol[col]) {
          const n = NRM[a.n], r = [n[2], 0, -n[0]];
          const slope = 0.42, dz = a.depth * Math.cos(slope), dy = a.depth * Math.sin(slope);
          const c = [a.x + n[0] * dz / 2, a.y - dy / 2, a.z + n[2] * dz / 2];
          const up = [n[0] * Math.cos(slope) * -1, Math.sin(slope), n[2] * Math.cos(slope) * -1];
          const len = Math.hypot(...up); up[0] /= len; up[1] /= len; up[2] /= len;
          const nn = [n[0] * Math.sin(slope), Math.cos(slope), n[2] * Math.sin(slope)];
          quad(q, c, r, up, a.w, a.depth, [0, 0, a.w / 2, 1], nn);
          a.supports = true;
        }
        const t = G.tex('awning', col === 'r' ? '#b0392b' : col).clone(); t.needsUpdate = true; t.wrapS = THREE.RepeatWrapping;
        const m = qmesh(q, new THREE.MeshLambertMaterial({ map: t, side: THREE.DoubleSide }));
        m.castShadow = true; m.receiveShadow = true; group.add(m);
      }
    }
    if (api.fronds.length) {
      const q = quads();
      for (const p of api.fronds) {
        for (let i = 0; i < p.n; i++) {
          const a = i / p.n * Math.PI * 2 + Math.random() * 0.3, dx = Math.cos(a), dz = Math.sin(a);
          const r = [-dz, 0, dx];
          // две части листа: вверх-наружу и вниз
          const l1 = 1.6, l2 = 1.7, up1 = 0.35, dn2 = -0.9;
          const c1 = [p.x + dx * l1 / 2, p.y + up1 / 2, p.z + dz * l1 / 2];
          const u1 = [dx, up1 / l1, dz]; const n1 = Math.hypot(...u1); u1[0] /= n1; u1[1] /= n1; u1[2] /= n1;
          quad(q, c1, r, u1, 0.75, l1 * 1.02, [0, 0, 1, 0.5], [0, 1, 0]);
          const c2 = [p.x + dx * (l1 + l2 / 2 * 0.8), p.y + up1 + dn2 / 2, p.z + dz * (l1 + l2 / 2 * 0.8)];
          const u2 = [dx * 0.8, dn2 / l2, dz * 0.8]; const n2 = Math.hypot(...u2); u2[0] /= n2; u2[1] /= n2; u2[2] /= n2;
          quad(q, c2, r, u2, 0.75, l2, [0, 0.5, 1, 1], [0, 1, 0]);
        }
      }
      const tex = G.tex('palm');
      // текстура листа лежит горизонтально: u — вдоль листа, v — поперёк
      for (let i = 0; i < q.uv.length; i += 2) { const t = q.uv[i]; q.uv[i] = q.uv[i + 1]; q.uv[i + 1] = t; }
      const m = qmesh(q, new THREE.MeshLambertMaterial({ map: tex, alphaTest: 0.35, side: THREE.DoubleSide }));
      m.castShadow = true; group.add(m);
    }
    for (const kind of ['stain', 'pool', 'petals']) {
      const list = api.ground.filter(g => g.kind === kind);
      if (!list.length) continue;
      const q = quads();
      for (const g of list) quad(q, [g.x, kind === 'pool' ? 0.025 : kind === 'petals' ? 0.03 : 0.018, g.z], [1, 0, 0], [0, 0, -1], g.sz, g.sz, [0, 0, 1, 1], [0, 1, 0]);
      const mat = kind === 'pool'
        ? new THREE.MeshBasicMaterial({ map: G.tex('pool'), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })
        : new THREE.MeshLambertMaterial({ map: G.tex(kind), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
      group.add(qmesh(q, mat));
    }
  }

  // ---------- активная карта ----------
  const map = G.map = {
    id: null, def: null, boxes: [], solids: [], bounds: null, spawnZones: null, sites: null, groups: {}, built: {},
    // построить (один раз) и сделать активной
    load(id, scene) {
      const def = G.MAPS[id] || G.MAPS.dust;
      if (!this.built[id]) this.built[id] = this.build(id, def, scene);
      const data = this.built[id];
      for (const k in this.built) this.built[k].group.visible = (k === id);
      this.id = id; this.def = def; this.boxes = data.boxes; this.solids = data.solids;
      this.bounds = data.bounds; this.spawnZones = data.spawnZones; this.sites = data.sites;
      this.water = data.water;
      this.lampSprites = data.lampSprites;
      this.anim = data.anim;
      return data;
    },
    build(id, def, scene) {
      const sc = def.scale || 1;
      const api = makeApi(sc);
      def.layout(api); G.map._api = api; G.map._lite = liteList;
      const R = (r) => ({ x0: r.x0 * sc, x1: r.x1 * sc, z0: r.z0 * sc, z1: r.z1 * sc });
      const bounds = R(def.bounds), sites = {}, spawnZones = def.spawnZones.map(z => Object.assign(R(z), { yaw: z.yaw }));
      for (const k in def.sites) sites[k] = R(def.sites[k]);
      const env = Object.assign({}, def.env);
      if (env.water) env.water = Object.assign({}, env.water, { x0: env.water.x0 * sc });
      const boxes = api.boxes, solids = boxes.filter(b => b.solid);
      // сервер: только геометрия столкновений, без графики
      if (G.HEADLESS) return { group: { visible: false }, boxes, solids, bounds, spawnZones, sites, water: null, lampSprites: null, anim: null };
      const group = new THREE.Group();
      const bufs = {};
      const vis = boxes.filter(b => !b.hidden && b.mat !== 'none');
      const trims = genTrims(vis, api, R(def.bounds));
      const rboxes = deZFight(vis.concat(trims));
      const att = computeAttach(rboxes.slice(0, vis.length)).concat(rboxes.slice(vis.length).map(b => ({ [b.back]: true, chAll: true })));
      let nCh = 0;
      rboxes.forEach((b, i) => {
        const k = b.mat;
        if (!bufs[k]) bufs[k] = { pos: [], nor: [], uv: [], col: [], idx: [] };
        const c = b.y1 - b.y0 < 0.05 ? 0 : chamferOf(b, att[i]);
        const c0 = bufs[k].col.length;
        if (c > 0.005) { addBoxCh(bufs[k], b, def.matScale[k] || 3, c); nCh++; } else addBox(bufs[k], b, def.matScale[k] || 3);
        if (b.extra && !b.base) { const col = bufs[k].col; for (let q = c0; q < col.length; q++) col[q] *= 0.9; }
        if (b.tint) { const col = bufs[k].col; _tc.set(b.tint); for (let q = c0; q < col.length; q += 3) { col[q] *= _tc.r; col[q + 1] *= _tc.g; col[q + 2] *= _tc.b; } }
      });
      unflushDecor(api.decor, rboxes); G.map._rboxes = rboxes; G.map._nCh = nCh; G.map._nTrim = trims.length;
      const nd0 = api.decor.length; wallCaps(rboxes, att, api.decor); G.map._nCaps = api.decor.length - nd0;
      contactAO(rboxes, att, group);
      const scat = scatterGround(id, rboxes, R(def.bounds), solids);
      for (const k in bufs) {
        const bf = bufs[k], geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(bf.pos, 3));
        geo.setAttribute('normal', new THREE.Float32BufferAttribute(bf.nor, 3));
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(bf.uv, 2));
        geo.setAttribute('color', new THREE.Float32BufferAttribute(bf.col, 3));
        geo.setIndex(bf.idx);
        geo.computeBoundingSphere();
        const m = new THREE.Mesh(geo, getMat(k));
        m.castShadow = true; m.receiveShadow = true; m.matrixAutoUpdate = false;
        group.add(m);
      }
      // земля (ground.none — карта целиком покрыта полами-коробками: без второго слоя под ними)
      if (!def.ground.none) {
      const gm = lam(def.ground.mat, null, 0.9);
      gm.vertexColors = false;
      const gtex = gm.map.clone(); gtex.needsUpdate = true; gm.map = gtex;
      const gnm = gm.userData.nm.clone(); gnm.needsUpdate = true; gm.userData.nm = gnm; if (gm.normalMap) gm.normalMap = gnm;
      const gsz = [def.ground.size[0] * sc, def.ground.size[1] * sc];
      for (const t of [gtex, gnm]) t.repeat.set(gsz[0] / def.ground.repeat, gsz[1] / def.ground.repeat);
      // крупные пятна на земле — ломают повтор текстуры
      const gg = new THREE.PlaneGeometry(gsz[0], gsz[1], Math.ceil(gsz[0] / 2.2), Math.ceil(gsz[1] / 2.2));
      { const pa = gg.attributes.position.array, col = new Float32Array(pa.length);
        for (let i = 0; i < pa.length; i += 3) {
          const x = pa[i], y = pa[i + 1];
          const n1 = Math.sin(x * 0.11 + 1.7) * Math.cos(y * 0.093 - 0.6) + Math.sin(x * 0.047 - y * 0.061 + 2.1);
          const n2 = Math.sin(x * 0.31 + y * 0.27) * Math.cos(x * 0.23 - y * 0.35);
          const v = 0.95 + n1 * 0.035 + n2 * 0.02;
          col[i] = v * (1 + n2 * 0.015); col[i + 1] = v; col[i + 2] = v * (1 - n2 * 0.02);
        }
        gg.setAttribute('color', new THREE.BufferAttribute(col, 3)); }
      gm.vertexColors = true;
      const ground = new THREE.Mesh(gg, gm);
      gm.polygonOffset = true; gm.polygonOffsetFactor = 1; gm.polygonOffsetUnits = 2; // земля всегда «под» наклейками
      ground.rotation.x = -HP; ground.receiveShadow = true; ground.updateMatrix(); ground.matrixAutoUpdate = false;
      group.add(ground);
      }
      // декор (на картах с def.lite — ещё и упрощённая копия для низкого/среднего качества)
      const hiQ = G.settings.quality === 'high';
      if (api.decor.length) {
        const dm = new THREE.Mesh(G.geo.build(api.decor), G.getVCMat());
        dm.castShadow = true; dm.receiveShadow = true; dm.matrixAutoUpdate = false;
        group.add(dm);
        if (def.lite) {
          const lm = new THREE.Mesh(G.geo.build(liteList(api.decor).concat(api.lo)), G.getVCMat());
          lm.castShadow = true; lm.receiveShadow = true; lm.matrixAutoUpdate = false;
          group.add(lm); dm.visible = hiQ; lm.visible = !hiQ; BACKDROP.push(dm); LITE.push(lm);
        }
      }
      // мелкие детали и пейзаж за стенами — отдельным мешем, только на высоком качестве
      if (api.hi.length) {
        const hm = new THREE.Mesh(G.geo.build(api.hi), G.getVCMat());
        hm.receiveShadow = true; hm.matrixAutoUpdate = false; hm.visible = hiQ;
        group.add(hm); BACKDROP.push(hm);
      }
      // мелочи на земле (без отбрасывания теней — дёшево)
      if (scat.length) {
        const pud = scat.filter(p => p.puddle), rest = scat.filter(p => !p.puddle);
        if (rest.length) { const sm = new THREE.Mesh(G.geo.build(rest), G.getVCMat()); sm.receiveShadow = true; sm.matrixAutoUpdate = false; group.add(sm); if (def.scatterHi) { sm.visible = hiQ; BACKDROP.push(sm); } }
        if (pud.length) {
          const pm = new THREE.Mesh(G.geo.build(pud), new THREE.MeshPhongMaterial({ vertexColors: true, shininess: 90, specular: 0x8a8f99, transparent: true, opacity: 0.78, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
          pm.receiveShadow = true; pm.matrixAutoUpdate = false; group.add(pm);
        }
      }
      // кроны сакуры: фактура цветков, неровный силуэт
      if (api.blossoms.length) {
        const bmat = new THREE.MeshLambertMaterial({ map: G.tex(def.blossomTex || 'blossom'), vertexColors: true });
        const crown = (parts) => {
          const bg = G.geo.buildUV(parts, 0.55), pa = bg.attributes.position.array, na = bg.attributes.normal.array;
          for (let i = 0; i < pa.length; i += 3) {
            const h = Math.sin(pa[i] * 3.1 + pa[i + 1] * 5.7 + pa[i + 2] * 2.3) * Math.cos(pa[i] * 1.7 - pa[i + 2] * 4.1 + pa[i + 1]);
            const o = h * (def.blossomAmp || 0.28);
            pa[i] += na[i] * o; pa[i + 1] += na[i + 1] * o; pa[i + 2] += na[i + 2] * o;
          }
          bg.computeBoundingSphere();
          const bm = new THREE.Mesh(bg, bmat);
          bm.castShadow = true; bm.receiveShadow = true; bm.matrixAutoUpdate = false;
          group.add(bm);
          return bm;
        };
        const bm = crown(api.blossoms);
        if (def.lite) { const lm = crown(liteList(api.blossoms)); bm.visible = hiQ; lm.visible = !hiQ; BACKDROP.push(bm); LITE.push(lm); }
      }
      // нарисованные буквы точек
      for (const L of api.letters) {
        const p = new THREE.Mesh(new THREE.PlaneGeometry(L.size, L.size), new THREE.MeshLambertMaterial({ map: G.T.letter(L.ch), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
        p.rotation.set(-HP, 0, L.rotY); p.position.set(L.x, 0.04, L.z); p.receiveShadow = true;
        group.add(p);
      }
      const anim = { gulls: [], foam: null, ponds: [], petals: null, swim: [] };
      buildDetails(group, api, def, anim);
      // огни фонарей
      // свечение фонарей: одни точки с размером на вершину — один вызов отрисовки на все огни
      const lampSprites = [];
      if (api.lamps.length) {
        const n = api.lamps.length, lp = new Float32Array(n * 3), ls = new Float32Array(n);
        api.lamps.forEach((l, i) => { lp[i * 3] = l[0]; lp[i * 3 + 1] = l[1]; lp[i * 3 + 2] = l[2]; ls[i] = l[3] || 1.8; });
        const lg = new THREE.BufferGeometry();
        lg.setAttribute('position', new THREE.BufferAttribute(lp, 3)); lg.setAttribute('size', new THREE.BufferAttribute(ls, 1));
        lg.computeBoundingSphere();
        const lm = new THREE.ShaderMaterial({
          uniforms: { map: { value: G.tex('lampGlow') }, scale: { value: 500 } },
          vertexShader: 'attribute float size; uniform float scale; void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = size * scale / max(0.2, -mv.z); gl_Position = projectionMatrix * mv; }',
          fragmentShader: 'uniform sampler2D map; void main(){ gl_FragColor = texture2D(map, gl_PointCoord); }',
          transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
        });
        const lpts = new THREE.Points(lg, lm);
        const dbs = new THREE.Vector2();
        lpts.onBeforeRender = (r, sc2, cam) => { r.getDrawingBufferSize(dbs); lm.uniforms.scale.value = dbs.y / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov || 60) / 2)); };
        group.add(lpts); lampSprites.push(lpts);
      }
      buildSky(group, def.env, def.bounds);
      let water = null;
      // падающие лепестки сакуры
      const ptrees = api.trees.filter(t => t.petals);
      if (ptrees.length) {
        const N = G.settings.quality === 'low' ? 140 : 320, pos = new Float32Array(N * 3), ph = new Float32Array(N), sp = new Float32Array(N);
        const spawn = (i, any) => {
          const t = ptrees[(Math.random() * ptrees.length) | 0], a = Math.random() * 6.28, rr = Math.sqrt(Math.random()) * t.r;
          pos[i * 3] = t.x + Math.cos(a) * rr; pos[i * 3 + 1] = any ? Math.random() * (t.y + 1) : t.y + Math.random() * 1.4; pos[i * 3 + 2] = t.z + Math.sin(a) * rr;
          ph[i] = Math.random() * 6.28; sp[i] = 0.35 + Math.random() * 0.45;
        };
        for (let i = 0; i < N; i++) spawn(i, true);
        const pg = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); attr.setUsage(THREE.DynamicDrawUsage);
        pg.setAttribute('position', attr);
        const pts = new THREE.Points(pg, new THREE.PointsMaterial({ map: G.tex('petal'), size: 0.28, sizeAttenuation: true, transparent: true, alphaTest: 0.3, depthWrite: false, color: '#ffe3ec' }));
        pts.frustumCulled = false; group.add(pts);
        anim.petals = { pos, ph, sp, spawn, attr, n: N };
      }
      // снегопад над всей площадью (те же «лепестки», только белые и медленные)
      if (api.snowfall) {
        const bd = R(def.bounds), N = G.settings.quality === 'low' ? 260 : 600, pos = new Float32Array(N * 3), ph = new Float32Array(N), sp = new Float32Array(N);
        const spawn = (i, any) => {
          pos[i * 3] = bd.x0 + Math.random() * (bd.x1 - bd.x0); pos[i * 3 + 2] = bd.z0 + Math.random() * (bd.z1 - bd.z0);
          pos[i * 3 + 1] = any ? Math.random() * 14 : 12 + Math.random() * 3;
          ph[i] = Math.random() * 6.28; sp[i] = 0.7 + Math.random() * 0.8;
        };
        for (let i = 0; i < N; i++) spawn(i, true);
        const pg = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); attr.setUsage(THREE.DynamicDrawUsage);
        pg.setAttribute('position', attr);
        const pts = new THREE.Points(pg, new THREE.PointsMaterial({ map: G.tex('dot'), size: 0.13, sizeAttenuation: true, transparent: true, depthWrite: false, color: '#ffffff', opacity: 0.9 }));
        pts.frustumCulled = false; group.add(pts);
        anim.petals = { pos, ph, sp, spawn, attr, n: N, snow: true };
      }
      if (env.water) {
        const W = env.water;
        water = makeWater(env); group.add(water);
        // пена у стенки причала
        const fq = quads();
        quad(fq, [W.x0 + 0.7 * sc + 0.75, W.level + 0.04, 0], [0, 0, 1], [1, 0, 0], 190, 1.5, [0, 0, 40, 1], [0, 1, 0]);
        const ft = G.tex('foam').clone(); ft.needsUpdate = true;
        anim.foam = new THREE.MeshBasicMaterial({ map: ft, transparent: true, depthWrite: false, opacity: 0.7, color: '#fff3e8' });
        group.add(qmesh(fq, anim.foam));
      }
      // чайки над водой
      if (api.gulls) {
        const gm = new THREE.SpriteMaterial({ map: G.tex('gull'), color: '#fff0e4', transparent: true, depthWrite: false });
        for (let i = 0; i < api.gulls; i++) {
          const s = new THREE.Sprite(gm);
          s.userData = { cx: (50 + Math.random() * 26) * sc, cz: (-30 + Math.random() * 60) * sc, r: 6 + Math.random() * 12, h: 9 + Math.random() * 10,
            sp: (0.18 + Math.random() * 0.2) * (Math.random() < 0.5 ? -1 : 1), ph: Math.random() * 6.28, sz: 2.6 + Math.random() * 1.0 };
          group.add(s); anim.gulls.push(s);
        }
      }
      group.visible = false;
      scene.add(group);
      return { group, boxes, solids, water, lampSprites, anim, bounds, sites, spawnZones };
    },
    update(dt, time) {
      if (this.water) this.water.userData.water.uniforms.t.value = time;
      const an = this.anim;
      if (!an) return;
      if (an.petals) {
        const P = an.petals, p = P.pos, w = Math.sin(time * 0.23) * 0.4 + 0.6, k0 = P.snow ? 0.35 : 1;
        for (let i = 0; i < P.n; i++) {
          const k = i * 3, f = P.ph[i];
          p[k + 1] -= P.sp[i] * dt;
          p[k] += (w * 0.7 + Math.sin(time * 1.6 + f) * 0.55) * dt * k0;
          p[k + 2] += (0.25 + Math.cos(time * 1.2 + f * 1.7) * 0.5) * dt * k0;
          if (p[k + 1] < 0.04) P.spawn(i, false);
        }
        P.attr.needsUpdate = true;
      }
      for (const t of an.ponds) { t.offset.x = Math.sin(time * 0.11) * 0.02; t.offset.y = Math.cos(time * 0.09) * 0.02; }
      if (an.swim) for (const t of an.swim) { t.offset.x = time * 0.016 + Math.sin(time * 0.4) * 0.01; t.offset.y = time * 0.011; }
      if (an.foam) { an.foam.map.offset.x = time * 0.025; an.foam.map.offset.y = Math.sin(time * 0.8) * 0.08; an.foam.opacity = 0.55 + 0.18 * Math.sin(time * 1.3); }
      for (let i = 0; i < an.gulls.length; i++) {
        const s = an.gulls[i], u = s.userData, a = u.ph + time * u.sp;
        s.position.set(u.cx + Math.cos(a) * u.r, u.h + Math.sin(time * 0.6 + u.ph) * 1.4, u.cz + Math.sin(a) * u.r);
        const f = Math.sin(time * (u.sp > 0 ? 8 : 9) + u.ph * 3);
        s.scale.set(u.sz, u.sz * 0.5 * (0.3 + 0.7 * Math.abs(f)), 1);
      }
    },
    inSite(x, z) {
      for (const k in this.sites) { const s = this.sites[k]; if (x > s.x0 && x < s.x1 && z > s.z0 && z < s.z1) return k; }
      return null;
    },

    ray(ox, oy, oz, dx, dy, dz, maxT) {
      const solids = this.solids;
      let best = maxT, hit = false, bnx = 0, bny = 0, bnz = 0;
      if (dy < -1e-6) {
        const t = -oy / dy;
        if (t > 0 && t < best) { best = t; hit = true; bnx = 0; bny = 1; bnz = 0; }
      }
      const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (b.nr) continue; // вода бассейна: не пройти, но простреливается
        let tmin = 0, tmax = best, nx = 0, ny = 0, nz = 0, t1, t2;
        if (Math.abs(dx) < 1e-9) { if (ox < b.x0 || ox > b.x1) continue; }
        else {
          t1 = (b.x0 - ox) * ix; t2 = (b.x1 - ox) * ix;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = dx > 0 ? -1 : 1; ny = 0; nz = 0; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (Math.abs(dy) < 1e-9) { if (oy < b.y0 || oy > b.y1) continue; }
        else {
          t1 = (b.y0 - oy) * iy; t2 = (b.y1 - oy) * iy;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = 0; ny = dy > 0 ? -1 : 1; nz = 0; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (Math.abs(dz) < 1e-9) { if (oz < b.z0 || oz > b.z1) continue; }
        else {
          t1 = (b.z0 - oz) * iz; t2 = (b.z1 - oz) * iz;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = 0; ny = 0; nz = dz > 0 ? -1 : 1; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (tmin < best) { best = tmin; hit = true; bnx = nx; bny = ny; bnz = nz; }
      }
      return hit ? { t: best, nx: bnx, ny: bny, nz: bnz } : null;
    },
    clear(ax, ay, az, bx, by, bz) {
      const dx = bx - ax, dy = by - ay, dz = bz - az;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d < 0.01) return true;
      const h = this.ray(ax, ay, az, dx / d, dy / d, dz / d, d);
      return !h || h.t >= d - 0.05;
    },
    move(a, dx, dy, dz) {
      const solids = this.solids, r = a.radius, h = a.height, step = 0.42, p = a.pos;
      const prevY = p.y;
      p.x += dx;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (b.y1 - p.y <= step && a.onGround) continue;
        if (dx > 0) p.x = b.x0 - r - 1e-4; else if (dx < 0) p.x = b.x1 + r + 1e-4;
      }
      p.z += dz;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (b.y1 - p.y <= step && a.onGround) continue;
        if (dz > 0) p.z = b.z0 - r - 1e-4; else if (dz < 0) p.z = b.z1 + r + 1e-4;
      }
      p.y += dy;
      a.onGround = false;
      if (p.y <= 0) { p.y = 0; if (a.vel.y < 0) a.vel.y = 0; a.onGround = true; }
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.y + h <= b.y0 || p.y >= b.y1) {
          if (Math.abs(p.y - b.y1) < 0.02 && a.vel.y <= 0) a.onGround = true;
          continue;
        }
        if (prevY >= b.y1 - step && a.vel.y <= 0.01) { p.y = b.y1; a.vel.y = 0; a.onGround = true; }
        else if (dy > 0) { p.y = b.y0 - h - 1e-3; a.vel.y = 0; }
        else { p.y = Math.max(p.y, b.y1); a.vel.y = 0; a.onGround = true; }
      }
      const bd = this.bounds;
      p.x = G.clamp(p.x, bd.x0 + r, bd.x1 - r);
      p.z = G.clamp(p.z, bd.z0 + r, bd.z1 - r);
    },
    blocked(x, z, r, maxY) {
      maxY = maxY == null ? 1.7 : maxY;
      const solids = this.solids;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (b.y0 > maxY || b.y1 < 0.3) continue;
        if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true;
      }
      const bd = this.bounds;
      return x < bd.x0 + r || x > bd.x1 - r || z < bd.z0 + r || z > bd.z1 - r;
    }
  };
})(window.G);
