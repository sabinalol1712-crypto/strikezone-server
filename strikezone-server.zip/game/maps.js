'use strict';
/* Карты: описание, постройка геометрии, столкновения и лучи. Активная карта — G.map */
(function (G) {
  const HP = Math.PI / 2;

  // ---------- конструктор описания карты ----------
  // все координаты раскладки умножаются на масштаб карты sc (размеры ящиков, бочек, высоты — нет)
  function makeApi(sc) {
    sc = sc || 1;
    const S = (v) => v * sc;
    const api = { boxes: [], decor: [], lamps: [], letters: [], sc };
    const rawB = (x0, z0, x1, z1, h, mat, y0, opts) => {
      opts = opts || {};
      api.boxes.push({
        x0: Math.min(x0, x1), z0: Math.min(z0, z1), x1: Math.max(x0, x1), z1: Math.max(z0, z1),
        y0: y0 || 0, y1: (y0 || 0) + h, mat, solid: opts.solid !== false, hidden: !!opts.hidden, uv: opts.uv || 'world'
      });
    };
    api.B = (x0, z0, x1, z1, h, mat, y0, opts) => rawB(S(x0), S(z0), S(x1), S(z1), h, mat, y0, opts);
    api.crate = (cx, cz, s, y0) => rawB(S(cx) - s / 2, S(cz) - s / 2, S(cx) + s / 2, S(cz) + s / 2, s, 'crate', y0 || 0, { uv: 'face' });
    api.stack = (cx, cz, s) => { api.crate(cx, cz, s); api.crate(cx + 0.08 / sc, cz - 0.05 / sc, s * 0.8, s); };
    api.lintel = (x0, z0, x1, z1, yb, yt, mat) => api.B(x0, z0, x1, z1, yt - yb, mat, yb);
    // декор: позиция масштабируется; DS — ещё и размеры по X/Z (кран, корабль)
    api.D = (...parts) => { for (const p of parts) { p.x = S(p.x || 0); p.z = S(p.z || 0); api.decor.push(p); } };
    api.DS = (...parts) => { for (const p of parts) { p.x = S(p.x || 0); p.z = S(p.z || 0); if (p.w) p.w *= sc; if (p.d) p.d *= sc; api.decor.push(p); } };
    api.barrel = (x, z, color) => {
      x = S(x); z = S(z);
      rawB(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 0.95, 'none', 0, { hidden: true });
      api.decor.push(G.geo.cyl(0.3, 0.95, x, 0.475, z, color || '#2f5f8a', 0, 0, 0, 12));
      api.decor.push(G.geo.cyl(0.31, 0.05, x, 0.3, z, '#222'), G.geo.cyl(0.31, 0.05, x, 0.68, z, '#222'));
    };
    api.lamp = (x, z, h, armDir) => {
      x = S(x); z = S(z);
      const d = armDir || 0;
      api.decor.push(G.geo.cyl(0.09, h, x, h / 2, z, '#3a3d40', 0, 0, 0, 8));
      api.decor.push(G.geo.box(0.1, 0.1, 1.2, x + Math.sin(d) * 0.55, h, z + Math.cos(d) * 0.55, '#3a3d40', 0, d, 0));
      api.decor.push(G.geo.box(0.36, 0.14, 0.5, x + Math.sin(d) * 1.1, h - 0.08, z + Math.cos(d) * 1.1, '#2a2c2e', 0, d, 0));
      api.lamps.push([x + Math.sin(d) * 1.1, h - 0.2, z + Math.cos(d) * 1.1]);
      rawB(x - 0.12, z - 0.12, x + 0.12, z + 0.12, h, 'none', 0, { hidden: true });
    };
    api.letter = (ch, x, z, size, rotY) => api.letters.push({ ch, x: S(x), z: S(z), size: size || 5, rotY: rotY || 0 });
    // наклейка на стену из атласа фасадов: n — '+x' | '-x' | '+z' | '-z'
    api.decals = []; api.awnings = []; api.fronds = []; api.ground = []; api.roofs = []; api.trees = []; api.blossoms = [];
    api.decal = (cell, x, y, z, w, h, n, atlas) => api.decals.push({ cell, x: S(x), y, z: S(z), w, h, n, atlas: atlas || 'facade', lit: cell === 5 });
    api.awning = (x, y, z, w, depth, n, col) => api.awnings.push({ x: S(x), y, z: S(z), w: w * sc, depth, n, col });
    api.palm = (x, z, h) => {
      x = S(x); z = S(z); h = h || 6.5;
      rawB(x - 0.25, z - 0.25, x + 0.25, z + 0.25, h, 'none', 0, { hidden: true });
      const lean = Math.random() * 6.28, segs = 6;
      let px = x, pz = z, py = 0;
      for (let i = 0; i < segs; i++) {
        const t = i / segs, sh = h / segs;
        const ox = Math.cos(lean) * 0.12 * (i + 1) * t, oz = Math.sin(lean) * 0.12 * (i + 1) * t;
        api.decor.push(G.geo.cyl(0.2 - t * 0.06, sh * 1.02, x + ox, py + sh / 2, z + oz, i % 2 ? '#7a6248' : '#6a543c', 0, 0, 0, 8, 0.22 - t * 0.06));
        api.decor.push(G.geo.cyl(0.23 - t * 0.06, 0.08, x + ox, py + sh * 0.95, z + oz, '#5a4632', 0, 0, 0, 8));
        px = x + ox; pz = z + oz; py += sh;
      }
      api.fronds.push({ x: px, y: py, z: pz, n: 9 });
    };
    api.wire = (a, b, sag) => {
      a = [S(a[0]), a[1], S(a[2])]; b = [S(b[0]), b[1], S(b[2])];
      const n = 6;
      for (let i = 0; i < n; i++) {
        const t0 = i / n, t1 = (i + 1) / n;
        const p0 = [a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0 - Math.sin(t0 * Math.PI) * sag, a[2] + (b[2] - a[2]) * t0];
        const p1 = [a[0] + (b[0] - a[0]) * t1, a[1] + (b[1] - a[1]) * t1 - Math.sin(t1 * Math.PI) * sag, a[2] + (b[2] - a[2]) * t1];
        api.decor.push(G.limb(p0, p1, 0.025, '#1c1c1c'));
      }
    };
    api.pole = (x, z, h) => {
      const X = S(x), Z = S(z);
      api.decor.push(G.geo.cyl(0.11, h, X, h / 2, Z, '#5a4430', 0, 0, 0, 8), G.geo.box(1.4, 0.1, 0.1, X, h - 0.4, Z, '#5a4430'));
      api.decor.push(G.geo.cyl(0.04, 0.12, X - 0.55, h - 0.3, Z, '#cfcfcf'), G.geo.cyl(0.04, 0.12, X + 0.55, h - 0.3, Z, '#cfcfcf'));
      rawB(X - 0.15, Z - 0.15, X + 0.15, Z + 0.15, h, 'none', 0, { hidden: true });
      return [x, h - 0.3, z];
    };
    api.sandbags = (x, z, len, rotY, rows) => {
      x = S(x); z = S(z); rows = rows || 2;
      const c = Math.cos(rotY), sn = Math.sin(rotY), n = Math.max(2, Math.round(len / 0.55));
      for (let r = 0; r < rows; r++) for (let i = 0; i < n - (r % 2); i++) {
        const o = -len / 2 + 0.28 + i * 0.55 + (r % 2) * 0.27;
        api.decor.push({ sph: true, r: 0.3, x: x + c * o, y: 0.13 + r * 0.22, z: z - sn * o, ry: rotY + (Math.random() - 0.5) * 0.12, sx: 0.98, sy: 0.46, sz: 0.72, color: ['#a8946a', '#9a865e', '#b09c72'][(i + r) % 3], seg: 9 });
      }
      const hx = Math.abs(c) * len / 2 + Math.abs(sn) * 0.3, hz = Math.abs(sn) * len / 2 + Math.abs(c) * 0.3;
      rawB(x - hx, z - hz, x + hx, z + hz, rows * 0.24 + 0.1, 'none', 0, { hidden: true });
    };
    api.tires = (x, z, n) => { x = S(x); z = S(z); for (let i = 0; i < n; i++) api.decor.push({ torus: true, r: 0.32, tube: 0.13, x, y: 0.13 + i * 0.25, z, rx: Math.PI / 2, color: '#1b1b1b', seg: 12 }); rawB(x - 0.45, z - 0.45, x + 0.45, z + 0.45, n * 0.25 + 0.05, 'none', 0, { hidden: true }); };
    api.reel = (x, z) => { x = S(x); z = S(z); api.decor.push(G.geo.cyl(0.6, 0.08, x, 0.6, z - 0.4, '#8a6a42', Math.PI / 2), G.geo.cyl(0.6, 0.08, x, 0.6, z + 0.4, '#8a6a42', Math.PI / 2), G.geo.cyl(0.3, 0.8, x, 0.6, z, '#2a2a2a', Math.PI / 2)); rawB(x - 0.6, z - 0.45, x + 0.6, z + 0.45, 1.2, 'none', 0, { hidden: true }); };
    api.stain = (x, z, sz) => api.ground.push({ kind: 'stain', x: S(x), z: S(z), sz: sz || 2 });
    api.pool = (x, z, sz) => api.ground.push({ kind: 'pool', x: S(x), z: S(z), sz: sz || 5 });
    jpApi(api, S, rawB, sc);
    return api;
  }

  // ---------- японский квартал: крыши, деревья, фонари, ворота ----------
  const _qa = new THREE.Quaternion(), _ea = new THREE.Euler(), _va = new THREE.Vector3(), _upv = new THREE.Vector3(0, 1, 0);
  // цилиндр между двумя точками (ветви, стебли, коньки вальм)
  function stick(a, b, r0, r1, color, seg) {
    _va.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const len = _va.length(); _va.normalize();
    _qa.setFromUnitVectors(_upv, _va); _ea.setFromQuaternion(_qa);
    return { cyl: true, r: r1, r2: r0, h: len, x: (a[0] + b[0]) / 2, y: (a[1] + b[1]) / 2, z: (a[2] + b[2]) / 2, color, rx: _ea.x, ry: _ea.y, rz: _ea.z, seg: seg || 6 };
  }
  const rnd = (a, b) => a + Math.random() * (b - a);
  const PINK = ['#ffffff', '#fff2f6', '#ffe8ef', '#f8e2ea', '#fff8fa'];

  function jpApi(api, S, rawB, sc) {
    const box = G.geo.box, cyl = G.geo.cyl, dec = api.decor;
    // черепичная крыша над стенами (x0..x1, z0..z1) с верхом стен y: подъём h и свес ov — в метрах
    // opt: hip — вальмовая, col — оттенок черепицы, gable — цвет фронтона, along — 'x'|'z'
    api.roof = (x0, z0, x1, z1, y, h, ov, opt) => {
      opt = opt || {}; ov = ov == null ? 0.8 : ov;
      const X0 = S(Math.min(x0, x1)), X1 = S(Math.max(x0, x1)), Z0 = S(Math.min(z0, z1)), Z1 = S(Math.max(z0, z1));
      const ax = opt.along ? opt.along === 'x' : (X1 - X0) >= (Z1 - Z0);
      const r = { X0, X1, Z0, Z1, y, h, ov, hip: !!opt.hip, col: opt.col || '#ffffff', alongX: ax };
      api.roofs.push(r);
      const g = roofFrame(r);
      const P = (aa, c, yy) => ax ? [aa, yy, c] : [c, yy, aa];
      const rc = opt.ridgeCol || '#2a2e34', trim = '#2b2622';
      const along = (len, hh, dd, aa, c, yy, col) => { const p = P(aa, c, yy); dec.push(box(ax ? len : dd, hh, ax ? dd : len, p[0], p[1], p[2], col)); };
      // доски свеса
      along(g.A1 - g.A0, 0.13, 0.1, g.mid, g.C0, g.ey - 0.05, trim); along(g.A1 - g.A0, 0.13, 0.1, g.mid, g.C1, g.ey - 0.05, trim);
      // конёк
      if (g.ra1 - g.ra0 > 0.05) along(g.ra1 - g.ra0 + 0.25, 0.26, 0.3, (g.ra0 + g.ra1) / 2, g.cc, g.top + 0.05, rc);
      if (!r.hip) {
        // фронтоны и концевые плитки они-гавара
        for (const aa of [g.a0w + 0.07, g.a1w - 0.07]) {
          const p = P(aa, g.cc, y);
          dec.push({ shape: true, pts: [[-g.hw0, 0], [0, h], [g.hw0, 0]], d: 0.12, x: p[0], y, z: p[2], color: opt.gable || '#e9e2d4', ry: ax ? 0 : HP, cs: 1 });
        }
        for (const aa of [g.A0 + 0.12, g.A1 - 0.12]) { const p = P(aa, g.cc, g.top + 0.12); dec.push(box(ax ? 0.26 : 0.36, 0.44, ax ? 0.36 : 0.26, p[0], p[1], p[2], rc)); }
        // торцевые доски вдоль скатов
        for (const aa of [g.A0, g.A1]) for (const s of [-1, 1]) dec.push(stick(P(aa, g.cc + s * g.hw, g.ey - 0.02), P(aa, g.cc, g.top), 0.07, 0.07, trim, 4));
      } else {
        for (const aa of [g.A0, g.A1]) { const p = P(aa, g.cc, g.ey - 0.05); dec.push(box(ax ? 0.1 : g.C1 - g.C0, 0.13, ax ? g.C1 - g.C0 : 0.1, p[0], p[1], p[2], trim)); }
        // рёбра вальм
        for (const [aa, ra] of [[g.A0, g.ra0], [g.A1, g.ra1]]) for (const c of [g.C0, g.C1]) dec.push(stick(P(aa, c, g.ey + 0.02), P(ra, g.cc, g.top + 0.06), 0.11, 0.09, rc, 5));
        if (opt.finial) { const p = P(g.mid, g.cc, g.top); dec.push(cyl(0.12, opt.finial, p[0], g.top + opt.finial / 2, p[2], '#6b5a3a', 0, 0, 0, 8)); if (opt.finial > 3) for (let i = 0; i < 7; i++) dec.push({ torus: true, r: 0.5 - i * 0.04, tube: 0.07, x: p[0], y: g.top + opt.finial * (0.25 + i * 0.08), z: p[2], rx: HP, color: '#8a7448', seg: 10 });
          dec.push({ sph: true, r: opt.finial > 3 ? 0.32 : 0.14, x: p[0], y: g.top + opt.finial, z: p[2], color: '#c9a54a', seg: 8 }); }
      }
    };
    // сакура: ствол, развилка, ветви и облака цветов; лепестки падают вокруг
    api.sakura = (x, z, h, k, far) => {
      const X = S(x), Z = S(z); h = h || 6; k = k || 1;
      const lean = Math.random() * 6.28, fh = h * 0.36;
      const fork = [X + Math.cos(lean) * 0.35 * k, fh, Z + Math.sin(lean) * 0.35 * k];
      dec.push(stick([X, 0, Z], [X, 0.6, Z], 0.42 * k, 0.32 * k, '#3a2a20', 7), stick([X, 0.5, Z], fork, 0.32 * k, 0.22 * k, '#4a3428', 7));
      const m = 4 + (Math.random() < 0.5 ? 1 : 0);
      const blob = (p, r) => api.blossoms.push({ sph: true, r, x: p[0], y: p[1], z: p[2], sx: 1.15, sy: 0.74, sz: 1.1, ry: Math.random() * 3, color: PINK[(Math.random() * PINK.length) | 0], seg: far ? 6 : 8 });
      for (let j = 0; j < m; j++) {
        const ang = lean + j * 6.28 / m + rnd(-0.35, 0.35), out = rnd(1.5, 2.3) * k, up = h * rnd(0.6, 0.72);
        const end = [fork[0] + Math.cos(ang) * out, up, fork[2] + Math.sin(ang) * out];
        dec.push(stick(fork, end, 0.2 * k, 0.09 * k, '#4a3428'));
        const midp = [(fork[0] + end[0]) / 2, (fork[1] + end[1]) / 2, (fork[2] + end[2]) / 2];
        const a2 = ang + rnd(-0.7, 0.7), end2 = [midp[0] + Math.cos(a2) * 1.4 * k, up + rnd(-0.6, 0.4), midp[2] + Math.sin(a2) * 1.4 * k];
        dec.push(stick(midp, end2, 0.1 * k, 0.05 * k, '#4a3428', 5));
        blob(end, rnd(1.25, 1.6) * k); blob(end2, rnd(1.0, 1.3) * k);
        blob([end[0] + Math.cos(ang) * 0.9 * k, end[1] - 0.7 * k, end[2] + Math.sin(ang) * 0.9 * k], rnd(0.8, 1.05) * k);
      }
      blob([fork[0], h * 0.86, fork[2]], 1.75 * k); blob([fork[0] + 0.6, h * 0.76, fork[2] - 0.5], 1.4 * k);
      if (!far) {
        rawB(X - 0.32 * k, Z - 0.32 * k, X + 0.32 * k, Z + 0.32 * k, fh + 0.3, 'none', 0, { hidden: true });
        api.ground.push({ kind: 'petals', x: X, z: Z, sz: 6.5 * k });
      }
      api.trees.push({ x: fork[0], y: h * 0.72, z: fork[2], r: 2.6 * k, petals: !far });
    };
    // каменный фонарь торо
    api.toro = (x, z, k) => {
      const X = S(x), Z = S(z); k = k || 1;
      const st = '#8e8b83', dk = '#77746c';
      dec.push(box(0.78 * k, 0.22 * k, 0.78 * k, X, 0.11 * k, Z, dk), cyl(0.3 * k, 0.18 * k, X, 0.31 * k, Z, st, 0, 0, 0, 6),
        cyl(0.13 * k, 0.78 * k, X, 0.79 * k, Z, st, 0, 0, 0, 8), box(0.64 * k, 0.16 * k, 0.64 * k, X, 1.25 * k, Z, dk),
        box(0.44 * k, 0.42 * k, 0.44 * k, X, 1.54 * k, Z, st), box(0.22 * k, 0.22 * k, 0.46 * k, X, 1.54 * k, Z, '#ffdc96'), box(0.46 * k, 0.22 * k, 0.22 * k, X, 1.54 * k, Z, '#ffdc96'),
        { cyl: true, r: 0.03, r2: 0.56 * k, h: 0.32 * k, x: X, y: 1.91 * k, z: Z, color: dk, seg: 4, ry: Math.PI / 4 }, { sph: true, r: 0.1 * k, x: X, y: 2.12 * k, z: Z, color: st, seg: 6 });
      api.lamps.push([X, 1.54 * k, Z, 0.8 * k]);
      rawB(X - 0.39 * k, Z - 0.39 * k, X + 0.39 * k, Z + 0.39 * k, 2.15 * k, 'none', 0, { hidden: true });
    };
    // бумажный фонарь тётин на шнуре (координаты x,z — в масштабе карты, y — в метрах)
    api.chochin = (x, y, z, col, top) => {
      const X = S(x), Z = S(z), t = Math.max(top || 0, y + 0.6);
      dec.push(cyl(0.01, t - y - 0.3, X, (t + y + 0.3) / 2, Z, '#1a1a1a', 0, 0, 0, 4), { sph: true, r: 0.24, x: X, y, z: Z, sy: 1.3, color: col || '#d6402a', seg: 7 },
        cyl(0.13, 0.06, X, y + 0.3, Z, '#1d1d1d', 0, 0, 0, 6), cyl(0.13, 0.06, X, y - 0.3, Z, '#1d1d1d', 0, 0, 0, 6));
      api.lamps.push([X, y, Z, 1.0]);
    };
    // ворота тории: w — пролёт (в масштабе карты), h — высота в метрах, rot — 0 (поперёк Z) или HP
    api.torii = (x, z, w, h, rot, col) => {
      const X = S(x), Z = S(z), W = S(w), c = col || '#c8321e', dx = rot ? 0 : 1, dz = rot ? 1 : 0, ry = rot ? HP : 0;
      for (const s of [-1, 1]) {
        const px = X + dx * s * W / 2, pz = Z + dz * s * W / 2;
        dec.push(cyl(0.21, h, px, h / 2, pz, c, 0, 0, 0, 12, 0.25), cyl(0.27, 0.5, px, 0.25, pz, '#1d1d1d', 0, 0, 0, 12));
        rawB(px - 0.28, pz - 0.28, px + 0.28, pz + 0.28, h, 'none', 0, { hidden: true });
        // приподнятые концы верхней балки
        dec.push(box(1.5, 0.3, 0.55, X + dx * s * (W / 2 + 0.55), h + 0.42, Z + dz * s * (W / 2 + 0.55), '#1d1d1d', rot ? -s * 0.12 : 0, ry, rot ? 0 : s * 0.12));
      }
      dec.push(box(W + 0.6, 0.3, 0.55, X, h + 0.36, Z, '#1d1d1d', 0, ry, 0), box(W + 1.7, 0.24, 0.44, X, h + 0.12, Z, c, 0, ry, 0),
        box(W + 0.9, 0.22, 0.24, X, h - 0.85, Z, c, 0, ry, 0), box(0.24, 0.7, 0.22, X, h - 0.4, Z, c, 0, ry, 0),
        box(0.62, 0.78, 0.1, X, h - 0.4, Z, '#24201c', 0, ry, 0), box(0.46, 0.6, 0.12, X, h - 0.4, Z, '#d9b23a', 0, ry, 0));
    };
    // горбатый мост вдоль X: ступени-столкновения + изогнутый настил и перила
    api.bridge = (xc, zc, len) => {
      const L = S(len), X = S(xc), Z = S(zc), Wd = 2.4;
      for (const [f0, f1, hh] of [[0, 0.15, 0.3], [0.15, 0.3, 0.6], [0.3, 0.7, 0.85], [0.7, 0.85, 0.6], [0.85, 1, 0.3]])
        rawB(X - L / 2 + f0 * L, Z - Wd / 2, X - L / 2 + f1 * L, Z + Wd / 2, hh, 'none', 0, { hidden: true });
      const yAt = (t) => 0.06 + 0.82 * Math.min(1, Math.sin(Math.PI * t) * 1.25);
      const N = 14, xAt = (t) => X - L / 2 + t * L;
      for (let i = 0; i < N; i++) {
        const t0 = i / N, t1 = (i + 1) / N, x0 = xAt(t0), x1 = xAt(t1), y0 = yAt(t0), y1 = yAt(t1);
        const ang = Math.atan2(y1 - y0, x1 - x0), ln = Math.hypot(x1 - x0, y1 - y0);
        dec.push(box(ln + 0.04, 0.14, Wd, (x0 + x1) / 2, (y0 + y1) / 2 - 0.07, Z, i % 2 ? '#7a4e30' : '#86583a', 0, 0, ang));
        for (const s of [-1, 1]) {
          dec.push(box(ln + 0.02, 0.08, 0.1, (x0 + x1) / 2, (y0 + y1) / 2 + 0.85, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, ang));
          if (i % 2 === 0) dec.push(cyl(0.06, 0.9, x0, y0 + 0.43, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, 0, 6));
        }
      }
      for (const t of [0, 1]) for (const s of [-1, 1]) dec.push(cyl(0.08, 1.0, xAt(t), 0.5, Z + s * (Wd / 2 - 0.06), '#c8321e', 0, 0, 0, 8), { sph: true, r: 0.12, x: xAt(t), y: 1.08, z: Z + s * (Wd / 2 - 0.06), sy: 1.4, color: '#b58a3a', seg: 8 });
      for (const t of [0.3, 0.5, 0.7]) for (const s of [-1, 1]) dec.push(cyl(0.11, yAt(t), xAt(t), yAt(t) / 2, Z + s * (Wd / 2 - 0.3), '#4a3426', 0, 0, 0, 8));
    };
    // пруд с карпами: вода на земле и каменная кайма
    api.pond = (x0, z0, x1, z1) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.ground.push({ kind: 'pond', x: (X0 + X1) / 2, z: (Z0 + Z1) / 2, w: X1 - X0, d: Z1 - Z0 });
      const per = 2 * (X1 - X0 + Z1 - Z0), n = Math.round(per / 0.75);
      for (let i = 0; i < n; i++) {
        let t = i / n * per, px, pz;
        if (t < X1 - X0) { px = X0 + t; pz = Z0; } else if ((t -= X1 - X0) < Z1 - Z0) { px = X1; pz = Z0 + t; }
        else if ((t -= Z1 - Z0) < X1 - X0) { px = X1 - t; pz = Z1; } else { t -= X1 - X0; px = X0; pz = Z1 - t; }
        const v = 92 + Math.random() * 34 | 0;
        dec.push({ sph: true, r: rnd(0.32, 0.46), x: px + rnd(-0.1, 0.1), y: 0.04, z: pz + rnd(-0.1, 0.1), sy: 0.55, ry: Math.random() * 3, color: `rgb(${v},${v - 2},${v - 8})`, seg: 7 });
      }
    };
    api.rock = (x, z, s) => {
      const X = S(x), Z = S(z);
      dec.push({ sph: true, r: s * 0.62, x: X, y: s * 0.18, z: Z, sx: 1.25, sy: 0.8, sz: 1.0, ry: Math.random() * 3, color: '#7b7870', seg: 7 },
        { sph: true, r: s * 0.38, x: X + s * 0.45, y: s * 0.08, z: Z - s * 0.3, sy: 0.7, ry: Math.random() * 3, color: '#6d6b64', seg: 6 });
      rawB(X - s * 0.62, Z - s * 0.55, X + s * 0.62, Z + s * 0.55, s * 0.62, 'none', 0, { hidden: true });
    };
    // пирамида бочек сакэ (rot: 0 — вдоль X, HP — вдоль Z), лицом в сторону face (+1/-1)
    api.taru = (x, z, n, rot, face) => {
      const X = S(x), Z = S(z), dx = rot ? 0 : 1, dz = rot ? 1 : 0, f = face || 1;
      const lab = ['#b02a1e', '#23326a', '#f2ece0', '#1d1d1d'];
      for (let r = 0; r < n; r++) for (let i = 0; i < n - r; i++) {
        const o = (i - (n - r - 1) / 2) * 0.7, px = X + dx * o, pz = Z + dz * o, y = r * 0.66 + 0.33;
        dec.push(cyl(0.34, 0.64, px, y, pz, '#dccb9c', 0, 0, 0, 9), cyl(0.35, 0.05, px, y + 0.26, pz, '#3a2a1a', 0, 0, 0, 9), cyl(0.35, 0.05, px, y - 0.26, pz, '#3a2a1a', 0, 0, 0, 9));
        dec.push(box(rot ? 0.03 : 0.34, 0.34, rot ? 0.34 : 0.03, px + (rot ? f * 0.335 : 0), y, pz + (rot ? 0 : f * 0.335), lab[(r * 3 + i) % 4]));
      }
      const hl = n * 0.35 + 0.02;
      rawB(X - (dx ? hl : 0.36), Z - (dz ? hl : 0.36), X + (dx ? hl : 0.36), Z + (dz ? hl : 0.36), n * 0.66, 'none', 0, { hidden: true });
    };
    // ручная тележка (rot: 0 — вдоль X, HP — вдоль Z)
    api.cart = (x, z, rot) => {
      const X = S(x), Z = S(z), ax = !rot, ry = rot ? HP : 0;
      const L = (lx, lz) => ax ? [X + lx, Z + lz] : [X + lz, Z - lx];
      dec.push(box(2.4, 0.12, 1.3, X, 0.78, Z, '#7a5434', 0, ry, 0));
      for (const s of [-1, 1]) { const p = L(0, s * 0.62); dec.push(box(2.4, 0.3, 0.06, p[0], 0.98, p[1], '#6a4a2e', 0, ry, 0)); }
      for (const s of [-1, 1]) {
        const p = L(0.2, s * 0.76);
        dec.push({ torus: true, r: 0.46, tube: 0.06, x: p[0], y: 0.46, z: p[1], ry, color: '#3a2a1e', seg: 16 });
        for (let k = 0; k < 4; k++) dec.push(box(0.9, 0.05, 0.05, p[0], 0.46, p[1], '#3a2a1e', 0, ry, k * Math.PI / 4));
      }
      for (const s of [-1, 1]) { const a0 = L(-1.2, s * 0.5), a1 = L(-2.5, s * 0.5); dec.push(stick([a0[0], 0.8, a0[1]], [a1[0], 0.35, a1[1]], 0.05, 0.04, '#6a4a2e', 5)); }
      const sk = ['#d8c8a0', '#cdbb8c', '#e2d4b0'];
      for (let i = 0; i < 4; i++) { const p = L(-0.75 + i * 0.5, (i % 2 ? 0.25 : -0.2)); dec.push({ sph: true, r: 0.36, x: p[0], y: 1.06, z: p[1], sx: 1.2, sy: 0.6, sz: 0.8, ry: ry + i, color: sk[i % 3], seg: 8 }); }
      const hx = ax ? 1.3 : 0.8, hz = ax ? 0.8 : 1.3;
      rawB(X - hx, Z - hz, X + hx, Z + hz, 1.3, 'none', 0, { hidden: true });
    };
    // лавка-ятай: прилавок, стойки, навес-крыша, занавес норэн
    api.stall = (x0, z0, x1, z1, face, col) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.B(x0, z0, x1, z1, 1.05, 'planks');
      for (const [px, pz] of [[X0 + 0.1, Z0 + 0.1], [X1 - 0.1, Z0 + 0.1], [X0 + 0.1, Z1 - 0.1], [X1 - 0.1, Z1 - 0.1]]) dec.push(cyl(0.07, 2.5, px, 1.25, pz, '#5a3c26', 0, 0, 0, 6));
      api.roof(x0 - 0.1, z0 - 0.1, x1 + 0.1, z1 + 0.1, 2.5, 0.7, 0.35, { col: '#b8a089', gable: '#5a3c26' });
      const fz = face > 0 ? Z1 + 0.05 : Z0 - 0.05, w = X1 - X0, n = Math.max(2, Math.round(w / 0.9));
      for (let i = 0; i < n; i++) dec.push(box(w / n - 0.06, 0.7, 0.03, X0 + (i + 0.5) * w / n, 2.12, fz, col || '#23326a'));
      const goods = ['#e8452a', '#f2a03a', '#e9e3d0', '#7aa04a', '#c8321e'];
      for (let i = 0; i < 6; i++) dec.push({ sph: true, r: 0.12, x: X0 + 0.4 + Math.random() * (w - 0.8), y: 1.12, z: (Z0 + Z1) / 2 + rnd(-0.3, 0.3), color: goods[i % 5], seg: 6 });
      dec.push(box(0.5, 0.18, 0.35, X0 + w * 0.3, 1.14, (Z0 + Z1) / 2, '#3a2a1e'), box(0.4, 0.22, 0.4, X0 + w * 0.7, 1.16, (Z0 + Z1) / 2 + 0.1, '#7a5a3a'));
    };
    // беседка азумая с вальмовой крышей
    api.pavilion = (x, z, s) => {
      const X = S(x), Z = S(z), hs = S(s) / 2;
      api.B(x - s / 2, z - s / 2, x + s / 2, z + s / 2, 0.25, 'planks');
      for (const [px, pz] of [[X - hs + 0.25, Z - hs + 0.25], [X + hs - 0.25, Z - hs + 0.25], [X - hs + 0.25, Z + hs - 0.25], [X + hs - 0.25, Z + hs - 0.25]]) {
        dec.push(cyl(0.12, 2.5, px, 1.5, pz, '#6a4a30', 0, 0, 0, 8));
        rawB(px - 0.16, pz - 0.16, px + 0.16, pz + 0.16, 2.75, 'none', 0, { hidden: true });
      }
      rawB(X - 0.9, Z - 0.3, X + 0.9, Z + 0.3, 0.7, 'none', 0, { hidden: true });
      dec.push(box(1.8, 0.08, 0.6, X, 0.68, Z, '#7a5434'), box(0.1, 0.42, 0.5, X - 0.8, 0.46, Z, '#5a3c26'), box(0.1, 0.42, 0.5, X + 0.8, 0.46, Z, '#5a3c26'));
      api.roof(x - s / 2, z - s / 2, x + s / 2, z + s / 2, 2.75, 1.5, 0.55, { hip: true, col: '#d4d8de', finial: 0.5 });
    };
    // двухэтажная машия: цоколь, решётка первого этажа, штукатурка с балками наверху, навес между этажами, главная крыша
    // o: h — высота, rise — подъём крыши, face — сторона фасада ('+z'|'-z'|'+x'|'-x'), shop — вывеска/норэн, solid:false — декорация за оградой
    api.house2 = (x0, z0, x1, z1, o) => {
      o = o || {}; const h = o.h || 5.6, lo = 2.5, X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      const sopt = o.solid === false ? { solid: false } : null;
      api.B(x0, z0, x1, z1, 0.3, 'stonewall', 0, sopt);
      api.B(x0, z0, x1, z1, lo - 0.3, 'koshi', 0.3, sopt);
      api.B(x0, z0, x1, z1, h - lo, 'plaster', lo, sopt);
      // горизонтальные балки и столбы
      const beam = '#3a2a1e';
      for (const yy of [lo + 0.05, h - 0.12]) {
        dec.push(box(X1 - X0 + 0.16, 0.22, 0.16, (X0 + X1) / 2, yy, Z0 - 0.04, beam), box(X1 - X0 + 0.16, 0.22, 0.16, (X0 + X1) / 2, yy, Z1 + 0.04, beam));
        dec.push(box(0.16, 0.22, Z1 - Z0 + 0.16, X0 - 0.04, yy, (Z0 + Z1) / 2, beam), box(0.16, 0.22, Z1 - Z0 + 0.16, X1 + 0.04, yy, (Z0 + Z1) / 2, beam));
      }
      const nx = Math.max(1, Math.round((X1 - X0) / 3.2)), nz = Math.max(1, Math.round((Z1 - Z0) / 3.2));
      for (let i = 0; i <= nx; i++) { const px = X0 + (X1 - X0) * i / nx; dec.push(box(0.16, h - lo, 0.1, px, (h + lo) / 2, Z0 - 0.05, beam), box(0.16, h - lo, 0.1, px, (h + lo) / 2, Z1 + 0.05, beam)); }
      for (let i = 0; i <= nz; i++) { const pz = Z0 + (Z1 - Z0) * i / nz; dec.push(box(0.1, h - lo, 0.16, X0 - 0.05, (h + lo) / 2, pz, beam), box(0.1, h - lo, 0.16, X1 + 0.05, (h + lo) / 2, pz, beam)); }
      // навес хисаси над первым этажом и главная крыша
      api.roof(x0, z0, x1, z1, lo + 0.25, 0.42, 0.95, { col: o.col || '#ffffff', ridgeCol: '#30343a' });
      api.roof(x0, z0, x1, z1, h, o.rise || 2.2, o.ov == null ? 1.0 : o.ov, { col: o.col || '#ffffff', gable: '#e9e2d4', hip: !!o.hip });
      // окна верхнего этажа (сёдзи) по длинным сторонам
      const long = (X1 - X0) >= (Z1 - Z0);
      const n = Math.max(1, Math.round((long ? X1 - X0 : Z1 - Z0) / 4));
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n;
        if (long) { const px = X0 + (X1 - X0) * t; api.decals.push({ cell: 1, x: px, y: lo + 1.55, z: Z0, w: 1.6, h: 1.5, n: '-z', atlas: 'jp' }, { cell: 1, x: px, y: lo + 1.55, z: Z1, w: 1.6, h: 1.5, n: '+z', atlas: 'jp' }); }
        else { const pz = Z0 + (Z1 - Z0) * t; api.decals.push({ cell: 1, x: X0, y: lo + 1.55, z: pz, w: 1.6, h: 1.5, n: '-x', atlas: 'jp' }, { cell: 1, x: X1, y: lo + 1.55, z: pz, w: 1.6, h: 1.5, n: '+x', atlas: 'jp' }); }
      }
    };
    // энгава: приподнятая деревянная веранда вдоль стены дома (x0..x1 по X при n='+z'/'-z'), со столбами и перилами
    api.veranda = (x0, z0, x1, z1, n) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1);
      api.B(x0, z0, x1, z1, 0.4, 'planks');
      const along = n === '+z' || n === '-z', edge = n === '+z' ? Z1 : n === '-z' ? Z0 : n === '+x' ? X1 : X0;
      const len = along ? X1 - X0 : Z1 - Z0, m = Math.max(2, Math.round(len / 2.2));
      for (let i = 0; i <= m; i++) {
        const t = i / m, px = along ? X0 + len * t : edge, pz = along ? edge : Z0 + len * t;
        dec.push(cyl(0.07, 0.95, px, 0.85, pz, '#5a3c26', 0, 0, 0, 6));
      }
      const cx = along ? (X0 + X1) / 2 : edge, cz = along ? edge : (Z0 + Z1) / 2;
      dec.push(box(along ? len : 0.08, 0.07, along ? 0.08 : len, cx, 1.28, cz, '#6a4a30'), box(along ? len : 0.05, 0.05, along ? 0.05 : len, cx, 0.86, cz, '#6a4a30'));
      // ступенька
      const sx = along ? (X0 + X1) / 2 : edge + (n === '+x' ? 0.35 : -0.35), sz = along ? edge + (n === '+z' ? 0.35 : -0.35) : (Z0 + Z1) / 2;
      rawB(sx - (along ? 0.8 : 0.3), sz - (along ? 0.3 : 0.8), sx + (along ? 0.8 : 0.3), sz + (along ? 0.3 : 0.8), 0.2, 'stonewall', 0);
    };
    // каменная лестница на платформу: dir — направление подъёма ('+z' и т.д.), w — ширина, top — высота платформы
    api.stairs = (x, z, dir, w, top) => {
      const X = S(x), Z = S(z), W = S(w), n = Math.max(1, Math.round(top / 0.4)), dx = dir === '+x' ? 1 : dir === '-x' ? -1 : 0, dz = dir === '+z' ? 1 : dir === '-z' ? -1 : 0;
      for (let i = 0; i < n; i++) {
        const hh = top * (i + 1) / n, d0 = i * 0.45, d1 = (n - 0) * 0.45;
        const ax = X + dx * d0, az = Z + dz * d0, bx = X + dx * d1, bz = Z + dz * d1;
        rawB(Math.min(ax, bx) - (dx ? 0 : W / 2), Math.min(az, bz) - (dz ? 0 : W / 2), Math.max(ax, bx) + (dx ? 0 : W / 2), Math.max(az, bz) + (dz ? 0 : W / 2), hh, 'stonewall', 0);
      }
    };
    // живая изгородь (с проходами, если даны gaps — массив [z0,z1] или [x0,x1] пропусков по длинной оси)
    api.hedge = (x0, z0, x1, z1, h, gaps) => {
      const along = Math.abs(x1 - x0) >= Math.abs(z1 - z0);
      let segs = [[along ? x0 : z0, along ? x1 : z1]];
      for (const g of gaps || []) { const out = []; for (const [a0, a1] of segs) { if (g[1] <= a0 || g[0] >= a1) out.push([a0, a1]); else { if (g[0] > a0) out.push([a0, g[0]]); if (g[1] < a1) out.push([g[1], a1]); } } segs = out; }
      for (const [a0, a1] of segs) {
        if (along) api.B(a0, z0, a1, z1, h || 1.25, 'hedge'); else api.B(x0, a0, x1, a1, h || 1.25, 'hedge');
        const n = Math.max(1, Math.round(S(a1 - a0) / 1.1));
        for (let i = 0; i < n; i++) {
          const t = (i + 0.5) / n, px = along ? S(a0 + (a1 - a0) * t) : S((x0 + x1) / 2), pz = along ? S((z0 + z1) / 2) : S(a0 + (a1 - a0) * t);
          dec.push({ sph: true, r: 0.62, x: px, y: (h || 1.25) - 0.05, z: pz, sx: along ? 1.1 : 0.75, sy: 0.5, sz: along ? 0.75 : 1.1, color: i % 2 ? '#4f7a36' : '#5a8a3c', seg: 7 });
        }
      }
    };
    // деревянный забор с перекладинами
    api.fence = (x0, z0, x1, z1) => {
      const X0 = S(x0), X1 = S(x1), Z0 = S(z0), Z1 = S(z1), along = Math.abs(X1 - X0) >= Math.abs(Z1 - Z0), len = along ? X1 - X0 : Z1 - Z0;
      const n = Math.max(1, Math.round(len / 1.6)), cx = (X0 + X1) / 2, cz = (Z0 + Z1) / 2;
      for (let i = 0; i <= n; i++) { const t = i / n; dec.push(box(0.12, 1.2, 0.12, along ? X0 + len * t : cx, 0.6, along ? cz : Z0 + len * t, '#4a3426')); }
      for (const yy of [0.5, 1.0]) dec.push(box(along ? len : 0.06, 0.1, along ? 0.06 : len, cx, yy, cz, '#6a4a30'));
      rawB(Math.min(X0, X1) - 0.06, Math.min(Z0, Z1) - 0.06, Math.max(X0, X1) + 0.06, Math.max(Z0, Z1) + 0.06, 1.2, 'none', 0, { hidden: true });
    };
    api.bench = (x, z, rot) => {
      const X = S(x), Z = S(z), ry = rot ? HP : 0;
      dec.push(box(1.8, 0.08, 0.5, X, 0.45, Z, '#7a5434', 0, ry, 0), box(0.12, 0.42, 0.42, X + (rot ? 0 : 0.75), 0.21, Z + (rot ? 0.75 : 0), '#4a3426', 0, ry, 0), box(0.12, 0.42, 0.42, X - (rot ? 0 : 0.75), 0.21, Z - (rot ? 0.75 : 0), '#4a3426', 0, ry, 0));
      dec.push(box(1.5, 0.05, 0.4, X, 0.52, Z, '#b02a1e', 0, ry, 0));
      const hx = rot ? 0.28 : 0.92, hz = rot ? 0.92 : 0.28;
      rawB(X - hx, Z - hz, X + hx, Z + hz, 0.5, 'none', 0, { hidden: true });
    };
    // горшок с растением
    api.pot = (x, z, k) => {
      const X = S(x), Z = S(z); k = k || 1;
      dec.push(cyl(0.22 * k, 0.32 * k, X, 0.16 * k, Z, '#6b4a3a', 0, 0, 0, 8, 0.17 * k));
      for (let i = 0; i < 4; i++) dec.push({ sph: true, r: 0.2 * k, x: X + rnd(-0.1, 0.1) * k, y: 0.42 * k + i * 0.06, z: Z + rnd(-0.1, 0.1) * k, sx: 1.2, sy: 0.7, color: i % 2 ? '#4f8a3a' : '#5f9a42', seg: 6 });
      rawB(X - 0.24 * k, Z - 0.24 * k, X + 0.24 * k, Z + 0.24 * k, 0.5 * k, 'none', 0, { hidden: true });
    };
    // каменная чаша цукубай с бамбуковым желобом
    api.basin = (x, z) => {
      const X = S(x), Z = S(z);
      dec.push({ sph: true, r: 0.48, x: X, y: 0.3, z: Z, sy: 0.7, color: '#767a74', seg: 9 }, cyl(0.3, 0.04, X, 0.6, Z, '#2a5a5e', 0, 0, 0, 10));
      dec.push(cyl(0.05, 1.0, X + 0.5, 0.5, Z, '#b8b56a', 0, 0, 0, 6), cyl(0.04, 0.5, X + 0.3, 0.95, Z, '#b8b56a', 0, 0, HP, 6));
      for (let i = 0; i < 4; i++) dec.push({ sph: true, r: 0.14, x: X + rnd(-0.8, 0.8), y: 0.06, z: Z + rnd(-0.8, 0.8), sy: 0.5, color: '#7e8278', seg: 6 });
      rawB(X - 0.5, Z - 0.5, X + 0.5, Z + 0.5, 0.7, 'none', 0, { hidden: true });
    };
    // бумажный зонт вагаса, раскрытый (стоит или лежит)
    api.wagasa = (x, z, col, tilt) => {
      const X = S(x), Z = S(z), c = col || '#c8321e';
      dec.push({ cyl: true, r: 0.02, r2: 1.05, h: 0.32, x: X, y: 1.9, z: Z, color: c, seg: 16, rz: tilt || 0 }, cyl(0.025, 1.9, X, 0.95, Z, '#5a3c26', 0, 0, tilt || 0, 6));
      for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; dec.push(box(0.02, 0.012, 1.0, X + Math.cos(an) * 0.5, 1.75, Z + Math.sin(an) * 0.5, '#f2e6c8', 0, -an + HP, 0)); }
      rawB(X - 0.15, Z - 0.15, X + 0.15, Z + 0.15, 1.9, 'none', 0, { hidden: true });
    };
    // колокол на деревянной раме
    api.bell = (x, z) => {
      const X = S(x), Z = S(z);
      api.B(x - 1.1, z - 1.1, x + 1.1, z + 1.1, 0.45, 'stonewall');
      for (const [px, pz] of [[X - 0.85, Z - 0.85], [X + 0.85, Z - 0.85], [X - 0.85, Z + 0.85], [X + 0.85, Z + 0.85]]) { dec.push(cyl(0.11, 3.0, px, 1.95, pz, '#5a3c26', 0, 0, 0, 8)); rawB(px - 0.14, pz - 0.14, px + 0.14, pz + 0.14, 3.5, 'none', 0, { hidden: true }); }
      dec.push(box(2.2, 0.2, 0.2, X, 3.45, Z - 0.85, '#5a3c26'), box(2.2, 0.2, 0.2, X, 3.45, Z + 0.85, '#5a3c26'), box(0.2, 0.2, 2.0, X, 3.45, Z, '#5a3c26'));
      dec.push({ cyl: true, r: 0.42, r2: 0.3, h: 1.0, x: X, y: 2.4, z: Z, color: '#4b5a3a', seg: 14 }, cyl(0.1, 0.4, X, 3.1, Z, '#3a2a1e', 0, 0, 0, 6), cyl(0.44, 0.06, X, 1.9, Z, '#3f4a30', 0, 0, 0, 14));
      dec.push(cyl(0.12, 1.6, X + 1.4, 2.6, Z, '#6a4a30', 0, 0, HP, 8));
      api.roof(x - 1.3, z - 1.3, x + 1.3, z + 1.3, 3.55, 1.0, 0.5, { hip: true, col: '#8cbcaa', ridgeCol: '#3d5a50' });
      rawB(X - 0.45, Z - 0.45, X + 0.45, Z + 0.45, 3.0, 'none', 0, { hidden: true });
    };
    // стена с табличками эма (укрытие)
    api.emaWall = (x, z, w, rot) => {
      const X = S(x), Z = S(z), W = S(w), ry = rot ? HP : 0;
      dec.push(box(W, 0.12, 0.3, X, 1.85, Z, '#5a3c26', 0, ry, 0), box(W, 1.3, 0.08, X, 1.15, Z, '#8a6a46', 0, ry, 0));
      for (const s of [-1, 1]) dec.push(box(0.14, 1.9, 0.14, X + (rot ? 0 : s * W / 2), 0.95, Z + (rot ? s * W / 2 : 0), '#4a3426'));
      const n = Math.max(2, Math.round(W / 0.5));
      for (let i = 0; i < n; i++) for (let r = 0; r < 2; r++) for (const sd of [-1, 1]) { const t = (i + 0.5) / n - 0.5, px = X + (rot ? 0 : t * W), pz = Z + (rot ? t * W : 0); dec.push(box(0.34, 0.28, 0.04, px + (rot ? sd * 0.06 : 0), 1.3 - r * 0.34, pz + (rot ? 0 : sd * 0.06), ['#c8a06a', '#d8b27a', '#b89060'][(i + r) % 3], 0, ry, 0)); }
      api.roof(x - (rot ? 0.5 : w / 2), z - (rot ? w / 2 : 0.5), x + (rot ? 0.5 : w / 2), z + (rot ? w / 2 : 0.5), 1.95, 0.4, 0.3, { col: '#d4d8de', along: rot ? 'z' : 'x' });
      rawB(X - (rot ? 0.2 : W / 2), Z - (rot ? W / 2 : 0.2), X + (rot ? 0.2 : W / 2), Z + (rot ? W / 2 : 0.2), 2.0, 'none', 0, { hidden: true });
    };
    // маленькое придорожное святилище хокора
    api.hokora = (x, z, rot) => {
      const X = S(x), Z = S(z), ry = rot ? HP : 0;
      api.B(x - 0.9, z - 0.9, x + 0.9, z + 0.9, 0.5, 'stonewall');
      dec.push(box(1.0, 1.2, 0.9, X, 1.1, Z, '#6a4a30', 0, ry, 0), box(0.6, 0.9, 0.06, X + (rot ? 0.46 : 0), 1.05, Z + (rot ? 0 : 0.46), '#2a1c14', 0, ry, 0));
      dec.push(box(0.1, 1.5, 0.1, X - 0.6, 1.25, Z - 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X + 0.6, 1.25, Z - 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X - 0.6, 1.25, Z + 0.6, '#c8321e'), box(0.1, 1.5, 0.1, X + 0.6, 1.25, Z + 0.6, '#c8321e'));
      api.roof(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 1.95, 0.7, 0.35, { hip: true, col: '#d4d8de' });
      rawB(X - 0.55, Z - 0.5, X + 0.55, Z + 0.5, 2.2, 'none', 0, { hidden: true });
      api.lamps.push([X, 1.0, Z + (rot ? 0 : 0.6), 0.6]);
    };
    // колодец с крышей
    api.well = (x, z) => {
      const X = S(x), Z = S(z);
      api.B(x - 0.8, z - 0.8, x + 0.8, z + 0.8, 0.85, 'stonewall');
      dec.push(box(2.0, 0.04, 2.0, X, 0.86, Z, '#203a40'), cyl(0.08, 2.4, X - 1.0, 1.2, Z, '#5a3c26', 0, 0, 0, 6), cyl(0.08, 2.4, X + 1.0, 1.2, Z, '#5a3c26', 0, 0, 0, 6), cyl(0.05, 2.2, X, 2.25, Z, '#5a3c26', 0, 0, HP, 6), cyl(0.2, 0.3, X, 1.6, Z, '#6a4a2e'), box(0.28, 0.3, 0.28, X + 0.3, 1.0, Z + 0.3, '#5a3c26'));
      api.roof(x - 1.1, z - 1.1, x + 1.1, z + 1.1, 2.4, 0.7, 0.3, { along: 'x' });
    };
    // куст бамбука
    api.bamboo = (x, z, n) => {
      const X = S(x), Z = S(z);
      const cols = ['#7f9c3c', '#8aa645', '#6f8e34', '#94a84e'];
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.28, rr = Math.random() * 0.7, px = X + Math.cos(a) * rr, pz = Z + Math.sin(a) * rr, h = rnd(4.5, 6.8);
        const tx = px + rnd(-0.4, 0.4), tz = pz + rnd(-0.4, 0.4);
        dec.push(stick([px, 0, pz], [tx, h, tz], 0.06, 0.045, cols[i % 4], 6));
        for (let k = 0; k < 4; k++) {
          const t = 0.55 + k * 0.13, lx = px + (tx - px) * t, lz = pz + (tz - pz) * t;
          dec.push({ sph: true, r: 0.5, x: lx + rnd(-0.3, 0.3), y: h * t, z: lz + rnd(-0.3, 0.3), sx: 0.35, sy: 0.12, sz: 1.0, rx: rnd(-0.4, 0.4), ry: Math.random() * 6.28, color: k % 2 ? '#5f8a32' : '#6f9a3a', seg: 6 });
        }
      }
      rawB(X - 0.75, Z - 0.75, X + 0.75, Z + 0.75, 3, 'none', 0, { hidden: true });
    };
  }

  // размеры крыши: стены, свесы, конёк
  function roofFrame(r) {
    const ax = r.alongX;
    const a0w = ax ? r.X0 : r.Z0, a1w = ax ? r.X1 : r.Z1, c0w = ax ? r.Z0 : r.X0, c1w = ax ? r.Z1 : r.X1;
    const cc = (c0w + c1w) / 2, hw0 = (c1w - c0w) / 2, sl = r.h / hw0, ov = r.ov;
    const A0 = a0w - ov, A1 = a1w + ov, C0 = c0w - ov, C1 = c1w + ov, hw = hw0 + ov, mid = (A0 + A1) / 2;
    return {
      a0w, a1w, cc, hw0, hw, A0, A1, C0, C1, mid, ey: r.y - ov * sl, top: r.y + r.h,
      ra0: r.hip ? Math.min(A0 + hw, mid) : A0, ra1: r.hip ? Math.max(A1 - hw, mid) : A1
    };
  }

  // ===================== «Пыльный квартал» =====================
  function layoutDust(a) {
    const { B, crate, stack, lintel } = a;
    B(-41, -33, 41, -32, 7, 'wall'); B(-41, 32, 41, 33, 7, 'wall');
    B(-41, -32, -40, 32, 7, 'wall'); B(40, -32, 41, 32, 7, 'wall');
    for (const zc of [14, -14]) {
      const z0 = zc - 0.5, z1 = zc + 0.5;
      B(-40, z0, -30, z1, 5, 'wall'); B(-25, z0, -3, z1, 5, 'wall'); B(3, z0, 25, z1, 5, 'wall'); B(30, z0, 40, z1, 5, 'wall');
      lintel(-30, z0, -25, z1, 3.6, 5, 'wall'); lintel(-3, z0, 3, z1, 3.6, 5, 'wall'); lintel(25, z0, 30, z1, 3.6, 5, 'wall');
    }
    for (const xc of [-12, 12]) {
      const x0 = xc - 0.5, x1 = xc + 0.5;
      B(x0, -13.5, x1, -2.5, 5, 'wall'); B(x0, 2.5, x1, 13.5, 5, 'wall'); lintel(x0, -2.5, x1, 2.5, 3.6, 5, 'wall');
    }
    // дом
    B(-36, 6.4, -29, 7, 4.2, 'stucco'); B(-26, 6.4, -18, 7, 4.2, 'stucco'); lintel(-29, 6.4, -26, 7, 2.8, 4.2, 'stucco');
    B(-36, -7, -29, -6.4, 4.2, 'stucco'); B(-26, -7, -18, -6.4, 4.2, 'stucco'); lintel(-29, -7, -26, -6.4, 2.8, 4.2, 'stucco');
    B(-36, -7, -35.4, 7, 4.2, 'stucco');
    B(-18.6, -7, -18, -4, 4.2, 'stucco'); B(-18.6, -4, -18, -1.5, 1.1, 'stucco'); lintel(-18.6, -4, -18, -1.5, 2.2, 4.2, 'stucco');
    B(-18.6, 1.5, -18, 7, 4.2, 'stucco'); lintel(-18.6, -1.5, -18, 1.5, 2.8, 4.2, 'stucco');
    B(-36.3, -7.3, -17.7, 7.3, 0.4, 'roof', 4.2);
    B(-35.4, -0.3, -31, 0.3, 1.1, 'stucco');
    crate(-33.6, -4.6, 1.2); stack(-20.2, 4.8, 1.3); crate(-24, -4.8, 1.0);
    B(-30, 2.6, -27.5, 3.8, 0.85, 'metal');
    crate(-15, -9.5, 1.3); crate(-15.7, 9.2, 1.2); crate(-14.2, 4.5, 1.0);
    crate(-38.5, -2, 1.1); crate(-38.4, 10.5, 1.2);
    // центр
    B(-1.5, -1.5, 1.5, 1.5, 2.6, 'concrete'); B(-7, 4.5, -4, 5.3, 1.1, 'concrete'); B(4, -5.3, 7, -4.5, 1.1, 'concrete');
    stack(-7, -7, 1.4); stack(7, 7, 1.4); crate(8.5, -10.5, 1.2); crate(-8.5, 10.5, 1.2); crate(-2.2, 10.8, 1.0); crate(2.2, -10.8, 1.0);
    // контейнеры
    B(17, 3, 19.5, 9, 2.6, 'contRed'); B(26, -5, 32, -2.5, 2.6, 'contBlue'); B(26, -5, 32, -2.5, 2.6, 'contRed', 2.6);
    B(33, 4, 35.5, 10, 2.6, 'contGreen'); B(20, -11, 22.5, -5.5, 2.6, 'contBlue'); B(35, -9, 40, -6.5, 2.6, 'contGreen');
    crate(15, -3, 1.2); stack(25, 6, 1.3); crate(29, 10, 1.0); crate(37.5, -1, 1.2); B(23, -10.4, 27, -9.6, 1.0, 'concrete'); crate(14.5, 11, 1.1);
    // север (спецназ) + точки A/B
    B(-14, 21, 14, 31.5, 0.02, 'pave', 0, { solid: false });
    B(-40, 24, -30, 32, 5, 'stucco'); B(-40.2, 23.8, -29.8, 32, 0.3, 'roof', 5);
    B(30, 22, 40, 32, 4.5, 'wall');
    crate(-20, 18, 1.3); crate(-27.5, 19, 1.2); B(-3, 18.6, 3, 19.4, 1.1, 'concrete');
    crate(27.5, 19, 1.2); stack(18, 25, 1.3); crate(-12, 27, 1.2); crate(-22, 27.5, 1.1);
    B(6, 24, 8.5, 30, 2.8, 'metal'); B(6.1, 30, 8.4, 31.7, 2.0, 'metal');
    stack(-35, 19, 1.3); B(-33, 21.6, -29, 22.4, 1.1, 'concrete');
    B(33, 16, 39, 18.5, 2.6, 'contBlue'); crate(22, 17, 1.2);
    a.letter('A', -30, 18.5, 4.5); a.letter('B', 26, 17, 4.5);
    // юг (налётчики)
    B(-14, -31.5, 14, -21, 0.02, 'pave', 0, { solid: false });
    B(30, -32, 40, -24, 5, 'stucco'); B(29.8, -32, 40.2, -23.8, 0.3, 'roof', 5);
    B(-40, -32, -30, -22, 4.5, 'wall');
    crate(20, -18, 1.3); crate(27.5, -19, 1.2); B(-3, -19.4, 3, -18.6, 1.1, 'concrete');
    crate(-27.5, -19, 1.2); stack(-18, -25, 1.3); crate(12, -27, 1.2); crate(22, -27.5, 1.1);
    B(-8.5, -30, -6, -24, 2.8, 'metal'); B(-8.4, -31.7, -6.1, -30, 2.0, 'metal');
    // дополнительные укрытия на увеличенной карте
    crate(-6, 8.5, 1.1); crate(6, -8.5, 1.1); B(-25, 9.6, -21, 10.4, 1.1, 'concrete'); B(21, -10.4, 25, -9.6, 1.1, 'concrete');
    stack(-27.5, 27.5, 1.2); stack(27.5, -27.5, 1.2); crate(16.5, 18, 1.0); crate(-16.5, -18, 1.0);
    detailDust(a);
  }

  // фасады, навесы, пальмы, провода — только визуальные детали (+ мешки с песком как укрытия)
  function detailDust(a) {
    const D = a.decal;
    // дом: окна, ставни, вывеска кафе
    D(0, -33, 2.3, 7, 1.5, 3, '+z'); D(3, -21.5, 2.3, 7, 1.5, 3, '+z'); D(4, -23.6, 3.0, 7, 2.2, 4.4, '+z');
    D(1, -33, 2.1, -7, 1.6, 3.2, '-z'); D(0, -22, 2.3, -7, 1.5, 3, '-z'); D(6, -24.7, 1.9, -7, 1.1, 2.2, '-z');
    D(3, -36, 2.3, -3, 1.5, 3, '-x'); D(0, -36, 2.3, 3.5, 1.5, 3, '-x');
    D(6, -18, 1.9, -5.6, 1.1, 2.2, '+x'); D(1, -18, 2.1, 4.3, 1.6, 3.2, '+x');
    a.awning(-27.5, 3.15, 7, 3.8, 1.3, '+z', '#b0392b');
    a.awning(-18, 3.05, 0, 3.6, 1.2, '+x', '#2f6f8a');
    // здания у спавнов
    D(1, -37.5, 2.5, 24, 1.6, 3.2, '-z'); D(0, -33, 2.6, 24, 1.5, 3, '-z'); D(2, -30, 1.6, 28.5, 1.6, 3.2, '+x'); D(3, -30, 2.6, 25.6, 1.5, 3, '+x');
    a.awning(-35.2, 4.1, 24, 8.4, 1.4, '-z', '#2f6f8a');
    D(1, 37.5, 2.5, -24, 1.6, 3.2, '+z'); D(0, 33, 2.6, -24, 1.5, 3, '+z'); D(2, 30, 1.6, -28.5, 1.6, 3.2, '-x'); D(3, 30, 2.6, -25.6, 1.5, 3, '-x');
    a.awning(35.2, 4.1, -24, 8.4, 1.4, '+z', '#b0392b');
    D(7, 33, 3.4, 22, 1.2, 2.4, '-z'); D(6, 36.5, 1.8, 22, 1.1, 2.2, '-z');
    D(7, -33, 3.4, -22, 1.2, 2.4, '+z'); D(6, -36.5, 1.8, -22, 1.1, 2.2, '+z');
    // плакаты и решётки на стенах кварталов
    for (const zc of [14, -14]) {
      const s = zc > 0 ? 1 : -1;
      D(6, -15, 1.8, zc + 0.5 * s, 1.1, 2.2, s > 0 ? '+z' : '-z'); D(7, 18, 3.6, zc + 0.5 * s, 1.2, 2.4, s > 0 ? '+z' : '-z');
      D(7, -36, 3.6, zc - 0.5 * s, 1.2, 2.4, s > 0 ? '-z' : '+z'); D(6, 8, 1.8, zc - 0.5 * s, 1.1, 2.2, s > 0 ? '-z' : '+z');
    }
    D(6, 12.5, 1.8, 8, 1.1, 2.2, '+x'); D(6, -12.5, 1.8, -8, 1.1, 2.2, '-x');
    D(3, -40, 3.4, -20, 1.5, 3, '+x'); D(1, 40, 3.4, 0, 1.6, 3.2, '-x'); D(3, 40, 3.4, 8, 1.5, 3, '-x'); D(0, -40, 3.4, 18, 1.5, 3, '+x');
    D(1, -20, 3.6, 32, 1.6, 3.2, '-z'); D(1, 20, 3.6, -32, 1.6, 3.2, '+z');
    // пальмы
    a.palm(-11, 23.5, 6.8); a.palm(11.2, 22, 6.2); a.palm(-11.5, -23.2, 6.4); a.palm(12, -22.5, 7);
    a.palm(-38, -11.5, 6.6); a.palm(38, 12.6, 6.4); a.palm(-37.8, 12.4, 5.8);
    // столбы и провода
    const p1 = a.pole(-16, 30.8, 7.6), p2 = a.pole(16, 30.8, 7.6), p3 = a.pole(16, -30.8, 7.6), p4 = a.pole(-16, -30.8, 7.6);
    a.wire(p1, p2, 1.1); a.wire(p1, [-30, 4.7, 28], 0.5); a.wire(p2, [30, 4.3, 27], 0.5);
    a.wire(p3, p4, 1.1); a.wire(p3, [30, 4.7, -28], 0.5); a.wire(p4, [-30, 4.3, -27], 0.5);
    // мешки с песком на точках
    a.sandbags(-25, 21.6, 3, 0, 2); a.sandbags(-37.2, 16.6, 2.2, Math.PI / 2, 2);
    a.sandbags(31, 20.6, 2.8, 0, 2); a.sandbags(19.2, 19.6, 2.2, Math.PI / 2, 2);
    // пятна и разбитые бочки
    a.stain(-27, 3.2, 2.5); a.stain(0, -6, 3); a.stain(24, -1, 2.2); a.stain(-5, 26, 2.4); a.stain(6, -27, 2.6);
    a.barrel(-38.6, -5.2, '#8a5a2a'); a.barrel(38.4, -12.6, '#3b5f3a'); a.barrel(23.6, 9.6, '#8a2d22');
  }

  // ===================== «Гавань» =====================
  function layoutHarbor(a) {
    const { B, crate, stack, lintel, barrel, lamp } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    // периметр
    B(-45, -35, 45, -34, 6, 'corrug'); B(-45, 34, 45, 35, 6, 'corrug');
    B(-45, -34, -44, 34, 9, 'brick');
    B(44, -34, 44.25, 34, 1.1, 'metal');
    B(44.25, -34, 46, 34, 6, 'none', 0, { hidden: true });
    B(44, -34, 44.7, 34, 1.4, 'concrete', -1.4, { solid: false });
    // пирс из досок вдоль воды
    B(34, -34, 44, 34, 0.03, 'planks', 0, { solid: false });
    // склад (запад)
    B(-40, -16, -32, -15.4, 7, 'brick'); B(-28, -16, -18, -15.4, 7, 'brick'); lintel(-32, -16, -28, -15.4, 3.4, 7, 'brick');
    B(-40, 3.4, -26, 4, 7, 'brick'); B(-22, 3.4, -18, 4, 7, 'brick'); lintel(-26, 3.4, -22, 4, 3.4, 7, 'brick');
    B(-40, -16, -39.4, 4, 7, 'brick');
    B(-18.6, -16, -18, -8, 7, 'brick'); B(-18.6, -4, -18, 4, 7, 'brick'); lintel(-18.6, -8, -18, -4, 3.4, 7, 'brick');
    B(-40.3, -16.3, -17.7, 4.3, 0.4, 'roof', 7);
    B(-37, -13, -36, -6, 3.2, 'metal'); B(-37, -3, -36, 2, 3.2, 'metal');
    stack(-24, -12, 1.3); crate(-31, -6, 1.2); crate(-29.8, -6.3, 1.0); crate(-33.5, 0.5, 1.1);
    B(-26, -2, -24.4, 0.4, 1.5, 'hazard'); // погрузчик
    a.D(box(0.1, 2.6, 0.1, -26.1, 1.3, -1.5, '#2a2a2a'), box(0.1, 2.6, 0.1, -26.1, 1.3, -0.1, '#2a2a2a'),
      box(1.2, 0.06, 0.12, -26.7, 0.15, -1.4, '#333'), box(1.2, 0.06, 0.12, -26.7, 0.15, -0.2, '#333'));
    // ящики на стеллажах
    for (let i = 0; i < 4; i++) { a.D(box(0.8, 0.6, 1.2, -36.5, 1.0 + (i % 2) * 1.2, -12 + i * 1.6, i % 2 ? '#8a6a3c' : '#6e7a85')); }
    // западный проулок и юго-западный двор
    crate(-42, -26, 1.2); crate(-42.5, -6, 1.1); barrel(-42, 8, '#8a2d22');
    stack(-34, -24, 1.3); crate(-24, -28, 1.2); B(-38, -31, -32, -28.5, 2.6, 'contGreen');
    barrel(-26, -20); barrel(-25.3, -20.7, '#a07a20');
    // середина
    B(-18, -24.6, -6, -24, 3, 'corrug'); B(6, -24.6, 14, -24, 3, 'corrug');
    B(-2.5, -3, 2.5, 1, 3, 'concrete'); B(-3, -3.5, 3, 1.5, 0.3, 'roof', 3);
    B(6, -12, 8.6, -5, 3, 'contOrange'); B(6.1, -14.2, 8.5, -12, 2.3, 'metal');
    a.D(box(2.2, 0.9, 0.05, 7.3, 1.6, -14.23, '#9fc3d6')); // стекло кабины
    B(-11, -10.3, -8, -9.7, 1.0, 'concrete'); B(-6, 6, -2, 6.6, 1.0, 'concrete'); B(2, -19.3, 6, -18.7, 1.0, 'concrete');
    crate(-12, 5, 1.2); stack(10, 8, 1.3); crate(-14, -20, 1.2); crate(11, -20, 1.1);
    for (let z = -20; z <= 10; z += 6) a.D(box(0.15, 0.012, 2.4, -2.0 - 6, 0.01, z, '#d9b23a'), box(0.15, 0.012, 2.4, 6.5, 0.01, z, '#d9b23a'));
    // контейнерный двор (восток)
    B(13.7, -24, 14.3, -6, 3, 'corrug');
    B(17, -16, 23, -13.5, 2.6, 'contBlue'); B(17, -16, 23, -13.5, 2.6, 'contRed', 2.6);
    B(26, -14, 28.5, -8, 2.6, 'contGreen'); B(18, -8, 20.5, -2, 2.6, 'contOrange');
    B(31, -6, 37, -3.5, 2.6, 'contRed'); B(31, -6, 37, -3.5, 2.6, 'contBlue', 2.6);
    B(24, 0, 30, 2.5, 2.6, 'contBlue'); B(37, -16, 39.5, -10, 2.6, 'contGreen');
    B(20, -28, 26, -25.5, 2.6, 'contOrange'); B(33, -30, 35.5, -24, 2.6, 'contBlue');
    crate(30, -12, 1.2); crate(23, -5, 1.1); crate(40, 0, 1.2); stack(16, -30, 1.3);
    barrel(41.5, -20, '#2f5f8a'); barrel(41.6, -21, '#8a2d22'); barrel(40.8, -20.5, '#2f5f8a');
    // офис между серединой и спавном спецназа
    B(-12, 13, 12, 21, 6, 'concrete'); B(-12.3, 12.7, 12.3, 21.3, 0.35, 'roof', 6);
    a.D(box(2, 1.2, 1.5, -6, 6.95, 17, '#8c9196'), box(2, 1.2, 1.5, 5, 6.95, 16, '#8c9196'), box(0.9, 0.9, 0.9, 0, 6.8, 19, '#7a7f84'));
    for (let x = -10; x <= 10; x += 4) a.D(box(2.4, 1.4, 0.05, x, 3.6, 12.97, '#2a3540'), box(2.4, 1.4, 0.05, x, 3.6, 21.03, '#2a3540'));
    // точка A (северо-западный двор)
    B(-34, 13, -28, 15.5, 2.6, 'contGreen'); B(-34, 13, -28, 15.5, 2.6, 'contRed', 2.6);
    B(-24, 16, -21.5, 22, 2.6, 'contBlue');
    stack(-38, 19, 1.3); crate(-29, 21, 1.2); barrel(-20, 10); barrel(-20.6, 10.7, '#a07a20');
    B(-44, 26, -38, 34, 4, 'corrug'); B(-44.2, 25.8, -37.8, 34, 0.3, 'roof', 4);
    B(-38, 25.7, -26, 26.3, 2.5, 'corrug'); B(-22, 25.7, -18, 26.3, 2.5, 'corrug');
    a.letter('A', -30, 19, 5);
    // точка B (пирс, портальный кран)
    for (const [lx, lz] of [[20, 8], [20, 21], [33, 8], [33, 21]]) B(lx, lz, lx + 1, lz + 1, 15, 'hazard');
    B(20, 8, 34, 9, 1.2, 'hazard', 15); B(20, 21, 34, 22, 1.2, 'hazard', 15);
    B(20, 8, 21, 22, 1.2, 'hazard', 15); B(33, 8, 34, 22, 1.2, 'hazard', 15);
    B(36, 17, 42, 19.5, 2.6, 'contOrange'); stack(25, 12, 1.3); crate(29, 18, 1.2);
    B(27, 9.6, 30, 10.4, 1.1, 'concrete'); crate(38, 10, 1.0); crate(38.9, 10.3, 0.8);
    B(18, 25.7, 22, 26.3, 2.5, 'corrug'); B(26, 25.7, 38, 26.3, 2.5, 'corrug');
    B(38, 26, 44, 34, 4, 'corrug'); B(37.8, 25.8, 44, 34, 0.3, 'roof', 4);
    a.letter('B', 27, 15, 5);
    // кран: кабина, стрела над водой, трос с контейнером (декор)
    a.DS(
      box(4, 2.6, 4, 26, 13.6, 15, '#d9a21b'), box(3.6, 1, 0.05, 26, 13.9, 12.98, '#2a3540'),
      box(52, 1.1, 1.6, 58, 16.8, 15, '#d9a21b'), box(14, 1.1, 1.6, 13, 16.8, 15, '#d9a21b'),
      box(3, 2.4, 3, 7.5, 15.2, 15, '#6c6f72'),
      box(0.05, 9, 0.05, 72, 12, 15, '#222'), box(6, 2.6, 2.5, 72, 6.3, 15, '#2f5d86'),
      box(0.4, 7, 0.4, 40, 20, 15, '#d9a21b', 0, 0, 0.5), box(0.4, 7, 0.4, 30, 20, 15, '#d9a21b', 0, 0, -0.5)
    );
    // спавн спецназа
    crate(-8, 27, 1.2); crate(9, 29, 1.2); B(-4, 28, -1.6, 33, 2.4, 'metal');
    a.D(box(2.2, 0.8, 0.05, -2.8, 1.7, 27.97, '#9fc3d6'));
    // спавн налётчиков
    crate(-10, -28, 1.2); stack(10, -31, 1.3); B(-14, -33, -8, -30.5, 2.6, 'contRed');
    // фонари и швартовые тумбы
    lamp(-17, -22, 6, HP); lamp(-17, 9, 6, HP); lamp(13, -22, 6, -HP); lamp(13, 9, 6, -HP);
    for (let z = -28; z <= 28; z += 14) lamp(43.2, z, 6.5, -HP);
    for (let z = -31; z <= 31; z += 6) a.D(cyl(0.22, 0.6, 43.4, 0.3, z, '#2b2b2b', 0, 0, 0, 10), cyl(0.3, 0.1, 43.4, 0.62, z, '#2b2b2b', 0, 0, 0, 10));
    // корабль на рейде
    a.DS(
      box(16, 7, 64, 92, 1.5, -6, '#6b1f1a'), box(16.2, 1.2, 64.2, 92, -1.2, -6, '#1d1d1d'),
      box(11.3, 7, 11.3, 92, 1.5, 26, '#6b1f1a', 0, Math.PI / 4, 0),
      box(14, 9, 9, 92, 9.5, -33, '#e8e4dc'), box(14.2, 1.2, 9.2, 92, 11.5, -33, '#2a3540'),
      box(3, 6, 3, 92, 16.5, -35, '#c8c4bc'), box(3.2, 1.2, 3.2, 92, 19, -35, '#a33a2a')
    );
    const cc = ['#2f5d86', '#9c3b2c', '#4d6b3a', '#c46a1f', '#7a7f84'];
    for (let i = 0; i < 18; i++) a.DS(box(2.5, 2.6, 6, 87 + (i % 3) * 3.3 - 1, 6.3 + Math.floor(i / 9) * 2.6, -24 + (i % 9) * 5.5 - (i % 3), cc[(i * 7) % 5]));
    // маяк на скале
    a.D({ sph: true, r: 14, x: 150, y: -6, z: -95, color: '#5b5048', seg: 10, sy: 0.6 });
    for (let i = 0; i < 6; i++) a.D(cyl(2.6 - i * 0.18, 4, 150, 4 + i * 4, -95, i % 2 ? '#c8352a' : '#eeeae2', 0, 0, 0, 12, 2.6 - (i + 1) * 0.18));
    a.D(cyl(1.6, 2.4, 150, 29, -95, '#ffe7a0', 0, 0, 0, 10), { cyl: true, r: 0.2, r2: 2.2, h: 2.2, x: 150, y: 31.3, z: -95, color: '#2a2a2a', seg: 10 });
    a.lamps.push([150 * a.sc, 29, -95 * a.sc, 9]);
    // дополнительные укрытия на увеличенной карте
    stack(-10, -5, 1.3); stack(11, 1, 1.2); crate(-16, 11.5, 1.1); B(-5, -15.3, -1, -14.7, 1.1, 'concrete');
    B(21, -21.5, 27, -19, 2.6, 'contRed'); crate(-31, 7, 1.2); B(29, 4.6, 33, 5.4, 1.1, 'concrete'); crate(36.5, 6, 1.1);
    barrel(-6, 10.5, '#2f5f8a'); stack(1, -27, 1.2);
    detailHarbor(a);
  }

  function detailHarbor(a) {
    const D = a.decal, box = G.geo.box;
    // склад: светящиеся окна под крышей
    for (const x of [-38, -34.5, -31, -28, -20]) D(5, x, 5.1, 4, 1.4, 2.8, '+z');
    D(5, -24, 5.3, 4, 1.4, 2.8, '+z');
    for (const x of [-38, -35, -25, -21.5]) D(5, x, 5.1, -16, 1.4, 2.8, '-z');
    D(5, -30, 5.3, -16, 1.4, 2.8, '-z');
    for (const z of [-13.5, -10.5, -1, 2]) D(5, -18, 5.1, z, 1.4, 2.8, '+x');
    D(6, -18, 1.8, -12, 1.1, 2.2, '+x'); D(7, -18, 1.6, 0.5, 1.2, 2.4, '+x'); D(6, -36, 1.8, 4, 1.1, 2.2, '+z');
    D(7, -23, 1.6, -16, 1.2, 2.4, '-z');
    a.awning(-24, 3.95, 4, 4.6, 1.4, '+z', '#3d5c7a'); a.awning(-30, 3.95, -16, 4.6, 1.4, '-z', '#5a6a3a');
    // западная кирпичная стена — фасад жилого дома
    for (let z = -30; z <= 22; z += 6.5) { D((z / 6.5 | 0) % 2 ? 5 : 1, -44, 6.6, z, 1.5, 3, '+x'); }
    D(6, -44, 1.8, -21, 1.1, 2.2, '+x'); D(7, -44, 2.8, 12, 1.2, 2.4, '+x');
    // офис
    D(2, 12, 1.6, 17, 1.6, 3.2, '+x'); D(2, -12, 1.6, 17, 1.6, 3.2, '-x');
    for (const x of [-8, 0, 8]) D(7, x, 5.2, 21, 1.2, 2.4, '+z');
    D(6, -2, 1.7, 13, 1.1, 2.2, '-z'); D(6, 6.5, 1.7, 13, 1.1, 2.2, '-z');
    // сараи, перегородки
    D(2, -38, 1.6, 29.5, 1.6, 3.2, '+x'); D(5, -41, 2.6, 26, 1.2, 2.4, '-z');
    D(2, 38, 1.6, 30, 1.6, 3.2, '-x'); D(5, 41, 2.6, 26, 1.2, 2.4, '-z');
    D(6, -12, 1.6, -24.6, 1.1, 2.2, '-z'); D(6, 10, 1.6, -24, 1.1, 2.2, '+z'); D(6, -30, 1.4, 26.3, 1.1, 2.2, '+z');
    D(7, 14.3, 1.5, -15, 1.2, 2.4, '+x');
    // окна надстройки корабля
    for (let i = 0; i < 4; i++) { D(5, 85, 11.6, -36 + i * 2, 1.1, 2, '-x'); D(5, 85, 8.4, -36 + i * 2, 1.1, 2, '-x'); }
    // спасательные круги на ограждении и кранцы-покрышки на причале
    for (const z of [-22, -10, 8, 20]) {
      a.D({ torus: true, r: 0.3, tube: 0.075, x: 43.9, y: 0.68, z, ry: HP, color: '#e8531f', seg: 16 },
        box(0.17, 0.17, 0.09, 43.9, 0.98, z, '#f4f1ea'), box(0.17, 0.17, 0.09, 43.9, 0.38, z, '#f4f1ea'),
        box(0.17, 0.09, 0.17, 43.9, 0.68, z + 0.3, '#f4f1ea'), box(0.17, 0.09, 0.17, 43.9, 0.68, z - 0.3, '#f4f1ea'));
    }
    for (let z = -30; z <= 30; z += 7.5) a.D({ torus: true, r: 0.36, tube: 0.15, x: 44.85, y: -0.55, z, ry: HP, color: '#1b1b1b', seg: 12 });
    // покрышки, катушки кабеля, пятна масла
    a.tires(16.6, -21, 3); a.tires(-42.6, 14.5, 2); a.tires(41, 24.6, 2);
    a.reel(30, -20); a.reel(-8, 9.6);
    a.stain(-27, -1, 3); a.stain(7.5, -9, 3.5); a.stain(25, -20, 2.5); a.stain(-5, -15, 2.2); a.stain(0, 26, 2.6);
    a.stain(-30, -27, 2.4); a.stain(36, 0, 2.4); a.stain(28, 14, 3); a.stain(-30, 10, 2.6);
    // световые пятна под фонарями
    for (const l of a.lamps) if (!l[3]) a.pool(l[0] / a.sc, l[2] / a.sc, 6);
    a.gulls = 7;
  }

  // ===================== «Сакура» =====================
  function layoutSakura(a) {
    const { B, crate, stack, lintel } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    // ограда: каменное основание, белая стена и черепичный гребень
    const wall = (x0, z0, x1, z1) => { B(x0, z0, x1, z1, 1.5, 'stonewall'); B(x0, z0, x1, z1, 1.9, 'plaster', 1.5); a.roof(x0, z0, x1, z1, 3.4, 0.45, 0.35, { ridgeCol: '#30343a' }); };
    wall(-43, 34, 43, 35); wall(-43, -35, 43, -34); wall(-43, -34, -42, 34); wall(42, -34, 43, 34);
    // одноэтажный дом (простая машия) и амбар-кура
    const house = (x0, z0, x1, z1, o) => {
      o = o || {}; const h = o.h || 5;
      B(x0, z0, x1, z1, h, o.mat || 'machiya', 0, o.solid === false ? { solid: false } : null); a.roof(x0, z0, x1, z1, h, o.rise || 2.1, o.ov == null ? 0.9 : o.ov, o);
    };
    const kura = (x0, z0, x1, z1) => { B(x0, z0, x1, z1, 0.35, 'stonewall'); B(x0, z0, x1, z1, 5.3, 'kura', 0.35); a.roof(x0, z0, x1, z1, 5.65, 2.3, 0.7, { col: '#ffffff' }); };
    // ---------- северный ряд (z 10..16) ----------
    a.house2(-42, 10, -29, 16, { h: 5.8 }); a.veranda(-41, 8.8, -30, 10, '-z');
    a.torii(-26, 13.6, 4.6, 3.7, 0); a.toro(-28.3, 8.3, 0.9); a.toro(-23.7, 8.3, 0.9);
    B(-29, 10, -23, 16, 0.02, 'gravel', 0, { solid: false });
    a.house2(-23, 10, -8, 16, { h: 5.6, shop: true }); a.veranda(-22, 8.8, -9, 10, '-z');
    lintel(-8, 12.4, -2, 13.6, 3.5, 4.3, 'planks'); a.roof(-8.3, 12.2, -1.7, 13.8, 4.3, 0.8, 0.5, { col: '#d4d8de' });
    a.D(box(0.1, 3.3, 1.5, -7.9, 1.75, 11.6, '#5a3c26'), box(0.1, 3.3, 1.5, -2.1, 1.75, 11.6, '#5a3c26'));
    house(-2, 10, 6, 16, { rise: 1.8 });
    // чайный дом — сквозной проход из сада к точке B
    const TH = 'machiya';
    B(6, 10, 9, 10.5, 5, TH); B(12, 10, 22, 10.5, 5, TH); lintel(9, 10, 12, 10.5, 2.8, 5, TH);
    B(6, 15.5, 17, 16, 5, TH); B(20, 15.5, 22, 16, 5, TH); lintel(17, 15.5, 20, 16, 2.8, 5, TH);
    B(6, 10.5, 6.5, 15.5, 5, TH); B(21.5, 10.5, 22, 15.5, 5, TH);
    B(6.5, 10.5, 21.5, 15.5, 0.35, 'planks', 3.5);
    B(14, 10.5, 14.5, 13, 3.5, 'plaster');
    a.roof(6, 10, 22, 16, 5, 2.1, 0.9);
    B(7.2, 13.9, 11.6, 14.6, 1.05, 'planks');
    B(15, 10.5, 21.5, 12.6, 0.28, 'tatami', 0, { solid: true });
    a.wagasa(7.6, 8.6, '#c8321e'); a.wagasa(20.4, 8.6, '#f2e6c8'); a.bench(10.5, 8.6, 0); a.bench(17.5, 8.6, 0);
    a.house2(28, 10, 42, 16, { h: 5.8, shop: true }); a.veranda(29, 8.8, 41, 10, '-z');
    // ---------- южный ряд (z -16..-10) ----------
    a.house2(-42, -16, -33, -10, { h: 5.4 });
    kura(-27, -16, -13, -10);
    a.house2(-13, -16, 2, -10, { h: 5.8 }); a.veranda(-12, -10, 1, -8.8, '+z');
    lintel(2, -13.6, 8, -12.4, 3.5, 4.3, 'planks'); a.roof(1.7, -13.8, 8.3, -12.2, 4.3, 0.8, 0.5, { col: '#d4d8de' });
    a.D(box(0.1, 3.3, 1.5, 2.1, 1.75, -11.6, '#5a3c26'), box(0.1, 3.3, 1.5, 7.9, 1.75, -11.6, '#5a3c26'));
    a.house2(8, -16, 20, -10, { h: 5.6, shop: true }); a.veranda(9, -10, 19, -8.8, '+z');
    house(20, -16, 30, -10, { rise: 1.9 });
    a.house2(36, -16, 42, -10, { h: 5.4 });
    // ---------- сад: гравий, живая изгородь, каменная терраса вокруг пруда ----------
    B(-16, -10, 16, 10, 0.02, 'gravel', 0, { solid: false });
    a.hedge(-16.4, -10, -15.8, 10, 1.25, [[-2.6, 2.6]]); a.hedge(15.8, -10, 16.4, 10, 1.25, [[-2.6, 2.6]]);
    for (const s of [-1, 1]) { a.D(cyl(0.12, 3.1, s * 16.1, 1.55, -2.75, '#5a3c26'), cyl(0.12, 3.1, s * 16.1, 1.55, 2.75, '#5a3c26'), box(0.28, 0.22, 7.4, s * 16.1, 2.95, 0, '#5a3c26')); a.roof(s * 16.1 - 0.35, -2.95, s * 16.1 + 0.35, 2.95, 3.1, 0.6, 0.35, { along: 'z' }); }
    B(-8.5, -6.5, 8.5, -3, 0.4, 'jpstone'); B(-8.5, 3, 8.5, 6.5, 0.4, 'jpstone'); B(-8.5, -3, -5, 3, 0.4, 'jpstone'); B(5, -3, 8.5, 3, 0.4, 'jpstone');
    a.pond(-5, -3, 5, 3); a.bridge(0, 0, 12.5);
    a.rock(-11, 7.2, 1.7); a.rock(11, -7.4, 1.6); a.rock(-6.8, -8.6, 1.2); a.rock(7, 8.6, 1.1); a.rock(-13.5, -2, 0.9); a.rock(13.5, 2, 0.9);
    a.toro(-9.8, 4.6, 0.9); a.toro(9.8, -4.6, 0.9); a.toro(-9.8, -4.6, 0.8); a.toro(9.8, 4.6, 0.8);
    a.sakura(-12.2, 6.6, 6.8, 1.1); a.sakura(12.2, -6.6, 7.0, 1.15); a.sakura(-4.2, 8.9, 5.4, 0.85); a.sakura(4.2, -8.9, 5.6, 0.85);
    a.pavilion(-11.6, -7, 4); a.pavilion(11.6, 7, 4);
    a.bamboo(-14.6, 8.8, 8); a.bamboo(14.6, -8.8, 8);
    a.basin(-10.6, -1.2); a.bench(10.4, 1.4, 1); a.pot(-9.6, 8.6, 1.1); a.pot(9.6, -8.6, 1.1);
    // ---------- западная улица: канал вдоль стены, колодец, лавки ----------
    a.ground.push({ kind: 'pond', x: a.sc * -40.2, z: 0, w: a.sc * 3.4, d: a.sc * 20 });
    B(-38.5, -10, -38.1, 10, 0.32, 'stonewall'); B(-42, -10, -38.5, 10, 0.5, 'none', 0, { hidden: true });
    for (const z of [-7, 0, 7]) a.D(box(0.3, 0.6, 0.3, -38.3, 0.6, z, '#6e6a62'));
    a.well(-33, -3); a.cart(-29, 1.6, 0); a.taru(-36.5, -8.2, 3, 0, 1); a.taru(-21.5, 8.2, 2, 0, -1);
    stack(-22.6, -7, 1.3); crate(-21.4, -7.9, 1.0); crate(-36, 7.6, 1.2); crate(-34.8, 8.3, 0.9);
    a.toro(-19.6, 5.4); a.bench(-26, 7.6, 0); a.pot(-19.6, -8.4); a.pot(-33.5, 7.9, 0.8); a.wagasa(-23.2, -4.2, '#c8321e', 0.9);
    a.fence(-37.9, 9.6, -30.2, 9.6); a.fence(-30.2, -9.6, -24.2, -9.6);
    a.sakura(-35, 5.6, 6.6, 1.0); a.sakura(-25.6, -7.2, 6.2, 0.95);
    // ---------- восточная улица: хокора, лавка, сакэ ----------
    a.hokora(37.6, 1.6, false); a.hedge(35.6, -1, 39.6, -0.6, 1.0); a.hedge(35.6, 3.6, 39.6, 4.0, 1.0);
    a.cart(29, -1.2, HP); a.stall(32.6, 6.4, 37.2, 8.4, -1, '#7a2a2a'); a.taru(40.6, -5.6, 3, HP, -1); a.taru(23.6, 8.0, 2, 0, -1);
    stack(22.6, -7.2, 1.3); crate(21.4, -8.1, 1.0); crate(35.6, -8.2, 1.2); a.toro(19.6, -5.4); a.bench(25, -5.6, 1); a.pot(19.6, 8.4); a.pot(40.6, 8.6, 0.9);
    a.fence(23.8, 9.6, 30.8, 9.6); a.fence(30.6, -9.6, 35.4, -9.6);
    a.sakura(38.4, -8.4, 6.0, 0.95); a.sakura(24.4, 7.2, 5.8, 0.9);
    // ---------- юг: спавн налётчиков ----------
    a.house2(-42, -34, -30, -25, { h: 5.6 }); kura(30, -34, 42, -25);
    a.torii(0, -19.4, 6.4, 5.2, 0);
    B(-3.4, -22.4, 3.4, -21.6, 1.1, 'stonewall');
    crate(-19, -20, 1.2); stack(18.6, -21, 1.3); crate(-8, -30.6, 1.2); a.taru(12.5, -32.6, 3, 0, 1);
    a.toro(-24, -21.4); a.toro(24, -21.4); a.sakura(-26.2, -30.4, 6.2, 1.0); a.sakura(25.8, -30.6, 6.4, 1.0);
    a.cart(-17.4, -27.5, HP); crate(8.6, -24.6, 1.1); stack(-27.5, -19.5, 1.2); crate(27.4, -19.6, 1.2);
    a.bench(-6, -32.4, 0); a.bench(6, -32.4, 0); a.pot(-13, -21.6); a.pot(13, -21.6); a.fence(-29.6, -24.4, -22, -24.4); a.fence(22, -24.4, 29.6, -24.4);
    B(-2.6, -34, 2.6, -22.4, 0.02, 'gravel', 0, { solid: false }); B(-28, -24, 28, -22.8, 0.02, 'gravel', 0, { solid: false });
    a.hedge(-22, -29.8, -12, -29.4, 1.1, [[-18, -16]]); a.hedge(12, -29.8, 22, -29.4, 1.1, [[16, 18]]);
    a.hokora(10.4, -30.6, false); a.emaWall(-12, -26, 3.5, true); a.rock(-20, -32.6, 1.4); a.rock(20, -32.6, 1.3);
    a.toro(-6, -22.6, 0.85); a.toro(6, -22.6, 0.85); a.wagasa(-15.5, -32.4, '#f2e6c8', 0.7);
    // ---------- север: двор храма (спавн спецназа) ----------
    B(-16, 17, 16, 34, 0.02, 'gravel', 0, { solid: false });
    wall(-17, 24, -16, 34); wall(16, 24, 17, 34);
    a.toro(-13.4, 20.6); a.toro(13.4, 20.6); a.sakura(-12.8, 31.6, 6.4, 1.0); a.sakura(12.8, 31.8, 6.6, 1.0);
    // курильница дзёро: каменный постамент, бронзовый котёл на трёх лапах, крыша на четырёх стойках
    a.D(cyl(0.95, 0.22, 0, 0.11, 20.8, '#8d877b', 0, 0, 0, 8), cyl(0.8, 0.12, 0, 0.28, 20.8, '#7d776c', 0, 0, 0, 8),
      cyl(0.62, 0.42, 0, 0.72, 20.8, '#3f5a4c', 0, 0, 0, 14, 0.42), cyl(0.68, 0.07, 0, 0.95, 20.8, '#567563', 0, 0, 0, 14),
      { torus: true, r: 0.62, tube: 0.035, x: 0, y: 0.98, z: 20.8, color: '#6f8f78', seg: 14, rx: HP });
    for (let i = 0; i < 3; i++) { const an = i * 2.094; a.D(cyl(0.05, 0.36, Math.cos(an) * 0.36, 0.48, 20.8 + Math.sin(an) * 0.36, '#2f4438', 0, 0, 0, 5)); }
    for (const [px, pz] of [[-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]]) a.D(cyl(0.035, 1.2, px * 1.0, 1.58, 20.8 + pz * 1.0, '#2f4438', 0, 0, 0, 5));
    a.D({ cyl: true, r: 0.3, r2: 1.05, h: 0.3, x: 0, y: 2.33, z: 20.8, color: '#3f5a4c', seg: 4, ry: Math.PI / 4 },
      { cyl: true, r: 0.06, r2: 0.48, h: 0.26, x: 0, y: 2.6, z: 20.8, color: '#4a6a58', seg: 4, ry: Math.PI / 4 },
      { sph: true, r: 0.09, x: 0, y: 2.8, z: 20.8, color: '#c9a640', seg: 6 }, cyl(0.5, 0.05, 0, 1.02, 20.8, '#6a6258', 0, 0, 0, 12));
    B(-0.6, 20.3, 0.6, 21.3, 1.1, 'none', 0, { hidden: true });
    a.basin(-8, 27); a.bench(8, 27, 1); a.pot(-14.5, 25.5); a.pot(14.5, 25.5);
    a.rock(-5, 31, 1.5); a.rock(5.5, 30, 1.2); a.hedge(-15.6, 18.4, -8, 18.8, 1.0); a.hedge(8, 18.4, 15.6, 18.8, 1.0);
    B(-2.6, 17, 2.6, 34, 0.02, 'jpstone', 0, { solid: false });
    // ---------- точка A: святилище на каменной платформе ----------
    B(-42, 25, -31, 34, 0.6, 'stonewall'); a.stairs(-36.5, 24.32, '+z', 4, 0.6);
    B(-42, 26, -32, 34, 4.2, 'shrine', 0.6); a.roof(-42, 26, -32, 34, 4.8, 2.8, 1.5, { hip: true, col: '#8cbcaa', ridgeCol: '#3d5a50' });
    B(-40, 25.2, -34, 26, 0.3, 'planks', 0.6);
    a.torii(-25, 18.4, 5.3, 4.6, 0);
    a.toro(-36.8, 21.2); a.toro(-21.4, 27.6); a.emaWall(-26.5, 22.2, 4, false); a.bell(-21.6, 31.4);
    stack(-25, 23.8, 1.3); crate(-39.6, 18.4, 1.2); crate(-38.5, 19.1, 0.9);
    B(-31, 28.6, -27, 29.4, 1.1, 'stonewall'); a.taru(-29, 32.8, 3, 0, -1);
    a.sakura(-25.6, 30.4, 6.6, 1.05); a.fence(-41.5, 17.2, -36.4, 17.2); a.pot(-31.6, 24.2, 0.9); a.hokora(-39.6, 22.6, true);
    a.letter('A', -30, 21.6, 4.5);
    // ---------- точка B: рынок у амбара ----------
    kura(33, 26, 42, 34);
    a.stall(21.6, 26.6, 25.6, 28.6, -1, '#23326a'); a.stall(27, 19.6, 31, 21.4, 1, '#8a2a2a'); a.stall(36.4, 17.6, 40.6, 19.6, 1, '#2f4a3a');
    a.well(29.2, 25.2); a.cart(37.6, 22.4, HP); stack(22.6, 19.4, 1.3); crate(31.6, 31.2, 1.2); crate(30.4, 31.8, 0.9);
    a.taru(36, 24.2, 3, 0, -1); a.sakura(20.6, 31.6, 6.4, 1.0); a.bench(24, 22.6, 0); a.pot(19.6, 24.6); a.pot(41.2, 21.6, 0.9); a.hokora(40.4, 28.6, true);
    a.letter('B', 32.6, 23.2, 4.5);
    // ---------- за оградой: главный храм, пагода, крыши соседних кварталов, деревья ----------
    B(-15, 39, 15, 51, 6.5, 'shrine', 0, { solid: false });
    a.roof(-15, 39, 15, 51, 6.5, 5.5, 2.6, { hip: true, col: '#8cbcaa', ridgeCol: '#3d5a50' });
    let py = 0;
    for (let i = 0; i < 5; i++) {
      const s = 6.2 - i * 0.75, hh = i ? 2.4 : 3.2, cx = 31, cz = 47;
      B(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, hh, 'shrine', py, { solid: false });
      py += hh;
      a.roof(cx - s / 2, cz - s / 2, cx + s / 2, cz + s / 2, py, 1.35, 2.1 - i * 0.12, { hip: true, col: '#cdd2da', finial: i === 4 ? 8 : 0 });
      py += 0.5;
    }
    for (const [x0, z0, x1, z1] of [[-60, -6, -50, 6], [50, -8, 62, 4], [-18, -54, -2, -44], [6, -52, 22, -44]]) a.house2(x0, z0, x1, z1, { solid: false, h: 5.6 });
    const outer = [[-62, -24, -50, -12], [-63, 12, -50, 24], [50, -28, 61, -16], [50, 12, 60, 24], [-38, -52, -24, -44], [28, -54, 40, -44], [-44, 40, -26, 50], [42, 36, 56, 44]];
    for (const [x0, z0, x1, z1] of outer) house(x0, z0, x1, z1, { solid: false });
    for (const [x, z, h] of [[-30, 39, 7], [21, 40, 7.5], [-48, -16, 7], [-47, 9, 6.5], [47, 20, 7.5], [48, -6, 7], [-8, -40, 6.5], [16, -40, 7], [40, -41, 6.5], [-21, 52, 8]])
      a.sakura(x, z, h, 1.15, true);
    detailSakura(a);
  }

  function detailSakura(a) {
    const box = G.geo.box, cyl = G.geo.cyl;
    // лавка на первом этаже: дверь, норэн с гербом, вывеска и фонари под навесом (по фасаду вдоль X)
    const shopFront = (x0, x1, z, n, ph) => {
      ph = ph || 0;
      const s = n === '+z' ? 1 : -1, len = x1 - x0, k = Math.max(1, Math.round(len / 6.5));
      for (let i = 0; i < k; i++) {
        const x = x0 + (i + 0.5) * len / k, v = i + ph;
        a.decal(3, x, 1.35, z, 1.8, 2.2, n, 'jp');
        if (v % 2 === 0) {
          const nc = ['#23326a', '#8a2a2a', '#2f4a3a'][v % 3];
          for (let j = 0; j < 3; j++) a.D(box(0.56, 0.9, 0.03, x + (j - 1) * 0.46, 1.95, z + s * 0.1, nc));
          a.decal(7, x, 2.0, z + s * 0.13, 0.46, 0.9, n, 'jp');
        } else a.decal(2, x + 1.35, 1.7, z, 0.75, 1.5, n, 'jp');
        a.chochin(x - 1.3, 2.2, z + s * 0.5, null, 2.7); a.chochin(x + 1.3, 2.2, z + s * 0.5, null, 2.7);
      }
    };
    const shopZ = (z0, z1, x, n) => {
      const len = z1 - z0, k = Math.max(1, Math.round(len / 6.5));
      for (let i = 0; i < k; i++) { const z = z0 + (i + 0.5) * len / k; a.decal(3, x, 1.35, z, 1.8, 2.2, n, 'jp'); a.decal(2, x, 1.7, z + 1.35, 0.75, 1.5, n, 'jp'); }
    };
    shopFront(-41, -30, 10, '-z'); shopFront(-42, -29, 16, '+z', 1); shopZ(10, 16, -29, '+x');
    shopFront(-22, -9, 10, '-z', 1); shopFront(-23, -8, 16, '+z'); shopZ(10, 16, -23, '-x');
    shopFront(-2, 6, 10, '-z'); shopFront(-2, 6, 16, '+z', 1);
    shopFront(29, 41, 10, '-z'); shopFront(28, 42, 16, '+z', 1); shopZ(10, 16, 28, '-x');
    shopFront(-42, -33, -10, '+z'); shopFront(-42, -33, -16, '-z', 1); shopZ(-16, -10, -33, '+x');
    shopFront(-12, 1, -10, '+z', 1); shopFront(-13, 2, -16, '-z'); shopZ(-16, -10, -13, '-x');
    shopFront(9, 19, -10, '+z', 1); shopFront(8, 20, -16, '-z'); shopFront(20, 30, -10, '+z'); shopFront(20, 30, -16, '-z', 1); shopZ(-16, -10, 30, '+x');
    shopFront(36, 42, -10, '+z', 1); shopZ(-16, -10, 36, '-x');
    shopFront(-42, -30, -25, '+z'); shopZ(-34, -25, -30, '+x');
    // гербы на амбарах
    a.decal(7, -20, 4.3, -10, 1.1, 2.2, '+z', 'jp'); a.decal(7, -20, 4.3, -16, 1.1, 2.2, '-z', 'jp');
    a.decal(7, 37.5, 4.4, 26, 1.2, 2.4, '-z', 'jp'); a.decal(7, 36, 4.4, -25, 1.2, 2.4, '+z', 'jp');
    a.decal(3, -17, 1.4, -10, 1.8, 2.4, '+z', 'jp'); a.decal(3, 37.5, 1.4, 26, 1.8, 2.4, '-z', 'jp');
    // чайный дом: норэн над входами, вывески, светящиеся сёдзи внутри
    for (const [x0, z, n, s] of [[10.5, 10, '-z', -1], [18.5, 16, '+z', 1]]) {
      for (let j = 0; j < 4; j++) a.D(box(0.82, 1.0, 0.03, x0 + (j - 1.5) * 0.66, 2.3, z + s * 0.1, '#23326a'));
      a.decal(7, x0, 2.4, z + s * 0.13, 0.5, 1.0, n, 'jp');
      a.decal(2, x0 + 2.4, 2.8, z, 0.9, 1.8, n, 'jp');
      a.chochin(x0 - 2.1, 3.3, z + s * 0.4, null, 4.9); a.chochin(x0 + 2.1, 3.3, z + s * 0.4, null, 4.9);
    }
    for (const x of [16.6, 19.6]) a.decal(5, x, 1.9, 10.5, 1.4, 2.8, '+z', 'jp');
    for (const z of [11.8, 14.6]) a.decal(5, 6.5, 1.9, z, 1.4, 2.8, '+x', 'jp');
    a.decal(5, 21.5, 1.9, 13.4, 1.4, 2.8, '-x', 'jp'); a.decal(4, 14.5, 1.6, 11.6, 1.2, 2.4, '+x', 'jp');
    a.chochin(10, 2.9, 12.3, '#f2e6c8', 3.5); a.chochin(18, 2.9, 14.2, '#f2e6c8', 3.5);
    a.D(box(1.3, 0.3, 0.8, 17, 0.43, 11.4, '#5a3a24'), box(1.3, 0.3, 0.8, 20, 0.43, 11.4, '#5a3a24'));
    for (const [x, z] of [[16.2, 12.1], [17.8, 12.1], [19.2, 12.1], [20.8, 12.1], [16.2, 10.9], [20.8, 10.9]]) a.D(box(0.5, 0.08, 0.5, x, 0.32, z, '#8a2a2a'));
    for (let i = 0; i < 5; i++) a.D(cyl(0.07, 0.3, 7.8 + i * 0.8, 1.2, 14.2, ['#f2ece0', '#3a5a3a', '#8a5a2a'][i % 3], 0, 0, 0, 8));
    // святилище: верёвка симэнава с бумажными сидэ, ящик для подношений, таблички
    a.D(cyl(0.14, 7.6, -37, 4.15, 25.75, '#d8c48a', 0, 0, HP, 8));
    for (let i = 0; i < 5; i++) a.D(box(0.22, 0.5, 0.02, -39.4 + i * 1.2, 3.7, 25.68, '#ffffff'));
    a.decal(4, -29, 1.5, 34, 1.4, 2.8, '-z', 'jp'); a.D(box(2.2, 0.12, 0.5, -29, 2.6, 33.7, '#5a3c26'));
    a.D(box(1.2, 0.5, 0.6, -37, 0.85, 25.6, '#4a3426'), box(1.2, 0.06, 0.6, -37, 1.12, 25.6, '#6a4a30'));
    // флаги-нобори у храма и вдоль дороги к святилищу
    for (const [x, z, col] of [[-9.5, 33.3, '#c8321e'], [-6, 33.3, '#f2ece0'], [6, 33.3, '#f2ece0'], [9.5, 33.3, '#c8321e'], [-28.6, 17.6, '#c8321e'], [-23.4, 17.6, '#f2ece0']]) {
      a.D(cyl(0.05, 4.4, x, 2.2, z, '#3a2a1e', 0, 0, 0, 5), box(0.75, 2.8, 0.03, x + 0.32, 2.7, z, col), box(0.75, 0.05, 0.05, x + 0.32, 4.1, z, '#3a2a1e'));
    }
    // гирлянды фонарей: над рынком, над улицами, в переулке к B
    const garland = (ax, az, bx, bz, y0, y1, n) => {
      a.wire([ax, y0, az], [bx, y1, bz], 0.5);
      for (let i = 1; i < n; i++) { const t = i / n, wy = y0 + (y1 - y0) * t - Math.sin(t * Math.PI) * 0.5; a.chochin(ax + (bx - ax) * t, wy - 0.55, az + (bz - az) * t, i % 2 ? '#d6402a' : '#f2e6c8', wy); }
    };
    garland(33, 27.6, 26, 27.6, 4.6, 2.6, 5); garland(25, 10, 25, 16, 4.4, 4.4, 4); garland(-20, 9.8, -20, -9.8, 5.2, 5.2, 7); garland(33, 9.8, 33, -9.8, 5.2, 5.2, 7);
    garland(-35, -9.8, -25, -9.8, 4.8, 4.8, 5); garland(23, -24.6, 30, -24.6, 4.6, 4.6, 4);
    // каменная дорожка в саду, пятна мха
    for (const [x, z] of [[5.6, -9], [6.4, -7.6], [7.9, -6.9], [9, -3.6], [8.2, -2.4], [-6.8, 2.2], [-7.6, 3.4], [-6.6, 5], [-5.4, 9.2], [-10.2, 1.6], [10.2, -1.6]])
      a.D(cyl(0.42, 0.06, x, 0.03, z, '#8c8981', 0, 0, 0, 7));
    a.stain(-29, 2, 2.2); a.stain(28, -2, 2.2); a.stain(3, -27, 2.4); a.stain(-36, 20, 2.6); a.stain(30, 23, 2.4);
  }

  // ===================== «Полигон» (обучение) =====================
  function layoutRange(a) {
    const { B, crate, stack, lintel, barrel, lamp } = a;
    const box = G.geo.box, cyl = G.geo.cyl;
    B(-22, -18, 22, -17, 5, 'corrug'); B(-22, 17, 22, 18, 5, 'corrug'); B(-22, -17, -21, 17, 5, 'corrug'); B(21, -17, 22, 17, 5, 'corrug');
    for (const [x0, z0, x1, z1] of [[-22, -18, 22, -17], [-22, 17, 22, 18], [-22, -17, -21, 17], [21, -17, 22, 17]]) B(x0, z0, x1, z1, 0.9, 'hazard', 0, { solid: false });
    // полоса препятствий: коридор, барьер для прыжка, балка для приседа
    B(-5, -10.5, -4.5, 7, 2.6, 'concrete'); B(4.5, -10.5, 5, 7, 2.6, 'concrete');
    B(-4.5, -0.3, 4.5, 0.3, 0.9, 'hazard');
    lintel(-4.5, -5.5, 4.5, -4.5, 1.35, 2.6, 'metal');
    B(-5.2, -10.8, 5.2, 7.3, 0.3, 'roof', 2.6, { solid: false });
    B(-4.5, -10.5, 4.5, 7, 0.02, 'pave', 0, { solid: false });
    // стрельбище: дорожки и щиты за мишенями
    B(-9, -17, 9, -11, 0.02, 'pave', 0, { solid: false });
    for (const x of [-5, 0, 5]) { B(x - 1.3, -17, x + 1.3, -16.5, 2.4, 'planks'); B(x - 1.4, -17, x + 1.4, -16.4, 0.12, 'metal', 2.4); }
    B(-9.4, -16, -9, -11, 1.0, 'concrete'); B(9, -16, 9.4, -11, 1.0, 'concrete');
    a.sandbags(-6.5, -11.6, 3.2, 0, 2); a.sandbags(6.5, -11.6, 3.2, 0, 2);
    // яма для гранат: невысокая ограда, мишени внутри
    B(10, -14, 18, -13.6, 1.1, 'hazard'); B(10, -6.4, 18, -6, 1.1, 'hazard'); B(10, -14, 10.4, -6, 1.1, 'hazard'); B(17.6, -14, 18, -6, 1.1, 'hazard');
    B(10.4, -13.6, 17.6, -6.4, 0.02, 'sand', 0, { solid: false });
    a.tires(11.6, -12.6, 2); barrel(16.4, -7.4, '#8a2d22');
    // точка A
    B(-18, -14, -10, -6, 0.02, 'pave', 0, { solid: false });
    a.sandbags(-14, -5.2, 3, 0, 2); a.sandbags(-18.6, -10, 2.6, HP, 2);
    crate(-11, -13, 1.2); stack(-17, -13, 1.2);
    a.letter('A', -14, -10, 4.5);
    // двор у спавна: ящики, бочки, фонари, вышка
    crate(-9, 12, 1.2); stack(8, 13, 1.3); barrel(10, 10, '#2f5f8a'); barrel(10.7, 10.4, '#3b5f3a'); crate(-8, 4, 1.1); crate(12, 3, 1.2);
    a.tires(-16, 15, 3); a.tires(17, -2, 2);
    lamp(-8, -9, 6, HP); lamp(8, -9, 6, -HP); lamp(-16, 2, 6, 0); lamp(16, 8, 6, Math.PI);
    B(-20, 8, -16, 12, 3.2, 'contGreen'); B(16, -16, 20, -12, 2.6, 'contBlue');
    // смотровая вышка в юго-восточном углу
    for (const [x, z] of [[16, 14], [19.5, 14], [16, 16.5], [19.5, 16.5]]) a.D(cyl(0.12, 6, x, 3, z, '#4a4d50', 0, 0, 0, 8));
    a.D(box(4.3, 0.2, 3.3, 17.75, 6, 15.25, '#5a5d60'), box(4.3, 1.0, 0.1, 17.75, 6.6, 13.65, '#6a6d70'), box(0.1, 1.0, 3.3, 15.65, 6.6, 15.25, '#6a6d70'));
    B(15.6, 13.6, 19.9, 16.9, 7, 'none', 0, { hidden: true });
    detailRange(a);
  }
  function detailRange(a) {
    const D = a.decal;
    D(7, -21, 2.6, -8, 1.2, 2.4, '+x'); D(6, -21, 1.8, 10, 1.1, 2.2, '+x'); D(7, 21, 2.6, 4, 1.2, 2.4, '-x');
    D(6, 6, 1.8, 17, 1.1, 2.2, '-z'); D(7, -6, 2.6, 17, 1.2, 2.4, '-z'); D(6, 14, 1.8, -17, 1.1, 2.2, '+z'); D(7, -14, 2.6, -17, 1.2, 2.4, '+z');
    a.stain(0, 9, 2.4); a.stain(-14, -10, 2); a.stain(6, -8, 2.2);
    const p1 = a.pole(-12, 16.5, 7), p2 = a.pole(12, 16.5, 7); a.wire(p1, p2, 1.0);
  }

  // ===================== «Зимний двор» (дуэли 1 на 1) =====================
  // компактная симметричная площадь: фонтан во льду, два спуска к спавнам, рынок и поленница по бокам
  function layoutWinter(a) {
    const { B, crate, stack } = a;
    const box = G.geo.box, cyl = G.geo.cyl, D = (...p) => a.D(...p);
    const SNOW = '#f2f6fb', SNOW2 = '#e4ebf3', IRON = '#2a2d31', WOODD = '#4a3020';
    // снежная «подушка» поверх детали: чуть шире, со скруглением
    const cap = (x0, z0, x1, z1, y, t) => {
      t = t || 0.16;
      D(box(x1 - x0 + 0.12, t, z1 - z0 + 0.12, (x0 + x1) / 2, y + t / 2, (z0 + z1) / 2, SNOW));
      D({ sph: true, r: 1, sx: (x1 - x0) / 2 + 0.04, sy: t * 0.9, sz: (z1 - z0) / 2 + 0.04, x: (x0 + x1) / 2, y: y + t, z: (z0 + z1) / 2, color: SNOW, seg: 10 });
    };
    const stoneWall = (x0, z0, x1, z1, h) => { B(x0, z0, x1, z1, h, 'stonewall'); cap(x0, z0, x1, z1, h, 0.18); };
    const drift = (x, z, sx, sz, h) => D({ sph: true, r: 1, sx, sy: h, sz, x, y: 0, z, color: Math.random() < 0.5 ? SNOW : SNOW2, seg: 12 });
    // ель: тёмные ярусы и снег на каждом
    const pine = (x, z, h) => {
      h = h || 7;
      B(x - 0.35, z - 0.35, x + 0.35, z + 0.35, h, 'none', 0, { hidden: true });
      D(cyl(0.22, 1.4, x, 0.7, z, '#3b2a1e', 0, 0, 0, 7));
      const tiers = 4;
      for (let i = 0; i < tiers; i++) {
        const t = i / tiers, r = 2.1 * (1 - t * 0.68), y0 = 1.0 + i * (h - 1.6) / tiers, th = (h - 1.0) / tiers * 1.35;
        D({ cyl: true, r: 0.05, r2: r, h: th, x, y: y0 + th / 2, z, color: i % 2 ? '#1f3b2b' : '#25442f', seg: 9 });
        D({ cyl: true, r: 0.04, r2: r * 0.78, h: th * 0.5, x, y: y0 + th * 0.78, z, color: SNOW, seg: 9 });
      }
      D({ sph: true, r: 0.18, x, y: h + 0.05, z, color: SNOW, seg: 8 });
      drift(x, z, 1.6, 1.4, 0.32);
    };
    // фонарь на кованом столбе: тёплый свет и пятно на снегу
    const lantern = (x, z) => {
      B(x - 0.15, z - 0.15, x + 0.15, z + 0.15, 3.2, 'none', 0, { hidden: true });
      D(cyl(0.1, 3.0, x, 1.5, z, IRON, 0, 0, 0, 8), cyl(0.2, 0.25, x, 0.12, z, IRON, 0, 0, 0, 8));
      D(box(0.42, 0.06, 0.42, x, 3.04, z, IRON), box(0.34, 0.5, 0.34, x, 3.32, z, '#ffd9a0'), box(0.46, 0.08, 0.46, x, 3.6, z, IRON),
        { cyl: true, r: 0.02, r2: 0.3, h: 0.22, x, y: 3.74, z, color: IRON, seg: 4, ry: Math.PI / 4 }, box(0.3, 0.06, 0.3, x, 3.88, z, SNOW));
      a.lamps.push([x, 3.32, z, 2.2]);
      a.pool(x, z, 5.5);
    };
    // дом по краю площади: стены, светящиеся окна, дверь, снежная двускатная крыша, труба
    const house = (x0, z0, x1, z1, mat, inner) => {
      const h = 7.2;
      B(x0, z0, x1, z1, h, mat);
      const w = x1 - x0, l = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      D({ shape: true, pts: [[-w / 2 - 0.55, 0], [0, 2.5], [w / 2 + 0.55, 0]], d: l + 0.9, x: cx, y: h, z: cz, ry: HP, color: SNOW, cs: 1 });
      D(box(0.18, 0.22, l + 0.9, x0 - 0.5, h - 0.05, cz, WOODD), box(0.18, 0.22, l + 0.9, x1 + 0.5, h - 0.05, cz, WOODD));
      D(box(0.9, 1.8, 0.9, cx + w * 0.18, h + 1.7, z0 + l * 0.3, '#5c4a40'), box(1.04, 0.2, 1.04, cx + w * 0.18, h + 2.65, z0 + l * 0.3, SNOW));
      // окна и дверь на стороне площади
      const xf = inner > 0 ? x1 : x0, n = inner > 0 ? '+x' : '-x';
      for (let zz = z0 + 2; zz <= z1 - 1.5; zz += 3.2) {
        a.decal(5, xf, 5.0, zz, 1.3, 1.9, n);
        if (Math.abs(zz - cz) < 1.7) a.decal(2, xf, 1.45, zz, 1.5, 2.9, n); else a.decal(5, xf, 2.0, zz, 1.3, 1.9, n);
        D(box(0.3, 0.12, 1.5, xf + inner * 0.15, 4.0, zz, SNOW));
      }
      drift(xf + inner * 0.35, cz, 0.8, l / 2, 0.35);
    };
    // ---------- периметр ----------
    B(-19, -27, 19, -26, 6, 'stonewall'); B(-19, 26, 19, 27, 6, 'stonewall');
    B(-19, -26, -18, 26, 6, 'stonewall'); B(18, -26, 19, 26, 6, 'stonewall');
    for (const [x0, z0, x1, z1] of [[-19, -27, 19, -26], [-19, 26, 19, 27], [-19, -26, -18, 26], [18, -26, 19, 26]]) cap(x0, z0, x1, z1, 6, 0.25);
    // всё остальное — центрально-симметрично: (x, z) и (-x, -z)
    for (const s of [1, -1]) {
      const X = (v) => v * s, Z = (v) => v * s, R = s > 0 ? 0 : Math.PI;
      const BB = (x0, z0, x1, z1, h, mat, y0, o) => B(X(x0), Z(z0), X(x1), Z(z1), h, mat, y0, o);
      const SW = (x0, z0, x1, z1, h) => stoneWall(Math.min(X(x0), X(x1)), Math.min(Z(z0), Z(z1)), Math.max(X(x0), X(x1)), Math.max(Z(z0), Z(z1)), h);
      // дома: штукатурка у одного спавна, кирпич у другого
      house(Math.min(X(-18), X(-13)), Math.min(Z(8), Z(25.9)), Math.max(X(-18), X(-13)), Math.max(Z(8), Z(25.9)), 'plaster', s);
      house(Math.min(X(13), X(18)), Math.min(Z(13), Z(25.9)), Math.max(X(13), X(18)), Math.max(Z(13), Z(25.9)), 'brick', -s);
      // арка ворот на торце: столбы, свод, тёмные створки
      D(box(1.0, 4.6, 0.9, X(-2.9), 2.3, Z(25.6), '#6f6a66'), box(1.0, 4.6, 0.9, X(2.9), 2.3, Z(25.6), '#6f6a66'),
        box(6.8, 1.0, 1.0, 0, 4.9, Z(25.6), '#6f6a66'), box(7.0, 0.22, 1.2, 0, 5.5, Z(25.6), SNOW),
        box(4.6, 3.8, 0.12, 0, 1.9, Z(25.45), '#3c2618'), box(0.08, 3.6, 0.14, 0, 1.9, Z(25.4), '#1c120b'),
        box(0.12, 0.12, 0.2, X(-0.4), 1.8, Z(25.3), '#b08a40'), box(0.12, 0.12, 0.2, X(0.4), 1.8, Z(25.3), '#b08a40'));
      // навес над спавном
      for (const xx of [-3.6, 3.6]) { BB(xx - 0.12, 21.3, xx + 0.12, 21.6, 3.3, 'none', 0, { hidden: true }); D(box(0.22, 3.3, 0.22, X(xx), 1.65, Z(21.45), WOODD)); }
      D(box(8.2, 0.16, 4.4, 0, 3.38, Z(23.4), '#5a3a26', 0.08 * s), box(8.4, 0.2, 4.6, 0, 3.55, Z(23.4), SNOW, 0.08 * s), box(8.4, 0.12, 0.2, 0, 3.22, Z(21.3), WOODD));
      // низкие каменные стенки перед спавном
      SW(-7.5, 16.6, -2.6, 17.3, 1.15); SW(2.6, 16.6, 7.5, 17.3, 1.15);
      // дорожка к фонтану
      BB(-1.6, 6.2, 1.6, 25, 0.02, 'jpstone', 0, { solid: false });
      // рынок: прилавок с навесом и ящики
      BB(-11.8, 10.4, -8.4, 11.5, 1.05, 'planks');
      D(box(3.6, 0.1, 1.3, X(-10.1), 1.08, Z(10.95), SNOW2));
      for (const xx of [-11.7, -8.5]) D(box(0.14, 2.6, 0.14, X(xx), 1.3, Z(11.45), WOODD));
      a.awning(X(-10.1), 2.75, Z(11.45), 3.6, 1.6, s > 0 ? '-z' : '+z', '#2f5d86');
      stack(X(-12.3), Z(7.2), 1.15); crate(X(-7.8), Z(13.8), 1.1);
      D(box(1.2, 0.14, 1.2, X(-12.3), 1.22, Z(7.2), SNOW), box(1.0, 0.12, 1.0, X(-12.24), 2.15, Z(7.15), SNOW));
      // поленница
      BB(6.6, 4.0, 10.2, 5.3, 1.1, 'none', 0, { hidden: true });
      for (let r = 0; r < 3; r++) for (let i = 0; i < 9 - r; i++) D(cyl(0.2, 1.25, X(6.95 + i * 0.4 + r * 0.2), 0.22 + r * 0.36, Z(4.65), i % 3 ? '#7a5634' : '#8a6440', HP, 0, 0, 8));
      D(box(3.8, 0.14, 1.4, X(8.4), 1.18, Z(4.65), SNOW));
      // каменная стенка у фонтана и бочки
      SW(7.2, 0.9, 10.2, 1.6, 1.1);
      a.barrel(X(10.6), Z(11.8), '#5b3a2a'); a.barrel(X(11.3), Z(12.4), '#3f4f5f');
      D(cyl(0.32, 0.08, X(10.6), 1.0, Z(11.8), SNOW, 0, 0, 0, 12), cyl(0.32, 0.08, X(11.3), 1.0, Z(12.4), SNOW, 0, 0, 0, 12));
      crate(X(6.4), Z(10.2), 1.2); D(box(1.3, 0.14, 1.3, X(6.4), 1.27, Z(10.2), SNOW));
      // ели и фонари
      pine(X(-15.6), Z(2.4), 7.5); pine(X(15.8), Z(7.0), 6.5);
      lantern(X(-4.6), Z(4.6)); lantern(X(4.6), Z(4.6)); lantern(X(-12.4), Z(17.6));
      // сугробы вдоль стен
      drift(X(-8), Z(25.6), 4.5, 0.9, 0.5); drift(X(9), Z(25.6), 3.5, 0.8, 0.45); drift(X(-17.6), Z(-1), 0.7, 4, 0.5); drift(X(17.5), Z(9.5), 0.6, 2.5, 0.4);
      a.stain(X(-3), Z(12), 2.2);
    }
    // ---------- фонтан во льду ----------
    stoneWall(-2.6, -2.6, 2.6, 2.6, 0.8);
    D(box(4.6, 0.06, 4.6, 0, 0.84, 0, '#bfe0ee'));
    B(-0.6, -0.6, 0.6, 0.6, 2.3, 'stonewall');
    D(cyl(1.1, 0.25, 0, 2.42, 0, '#6f6a66', 0, 0, 0, 16), cyl(1.15, 0.12, 0, 2.6, 0, SNOW, 0, 0, 0, 16));
    // ледяная скульптура: сосульки и шар
    for (let i = 0; i < 10; i++) { const an = i / 10 * Math.PI * 2; D({ cyl: true, r: 0.11, r2: 0.01, h: 0.6 + (i % 3) * 0.2, x: Math.cos(an) * 1.0, y: 2.0 - (i % 3) * 0.1, z: Math.sin(an) * 1.0, color: '#d6f0fa', seg: 6, rx: Math.PI }); }
    D({ sph: true, r: 0.55, x: 0, y: 3.2, z: 0, color: '#cdeefa', seg: 12 }, { cyl: true, r: 0.12, r2: 0.3, h: 0.5, x: 0, y: 2.75, z: 0, color: '#9fc8d8', seg: 10 });
    B(-6.2, -6.2, 6.2, 6.2, 0.02, 'jpstone', 0, { solid: false });
    a.snowfall = true;
  }

  // ---------- описание карт ----------
  G.DUEL_MAP = 'winter';
  G.MAPS = {
    dust: {
      name: 'Пыльный квартал', sub: 'Полдень · пустынный город', scale: 1.35, bounds: { x0: -40, x1: 40, z0: -32, z1: 32 },
      layout: layoutDust, ground: { mat: 'sand', size: [82, 66], repeat: 5 },
      matScale: { wall: 4, stucco: 3, concrete: 3, roof: 3, pave: 4, metal: 2, contRed: 2.6, contBlue: 2.6, contGreen: 2.6, crate: 1 },
      env: {
        skyTop: '#5d93cf', skyHor: '#e3e6df', skyLow: '#cdbb98', fog: '#d9d6c8', fogNear: 55, fogFar: 175,
        hemiSky: '#d6e6ff', hemiGround: '#9a7d55', hemiI: 0.78, sun: '#fff0d2', sunI: 0.95, sunPos: [30, 55, 20],
        sunSprite: [120, 160, 70], sunSpriteColor: '#fff4d6', sunSize: 40, clouds: '#ffffff', cloudN: 10, dune: '#c2a77a',
        vmTint: '#fff2dc'
      },
      spawnZones: [{ x0: -13, x1: 13, z0: 21.5, z1: 30.5, yaw: 0 }, { x0: -13, x1: 13, z0: -30.5, z1: -21.5, yaw: Math.PI }],
      sites: { A: { x0: -39, x1: -21, z0: 15.2, z1: 23.5 }, B: { x0: 17, x1: 39, z0: 15.2, z1: 21.5 } }
    },
    harbor: {
      name: 'Гавань', sub: 'Закат · морской порт', scale: 1.3, bounds: { x0: -44, x1: 44, z0: -34, z1: 34 },
      layout: layoutHarbor, ground: { mat: 'asphalt', size: [90, 70], repeat: 6 },
      matScale: { brick: 3, corrug: 3, concrete: 3, roof: 3, metal: 2, planks: 4, hazard: 2, contRed: 2.6, contBlue: 2.6, contGreen: 2.6, contOrange: 2.6, crate: 1 },
      env: {
        skyTop: '#2c3a72', skyHor: '#ffb07a', skyLow: '#b8806a', skyMid: '#c9708a', fog: '#e7a17e', fogNear: 50, fogFar: 210,
        hemiSky: '#a8b4e6', hemiGround: '#b0744c', hemiI: 0.66, sun: '#ffb56e', sunI: 1.12, sunPos: [60, 24, -14],
        sunSprite: [260, 48, -60], sunSpriteColor: '#ffd08a', sunSize: 70, clouds: '#ffc9a8', cloudN: 14,
        water: { level: -1.3, deep: '#1b2c4a', shallow: '#3d6880', sky: '#f2a283', x0: 44 }, vmTint: '#ffd9b0'
      },
      spawnZones: [{ x0: -11, x1: 11, z0: 23, z1: 32.5, yaw: 0 }, { x0: -12, x1: 12, z0: -32.5, z1: -25.5, yaw: Math.PI }],
      sites: { A: { x0: -40, x1: -19, z0: 8, z1: 24 }, B: { x0: 19, x1: 42, z0: 7, z1: 22.5 } }
    },
    sakura: {
      name: 'Сакура', sub: 'Весеннее утро · японский квартал', scale: 1.3, bounds: { x0: -42, x1: 42, z0: -34, z1: 34 },
      layout: layoutSakura, ground: { mat: 'jpstone', size: [132, 116], repeat: 5 },
      matScale: { machiya: 5, kura: 5.5, shrine: 4.2, stonewall: 3, plaster: 3.4, gravel: 4, bamboo: 2.6, planks: 3, tatami: 1.8, crate: 1 },
      env: {
        skyTop: '#5d9ade', skyMid: '#a8c8ec', skyHor: '#fbe3ea', skyLow: '#e3c4ce', fog: '#f1dde4', fogNear: 62, fogFar: 220,
        hemiSky: '#f4f0ff', hemiGround: '#8d7c74', hemiI: 0.82, sun: '#fff0e0', sunI: 0.95, sunPos: [-34, 52, -26],
        sunSprite: [-150, 115, -170], sunSpriteColor: '#fff4e6', sunSize: 42, clouds: '#ffffff', cloudN: 12,
        mount: '#5f7d84', rock: '#45605a', mountH: 0.5, fuji: [20, 320], vmTint: '#fff0ec'
      },
      spawnZones: [{ x0: -11, x1: 11, z0: 23, z1: 32, yaw: 0 }, { x0: -12, x1: 12, z0: -32, z1: -23, yaw: Math.PI }],
      sites: { A: { x0: -41, x1: -19, z0: 17, z1: 25.5 }, B: { x0: 20, x1: 41, z0: 17, z1: 25.5 } }
    },
    winter: {
      name: 'Зимний двор', sub: 'Снегопад · дуэли 1 на 1', scale: 1, bounds: { x0: -18, x1: 18, z0: -26, z1: 26 }, duel: true,
      layout: layoutWinter, ground: { mat: 'snow', size: [40, 56], repeat: 6 },
      matScale: { stonewall: 3, plaster: 3.4, brick: 3, planks: 3, jpstone: 4, crate: 1 },
      env: {
        skyTop: '#6f8fb8', skyMid: '#a9bfd8', skyHor: '#e9eef4', skyLow: '#d5dde6', fog: '#dde4ec', fogNear: 36, fogFar: 140,
        hemiSky: '#e4ecff', hemiGround: '#a9b3c0', hemiI: 0.92, sun: '#ffdcb4', sunI: 0.82, sunPos: [-35, 30, 22],
        sunSprite: [-180, 70, 120], sunSpriteColor: '#ffe6c8', sunSize: 46, clouds: '#f6f8fb', cloudN: 14,
        mount: '#9aa8ba', rock: '#7c8a9c', mountH: 0.9, vmTint: '#eef2ff'
      },
      spawnZones: [{ x0: -4, x1: 4, z0: 20.5, z1: 24, yaw: 0 }, { x0: -4, x1: 4, z0: -24, z1: -20.5, yaw: Math.PI }],
      sites: { A: { x0: -12, x1: -8, z0: 8, z1: 12 }, B: { x0: 8, x1: 12, z0: -12, z1: -8 } }
    },
    range: {
      name: 'Полигон', sub: 'Обучение', scale: 1, bounds: { x0: -21, x1: 21, z0: -17, z1: 17 }, hidden: true,
      layout: layoutRange, ground: { mat: 'asphalt', size: [44, 36], repeat: 6 },
      matScale: { corrug: 3, concrete: 3, roof: 3, pave: 4, metal: 2, hazard: 2, planks: 3, contGreen: 2.6, contBlue: 2.6, crate: 1, sand: 4 },
      env: {
        skyTop: '#4f8fd2', skyHor: '#dfe6ea', skyLow: '#b9b2a4', fog: '#d6d9d6', fogNear: 50, fogFar: 170,
        hemiSky: '#d6e6ff', hemiGround: '#8f8678', hemiI: 0.8, sun: '#fff3dc', sunI: 1.0, sunPos: [26, 58, 18],
        sunSprite: [110, 170, 60], sunSpriteColor: '#fff6dc', sunSize: 38, clouds: '#ffffff', cloudN: 9, dune: '#8f8a7e', mount: '#6f7a78', vmTint: '#fff4e4'
      },
      spawnZones: [{ x0: -2, x1: 2, z0: 12, z1: 15, yaw: 0 }, { x0: -2, x1: 2, z0: 12, z1: 15, yaw: 0 }],
      sites: { A: { x0: -18, x1: -10, z0: -14, z1: -6 } },
      // данные обучения: манекены [x, z, yaw], центр ямы, точка закладки
      tut: { dummies: [[-5, -16, Math.PI], [0, -16, Math.PI], [5, -16, Math.PI], [13, -9, HP], [15, -11, HP], [-12, 9, -HP]], pit: [14, -10], look: [-12, 9], site: { x0: -18, x1: -10, z0: -14, z1: -6 } }
    }
  };

  // ---------- материалы ----------
  const NM = [];
  // материал с рельефом: карта нормалей строится из яркости текстуры
  const lam = (name, arg, ns) => {
    const m = new THREE.MeshLambertMaterial({ map: G.tex(name, arg), vertexColors: true });
    m.userData.nm = G.normalTex(name, arg); m.userData.ns = ns || 1;
    if (G.settings.quality === 'high') { m.normalMap = m.userData.nm; m.normalScale = new THREE.Vector2(m.userData.ns, m.userData.ns); }
    NM.push(m);
    return m;
  };
  const MAT_FACTORY = {
    wall: () => lam('wall', null, 1.3), stucco: () => lam('stucco', null, 0.7), concrete: () => lam('concrete', null, 0.8),
    roof: () => lam('roof', null, 1), pave: () => lam('pave', null, 1.2), metal: () => lam('metal', null, 0.9), crate: () => lam('crate', null, 1.2),
    contRed: () => lam('container', '#9c3b2c', 1.5), contBlue: () => lam('container', '#2f5d86', 1.5),
    contGreen: () => lam('container', '#4d6b3a', 1.5), contOrange: () => lam('container', '#c46a1f', 1.5),
    brick: () => lam('brick', null, 1.4), corrug: () => lam('corrug', '#7d8b95', 1.6), planks: () => lam('planks', null, 1.3),
    hazard: () => lam('hazard', null, 0.6), asphalt: () => lam('asphalt', null, 0.8), sand: () => lam('sand', null, 0.9),
    machiya: () => lam('machiya', null, 0.8), kura: () => lam('kura', null, 0.9), shrine: () => lam('shrine', null, 0.6),
    stonewall: () => lam('stonewall', null, 1.5), plaster: () => lam('plaster', null, 0.4), jpstone: () => lam('jpstone', null, 1.0),
    gravel: () => lam('gravel', null, 0.8), bamboo: () => lam('bamboo', null, 1.3), tatami: () => lam('tatami', null, 0.5),
    koshi: () => lam('koshi', null, 1.4), hedge: () => lam('hedge', null, 1.2),
    snow: () => lam('snow', null, 0.5)
  };
  G.mapDetail = (on) => {
    for (const m of NM) { m.normalMap = on ? m.userData.nm : null; if (on) m.normalScale = new THREE.Vector2(m.userData.ns, m.userData.ns); m.needsUpdate = true; }
  };
  // дальний фон за картой (горы, дюны, город, облака) — только на высоком качестве
  const BACKDROP = [];
  G.mapBackdrop = (on) => { for (const o of BACKDROP) o.visible = !!on; };
  const matCache = {};
  const getMat = (k) => matCache[k] || (matCache[k] = MAT_FACTORY[k]());

  function addBox(buf, b, scale) {
    const { x0, y0, z0, x1, y1, z1 } = b;
    const faces = [
      { n: [1, 0, 0], c: [[x1, y0, z0], [x1, y0, z1], [x1, y1, z1], [x1, y1, z0]] },
      { n: [-1, 0, 0], c: [[x0, y0, z1], [x0, y0, z0], [x0, y1, z0], [x0, y1, z1]] },
      { n: [0, 1, 0], c: [[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]] },
      { n: [0, -1, 0], c: [[x0, y0, z1], [x1, y0, z1], [x1, y0, z0], [x0, y0, z0]] },
      { n: [0, 0, 1], c: [[x1, y0, z1], [x0, y0, z1], [x0, y1, z1], [x1, y1, z1]] },
      { n: [0, 0, -1], c: [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0]] }
    ];
    for (const f of faces) {
      if (f.n[1] === -1 && y0 <= 0.001 && y0 >= -0.001) continue;
      if (y1 - y0 < 0.05 && f.n[1] !== 1) continue; // тонкие «наклейки» — только верх
      let c = f.c;
      const ax = c[1][0] - c[0][0], ay = c[1][1] - c[0][1], az = c[1][2] - c[0][2];
      const bx = c[2][0] - c[0][0], by = c[2][1] - c[0][1], bz = c[2][2] - c[0][2];
      const cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
      if (cx * f.n[0] + cy * f.n[1] + cz * f.n[2] < 0) c = [c[0], c[3], c[2], c[1]];
      const base = buf.pos.length / 3;
      for (const v of c) {
        buf.pos.push(v[0], v[1], v[2]);
        buf.nor.push(f.n[0], f.n[1], f.n[2]);
        let u, w;
        if (b.uv === 'face') {
          if (f.n[0] !== 0) { u = (v[2] - z0) / (z1 - z0); w = (v[1] - y0) / (y1 - y0); }
          else if (f.n[1] !== 0) { u = (v[0] - x0) / (x1 - x0); w = (v[2] - z0) / (z1 - z0); }
          else { u = (v[0] - x0) / (x1 - x0); w = (v[1] - y0) / (y1 - y0); }
        } else {
          if (f.n[0] !== 0) { u = v[2] / scale; w = v[1] / scale; }
          else if (f.n[1] !== 0) { u = v[0] / scale; w = v[2] / scale; }
          else { u = v[0] / scale; w = v[1] / scale; }
        }
        buf.uv.push(u, w);
        let ao = 1;
        if (f.n[1] === 0 && v[1] <= 0.01 && y0 <= 0.01) ao = 0.6;
        else if (f.n[1] === 0 && v[1] < 1.2 && y0 <= 0.01) ao = 0.6 + 0.4 * (v[1] / 1.2);
        if (f.n[1] === -1) ao = 0.72;
        buf.col.push(ao, ao, ao);
      }
      buf.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }

  // ---------- борьба с мерцанием совпадающих плоскостей (z-fighting) ----------
  // Если грань коробки лежит в той же плоскости, что и грань более ранней коробки (и смотрит туда же),
  // а материалы/развёртка отличаются — на телефоне они «дерутся» за пиксели. Сдвигаем такую грань
  // (только визуально, коллизии не меняются) на несколько миллиметров наружу, слоями.
  const ZSTEP = 0.009, ZEPS = 0.004;
  function deZFight(list) {
    const bucket = new Map(), out = [];
    const sides = (b, thin) => {
      const r = [{ k: 'py', ax: 1, s: 1, v: b.y1, a0: b.x0, a1: b.x1, b0: b.z0, b1: b.z1 }];
      if (!thin) r.push(
        { k: 'px', ax: 0, s: 1, v: b.x1, a0: b.y0, a1: b.y1, b0: b.z0, b1: b.z1 }, { k: 'nx', ax: 0, s: -1, v: b.x0, a0: b.y0, a1: b.y1, b0: b.z0, b1: b.z1 },
        { k: 'pz', ax: 2, s: 1, v: b.z1, a0: b.x0, a1: b.x1, b0: b.y0, b1: b.y1 }, { k: 'nz', ax: 2, s: -1, v: b.z0, a0: b.x0, a1: b.x1, b0: b.y0, b1: b.y1 });
      return r;
    };
    for (const b of list) {
      const thin = b.y1 - b.y0 < 0.05, off = {};
      const fs = sides(b, thin);
      for (const f of fs) {
        let layer = 0;
        const kk = Math.round(f.v / 0.01);
        for (let d = -1; d <= 1; d++) {
          const L = bucket.get(f.ax + '|' + f.s + '|' + (kk + d)); if (!L) continue;
          for (const q of L) {
            if (Math.abs(q.v - f.v) > ZEPS) continue;
            if (q.mat === b.mat && q.uv !== 'face' && b.uv !== 'face') continue;
            if (Math.min(q.a1, f.a1) - Math.max(q.a0, f.a0) <= 0.01 || Math.min(q.b1, f.b1) - Math.max(q.b0, f.b0) <= 0.01) continue;
            layer = Math.max(layer, q.layer + 1);
          }
        }
        if (layer) off[f.k] = layer * ZSTEP;
        f.layer = layer; f.mat = b.mat; f.uv = b.uv;
        const key = f.ax + '|' + f.s + '|' + kk;
        if (!bucket.has(key)) bucket.set(key, []);
        bucket.get(key).push(f);
      }
      if (Object.keys(off).length) {
        const nb = Object.assign({}, b);
        nb.x1 += off.px || 0; nb.x0 -= off.nx || 0; nb.y1 += off.py || 0; nb.z1 += off.pz || 0; nb.z0 -= off.nz || 0;
        out.push(nb);
      } else out.push(b);
    }
    return out;
  }
  // декоративные брусья/доски вровень со стеной — чуть «выдвигаем» из стены
  function unflushDecor(dec, list) {
    if (!dec || !dec.length) return;
    const planes = { 0: new Map(), 1: new Map(), 2: new Map() };
    const put = (ax, v, a0, a1, b0, b1, c) => { const k = Math.round(v / 0.01); if (!planes[ax].has(k)) planes[ax].set(k, []); planes[ax].get(k).push([v, a0, a1, b0, b1, c]); };
    const putBox = (b, c) => {
      put(0, b.x0, b.y0, b.y1, b.z0, b.z1, c); put(0, b.x1, b.y0, b.y1, b.z0, b.z1, c);
      put(2, b.z0, b.x0, b.x1, b.y0, b.y1, c); put(2, b.z1, b.x0, b.x1, b.y0, b.y1, c);
      put(1, b.y1, b.x0, b.x1, b.z0, b.z1, c);
    };
    for (const b of list) putBox(b, null);
    const hit = (ax, v, a0, a1, b0, b1, c) => {
      const k = Math.round(v / 0.01);
      for (let d = -1; d <= 1; d++) { const L = planes[ax].get(k + d); if (!L) continue;
        for (const q of L) if (q[5] !== c && Math.abs(q[0] - v) < ZEPS && Math.min(q[2], a1) - Math.max(q[1], a0) > 0.005 && Math.min(q[4], b1) - Math.max(q[3], b0) > 0.005) return true; }
      return false;
    };
    for (const d of dec) {
      if (d.cyl || d.sph || d.torus || d.shape || d.rx || d.ry || d.rz || d.w == null || d._uf) continue;
      let x0 = d.x - d.w / 2, x1 = d.x + d.w / 2, y0 = d.y - d.h / 2, y1 = d.y + d.h / 2, z0 = d.z - d.d / 2, z1 = d.z + d.d / 2;
      const c = d.color || '#fff';
      if (hit(0, x0, y0, y1, z0, z1, c) || hit(0, x1, y0, y1, z0, z1, c) || hit(2, z0, x0, x1, y0, y1, c) || hit(2, z1, x0, x1, y0, y1, c) || hit(1, y1, x0, x1, z0, z1, c)) {
        const e = Math.min(0.01, d.w * 0.2, d.d * 0.2);
        d.w += 2 * e; d.d += 2 * e; d.h += 0.012; d.y += 0.006; d._uf = true;
        x0 -= e; x1 += e; z0 -= e; z1 += e; y1 += 0.012;
      }
      putBox({ x0, x1, y0, y1, z0, z1 }, c);
    }
  }

  // ===================== реализм: фаски, карнизы, контактные тени, мелочи на земле =====================
  // какие грани коробки упираются в соседнюю коробку (там фаску не делаем — была бы щель)
  function computeAttach(list) {
    const idx = new Map();
    const add = (k, e) => { if (!idx.has(k)) idx.set(k, []); idx.get(k).push(e); };
    list.forEach((b, i) => {
      add('x' + Math.round(b.x0 * 50), [i, -1, b.x0, b.y0, b.y1, b.z0, b.z1]); add('x' + Math.round(b.x1 * 50), [i, 1, b.x1, b.y0, b.y1, b.z0, b.z1]);
      add('z' + Math.round(b.z0 * 50), [i, -1, b.z0, b.x0, b.x1, b.y0, b.y1]); add('z' + Math.round(b.z1 * 50), [i, 1, b.z1, b.x0, b.x1, b.y0, b.y1]);
      add('y' + Math.round(b.y1 * 50), [i, 1, b.y1, b.x0, b.x1, b.z0, b.z1]); add('y' + Math.round(b.y0 * 50), [i, -1, b.y0, b.x0, b.x1, b.z0, b.z1]);
    });
    const att = list.map(() => ({}));
    const near = (ax, v) => { const k = Math.round(v * 50), r = []; for (let d = -1; d <= 1; d++) { const L = idx.get(ax + (k + d)); if (L) r.push(...L); } return r; };
    list.forEach((b, i) => {
      const chk = (ax, s, v, a0, a1, c0, c1, key) => {
        for (const q of near(ax, v)) {
          if (q[0] === i || q[1] !== -s || Math.abs(q[2] - v) > 0.02) continue;
          if (Math.min(a1, q[4]) - Math.max(a0, q[3]) > 0.02 && Math.min(c1, q[6]) - Math.max(c0, q[5]) > 0.02) { att[i][key] = true; return; }
        }
        // грань утоплена внутрь другой коробки
        for (const o of list) {
          if (o === b) continue;
          if (ax === 'x' && o.x0 < v - 0.01 && o.x1 > v + 0.01 && o.y0 <= a0 + 0.01 && o.y1 >= Math.min(a1, a0 + 0.6) && o.z0 < c1 && o.z1 > c0 && Math.min(c1, o.z1) - Math.max(c0, o.z0) > 0.3) { att[i][key] = true; return; }
          if (ax === 'z' && o.z0 < v - 0.01 && o.z1 > v + 0.01 && o.y0 <= c0 + 0.01 && o.y1 >= Math.min(c1, c0 + 0.6) && o.x0 < a1 && o.x1 > a0 && Math.min(a1, o.x1) - Math.max(a0, o.x0) > 0.3) { att[i][key] = true; return; }
        }
      };
      chk('x', -1, b.x0, b.y0, b.y1, b.z0, b.z1, 'nx'); chk('x', 1, b.x1, b.y0, b.y1, b.z0, b.z1, 'px');
      chk('z', -1, b.z0, b.x0, b.x1, b.y0, b.y1, 'nz'); chk('z', 1, b.z1, b.x0, b.x1, b.y0, b.y1, 'pz');
      chk('y', 1, b.y1, b.x0, b.x1, b.z0, b.z1, 'py');
    });
    return att;
  }
  const _fv = new THREE.Vector3(), _fa = new THREE.Vector3(), _fb = new THREE.Vector3();
  // многоугольник с нормалью n (веер), мировая развёртка и запечённое затенение как в addBox
  function pushPoly(buf, vs, n, scale, y0, fb) {
    _fa.set(vs[1][0] - vs[0][0], vs[1][1] - vs[0][1], vs[1][2] - vs[0][2]);
    _fb.set(vs[2][0] - vs[0][0], vs[2][1] - vs[0][1], vs[2][2] - vs[0][2]);
    _fv.crossVectors(_fa, _fb);
    if (_fv.x * n[0] + _fv.y * n[1] + _fv.z * n[2] < 0) vs = vs.slice().reverse();
    const base = buf.pos.length / 3, ax = Math.abs(n[0]), ay = Math.abs(n[1]), az = Math.abs(n[2]);
    for (const v of vs) {
      buf.pos.push(v[0], v[1], v[2]); buf.nor.push(n[0], n[1], n[2]);
      let u, w;
      if (fb) {
        const fx = (v[0] - fb.x0) / (fb.x1 - fb.x0), fy = (v[1] - fb.y0) / (fb.y1 - fb.y0), fz = (v[2] - fb.z0) / (fb.z1 - fb.z0);
        if (ay >= ax && ay >= az) { u = fx; w = fz; } else if (ax >= az) { u = fz; w = fy; } else { u = fx; w = fy; }
      } else if (ay >= ax && ay >= az) { u = v[0] / scale; w = v[2] / scale; }
      else if (ax >= az) { u = v[2] / scale; w = v[1] / scale; }
      else { u = v[0] / scale; w = v[1] / scale; }
      buf.uv.push(u, w);
      let ao = 1;
      if (n[1] < -0.5) ao = 0.72;
      else if (n[1] < 0.5 && y0 <= 0.01) ao = v[1] <= 0.01 ? 0.6 : v[1] < 1.2 ? 0.6 + 0.4 * (v[1] / 1.2) : 1;
      buf.col.push(ao, ao, ao);
    }
    for (let i = 1; i < vs.length - 1; i++) buf.idx.push(base, base + i, base + i + 1);
  }
  const S2 = Math.SQRT1_2, S3 = 1 / Math.sqrt(3);
  // коробка с фасками на вертикальных и верхних рёбрах
  function addBoxCh(buf, b, scale, c) {
    const { x0, y0, z0, x1, y1, z1 } = b, yt = y1 - c, fb = b.uv === 'face' ? b : null;
    pushPoly(buf, [[x0 + c, y1, z0 + c], [x1 - c, y1, z0 + c], [x1 - c, y1, z1 - c], [x0 + c, y1, z1 - c]], [0, 1, 0], scale, y0, fb);
    pushPoly(buf, [[x1, y0, z0 + c], [x1, y0, z1 - c], [x1, yt, z1 - c], [x1, yt, z0 + c]], [1, 0, 0], scale, y0, fb);
    pushPoly(buf, [[x0, y0, z0 + c], [x0, y0, z1 - c], [x0, yt, z1 - c], [x0, yt, z0 + c]], [-1, 0, 0], scale, y0, fb);
    pushPoly(buf, [[x0 + c, y0, z1], [x1 - c, y0, z1], [x1 - c, yt, z1], [x0 + c, yt, z1]], [0, 0, 1], scale, y0, fb);
    pushPoly(buf, [[x0 + c, y0, z0], [x1 - c, y0, z0], [x1 - c, yt, z0], [x0 + c, yt, z0]], [0, 0, -1], scale, y0, fb);
    if (y0 > 0.001) pushPoly(buf, [[x0 + c, y0, z0], [x1 - c, y0, z0], [x1, y0, z0 + c], [x1, y0, z1 - c], [x1 - c, y0, z1], [x0 + c, y0, z1], [x0, y0, z1 - c], [x0, y0, z0 + c]], [0, -1, 0], scale, y0, fb);
    // вертикальные фаски
    for (const [sx, sz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
      const X = sx > 0 ? x1 : x0, Z = sz > 0 ? z1 : z0;
      pushPoly(buf, [[X, y0, Z - sz * c], [X - sx * c, y0, Z], [X - sx * c, yt, Z], [X, yt, Z - sz * c]], [sx * S2, 0, sz * S2], scale, y0, fb);
      pushPoly(buf, [[X, yt, Z - sz * c], [X - sx * c, yt, Z], [X - sx * c, y1, Z - sz * c]], [sx * S3, S3, sz * S3], scale, y0, fb);
    }
    // верхние фаски
    pushPoly(buf, [[x1, yt, z0 + c], [x1, yt, z1 - c], [x1 - c, y1, z1 - c], [x1 - c, y1, z0 + c]], [S2, S2, 0], scale, y0, fb);
    pushPoly(buf, [[x0, yt, z0 + c], [x0, yt, z1 - c], [x0 + c, y1, z1 - c], [x0 + c, y1, z0 + c]], [-S2, S2, 0], scale, y0, fb);
    pushPoly(buf, [[x0 + c, yt, z1], [x1 - c, yt, z1], [x1 - c, y1, z1 - c], [x0 + c, y1, z1 - c]], [0, S2, S2], scale, y0, fb);
    pushPoly(buf, [[x0 + c, yt, z0], [x1 - c, yt, z0], [x1 - c, y1, z0 + c], [x0 + c, y1, z0 + c]], [0, S2, -S2], scale, y0, fb);
  }
  const CH_MATS = { wall: 1, stucco: 1, brick: 1, concrete: 1, metal: 1, crate: 1, contRed: 1, contBlue: 1, contGreen: 1, contOrange: 1, corrug: 1, stonewall: 1, hedge: 2 };
  const chamferOf = (b, a) => {
    const k = CH_MATS[b.mat]; if (!k || (b.uv === 'face' && b.mat !== 'crate')) return 0;
    const w = b.x1 - b.x0, d = b.z1 - b.z0, h = b.y1 - b.y0, m = Math.min(w, d, h);
    if (m < 0.1 || (!a.chAll && (m < 0.28 || a.px || a.nx || a.pz || a.nz))) return 0;
    if (b.base) return 0.03;
    return k === 2 ? Math.min(0.16, m * 0.2) : Math.min(0.055, m * 0.07);
  };
  // каменные/бетонные карнизы на высоких стенах
  const CAP = { wall: '#b6a27d', stucco: '#d5c4a2', brick: '#7c776f', concrete: '#a19f98', corrug: '#6d7277' };
  function wallCaps(list, att, out) {
    list.forEach((b, i) => {
      const col = CAP[b.mat], h = b.y1 - b.y0;
      if (!col || h < 1.6 || b.y0 > 0.3 || att[i].py || b.uv === 'face') return;
      const o = b.mat === 'corrug' ? 0.03 : 0.06, t = b.mat === 'corrug' ? 0.06 : 0.12;
      const w = b.x1 - b.x0 + (att[i].nx ? 0 : o) + (att[i].px ? 0 : o), d = b.z1 - b.z0 + (att[i].nz ? 0 : o) + (att[i].pz ? 0 : o);
      const cx = (b.x0 - (att[i].nx ? 0 : o) + b.x1 + (att[i].px ? 0 : o)) / 2, cz = (b.z0 - (att[i].nz ? 0 : o) + b.z1 + (att[i].pz ? 0 : o)) / 2;
      out.push({ w, h: t, d, x: cx, y: b.y1 + t / 2 - 0.001, z: cz, color: col });
      // тонкая полоска тени под карнизом
      if (b.mat !== 'corrug') out.push({ w: w - o * 0.6, h: 0.05, d: d - o * 0.6, x: cx, y: b.y1 - 0.02, z: cz, color: shade(col, 0.72) });
    });
  }
  const shade = (hex, k) => { const c = new THREE.Color(hex).multiplyScalar(k); return '#' + c.getHexString(); };
  // мягкие контактные тени у основания стен и ящиков
  function contactAO(list, att, group) {
    const P = [], C = [], I = [];
    const quad = (pts, al) => { const b = P.length / 3; for (let k = 0; k < 4; k++) { P.push(pts[k][0], 0.05, pts[k][1]); C.push(0, 0, 0, al[k]); } I.push(b, b + 2, b + 1, b, b + 3, b + 2); };
    list.forEach((b, i) => {
      const h = b.y1 - b.y0;
      if (b.y0 > 0.02 || h < 0.3 || b.mat === 'roof') return;
      const A = Math.min(0.5, 0.2 + h * 0.07), W = Math.min(1.1, 0.35 + h * 0.12), a = att[i];
      const { x0, x1, z0, z1 } = b;
      if (!a.pz) quad([[x0, z1], [x1, z1], [x1, z1 + W], [x0, z1 + W]], [A, A, 0, 0]);
      if (!a.nz) quad([[x1, z0], [x0, z0], [x0, z0 - W], [x1, z0 - W]], [A, A, 0, 0]);
      if (!a.px) quad([[x1, z1], [x1, z0], [x1 + W, z0], [x1 + W, z1]], [A, A, 0, 0]);
      if (!a.nx) quad([[x0, z0], [x0, z1], [x0 - W, z1], [x0 - W, z0]], [A, A, 0, 0]);
      // углы
      if (!a.pz && !a.px) quad([[x1, z1], [x1, z1 + W], [x1 + W * 0.8, z1 + W * 0.8], [x1 + W, z1]], [A, 0, 0, 0]);
      if (!a.pz && !a.nx) quad([[x0, z1], [x0 - W, z1], [x0 - W * 0.8, z1 + W * 0.8], [x0, z1 + W]], [A, 0, 0, 0]);
      if (!a.nz && !a.px) quad([[x1, z0], [x1 + W, z0], [x1 + W * 0.8, z0 - W * 0.8], [x1, z0 - W]], [A, 0, 0, 0]);
      if (!a.nz && !a.nx) quad([[x0, z0], [x0, z0 - W], [x0 - W * 0.8, z0 - W * 0.8], [x0 - W, z0]], [A, 0, 0, 0]);
    });
    if (!P.length) return;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(C, 4));
    g.setIndex(I); g.computeBoundingSphere();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
    m.renderOrder = -1; m.matrixAutoUpdate = false;
    group.add(m);
  }
  // пилястры и цоколь на длинных глухих стенах (только визуально, без коллизий)
  const PIER = { wall: { w: 0.75, p: 0.2, base: 'concrete' }, brick: { w: 0.7, p: 0.18, base: 'concrete' }, stucco: { w: 0.6, p: 0.12 }, corrug: { w: 0.16, p: 0.12, mat: 'metal', post: true } };
  function genTrims(list, api, bounds) {
    const out = [];
    const clash = (x0, x1, y0, y1, z0, z1, self) => {
      for (const o of list) if (o !== self && o.x0 < x1 && o.x1 > x0 && o.z0 < z1 && o.z1 > z0 && o.y0 < y1 && o.y1 > y0) return true;
      for (const d of api.decals) { const hw = d.w / 2 + 0.2; if (d.y - d.h / 2 < y1 && d.y + d.h / 2 > y0 && d.x > x0 - hw && d.x < x1 + hw && d.z > z0 - hw && d.z < z1 + hw) return true; }
      for (const a of api.awnings) { const hw = (a.w || 3) / 2 + 0.4; if (a.x > x0 - hw && a.x < x1 + hw && a.z > z0 - hw && a.z < z1 + hw) return true; }
      for (const d of api.decor) { const r = Math.max(d.w || 0, d.d || 0, (d.r || 0) * 2, 0.3) / 2 + 0.15; if (d.x > x0 - r && d.x < x1 + r && d.z > z0 - r && d.z < z1 + r && (d.y || 0) < y1 + 0.3) return true; }
      return false;
    };
    const inB = (x, z) => x > bounds.x0 && x < bounds.x1 && z > bounds.z0 && z < bounds.z1;
    for (const b of list) {
      const P = PIER[b.mat];
      if (!P || b.uv === 'face' || b.y0 > 0.02 || b.hidden || !b.solid) continue;
      const h = b.y1 - b.y0, lx = b.x1 - b.x0, lz = b.z1 - b.z0, alongX = lx >= lz, L = alongX ? lx : lz, T = alongX ? lz : lx;
      if (h < 2.2 || L < 6 || T > 2.6) continue;
      const n = Math.floor(L / (P.post ? 3.2 : 6.2)); if (n < 1) continue;
      const step = L / (n + 1);
      for (const side of [-1, 1]) {
        const face = alongX ? (side < 0 ? b.z0 : b.z1) : (side < 0 ? b.x0 : b.x1);
        const mid = alongX ? (b.x0 + b.x1) / 2 : (b.z0 + b.z1) / 2;
        if (!(alongX ? inB(mid, face + side * 1.2) : inB(face + side * 1.2, mid))) continue;
        const f0 = side > 0 ? face - 0.04 : face - P.p, f1 = side > 0 ? face + P.p : face + 0.04;
        for (let k = 1; k <= n; k++) {
          const c = (alongX ? b.x0 : b.z0) + k * step, a0 = c - P.w / 2, a1 = c + P.w / 2;
          const bx = alongX ? { x0: a0, x1: a1, z0: f0, z1: f1 } : { x0: f0, x1: f1, z0: a0, z1: a1 };
          // проверяем зону перед стеной чуть шире пилястры
          const tz = alongX ? [side > 0 ? face + 0.01 : face - P.p - 0.25, side > 0 ? face + P.p + 0.25 : face - 0.01] : null;
          const tx = alongX ? null : [side > 0 ? face + 0.01 : face - P.p - 0.25, side > 0 ? face + P.p + 0.25 : face - 0.01];
          const cx0 = alongX ? a0 - 0.1 : tx[0], cx1 = alongX ? a1 + 0.1 : tx[1], cz0 = alongX ? tz[0] : a0 - 0.1, cz1 = alongX ? tz[1] : a1 + 0.1;
          if (clash(cx0, cx1, 0, b.y1, cz0, cz1, b)) continue;
          out.push(Object.assign(bx, { y0: 0, y1: b.y1 - (P.post ? 0 : 0.0), mat: P.mat || b.mat, solid: false, hidden: false, uv: 'world', extra: true, back: alongX ? (side > 0 ? 'nz' : 'pz') : (side > 0 ? 'nx' : 'px') }));
        }
        // цоколь
        if (P.base) {
          const t = 0.07, hb = 0.42;
          const g0 = side > 0 ? face - 0.02 : face - t, g1 = side > 0 ? face + t : face + 0.02;
          const lo = alongX ? b.x0 : b.z0, hi = alongX ? b.x1 : b.z1;
          // режем цоколь на участки, где перед стеной ничего нет
          let segStart = null;
          const SEG = 1.0;
          for (let u = lo; u < hi + 1e-6; u += SEG) {
            const u1 = Math.min(hi, u + SEG);
            const cx0 = alongX ? u : (side > 0 ? face + 0.01 : face - 0.3), cx1 = alongX ? u1 : (side > 0 ? face + 0.3 : face - 0.01);
            const cz0 = alongX ? (side > 0 ? face + 0.01 : face - 0.3) : u, cz1 = alongX ? (side > 0 ? face + 0.3 : face - 0.01) : u1;
            const ok = !clash(cx0, cx1, 0, hb + 0.6, cz0, cz1, b) && u1 - u > 0.05;
            if (ok && segStart === null) segStart = u;
            if ((!ok || u1 >= hi - 1e-6) && segStart !== null) {
              const e = ok ? u1 : u;
              if (e - segStart > 0.8) out.push(Object.assign(alongX ? { x0: segStart, x1: e, z0: g0, z1: g1 } : { x0: g0, x1: g1, z0: segStart, z1: e },
                { y0: 0, y1: hb, mat: P.base, solid: false, hidden: false, uv: 'world', extra: true, base: true, back: alongX ? (side > 0 ? 'nz' : 'pz') : (side > 0 ? 'nx' : 'px') }));
              segStart = null;
            }
          }
        }
      }
    }
    return out;
  }

  // мелочи на земле: камешки, сухая трава, мусор, лужи
  let _seed = 1;
  const srnd = (a, b) => { _seed = (_seed * 16807) % 2147483647; return a + (_seed / 2147483647) * (b - a); };
  const SCATTER = {
    dust: { seed: 11, peb: 240, pebCol: ['#a08c6a', '#8f7b5c', '#b7a17c', '#9a8a70'], tuft: 80, tuftCol: ['#b8a45e', '#9f8c4c', '#c4b070'], rubble: 70, rubCol: ['#c9b48c', '#b39d76', '#d8c7a0'] },
    harbor: { seed: 23, peb: 150, pebCol: ['#6c6a66', '#5a5956', '#7c7a74'], tuft: 50, tuftCol: ['#5e6a3c', '#4f5a33', '#6f7a46'], rubble: 60, rubCol: ['#8a5a44', '#6f6f6f', '#9c8c70', '#3d6b8c'], puddle: 16, oil: 10 },
    sakura: { seed: 37, peb: 90, pebCol: ['#8d8a82', '#7b7870', '#a19d93'], tuft: 70, tuftCol: ['#5f7a3a', '#6f8a44', '#4f6a30'], rubble: 0, rubCol: [] },
    range: { seed: 5, peb: 40, pebCol: ['#77736c', '#66635d'], tuft: 20, tuftCol: ['#6a7440', '#596336'], rubble: 15, rubCol: ['#8a8a84', '#9c8c70'] }
  };
  function scatterGround(id, list, bounds, solids) {
    const cfg = SCATTER[id]; if (!cfg) return [];
    _seed = cfg.seed * 7919 + 1;
    const out = [], ground = list.filter(b => b.y0 < 0.02 && b.y1 - b.y0 > 0.3 && b.mat !== 'roof');
    const inside = (x, z, pad) => { for (const b of solids) if (b.y0 < 0.5 && x > b.x0 - pad && x < b.x1 + pad && z > b.z0 - pad && z < b.z1 + pad) return true; return false; };
    const inB = (x, z) => x > bounds.x0 + 0.5 && x < bounds.x1 - 0.5 && z > bounds.z0 + 0.5 && z < bounds.z1 - 0.5;
    // точка у основания случайной стены
    const atWall = () => {
      const b = ground[Math.floor(srnd(0, ground.length))]; if (!b) return null;
      const side = Math.floor(srnd(0, 4)), off = srnd(0.12, 0.7);
      let x, z;
      if (side === 0) { x = srnd(b.x0, b.x1); z = b.z1 + off; } else if (side === 1) { x = srnd(b.x0, b.x1); z = b.z0 - off; }
      else if (side === 2) { z = srnd(b.z0, b.z1); x = b.x1 + off; } else { z = srnd(b.z0, b.z1); x = b.x0 - off; }
      return inB(x, z) && !inside(x, z, 0.08) ? [x, z] : null;
    };
    const free = () => { const x = srnd(bounds.x0, bounds.x1), z = srnd(bounds.z0, bounds.z1); return inB(x, z) && !inside(x, z, 0.15) ? [x, z] : null; };
    const pick = (a) => a[Math.floor(srnd(0, a.length))];
    for (let i = 0; i < cfg.peb; i++) {
      const p = i % 3 ? free() : atWall(); if (!p) continue;
      const n = 1 + Math.floor(srnd(0, 3));
      for (let k = 0; k < n; k++) { const r = srnd(0.035, 0.11); out.push({ sph: true, r, x: p[0] + srnd(-0.25, 0.25), y: r * 0.25, z: p[1] + srnd(-0.25, 0.25), sy: srnd(0.4, 0.7), sx: srnd(0.8, 1.3), color: pick(cfg.pebCol), seg: 5, ry: srnd(0, 3) }); }
    }
    for (let i = 0; i < cfg.tuft; i++) {
      const p = i % 4 ? atWall() : free(); if (!p) continue;
      const col = pick(cfg.tuftCol), n = 4 + Math.floor(srnd(0, 4)), hh = srnd(0.16, 0.34);
      for (let k = 0; k < n; k++) { const an = srnd(0, 6.28), tl = srnd(0.15, 0.5); out.push({ cyl: true, r: 0, r2: 0.022, h: hh * srnd(0.7, 1.15), x: p[0] + Math.cos(an) * 0.05, y: hh * 0.45, z: p[1] + Math.sin(an) * 0.05, color: col, seg: 3, rx: Math.sin(an) * tl, rz: -Math.cos(an) * tl }); }
    }
    for (let i = 0; i < cfg.rubble; i++) {
      const p = atWall(); if (!p) continue;
      const s = srnd(0.06, 0.18);
      out.push({ w: s * srnd(0.8, 1.6), h: s * srnd(0.4, 0.8), d: s * srnd(0.7, 1.3), x: p[0], y: s * 0.25, z: p[1], color: pick(cfg.rubCol), ry: srnd(0, 3.14), rx: srnd(-0.25, 0.25) });
    }
    for (let i = 0; i < (cfg.puddle || 0); i++) {
      const p = free(); if (!p) continue;
      const r = srnd(0.6, 1.6);
      out.push({ cyl: true, r, h: 0.006, x: p[0], y: 0.045, z: p[1], color: '#2f3640', seg: 12, sx: 1, sz: srnd(0.5, 0.9), ry: srnd(0, 3.14), puddle: true });
    }
    for (let i = 0; i < (cfg.oil || 0); i++) {
      const p = free(); if (!p) continue;
      out.push({ cyl: true, r: srnd(0.3, 0.8), h: 0.004, x: p[0], y: 0.043, z: p[1], color: '#1f2226', seg: 9, sz: srnd(0.6, 1), ry: srnd(0, 3.14) });
    }
    return out;
  }

  // вода: дешёвый шейдер с бликами солнца
  function makeWater(env) {
    const W = env.water;
    const sd = new THREE.Vector3(env.sunSprite[0], env.sunSprite[1], env.sunSprite[2]).normalize();
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        t: { value: 0 }, deep: { value: new THREE.Color(W.deep) }, shallow: { value: new THREE.Color(W.shallow) },
        skyc: { value: new THREE.Color(W.sky) }, sunc: { value: new THREE.Color(env.sun) }, sund: { value: sd },
        fogc: { value: new THREE.Color(env.fog) }, fn: { value: env.fogNear * 1.3 }, ff: { value: env.fogFar * 1.6 }
      },
      vertexShader: 'varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
      fragmentShader: [
        'uniform float t; uniform vec3 deep, shallow, skyc, sunc, sund, fogc; uniform float fn, ff; varying vec3 vW;',
        'void main(){',
        ' vec2 p = vW.xz;',
        ' float a1 = p.x*0.31 + t*1.2, a2 = p.y*0.23 - t*0.9, a3 = (p.x+p.y)*0.83 + t*2.0, a4 = (p.x-p.y)*1.27 - t*1.6;',
        ' vec3 n = normalize(vec3(cos(a1)*0.11 + cos(a3)*0.09 + cos(a4)*0.07, 1.0, cos(a2)*0.1 + cos(a3)*0.09 - cos(a4)*0.07));',
        ' vec3 V = normalize(cameraPosition - vW);',
        ' float fres = pow(1.0 - max(dot(n, V), 0.0), 3.0);',
        ' float wv = 0.5 + 0.25*(sin(a3) + sin(a4));',
        ' vec3 col = mix(deep, shallow, wv*0.6);',
        ' col = mix(col, skyc, clamp(fres*1.1, 0.0, 0.85));',
        ' vec3 R = reflect(-V, n);',
        ' float s = pow(max(dot(R, sund), 0.0), 90.0);',
        ' col += sunc * s * 1.6;',
        ' float d = length(vW - cameraPosition);',
        ' col = mix(col, fogc, smoothstep(fn, ff, d));',
        ' gl_FragColor = vec4(col, 1.0);',
        '}'
      ].join('\n'),
      fog: false
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(900, 900, 1, 1), mat);
    m.rotation.x = -HP; m.position.set(W.x0 + 450, W.level, 0);
    m.userData.water = mat;
    return m;
  }

  function buildSky(group, env, bounds) {
    const skyGeo = new THREE.SphereGeometry(320, 32, 16);
    const cols = [], top = new THREE.Color(env.skyTop), hor = new THREE.Color(env.skyHor), low = new THREE.Color(env.skyLow);
    const mid = env.skyMid ? new THREE.Color(env.skyMid) : null;
    const pa = skyGeo.attributes.position;
    const sd = new THREE.Vector3(env.sunSprite[0], 0, env.sunSprite[2]).normalize();
    const glow = new THREE.Color(env.sunSpriteColor);
    for (let i = 0; i < pa.count; i++) {
      const vx = pa.getX(i), vy = pa.getY(i) / 320, vz = pa.getZ(i);
      let c;
      if (vy > 0) {
        if (mid) c = vy < 0.25 ? hor.clone().lerp(mid, vy / 0.25) : mid.clone().lerp(top, Math.pow((vy - 0.25) / 0.75, 0.7));
        else c = hor.clone().lerp(top, Math.pow(vy, 0.6));
      } else c = hor.clone().lerp(low, Math.min(1, -vy * 4));
      // свечение у солнца
      const hl = Math.hypot(vx, vz) || 1;
      const dot = (vx * sd.x + vz * sd.z) / hl;
      const g = Math.pow(Math.max(0, dot), 6) * Math.max(0, 1 - Math.abs(vy) * 2.2);
      c.lerp(glow, g * 0.55);
      cols.push(c.r, c.g, c.b);
    }
    skyGeo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
    const sky = new THREE.Mesh(skyGeo, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false }));
    sky.renderOrder = -2;
    group.add(sky);
    const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: G.tex('dot'), color: env.sunSpriteColor, fog: false, depthWrite: false, transparent: true }));
    sun.position.set(env.sunSprite[0], env.sunSprite[1], env.sunSprite[2]); sun.scale.set(env.sunSize, env.sunSize, 1);
    sun.renderOrder = -1;
    group.add(sun);
    // облака — один меш из повёрнутых к центру квадов
    const n = env.cloudN, pos = [], uv = [], idx = [];
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + Math.random() * 0.3, r = 270, h = 30 + Math.random() * 50;
      const w = 70 + Math.random() * 60, hh = w * 0.32;
      const cx = Math.cos(ang) * r, cz = Math.sin(ang) * r, rx = -Math.sin(ang), rz = Math.cos(ang);
      const b = pos.length / 3;
      pos.push(cx - rx * w / 2, h - hh / 2, cz - rz * w / 2, cx + rx * w / 2, h - hh / 2, cz + rz * w / 2,
        cx + rx * w / 2, h + hh / 2, cz + rz * w / 2, cx - rx * w / 2, h + hh / 2, cz - rz * w / 2);
      uv.push(0, 0, 1, 0, 1, 1, 0, 1);
      idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
    }
    const cg = new THREE.BufferGeometry();
    cg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    cg.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    cg.setIndex(idx);
    const clouds = new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ map: G.tex('cloud'), color: env.clouds, transparent: true, depthWrite: false, fog: false, side: THREE.DoubleSide }));
    clouds.renderOrder = -1;
    const far = [clouds];
    // дальние горы и дюны / город
    if (env.dune || env.mount) far.push(mountains(env));
    else if (!env.noCity) far.push(city(env));
    if (env.fuji) far.push(fuji(env));
    const hi = G.settings.quality === 'high';
    for (const o of far) { o.visible = hi; group.add(o); BACKDROP.push(o); }
  }

  // Фудзи: вогнутый конус со снежной шапкой, в дымке у горизонта
  function fuji(env) {
    const H = 135, R = 215, g = new THREE.ConeGeometry(R, H, 48, 10, true);
    const pa = g.attributes.position, col = [];
    const base = new THREE.Color('#5a7099'), haze = new THREE.Color(env.skyHor), snow = new THREE.Color('#f8f9ff'), shade = new THREE.Color('#b9c4dc');
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i), z = pa.getZ(i), y = pa.getY(i), ang = Math.atan2(z, x);
      const t = Math.min((y + H / 2) / H, 0.94);
      const r = R * Math.pow(1 - t, 1.75) * (1 + 0.025 * Math.sin(ang * 7 + t * 9));
      const hl = Math.hypot(x, z) || 1;
      pa.setXYZ(i, x / hl * r, t * H - 6, z / hl * r);
      const line = 0.7 + 0.06 * Math.sin(ang * 9) + 0.035 * Math.sin(ang * 23 + 1.3);
      let c;
      if (t > line) c = snow.clone().lerp(shade, Math.max(0, Math.sin(ang + 0.6)) * 0.45);
      else c = base.clone().lerp(haze, 0.12 + (1 - t) * 0.38);
      c.lerp(haze, 0.18);
      col.push(c.r, c.g, c.b);
    }
    // освещение «запечено» в цвета: неосвещённый материал не пересвечивает гору
    g.computeVertexNormals();
    const na = g.attributes.normal, L = new THREE.Vector3(env.sunPos[0], env.sunPos[1], env.sunPos[2]).normalize();
    for (let i = 0; i < pa.count; i++) {
      const d = Math.max(0, na.getX(i) * L.x + na.getY(i) * L.y + na.getZ(i) * L.z), k = 0.78 + d * 0.32;
      col[i * 3] = Math.min(1, col[i * 3] * k); col[i * 3 + 1] = Math.min(1, col[i * 3 + 1] * k); col[i * 3 + 2] = Math.min(1, col[i * 3 + 2] * k);
    }
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.translate(env.fuji[0], 0, env.fuji[1]);
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, fog: false }));
    m.matrixAutoUpdate = false; m.renderOrder = -1;
    return m;
  }

  // кольцо гор: низкополигональные конусы с изломанными склонами, дымка к горизонту
  function mountains(env) {
    const pos = [], col = [];
    const base = new THREE.Color(env.mount || '#8a6e50'), haze = new THREE.Color(env.skyHor), rock = new THREE.Color(env.rock || '#6e5a46');
    const ring = (n, r0, r1, h0, h1, hz) => {
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + Math.random() * 0.2, r = r0 + Math.random() * (r1 - r0);
        const h = h0 + Math.random() * (h1 - h0), rad = h * (1.6 + Math.random() * 1.2);
        const g = new THREE.ConeGeometry(rad, h, 7, 3, true);
        const pa = g.attributes.position;
        // одинаковый сдвиг для совпадающих вершин шва (колонка 7 = колонка 0)
        const J = []; for (let k = 0; k < 4 * 7; k++) J.push([1 + (Math.random() - 0.5) * 0.35, (Math.random() - 0.5) * h * 0.12]);
        for (let k = 0; k < pa.count; k++) {
          const row = Math.floor(k / 8), colm = (k % 8) % 7;
          if (row === 0) continue; // вершина
          const jj = J[row * 7 + colm];
          pa.setX(k, pa.getX(k) * jj[0]); pa.setZ(k, pa.getZ(k) * jj[0]); if (row < 3) pa.setY(k, pa.getY(k) + jj[1]);
        }
        const ng = g.toNonIndexed(); g.dispose();
        ng.translate(Math.cos(a) * r, h / 2 - 4, Math.sin(a) * r);
        const p = ng.attributes.position.array;
        for (let k = 0; k < p.length; k += 3) {
          pos.push(p[k], p[k + 1], p[k + 2]);
          const t = G.clamp((p[k + 1] + 4) / (h + 4), 0, 1);
          const c = base.clone().lerp(rock, t * 0.5).lerp(haze, hz - t * 0.1);
          col.push(c.r, c.g, c.b);
        }
        ng.dispose();
      }
    };
    const mh = env.mountH || 1;
    ring(16, 230, 260, 30 * mh, 56 * mh, 0.42);
    ring(22, 150, 175, 9 * mh, 20 * mh, 0.22);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, fog: false, flatShading: true }));
    m.matrixAutoUpdate = false;
    return m;
  }

  // силуэт вечернего города с горящими окнами
  function city(env) {
    const pos = [], nor = [], uv = [], col = [];
    for (let i = 0; i < 42; i++) {
      const side = i % 3, t = (Math.floor(i / 3) + Math.random() * 0.8) / 14;
      const near = Math.random() < 0.4;
      const h = (near ? 14 : 24) + Math.random() * (near ? 16 : 34), w = 10 + Math.random() * 12, d = 10 + Math.random() * 10;
      const dist = near ? 85 + Math.random() * 20 : 120 + Math.random() * 45;
      let x, z;
      if (side === 0) { x = -dist; z = -150 + t * 300; }
      else if (side === 1) { x = -110 + t * 170; z = dist; }
      else { x = -110 + t * 170; z = -dist; }
      const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
      g.translate(x, h / 2 - 1, z);
      const p = g.attributes.position.array, n = g.attributes.normal.array, u = g.attributes.uv.array;
      const ou = Math.random(), ov = Math.random(), sh = 0.7 + Math.random() * 0.35;
      for (let k = 0; k < p.length / 3; k++) {
        const f = Math.floor(k / 6);
        pos.push(p[k * 3], p[k * 3 + 1], p[k * 3 + 2]); nor.push(n[k * 3], n[k * 3 + 1], n[k * 3 + 2]);
        if (f === 2 || f === 3) uv.push(0.004, 0.996);
        else uv.push(u[k * 2] * (f < 2 ? d : w) / 17 + ou, u[k * 2 + 1] * h / 30 + ov);
        const s = f === 0 || f === 4 ? sh : sh * 0.8;
        col.push(s, s * 0.96, s * 1.02);
      }
      g.dispose();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeBoundingSphere();
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map: G.tex('cityWin'), vertexColors: true }));
    m.matrixAutoUpdate = false;
    return m;
  }

  // ---------- наклейки, навесы, пальмы, пятна ----------
  const NRM = { '+x': [1, 0, 0], '-x': [-1, 0, 0], '+z': [0, 0, 1], '-z': [0, 0, -1] };
  function quads() { return { pos: [], nor: [], uv: [], idx: [] }; }
  function quad(q, c, r, u, w, h, uv, n) {
    const b = q.pos.length / 3;
    const hw = w / 2, hh = h / 2;
    const P = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
    for (const [a, bb] of P) { q.pos.push(c[0] + r[0] * a + u[0] * bb, c[1] + r[1] * a + u[1] * bb, c[2] + r[2] * a + u[2] * bb); q.nor.push(n[0], n[1], n[2]); }
    q.uv.push(uv[0], uv[1], uv[2], uv[1], uv[2], uv[3], uv[0], uv[3]);
    q.idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  }
  function qmesh(q, mat) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(q.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(q.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(q.uv, 2));
    g.setIndex(q.idx); g.computeBoundingSphere();
    const m = new THREE.Mesh(g, mat); m.matrixAutoUpdate = false; return m;
  }
  const cellUV = (i) => { const u0 = (i % 4) * 0.25, v1 = 1 - Math.floor(i / 4) * 0.5; return [u0 + 0.002, v1 - 0.5 + 0.002, u0 + 0.248, v1 - 0.002]; };
  function wallQuad(q, d) {
    const n = NRM[d.n], r = [n[2], 0, -n[0]];
    quad(q, [d.x + n[0] * 0.02, d.y, d.z + n[2] * 0.02], r, [0, 1, 0], d.w, d.h, cellUV(d.cell), n);
  }
  // многоугольник крыши с плоской нормалью, повёрнутой вверх
  function poly(q, pts, uvs) {
    const a = pts[0], b = pts[1], c = pts[2];
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    if (ny < 0) { pts = pts.slice().reverse(); uvs = uvs.slice().reverse(); nx = -nx; ny = -ny; nz = -nz; }
    const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    const base = q.pos.length / 3;
    for (let i = 0; i < pts.length; i++) { q.pos.push(pts[i][0], pts[i][1], pts[i][2]); q.nor.push(nx, ny, nz); q.uv.push(uvs[i][0], uvs[i][1]); }
    for (let i = 1; i < pts.length - 1; i++) q.idx.push(base, base + i, base + i + 1);
  }
  function roofGeo(q, r) {
    const g = roofFrame(r), ax = r.alongX;
    const P = (aa, c, y) => ax ? [aa, y, c] : [c, y, aa];
    const T = 2.2, L = Math.hypot(g.hw, g.top - g.ey) / T, { A0, A1, C0, C1, ra0, ra1, cc, ey, top } = g;
    poly(q, [P(A0, C0, ey), P(A1, C0, ey), P(ra1, cc, top), P(ra0, cc, top)], [[A0 / T, 0], [A1 / T, 0], [ra1 / T, L], [ra0 / T, L]]);
    poly(q, [P(A1, C1, ey), P(A0, C1, ey), P(ra0, cc, top), P(ra1, cc, top)], [[A1 / T, 0], [A0 / T, 0], [ra0 / T, L], [ra1 / T, L]]);
    if (r.hip) {
      poly(q, [P(A0, C1, ey), P(A0, C0, ey), P(ra0, cc, top)], [[C1 / T, 0], [C0 / T, 0], [cc / T, L]]);
      poly(q, [P(A1, C0, ey), P(A1, C1, ey), P(ra1, cc, top)], [[C0 / T, 0], [C1 / T, 0], [cc / T, L]]);
    }
  }
  function buildDetails(group, api, def, anim) {
    const dg = {};
    for (const d of api.decals) { const k = d.atlas + (d.lit ? '|lit' : ''); (dg[k] = dg[k] || []).push(d); }
    for (const k in dg) {
      const q = quads(); dg[k].forEach(d => wallQuad(q, d));
      const lit = k.endsWith('|lit'), o = { map: G.tex(k.split('|')[0]), transparent: true, alphaTest: 0.1, polygonOffset: true, polygonOffsetFactor: -2 };
      const m = qmesh(q, lit ? new THREE.MeshBasicMaterial(o) : new THREE.MeshLambertMaterial(o));
      if (!lit) m.receiveShadow = true;
      group.add(m);
    }
    if (api.roofs.length) {
      // все крыши одним мешем: оттенок черепицы — в цвете вершин
      const q = quads(), col = [], c = new THREE.Color();
      for (const r of api.roofs) {
        const n0 = q.pos.length / 3; roofGeo(q, r); c.set(r.col);
        for (let i = n0; i < q.pos.length / 3; i++) col.push(c.r, c.g, c.b);
      }
      const mat = new THREE.MeshLambertMaterial({ map: G.tex('kawara'), vertexColors: true, side: THREE.DoubleSide });
      mat.userData.nm = G.normalTex('kawara'); mat.userData.ns = 1.2; NM.push(mat);
      if (G.settings.quality === 'high') { mat.normalMap = mat.userData.nm; mat.normalScale = new THREE.Vector2(1.2, 1.2); }
      const m = qmesh(q, mat); m.geometry.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      m.castShadow = true; m.receiveShadow = true; group.add(m);
    }
    for (const p of api.ground.filter(g => g.kind === 'pond')) {
      const q = quads();
      quad(q, [p.x, 0.035, p.z], [1, 0, 0], [0, 0, -1], p.w, p.d, [0, 0, p.w / 9, p.d / 9], [0, 1, 0]);
      const t = G.tex('pond').clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping;
      const m = qmesh(q, new THREE.MeshPhongMaterial({ map: t, shininess: 90, specular: 0x8899aa }));
      m.receiveShadow = true; group.add(m);
      if (anim) anim.ponds.push(t);
    }
    if (api.awnings.length) {
      const byCol = {};
      for (const a of api.awnings) (byCol[a.col || 'r'] = byCol[a.col || 'r'] || []).push(a);
      for (const col in byCol) {
        const q = quads();
        for (const a of byCol[col]) {
          const n = NRM[a.n], r = [n[2], 0, -n[0]];
          const slope = 0.42, dz = a.depth * Math.cos(slope), dy = a.depth * Math.sin(slope);
          const c = [a.x + n[0] * dz / 2, a.y - dy / 2, a.z + n[2] * dz / 2];
          const up = [n[0] * Math.cos(slope) * -1, Math.sin(slope), n[2] * Math.cos(slope) * -1];
          const len = Math.hypot(...up); up[0] /= len; up[1] /= len; up[2] /= len;
          const nn = [n[0] * Math.sin(slope), Math.cos(slope), n[2] * Math.sin(slope)];
          quad(q, c, r, up, a.w, a.depth, [0, 0, a.w / 2, 1], nn);
          a.supports = true;
        }
        const t = G.tex('awning', col === 'r' ? '#b0392b' : col).clone(); t.needsUpdate = true; t.wrapS = THREE.RepeatWrapping;
        const m = qmesh(q, new THREE.MeshLambertMaterial({ map: t, side: THREE.DoubleSide }));
        m.castShadow = true; m.receiveShadow = true; group.add(m);
      }
    }
    if (api.fronds.length) {
      const q = quads();
      for (const p of api.fronds) {
        for (let i = 0; i < p.n; i++) {
          const a = i / p.n * Math.PI * 2 + Math.random() * 0.3, dx = Math.cos(a), dz = Math.sin(a);
          const r = [-dz, 0, dx];
          // две части листа: вверх-наружу и вниз
          const l1 = 1.6, l2 = 1.7, up1 = 0.35, dn2 = -0.9;
          const c1 = [p.x + dx * l1 / 2, p.y + up1 / 2, p.z + dz * l1 / 2];
          const u1 = [dx, up1 / l1, dz]; const n1 = Math.hypot(...u1); u1[0] /= n1; u1[1] /= n1; u1[2] /= n1;
          quad(q, c1, r, u1, 0.75, l1 * 1.02, [0, 0, 1, 0.5], [0, 1, 0]);
          const c2 = [p.x + dx * (l1 + l2 / 2 * 0.8), p.y + up1 + dn2 / 2, p.z + dz * (l1 + l2 / 2 * 0.8)];
          const u2 = [dx * 0.8, dn2 / l2, dz * 0.8]; const n2 = Math.hypot(...u2); u2[0] /= n2; u2[1] /= n2; u2[2] /= n2;
          quad(q, c2, r, u2, 0.75, l2, [0, 0.5, 1, 1], [0, 1, 0]);
        }
      }
      const tex = G.tex('palm');
      // текстура листа лежит горизонтально: u — вдоль листа, v — поперёк
      for (let i = 0; i < q.uv.length; i += 2) { const t = q.uv[i]; q.uv[i] = q.uv[i + 1]; q.uv[i + 1] = t; }
      const m = qmesh(q, new THREE.MeshLambertMaterial({ map: tex, alphaTest: 0.35, side: THREE.DoubleSide }));
      m.castShadow = true; group.add(m);
    }
    for (const kind of ['stain', 'pool', 'petals']) {
      const list = api.ground.filter(g => g.kind === kind);
      if (!list.length) continue;
      const q = quads();
      for (const g of list) quad(q, [g.x, kind === 'pool' ? 0.025 : kind === 'petals' ? 0.03 : 0.018, g.z], [1, 0, 0], [0, 0, -1], g.sz, g.sz, [0, 0, 1, 1], [0, 1, 0]);
      const mat = kind === 'pool'
        ? new THREE.MeshBasicMaterial({ map: G.tex('pool'), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })
        : new THREE.MeshLambertMaterial({ map: G.tex(kind), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
      group.add(qmesh(q, mat));
    }
  }

  // ---------- активная карта ----------
  const map = G.map = {
    id: null, def: null, boxes: [], solids: [], bounds: null, spawnZones: null, sites: null, groups: {}, built: {},
    // построить (один раз) и сделать активной
    load(id, scene) {
      const def = G.MAPS[id] || G.MAPS.dust;
      if (!this.built[id]) this.built[id] = this.build(id, def, scene);
      const data = this.built[id];
      for (const k in this.built) this.built[k].group.visible = (k === id);
      this.id = id; this.def = def; this.boxes = data.boxes; this.solids = data.solids;
      this.bounds = data.bounds; this.spawnZones = data.spawnZones; this.sites = data.sites;
      this.water = data.water;
      this.lampSprites = data.lampSprites;
      this.anim = data.anim;
      return data;
    },
    build(id, def, scene) {
      const sc = def.scale || 1;
      const api = makeApi(sc);
      def.layout(api); G.map._api = api;
      const R = (r) => ({ x0: r.x0 * sc, x1: r.x1 * sc, z0: r.z0 * sc, z1: r.z1 * sc });
      const bounds = R(def.bounds), sites = {}, spawnZones = def.spawnZones.map(z => Object.assign(R(z), { yaw: z.yaw }));
      for (const k in def.sites) sites[k] = R(def.sites[k]);
      const env = Object.assign({}, def.env);
      if (env.water) env.water = Object.assign({}, env.water, { x0: env.water.x0 * sc });
      const boxes = api.boxes, solids = boxes.filter(b => b.solid);
      // сервер: только геометрия столкновений, без графики
      if (G.HEADLESS) return { group: { visible: false }, boxes, solids, bounds, spawnZones, sites, water: null, lampSprites: null, anim: null };
      const group = new THREE.Group();
      const bufs = {};
      const vis = boxes.filter(b => !b.hidden && b.mat !== 'none');
      const trims = genTrims(vis, api, R(def.bounds));
      const rboxes = deZFight(vis.concat(trims));
      const att = computeAttach(rboxes.slice(0, vis.length)).concat(rboxes.slice(vis.length).map(b => ({ [b.back]: true, chAll: true })));
      let nCh = 0;
      rboxes.forEach((b, i) => {
        const k = b.mat;
        if (!bufs[k]) bufs[k] = { pos: [], nor: [], uv: [], col: [], idx: [] };
        const c = b.y1 - b.y0 < 0.05 ? 0 : chamferOf(b, att[i]);
        const c0 = bufs[k].col.length;
        if (c > 0.005) { addBoxCh(bufs[k], b, def.matScale[k] || 3, c); nCh++; } else addBox(bufs[k], b, def.matScale[k] || 3);
        if (b.extra && !b.base) { const col = bufs[k].col; for (let q = c0; q < col.length; q++) col[q] *= 0.9; }
      });
      unflushDecor(api.decor, rboxes); G.map._rboxes = rboxes; G.map._nCh = nCh; G.map._nTrim = trims.length;
      const nd0 = api.decor.length; wallCaps(rboxes, att, api.decor); G.map._nCaps = api.decor.length - nd0;
      contactAO(rboxes, att, group);
      const scat = scatterGround(id, rboxes, R(def.bounds), solids);
      for (const k in bufs) {
        const bf = bufs[k], geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(bf.pos, 3));
        geo.setAttribute('normal', new THREE.Float32BufferAttribute(bf.nor, 3));
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(bf.uv, 2));
        geo.setAttribute('color', new THREE.Float32BufferAttribute(bf.col, 3));
        geo.setIndex(bf.idx);
        geo.computeBoundingSphere();
        const m = new THREE.Mesh(geo, getMat(k));
        m.castShadow = true; m.receiveShadow = true; m.matrixAutoUpdate = false;
        group.add(m);
      }
      // земля
      const gm = lam(def.ground.mat, null, 0.9);
      gm.vertexColors = false;
      const gtex = gm.map.clone(); gtex.needsUpdate = true; gm.map = gtex;
      const gnm = gm.userData.nm.clone(); gnm.needsUpdate = true; gm.userData.nm = gnm; if (gm.normalMap) gm.normalMap = gnm;
      const gsz = [def.ground.size[0] * sc, def.ground.size[1] * sc];
      for (const t of [gtex, gnm]) t.repeat.set(gsz[0] / def.ground.repeat, gsz[1] / def.ground.repeat);
      // крупные пятна на земле — ломают повтор текстуры
      const gg = new THREE.PlaneGeometry(gsz[0], gsz[1], Math.ceil(gsz[0] / 2.2), Math.ceil(gsz[1] / 2.2));
      { const pa = gg.attributes.position.array, col = new Float32Array(pa.length);
        for (let i = 0; i < pa.length; i += 3) {
          const x = pa[i], y = pa[i + 1];
          const n1 = Math.sin(x * 0.11 + 1.7) * Math.cos(y * 0.093 - 0.6) + Math.sin(x * 0.047 - y * 0.061 + 2.1);
          const n2 = Math.sin(x * 0.31 + y * 0.27) * Math.cos(x * 0.23 - y * 0.35);
          const v = 0.95 + n1 * 0.035 + n2 * 0.02;
          col[i] = v * (1 + n2 * 0.015); col[i + 1] = v; col[i + 2] = v * (1 - n2 * 0.02);
        }
        gg.setAttribute('color', new THREE.BufferAttribute(col, 3)); }
      gm.vertexColors = true;
      const ground = new THREE.Mesh(gg, gm);
      gm.polygonOffset = true; gm.polygonOffsetFactor = 1; gm.polygonOffsetUnits = 2; // земля всегда «под» наклейками
      ground.rotation.x = -HP; ground.receiveShadow = true; ground.updateMatrix(); ground.matrixAutoUpdate = false;
      group.add(ground);
      // декор
      if (api.decor.length) {
        const dm = new THREE.Mesh(G.geo.build(api.decor), G.getVCMat());
        dm.castShadow = true; dm.receiveShadow = true; dm.matrixAutoUpdate = false;
        group.add(dm);
      }
      // мелочи на земле (без отбрасывания теней — дёшево)
      if (scat.length) {
        const pud = scat.filter(p => p.puddle), rest = scat.filter(p => !p.puddle);
        if (rest.length) { const sm = new THREE.Mesh(G.geo.build(rest), G.getVCMat()); sm.receiveShadow = true; sm.matrixAutoUpdate = false; group.add(sm); }
        if (pud.length) {
          const pm = new THREE.Mesh(G.geo.build(pud), new THREE.MeshPhongMaterial({ vertexColors: true, shininess: 90, specular: 0x8a8f99, transparent: true, opacity: 0.78, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
          pm.receiveShadow = true; pm.matrixAutoUpdate = false; group.add(pm);
        }
      }
      // кроны сакуры: фактура цветков, неровный силуэт
      if (api.blossoms.length) {
        const bg = G.geo.buildUV(api.blossoms, 0.55), pa = bg.attributes.position.array, na = bg.attributes.normal.array;
        for (let i = 0; i < pa.length; i += 3) {
          const h = Math.sin(pa[i] * 3.1 + pa[i + 1] * 5.7 + pa[i + 2] * 2.3) * Math.cos(pa[i] * 1.7 - pa[i + 2] * 4.1 + pa[i + 1]);
          const o = h * 0.28;
          pa[i] += na[i] * o; pa[i + 1] += na[i + 1] * o; pa[i + 2] += na[i + 2] * o;
        }
        bg.computeBoundingSphere();
        const bm = new THREE.Mesh(bg, new THREE.MeshLambertMaterial({ map: G.tex('blossom'), vertexColors: true }));
        bm.castShadow = true; bm.receiveShadow = true; bm.matrixAutoUpdate = false;
        group.add(bm);
      }
      // нарисованные буквы точек
      for (const L of api.letters) {
        const p = new THREE.Mesh(new THREE.PlaneGeometry(L.size, L.size), new THREE.MeshLambertMaterial({ map: G.T.letter(L.ch), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
        p.rotation.set(-HP, 0, L.rotY); p.position.set(L.x, 0.04, L.z); p.receiveShadow = true;
        group.add(p);
      }
      const anim = { gulls: [], foam: null, ponds: [], petals: null };
      buildDetails(group, api, def, anim);
      // огни фонарей
      // свечение фонарей: одни точки с размером на вершину — один вызов отрисовки на все огни
      const lampSprites = [];
      if (api.lamps.length) {
        const n = api.lamps.length, lp = new Float32Array(n * 3), ls = new Float32Array(n);
        api.lamps.forEach((l, i) => { lp[i * 3] = l[0]; lp[i * 3 + 1] = l[1]; lp[i * 3 + 2] = l[2]; ls[i] = l[3] || 1.8; });
        const lg = new THREE.BufferGeometry();
        lg.setAttribute('position', new THREE.BufferAttribute(lp, 3)); lg.setAttribute('size', new THREE.BufferAttribute(ls, 1));
        lg.computeBoundingSphere();
        const lm = new THREE.ShaderMaterial({
          uniforms: { map: { value: G.tex('lampGlow') }, scale: { value: 500 } },
          vertexShader: 'attribute float size; uniform float scale; void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = size * scale / max(0.2, -mv.z); gl_Position = projectionMatrix * mv; }',
          fragmentShader: 'uniform sampler2D map; void main(){ gl_FragColor = texture2D(map, gl_PointCoord); }',
          transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
        });
        const lpts = new THREE.Points(lg, lm);
        const dbs = new THREE.Vector2();
        lpts.onBeforeRender = (r, sc2, cam) => { r.getDrawingBufferSize(dbs); lm.uniforms.scale.value = dbs.y / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov || 60) / 2)); };
        group.add(lpts); lampSprites.push(lpts);
      }
      buildSky(group, def.env, def.bounds);
      let water = null;
      // падающие лепестки сакуры
      const ptrees = api.trees.filter(t => t.petals);
      if (ptrees.length) {
        const N = G.settings.quality === 'low' ? 140 : 320, pos = new Float32Array(N * 3), ph = new Float32Array(N), sp = new Float32Array(N);
        const spawn = (i, any) => {
          const t = ptrees[(Math.random() * ptrees.length) | 0], a = Math.random() * 6.28, rr = Math.sqrt(Math.random()) * t.r;
          pos[i * 3] = t.x + Math.cos(a) * rr; pos[i * 3 + 1] = any ? Math.random() * (t.y + 1) : t.y + Math.random() * 1.4; pos[i * 3 + 2] = t.z + Math.sin(a) * rr;
          ph[i] = Math.random() * 6.28; sp[i] = 0.35 + Math.random() * 0.45;
        };
        for (let i = 0; i < N; i++) spawn(i, true);
        const pg = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); attr.setUsage(THREE.DynamicDrawUsage);
        pg.setAttribute('position', attr);
        const pts = new THREE.Points(pg, new THREE.PointsMaterial({ map: G.tex('petal'), size: 0.28, sizeAttenuation: true, transparent: true, alphaTest: 0.3, depthWrite: false, color: '#ffe3ec' }));
        pts.frustumCulled = false; group.add(pts);
        anim.petals = { pos, ph, sp, spawn, attr, n: N };
      }
      // снегопад над всей площадью (те же «лепестки», только белые и медленные)
      if (api.snowfall) {
        const bd = R(def.bounds), N = G.settings.quality === 'low' ? 260 : 600, pos = new Float32Array(N * 3), ph = new Float32Array(N), sp = new Float32Array(N);
        const spawn = (i, any) => {
          pos[i * 3] = bd.x0 + Math.random() * (bd.x1 - bd.x0); pos[i * 3 + 2] = bd.z0 + Math.random() * (bd.z1 - bd.z0);
          pos[i * 3 + 1] = any ? Math.random() * 14 : 12 + Math.random() * 3;
          ph[i] = Math.random() * 6.28; sp[i] = 0.7 + Math.random() * 0.8;
        };
        for (let i = 0; i < N; i++) spawn(i, true);
        const pg = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); attr.setUsage(THREE.DynamicDrawUsage);
        pg.setAttribute('position', attr);
        const pts = new THREE.Points(pg, new THREE.PointsMaterial({ map: G.tex('dot'), size: 0.13, sizeAttenuation: true, transparent: true, depthWrite: false, color: '#ffffff', opacity: 0.9 }));
        pts.frustumCulled = false; group.add(pts);
        anim.petals = { pos, ph, sp, spawn, attr, n: N, snow: true };
      }
      if (env.water) {
        const W = env.water;
        water = makeWater(env); group.add(water);
        // пена у стенки причала
        const fq = quads();
        quad(fq, [W.x0 + 0.7 * sc + 0.75, W.level + 0.04, 0], [0, 0, 1], [1, 0, 0], 190, 1.5, [0, 0, 40, 1], [0, 1, 0]);
        const ft = G.tex('foam').clone(); ft.needsUpdate = true;
        anim.foam = new THREE.MeshBasicMaterial({ map: ft, transparent: true, depthWrite: false, opacity: 0.7, color: '#fff3e8' });
        group.add(qmesh(fq, anim.foam));
      }
      // чайки над водой
      if (api.gulls) {
        const gm = new THREE.SpriteMaterial({ map: G.tex('gull'), color: '#fff0e4', transparent: true, depthWrite: false });
        for (let i = 0; i < api.gulls; i++) {
          const s = new THREE.Sprite(gm);
          s.userData = { cx: (50 + Math.random() * 26) * sc, cz: (-30 + Math.random() * 60) * sc, r: 6 + Math.random() * 12, h: 9 + Math.random() * 10,
            sp: (0.18 + Math.random() * 0.2) * (Math.random() < 0.5 ? -1 : 1), ph: Math.random() * 6.28, sz: 2.6 + Math.random() * 1.0 };
          group.add(s); anim.gulls.push(s);
        }
      }
      group.visible = false;
      scene.add(group);
      return { group, boxes, solids, water, lampSprites, anim, bounds, sites, spawnZones };
    },
    update(dt, time) {
      if (this.water) this.water.userData.water.uniforms.t.value = time;
      const an = this.anim;
      if (!an) return;
      if (an.petals) {
        const P = an.petals, p = P.pos, w = Math.sin(time * 0.23) * 0.4 + 0.6, k0 = P.snow ? 0.35 : 1;
        for (let i = 0; i < P.n; i++) {
          const k = i * 3, f = P.ph[i];
          p[k + 1] -= P.sp[i] * dt;
          p[k] += (w * 0.7 + Math.sin(time * 1.6 + f) * 0.55) * dt * k0;
          p[k + 2] += (0.25 + Math.cos(time * 1.2 + f * 1.7) * 0.5) * dt * k0;
          if (p[k + 1] < 0.04) P.spawn(i, false);
        }
        P.attr.needsUpdate = true;
      }
      for (const t of an.ponds) { t.offset.x = Math.sin(time * 0.11) * 0.02; t.offset.y = Math.cos(time * 0.09) * 0.02; }
      if (an.foam) { an.foam.map.offset.x = time * 0.025; an.foam.map.offset.y = Math.sin(time * 0.8) * 0.08; an.foam.opacity = 0.55 + 0.18 * Math.sin(time * 1.3); }
      for (let i = 0; i < an.gulls.length; i++) {
        const s = an.gulls[i], u = s.userData, a = u.ph + time * u.sp;
        s.position.set(u.cx + Math.cos(a) * u.r, u.h + Math.sin(time * 0.6 + u.ph) * 1.4, u.cz + Math.sin(a) * u.r);
        const f = Math.sin(time * (u.sp > 0 ? 8 : 9) + u.ph * 3);
        s.scale.set(u.sz, u.sz * 0.5 * (0.3 + 0.7 * Math.abs(f)), 1);
      }
    },
    inSite(x, z) {
      for (const k in this.sites) { const s = this.sites[k]; if (x > s.x0 && x < s.x1 && z > s.z0 && z < s.z1) return k; }
      return null;
    },

    ray(ox, oy, oz, dx, dy, dz, maxT) {
      const solids = this.solids;
      let best = maxT, hit = false, bnx = 0, bny = 0, bnz = 0;
      if (dy < -1e-6) {
        const t = -oy / dy;
        if (t > 0 && t < best) { best = t; hit = true; bnx = 0; bny = 1; bnz = 0; }
      }
      const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        let tmin = 0, tmax = best, nx = 0, ny = 0, nz = 0, t1, t2;
        if (Math.abs(dx) < 1e-9) { if (ox < b.x0 || ox > b.x1) continue; }
        else {
          t1 = (b.x0 - ox) * ix; t2 = (b.x1 - ox) * ix;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = dx > 0 ? -1 : 1; ny = 0; nz = 0; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (Math.abs(dy) < 1e-9) { if (oy < b.y0 || oy > b.y1) continue; }
        else {
          t1 = (b.y0 - oy) * iy; t2 = (b.y1 - oy) * iy;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = 0; ny = dy > 0 ? -1 : 1; nz = 0; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (Math.abs(dz) < 1e-9) { if (oz < b.z0 || oz > b.z1) continue; }
        else {
          t1 = (b.z0 - oz) * iz; t2 = (b.z1 - oz) * iz;
          if (t1 > t2) { const tt = t1; t1 = t2; t2 = tt; }
          if (t1 > tmin) { tmin = t1; nx = 0; ny = 0; nz = dz > 0 ? -1 : 1; }
          if (t2 < tmax) tmax = t2;
          if (tmin > tmax) continue;
        }
        if (tmin < best) { best = tmin; hit = true; bnx = nx; bny = ny; bnz = nz; }
      }
      return hit ? { t: best, nx: bnx, ny: bny, nz: bnz } : null;
    },
    clear(ax, ay, az, bx, by, bz) {
      const dx = bx - ax, dy = by - ay, dz = bz - az;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d < 0.01) return true;
      const h = this.ray(ax, ay, az, dx / d, dy / d, dz / d, d);
      return !h || h.t >= d - 0.05;
    },
    move(a, dx, dy, dz) {
      const solids = this.solids, r = a.radius, h = a.height, step = 0.42, p = a.pos;
      const prevY = p.y;
      p.x += dx;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (b.y1 - p.y <= step && a.onGround) continue;
        if (dx > 0) p.x = b.x0 - r - 1e-4; else if (dx < 0) p.x = b.x1 + r + 1e-4;
      }
      p.z += dz;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.y + h <= b.y0 || p.y >= b.y1) continue;
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (b.y1 - p.y <= step && a.onGround) continue;
        if (dz > 0) p.z = b.z0 - r - 1e-4; else if (dz < 0) p.z = b.z1 + r + 1e-4;
      }
      p.y += dy;
      a.onGround = false;
      if (p.y <= 0) { p.y = 0; if (a.vel.y < 0) a.vel.y = 0; a.onGround = true; }
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (p.x + r <= b.x0 || p.x - r >= b.x1) continue;
        if (p.z + r <= b.z0 || p.z - r >= b.z1) continue;
        if (p.y + h <= b.y0 || p.y >= b.y1) {
          if (Math.abs(p.y - b.y1) < 0.02 && a.vel.y <= 0) a.onGround = true;
          continue;
        }
        if (prevY >= b.y1 - step && a.vel.y <= 0.01) { p.y = b.y1; a.vel.y = 0; a.onGround = true; }
        else if (dy > 0) { p.y = b.y0 - h - 1e-3; a.vel.y = 0; }
        else { p.y = Math.max(p.y, b.y1); a.vel.y = 0; a.onGround = true; }
      }
      const bd = this.bounds;
      p.x = G.clamp(p.x, bd.x0 + r, bd.x1 - r);
      p.z = G.clamp(p.z, bd.z0 + r, bd.z1 - r);
    },
    blocked(x, z, r, maxY) {
      maxY = maxY == null ? 1.7 : maxY;
      const solids = this.solids;
      for (let i = 0; i < solids.length; i++) {
        const b = solids[i];
        if (b.y0 > maxY || b.y1 < 0.3) continue;
        if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r) return true;
      }
      const bd = this.bounds;
      return x < bd.x0 + r || x > bd.x1 - r || z < bd.z0 + r || z > bd.z1 - r;
    }
  };
})(window.G);
