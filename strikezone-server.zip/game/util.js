'use strict';
/* Общие утилиты, настройки, сборка геометрии из примитивов (коробки, цилиндры, профили, торы) */
window.G = window.G || {};
(function (G) {
  G.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  G.lerp = (a, b, t) => a + (b - a) * t;
  G.rand = (a, b) => a + Math.random() * (b - a);
  G.randi = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
  G.pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  G.shuffle = (arr) => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };
  G.angleDiff = (a, b) => {
    let d = b - a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return d;
  };
  G.damp = (k, dt) => 1 - Math.exp(-k * dt);
  // шина событий: в одиночной игре ничего не делает, на сервере собирает события для рассылки игрокам
  G.emit = G.emit || function () { };
  G.esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  G.store = {
    get(k, def) {
      try {
        const v = localStorage.getItem('sz_' + k);
        return v == null ? def : JSON.parse(v);
      } catch (e) { return def; }
    },
    set(k, v) {
      try { localStorage.setItem('sz_' + k, JSON.stringify(v)); } catch (e) { /* хранилище недоступно */ }
    },
    remove(k) { try { localStorage.removeItem('sz_' + k); } catch (e) { } }
  };

  const defaults = {
    nick: 'Игрок', sens: 1.0, quality: 'medium', volume: 0.8, autofire: false, res: 1, chat: true,
    difficulty: 'normal', mode: 'tdm', teamSize: 5, primary: 'ar', leftFire: true, fov: 64,
    map: 'dust', showFps: false, btnOpacity: 0.85, layout: null
  };
  G.settings = Object.assign({}, defaults, G.store.get('settings', {}));
  G.saveSettings = () => G.store.set('settings', G.settings);
  // статистика текущего профиля (ключ меняется при смене профиля)
  G.loadStats = (key) => {
    G.statsKey = key;
    G.stats = Object.assign({ kills: 0, deaths: 0, matches: 0, wins: 0, hs: 0, xp: 0, shots: 0, hits: 0, best: 0, time: 0, wk: {} }, G.store.get(key, {}));
  };
  G.loadStats('stats');
  G.saveStats = () => G.store.set(G.statsKey, G.stats);
  G.level = () => {
    const xp = G.stats.xp || 0;
    const lvl = Math.floor(Math.sqrt(xp / 120)) + 1;
    const cur = (lvl - 1) * (lvl - 1) * 120, next = lvl * lvl * 120;
    return { lvl, frac: (xp - cur) / (next - cur) };
  };

  G.isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

  /* ---------- Геометрия ---------- */
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(),
    _s = new THREE.Vector3(1, 1, 1), _p = new THREE.Vector3(), _c = new THREE.Color();

  // путь профиля: [x,y] — линия; ['q',cx,cy,x,y] — квадратичная кривая; ['c',…] — кубическая
  function tracePath(p, pts) {
    let first = true;
    for (const q of pts) {
      if (typeof q[0] === 'string') {
        if (q[0] === 'q') p.quadraticCurveTo(q[1], q[2], q[3], q[4]);
        else if (q[0] === 'c') p.bezierCurveTo(q[1], q[2], q[3], q[4], q[5], q[6]);
      } else if (first) { p.moveTo(q[0], q[1]); first = false; }
      else p.lineTo(q[0], q[1]);
    }
  }
  // коробка со скошенными рёбрами (фаска ловит свет — деталь выглядит как настоящая, а не как кубик)
  function chamferBox(w, h, d, c) {
    const hx = w / 2, hy = h / 2, hz = d / 2, P = {};
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) {
      P[sx + ',' + sy + ',' + sz] = {
        x: [sx * hx, sy * (hy - c), sz * (hz - c)], y: [sx * (hx - c), sy * hy, sz * (hz - c)], z: [sx * (hx - c), sy * (hy - c), sz * hz]
      };
    }
    const pos = [], edge = [];
    const tri = (a, b, c2, e) => {
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c2[0] - a[0], vy = c2[1] - a[1], vz = c2[2] - a[2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const cx = a[0] + b[0] + c2[0], cy = a[1] + b[1] + c2[1], cz = a[2] + b[2] + c2[2];
      if (nx * cx + ny * cy + nz * cz < 0) pos.push(...a, ...c2, ...b); else pos.push(...a, ...b, ...c2);
      edge.push(e, e, e);
    };
    const quad = (a, b, c2, d2, e) => { tri(a, b, c2, e); tri(a, c2, d2, e); };
    const k = (x, y, z) => P[x + ',' + y + ',' + z];
    // грани
    for (const s of [-1, 1]) {
      quad(k(s, -1, -1).x, k(s, 1, -1).x, k(s, 1, 1).x, k(s, -1, 1).x, 0);
      quad(k(-1, s, -1).y, k(1, s, -1).y, k(1, s, 1).y, k(-1, s, 1).y, 0);
      quad(k(-1, -1, s).z, k(1, -1, s).z, k(1, 1, s).z, k(-1, 1, s).z, 0);
    }
    // фаски вдоль рёбер
    for (const a of [-1, 1]) for (const b of [-1, 1]) {
      quad(k(a, b, -1).x, k(a, b, 1).x, k(a, b, 1).y, k(a, b, -1).y, 1);   // вдоль Z
      quad(k(a, -1, b).x, k(a, 1, b).x, k(a, 1, b).z, k(a, -1, b).z, 1);   // вдоль Y
      quad(k(-1, a, b).y, k(1, a, b).y, k(1, a, b).z, k(-1, a, b).z, 1);   // вдоль X
    }
    // уголки
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) { const q = k(sx, sy, sz); tri(q.x, q.y, q.z, 1); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.computeVertexNormals();
    g.setAttribute('edge', new THREE.Float32BufferAttribute(edge, 1));
    return g;
  }
  // сглаживание нормалей по углу излома: изогнутые поверхности гладкие, острые рёбра остаются острыми
  function creaseNormals(g, deg) {
    const pa = g.attributes.position.array, nt = pa.length / 9, fn = new Float32Array(nt * 3);
    for (let t = 0; t < nt; t++) {
      const o = t * 9;
      const ux = pa[o + 3] - pa[o], uy = pa[o + 4] - pa[o + 1], uz = pa[o + 5] - pa[o + 2];
      const vx = pa[o + 6] - pa[o], vy = pa[o + 7] - pa[o + 1], vz = pa[o + 8] - pa[o + 2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const l = Math.hypot(nx, ny, nz) || 1; fn[t * 3] = nx / l; fn[t * 3 + 1] = ny / l; fn[t * 3 + 2] = nz / l;
    }
    const groups = new Map(), key = (i) => Math.round(pa[i * 3] * 2e4) + '_' + Math.round(pa[i * 3 + 1] * 2e4) + '_' + Math.round(pa[i * 3 + 2] * 2e4);
    const nv = pa.length / 3, keys = new Array(nv);
    for (let i = 0; i < nv; i++) { const k = keys[i] = key(i); let a = groups.get(k); if (!a) groups.set(k, a = []); a.push(i); }
    const cosT = Math.cos(deg * Math.PI / 180), out = new Float32Array(pa.length);
    for (let i = 0; i < nv; i++) {
      const f = (i / 3) | 0, ax = fn[f * 3], ay = fn[f * 3 + 1], az = fn[f * 3 + 2];
      let sx = 0, sy = 0, sz = 0;
      for (const j of groups.get(keys[i])) {
        const fj = (j / 3) | 0, bx = fn[fj * 3], by = fn[fj * 3 + 1], bz = fn[fj * 3 + 2];
        if (ax * bx + ay * by + az * bz >= cosT) { sx += bx; sy += by; sz += bz; }
      }
      const l = Math.hypot(sx, sy, sz) || 1; out[i * 3] = sx / l; out[i * 3 + 1] = sy / l; out[i * 3 + 2] = sz / l;
    }
    g.setAttribute('normal', new THREE.Float32BufferAttribute(out, 3));
  }
  // фаски профиля (выдавленной детали): грани под углом к оси выдавливания
  function markBevel(g) {
    const na = g.attributes.normal.array, n = na.length / 3, e = new Float32Array(n);
    for (let t = 0; t < n; t += 3) {
      const z = Math.abs(na[t * 3 + 2] + na[t * 3 + 5] + na[t * 3 + 8]) / 3;
      const v = z > 0.15 && z < 0.97 ? 1 : 0; e[t] = e[t + 1] = e[t + 2] = v;
    }
    g.setAttribute('edge', new THREE.BufferAttribute(e, 1));
  }
  let HQ = false; // качественная геометрия: для оружия в руках и витрины

  // создать трансформированную неиндексированную геометрию одной детали
  function partGeo(pt) {
    let g;
    if (HQ && !pt.shape && !pt.cyl && !pt.torus && !pt.sph && !pt.flat) {
      const mn = Math.min(pt.w, pt.h, pt.d);
      if (mn >= 0.0055) g = chamferBox(pt.w, pt.h, pt.d, Math.min(0.0032, mn * 0.2));
    }
    if (g) { /* фаска уже готова */ }
    else if (pt.shape) {
      const sh = new THREE.Shape();
      tracePath(sh, pt.pts);
      if (pt.holes) for (const h of pt.holes) { const hp = new THREE.Path(); tracePath(hp, h); sh.holes.push(hp); }
      const bev = pt.bevel || 0;
      g = new THREE.ExtrudeGeometry(sh, {
        depth: Math.max(0.001, pt.d - bev * 2), bevelEnabled: bev > 0, bevelThickness: bev, bevelSize: bev,
        bevelSegments: pt.bseg || 2, curveSegments: pt.cs || 5, steps: 1
      });
      g.translate(0, 0, -(pt.d - bev * 2) / 2);
      if (HQ) { const ng0 = g.index ? g.toNonIndexed() : g; if (ng0 !== g) { g.dispose(); g = ng0; } markBevel(g); creaseNormals(g, 32); }
      g.rotateY(Math.PI / 2); // профиль рисуется в плоскости (вперёд, вверх), вперёд = -Z
    } else if (pt.cyl) {
      g = new THREE.CylinderGeometry(pt.r, pt.r2 != null ? pt.r2 : pt.r, pt.h, pt.seg || 10, 1, !!pt.open);
    } else if (pt.torus) {
      g = new THREE.TorusGeometry(pt.r, pt.tube, 6, pt.seg || 14);
    } else if (pt.sph) {
      g = new THREE.SphereGeometry(pt.r, pt.seg || 10, Math.max(4, (pt.seg || 10) >> 1));
    } else {
      g = new THREE.BoxGeometry(pt.w, pt.h, pt.d);
    }
    const ng = g.index ? g.toNonIndexed() : g;
    if (ng !== g) g.dispose();
    if (pt.sx || pt.sy || pt.sz) ng.scale(pt.sx || 1, pt.sy || 1, pt.sz || 1);
    _e.set(pt.rx || 0, pt.ry || 0, pt.rz || 0);
    _q.setFromEuler(_e);
    _p.set(pt.x || 0, pt.y || 0, pt.z || 0);
    _m.compose(_p, _q, _s);
    ng.applyMatrix4(_m);
    if (pt.post) ng.applyMatrix4(pt.post);
    return ng;
  }

  function pack(list, withUV, uvScale, keepCol) {
    const pos = [], nor = [], col = [], uv = [];
    for (const { g, pt } of list) {
      _c.set(pt.color || '#ffffff');
      const pa = g.attributes.position.array, na = g.attributes.normal.array, ea = g.attributes.edge ? g.attributes.edge.array : null;
      const n = pa.length / 3;
      for (let i = 0; i < n; i++) {
        const x = pa[i * 3], y = pa[i * 3 + 1], z = pa[i * 3 + 2];
        const nx = na[i * 3], ny = na[i * 3 + 1], nz = na[i * 3 + 2];
        pos.push(x, y, z); nor.push(nx, ny, nz);
        // низ детали в тени; фаски светлее — потёртые края ловят свет
        const shade = (ny < -0.5 ? 0.72 : ny < -0.1 ? 0.86 : 1) * (ea && ea[i] ? 1.1 : 1);
        if (withUV) {
          if (keepCol) col.push(_c.r * shade, _c.g * shade, _c.b * shade); else col.push(shade, shade, shade);
          const k = pt.uvk || uvScale, ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
          if (ax >= ay && ax >= az) uv.push(z * k + 0.13, y * k + 0.37);
          else if (ay >= az) uv.push(x * k + 0.71, z * k + 0.29);
          else uv.push(x * k + 0.41, y * k + 0.57);
        } else col.push(_c.r * shade, _c.g * shade, _c.b * shade);
      }
      g.dispose();
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    if (withUV) geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.computeBoundingSphere();
    return geo;
  }

  G.geo = {
    part: partGeo,
    // все детали в одну геометрию с вершинными цветами
    build(parts) { return pack(parts.map(pt => ({ g: partGeo(pt), pt })), false); },
    // с UV и вершинными цветами — для деталей с общей фактурой (перчатки, металл, пластик)
    buildUV(parts, uvScale) { return pack(parts.map(pt => ({ g: partGeo(pt), pt })), true, uvScale || 3, true); },
    // детали, помеченные skin:'a'|'b', уходят в отдельные геометрии с UV — для скинов
    buildSkinned(parts, uvScale) {
      const base = [], metal = [], glass = [], a = [], b = [], em = [];
      HQ = true;
      try {
        for (const pt of parts) {
          const g = partGeo(pt);
          (pt.em ? em : pt.skin === 'a' ? a : pt.skin === 'b' ? b : pt.g ? glass : pt.m ? metal : base).push({ g, pt });
        }
      } finally { HQ = false; }
      return {
        // пластик и металл — с UV для общей микрофактуры (царапины, зерно) и с вершинными цветами
        base: base.length ? pack(base, true, 9, true) : null,
        metal: metal.length ? pack(metal, true, 9, true) : null,
        em: em.length ? pack(em, false) : null,
        glass: glass.length ? pack(glass, false) : null,
        a: a.length ? pack(a, true, uvScale || 3) : null,
        b: b.length ? pack(b, true, uvScale || 3) : null
      };
    },
    box(w, h, d, x, y, z, color, rx, ry, rz) { return { w, h, d, x, y, z, color, rx, ry, rz }; },
    cyl(r, h, x, y, z, color, rx, ry, rz, seg, r2) { return { cyl: true, r, r2, h, x, y, z, color, rx, ry, rz, seg }; }
  };

  G.vcMat = null; // общий материал с вершинными цветами
  G.getVCMat = () => {
    if (!G.vcMat) G.vcMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    return G.vcMat;
  };
  G.vmBaseMat = null;
  G.getVMBaseMat = () => {
    if (!G.vmBaseMat) G.vmBaseMat = new THREE.MeshPhongMaterial({ vertexColors: true, shininess: 38, specular: 0x2a2a2a });
    return G.vmBaseMat;
  };
})(window.G);
