'use strict';
/* Общие утилиты, настройки, сборка геометрии из примитивов (коробки, цилиндры, профили, торы) */
window.G = window.G || {};
(function (G) {
  G.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  G.lerp = (a, b, t) => a + (b - a) * t;
  G.rand = (a, b) => a + Math.random() * (b - a);
  G.randi = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
  G.pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  G.shuffle = (arr) => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };
  G.angleDiff = (a, b) => {
    let d = b - a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return d;
  };
  G.damp = (k, dt) => 1 - Math.exp(-k * dt);
  // шина событий: в одиночной игре ничего не делает, на сервере собирает события для рассылки игрокам
  G.emit = G.emit || function () { };
  G.esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  G.store = {
    get(k, def) {
      try {
        const v = localStorage.getItem('sz_' + k);
        return v == null ? def : JSON.parse(v);
      } catch (e) { return def; }
    },
    set(k, v) {
      try { localStorage.setItem('sz_' + k, JSON.stringify(v)); } catch (e) { /* хранилище недоступно */ }
    },
    remove(k) { try { localStorage.removeItem('sz_' + k); } catch (e) { } }
  };

  const defaults = {
    nick: 'Игрок', sens: 1.0, quality: 'medium', volume: 0.8, autofire: false, res: 1, chat: true,
    difficulty: 'normal', mode: 'tdm', teamSize: 5, primary: 'ar', leftFire: true, fov: 64,
    map: 'harbor', showFps: false, btnOpacity: 0.85, layout: null, fpsCap: 60, playKind: 'bots', side: 'auto',
    wheel: true, slotBar: false, crouchMode: 'hold', hudV: 2
  };
  // прицел: стиль, цвет, длина, толщина, зазор, прозрачность, обводка, расхождение при стрельбе
  G.XH_DEF = { style: 'crossdot', color: '#ffffff', len: 9, thick: 2, gap: 4, alpha: 1, outline: true, dyn: true };
  G.applyCrosshair = (el, xh) => {
    if (!el) return;
    const x = Object.assign({}, G.XH_DEF, xh || {});
    el.style.setProperty('--xl', x.len + 'px'); el.style.setProperty('--xw', x.thick + 'px');
    el.style.setProperty('--xd', Math.max(2, x.thick + (x.style === 'dot' ? 2 : 0)) + 'px');
    el.style.setProperty('--xc', x.color); el.style.setProperty('--xa', x.alpha);
    el.style.setProperty('--xo', x.outline ? '0 0 0 1px rgba(0,0,0,.6)' : 'none');
    el.dataset.xs = x.style; el.dataset.xg = x.gap; el.dataset.xdyn = x.dyn ? 1 : 0;
    el._xg = +x.gap; el._xdyn = !!x.dyn; // 2.0 perf: crossGap каждый кадр читал dataset (обращение к DOM)
    el.style.setProperty('--gap', x.gap + 'px');
  };
  // зазор прицела, px: «расходится при стрельбе» — плавно (без скачка на каждый выстрел) и умеренно,
  // с мягким потолком; настройка выключена — статичный зазор
  G.crossGap = (el, sp, fov, h, dt) => {
    const xg = el._xg != null ? el._xg : +(el.dataset.xg || 4);
    if (el._xdyn != null ? !el._xdyn : el.dataset.xdyn === '0') { el._xgS = 0; return xg; }
    const px = Math.tan(sp) / Math.tan(fov * Math.PI / 360) * (h / 2);
    const M = G.clamp(h * 0.05, 14, 32), want = M * (1 - Math.exp(-px * 0.85 / M));
    let s = el._xgS;
    if (!(s >= 0)) s = want;
    s += (want - s) * (1 - Math.exp(-Math.min(dt, 0.1) * (want > s ? 11 : 7)));
    el._xgS = s;
    return xg + s;
  };
  const stored = G.store.get('settings', null);
  G.settings = Object.assign({}, defaults, stored || {});
  // 11.8: вместо панели слотов внизу — два колеса (оружие и гранаты); старым игрокам включаем новую раскладку
  if (stored && !(stored.hudV >= 2)) {
    G.settings.hudV = 2; G.settings.slotBar = false; G.settings.wheel = true; G.settings.crouchMode = 'hold';
    const lay = G.settings.layout;
    // свои положения кнопок сохраняем; битые записи раскладки выбрасываем
    if (lay && typeof lay === 'object') for (const k in lay) { const c = lay[k]; if (!c || typeof c !== 'object' || !isFinite(c.x) || !isFinite(c.y)) delete lay[k]; }
    G.store.set('settings', G.settings);
  }
  // автоснижение графики (game.perfCheck) действует только до перезапуска: в хранилище — качество, выбранное игроком
  G.saveSettings = () => G.store.set('settings', G.settings._userQ ? Object.assign({}, G.settings, { quality: G.settings._userQ, _userQ: undefined }) : G.settings);
  // статистика текущего профиля (ключ меняется при смене профиля)
  G.loadStats = (key) => {
    G.statsKey = key;
    G.stats = Object.assign({ kills: 0, deaths: 0, matches: 0, wins: 0, hs: 0, xp: 0, shots: 0, hits: 0, best: 0, time: 0, wk: {} }, G.store.get(key, {}));
  };
  G.loadStats('stats');
  G.saveStats = () => G.store.set(G.statsKey, G.stats);
  G.level = () => {
    const xp = G.stats.xp || 0;
    const lvl = Math.floor(Math.sqrt(xp / 120)) + 1;
    const cur = (lvl - 1) * (lvl - 1) * 120, next = lvl * lvl * 120;
    return { lvl, frac: (xp - cur) / (next - cur) };
  };

  // 2.0: внешняя ссылка (Telegram и т.п.): в APK — через системный браузер/приложение, в вебе — новая вкладка
  G.DONATE_URL = 'https://t.me/Narelax3akaT';
  G.openUrl = (url) => {
    try { if (window.Android && window.Android.openUrl) { window.Android.openUrl(url); return true; } } catch (e) { }
    try { const w = window.open(url, '_blank', 'noopener'); if (w) return true; } catch (e) { }
    try { const a = document.createElement('a'); a.href = url; a.target = '_blank'; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove(); return true; } catch (e) { }
    return false;
  };
  G.isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

  /* ---------- Геометрия ---------- */
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(),
    _s = new THREE.Vector3(1, 1, 1), _p = new THREE.Vector3(), _c = new THREE.Color();

  // путь профиля: [x,y] — линия; ['q',cx,cy,x,y] — квадратичная кривая; ['c',…] — кубическая
  function tracePath(p, pts) {
    let first = true;
    for (const q of pts) {
      if (typeof q[0] === 'string') {
        if (q[0] === 'q') p.quadraticCurveTo(q[1], q[2], q[3], q[4]);
        else if (q[0] === 'c') p.bezierCurveTo(q[1], q[2], q[3], q[4], q[5], q[6]);
      } else if (first) { p.moveTo(q[0], q[1]); first = false; }
      else p.lineTo(q[0], q[1]);
    }
  }
  // коробка со скошенными рёбрами (фаска ловит свет — деталь выглядит как настоящая, а не как кубик)
  function chamferBox(w, h, d, c) {
    const hx = w / 2, hy = h / 2, hz = d / 2, P = {};
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) {
      P[sx + ',' + sy + ',' + sz] = {
        x: [sx * hx, sy * (hy - c), sz * (hz - c)], y: [sx * (hx - c), sy * hy, sz * (hz - c)], z: [sx * (hx - c), sy * (hy - c), sz * hz]
      };
    }
    const pos = [], edge = [];
    const tri = (a, b, c2, e) => {
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c2[0] - a[0], vy = c2[1] - a[1], vz = c2[2] - a[2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const cx = a[0] + b[0] + c2[0], cy = a[1] + b[1] + c2[1], cz = a[2] + b[2] + c2[2];
      if (nx * cx + ny * cy + nz * cz < 0) pos.push(...a, ...c2, ...b); else pos.push(...a, ...b, ...c2);
      edge.push(e, e, e);
    };
    const quad = (a, b, c2, d2, e) => { tri(a, b, c2, e); tri(a, c2, d2, e); };
    const k = (x, y, z) => P[x + ',' + y + ',' + z];
    // грани
    for (const s of [-1, 1]) {
      quad(k(s, -1, -1).x, k(s, 1, -1).x, k(s, 1, 1).x, k(s, -1, 1).x, 0);
      quad(k(-1, s, -1).y, k(1, s, -1).y, k(1, s, 1).y, k(-1, s, 1).y, 0);
      quad(k(-1, -1, s).z, k(1, -1, s).z, k(1, 1, s).z, k(-1, 1, s).z, 0);
    }
    // фаски вдоль рёбер
    for (const a of [-1, 1]) for (const b of [-1, 1]) {
      quad(k(a, b, -1).x, k(a, b, 1).x, k(a, b, 1).y, k(a, b, -1).y, 1);   // вдоль Z
      quad(k(a, -1, b).x, k(a, 1, b).x, k(a, 1, b).z, k(a, -1, b).z, 1);   // вдоль Y
      quad(k(-1, a, b).y, k(1, a, b).y, k(1, a, b).z, k(-1, a, b).z, 1);   // вдоль X
    }
    // уголки
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) { const q = k(sx, sy, sz); tri(q.x, q.y, q.z, 1); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.computeVertexNormals();
    g.setAttribute('edge', new THREE.Float32BufferAttribute(edge, 1));
    return g;
  }
  // сглаживание нормалей по углу излома: изогнутые поверхности гладкие, острые рёбра остаются острыми
  function creaseNormals(g, deg) {
    const pa = g.attributes.position.array, nt = pa.length / 9, fn = new Float32Array(nt * 3);
    for (let t = 0; t < nt; t++) {
      const o = t * 9;
      const ux = pa[o + 3] - pa[o], uy = pa[o + 4] - pa[o + 1], uz = pa[o + 5] - pa[o + 2];
      const vx = pa[o + 6] - pa[o], vy = pa[o + 7] - pa[o + 1], vz = pa[o + 8] - pa[o + 2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const l = Math.hypot(nx, ny, nz) || 1; fn[t * 3] = nx / l; fn[t * 3 + 1] = ny / l; fn[t * 3 + 2] = nz / l;
    }
    const groups = new Map(), key = (i) => Math.round(pa[i * 3] * 2e4) + '_' + Math.round(pa[i * 3 + 1] * 2e4) + '_' + Math.round(pa[i * 3 + 2] * 2e4);
    const nv = pa.length / 3, keys = new Array(nv);
    for (let i = 0; i < nv; i++) { const k = keys[i] = key(i); let a = groups.get(k); if (!a) groups.set(k, a = []); a.push(i); }
    const cosT = Math.cos(deg * Math.PI / 180), out = new Float32Array(pa.length);
    for (let i = 0; i < nv; i++) {
      const f = (i / 3) | 0, ax = fn[f * 3], ay = fn[f * 3 + 1], az = fn[f * 3 + 2];
      let sx = 0, sy = 0, sz = 0;
      for (const j of groups.get(keys[i])) {
        const fj = (j / 3) | 0, bx = fn[fj * 3], by = fn[fj * 3 + 1], bz = fn[fj * 3 + 2];
        if (ax * bx + ay * by + az * bz >= cosT) { sx += bx; sy += by; sz += bz; }
      }
      const l = Math.hypot(sx, sy, sz) || 1; out[i * 3] = sx / l; out[i * 3 + 1] = sy / l; out[i * 3 + 2] = sz / l;
    }
    g.setAttribute('normal', new THREE.Float32BufferAttribute(out, 3));
  }
  // фаски профиля (выдавленной детали): грани под углом к оси выдавливания
  function markBevel(g) {
    const na = g.attributes.normal.array, n = na.length / 3, e = new Float32Array(n);
    for (let t = 0; t < n; t += 3) {
      const z = Math.abs(na[t * 3 + 2] + na[t * 3 + 5] + na[t * 3 + 8]) / 3;
      const v = z > 0.15 && z < 0.97 ? 1 : 0; e[t] = e[t + 1] = e[t + 2] = v;
    }
    g.setAttribute('edge', new THREE.BufferAttribute(e, 1));
  }
  let HQ = false; // качественная геометрия: для оружия в руках и витрины

  // создать трансформированную неиндексированную геометрию одной детали
  function partGeo(pt) {
    let g;
    if (HQ && !pt.shape && !pt.cyl && !pt.torus && !pt.sph && !pt.flat) {
      const mn = Math.min(pt.w, pt.h, pt.d);
      if (mn >= 0.0055) g = chamferBox(pt.w, pt.h, pt.d, Math.min(0.0032, mn * 0.2));
    }
    if (g) { /* фаска уже готова */ }
    else if (pt.shape) {
      const sh = new THREE.Shape();
      tracePath(sh, pt.pts);
      if (pt.holes) for (const h of pt.holes) { const hp = new THREE.Path(); tracePath(hp, h); sh.holes.push(hp); }
      const bev = pt.bevel || 0;
      g = new THREE.ExtrudeGeometry(sh, {
        depth: Math.max(0.001, pt.d - bev * 2), bevelEnabled: bev > 0, bevelThickness: bev, bevelSize: bev,
        bevelSegments: pt.bseg || 2, curveSegments: pt.cs || 5, steps: 1
      });
      g.translate(0, 0, -(pt.d - bev * 2) / 2);
      if (HQ) { const ng0 = g.index ? g.toNonIndexed() : g; if (ng0 !== g) { g.dispose(); g = ng0; } markBevel(g); creaseNormals(g, 32); }
      g.rotateY(Math.PI / 2); // профиль рисуется в плоскости (вперёд, вверх), вперёд = -Z
    } else if (pt.cyl) {
      g = new THREE.CylinderGeometry(pt.r, pt.r2 != null ? pt.r2 : pt.r, pt.h, pt.seg || 10, 1, !!pt.open);
    } else if (pt.torus) {
      g = new THREE.TorusGeometry(pt.r, pt.tube, 6, pt.seg || 14);
    } else if (pt.sph) {
      g = new THREE.SphereGeometry(pt.r, pt.seg || 10, pt.hs || Math.max(4, (pt.seg || 10) >> 1));
    } else {
      g = new THREE.BoxGeometry(pt.w, pt.h, pt.d);
    }
    const ng = g.index ? g.toNonIndexed() : g;
    if (ng !== g) g.dispose();
    if (pt.sx || pt.sy || pt.sz) ng.scale(pt.sx || 1, pt.sy || 1, pt.sz || 1);
    _e.set(pt.rx || 0, pt.ry || 0, pt.rz || 0);
    _q.setFromEuler(_e);
    _p.set(pt.x || 0, pt.y || 0, pt.z || 0);
    _m.compose(_p, _q, _s);
    ng.applyMatrix4(_m);
    if (pt.post) ng.applyMatrix4(pt.post);
    return ng;
  }

  function pack(list, withUV, uvScale, keepCol) {
    const pos = [], nor = [], col = [], uv = [];
    for (const { g, pt } of list) {
      _c.set(pt.color || '#ffffff');
      const pa = g.attributes.position.array, na = g.attributes.normal.array, ea = g.attributes.edge ? g.attributes.edge.array : null;
      const n = pa.length / 3;
      for (let i = 0; i < n; i++) {
        const x = pa[i * 3], y = pa[i * 3 + 1], z = pa[i * 3 + 2];
        const nx = na[i * 3], ny = na[i * 3 + 1], nz = na[i * 3 + 2];
        pos.push(x, y, z); nor.push(nx, ny, nz);
        // низ детали в тени; фаски светлее — потёртые края ловят свет
        const shade = (ny < -0.5 ? 0.72 : ny < -0.1 ? 0.86 : 1) * (ea && ea[i] ? 1.1 : 1);
        if (withUV) {
          if (keepCol) col.push(_c.r * shade, _c.g * shade, _c.b * shade); else col.push(shade, shade, shade);
          const k = pt.uvk || uvScale, ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
          if (ax >= ay && ax >= az) uv.push(z * k + 0.13, y * k + 0.37);
          else if (ay >= az) uv.push(x * k + 0.71, z * k + 0.29);
          else uv.push(x * k + 0.41, y * k + 0.57);
        } else col.push(_c.r * shade, _c.g * shade, _c.b * shade);
      }
      g.dispose();
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    if (withUV) geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.computeBoundingSphere();
    return geo;
  }

  // 2.2 perf: готовые геометрии моделей в руках по содержимому деталей. Модель того же ствола (другая сторона, наблюдение
  // за союзником с тем же оружием, следующий матч после смены скинов) раньше каждый раз заново считала фаски и нормали
  // (~25–50 мс на ПК, в 5–8 раз дольше на телефоне — рывок при переходе в наблюдение после смерти). Теперь — копия
  // готовой геометрии (те же числа, картинка та же). Хранится не больше ~10 МБ (вытесняются давно не нужные)
  const GM = new Map(), GM_MAX = 10 * 1048576; let gmBytes = 0;
  const gBytes = (g) => { let b = 0; if (g) { for (const n in g.attributes) b += g.attributes[n].array.byteLength; if (g.index) b += g.index.array.byteLength; } return b; };
  function memoGeo(tag, parts, k, make) {
    let key = null;
    if (parts && parts.length < 400) { try { key = tag + '|' + k + '|' + JSON.stringify(parts); } catch (e) { key = null; } }
    if (!key) return make();
    let e = GM.get(key);
    if (e) { GM.delete(key); GM.set(key, e); }
    else {
      const v = make();
      let b = 0; if (v && v.isBufferGeometry) b = gBytes(v); else if (v) for (const n in v) b += gBytes(v[n]);
      e = { v, b }; GM.set(key, e); gmBytes += b;
      while (gmBytes > GM_MAX && GM.size > 1) { const k0 = GM.keys().next().value; gmBytes -= GM.get(k0).b; GM.delete(k0); }
    }
    const v = e.v;
    if (v && v.isBufferGeometry) return v.clone();
    const out = {}; for (const n in v) out[n] = v[n] ? v[n].clone() : null;
    return out;
  }
  G.geoMemoStats = () => ({ n: GM.size, mb: gmBytes / 1048576 });

  G.geo = {
    part: partGeo,
    // все детали в одну геометрию с вершинными цветами
    build(parts) { return pack(parts.map(pt => ({ g: partGeo(pt), pt })), false); },
    // с UV и вершинными цветами — для деталей с общей фактурой (перчатки, металл, пластик)
    buildUV(parts, uvScale) { return memoGeo('U', parts, uvScale || 3, () => pack(parts.map(pt => ({ g: partGeo(pt), pt })), true, uvScale || 3, true)); },
    // детали, помеченные skin:'a'|'b', уходят в отдельные геометрии с UV — для скинов
    buildSkinned(parts, uvScale) { return memoGeo('S', parts, uvScale || 3, () => this.buildSkinned0(parts, uvScale)); },
    buildSkinned0(parts, uvScale) {
      const base = [], metal = [], glass = [], a = [], b = [], em = [];
      HQ = true;
      try {
        for (const pt of parts) {
          const g = partGeo(pt);
          (pt.em ? em : pt.skin === 'a' ? a : pt.skin === 'b' ? b : pt.g ? glass : pt.m ? metal : base).push({ g, pt });
        }
      } finally { HQ = false; }
      return {
        // пластик и металл — с UV для общей микрофактуры (царапины, зерно) и с вершинными цветами
        base: base.length ? pack(base, true, 9, true) : null,
        metal: metal.length ? pack(metal, true, 9, true) : null,
        em: em.length ? pack(em, false) : null,
        glass: glass.length ? pack(glass, false) : null,
        a: a.length ? pack(a, true, uvScale || 3) : null,
        b: b.length ? pack(b, true, uvScale || 3) : null
      };
    },
    box(w, h, d, x, y, z, color, rx, ry, rz) { return { w, h, d, x, y, z, color, rx, ry, rz }; },
    cyl(r, h, x, y, z, color, rx, ry, rz, seg, r2) { return { cyl: true, r, r2, h, x, y, z, color, rx, ry, rz, seg }; }
  };

  // 2.0 perf: «заморозить» неподвижное поддерево: матрицы считаются один раз, дальше three.js их не трогает
  // (ни compose, ни умножение на родителя каждый кадр). Объект, который двигают в игре, помечают
  // userData.dynamic = true (или передают в skip) — он и его потомки остаются «живыми».
  // Подвинуть замороженный объект потом можно так: o.position.set(...); o.updateMatrix(); o.updateMatrixWorld(true).
  G.freezeStatic = (root, skip) => {
    if (!root || !root.isObject3D) return;
    root.updateMatrixWorld(true);
    const walk = (o) => {
      if ((skip && skip.has(o)) || (o.userData && o.userData.dynamic)) return false;
      let still = true;
      for (let i = 0; i < o.children.length; i++) if (!walk(o.children[i])) still = false;
      if (o.matrixAutoUpdate) { o.updateMatrix(); o.matrixAutoUpdate = false; }
      // ветвь целиком неподвижна — её не обходим вовсе; корень оставляем в обходе (его видимость переключают)
      if (still && o !== root) o.matrixWorldAutoUpdate = false;
      return still;
    };
    walk(root);
  };

  // 2.2 perf: неподвижная геометрия (карта, модели в руках) после загрузки в видеопамять больше не читается из JS —
  // массивы вершин освобождаем (стандартный приём three.js: onUpload). Карта — ~12–15 МБ кучи JS на каждую
  // отрисованную карту. Только обычные меши (не Points/Sprite/Line, не скиннинг, не InstancedMesh) и только
  // атрибуты без обновлений (StaticDrawUsage); то, что ещё не рисовалось (скрыто качеством), остаётся с массивами до
  // первой отрисовки. ВАЖНО: такую геометрию нельзя dispose() и рисовать снова (нечем перезагрузить) — освобождать
  // её можно только вместе с выбрасыванием объекта
  const dropArr = function () { this.array = null; };
  G.freeAfterUpload = (root) => {
    if (!root || !root.traverse || typeof THREE === 'undefined') return;
    root.traverse(o => {
      if (!o.isMesh || o.isSkinnedMesh || o.isInstancedMesh || !o.geometry || !o.geometry.isBufferGeometry) return;
      const g = o.geometry;
      if (g.morphAttributes && Object.keys(g.morphAttributes).length) return;
      if (!g.boundingSphere) g.computeBoundingSphere();
      for (const k in g.attributes) { const a = g.attributes[k]; if (a.isBufferAttribute && !a.isInterleavedBufferAttribute && a.usage === THREE.StaticDrawUsage && a.array) a.onUpload(dropArr); }
      if (g.index && g.index.array) g.index.onUpload(dropArr);
    });
  };

  // 2.1 perf: тень солнца не читаем там, куда солнце и так не светит (dot(N, L) <= 0 — грань отвёрнута от солнца):
  // вклад солнца там равен нулю при любом значении тени (Lambert/Phong/Standard: irradiance = saturate(dotNL) * color),
  // значит картинка та же, а у ~трети пикселей пропадают выборки карты теней (на «Высоком» мягкие тени — 16 выборок
  // на пиксель). Где тень нужна и при dotNL <= 0 (лак clearcoat, мультяшный toon) — прежний код.
  // Только браузер: сервер (G.HEADLESS) THREE не загружает
  if (typeof THREE !== 'undefined' && THREE.ShaderChunk && typeof THREE.ShaderChunk.lights_fragment_begin === 'string') {
    const SC = THREE.ShaderChunk, re = /directLight\.color \*= \( directLight\.visible && receiveShadow \) \? (getShadow\( directionalShadowMap\[ i \][^;]*?\)) : 1\.0;/;
    const src = SC.lights_fragment_begin, mm = src.match(re);
    if (mm && src.indexOf('szNL') < 0) {
      SC.lights_fragment_begin = src.replace(re, () => '\n#if defined( USE_CLEARCOAT ) || defined( TOON )\n\t\t' + mm[0] +
        '\n#else\n\t\tdirectLight.color *= ( directLight.visible && receiveShadow && dot( geometry.normal, directLight.direction ) > 0.0 /* szNL */ ) ? ' + mm[1] + ' : 1.0;\n#endif\n');
      G.shadowNLPatch = true;
    }
    // 2.1 perf: сферические гармоники «световых зондов» (LightProbe) считались в КАЖДОМ пикселе каждого освещённого
    // материала (9 цветов из uniform-массива и ~30 умножений) — а зондов в игре нет, массив нулевой, вклад ровно 0.
    // Убираем вычисление (картинка та же бит в бит). Если когда-нибудь добавите THREE.LightProbe — удалите этот блок
    const lp = 'irradiance += getLightProbeIrradiance( lightProbe, geometry.normal );', s2 = SC.lights_fragment_begin;
    if (s2.indexOf(lp) >= 0) { SC.lights_fragment_begin = s2.replace(lp, '#ifdef SZ_LIGHT_PROBES\n\t' + lp + '\n\t#endif'); G.lightProbeStrip = true; }
  }

  // 2.1 perf: освещение плоских граней карты — в вершинах, а не в каждом пикселе.
  // У коробок карты и земли нормаль постоянна по всей грани, значит рассеянный свет (солнце · N, небо/земля полусферы)
  // в каждом пикселе грани один и тот же: считаем его в 3 вершинах, а в пикселе остаются фактура, цвет, тень и туман.
  // Тень (карта теней) по-прежнему попиксельная. Работает только там, где это даёт ту же картинку: без карт нормалей
  // («Высокое» с рельефом — прежний попиксельный путь), не двусторонние, один «солнечный» и один полусферный свет,
  // и геометрия проверена на плоскость (G.vlitCheck при сборке карты; кривая — прежний путь)
  const VLIT_DEF = '#if !defined( USE_NORMALMAP ) && !defined( USE_BUMPMAP ) && !defined( DOUBLE_SIDED ) && !defined( FLAT_SHADED ) && !defined( USE_LIGHTMAP ) && !defined( USE_ENVMAP ) && NUM_DIR_LIGHTS == 1 && NUM_HEMI_LIGHTS == 1 && NUM_POINT_LIGHTS == 0 && NUM_SPOT_LIGHTS == 0 && NUM_RECT_AREA_LIGHTS == 0\n#define SZ_VLIT\n#endif\n';
  const VLIT_VARY = '#ifdef SZ_VLIT\nvarying vec3 vSzD;\nvarying vec3 vSzI;\nvarying float vSzNL;\n#endif\n';
  G.vlitMat = (m) => {
    if (!m || m.userData.vlit || typeof THREE === 'undefined') return m;
    m.userData.vlit = true;
    m.onBeforeCompile = function (sh) {
      if (this.userData.vlitOff) return;
      let v = sh.vertexShader, f = sh.fragmentShader;
      if (v.indexOf('#include <fog_vertex>') < 0 || f.indexOf('#include <lights_fragment_begin>') < 0 || v.indexOf('#include <common>') < 0) return;
      v = v.replace('#include <common>', '#include <common>\n' + VLIT_DEF + VLIT_VARY + '#ifdef SZ_VLIT\n#include <lights_pars_begin>\n#endif');
      v = v.replace('#include <fog_vertex>', '#include <fog_vertex>\n#ifdef SZ_VLIT\n{\n\tvec3 szN = normalize( normalize( transformedNormal ) );\n' +
        '\tfloat szNL = dot( szN, directionalLights[ 0 ].direction );\n\tvSzNL = szNL;\n\tvSzD = saturate( szNL ) * directionalLights[ 0 ].color;\n' +
        '\tvSzI = getAmbientLightIrradiance( ambientLightColor ) + getHemisphereLightIrradiance( hemisphereLights[ 0 ], szN );\n}\n#endif');
      f = f.replace('#include <common>', '#include <common>\n' + VLIT_DEF + VLIT_VARY);
      f = f.replace('#include <lights_fragment_begin>', '#ifdef SZ_VLIT\nGeometricContext geometry;\ngeometry.position = - vViewPosition;\ngeometry.normal = normal;\ngeometry.viewDir = normalize( vViewPosition );\n' +
        'vec3 szSun = vSzD;\n#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\nDirectionalLightShadow szSh = directionalLightShadows[ 0 ];\n' +
        'szSun *= ( receiveShadow && vSzNL > 0.0 ) ? getShadow( directionalShadowMap[ 0 ], szSh.shadowMapSize, szSh.shadowBias, szSh.shadowRadius, vDirectionalShadowCoord[ 0 ] ) : 1.0;\n#endif\n' +
        'reflectedLight.directDiffuse += szSun * BRDF_Lambert( material.diffuseColor );\nvec3 iblIrradiance = vec3( 0.0 );\nvec3 irradiance = vSzI;\n#else\n#include <lights_fragment_begin>\n#endif');
      sh.vertexShader = v; sh.fragmentShader = f;
    };
    m.customProgramCacheKey = function () { return this.userData.vlitOff ? 'novlit' : 'vlit'; };
    m.needsUpdate = true;
    return m;
  };
  // проверка при сборке карты: материалы с вершинным светом должны лежать только на плоских гранях (у каждого
  // треугольника три одинаковые нормали) и не быть двусторонними; иначе этот материал остаётся с попиксельным светом
  G.vlitCheck = (root) => {
    if (!root || !root.traverse) return;
    root.traverse(o => {
      const m = o.material; if (!m || Array.isArray(m) || !m.userData || !m.userData.vlit || m.userData.vlitOff) return;
      let ok = !!o.isMesh && !o.isSkinnedMesh && !o.isInstancedMesh && m.side !== THREE.DoubleSide && !m.flatShading;
      const g = o.geometry, nor = ok && g && g.attributes.normal, idx = g && g.index;
      if (!nor) ok = false;
      else {
        const n = nor.array, ia = idx ? idx.array : null, cnt = ia ? ia.length : nor.count;
        for (let t = 0; t + 2 < cnt && ok; t += 3) {
          const a = (ia ? ia[t] : t) * 3, b = (ia ? ia[t + 1] : t + 1) * 3, c = (ia ? ia[t + 2] : t + 2) * 3;
          if (n[a] !== n[b] || n[a] !== n[c] || n[a + 1] !== n[b + 1] || n[a + 1] !== n[c + 1] || n[a + 2] !== n[b + 2] || n[a + 2] !== n[c + 2]) ok = false;
        }
      }
      if (!ok) { m.userData.vlitOff = true; m.needsUpdate = true; }
    });
  };

  G.vcMat = null; // общий материал с вершинными цветами
  G.getVCMat = () => {
    if (!G.vcMat) G.vcMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    return G.vcMat;
  };
  G.vmBaseMat = null;
  G.getVMBaseMat = () => {
    if (!G.vmBaseMat) G.vmBaseMat = new THREE.MeshPhongMaterial({ vertexColors: true, shininess: 38, specular: 0x2a2a2a });
    return G.vmBaseMat;
  };
})(window.G);
