'use strict';
/* Prodigy Strike (бывш. Strike Zone) — онлайн-сервер: комнаты, быстрый поиск матча, комнаты по коду.
   Матч целиком считается здесь (боты, раунды, бомба, попадания); телефоны присылают движение и выстрелы. */
const http = require('http');
const { attach } = require('./lib/ws');
const { createSim } = require('./sim/loader');

const PORT = +process.env.PORT || 8080;
const MIN_CV = 119; // минимальная версия игры (11.9)
const PROTO = 1;
const VERSION = '1.8.0';
const HOLD_MS = 40000;          // столько ждём игрока после обрыва связи, прежде чем отдать его место боту
const STARTED = Date.now();
const TICK = 1 / 30;             // шаг симуляции
const SNAP_EVERY = 2;            // снимок состояния каждые 2 шага (15 раз в секунду)
const MAX_ROOMS = 30, MAX_CONN = 200;
const MAPS = ['harbor', 'sakura'];   // 5 на 5 по кругу («Пыльный квартал» убран в 1.5)
const SMALL = ['villa'];             // 2 на 2 — только по прямому выбору; с 1.6 — только живые игроки, без ботов
const PVP_NEED = 4;                  // столько людей нужно, чтобы на «Вилле» начался матч (до этого — разминка)
const PVP_COUNT = 5;                 // отсчёт перед матчем, с
const okMap = (m) => MAPS.includes(m) || SMALL.includes(m);
const DUEL_MAP = 'winter';
const MODES = ['tdm', 'bomb', 'duel'];
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const rooms = new Map();
const conns = new Set();
let connSeq = 0;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

function newCode() {
  for (; ;) {
    let c = ''; for (let i = 0; i < 4; i++) c += CODE_ABC[Math.floor(Math.random() * CODE_ABC.length)];
    if (!rooms.has(c)) return c;
  }
}
const r2 = (v) => Math.round(v * 100) / 100;
const r3 = (v) => Math.round(v * 1000) / 1000;
const cleanName = (s) => String(s || 'Игрок').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 14) || 'Игрок';
const cleanText = (s) => String(s || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 90);

// ---------- комната ----------
class Room {
  constructor(opts) {
    this.code = newCode();
    this.pub = !!opts.pub;
    this.mode = MODES.includes(opts.mode) ? opts.mode : SMALL.includes(opts.map) ? 'bomb' : 'tdm';
    this.map = this.mode === 'duel' ? DUEL_MAP : okMap(opts.map) ? opts.map : MAPS[Math.floor(Math.random() * MAPS.length)];
    // «Вилла» (1.6): только люди, 2 на 2; пока не собрались четверо — разминка
    this.pvp = this.mode !== 'duel' && SMALL.includes(this.map);
    this.phase = this.pvp ? 'warm' : 'match';   // warm — разминка, count — отсчёт до матча, match — матч
    this.countT = 0; this.restartAfter = 12;
    this.size = this.mode === 'duel' ? 1 : SMALL.includes(this.map) ? 2 : Math.max(2, Math.min(5, opts.size | 0 || 5));
    this.diff = ['easy', 'normal', 'hard'].includes(opts.diff) ? opts.diff : 'normal';
    this.clients = new Set();
    this.held = new Map();          // ключ телефона → игрок, у которого оборвалась связь
    this.sim = createSim();
    this.G = this.sim.G;
    this.g = this.G.game;
    this.g.start(this.startOpts());
    this.G.events.length = 0;
    this.tickN = 0; this.emptyT = 0; this.restartT = 0;
    this.dropV = 0;                 // версия списка оружия на земле: изменилась — новый список в снимке
    this.timer = setInterval(() => this.tick(), TICK * 1000);
    rooms.set(this.code, this);
    log('room', this.code, this.pub ? 'public' : 'private', this.mode, this.map);
  }
  humans() { return [...this.clients].filter(c => c.actor); }
  // люди в матче, включая тех, у кого оборвалась связь (их место ждёт)
  seats() { return this.g.actors.filter(a => a.net).length; }
  startOpts() { return { mode: this.mode, map: this.map, size: this.size, diff: this.diff, noBots: this.pvp, warm: this.pvp && this.phase !== 'match' }; }
  info() {
    const o = { code: this.pub ? null : this.code, id: this.code, pub: this.pub, mode: this.mode, map: this.map, size: this.size, diff: this.diff, players: this.pvp ? this.seats() : this.clients.size, max: this.size * 2 };
    if (this.pvp) { o.pvp = 1; if (this.phase !== 'match') o.st = 'warm'; } // «только игроки», «разминка»
    return o;
  }
  // что сказать игроку при входе: сейчас идёт режим mode (разминка — всегда TDM), матч в комнате — rmode
  joinMsg(p, extra) { return Object.assign({ t: 'joined', code: this.code, pub: this.pub, mode: this.g.mode, map: this.map, size: this.size, diff: this.diff, you: p.nid, team: p.team }, this.pvp ? { pvp: 1, rmode: this.mode } : null, extra); }
  join(c) {
    // тот же телефон вернулся после обрыва — отдаём ему его же игрока (место, оружие, счёт)
    const back = this.reclaim(c);
    if (back) {
      const p = back, g = this.g;
      c.room = this; c.actor = p; this.clients.add(c); c.dropV = -1;
      p.tp++; p.lastStT = g.time; p.lastX = p.pos.x; p.lastZ = p.pos.z; p.netUse = false;
      p.noDrops = !(c.profile && c.profile.drops); // могли вернуться с другой версии игры
      c.send(this.joinMsg(p, { resumed: 1 }));
      this.flushEvents();
      this.sendRoster();
      this.chatSys(p.name + ' вернулся');
      log('resume', this.code, p.name, 'humans', this.clients.size);
      this.pvpCheck();
      return true;
    }
    const p = this.g.addHuman(this.uniqueName(c.name), Object.assign({}, c.profile, { side: c.side || 'auto' }));
    if (!p) return false;
    c.room = this; c.actor = p; this.clients.add(c); c.dropV = -1; // первый же снимок принесёт оружие на земле
    c.send(this.joinMsg(p));
    this.flushEvents();
    this.sendRoster();
    this.chatSys(p.name + ' в игре');
    const note = p.joinNote;
    if (note && note.startsWith('bot:')) c.send({ t: 'ev', l: [['sys', 'Вы заняли место бота ' + note.slice(4) + ' — в бой!']] });
    else if (note === 'wait') c.send({ t: 'ev', l: [['sys', 'Раунд уже идёт — вы появитесь в следующем раунде']] });
    else if (note === 'duel') this.chatSys(this.clients.size >= 2 ? 'Соперник найден — дуэль начинается заново!' : 'Соперника пока нет — разминка с ботом. Пришлите другу код комнаты ' + this.code);
    if (this.pvp && this.phase !== 'match') c.send({ t: 'ev', l: [['sys', 'Разминка: матч 2 на 2 начнётся, когда соберутся ' + PVP_NEED + ' игрока' + (this.pub ? '' : ' · код комнаты ' + this.code)]] });
    log('join', this.code, p.name, 'team', p.team, 'humans', this.clients.size, note || '');
    this.pvpCheck();
    return true;
  }
  reclaim(c) {
    if (!c.key) return null;
    const h = this.held.get(c.key);
    if (h) { this.held.delete(c.key); if (this.g.actors.includes(h.p)) return h.p; }
    // старое соединение этого же телефона ещё числится (сеть сменилась) — забираем у него игрока
    for (const o of this.clients) {
      if (o === c || o.key !== c.key || !o.actor) continue;
      const p = o.actor;
      this.clients.delete(o); o.room = null; o.actor = null;
      try { o.ws.close(4000, 'replaced'); } catch (e) { }
      return p;
    }
    return null;
  }
  // связь оборвалась (не «выйти из матча»): игрок остаётся в матче и ждёт возвращения
  drop(c) {
    if (!this.clients.has(c)) return;
    const p = c.actor;
    if (!p || !c.key) { this.leave(c); return; }
    this.clients.delete(c); c.room = null; c.actor = null;
    p.netUse = false; p.vel.set(0, 0, 0);
    this.held.set(c.key, { p, t: Date.now() });
    log('drop', this.code, p.name, 'waiting for return');
    this.pvpCheck();
  }
  expireHeld() {
    const now = Date.now();
    for (const [k, h] of this.held) {
      if (now - h.t < HOLD_MS) continue;
      this.held.delete(k);
      if (this.g.actors.includes(h.p)) { this.g.removeHuman(h.p); this.chatSys(h.p.name + ' вышел'); this.flushEvents(); this.sendRoster(); }
      log('hold expired', this.code, h.p.name);
      this.pvpCheck();
    }
  }
  leave(c) {
    if (!this.clients.has(c)) return;
    this.clients.delete(c);
    const p = c.actor; c.room = null; c.actor = null;
    if (p) { this.g.removeHuman(p); this.chatSys(p.name + ' вышел'); }
    this.flushEvents();
    this.sendRoster();
    log('leave', this.code, p && p.name, 'humans', this.clients.size);
    this.pvpCheck();
  }
  // ---------- «Вилла» только для людей (1.6) ----------
  // кто-то вошёл/вышел: разминка ↔ отсчёт, техническая победа, если команда опустела
  pvpCheck() {
    if (!this.pvp || this.g.over) return;
    const g = this.g;
    if (this.phase === 'match') {
      const t0 = g.teamCount(0, true), t1 = g.teamCount(1, true);
      if (t0 && t1) return;
      const win = t0 ? 0 : t1 ? 1 : null;
      this.restartAfter = 8;
      g.endMatch({ win, forfeit: true });
      this.chatSys(win == null ? 'Все игроки вышли — матч окончен' : 'Соперники покинули матч — техническая победа ' + (win === 0 ? 'спецназа' : 'налётчиков'));
      this.flushEvents();
      log('forfeit', this.code, 'win', win);
      return;
    }
    const ready = this.seats() >= PVP_NEED && this.humans().length >= PVP_NEED;
    if (ready && this.phase === 'warm') { this.phase = 'count'; this.countT = PVP_COUNT; this.chatSys('Все в сборе — матч начинается!'); log('countdown', this.code); }
    else if (!ready && this.phase === 'count') { this.phase = 'warm'; this.countT = 0; this.chatSys('Игрок вышел — снова разминка, ждём ' + PVP_NEED + ' игроков'); log('countdown cancelled', this.code); }
  }
  // новый круг в той же комнате: разминка (warm) или настоящий матч (match)
  pvpStart(phase) {
    this.phase = phase; this.countT = 0; this.restartT = 0; this.restartAfter = 12;
    this.g.start(this.startOpts());
    for (const c of this.clients) if (c.actor) c.send({ t: 'team', team: c.actor.team });
    this.flushEvents();
    this.sendRoster();
    log(phase === 'match' ? 'match start' : 'warm-up', this.code, this.mode, 'humans', this.seats());
    if (phase === 'warm') this.pvpCheck();
  }
  uniqueName(n) {
    const used = new Set(this.g.actors.map(a => a.name));
    if (!used.has(n)) return n;
    for (let i = 2; i < 99; i++) { const m = (n.slice(0, 12) + i); if (!used.has(m)) return m; }
    return n;
  }
  chatSys(text) { this.broadcast({ t: 'ev', l: [['sys', text]] }); }
  sendRoster() {
    const list = this.g.actors.filter(a => !this.pvp || a.net).map(a => [a.nid, a.name, a.team, a.net ? 1 : 0, a.net ? a.knifeFor().id : 'knife', a.net && a.gloves ? a.gloves[0] : null]);
    this.broadcast({ t: 'roster', list });
  }
  broadcast(msg) { const s = JSON.stringify(msg); for (const c of this.clients) c.sendRaw(s); }

  tick() {
    const g = this.g, G = this.G;
    try {
      if (g.over) {
        this.restartT += TICK;
        if (this.restartT > this.restartAfter) this.restartMatch();
      } else {
        g.step(TICK);
        // отсчёт до матча на «Вилле»
        if (this.phase === 'count' && (this.countT -= TICK) <= 0) this.pvpStart('match');
        else if (this.pvp && this.tickN % 30 === 0) this.pvpCheck();
      }
    } catch (e) { console.error('[room ' + this.code + ']', e && e.stack || e); }
    this.flushEvents();
    if (++this.tickN % SNAP_EVERY === 0) this.sendSnaps();
    if (this.held.size && this.tickN % 30 === 0) this.expireHeld();
    // пустая комната закрывается через минуту
    if (!this.clients.size) { this.emptyT += TICK; if (this.emptyT > 60) this.close(); } else this.emptyT = 0;
  }
  restartMatch() {
    this.restartT = 0;
    // «Вилла»: после матча — снова разминка; если все четверо на месте, она сразу перейдёт в отсчёт
    if (this.pvp) { this.pvpStart('warm'); return; }
    if (this.pub && this.mode !== 'duel' && MAPS.includes(this.map)) { const i = MAPS.indexOf(this.map); this.map = MAPS[(i + 1) % MAPS.length]; }
    this.g.start({ mode: this.mode, map: this.map, size: this.size, diff: this.diff });
    for (const c of this.clients) if (c.actor) c.send({ t: 'team', team: c.actor.team });
    this.flushEvents();
    this.sendRoster();
  }
  close() {
    clearInterval(this.timer);
    rooms.delete(this.code);
    for (const c of this.clients) { c.room = null; c.actor = null; }
    log('room closed', this.code);
  }

  // события симуляции → сообщения игрокам
  flushEvents() {
    const G = this.G, evs = G.events;
    if (!evs.length) return;
    const all = [], to = new Map();
    const push = (c, e) => { if (!to.has(c)) to.set(c, []); to.get(c).push(e); };
    const clientOf = (a) => { for (const c of this.clients) if (c.actor === a) return c; return null; };
    let roster = false;
    const dl = [];                  // события оружия на земле — только новым клиентам
    for (const [type, d] of evs) {
      switch (type) {
        case 'shot': {
          const e = ['shot', d.a.nid, d.w, d.mz, d.ends];
          if (d.net) { const sc = clientOf(d.a); for (const c of this.clients) if (c !== sc) push(c, e); }
          else all.push(e);
          break;
        }
        case 'melee': all.push(['mel', d.a.nid]); break;
        case 'hurt': {
          const e = ['hurt', d.v.nid, d.by ? d.by.nid : 0, Math.round(d.amt), d.head ? 1 : 0, d.wid];
          const vc = d.v.net && clientOf(d.v), bc = d.by && d.by.net && clientOf(d.by);
          if (vc) push(vc, e); if (bc && bc !== vc) push(bc, e);
          break;
        }
        case 'kill': all.push(['kill', d.k ? d.k.nid : 0, d.v.nid, d.w, d.head ? 1 : 0, d.k && d.k.net ? d.k.skinOf(d.w) : null]); break;
        case 'blood': all.push(['blood', r2(d.x), r2(d.y), r2(d.z), d.head ? 1 : 0]); break;
        case 'nadeSpawn': all.push(['nade', d.n.id, d.n.owner ? d.n.owner.nid : 0, d.n.type, d.o.map(r3), d.v.map(r3)]); break;
        case 'nadeBoom': all.push(['boom', d.n.id, d.n.type, r2(d.x), r2(d.y), r2(d.z), d.n.owner ? d.n.owner.nid : 0]); break;
        case 'blind': { const c = clientOf(d.a); if (c) push(c, ['blind', r2(d.T), r2(d.k)]); break; }
        case 'bp': { if (this.g.warm) break; const c = clientOf(d.a); if (c) push(c, ['bp', d.e]); break; } // разминка — без наград
        case 'spawn': all.push(['spawn', d.a.nid]); break;
        case 'roundStart': all.push(['round', d.round, d.pistol ? 1 : 0, d.half ? 1 : 0]); break;
        case 'duelRound': all.push(['dround', d.round, d.sc[0], d.sc[1]]); break;
        case 'duelTime': all.push(['dtime', d.w]); break;
        case 'live': all.push(['live']); break;
        case 'roundEnd': all.push(['rend', d.win, d.reason]); break;
        case 'planted': all.push(['plant', d.a.nid, d.site, r2(d.x), r2(d.z), r2(d.yaw)]); break;
        case 'defused': all.push(['defused', d.a.nid]); break;
        case 'exploded': all.push(['expl', r2(d.x), r2(d.z)]); break;
        case 'bombPick': all.push(['pick', d.a.nid]); break;
        case 'halftime': all.push(['half']); roster = true; break;
        case 'matchStart': all.push(['mstart', this.g.mode, this.g.mapId, this.g.warm ? 1 : 0]); roster = true; break; // разминка «Виллы» — TDM (4-е поле = 1), матч — режим комнаты
        case 'matchEnd': all.push(['mend', d.win, d.sc, d.forfeit ? 1 : 0]); break;
        case 'leave': all.push(['gone', d.a.nid]); break;
        case 'dropAdd': case 'dropDel': case 'dropClear': this.dropV++; break;
        case 'dropTake': { const st = d.d.st; dl.push(['dtake', d.a.nid, d.d.id, d.slot, st.id, st.skin || null, st.wear || 0, st.mag, st.reserve]); break; }
      }
    }
    evs.length = 0;
    for (const c of this.clients) {
      const mine = to.get(c);
      let l = mine ? all.concat(mine) : all;
      if (dl.length && c.profile && c.profile.drops) l = l.concat(dl);
      if (l.length) c.send({ t: 'ev', l });
    }
    if (roster) this.sendRoster();
  }

  sendSnaps() {
    const g = this.g, G = this.G, time = g.time;
    const A = g.actors.map(a => {
      let f = (a.alive ? 1 : 0) | (a.using || (a.net && a.netUse) ? 4 : 0) | (a.hasBomb ? 8 : 0) | (a.scoped ? 16 : 0) | (a.onGround ? 64 : 0) | (a.w && a.w.reloadT > 0 ? 128 : 0);
      const row = [a.nid, r2(a.pos.x), r2(a.pos.y), r2(a.pos.z), r3(a.yaw), r3(a.pitch), f, a.w ? a.w.id : 'knife', Math.ceil(a.hp), Math.round(a.crouchT * 10), a.team, a.spottedUntil > time ? (a.spottedBy == null ? -1 : a.spottedBy) : -2];
      // скин оружия в руках (1.5): виден при наблюдении от первого лица; старые клиенты лишнее поле не читают
      if (a.w && a.w.skin) row.push(a.w.skin, a.w.wear || 0);
      return row;
    });
    let gs;
    if (g.mode === 'bomb') {
      const B = G.bombMode, b = B.bomb;
      gs = { m: 'bomb', ph: B.phase, t: r2(B.t), r: B.round, sc: B.score, bs: b ? b.state : 'none', bx: b ? r2(b.pos.x) : 0, bz: b ? r2(b.pos.z) : 0, bc: b && b.carrier ? b.carrier.nid : 0, buyT: r2(B.buyT), dn: B.defuser ? B.defuser.nid : 0, dp: B.defuser ? r2(B.defuseT / B.defuseNeed(B.defuser)) : 0, pn: B.planter ? B.planter.nid : 0, pp: B.planter ? r2(B.plantT / B.PLANT) : 0, max: B.MAX, win: B.WIN };
    } else if (g.mode === 'duel') {
      const D = G.duelMode;
      gs = { m: 'duel', sc: g.scores, tl: Math.max(0, Math.round(g.timeLeft)), kl: g.killLimit, fz: g.frozen ? 1 : 0, rd: D.round, ph: D.phase, dt: r2(Math.max(0, D.t)) };
    } else gs = { m: g.mode, sc: g.scores, tl: Math.max(0, Math.round(g.timeLeft)), kl: g.killLimit };
    gs.over = g.over ? 1 : 0;
    // «Вилла» (1.6): разминка — [людей, нужно, секунд до матча (0 — ждём)]; старые клиенты поле не читают
    if (this.pvp && this.phase !== 'match' && !g.over) gs.wu = [this.seats(), PVP_NEED, this.phase === 'count' ? Math.max(1, Math.ceil(this.countT)) : 0];
    const stats = g.actors.map(a => [a.nid, a.kills, a.deaths, a.hs, a.money]);
    const base = { t: 'snap', s: r3(time), a: A, g: gs };
    const statStr = this.tickN % 30 === 0 ? stats : null;
    // оружие на земле: [id, оружие, скин, износ, x, y, z, поворот, чей (nid), возраст] — только когда список изменился (и раз в 2 с)
    let drops = null;
    const dropList = () => drops || (drops = G.drops ? G.drops.list.map(d => [d.id, d.st.id, d.st.skin || null, d.st.wear || 0, r2(d.pos.x), r2(d.pos.y), r2(d.pos.z), r3(d.yaw), d.owner && d.owner.nid || 0, Math.round(d.t * 10) / 10]) : []);
    for (const c of this.clients) {
      const p = c.actor; if (!p) continue;
      const sl = {};
      for (const k of ['primary', 'secondary', 'melee']) { const st = p.slots[k]; sl[k] = st ? [st.id, st.skin || null, st.wear || 0, st.mag, st.reserve] : null; }
      const me = { tp: p.tp, x: r2(p.pos.x), y: r2(p.pos.y), z: r2(p.pos.z), yw: r3(p.yaw), al: p.alive ? 1 : 0, hp: Math.ceil(p.hp), ar: Math.ceil(p.armor), hm: p.helmet ? 1 : 0, kit: p.kit ? 1 : 0, $: p.money, n: [p.nades.he | 0, p.nades.flash | 0, p.nades.smoke | 0], sl, team: p.team, bomb: p.hasBomb ? 1 : 0, k: p.kills, d: p.deaths, hs: p.hs, pr: p.protect > 0 ? 1 : 0 };
      if (g.mode === 'bomb') me.buy = G.bombMode.canBuy(p) ? 1 : 0;
      const msg = Object.assign({ me }, base);
      if (statStr) msg.st = statStr;
      const wantDrops = c.profile && c.profile.drops && G.drops && (c.dropV !== this.dropV || (statStr && G.drops.list.length));
      if (wantDrops) msg.dr = dropList();
      // медленному соединению не досылаем лишнего — следующий снимок всё равно новее
      if (c.ws.backlog > 256 * 1024) continue;
      c.send(msg);
      if (wantDrops) c.dropV = this.dropV;
    }
  }

  // ---------- сообщения от игрока ----------
  onMsg(c, m) {
    const p = c.actor, g = this.g;
    if (!p) return;
    switch (m.t) {
      case 'st': if (Array.isArray(m.p)) g.netState(p, m); break;
      case 'shot': if (Array.isArray(m.o) && Array.isArray(m.d)) { const r = g.netShot(p, m); if (r && r.hit) c.send({ t: 'hit', h: 1, hd: r.head ? 1 : 0, k: r.kill ? 1 : 0 }); } break;
      case 'mel': { const r = g.netMelee(p, m); if (r && r.hit) c.send({ t: 'hit', h: 1, hd: r.head ? 1 : 0, k: r.kill ? 1 : 0 }); break; }
      case 'nade': if (Array.isArray(m.o) && Array.isArray(m.v)) g.netNade(p, m); break;
      case 'rl': g.netReload(p, String(m.s)); break;
      case 'buy': g.netBuy(p, m.id); break;
      case 'prim': if (this.G.PRIMARIES.includes(m.w)) p.nextPrimary = m.w; break;
      case 'take': if (g.netTake) g.netTake(p, m.id); break;      // подобрать оружие с земли (1.5)
      case 'toss': if (g.netToss) g.netToss(p, String(m.s)); break; // выбросить оружие из рук (1.5)
      case 'chat': {
        const text = cleanText(m.m); if (!text) break;
        const now = Date.now();
        if (now - (c.chatT || 0) < 700) break;
        c.chatT = now;
        const e = { t: 'ev', l: [['chat', p.nid, text, m.team ? 1 : 0]] }, s = JSON.stringify(e);
        for (const o of this.clients) if (!m.team || (o.actor && o.actor.team === p.team)) o.sendRaw(s);
        break;
      }
    }
    this.flushEvents();
  }
}

// ---------- соединения ----------
function onConn(ws) {
  if (conns.size >= MAX_CONN) { ws.close(1013, 'full'); return; }
  const c = { id: ++connSeq, ws, room: null, actor: null, name: 'Игрок', profile: {}, msgN: 0, msgT: Date.now(), hello: false };
  c.sendRaw = (s) => ws.send(s);
  c.send = (o) => ws.send(JSON.stringify(o));
  conns.add(c);
  ws.on('message', (raw) => {
    // защита от спама сообщениями
    const now = Date.now();
    if (now - c.msgT > 1000) { c.msgT = now; c.msgN = 0; }
    if (++c.msgN > 150) { if (c.msgN > 400) ws.close(1008, 'flood'); return; }
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    try { handle(c, m); } catch (e) { console.error('[msg]', e && e.stack || e); }
  });
  ws.on('close', () => { if (c.room) c.room.drop(c); conns.delete(c); });
}

function handle(c, m) {
  // проверка канала: ответ больше 16 КБ — если провайдер обрезает соединения (как в России с зарубежными серверами), он не дойдёт
  if (m.t === 'probe') { if ((c.probes = (c.probes || 0) + 1) <= 3) { const n = Math.max(1000, Math.min(40000, m.n | 0 || 24000)); c.send({ t: 'probe', n, d: 'x'.repeat(n) }); } return; }
  if (m.t === 'ping') { c.send({ t: 'pong', c: m.c, s: c.room ? r3(c.room.g.time) : 0 }); return; }
  if (m.t === 'hello') {
    if (m.v !== PROTO) { c.send({ t: 'err', code: 'version', m: 'Нужна новая версия игры' }); return; }
    // 1.8: новые стволы (Galil, FAMAS, SSG 08, Five-SeveN, Tec-9) старые версии игры не знают — нужна 11.9+
    if (!((m.cv | 0) >= MIN_CV)) { c.send({ t: 'err', code: 'version', m: 'Вышло обновление Prodigy Strike — установите новую версию игры, чтобы играть по сети' }); return; }
    c.hello = true;
    c.name = cleanName(m.name);
    c.key = String(m.key || '').replace(/[^a-z0-9]/g, '').slice(0, 24) || null;
    const skins = {};
    if (m.skins && typeof m.skins === 'object') for (const k of Object.keys(m.skins).slice(0, 20)) { const v = m.skins[k]; if (Array.isArray(v)) skins[String(k).slice(0, 12)] = [String(v[0]).slice(0, 40), v[1] | 0]; }
    c.profile = { skins, knife: Array.isArray(m.knife) ? [String(m.knife[0]).slice(0, 12), m.knife[1] ? String(m.knife[1]).slice(0, 40) : null, m.knife[2] | 0] : null, gloves: Array.isArray(m.gloves) ? [String(m.gloves[0]).slice(0, 40), m.gloves[1] | 0] : null, prim: String(m.prim || 'ar'), drops: m.drops ? 1 : 0 };
    c.send({ t: 'welcome', id: c.id, srv: VERSION, online: conns.size, rooms: rooms.size });
    return;
  }
  if (!c.hello) return;
  if (m.t === 'quick' || m.t === 'create' || m.t === 'join') c.side = m.side === 'ct' || m.side === 't' ? m.side : 'auto';
  switch (m.t) {
    case 'list': c.send({ t: 'rooms', list: [...rooms.values()].filter(r => r.pub).map(r => r.info()), online: conns.size }); return;
    case 'quick': {
      if (c.room) c.room.leave(c);
      const map0 = okMap(m.map) ? m.map : null;
      const mode = MODES.includes(m.mode) ? m.mode : SMALL.includes(map0) ? 'bomb' : 'tdm';
      const map = mode === 'duel' ? DUEL_MAP : map0;
      // открытая комната с этим режимом, где есть место, — иначе новая
      let best = null;
      // этот телефон недавно выпал из открытого матча — вернуть туда же
      for (const r of rooms.values()) if (r.pub && r.mode === mode && c.key && r.held.has(c.key) && !r.g.over) { best = r; break; }
      if (!best) for (const r of rooms.values()) {
        if (!r.pub || r.mode !== mode || (map && r.map !== map) || (!map && SMALL.includes(r.map)) || r.g.over) continue;
        if (r.pvp) {
          // «Вилла»: где больше людей; при равенстве — где ещё разминка
          const h = r.seats();
          if (h >= r.size * 2) continue;
          const sc = h * 2 + (r.phase !== 'match' ? 1 : 0);
          if (!best || sc > best.seats() * 2 + (best.phase !== 'match' ? 1 : 0)) best = r;
          continue;
        }
        const h = r.humans().length;
        if (h >= r.size * 2) continue;
        if (!best || h > best.humans().length) best = r;
      }
      if (!best) {
        if (rooms.size >= MAX_ROOMS) { c.send({ t: 'err', m: 'Сервер заполнен, попробуйте позже' }); return; }
        best = new Room({ pub: true, mode, map: map || undefined, size: mode === 'duel' ? 1 : 5, diff: 'normal' });
      }
      if (!best.join(c)) c.send({ t: 'err', m: 'Комната заполнена' });
      return;
    }
    case 'create': {
      if (c.room) c.room.leave(c);
      if (rooms.size >= MAX_ROOMS) { c.send({ t: 'err', m: 'Сервер заполнен, попробуйте позже' }); return; }
      const r = new Room({ pub: false, mode: m.mode, map: m.map, size: m.size, diff: m.diff });
      r.join(c);
      return;
    }
    case 'join': {
      const code = String(m.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
      const r = rooms.get(code);
      if (!r) { c.send({ t: 'err', m: 'Комната ' + (code || '') + ' не найдена' }); return; }
      if (c.room === r) return;
      if (c.room) c.room.leave(c);
      if (!r.join(c)) c.send({ t: 'err', m: 'Комната заполнена' });
      return;
    }
    case 'leave': if (c.room) c.room.leave(c); c.send({ t: 'left' }); return;
  }
  if (c.room) c.room.onMsg(c, m);
}

const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('ok'); return; }
  // проверка из браузера: 64 КБ текста. Дошло до последней строки — провайдер связь не обрезает
  if (url === '/probe') {
    const line = 'Prodigy Strike · проверка связи · ' + '='.repeat(60) + '\n';
    let body = 'Проверка связи с сервером Prodigy Strike. Если внизу появилась строка «ГОТОВО» — всё в порядке.\n\n';
    while (Buffer.byteLength(body) < 65536) body += line;
    body += '\nГОТОВО: связь с сервером в порядке, данные дошли целиком (' + Math.round(Buffer.byteLength(body) / 1024) + ' КБ).\n';
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
    return;
  }
  if (url === '/robots.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('User-agent: *\nAllow: /\n'); return; }
  if (url === '/stats') {
    const list = [...rooms.values()].map(r => ({ id: r.pub ? r.code : '••••', pub: r.pub, mode: r.mode, map: r.g.mapId || r.map, phase: r.phase, players: r.clients.size, waiting: r.held.size, bots: r.g.actors.filter(a => !a.net).length, score: r.mode === 'bomb' ? r.G.bombMode.score : r.g.scores, over: r.g.over }));
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify({ version: VERSION, uptimeMin: Math.round((Date.now() - STARTED) / 60000), online: conns.size, rooms: list, memMB: Math.round(process.memoryUsage().rss / 1048576) }, null, 1));
    return;
  }
  const players = [...rooms.values()].reduce((s, r) => s + r.clients.size, 0);
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify({ name: 'Prodigy Strike', ok: true, version: VERSION, proto: PROTO, rooms: rooms.size, players, online: conns.size }));
});
attach(server, '/ws', onConn);
// соединения, которые молчат дольше 30 секунд, закрываем (телефон ушёл из сети)
setInterval(() => {
  const now = Date.now();
  for (const c of conns) {
    if (now - c.ws.lastSeen > 45000) c.ws.close(1001, 'timeout');
    else if (now - c.ws.lastSeen > 10000) c.ws.ping(); // браузер ответит сам, даже если вкладка в фоне
  }
}, 5000);
server.listen(PORT, () => log('Strike Zone server', VERSION, 'on port', PORT));
process.on('uncaughtException', (e) => console.error('[uncaught]', e && e.stack || e));
