'use strict';
/* Prodigy Strike (бывш. Strike Zone) — онлайн-сервер: комнаты, быстрый поиск матча, комнаты по коду,
   аккаунты (регистрация, аватары, медали), кланы, «Напарники» — рейтинговые матчи 2×2, клановые войны и админ-панель (/admin).
   Матч целиком считается здесь (боты, раунды, бомба, попадания); телефоны присылают движение и выстрелы. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { attach } = require('./lib/ws');
const { createSim } = require('./sim/loader');
const { openDb } = require('./lib/db');
const A = require('./lib/accounts');
const { createClans } = require('./lib/clans');
const { createMM } = require('./lib/mm');
const { createAdmin } = require('./lib/admin');
const { createProfile } = require('./lib/profile');
const { createLobbies } = require('./lib/lobby');
const { loadGameData } = require('./lib/gamedata');
const { createEconomy } = require('./lib/economy');
const { createMarket } = require('./lib/market');
const { marketRoutes } = require('./lib/adminmarket');
const { createFriends } = require('./lib/friends');

const PORT = +process.env.PORT || 8080;
const MIN_CV = 200; // минимальная версия игры (2.0): аккаунты, рейтинг 2×2, «Лагуна», подарки
const PROTO = 1;
const VERSION = '2.4.0';
const FRIENDS_CV = 240;           // 2.4: друзья, пати «Напарники», код прицела — игра 2.4 (cv >= 240)
const XH_RE = /^PS-[0-9A-HJKMNP-TV-Z]{6}-[0-9A-HJKMNP-TV-Z]{6}-[0-9A-HJKMNP-TV-Z]{6}$/;   // 2.4: код прицела (js/xhair.js)
const cleanXh = (v) => (typeof v === 'string' && v.length <= 24 && XH_RE.test(v) ? v : null);
const CLOUD_CV = 230;            // 2.3: облачный инвентарь и рынок — только у игры 2.3 (cv >= 230); старые игры живут с локальным инвентарём
const HOLD_MS = 40000;          // столько ждём игрока после обрыва связи, прежде чем отдать его место боту
const RANKED_HOLD_MS = +process.env.SZ_RANKED_HOLD_MS || 120000; // в рейтинговом матче ждём дольше (ботов там нет)
const RANKED_RULES = { WIN: 9, HALF: 8, MAX: 16, ROUND: 100 };
const RANKED_CLOSE_S = +process.env.SZ_RANKED_CLOSE_S || 20;      // рейтинговая комната закрывается через 20 с после конца матча
const LOBBY_BACK_S = +process.env.SZ_LOBBY_BACK_S || 12;           // 2.2: матч лобби окончен — через 12 с все снова в лобби
const OT_MONEY = 10000;                                             // 2.2: деньги в начале каждой половины овертайма (лобби)
// 2.0: разминка в начале каждого рейтингового матча (SZ_RANKED_WARM_S — для автотестов, 0 — без разминки)
const RANKED_WARM_S = process.env.SZ_RANKED_WARM_S != null && process.env.SZ_RANKED_WARM_S !== '' ? Math.max(0, +process.env.SZ_RANKED_WARM_S || 0) : 30;
const WARM_MONEY = 16000;        // деньги на разминке рейтингового матча (покупка где угодно)
const STARTED = Date.now();
const TICK = 1 / 30;             // шаг симуляции
const SNAP_EVERY = 2;            // снимок состояния каждые 2 шага (15 раз в секунду)
const MAX_ROOMS = 30, MAX_CONN = 200;
const CONN_PER_IP = +process.env.SZ_CONN_PER_IP || 24;   // соединений с одного адреса (мобильные сети: много игроков за одним адресом)
// карты, которые есть в загруженных игровых модулях (новая карта может ещё не прийти из игры — тогда её просто нет в списках)
const MAP_META = (() => { try { const M = createSim().G.MAPS; return Object.keys(M).map(id => ({ id, name: M[id].name, duel: !!M[id].duel, small: !!M[id].small, hidden: !!M[id].hidden })); } catch (e) { console.error('[maps]', e && e.stack || e); return []; } })();
const KNOWN_MAPS = MAP_META.map(m => m.id);
const hasMap = (m) => KNOWN_MAPS.includes(m);
const MAPS = (() => { const l = ['harbor', 'sakura', 'dust'].filter(hasMap); return l.length ? l : ['harbor']; })(); // 5 на 5 по кругу
const SMALL = ['villa', 'lagoon'].filter(hasMap);  // 2 на 2 — только по прямому выбору, только живые игроки (разминка до 4)
const RANKED_MAPS = (() => { const l = ['villa', 'lagoon'].filter(hasMap); return l.length ? l : [SMALL[0] || MAPS[0]]; })(); // «Рейтинг 2×2»
const PVP_NEED = 4;                  // столько людей нужно, чтобы на карте 2 на 2 начался матч (до этого — разминка)
const PVP_COUNT = 5;                 // отсчёт перед матчем, с
const DUEL_MAP = 'winter';
const okMap = (m) => typeof m === 'string' && (MAPS.includes(m) || SMALL.includes(m) || m === DUEL_MAP);
// карта 2 на 2, которой нет в этой сборке сервера (например, «Лагуна» ещё не пришла из игры), — заменяется другой картой 2 на 2
const mapOf = (m) => (okMap(m) ? m : ['villa', 'lagoon'].includes(m) && SMALL.length ? SMALL[0] : null);
const MODES = ['tdm', 'bomb', 'duel'];
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
// пароль админки: data/admin.json (если владелец сменил пароль на сервере — переживает обновления), иначе admin.json из репозитория
const ADMIN_FILE = () => process.env.ADMIN_FILE || (fs.existsSync(path.join(DATA_DIR, 'admin.json')) ? path.join(DATA_DIR, 'admin.json') : path.join(__dirname, 'admin.json'));
const TEST_HOOKS = process.env.SZ_TEST_HOOKS === '1';   // только для автотестов

const rooms = new Map();
const conns = new Set();
const accConns = new Map();      // аккаунт → его соединения
let connSeq = 0;

// журнал: в консоль и в кольцевой буфер последних 300 строк (раздел «Журнал» админки)
const logLines = [];
const fmtArg = (x) => (typeof x === 'string' ? x : x === undefined ? 'undefined' : typeof x === 'number' ? String(x) : (() => { try { return JSON.stringify(x); } catch (e) { return String(x); } })());
function remember(line) { logLines.push(line.length > 600 ? line.slice(0, 600) + '…' : line); if (logLines.length > 300) logLines.splice(0, logLines.length - 300); }
const stamp = () => new Date().toISOString().slice(11, 19);
const log = (...a) => { const t = stamp(); console.log(t, ...a); remember(t + ' ' + a.map(fmtArg).join(' ')); };
const logErr = (...a) => { console.error(...a); remember(stamp() + ' ' + a.map(fmtArg).join(' ')); };

const db = openDb(DATA_DIR, log);
// 2.3: облачный инвентарь и рынок (данные экономики — из файлов игры в game/, хранение — data/eco.json, журнал — data/trades.log)
const gd = loadGameData({ log });
const eco = createEconomy({ gd, dir: DATA_DIR, log, db, conns: (id) => accConns.get(id), rankRewards: A.RANK_REWARDS, onMigrated: (a) => onMigrated(a), mkcfg: () => market.cfg() });
const market = createMarket(eco, { gd, log, db, conns: (id) => accConns.get(id) });
const isCloudConn = (c) => (c.cv | 0) >= CLOUD_CV;

function newCode() {
  for (; ;) {
    let c = ''; for (let i = 0; i < 4; i++) c += CODE_ABC[Math.floor(Math.random() * CODE_ABC.length)];
    if (!rooms.has(c)) return c;
  }
}
const r2 = (v) => Math.round(v * 100) / 100;
const r3 = (v) => Math.round(v * 1000) / 1000;
const cleanName = (s) => String(s || 'Игрок').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 14) || 'Игрок';
const cleanText = (s) => String(s || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 90);
// проверка сообщений от телефона: числа конечные, векторы из трёх чисел, слоты оружия только из списка
const SLOTS = ['primary', 'secondary', 'melee', 'nade'];
const finite = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
const vec3 = (v) => Array.isArray(v) && v.length >= 3 && v.length <= 4 && Number.isFinite(v[0]) && Number.isFinite(v[1]) && Number.isFinite(v[2]);
function validSt(m) {
  if (!vec3(m.p)) return false;
  if (m.v != null && !vec3(m.v)) m.v = null;
  if (m.cur != null && !SLOTS.includes(m.cur)) m.cur = null;
  m.yw = finite(m.yw); m.pt = finite(m.pt); m.ct = finite(m.ct);
  return true;
}
function validShot(m) {
  if ((m.s !== 'primary' && m.s !== 'secondary') || typeof m.w !== 'string' || m.w.length > 16 || !vec3(m.o) || !Array.isArray(m.d) || m.d.length > 64) return false;
  m.lag = finite(m.lag);
  return true;
}
const holdKey = (c) => c.key || (c.acc ? 'acc:' + c.acc.id : null);
const clanOf = (accId) => { const a = accId && db.data.accounts[accId]; return a && a.clan ? db.data.clans[a.clan] || null : null; };

// карта рейтингового матча: случайная из RANKED_MAPS, не та же, что в прошлом матче этой очереди (если карт больше одной)
const lastRankedMap = {};
function pickRankedMap(kind) {
  let l = RANKED_MAPS;
  if (l.length > 1 && lastRankedMap[kind]) l = l.filter(m => m !== lastRankedMap[kind]);
  const m = l[Math.floor(Math.random() * l.length)];
  lastRankedMap[kind] = m;
  return m;
}

// ---------- комната ----------
class Room {
  constructor(opts) {
    this.code = newCode();
    opts = Object.assign({}, opts, { map: mapOf(opts.map) });
    this.match = opts.match || null;           // рейтинговый матч / клановая война: составы, кланы
    this.ranked = this.match ? this.match.kind : null;
    // 2.2: матч кастомного лобби — составы и правила задал хост лобби, после матча все возвращаются в лобби
    const L = this.lobby = opts.lobby || null;
    this.fixed = !!(this.ranked || L);         // составы заданы заранее (рейтинг, клановая война, лобби)
    this.pub = !this.fixed && !!opts.pub;
    this.mode = this.ranked ? 'bomb' : L ? L.mode : MODES.includes(opts.mode) ? opts.mode : opts.map === DUEL_MAP ? 'duel' : SMALL.includes(opts.map) ? 'bomb' : 'tdm';
    this.map = this.ranked ? this.match.map : L ? (L.mode === 'duel' ? DUEL_MAP : L.map) : this.mode === 'duel' ? DUEL_MAP : okMap(opts.map) && opts.map !== DUEL_MAP ? opts.map : MAPS[Math.floor(Math.random() * MAPS.length)];
    // карты 2 на 2 (1.6): только люди; пока не собрались четверо — разминка
    this.pvp = !this.fixed && this.mode !== 'duel' && SMALL.includes(this.map);
    // warm — разминка, count — отсчёт до матча, match — матч. Рейтинговый матч (2.0) начинается с разминки на RANKED_WARM_S секунд,
    // матч лобби (2.2) — только если хост включил разминку
    this.phase = this.pvp || (this.ranked && RANKED_WARM_S > 0) || (L && L.opts.warm > 0) ? 'warm' : 'match';
    this.countT = 0; this.restartAfter = 12; this.warmT = L ? L.opts.warm : RANKED_WARM_S;
    this.cost = 0; this.costN = 0;  // сколько мс занимает шаг комнаты (среднее) — для админки и замеров
    this.size = this.ranked ? 2 : L ? (this.mode === 'duel' ? 1 : L.size) : this.mode === 'duel' ? 1 : SMALL.includes(this.map) ? 2 : Math.max(2, Math.min(5, opts.size | 0 || 5));
    this.diff = L ? L.opts.diff : ['easy', 'normal', 'hard'].includes(opts.diff) ? opts.diff : 'normal';
    this.holdMs = this.fixed ? RANKED_HOLD_MS : HOLD_MS;
    this.otN = 0; this.otStart = 0;
    this.clients = new Set();
    this.held = new Map();          // ключ телефона → игрок, у которого оборвалась связь
    this.sim = createSim();
    this.G = this.sim.G;
    this.g = this.G.game;
    this.swapped = false; this.settled = false; this.closed = false; this.begun = false; this.closeT = 0;
    if (L && this.mode === 'bomb' && L.opts.ot) this.installOT();
    this.startMatch();
    this.G.events.length = 0;
    this.tickN = 0; this.emptyT = 0; this.restartT = 0;
    this.dropV = 0;                 // версия списка оружия на земле: изменилась — новый список в снимке
    this.timer = setInterval(() => this.tick(), TICK * 1000);
    rooms.set(this.code, this);
    log('room', this.code, this.ranked || (L ? 'lobby ' + L.code : this.pub ? 'public' : 'private'), this.mode, this.map);
  }
  startMatch() {
    if (this.ranked) Object.assign(this.G.bombMode, RANKED_RULES);
    if (this.lobby) this.lobbyRules();
    this.swapped = false; this.otN = 0; this.otStart = 0;
    this.g.start(this.startOpts());
    if (this.lobby && !this.g.warm && this.mode === 'tdm') { const o = this.lobby.opts; this.g.killLimit = o.kills; this.g.timeLeft = o.time * 60; }
  }
  // 2.2: правила матча лобби: побед до конца (половина — за раунд до), заморозка и время покупки; дуэль — побед до конца
  lobbyRules() {
    const o = this.lobby.opts, B = this.G.bombMode, W = o.win | 0 || 7;
    if (this.mode === 'bomb') Object.assign(B, { WIN: W, HALF: W - 1, MAX: 2 * W - 2, FREEZE: o.freeze, BUY: Math.max(o.buy, o.freeze + 5) });
    if (this.mode === 'duel') this.G.duelMode.WIN = W;
  }
  // 2.2: овертайм (лобби): ничья после всех раундов — ещё 6 раундов (MR3, стороны меняются через 3), побеждает набравший 4;
  // снова ничья — ещё овертайм. В начале каждой половины овертайма у всех OT_MONEY
  installOT() {
    const B = this.G.bombMode, room = this, endRound = B.endRound, startRound = B.startRound;
    B.endRound = function (win, reason) {
      endRound.call(this, win, reason);
      if (this.matchOver && this.score[0] === this.score[1] && this.round >= this.MAX) {
        this.matchOver = false;
        room.otN++; room.otStart = this.round;
        this.MAX = this.round + 6; this.WIN = this.score[0] + 4;
        room.sysLater('Ничья ' + this.score[0] + ' : ' + this.score[1] + ' — овертайм' + (room.otN > 1 ? ' ' + room.otN : '') + '! 6 раундов, до ' + this.WIN + ' побед, у всех $' + OT_MONEY);
      }
    };
    B.startRound = function () {
      if (room.otN && this.round === room.otStart + 3) this.halftime();
      if (room.otN && (this.round === room.otStart || this.round === room.otStart + 3)) for (const a of this.g.actors) a.money = OT_MONEY;
      return startRound.call(this);
    };
  }
  // системная строка после ближайшей рассылки событий (чтобы шла после «конец раунда»)
  sysLater(text) { (this.sysQ || (this.sysQ = [])).push(text); }
  // разминка рейтингового матча (и матча лобби) идёт: возрождение, покупка где угодно, 16000 $
  rwarm() { return this.fixed && this.phase === 'warm' && !this.g.over; }
  humans() { return [...this.clients].filter(c => c.actor); }
  // люди в матче, включая тех, у кого оборвалась связь (их место ждёт)
  seats() { return this.g.actors.filter(a => a.net).length; }
  startOpts() {
    const L = this.lobby;
    return { mode: this.mode, map: this.map, size: this.size, diff: this.diff, noBots: this.pvp || !!this.ranked || (!!L && !L.opts.bots), warm: (this.pvp || this.fixed) && this.phase !== 'match', fixedTeams: this.fixed, bots: !!(L && L.opts.bots), minSize: L ? 1 : 2 };
  }
  info() {
    const o = { code: this.pub ? null : this.code, id: this.code, pub: this.pub, mode: this.mode, map: this.map, size: this.size, diff: this.diff, players: this.pvp ? this.seats() : this.clients.size, max: this.size * 2 };
    if (this.pvp) { o.pvp = 1; if (this.phase !== 'match') o.st = 'warm'; } // «только игроки», «разминка»
    return o;
  }
  // что сказать игроку при входе: сейчас идёт режим mode (разминка — всегда TDM), матч в комнате — rmode
  joinMsg(p, extra) {
    return Object.assign({ t: 'joined', code: this.code, pub: this.pub, mode: this.g.mode, map: this.map, size: this.size, diff: this.diff, you: p ? p.nid : 0, team: p ? p.team : 0 },
      this.pvp || this.ranked ? { pvp: 1, rmode: this.mode } : null, this.ranked ? { ranked: this.ranked } : null,
      // 2.2: матч лобби — код лобби, режим матча, названия сторон [спецназ, налётчики] сейчас; наблюдатель — spec: 1 (без бойца)
      this.lobby ? { lobby: this.lobby.code, rmode: this.mode, tn: this.lobby.teamNames(this) } : null, extra);
  }
  joinFor(c) { return this.joinMsg(c.actor, c.spec ? { spec: 1 } : null); }
  // команды рейтингового матча: состав 0/1 и сторона в игре (после смены сторон они меняются местами)
  squadOf(accId) { const M = this.match; return !M || !accId ? -1 : M.squads[0].includes(accId) ? 0 : M.squads[1].includes(accId) ? 1 : -1; }
  teamOfSquad(s) { return this.swapped ? 1 - s : s; }
  squadOfTeam(t) { return this.swapped ? 1 - t : t; }
  // можно ли войти по коду: в рейтинговый матч — только его участникам
  canEnter(c) {
    if (this.lobby) return this.lobbyMember(c) != null; // матч лобби — только участники этого лобби (и вернувшиеся после обрыва)
    if (!this.ranked) return true;
    const k = holdKey(c);
    if (k && this.held.has(k)) return true;
    return !!(c.acc && this.squadOf(c.acc.id) >= 0);
  }
  join(c) {
    // тот же телефон вернулся после обрыва — отдаём ему его же игрока (место, оружие, счёт)
    const back = this.reclaim(c);
    if (back) {
      const p = back, g = this.g;
      c.room = this; c.actor = p; this.clients.add(c); c.dropV = -1;
      p.ops = c.ops || null; p.xh = c.xh || null; // 2.1: оперативники могли смениться, пока игрок был не в сети
      p.tp++; p.lastStT = g.time; p.lastX = p.pos.x; p.lastZ = p.pos.z; p.netUse = false;
      p.noDrops = !(c.profile && c.profile.drops); // могли вернуться с другой версии игры
      c.send(this.joinMsg(p, { resumed: 1 }));
      this.flushEvents();
      this.sendRoster();
      this.chatSys(p.name + ' вернулся');
      log('resume', this.code, p.name, 'humans', this.clients.size);
      this.pvpCheck();
      if (this.lobby) this.lobby.touch();
      return true;
    }
    const info = Object.assign({}, c.profile, { side: c.side || 'auto' });
    if (this.ranked) {
      const s = c.acc ? this.squadOf(c.acc.id) : -1;
      if (s < 0 || this.g.over) return false;
      info.team = this.teamOfSquad(s); info.squad = s;
    } else if (this.lobby) {
      const mem = this.lobbyMember(c);
      if (!mem) return false;
      if (mem.side === 'spec') return this.addSpec(c);
      if (this.g.over) return false;
      const s = mem.side === 'ct' ? 0 : 1;
      info.team = this.teamOfSquad(s); info.squad = s;
    }
    const p = this.g.addHuman(this.uniqueName(c.name), info);
    if (!p) return false;
    p.accId = c.acc ? c.acc.id : null;
    p.ops = c.ops || null; p.xh = c.xh || null; // 2.1: оперативники игрока
    c.room = this; c.actor = p; this.clients.add(c); c.dropV = -1; // первый же снимок принесёт оружие на земле
    c.send(this.joinMsg(p));
    this.flushEvents();
    this.sendRoster();
    this.chatSys(p.name + ' в игре');
    const note = p.joinNote;
    if (note && note.startsWith('bot:')) c.send({ t: 'ev', l: [['sys', 'Вы заняли место бота ' + note.slice(4) + ' — в бой!']] });
    else if (note === 'wait') c.send({ t: 'ev', l: [['sys', 'Раунд уже идёт — вы появитесь в следующем раунде']] });
    else if (note === 'duel') this.chatSys(this.clients.size >= 2 ? 'Соперник найден — дуэль начинается заново!' : 'Соперника пока нет — разминка с ботом. Пришлите другу код комнаты ' + this.code);
    if (this.pvp && this.phase !== 'match') c.send({ t: 'ev', l: [['sys', 'Разминка: матч 2 на 2 начнётся, когда соберутся ' + PVP_NEED + ' игрока' + (this.pub ? '' : ' · код комнаты ' + this.code)]] });
    log('join', this.code, p.name, 'team', p.team, 'humans', this.clients.size, note || '');
    this.pvpCheck();
    if (this.lobby) this.lobby.touch();
    return true;
  }
  // 2.2: участник лобби этой комнаты (тот же телефон или аккаунт после обрыва — снова привязывается к лобби)
  lobbyMember(c) {
    const L = this.lobby; if (!L || L.dead) return null;
    let mem = L.memberOf(c);
    if (!mem) {
      mem = L.findReturning(c);
      // место свободно (старое соединение закрыто) или это тот же телефон (сеть сменилась, старое ещё не отвалилось)
      if (mem && (!mem.c || mem.c === c || !conns.has(mem.c) || (c.key && mem.key === c.key))) {
        const old = mem.c;
        if (old && old !== c) { if (old.lobby === L) old.lobby = null; old.send({ t: 'lobby_left', code: L.code, why: 'replaced' }); }
        if (c.lobby && c.lobby !== L) lobbyHub.leave(c, 'quiet');
        L.attach(c, mem); L.touch();
      } else mem = null;
    }
    return mem;
  }
  // 2.2: игрок лобби в матч: сторона squad (0 — начинал за спецназ, 1 — за налётчиков); joined придёт в begin()
  addLobby(c, s) {
    const p = this.g.addHuman(this.uniqueName(c.name), Object.assign({}, c.profile, { team: this.teamOfSquad(s), squad: s }));
    if (!p) return false;
    p.accId = c.acc ? c.acc.id : null;
    p.ops = c.ops || null; p.xh = c.xh || null;
    c.room = this; c.actor = p; c.spec = false; this.clients.add(c); c.dropV = -1;
    return true;
  }
  // 2.2: наблюдатель — без бойца (его нет ни в ростере, ни в счёте), получает снимки с полной информацией обо всех
  addSpec(c, silent) {
    c.room = this; c.actor = null; c.spec = true; this.clients.add(c); c.dropV = -1;
    if (!silent) {
      c.send(this.joinFor(c));
      c.send({ t: 'roster', list: this.rosterList() });
      log('spectator', this.code, c.name);
      if (this.lobby) this.lobby.touch();
    }
    return true;
  }
  // рейтинговый матч: игроки входят до старта, «joined» получат в begin()
  addRanked(c, s) {
    const p = this.g.addHuman(this.uniqueName(c.name), Object.assign({}, c.profile, { team: s, squad: s }));
    if (!p) return false;
    p.accId = c.acc.id;
    p.ops = c.ops || null; p.xh = c.xh || null; // 2.1: оперативники игрока
    c.room = this; c.actor = p; this.clients.add(c); c.dropV = -1;
    return true;
  }
  // рейтинговый матч создан, игроки на местах: разминка (2.0) или сразу матч
  begin() {
    if (this.phase === 'warm') {
      this.g.start(this.startOpts());
      this.warmMoney();
      for (const c of this.clients) c.send(this.joinFor(c));
      this.flushEvents();
      this.sendRoster();
      if (this.lobby) this.chatSys('Разминка ' + this.warmT + ' секунд: покупка где угодно, возрождение. Потом — матч');
      else this.chatSys('Разминка ' + RANKED_WARM_S + ' секунд: покупка где угодно, возрождение. Потом — матч до ' + RANKED_RULES.WIN + ' побед');
      log(this.lobby ? 'lobby warm-up' : 'ranked warm-up', this.code, this.lobby ? this.lobby.code : this.match.kind, this.map, 'here', this.clients.size);
      return;
    }
    this.startMatch();            // матч заново — уже с игроками на своих местах
    this.begun = true;
    for (const c of this.clients) c.send(this.joinFor(c));
    this.announce();
  }
  // конец разминки рейтингового матча: чистый старт — раунд 1 с заморозкой, стартовые деньги, счёт 0:0
  endWarm() {
    this.phase = 'match';
    this.startMatch();
    this.begun = true;
    for (const c of this.clients) if (c.actor) c.send({ t: 'team', team: c.actor.team });
    this.announce();
  }
  warmMoney() { for (const a of this.g.actors) if (a.net && a.money < WARM_MONEY) a.money = WARM_MONEY; }
  // покупка на разминке рейтингового матча — где угодно (правила магазина те же, что в игре)
  warmBuy(p, id) {
    const G = this.G, B = G.bombMode, own = (o, k) => !!o && Object.prototype.hasOwnProperty.call(o, k);
    if (!p.alive || !(own(G.WEAPONS, id) || own(G.EQUIP, id))) return false;
    const cb = B.canBuy;
    B.canBuy = (a) => !!a && a.alive;
    try { return B.buy(p, id); } finally { B.canBuy = cb; }
  }
  announce() {
    this.flushEvents();
    this.sendRoster();
    if (this.lobby) {
      const L = this.lobby, o = L.opts;
      this.chatSys(this.mode === 'bomb' ? 'Матч лобби — до ' + o.win + ' побед' + (o.ot ? ', при ничьей овертайм' : '') : this.mode === 'tdm' ? 'Матч лобби — до ' + o.kills + ' убийств, ' + o.time + ' мин' : 'Дуэль лобби — до ' + o.win + ' побед');
      log('lobby match', this.code, L.code, this.mode, this.map, 'players', this.seats(), 'clients', this.clients.size);
      this.checkForfeit();
      return;
    }
    const M = this.match, D = db.data;
    if (M.kind === 'cw') {
      const t = M.clans.map(id => (D.clans[id] ? '[' + D.clans[id].tag + ']' : '[?]'));
      this.chatSys('Клановая война ' + t[0] + ' против ' + t[1] + ' — до ' + RANKED_RULES.WIN + ' побед');
    } else this.chatSys('Рейтинговый матч 2 на 2 — до ' + RANKED_RULES.WIN + ' побед');
    const here = new Set(this.g.actors.map(a => a.accId));
    for (const ids of M.squads) for (const id of ids) if (!here.has(id)) this.chatSys((D.accounts[id] ? D.accounts[id].nick : 'Игрок') + ' не пришёл');
    log('ranked start', this.code, M.kind, M.squads.map(s => s.map(id => (D.accounts[id] || {}).nick).join('+')).join(' vs '), 'here', this.clients.size);
    this.checkForfeit();
  }
  reclaim(c) {
    const k = holdKey(c);
    if (k) {
      const h = this.held.get(k);
      if (h) { this.held.delete(k); if (this.g.actors.includes(h.p)) return h.p; }
    }
    // старое соединение этого же телефона ещё числится (сеть сменилась) — забираем у него игрока
    if (c.key) for (const o of this.clients) {
      if (o === c || o.key !== c.key || !o.actor) continue;
      return this.takeFrom(o);
    }
    // рейтинговый матч: тот же аккаунт с другого соединения
    if (this.ranked && c.acc) {
      for (const [hk, h] of this.held) if (h.p.accId === c.acc.id) { this.held.delete(hk); if (this.g.actors.includes(h.p)) return h.p; }
      for (const o of this.clients) if (o !== c && o.actor && o.acc && o.acc.id === c.acc.id) return this.takeFrom(o);
    }
    return null;
  }
  takeFrom(o) {
    const p = o.actor;
    this.clients.delete(o); o.room = null; o.actor = null;
    try { o.ws.close(4000, 'replaced'); } catch (e) { }
    return p;
  }
  // связь оборвалась (не «выйти из матча»): игрок остаётся в матче и ждёт возвращения
  drop(c) {
    if (!this.clients.has(c)) return;
    const p = c.actor, k = holdKey(c);
    if (!p || !k) { this.leave(c); return; }
    this.clients.delete(c); c.room = null; c.actor = null;
    p.netUse = false; p.vel.set(0, 0, 0);
    this.held.set(k, { p, t: Date.now() });
    log('drop', this.code, p.name, 'waiting for return');
    this.pvpCheck();
    if (this.lobby) this.lobby.touch();
  }
  expireHeld(force) {
    const now = Date.now();
    for (const [k, h] of this.held) {
      if (!(force && force(h.p)) && now - h.t < this.holdMs) continue;
      this.held.delete(k);
      if (this.g.actors.includes(h.p)) { this.g.removeHuman(h.p); this.chatSys(h.p.name + ' вышел'); this.flushEvents(); this.sendRoster(); }
      log('hold expired', this.code, h.p.name);
    }
    this.pvpCheck();
    this.checkForfeit();
  }
  leave(c) {
    if (!this.clients.has(c)) return;
    this.clients.delete(c);
    const p = c.actor; c.room = null; c.actor = null; c.spec = false;
    if (p) { this.g.removeHuman(p); this.chatSys(p.name + ' вышел'); }
    this.flushEvents();
    if (p) this.sendRoster();
    log('leave', this.code, p ? p.name : c.name + ' (spectator)', 'humans', this.clients.size);
    this.pvpCheck();
    this.checkForfeit();
    if (this.lobby) this.lobby.touch();
  }
  // ---------- «Вилла» только для людей (1.6) ----------
  // кто-то вошёл/вышел: разминка ↔ отсчёт, техническая победа, если команда опустела
  pvpCheck() {
    if (!this.pvp || this.g.over) return;
    const g = this.g;
    if (this.phase === 'match') {
      const t0 = g.teamCount(0, true), t1 = g.teamCount(1, true);
      if (t0 && t1) return;
      const win = t0 ? 0 : t1 ? 1 : null;
      this.restartAfter = 8;
      g.endMatch({ win, forfeit: true });
      this.chatSys(win == null ? 'Все игроки вышли — матч окончен' : 'Соперники покинули матч — техническая победа ' + (win === 0 ? 'спецназа' : 'налётчиков'));
      this.flushEvents();
      log('forfeit', this.code, 'win', win);
      return;
    }
    const ready = this.seats() >= PVP_NEED && this.humans().length >= PVP_NEED;
    if (ready && this.phase === 'warm') { this.phase = 'count'; this.countT = PVP_COUNT; this.chatSys('Все в сборе — матч начинается!'); log('countdown', this.code); }
    else if (!ready && this.phase === 'count') { this.phase = 'warm'; this.countT = 0; this.chatSys('Игрок вышел — снова разминка, ждём ' + PVP_NEED + ' игроков'); log('countdown cancelled', this.code); }
  }
  // новый круг в той же комнате: разминка (warm) или настоящий матч (match)
  pvpStart(phase) {
    this.phase = phase; this.countT = 0; this.restartT = 0; this.restartAfter = 12;
    this.g.start(this.startOpts());
    for (const c of this.clients) if (c.actor) c.send({ t: 'team', team: c.actor.team });
    this.flushEvents();
    this.sendRoster();
    log(phase === 'match' ? 'match start' : 'warm-up', this.code, this.mode, 'humans', this.seats());
    if (phase === 'warm') this.pvpCheck();
  }
  // рейтинговый матч: в команде не осталось ни одного игрока (в игре или ждущего возвращения) — техническое поражение
  checkForfeit() {
    if (!this.fixed || !this.begun || this.g.over || this.closed) return;
    if (this.lobby && this.lobby.opts.bots) return;   // 2.2: лобби с ботами — ушедших заменяют боты
    const has = [0, 0];
    for (const a of this.g.actors) if (a.net && (a.fixedTeam === 0 || a.fixedTeam === 1)) has[a.fixedTeam]++;
    if (has[0] && has[1]) return;
    const win = has[0] ? 0 : has[1] ? 1 : null;
    this.chatSys(win == null ? 'Все игроки покинули матч' : 'Соперники покинули матч — техническая победа');
    log('forfeit', this.code, win == null ? 'nobody left' : 'squad ' + win + ' wins');
    this.g.endMatch({ win: win == null ? null : this.teamOfSquad(win), forfeit: true });
    this.flushEvents();
  }
  uniqueName(n) {
    const used = new Set(this.g.actors.map(a => a.name));
    if (!used.has(n)) return n;
    for (let i = 2; i < 99; i++) { const m = (n.slice(0, 12) + i); if (!used.has(m)) return m; }
    return n;
  }
  chatSys(text) { this.broadcast({ t: 'ev', l: [['sys', text]] }); }
  // [nid, имя, команда, человек, нож, перчатки, тег клана, цвет клана, номер ID, аватар {p,c}, надетые медали] (2.0)
  // + оперативники [спецназ, налётчики] (2.1, последнее поле; у ботов и старых клиентов — null)
  sendRoster() { this.broadcast({ t: 'roster', list: this.rosterList() }); }
  rosterList() {
    const D = db.data;
    return this.g.actors.filter(a => !this.pvp || a.net).map(a => {
      const base = [a.nid, a.name, a.team, a.net ? 1 : 0, a.net ? a.knifeFor().id : 'knife', a.net && a.gloves ? a.gloves[0] : null];
      const acc = a.net && a.accId ? D.accounts[a.accId] : null;
      const ops = a.net && a.ops ? a.ops : null;
      const xh = a.net && a.xh ? a.xh : null;   // 2.4: код прицела — 13-е поле
      if (!acc) return base.concat([null, null, 0, null, null, ops, xh]);
      const cl = acc.clan ? D.clans[acc.clan] : null;
      return base.concat([cl ? cl.tag : null, cl ? cl.color : null, acc.num, A.avObj(acc), A.equipped(acc, D.clans), ops, xh]);
    });
  }
  broadcast(msg) { const s = JSON.stringify(msg); for (const c of this.clients) c.sendRaw(s); }
  // счёт того, что идёт сейчас (на разминке комнаты «бомба» идёт TDM — счёт TDM)
  score() { const B = this.G.bombMode; return (this.g.mode === 'bomb' && Array.isArray(B.score) ? B.score : this.g.scores || [0, 0]).slice(); }

  tick() {
    if (this.closed) return;
    const t0 = process.hrtime.bigint();
    try { this.step(); } catch (e) { this.errN = (this.errN || 0) + 1; if (this.errN <= 20 || this.errN % 500 === 0) logErr('[room ' + this.code + ']', e && e.stack || e); }
    // шаг комнаты сам по себе не должен ронять сервер: ошибка — в журнал, комната продолжает жить
    // средняя цена шага за последние 5 с (мс); 30 шагов в секунду → доля ядра = cost × 30 / 1000
    this.costAcc = (this.costAcc || 0) + Number(process.hrtime.bigint() - t0) / 1e6;
    if (++this.costN >= 150) { this.cost = this.costAcc / this.costN; this.costAcc = 0; this.costN = 0; }
  }
  step() {
    const g = this.g;
    try {
      if (g.over) {
        if (this.fixed) { this.closeT += TICK; if (this.closeT > (this.lobby ? LOBBY_BACK_S : RANKED_CLOSE_S)) { this.close('match over'); return; } }
        else { this.restartT += TICK; if (this.restartT > this.restartAfter) this.restartMatch(); }
      } else {
        g.step(TICK);
        if (this.fixed && this.phase === 'warm') {
          // разминка рейтингового матча: 30 → 1, затем матч (даже если кто-то не пришёл — он считается вышедшим / ждущим)
          if (this.tickN % 15 === 0) this.warmMoney();
          if ((this.warmT -= TICK) <= 0) this.endWarm();
        }
        // отсчёт до матча на карте 2 на 2
        else if (this.phase === 'count' && (this.countT -= TICK) <= 0) this.pvpStart('match');
        else if (this.pvp && this.tickN % 30 === 0) this.pvpCheck();
      }
    } catch (e) { this.errN = (this.errN || 0) + 1; if (this.errN <= 20 || this.errN % 500 === 0) logErr('[room ' + this.code + ']', e && e.stack || e); }
    if (this.closed) return;
    this.flushEvents();
    if (++this.tickN % SNAP_EVERY === 0) this.sendSnaps();
    if (this.tickN % 30 === 0) { if (this.held.size) this.expireHeld(); else this.checkForfeit(); }
    // пустая комната закрывается через минуту (рейтинговая с незаконченным матчем ждёт вышедших)
    // матч лобби: все ушли (и никого не ждём) — сразу обратно в лобби
    if (this.lobby) { if (!this.clients.size && !this.held.size) { this.emptyT += TICK; if (this.emptyT > 2) this.close('empty'); } else this.emptyT = 0; }
    else if (!this.clients.size && !(this.ranked && !g.over)) { this.emptyT += TICK; if (this.emptyT > 60) this.close('empty'); } else this.emptyT = 0;
  }
  restartMatch() {
    this.restartT = 0;
    // «Вилла»: после матча — снова разминка; если все четверо на месте, она сразу перейдёт в отсчёт
    if (this.pvp) { this.pvpStart('warm'); return; }
    if (this.pub && this.mode !== 'duel' && MAPS.includes(this.map)) { const i = MAPS.indexOf(this.map); this.map = MAPS[(i + 1) % MAPS.length]; }
    this.g.start({ mode: this.mode, map: this.map, size: this.size, diff: this.diff });
    for (const c of this.clients) if (c.actor) c.send({ t: 'team', team: c.actor.team });
    this.flushEvents();
    this.sendRoster();
  }
  close(reason) {
    if (this.closed) return;
    this.closed = true;
    clearInterval(this.timer);
    rooms.delete(this.code);
    for (const c of this.clients) { c.room = null; c.actor = null; c.spec = false; }
    this.clients.clear(); this.held.clear();
    log('room closed', this.code, reason || '');
    if (this.lobby) { try { this.lobby.roomClosed(this); } catch (e) { logErr('[lobby back]', e && e.stack || e); } }
  }
  // закрыть по решению админа: игроки увидят конец матча и вернутся в меню
  adminClose() {
    const n = this.clients.size;
    if (!this.g.over) {
      if (this.ranked && !this.settled) { this.settled = true; log('ranked match cancelled by admin', this.code); }
      this.broadcast({ t: 'ev', l: [['sys', 'Комната закрыта администратором'], ['mend', null, this.score(), 0]] });
    } else this.chatSys('Комната закрыта администратором');
    this.close('by admin');
    return n;
  }

  // события симуляции → сообщения игрокам
  flushEvents() {
    const G = this.G, evs = G.events;
    if (!evs.length) return;
    const all = [], to = new Map();
    const push = (c, e) => { if (!to.has(c)) to.set(c, []); to.get(c).push(e); };
    const clientOf = (a) => { for (const c of this.clients) if (c.actor === a) return c; return null; };
    let roster = false, ended = null;
    const dl = [];                  // события оружия на земле — только новым клиентам
    for (const [type, d] of evs) {
      switch (type) {
        case 'shot': {
          const e = ['shot', d.a.nid, d.w, d.mz, d.ends];
          if (d.net) { const sc = clientOf(d.a); for (const c of this.clients) if (c !== sc) push(c, e); }
          else all.push(e);
          break;
        }
        case 'melee': all.push(['mel', d.a.nid]); break;
        case 'hurt': {
          const e = ['hurt', d.v.nid, d.by ? d.by.nid : 0, Math.round(d.amt), d.head ? 1 : 0, d.wid];
          const vc = d.v.net && clientOf(d.v), bc = d.by && d.by.net && clientOf(d.by);
          if (vc) push(vc, e); if (bc && bc !== vc) push(bc, e);
          for (const c of this.clients) if (c.spec) push(c, e);   // 2.2: наблюдатели видят весь урон
          break;
        }
        case 'kill': all.push(['kill', d.k ? d.k.nid : 0, d.v.nid, d.w, d.head ? 1 : 0, d.k && d.k.net ? d.k.skinOf(d.w) : null]); break;
        case 'blood': all.push(['blood', r2(d.x), r2(d.y), r2(d.z), d.head ? 1 : 0]); break;
        case 'nadeSpawn': all.push(['nade', d.n.id, d.n.owner ? d.n.owner.nid : 0, d.n.type, d.o.map(r3), d.v.map(r3)]); break;
        case 'nadeBoom': all.push(['boom', d.n.id, d.n.type, r2(d.x), r2(d.y), r2(d.z), d.n.owner ? d.n.owner.nid : 0]); break;
        case 'blind': { const c = clientOf(d.a); if (c) push(c, ['blind', r2(d.T), r2(d.k)]); break; }
        case 'bp': { if (this.g.warm || this.lobby) break; const c = clientOf(d.a); if (c) push(c, ['bp', d.e]); break; } // разминка и лобби (2.2) — без заданий пропуска
        case 'spawn': all.push(['spawn', d.a.nid]); break;
        case 'roundStart': all.push(['round', d.round, d.pistol ? 1 : 0, d.half ? 1 : 0]); break;
        case 'duelRound': all.push(['dround', d.round, d.sc[0], d.sc[1]]); break;
        case 'duelTime': all.push(['dtime', d.w]); break;
        case 'live': all.push(['live']); break;
        case 'roundEnd': all.push(['rend', d.win, d.reason]); break;
        case 'planted': all.push(['plant', d.a.nid, d.site, r2(d.x), r2(d.z), r2(d.yaw), r2(d.y || 0)]); break; // 2.1: + высота (бомба на ящике)
        case 'defused': all.push(['defused', d.a.nid]); break;
        case 'exploded': all.push(['expl', r2(d.x), r2(d.z), r2(d.y || 0)]); break;
        case 'bombPick': all.push(['pick', d.a.nid]); break;
        case 'halftime': all.push(['half']); roster = true; this.swapped = !this.swapped; break;
        case 'matchStart': all.push(['mstart', this.g.mode, this.g.mapId, this.g.warm ? 1 : 0]); roster = true; break; // разминка «Виллы» — TDM (4-е поле = 1), матч — режим комнаты
        case 'matchEnd': all.push(['mend', d.win, d.sc, d.forfeit ? 1 : 0]); ended = d; break;
        case 'leave': all.push(['gone', d.a.nid]); break;
        case 'dropAdd': case 'dropDel': case 'dropClear': this.dropV++; break;
        case 'dropTake': { const st = d.d.st; dl.push(['dtake', d.a.nid, d.d.id, d.slot, st.id, st.skin || null, st.wear || 0, st.mag, st.reserve]); break; }
      }
    }
    evs.length = 0;
    for (const c of this.clients) {
      const mine = to.get(c);
      let l = mine ? all.concat(mine) : all;
      if (dl.length && c.profile && c.profile.drops) l = l.concat(dl);
      if (l.length) c.send({ t: 'ev', l });
    }
    if (roster) this.sendRoster();
    if (this.sysQ && this.sysQ.length) { const q = this.sysQ; this.sysQ = null; for (const t of q) this.chatSys(t); }
    if (ended) {
      if (this.ranked) this.settle(ended.win, ended.sc || [0, 0]);
      else if (this.lobby) { if (!this.g.warm) this.lobby.matchEnded(this, ended); }   // лобби: в историю серии, медали не считаются
      else this.countMatch(ended.win);
    }
  }

  // обычный матч закончился: аккаунтам в комнате засчитывается онлайн-матч (медаль «Ветеран»)
  countMatch(win) {
    if (this.g.warm || this.g.time < 60) return;
    for (const c of this.clients) {
      const a = c.actor && c.acc;
      if (!a) continue;
      a.om = (a.om | 0) + 1; db.dirty();
      clans.addXp(a.id, (win === 0 || win === 1) && c.actor.team === win ? 15 : 10);   // 2.4: опыт клану
      if (a.om === 100) { log('medal vet100', a.nick); sendMe(a.id); }
    }
  }

  // итог рейтингового матча / клановой войны — ровно один раз
  settle(winTeam, sc) {
    if (this.settled) return;
    this.settled = true;
    const M = this.match, D = db.data, now = Date.now();
    const winSquad = winTeam === 0 || winTeam === 1 ? this.squadOfTeam(winTeam) : null;
    const ssc = [sc[this.teamOfSquad(0)] | 0, sc[this.teamOfSquad(1)] | 0];
    // дошёл до конца: на связи. Выпавший и не вернувшийся (даже если ещё ждёт возвращения) считается ушедшим
    const here = new Set();
    for (const c of this.clients) if (c.actor && c.acc) here.add(c.acc.id);
    const res = [];
    M.squads.forEach((ids, s) => {
      for (const id of ids) {
        const a = D.accounts[id]; if (!a) continue;
        const left = !here.has(id);
        res.push({ id, a, s, left, S: left ? 0 : winSquad == null ? 0.5 : s === winSquad ? 1 : 0 });
      }
    });
    const keep = (a, rec) => { a.matches.push(rec); if (a.matches.length > 20) a.matches.splice(0, a.matches.length - 20); };
    if (M.kind === 'ranked') {
      const avg = [0, 1].map(s => { const l = res.filter(r => r.s === s); return l.length ? l.reduce((t, r) => t + r.a.rating, 0) / l.length : A.START_RATING; });
      for (const r of res) { r.old = r.a.rating; r.new = Math.max(0, r.old + A.eloDelta(r.old, avg[1 - r.s], r.S, r.a.cal) - (r.left ? 10 : 0)); }
      for (const r of res) {
        const a = r.a, delta = r.new - r.old;
        a.rating = r.new; a.games++;
        if (!r.left) a.om = (a.om | 0) + 1;
        if (r.S === 1) a.wins++; else if (r.S === 0) a.losses++;
        a.cal = Math.min(5, a.cal + 1);
        keep(a, { t: now, kind: 'ranked', win: r.S, delta, score: [ssc[r.s], ssc[1 - r.s]] });
        // новый ранг: награда за каждый ещё не награждённый ранг (на всю жизнь аккаунта) и медаль яруса
        const gain = A.applyRank(a);
        // 2.3: аккаунт с облачным инвентарём — монеты сразу в облако (игре 2.3 — уведомление с cloud: 1), иначе как раньше
        for (const w of gain.rewards) {
          if (eco.credit(r.id, w.coins, 'reward', { rank: w.rank })) a.rcloud.push(w.rank); else a.rpend.push(w.rank);
          log('rank reward', a.nick, A.rankName(w.rank), w.coins, eco.has(r.id) ? 'cloud' : '');
        }
        if (!r.left) clans.addXp(r.id, r.S === 1 ? 30 : 20);   // 2.4: опыт клану
        sendAcc(r.id, { t: 'rated', kind: 'ranked', old: r.old, new: r.new, delta, cal: a.cal, win: r.S });
        sendMe(r.id);
        deliverRewards(r.id);
      }
      log('rated', this.code, ssc.join(':'), res.map(r => r.a.nick + ' ' + r.old + '->' + r.new + (r.left ? ' (left)' : '')).join(', '));
    } else {
      const cls = M.clans.map(id => D.clans[id] || null);
      let dW = 0, dL = 0;
      if (winSquad != null) {
        const W = cls[winSquad], L = cls[1 - winSquad];
        if (W) { W.pts += 25; W.wins++; dW = 25; }
        if (L) { const o = L.pts; L.pts = Math.max(0, L.pts - 10); L.losses++; dL = L.pts - o; }
      }
      for (const r of res) {
        if (!r.left) r.a.om = (r.a.om | 0) + 1;
        if (winSquad != null && r.s === winSquad && !r.left) { r.a.cw++; if (!r.a.medals.includes('cw_win')) r.a.medals.push('cw_win'); }
        if (!r.left) clans.addXp(r.id, r.S === 1 ? 40 : 15);   // 2.4: опыт клану
        keep(r.a, { t: now, kind: 'clan', win: r.S, score: [ssc[r.s], ssc[1 - r.s]] });
        sendAcc(r.id, { t: 'rated', kind: 'cw', win: r.S, clanDelta: winSquad == null ? 0 : r.s === winSquad ? dW : dL });
        sendMe(r.id);
      }
      for (const cl of cls) if (cl) hub.clanChanged(cl.id);
      log('clan war', this.code, ssc.join(':'), cls.map(cl => (cl ? '[' + cl.tag + '] ' + cl.pts : '?')).join(' vs '), winSquad == null ? 'draw' : 'winner squad ' + winSquad);
    }
    lbCache = null;
    db.dirty();
  }

  sendSnaps() {
    const g = this.g, G = this.G, time = g.time;
    const A = g.actors.map(a => {
      let f = (a.alive ? 1 : 0) | (a.using || (a.net && a.netUse) ? 4 : 0) | (a.hasBomb ? 8 : 0) | (a.scoped ? 16 : 0) | (a.onGround ? 64 : 0) | (a.w && a.w.reloadT > 0 ? 128 : 0);
      const row = [a.nid, r2(a.pos.x), r2(a.pos.y), r2(a.pos.z), r3(a.yaw), r3(a.pitch), f, a.w ? a.w.id : 'knife', Math.ceil(a.hp), Math.round(a.crouchT * 10), a.team, a.spottedUntil > time ? (a.spottedBy == null ? -1 : a.spottedBy) : -2];
      // скин оружия в руках (1.5): виден при наблюдении от первого лица; старые клиенты лишнее поле не читают
      if (a.w && a.w.skin) row.push(a.w.skin, a.w.wear || 0);
      return row;
    });
    let gs;
    if (g.mode === 'bomb') {
      const B = G.bombMode, b = B.bomb;
      gs = { m: 'bomb', ph: B.phase, t: r2(B.t), r: B.round, sc: B.score, bs: b ? b.state : 'none', bx: b ? r2(b.pos.x) : 0, by: b ? r2(b.pos.y) : 0, bz: b ? r2(b.pos.z) : 0, bc: b && b.carrier ? b.carrier.nid : 0, buyT: r2(B.buyT), dn: B.defuser ? B.defuser.nid : 0, dp: B.defuser ? r2(B.defuseT / B.defuseNeed(B.defuser)) : 0, pn: B.planter ? B.planter.nid : 0, pp: B.planter ? r2(B.plantT / B.PLANT) : 0, max: B.MAX, win: B.WIN };
    } else if (g.mode === 'duel') {
      const D = G.duelMode;
      gs = { m: 'duel', sc: g.scores, tl: Math.max(0, Math.round(g.timeLeft)), kl: g.killLimit, fz: g.frozen ? 1 : 0, rd: D.round, ph: D.phase, dt: r2(Math.max(0, D.t)) };
    } else gs = { m: g.mode, sc: g.scores, tl: Math.max(0, Math.round(g.timeLeft)), kl: g.killLimit };
    gs.over = g.over ? 1 : 0;
    // «Вилла» (1.6): разминка — [людей, нужно, секунд до матча (0 — ждём)]; старые клиенты поле не читают
    if (this.pvp && this.phase !== 'match' && !g.over) gs.wu = [this.seats(), PVP_NEED, this.phase === 'count' ? Math.max(1, Math.ceil(this.countT)) : 0];
    // разминка рейтингового матча (2.0): [игроков на местах, 4, секунд до матча 30 → 1]
    const rw = this.rwarm();
    if (rw) gs.wu = [this.seats(), this.lobby ? this.seats() : this.size * 2, Math.max(1, Math.ceil(this.warmT))];
    const base = { t: 'snap', s: r3(time), a: A, g: gs };
    // раз в секунду — счёт игроков; 2.3: шестое поле — пинг игрока в мс (сам телефон меряет и присылает в ping), −1 — бот,
    // null — неизвестен (игрок вылетел, ждём его). Старые клиенты лишнее поле не читают
    let statStr = null;
    if (this.tickN % 30 === 0) {
      const pg = new Map();
      for (const c of this.clients) if (c.actor) pg.set(c.actor, c.cping != null ? c.cping : c.rtt ? Math.min(999, c.rtt | 0) : null);
      statStr = g.actors.map(a => [a.nid, a.kills, a.deaths, a.hs, a.money, a.net ? (pg.has(a) ? pg.get(a) : null) : -1]);
    }
    // оружие на земле: [id, оружие, скин, износ, x, y, z, поворот, чей (nid), возраст] — только когда список изменился (и раз в 2 с)
    let drops = null;
    const dropList = () => drops || (drops = G.drops ? G.drops.list.map(d => [d.id, d.st.id, d.st.skin || null, d.st.wear || 0, r2(d.pos.x), r2(d.pos.y), r2(d.pos.z), r3(d.yaw), d.owner && d.owner.nid || 0, Math.round(d.t * 10) / 10]) : []);
    // 2.2: наблюдателям — полная информация обо всех: [nid, броня, шлем, сапёр, деньги, убийства, смерти, в голову, основное, пистолет, осколочные, вспышки, дымы, ослеплён]
    let sx = null;
    const specRows = () => sx || (sx = g.actors.map(a => { const s = a.slots || {}, n = a.nades || {}; return [a.nid, Math.ceil(a.armor || 0), a.helmet ? 1 : 0, a.kit ? 1 : 0, a.money | 0, a.kills | 0, a.deaths | 0, a.hs | 0, s.primary ? s.primary.id : null, s.secondary ? s.secondary.id : null, n.he | 0, n.flash | 0, n.smoke | 0, a.blindT > 0 ? 1 : 0]; }));
    for (const c of this.clients) {
      const p = c.actor;
      if (!p) {
        if (!c.spec || c.ws.backlog > 256 * 1024) continue;
        const msg = Object.assign({ sx: specRows() }, base);
        if (statStr) { msg.st = statStr; if (this.lobby) msg.tn = this.lobby.teamNames(this); }
        const wd = c.profile && c.profile.drops && G.drops && (c.dropV !== this.dropV || (statStr && G.drops.list.length));
        if (wd) msg.dr = dropList();
        c.send(msg);
        if (wd) c.dropV = this.dropV;
        continue;
      }
      const sl = {};
      for (const k of ['primary', 'secondary', 'melee']) { const st = p.slots[k]; sl[k] = st ? [st.id, st.skin || null, st.wear || 0, st.mag, st.reserve] : null; }
      const me = { tp: p.tp, x: r2(p.pos.x), y: r2(p.pos.y), z: r2(p.pos.z), yw: r3(p.yaw), al: p.alive ? 1 : 0, hp: Math.ceil(p.hp), ar: Math.ceil(p.armor), hm: p.helmet ? 1 : 0, kit: p.kit ? 1 : 0, $: p.money, n: [p.nades.he | 0, p.nades.flash | 0, p.nades.smoke | 0], sl, team: p.team, bomb: p.hasBomb ? 1 : 0, k: p.kills, d: p.deaths, hs: p.hs, pr: p.protect > 0 ? 1 : 0 };
      if (g.mode === 'bomb') me.buy = G.bombMode.canBuy(p) ? 1 : 0;
      else if (rw) me.buy = p.alive ? 1 : 0;      // разминка рейтингового матча: магазин открыт везде
      const msg = Object.assign({ me }, base);
      if (statStr) msg.st = statStr;
      const wantDrops = c.profile && c.profile.drops && G.drops && (c.dropV !== this.dropV || (statStr && G.drops.list.length));
      if (wantDrops) msg.dr = dropList();
      // медленному соединению не досылаем лишнего — следующий снимок всё равно новее
      if (c.ws.backlog > 256 * 1024) continue;
      c.send(msg);
      if (wantDrops) c.dropV = this.dropV;
    }
  }

  // 2.2: чат наблюдателей — во время матча только другим наблюдателям (без подсказок игрокам), после матча — всем
  specChat(c, m) {
    const text = cleanText(m.m); if (!text) return;
    const now = Date.now();
    if (c.acc && A.isMuted(c.acc, now)) return;
    if (now - (c.chatT || 0) < 700) return;
    c.chatT = now;
    const all = this.g.over;
    for (const o of this.clients) if (all || o.spec) o.send({ t: 'ev', l: [['schat', c.name, text, o === c ? 1 : 0]] });
  }
  // предмет из магазина игры (не нож и не что-то выдуманное)
  shopItem(id) { return !!id && this.G.SHOP.some(cat => cat.items.includes(id)); }
  // ---------- сообщения от игрока ----------
  onMsg(c, m) {
    const p = c.actor, g = this.g;
    if (!p) { if (c.spec && m.t === 'chat') this.specChat(c, m); return; }
    switch (m.t) {
      // всё, что пришло от телефона, проверяется: типы, длины, слоты оружия только из списка
      case 'st': if (validSt(m)) g.netState(p, m); break;
      case 'shot': if (validShot(m)) { const r = g.netShot(p, m); if (r && r.hit) c.send({ t: 'hit', h: 1, hd: r.head ? 1 : 0, k: r.kill ? 1 : 0 }); } break;
      case 'mel': { const r = g.netMelee(p, { yw: finite(m.yw), pt: finite(m.pt), lag: finite(m.lag) }); if (r && r.hit) c.send({ t: 'hit', h: 1, hd: r.head ? 1 : 0, k: r.kill ? 1 : 0 }); break; }
      case 'nade': if (vec3(m.o) && vec3(m.v) && typeof m.type === 'string') g.netNade(p, m); break;
      case 'rl': if (m.s === 'primary' || m.s === 'secondary') g.netReload(p, m.s); break;
      case 'buy': {
        const id = typeof m.id === 'string' ? m.id : '';
        if (!this.shopItem(id)) break;
        if (this.rwarm()) this.warmBuy(p, id); else g.netBuy(p, id);
        break;
      }
      case 'prim': if (typeof m.w === 'string' && this.G.PRIMARIES.includes(m.w)) p.nextPrimary = m.w; break;
      case 'take': if (g.netTake && Number.isInteger(m.id)) g.netTake(p, m.id); break;      // подобрать оружие с земли (1.5)
      case 'toss': if (g.netToss && (m.s === 'primary' || m.s === 'secondary')) g.netToss(p, m.s); break; // выбросить оружие из рук (1.5)
      case 'chat': {
        const text = cleanText(m.m); if (!text) break;
        const now = Date.now();
        // мут от администратора: сообщение не уходит, напоминание — не чаще раза в 30 с
        if (c.acc && A.isMuted(c.acc, now)) {
          if (now - (c.muteNoteT || 0) > 30000) { c.muteNoteT = now; c.send({ t: 'ev', l: [['sys', 'Чат для вас временно отключён']] }); }
          break;
        }
        if (now - (c.chatT || 0) < 700) break;
        c.chatT = now;
        const e = { t: 'ev', l: [['chat', p.nid, text, m.team ? 1 : 0]] }, s = JSON.stringify(e);
        for (const o of this.clients) if (!m.team || (o.actor && o.actor.team === p.team)) o.sendRaw(s);
        break;
      }
    }
    this.flushEvents();
  }
}

// ---------- аккаунты онлайн ----------
function sendAcc(id, msg) {
  const s = accConns.get(id);
  if (!s) return 0;
  const str = JSON.stringify(msg);
  for (const c of s) c.sendRaw(str);
  return s.size;
}
function sendMe(id) { const a = db.data.accounts[id]; if (a) sendAcc(id, { t: 'me', acc: A.meObj(a, db.data.clans) }); }
function bindAcc(c, a) {
  if (c.acc === a) return;
  unbindAcc(c);
  c.acc = a;
  c.name = a.nick;                  // в матчах игрок виден под ником аккаунта
  let s = accConns.get(a.id);
  if (!s) accConns.set(a.id, s = new Set());
  s.add(c);
  // вошёл уже в обычной комнате: комната узнаёт аккаунт (тег, аватар, медали в таблице)
  if (c.actor && c.room && !c.room.ranked) { c.actor.accId = a.id; c.room.sendRoster(); }
  if (c.lobby) lobbyHub.accChanged(c);   // 2.2: номер, аватар и ранг в лобби
}
function unbindAcc(c) {
  const a = c.acc;
  if (!a) return;
  mm.leave(c, false);
  const s = accConns.get(a.id);
  if (s) { s.delete(c); if (!s.size) accConns.delete(a.id); }
  a.seen = Date.now(); db.dirty();
  c.acc = null;
  if (c.actor && c.room && !c.room.ranked) { c.actor.accId = null; c.room.sendRoster(); }
  if (c.lobby) lobbyHub.accChanged(c);
}
// вход по {id, key} из hello: 'ok' | 'fail' | 'ban' | null (гость). Аккаунты создаются только регистрацией (reg)
function login(c, acc) {
  if (acc == null || typeof acc !== 'object') { unbindAcc(c); return null; }
  const id = typeof acc.id === 'string' ? acc.id : '', key = typeof acc.key === 'string' ? acc.key : '';
  if (!A.ID_RE.test(id) || !A.KEY_RE.test(key)) { unbindAcc(c); return 'fail'; }
  const a = db.data.accounts[id];
  if (!a || !A.checkKey(a, key)) { unbindAcc(c); log('account key rejected', id, c.helloName); return 'fail'; }
  if (A.isBanned(a)) { unbindAcc(c); c.banned = a; return 'ban'; }
  if (a.ban) a.ban = null;                     // срок бана вышел
  if (a.mute && !A.isMuted(a)) a.mute = null;
  const fresh = c.acc !== a;
  a.seen = Date.now(); db.dirty();
  bindAcc(c, a);
  c.authKey = key;
  if (fresh) log('login', a.nick, 'num', a.num);
  return 'ok';
}
// подарки (2.0): у каждого свой id; телефон зачисляет монеты один раз (по id) и отвечает gift_ok — только тогда подарок доставлен.
// Один и тот же подарок одновременно отправлен только одному соединению; оборвалось без ответа — уйдёт снова при следующем входе
const giftSent = new Map();      // id подарка → соединение, которому он отправлен и от которого ждём gift_ok
function deliverGifts(c) {
  const a = c.acc;
  if (!a || !a.gifts.length || !conns.has(c)) return;
  if (eco.has(a.id)) settlePending(a);
  let n = 0;
  for (const g of a.gifts) {
    // 2.3: монеты облачного подарка уже на аккаунте — уведомление только игре 2.3; подарок «на телефон» — только старой игре
    // (игра 2.3 без облачного инвентаря ждёт переноса: тогда подарок зачислится в облако)
    if (!!g.cloud !== isCloudConn(c)) continue;
    const to = giftSent.get(g.id);
    if (to && to !== c && conns.has(to) && to.acc === a) continue;   // уже ждём ответа от другого телефона этого аккаунта
    giftSent.set(g.id, c);
    c.send(g.cloud ? { t: 'gift', id: g.id, coins: g.coins, m: g.m, cloud: 1 } : { t: 'gift', id: g.id, coins: g.coins, m: g.m });
    n++;
  }
  if (n) log('gifts sent', a.nick, 'num', a.num, n);
}
function giftAck(c, id) {
  const a = c.acc;
  if (!a) return;
  const i = a.gifts.findIndex(g => g.id === id);
  giftSent.delete(id);
  if (i < 0) return;
  const g = a.gifts[i];
  a.gifts.splice(i, 1); db.dirty();
  log('gift delivered', a.nick, 'num', a.num, g.coins, id);
}
// соединение закрылось: его неподтверждённые подарки — другому готовому телефону этого аккаунта (если есть)
function releaseGifts(c) {
  let any = false;
  for (const [id, to] of giftSent) if (to === c) { giftSent.delete(id); any = true; }
  if (any && c.acc) for (const o of readyConns(c.acc.id, c)) deliverGifts(o);
}
function readyConns(id, except) { return [...(accConns.get(id) || [])].filter(c => c.ready && c !== except && conns.has(c)).sort((x, y) => y.id - x.id); }
// 2.3: аккаунт с облачным инвентарём — неполученные подарки (кроме летящих сейчас на телефон старой игры) и награды за ранги → в облако
function settlePending(a) {
  if (!eco.has(a.id)) return;
  let changed = false;
  for (const g of a.gifts) {
    if (g.cloud) continue;
    const to = giftSent.get(g.id);
    if (to && conns.has(to) && to.acc === a) continue;          // уже у телефона 2.2 — он зачислит сам и ответит gift_ok
    eco.credit(a.id, g.coins, 'gift', { gift: g.id, late: 1 });
    g.cloud = 1; changed = true;
  }
  if (a.rpend.length) {
    for (const i of a.rpend) { eco.credit(a.id, A.RANK_REWARDS[i], 'reward', { rank: i, late: 1 }); a.rcloud.push(i); }
    a.rpend = []; changed = true;
  }
  if (changed) db.dirty();
}
// инвентарь перенесён: старые подарки и награды — в облако, уведомления — на телефоны 2.3
function onMigrated(a) {
  settlePending(a);
  for (const c of readyConns(a.id)) if (isCloudConn(c)) deliverPending(c);
}
const coinsWord = (n) => { const a = n % 100, b = n % 10; return a > 10 && a < 20 ? 'монет' : b === 1 ? 'монета' : b > 1 && b < 5 ? 'монеты' : 'монет'; };
const rewardMsg = (i) => ({ t: 'reward', coins: A.RANK_REWARDS[i], rank: i, m: 'Новый ранг «' + A.rankName(i) + '»: +' + A.RANK_REWARDS[i] + ' монет' });
function sendRewards(c) {
  const a = c.acc;
  if (!a) return;
  // 2.3: игра 2.3 — только уведомления о наградах, монеты которых уже в облаке (cloud: 1); награды «на телефон» ждут переноса инвентаря
  if (isCloudConn(c)) {
    if (eco.has(a.id)) settlePending(a);
    if (!a.rcloud.length) return;
    const l = a.rcloud; a.rcloud = []; db.dirty();
    for (const i of l) c.send(Object.assign(rewardMsg(i), { cloud: 1 }));
    return;
  }
  if (!a.rpend.length) return;
  const l = a.rpend; a.rpend = []; db.dirty();
  for (const i of l) c.send(rewardMsg(i));
}
function deliverPending(c) { deliverGifts(c); sendRewards(c); }
// у игрока на связи есть готовое соединение — отдать ему награды сейчас, иначе при следующем входе
function deliverRewards(id) {
  for (const c of readyConns(id)) sendRewards(c);
}
function onReady(c) {
  if (c.acc) { c.send({ t: 'me', acc: A.meObj(c.acc, db.data.clans) }); deliverPending(c); }
  else if (c.accFail) c.send({ t: 'acc', ok: false });
  friends.hello(c);   // 2.4: друзья и пати
}

// ---------- хаб для модулей ----------
let lbCache = null, lbT = 0;
const hub = {
  db, log,
  isOnline: (id) => accConns.has(id),
  alive: (c) => conns.has(c),
  sendAcc, sendMe, bindAcc, unbindAcc, deliverPending,
  rankedMap: (kind) => pickRankedMap(kind),
  lbChanged() { lbCache = null; },
  publicInfo(id) {
    const a = db.data.accounts[id], cl = clanOf(id);
    if (!a) return { nick: 'Игрок', rating: A.START_RATING, cal: 0, tag: null, color: null, num: 0, av: null, eq: [] };
    return { nick: a.nick, rating: a.rating, cal: a.cal, tag: cl ? cl.tag : null, color: cl ? cl.color : null, num: a.num, av: A.avObj(a), eq: A.equipped(a, db.data.clans) };
  },
  // профиль изменился (ник, номер, аватар, медали): свежий «me» всем устройствам, свежая таблица в матчах
  accChanged(id, renamed) {
    const a = db.data.accounts[id];
    if (!a) return;
    if (renamed) for (const c of accConns.get(id) || []) c.name = a.nick;
    for (const c of accConns.get(id) || []) lobbyHub.accChanged(c);   // 2.2: ник/аватар в лобби
    sendMe(id);
    for (const r of rooms.values()) {
      let any = false;
      for (const x of r.g.actors) if (x.net && x.accId === id) { any = true; if (renamed) x.name = a.nick; }
      if (any) r.sendRoster();
    }
    lbCache = null;
  },
  // состав клана изменился: свежий «me», тег в матче, выход из очереди КВ
  membershipChanged(id) {
    sendMe(id);
    const a = db.data.accounts[id];
    for (const c of accConns.get(id) || []) if (c.q && c.q.kind === 'cw' && (!a || a.clan !== c.q.clan)) mm.leave(c, true);
    for (const r of rooms.values()) if (r.g.actors.some(x => x.accId === id)) r.sendRoster();
    lbCache = null;
  },
  // клан изменился: тем, у кого он открыт, — свежий вид
  clanChanged(id, deleted) {
    const cl = db.data.clans[id];
    for (const c of conns) {
      if (c.viewClan !== id) continue;
      if (deleted || !cl) c.viewClan = null;
      else c.send({ t: 'clan', clan: clans.full(cl, c.acc ? c.acc.id : null) });
    }
    lbCache = null;
  },
  startMatch: startRanked,
  // 2.4: пати «Напарники» — поиск начался / закончился, пати ещё жива
  partyChanged: (pid) => { if (friends) friends.partyChanged(pid); },
  partyAlive: (pid) => { if (!friends) return true; for (const id of accConns.keys()) { const P = friends.party(id); if (P && P.id === pid) return true; } return false; }
};
let friends = null;
const clans = createClans(hub);
const mm = createMM(hub);
const profile = createProfile(hub);
// 2.2: кастомные лобби
const lobbyHub = createLobbies({
  Room, rooms, log, A, limited: (...a) => limited(...a), cleanText,
  maps: MAP_META.filter(m => !m.hidden), duelMap: DUEL_MAP, maxRooms: MAX_ROOMS,
  rankedBusy: (c) => !!(c.acc && rankedRoomOf(c.acc.id)),
  leaveRoom: (c) => { if (c.room) { c.room.leave(c); c.send({ t: 'left' }); } }
});

// 2.4: друзья и пати
// статус соединения для друзей: в матче (какой, карта; наблюдает) / ищет игру / в лобби / в меню
function statusOf(c) {
  const r = c.room;
  if (r && !r.closed) return { st: 'match', where: { kind: r.ranked || (r.lobby ? 'lobby' : r.pub ? 'pub' : 'room'), mode: r.mode, map: r.map, spec: c.spec ? 1 : 0 } };
  if (c.q || c.found) return { st: 'queue', where: { kind: (c.q || c.found).kind } };
  if (c.lobby) return { st: 'lobby', where: { mode: c.lobby.mode, map: c.lobby.map } };
  return { st: 'menu', where: null };
}
friends = createFriends({
  db, log, A,
  conns: (id) => accConns.get(id),
  onlineIds: () => accConns.keys(),
  statusOf, clanOf,
  limited: (...a) => limited(...a),
  partyQ: (pid) => mm.partyQ(pid),
  dropPartyQ: (pid, why) => mm.dropParty(pid, why),
  lobbyInfo: (c) => { const L = c.lobby; return L && !L.dead ? { code: L.code, name: L.name, mode: L.mode, map: L.map } : null; }
});

// найденный матч начинается: кто из четверых ещё здесь — в комнату
function startRanked(match) {
  const free = (c, id) => c && conns.has(c) && c.acc && c.acc.id === id && !c.room && !c.q && !c.found;
  const pick = (id) => { if (free(match.conns[id], id)) return match.conns[id]; for (const c of accConns.get(id) || []) if (free(c, id)) return c; return null; };
  const present = [];
  match.squads.forEach((ids, s) => { for (const id of ids) { const c = pick(id); if (c) present.push([c, s]); } });
  if (!present.length) { log('match cancelled: nobody came', match.kind); return; }
  if (rooms.size >= MAX_ROOMS + 10) {
    for (const [c] of present) c.send({ t: 'err', code: 'rq', m: 'Сервер заполнен, попробуйте позже' });
    log('match cancelled: server full', match.kind);
    return;
  }
  const r = new Room({ match });
  for (const [c, s] of present) r.addRanked(c, s);
  r.begin();
}

function leaderboard() {
  const now = Date.now();
  if (lbCache && now - lbT < 2000) return lbCache;
  const players = Object.values(db.data.accounts).filter(a => a.cal >= 5 && !A.isBanned(a, now)).sort((a, b) => (b.rating - a.rating) || (b.wins - a.wins)).slice(0, 50);
  lbCache = { players, clans: clans.top(30) }; lbT = now;
  return lbCache;
}

// ---------- соединения ----------
function realIp(req) {
  const ra = String((req && req.socket && req.socket.remoteAddress) || '').replace(/^::ffff:/, '');
  const xf = req && req.headers && req.headers['x-forwarded-for'];
  // адресу из X-Forwarded-For верим, только если запрос пришёл через Caddy на этой же машине
  if (xf && (ra === '127.0.0.1' || ra === '::1')) return String(xf).split(',')[0].trim().replace(/^::ffff:/, '') || ra;
  return ra;
}
const ipConns = new Map();        // адрес → число соединений
function onConn(ws) {
  if (conns.size >= MAX_CONN) { ws.close(1013, 'full'); return; }
  const ip = realIp(ws.req);
  if ((ipConns.get(ip) || 0) >= CONN_PER_IP) { ws.close(1013, 'too many connections'); return; }
  ipConns.set(ip, (ipConns.get(ip) || 0) + 1);
  const c = { id: ++connSeq, ws, ip, room: null, actor: null, name: 'Игрок', profile: {}, msgN: 0, msgT: Date.now(), hello: false, ready: false, acc: null, q: null, found: null, rtt: 0 };
  // телефон не забирает данные (завис, очень медленная сеть) — не копим мегабайты в памяти, отключаем
  const out = (s) => { if (ws.backlog > 4 * 1024 * 1024) { ws.close(1008, 'slow'); return; } ws.send(s); };
  c.sendRaw = out;
  c.send = (o) => out(JSON.stringify(o));
  conns.add(c);
  ws.on('message', (raw) => {
    // защита от спама сообщениями
    const now = Date.now();
    if (now - c.msgT > 1000) { c.msgT = now; c.msgN = 0; }
    if (++c.msgN > 150) { if (c.msgN > 400) ws.close(1008, 'flood'); return; }
    let m; try { m = JSON.parse(raw); } catch (e) { c.badN = (c.badN || 0) + 1; if (c.badN > 50) ws.close(1008, 'bad data'); return; }
    if (!m || typeof m !== 'object' || Array.isArray(m) || typeof m.t !== 'string' || m.t.length > 24) return;
    try { handle(c, m); } catch (e) { c.errN = (c.errN || 0) + 1; if (c.errN <= 5) logErr('[msg ' + m.t + ']', e && e.stack || e); }
  });
  // пинг: время ответа телефона на служебный ping (для админки)
  ws.on('pong', (b) => { const t = +String(b); if (t > 0) { const rtt = Date.now() - t; if (rtt >= 0 && rtt < 20000) c.rtt = c.rtt ? Math.round(c.rtt * 0.6 + rtt * 0.4) : rtt; } });
  ws.on('close', () => {
    for (const f of [() => { if (c.room) c.room.drop(c); }, () => lobbyHub.onClose(c), () => mm.leave(c, false), () => { conns.delete(c); releaseGifts(c); }, () => unbindAcc(c)]) {
      try { f(); } catch (e) { logErr('[close]', e && e.stack || e); }
    }
    conns.delete(c); if (ipConns.get(c.ip) > 1) ipConns.set(c.ip, ipConns.get(c.ip) - 1); else ipConns.delete(c.ip);
  });
}

// ограничение частоты: по умолчанию не больше 5 действий с кланами / очередями / рейтингом в секунду;
// limited(c, имя, n, окно) — своё окно для отдельного вида действий
function limited(c, name, max, win) {
  const now = Date.now(), k = name || 'a';
  const L = c.rl || (c.rl = {});
  let e = L[k];
  if (!e || now - e.t > (win || 1000)) e = L[k] = { t: now, n: 0 };
  return ++e.n > (max || 5);
}
// вход в комнаты (quick / create / join): не больше 4 в секунду и 40 в минуту
const roomLimited = (c) => limited(c, 'room', 4) || limited(c, 'roomM', 40, 60000);
// незаконченный рейтинговый матч аккаунта (место ещё за ним: играет или ждёт возвращения)
function rankedRoomOf(accId) {
  for (const r of rooms.values()) if (r.ranked && !r.closed && !r.g.over && r.g.actors.some(a => a.net && a.accId === accId)) return r;
  return null;
}
// место в рейтинговом матче сейчас занято другим соединением этого аккаунта (второй телефон)
// (тот же телефон — тот же ключ устройства — после обрыва забирает место у своего старого соединения)
function seatBusy(r, c) { for (const o of r.clients) if (o !== c && o.acc && c.acc && o.acc.id === c.acc.id && o.actor && !(c.key && o.key === c.key)) return true; return false; }
function backToRanked(c, r) {
  mm.leave(c, false);
  if (c.room && c.room !== r) { c.room.leave(c); c.send({ t: 'left' }); }
  if (r.join(c)) { c.send({ t: 'ev', l: [['sys', 'У вас идёт рейтинговый матч — вы вернулись в него']] }); log('back to ranked', r.code, c.acc && c.acc.nick); return true; }
  return false;
}
// quick / create / join для аккаунта: найден матч — ждать; есть незаконченный рейтинговый матч — вернуть в него. true — обработано
function rankedGate(c, m) {
  if (!c.acc) return false;
  const id = c.acc.id;
  for (const o of accConns.get(id) || []) if (o.found) { c.send({ t: 'err', code: 'ranked', m: 'Рейтинговый матч найден — сейчас начнётся' }); return true; }
  const r = rankedRoomOf(id);
  if (!r) return false;
  if (m.t === 'join' && String(m.code || '').toUpperCase() === r.code) return false;   // возвращается сам, по коду
  if (c.room === r) return false;                       // сам вышел из рейтингового матча в меню — это уход из матча
  if (seatBusy(r, c)) { c.send({ t: 'err', code: 'ranked', m: 'Этот аккаунт уже играет рейтинговый матч на другом устройстве' }); return true; }
  return backToRanked(c, r);
}

// 2.1: выбор оперативников с телефона — не больше двух id вида [a-z_]{2,24}; что не подходит — null
const OP_RE = /^[a-z_]{2,24}$/;
function cleanOps(v) {
  if (!Array.isArray(v) || !v.length) return null;
  const out = v.slice(0, 2).map(x => typeof x === 'string' && OP_RE.test(x) ? x : null);
  return out.some(x => x) ? out : null;
}
function onHello(c, m) {
  if (m.v !== PROTO) { c.send({ t: 'err', code: 'version', m: 'Нужна новая версия игры' }); return; }
  // 2.0: аккаунты, рейтинг 2×2 и подарки — только у игры 2.0 (cv 200); старые версии просим обновиться
  if (!((m.cv | 0) >= MIN_CV)) { c.send({ t: 'err', code: 'version', m: 'Вышло обновление Prodigy Strike — установите новую версию игры, чтобы играть по сети' }); return; }
  if ((c.hellos = (c.hellos || 0) + 1) > 20) return;   // повторное приветствие — не чаще разумного
  c.hello = true;
  c.cv = m.cv | 0;                                     // 2.2: лобби — только для игры 2.2 (cv >= 220)
  c.helloName = cleanName(m.name);
  c.name = c.helloName;
  c.key = String(m.key || '').replace(/[^a-z0-9]/g, '').slice(0, 24) || null;
  const skins = Object.create(null);
  if (m.skins && typeof m.skins === 'object' && !Array.isArray(m.skins)) for (const k of Object.keys(m.skins).slice(0, 20)) { const v = m.skins[k]; if (Array.isArray(v) && /^[a-z0-9_]{1,12}$/.test(k)) skins[k] = [String(v[0]).slice(0, 40), v[1] | 0]; }
  if (m.ops !== undefined) c.ops = cleanOps(m.ops); // 2.1: оперативники [спецназ, налётчики]
  if (m.xh !== undefined) c.xh = cleanXh(m.xh);     // 2.4: код прицела
  c.profile = { skins, knife: Array.isArray(m.knife) ? [String(m.knife[0]).slice(0, 12), m.knife[1] ? String(m.knife[1]).slice(0, 40) : null, m.knife[2] | 0] : null, gloves: Array.isArray(m.gloves) ? [String(m.gloves[0]).slice(0, 40), m.gloves[1] | 0] : null, prim: String(m.prim || 'ar').slice(0, 16), drops: m.drops ? 1 : 0 };
  const res = login(c, m.acc);
  if (res === 'ban') {
    const a = c.banned;
    c.send({ t: 'err', code: 'ban', m: A.banText(a.ban) });
    log('banned player refused', a.nick, 'num', a.num);
    setImmediate(() => c.ws.close(4003, 'banned'));
    return;
  }
  c.accFail = res === 'fail';
  if (c.lobby) lobbyHub.accChanged(c);   // 2.2: новый ник/аккаунт — в карточке лобби
  c.send({ t: 'welcome', id: c.id, srv: VERSION, online: conns.size, rooms: rooms.size, motd: db.data.motd || '' });
  if (c.acc) { c.send({ t: 'me', acc: A.meObj(c.acc, db.data.clans) }); if (c.ready) deliverPending(c); }
  else if (c.accFail) c.send({ t: 'acc', ok: false });
  // 2.4: игра 2.4 — «сервер умеет друзей», аккаунту — список друзей и пати. Игра слушает соединение только после
  // проверки канала (probe), поэтому шлём при первом обычном сообщении (onReady) — или сейчас, если оно уже было
  if (c.ready) friends.hello(c);
}

function handle(c, m) {
  // проверка канала: ответ больше 16 КБ — если провайдер обрезает соединения (как в России с зарубежными серверами), он не дойдёт
  if (m.t === 'probe') { if ((c.probes = (c.probes || 0) + 1) <= 3) { const n = Math.max(1000, Math.min(40000, m.n | 0 || 24000)); c.send({ t: 'probe', n, d: 'x'.repeat(n) }); } return; }
  if (m.t === 'hello') { onHello(c, m); return; }
  if (m.t === 'ping') {
    // 2.3: телефон присылает свой замеренный пинг (p, мс) — его видят все в таблице счёта (Tab)
    if (m.p != null && Number.isFinite(+m.p)) c.cping = Math.max(0, Math.min(999, Math.round(+m.p)));
    c.send({ t: 'pong', c: finite(m.c), s: c.room ? r3(c.room.g.time) : 0 }); return;
  }
  if (!c.hello) {
    if (m.t === 'reg') c.send({ t: 'reg_err', m: 'Нет связи с сервером, попробуйте ещё раз' });
    else if (m.t === 'login') c.send({ t: 'login_err', m: 'Нет связи с сервером, попробуйте ещё раз' });
    return;
  }
  // первое обычное сообщение после hello: телефон точно слушает — «me» ещё раз и подарки
  if (!c.ready) { c.ready = true; onReady(c); }
  if (m.t === 'quick' || m.t === 'create' || m.t === 'join') {
    c.side = m.side === 'ct' || m.side === 't' ? m.side : 'auto';
    if (roomLimited(c)) { c.send({ t: 'err', m: 'Слишком часто — подождите секунду' }); return; }
    // 2.2: обычная комната — выход из лобби (вход в матч своего же лобби по коду — нет: это возвращение после обрыва)
    if (c.lobby) { const lr = c.lobby.room; if (!(m.t === 'join' && lr && String(m.code || '').toUpperCase() === lr.code)) lobbyHub.leave(c, 'room'); }
    // аккаунт с незаконченным рейтинговым матчем в обычную комнату не идёт: возвращаем в матч (или отказываем)
    if (rankedGate(c, m)) return;
    mm.leave(c, true);
    if (c.acc) mm.dropAcc(c.acc.id);            // и второй телефон этого аккаунта выходит из очереди
  }
  // 2.2: кастомные лобби (lobby_create, lobby_join, lobby_slot, lobby_set, lobby_start, lobby_chat …)
  if (m.t.startsWith('lobby_')) { lobbyHub.handle(c, m); return; }
  // 2.3: облачный инвентарь (inv_get, inv_migrate, case_open, bp_buy, bp_claim, op_buy, promo) и рынок (mk_*)
  if (eco.handle(c, m) || market.handle(c, m)) return;
  // 2.4: друзья и пати (fr_*, pt_*)
  if (friends.handle(c, m)) return;
  switch (m.t) {
    case 'list': if (limited(c, 'list', 10)) return; c.send({ t: 'rooms', list: [...rooms.values()].filter(r => r.pub).map(r => r.info()), online: conns.size }); return;
    case 'quick': {
      if (c.room) c.room.leave(c);
      let map0 = mapOf(m.map);
      const mode = MODES.includes(m.mode) ? m.mode : map0 === DUEL_MAP ? 'duel' : SMALL.includes(map0) ? 'bomb' : 'tdm';
      if (mode !== 'duel' && map0 === DUEL_MAP) map0 = null;
      const map = mode === 'duel' ? DUEL_MAP : map0;
      // открытая комната с этим режимом, где есть место, — иначе новая
      let best = null;
      // этот телефон недавно выпал из открытого матча — вернуть туда же
      for (const r of rooms.values()) if (r.pub && r.mode === mode && c.key && r.held.has(c.key) && !r.g.over) { best = r; break; }
      if (!best) for (const r of rooms.values()) {
        if (!r.pub || r.mode !== mode || (map && r.map !== map) || (!map && SMALL.includes(r.map)) || r.g.over) continue;
        if (r.pvp) {
          // «Вилла»: где больше людей; при равенстве — где ещё разминка
          const h = r.seats();
          if (h >= r.size * 2) continue;
          const sc = h * 2 + (r.phase !== 'match' ? 1 : 0);
          if (!best || sc > best.seats() * 2 + (best.phase !== 'match' ? 1 : 0)) best = r;
          continue;
        }
        const h = r.humans().length;
        if (h >= r.size * 2) continue;
        if (!best || h > best.humans().length) best = r;
      }
      if (!best) {
        if (rooms.size >= MAX_ROOMS) { c.send({ t: 'err', m: 'Сервер заполнен, попробуйте позже' }); return; }
        best = new Room({ pub: true, mode, map: map || undefined, size: mode === 'duel' ? 1 : 5, diff: 'normal' });
      }
      if (!best.join(c)) c.send({ t: 'err', m: 'Комната заполнена' });
      return;
    }
    case 'create': {
      if (c.room) c.room.leave(c);
      if (rooms.size >= MAX_ROOMS) { c.send({ t: 'err', m: 'Сервер заполнен, попробуйте позже' }); return; }
      const r = new Room({ pub: false, mode: m.mode, map: m.map, size: m.size, diff: m.diff });
      r.join(c);
      return;
    }
    case 'join': {
      const code = String(m.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
      const r = rooms.get(code);
      if (!r) { c.send({ t: 'err', m: 'Комната ' + (code || '') + ' не найдена' }); return; }
      if (c.room === r) return;
      if (!r.canEnter(c)) { c.send({ t: 'err', m: r.lobby ? 'Это матч лобби — войдите в лобби по его коду' : 'Это рейтинговый матч' }); return; }
      if (c.room) c.room.leave(c);
      if (!r.join(c)) c.send({ t: 'err', m: r.ranked || r.lobby ? 'Матч уже закончился' : 'Комната заполнена' });
      return;
    }
    case 'leave': if (c.room) c.room.leave(c); c.send({ t: 'left' }); return;
    // ---------- «Напарники»: рейтинговый поиск и клановые войны ----------
    case 'rq': {
      const kind = m.kind === 'cw' ? 'cw' : m.kind === 'ranked' ? 'ranked' : '';
      // очередь: не чаще 5 действий в секунду и 30 входов/выходов в минуту
      if (limited(c) || limited(c, 'rq', 30, 60000)) { c.send({ t: 'rq_err', kind, m: 'Слишком часто — подождите немного' }); return; }
      if (!c.acc) { c.send({ t: 'rq_err', kind, m: kind === 'cw' ? 'Войдите в аккаунт, чтобы играть клановые войны' : 'Войдите в аккаунт, чтобы играть в рейтинге' }); return; }
      // незаконченный рейтинговый матч: вернуться в него вместо новой очереди
      const rr = rankedRoomOf(c.acc.id);
      if (rr) {
        if (c.room === rr) { c.send({ t: 'rq_err', kind, m: 'Вы уже в рейтинговом матче' }); return; }
        if (seatBusy(rr, c)) { c.send({ t: 'rq_err', kind, m: 'Этот аккаунт уже играет рейтинговый матч на другом устройстве' }); return; }
        backToRanked(c, rr);
        return;
      }
      for (const o of accConns.get(c.acc.id) || []) if (o !== c && o.room) { c.send({ t: 'rq_err', kind, m: 'Этот аккаунт сейчас в матче на другом устройстве' }); return; }
      // сначала проверка, потом выход из комнаты и очередь
      const bad = mm.check(c, kind);
      if (bad) { c.send({ t: 'rq_err', kind, m: bad }); return; }
      // 2.4: пати «Напарники» — поиск начинает лидер, в очередь встают оба
      const P = kind === 'ranked' ? friends.party(c.acc.id) : null;
      if (P) {
        const mateId = P.lead === c.acc.id ? P.mate : P.lead, mate = db.data.accounts[mateId];
        if (P.lead !== c.acc.id) { c.send({ t: 'rq_err', kind, m: 'Поиск начинает лидер пати — ' + (mate ? mate.nick : 'лидер') }); return; }
        const mc = (readyConns(mateId).filter(o => (o.cv | 0) >= FRIENDS_CV))[0] || null;
        if (!mc) { c.send({ t: 'rq_err', kind, m: 'Напарник не в сети' }); return; }
        const free = readyConns(mateId).filter(o => (o.cv | 0) >= FRIENDS_CV && !o.room);
        if (!free.length) { c.send({ t: 'rq_err', kind, m: 'Напарник сейчас в матче — дождитесь его' }); return; }
        if (rankedRoomOf(mateId)) { c.send({ t: 'rq_err', kind, m: 'У напарника не закончен рейтинговый матч' }); return; }
        const mfree = free.sort((x, y) => (x.lobby ? 1 : 0) - (y.lobby ? 1 : 0))[0];
        const mbad = mm.check(mfree, kind);
        if (mbad) { c.send({ t: 'rq_err', kind, m: 'Напарник: ' + mbad }); return; }
        for (const o of [c, mfree]) {
          if (o.lobby) lobbyHub.leave(o, 'room');
          if (o.room) { o.room.leave(o); o.send({ t: 'left' }); }
        }
        const queued = !!(c.q && c.q.pid === P.id);
        const perr = mm.joinParty([c, mfree], P.id);
        if (perr) { c.send({ t: 'rq_err', kind, m: perr }); return; }
        if (!queued) log('queue party', c.acc.nick, '+', mate ? mate.nick : '?');
        return;
      }
      if (c.lobby) lobbyHub.leave(c, 'room');      // 2.2: в рейтинг — из лобби
      if (c.room) { c.room.leave(c); c.send({ t: 'left' }); }
      const queued = !!c.q;
      mm.join(c, kind);
      if (!queued) log('queue', kind, c.acc.nick, c.acc.rating);
      return;
    }
    // выйти из очереди (после rq_found матч уже не отменить — он начнётся через 3,5 с)
    case 'rq_leave':
      if (limited(c, 'rq', 30, 60000)) return;
      if (c.q) mm.leave(c, true); else if (!c.found) c.send({ t: 'rq', kind: m.kind === 'cw' ? 'cw' : 'ranked', st: 'off' });
      return;
    // подарок дошёл до телефона и зачислен — только теперь он считается доставленным
    case 'gift_ok': if (typeof m.id === 'string' && m.id.length <= 32) giftAck(c, m.id); return;
    case 'lb': {
      if (limited(c)) return;
      const lb = leaderboard();
      c.send({
        t: 'lb',
        players: lb.players.map(a => { const cl = clanOf(a.id); return { nick: a.nick, rating: a.rating, wins: a.wins, losses: a.losses, tag: cl ? cl.tag : null, color: cl ? cl.color : null, num: a.num, av: A.avObj(a), eq: A.equipped(a, db.data.clans) }; }),
        clans: lb.clans.map(cl => clans.short(cl))
      });
      return;
    }
    case 'clans': case 'clan': case 'clan_create': case 'clan_join': case 'clan_join_code': case 'clan_leave':
    case 'clan_kick': case 'clan_role': case 'clan_edit': case 'clan_disband': case 'clan_say':
    case 'clan_req': case 'clan_req_ok': case 'clan_req_no':   // 2.4: заявки в закрытый клан
      if (limited(c)) { c.send({ t: 'clan_err', m: 'Слишком часто — подождите секунду' }); return; }
      clans.handle(c, m);
      return;
    case 'reg': case 'login': case 'logout': case 'nick': case 'av': case 'avatar': case 'medals':
      profile.handle(c, m);
      return;
    case '__test': if (TEST_HOOKS) testHook(c, m); return;
    // 2.4: игрок сменил прицел — код виден другим в таблице счёта
    case 'xh': {
      if (limited(c, 'xh', 4, 5000)) return;
      const xh = cleanXh(m.c);
      if (xh === (c.xh || null)) return;
      c.xh = xh;
      if (c.actor && c.room) { c.actor.xh = xh; c.room.sendRoster(); }
      return;
    }
    // 2.1: игрок сменил оперативника — запоминаем; в комнате все получат новый ростер
    case 'ops': {
      if (limited(c, 'ops', 6, 5000)) return;
      const ops = cleanOps(m.ops);
      if (JSON.stringify(ops) === JSON.stringify(c.ops || null)) return;
      c.ops = ops;
      if (c.actor && c.room) { c.actor.ops = ops; c.room.sendRoster(); }
      return;
    }
  }
  if (c.room) c.room.onMsg(c, m);
}
// автотесты (SZ_TEST_HOOKS=1): end — закончить матч (squad 0/1 — победа состава, null — ничья, без squad — по счёту),
// half — смена сторон, score — выставить счёт [сторона 0, сторона 1] (и номер раунда round), rend — закончить раунд (2.2)
function testHook(c, m) {
  const r = c.room;
  if (!r) return;
  const B = r.G.bombMode;
  if (m.op === 'end') {
    if (!('squad' in m)) r.g.endMatch();
    else { const s = m.squad === 0 || m.squad === 1 ? m.squad : null; r.g.endMatch({ win: s == null ? null : r.ranked ? r.teamOfSquad(s) : s }); }
  } else if (m.op === 'half' && r.mode === 'bomb' && !r.g.over) { B.halftime(); B.startRound(); }
  else if (m.op === 'score' && Array.isArray(m.sc) && r.mode === 'bomb') { B.score = [m.sc[0] | 0, m.sc[1] | 0]; if (Number.isInteger(m.round)) B.round = m.round; }
  // 2.2: закончить текущий раунд победой стороны win (проверка овертайма лобби)
  else if (m.op === 'rend' && r.mode === 'bomb' && !r.g.over && B.phase !== 'end' && B.phase !== 'wait') B.endRound(m.win === 1 ? 1 : 0, 'elim');
  r.flushEvents();
}

// ---------- действия админа ----------
function kickAcc(id, code, msg) {
  let n = 0;
  for (const c of [...(accConns.get(id) || [])]) {
    if (c.room) c.room.leave(c);
    mm.leave(c, false);
    c.send({ t: 'err', code: code === 4003 ? 'ban' : 'kick', m: msg });
    try { c.ws.close(code, code === 4003 ? 'banned' : 'kicked'); } catch (e) { }
    n++;
  }
  // игрок с этим аккаунтом, ждущий возвращения после обрыва, тоже выходит
  for (const r of rooms.values()) if ([...r.held.values()].some(h => h.p.accId === id)) r.expireHeld(p => p.accId === id);
  return n;
}
const admin = createAdmin({
  VERSION, STARTED, ADMIN_FILE, db, log, logLines, rooms, conns, accConns, clans, mm, realIp, profile,
  // 2.3: раздел «Рынок» и облачный инвентарь в карточке игрока
  routes: (R) => marketRoutes(R, { eco, market, gd, db, log }),
  cloudOf(id) { const v = eco.get(id); return v ? { coins: v.coins, items: v.items.length, esc: market.escrow(id), frozen: market.frozen(id) ? 1 : 0 } : null; },
  isOnline: (id) => accConns.has(id),
  clanOf, leaderboard,
  roomOfAcc(id) { for (const c of accConns.get(id) || []) if (c.room) return c.room.code; return null; },
  roomPlayers(r) {
    const rtt = new Map(); for (const c of r.clients) if (c.actor) rtt.set(c.actor, c.rtt || 0);
    return r.g.actors.filter(a => a.net).map(a => { const cl = clanOf(a.accId), ac = a.accId && db.data.accounts[a.accId]; return { acc: a.accId || null, num: ac ? ac.num : 0, nick: a.name, tag: cl ? cl.tag : null, team: a.team, k: a.kills | 0, d: a.deaths | 0, ping: rtt.get(a) || 0 }; });
  },
  kick(id) { const n = kickAcc(id, 4002, 'Вас отключил администратор'); log('admin kick', (db.data.accounts[id] || {}).nick, id, 'connections', n); return n; },
  ban(id, hours, reason) {
    const a = db.data.accounts[id], now = Date.now();
    a.ban = { until: hours > 0 ? now + Math.round(hours * 3600000) : 0, reason, at: now };
    db.data.bans = db.data.bans.filter(b => b.acc !== id);
    db.data.bans.push({ acc: id, nick: a.nick, until: a.ban.until, reason, at: now });
    db.dirty(); lbCache = null;
    mm.dropAcc(id);
    kickAcc(id, 4003, A.banText(a.ban));
    log('admin ban', a.nick, id, hours ? hours + 'h' : 'forever', reason ? '(' + reason + ')' : '');
  },
  unban(id) {
    const a = db.data.accounts[id];
    a.ban = null; db.data.bans = db.data.bans.filter(b => b.acc !== id);
    db.dirty(); lbCache = null;
    log('admin unban', a.nick, id);
  },
  mute(id, minutes) {
    const a = db.data.accounts[id];
    a.mute = minutes > 0 ? Date.now() + Math.round(minutes * 60000) : null;
    db.dirty();
    log('admin mute', a.nick, id, minutes ? minutes + 'min' : 'off');
  },
  // подарок: онлайн — сразу, иначе при следующем входе
  // 2.3: у аккаунта облачный инвентарь — монеты зачисляются туда сразу, игре 2.3 остаётся уведомление (cloud: 1)
  gift(id, coins) {
    const a = db.data.accounts[id];
    if (a.gifts.filter(g => !g.cloud).length >= 100) return 'У игрока слишком много неполученных подарков';
    const g = { id: A.newGiftId(), coins, m: 'Подарок от разработчика: +' + coins + ' ' + coinsWord(coins), at: Date.now() };
    if (eco.credit(id, coins, 'gift', { gift: g.id, admin: 1 })) {
      g.cloud = 1;
      // непрочитанных уведомлений о подарках — не больше 30 (монеты уже на аккаунте)
      const cl = a.gifts.filter(x => x.cloud);
      if (cl.length >= 30) { const drop = new Set(cl.slice(0, cl.length - 29).map(x => x.id)); a.gifts = a.gifts.filter(x => !drop.has(x.id)); }
    }
    a.gifts.push(g);
    a.giftSum = (a.giftSum || 0) + coins;
    db.dirty();
    for (const c of readyConns(id)) deliverGifts(c);
    return null;
  },
  rating(id, rating, cal) {
    const a = db.data.accounts[id];
    if (rating == null) { a.rating = A.START_RATING; a.cal = 0; } else { a.rating = rating; if (cal != null) a.cal = cal; }
    db.dirty(); lbCache = null;
    sendMe(id);
    log('admin rating', a.nick, 'num', a.num, rating == null ? 'reset' : rating + (cal != null ? ' cal ' + cal : ''));
  },
  broadcast(text) {
    const s = JSON.stringify({ t: 'ann', m: text });
    let n = 0; for (const c of conns) { c.sendRaw(s); n++; }
    log('admin broadcast', JSON.stringify(text), 'to', n);
    return n;
  },
  motd(text) { db.data.motd = text; db.dirty(); log('admin motd', JSON.stringify(text)); },
  roomClose(code) { const r = rooms.get(code); if (!r) return -1; log('admin room close', code); return r.adminClose(); },
  roomSay(code, text) { const r = rooms.get(code); if (!r) return -1; r.chatSys('Администратор: ' + text); log('admin room say', code, JSON.stringify(text)); return r.clients.size; }
});

const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/admin' || url === '/admin/' || url.startsWith('/admin/')) { admin.handle(req, res, url); return; }
  if (url === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('ok'); return; }
  // проверка из браузера: 64 КБ текста. Дошло до последней строки — провайдер связь не обрезает
  if (url === '/probe') {
    const line = 'Prodigy Strike · проверка связи · ' + '='.repeat(60) + '\n';
    let body = 'Проверка связи с сервером Prodigy Strike. Если внизу появилась строка «ГОТОВО» — всё в порядке.\n\n';
    while (Buffer.byteLength(body) < 65536) body += line;
    body += '\nГОТОВО: связь с сервером в порядке, данные дошли целиком (' + Math.round(Buffer.byteLength(body) / 1024) + ' КБ).\n';
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
    return;
  }
  if (url === '/robots.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('User-agent: *\nDisallow: /admin\nAllow: /\n'); return; }
  if (url === '/stats') {
    const list = [...rooms.values()].map(r => ({ id: r.pub ? r.code : '••••', pub: r.pub, kind: r.ranked || (r.lobby ? 'lobby' : null), mode: r.mode, map: r.g.mapId || r.map, phase: r.phase, players: r.clients.size, waiting: r.held.size, bots: r.g.actors.filter(a => !a.net).length, score: r.score(), over: r.g.over }));
    const q = mm.counts();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify({ version: VERSION, uptimeMin: Math.round((Date.now() - STARTED) / 60000), online: conns.size, queues: { ranked: q.ranked, clan: q.cw }, rooms: list, lobbies: lobbyHub.lobbies.size, memMB: Math.round(process.memoryUsage().rss / 1048576) }, null, 1));
    return;
  }
  const players = [...rooms.values()].reduce((s, r) => s + r.clients.size, 0);
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify({ name: 'Prodigy Strike', ok: true, version: VERSION, proto: PROTO, rooms: rooms.size, players, online: conns.size }));
});
attach(server, '/ws', onConn);
// соединения, которые молчат дольше 45 секунд, закрываем (телефон ушёл из сети); ping раз в 5 с — заодно меряем пинг
setInterval(() => {
  const now = Date.now();
  for (const c of conns) {
    if (now - c.ws.lastSeen > 45000) c.ws.close(1001, 'timeout');
    else c.ws.ping(String(now)); // браузер ответит сам, даже если вкладка в фоне
  }
}, 5000);
// 2.3: «В игре: N» в меню — всем, кто поздоровался, новое число онлайна и комнат, когда оно изменилось (не чаще раза в 5 с)
let onlineSent = '';
setInterval(() => {
  const k = conns.size + ':' + rooms.size;
  if (k === onlineSent) return;
  onlineSent = k;
  const s = JSON.stringify({ t: 'online', n: conns.size, rooms: rooms.size });
  for (const c of conns) if (c.hello) { try { c.sendRaw(s); } catch (e) { } }
}, 5000);
// подбор рейтинговых матчей и клановых войн — раз в секунду
setInterval(() => { try { mm.tick(); } catch (e) { logErr('[mm]', e && e.stack || e); } }, 1000);
setInterval(() => { try { friends.tick(); } catch (e) { logErr('[friends]', e && e.stack || e); } }, +process.env.SZ_FR_TICK_MS || 1000);
// 2.2: лобби — вылетевшие участники, хост не на связи, пустые лобби
setInterval(() => { try { lobbyHub.tick(); } catch (e) { logErr('[lobby]', e && e.stack || e); } }, 1000);
// 2.3: рынок — лоты и запросы старше 7 дней возвращаются владельцам
setInterval(() => { try { market.tick(); } catch (e) { logErr('[market]', e && e.stack || e); } }, +process.env.SZ_MK_TICK_MS || 30000);
// порт занят и т. п.: выйти с ошибкой — systemd перезапустит сервер (а не «живой» процесс без порта)
server.on('error', (e) => { logErr('[listen]', e && e.message || e); process.exit(1); });
server.listen(PORT, () => log('Strike Zone server', VERSION, 'on port', PORT, '· data', DATA_DIR));
process.on('uncaughtException', (e) => logErr('[uncaught]', e && e.stack || e));
process.on('unhandledRejection', (e) => logErr('[unhandled]', e && e.stack || e));
// остановка (systemctl stop/restart, Ctrl+C): сначала сохранить базу
let stopping = false;
function shutdown(sig) {
  if (stopping) return;
  stopping = true;
  log('stopping (' + sig + '), saving data');
  const bye = () => process.exit(0);
  setTimeout(bye, 8000).unref();
  Promise.all([db.flush(), eco.flush()]).then(() => eco.close()).then(bye, bye);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
