'use strict';
/* Strike Zone — онлайн-сервер: комнаты, быстрый поиск матча, комнаты по коду.
   Матч целиком считается здесь (боты, раунды, бомба, попадания); телефоны присылают движение и выстрелы. */
const http = require('http');
const { attach } = require('./lib/ws');
const { createSim } = require('./sim/loader');

const PORT = +process.env.PORT || 8080;
const PROTO = 1;
const VERSION = '1.0.0';
const TICK = 1 / 30;             // шаг симуляции
const SNAP_EVERY = 2;            // снимок состояния каждые 2 шага (15 раз в секунду)
const MAX_ROOMS = 30, MAX_CONN = 200;
const MAPS = ['dust', 'harbor', 'sakura'];
const MODES = ['tdm', 'bomb'];
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const rooms = new Map();
const conns = new Set();
let connSeq = 0;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

function newCode() {
  for (; ;) {
    let c = ''; for (let i = 0; i < 4; i++) c += CODE_ABC[Math.floor(Math.random() * CODE_ABC.length)];
    if (!rooms.has(c)) return c;
  }
}
const r2 = (v) => Math.round(v * 100) / 100;
const r3 = (v) => Math.round(v * 1000) / 1000;
const cleanName = (s) => String(s || 'Игрок').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 14) || 'Игрок';
const cleanText = (s) => String(s || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 90);

// ---------- комната ----------
class Room {
  constructor(opts) {
    this.code = newCode();
    this.pub = !!opts.pub;
    this.mode = MODES.includes(opts.mode) ? opts.mode : 'tdm';
    this.map = MAPS.includes(opts.map) ? opts.map : MAPS[Math.floor(Math.random() * MAPS.length)];
    this.size = Math.max(2, Math.min(5, opts.size | 0 || 5));
    this.diff = ['easy', 'normal', 'hard'].includes(opts.diff) ? opts.diff : 'normal';
    this.clients = new Set();
    this.sim = createSim();
    this.G = this.sim.G;
    this.g = this.G.game;
    this.g.start({ mode: this.mode, map: this.map, size: this.size, diff: this.diff });
    this.G.events.length = 0;
    this.tickN = 0; this.emptyT = 0; this.restartT = 0;
    this.timer = setInterval(() => this.tick(), TICK * 1000);
    rooms.set(this.code, this);
    log('room', this.code, this.pub ? 'public' : 'private', this.mode, this.map);
  }
  humans() { return [...this.clients].filter(c => c.actor); }
  info() { return { code: this.pub ? null : this.code, id: this.code, pub: this.pub, mode: this.mode, map: this.map, size: this.size, diff: this.diff, players: this.clients.size, max: this.size * 2 }; }
  join(c) {
    const p = this.g.addHuman(this.uniqueName(c.name), c.profile);
    if (!p) return false;
    c.room = this; c.actor = p; this.clients.add(c);
    c.send({ t: 'joined', code: this.code, pub: this.pub, mode: this.mode, map: this.map, size: this.size, diff: this.diff, you: p.nid, team: p.team });
    this.flushEvents();
    this.sendRoster();
    this.chatSys(p.name + ' в игре');
    log('join', this.code, p.name, 'team', p.team, 'humans', this.clients.size);
    return true;
  }
  leave(c) {
    if (!this.clients.has(c)) return;
    this.clients.delete(c);
    const p = c.actor; c.room = null; c.actor = null;
    if (p) { this.g.removeHuman(p); this.chatSys(p.name + ' вышел'); }
    this.flushEvents();
    this.sendRoster();
    log('leave', this.code, p && p.name, 'humans', this.clients.size);
  }
  uniqueName(n) {
    const used = new Set(this.g.actors.map(a => a.name));
    if (!used.has(n)) return n;
    for (let i = 2; i < 99; i++) { const m = (n.slice(0, 12) + i); if (!used.has(m)) return m; }
    return n;
  }
  chatSys(text) { this.broadcast({ t: 'ev', l: [['sys', text]] }); }
  sendRoster() {
    const list = this.g.actors.map(a => [a.nid, a.name, a.team, a.net ? 1 : 0, a.net ? a.knifeFor().id : 'knife', a.net && a.gloves ? a.gloves[0] : null]);
    this.broadcast({ t: 'roster', list });
  }
  broadcast(msg) { const s = JSON.stringify(msg); for (const c of this.clients) c.sendRaw(s); }

  tick() {
    const g = this.g, G = this.G;
    try {
      if (g.over) {
        this.restartT += TICK;
        if (this.restartT > 12) this.restartMatch();
      } else g.step(TICK);
    } catch (e) { console.error('[room ' + this.code + ']', e && e.stack || e); }
    this.flushEvents();
    if (++this.tickN % SNAP_EVERY === 0) this.sendSnaps();
    // пустая комната закрывается через минуту
    if (!this.clients.size) { this.emptyT += TICK; if (this.emptyT > 60) this.close(); } else this.emptyT = 0;
  }
  restartMatch() {
    this.restartT = 0;
    if (this.pub) { const i = MAPS.indexOf(this.map); this.map = MAPS[(i + 1) % MAPS.length]; }
    this.g.start({ mode: this.mode, map: this.map, size: this.size, diff: this.diff });
    for (const c of this.clients) if (c.actor) c.send({ t: 'team', team: c.actor.team });
    this.flushEvents();
    this.sendRoster();
  }
  close() {
    clearInterval(this.timer);
    rooms.delete(this.code);
    for (const c of this.clients) { c.room = null; c.actor = null; }
    log('room closed', this.code);
  }

  // события симуляции → сообщения игрокам
  flushEvents() {
    const G = this.G, evs = G.events;
    if (!evs.length) return;
    const all = [], to = new Map();
    const push = (c, e) => { if (!to.has(c)) to.set(c, []); to.get(c).push(e); };
    const clientOf = (a) => { for (const c of this.clients) if (c.actor === a) return c; return null; };
    let roster = false;
    for (const [type, d] of evs) {
      switch (type) {
        case 'shot': {
          const e = ['shot', d.a.nid, d.w, d.mz, d.ends];
          if (d.net) { const sc = clientOf(d.a); for (const c of this.clients) if (c !== sc) push(c, e); }
          else all.push(e);
          break;
        }
        case 'melee': all.push(['mel', d.a.nid]); break;
        case 'hurt': {
          const e = ['hurt', d.v.nid, d.by ? d.by.nid : 0, Math.round(d.amt), d.head ? 1 : 0, d.wid];
          const vc = d.v.net && clientOf(d.v), bc = d.by && d.by.net && clientOf(d.by);
          if (vc) push(vc, e); if (bc && bc !== vc) push(bc, e);
          break;
        }
        case 'kill': all.push(['kill', d.k ? d.k.nid : 0, d.v.nid, d.w, d.head ? 1 : 0, d.k && d.k.net ? d.k.skinOf(d.w) : null]); break;
        case 'blood': all.push(['blood', r2(d.x), r2(d.y), r2(d.z), d.head ? 1 : 0]); break;
        case 'nadeSpawn': all.push(['nade', d.n.id, d.n.owner ? d.n.owner.nid : 0, d.n.type, d.o.map(r3), d.v.map(r3)]); break;
        case 'nadeBoom': all.push(['boom', d.n.id, d.n.type, r2(d.x), r2(d.y), r2(d.z), d.n.owner ? d.n.owner.nid : 0]); break;
        case 'blind': { const c = clientOf(d.a); if (c) push(c, ['blind', r2(d.T), r2(d.k)]); break; }
        case 'bp': { const c = clientOf(d.a); if (c) push(c, ['bp', d.e]); break; }
        case 'spawn': all.push(['spawn', d.a.nid]); break;
        case 'roundStart': all.push(['round', d.round, d.pistol ? 1 : 0, d.half ? 1 : 0]); break;
        case 'live': all.push(['live']); break;
        case 'roundEnd': all.push(['rend', d.win, d.reason]); break;
        case 'planted': all.push(['plant', d.a.nid, d.site, r2(d.x), r2(d.z), r2(d.yaw)]); break;
        case 'defused': all.push(['defused', d.a.nid]); break;
        case 'exploded': all.push(['expl', r2(d.x), r2(d.z)]); break;
        case 'bombPick': all.push(['pick', d.a.nid]); break;
        case 'halftime': all.push(['half']); roster = true; break;
        case 'matchStart': all.push(['mstart', this.mode, this.g.mapId]); roster = true; break;
        case 'matchEnd': all.push(['mend', d.win, d.sc]); break;
        case 'leave': all.push(['gone', d.a.nid]); break;
      }
    }
    evs.length = 0;
    for (const c of this.clients) {
      const mine = to.get(c);
      const l = mine ? all.concat(mine) : all;
      if (l.length) c.send({ t: 'ev', l });
    }
    if (roster) this.sendRoster();
  }

  sendSnaps() {
    const g = this.g, G = this.G, time = g.time;
    const A = g.actors.map(a => {
      let f = (a.alive ? 1 : 0) | (a.using || (a.net && a.netUse) ? 4 : 0) | (a.hasBomb ? 8 : 0) | (a.scoped ? 16 : 0) | (a.onGround ? 64 : 0) | (a.w && a.w.reloadT > 0 ? 128 : 0);
      return [a.nid, r2(a.pos.x), r2(a.pos.y), r2(a.pos.z), r3(a.yaw), r3(a.pitch), f, a.w ? a.w.id : 'knife', Math.ceil(a.hp), Math.round(a.crouchT * 10), a.team, a.spottedUntil > time ? (a.spottedBy == null ? -1 : a.spottedBy) : -2];
    });
    let gs;
    if (g.mode === 'bomb') {
      const B = G.bombMode, b = B.bomb;
      gs = { m: 'bomb', ph: B.phase, t: r2(B.t), r: B.round, sc: B.score, bs: b ? b.state : 'none', bx: b ? r2(b.pos.x) : 0, bz: b ? r2(b.pos.z) : 0, bc: b && b.carrier ? b.carrier.nid : 0, buyT: r2(B.buyT), dn: B.defuser ? B.defuser.nid : 0, dp: B.defuser ? r2(B.defuseT / B.defuseNeed(B.defuser)) : 0, pn: B.planter ? B.planter.nid : 0, pp: B.planter ? r2(B.plantT / B.PLANT) : 0, max: B.MAX, win: B.WIN };
    } else gs = { m: g.mode, sc: g.scores, tl: Math.max(0, Math.round(g.timeLeft)), kl: g.killLimit };
    gs.over = g.over ? 1 : 0;
    const stats = g.actors.map(a => [a.nid, a.kills, a.deaths, a.hs, a.money]);
    const base = { t: 'snap', s: r3(time), a: A, g: gs };
    const statStr = this.tickN % 30 === 0 ? stats : null;
    for (const c of this.clients) {
      const p = c.actor; if (!p) continue;
      const sl = {};
      for (const k of ['primary', 'secondary', 'melee']) { const st = p.slots[k]; sl[k] = st ? [st.id, st.skin || null, st.wear || 0, st.mag, st.reserve] : null; }
      const me = { tp: p.tp, x: r2(p.pos.x), y: r2(p.pos.y), z: r2(p.pos.z), yw: r3(p.yaw), al: p.alive ? 1 : 0, hp: Math.ceil(p.hp), ar: Math.ceil(p.armor), hm: p.helmet ? 1 : 0, kit: p.kit ? 1 : 0, $: p.money, n: [p.nades.he | 0, p.nades.flash | 0, p.nades.smoke | 0], sl, team: p.team, bomb: p.hasBomb ? 1 : 0, k: p.kills, d: p.deaths, hs: p.hs, pr: p.protect > 0 ? 1 : 0 };
      if (g.mode === 'bomb') me.buy = G.bombMode.canBuy(p) ? 1 : 0;
      const msg = Object.assign({ me }, base);
      if (statStr) msg.st = statStr;
      // медленному соединению не досылаем лишнего — следующий снимок всё равно новее
      if (c.ws.backlog > 256 * 1024) continue;
      c.send(msg);
    }
  }

  // ---------- сообщения от игрока ----------
  onMsg(c, m) {
    const p = c.actor, g = this.g;
    if (!p) return;
    switch (m.t) {
      case 'st': if (Array.isArray(m.p)) g.netState(p, m); break;
      case 'shot': if (Array.isArray(m.o) && Array.isArray(m.d)) { const r = g.netShot(p, m); if (r && r.hit) c.send({ t: 'hit', h: 1, hd: r.head ? 1 : 0, k: r.kill ? 1 : 0 }); } break;
      case 'mel': { const r = g.netMelee(p, m); if (r && r.hit) c.send({ t: 'hit', h: 1, hd: r.head ? 1 : 0, k: r.kill ? 1 : 0 }); break; }
      case 'nade': if (Array.isArray(m.o) && Array.isArray(m.v)) g.netNade(p, m); break;
      case 'rl': g.netReload(p, String(m.s)); break;
      case 'buy': g.netBuy(p, m.id); break;
      case 'prim': if (this.G.PRIMARIES.includes(m.w)) p.nextPrimary = m.w; break;
      case 'chat': {
        const text = cleanText(m.m); if (!text) break;
        const now = Date.now();
        if (now - (c.chatT || 0) < 700) break;
        c.chatT = now;
        const e = { t: 'ev', l: [['chat', p.nid, text, m.team ? 1 : 0]] }, s = JSON.stringify(e);
        for (const o of this.clients) if (!m.team || (o.actor && o.actor.team === p.team)) o.sendRaw(s);
        break;
      }
    }
    this.flushEvents();
  }
}

// ---------- соединения ----------
function onConn(ws) {
  if (conns.size >= MAX_CONN) { ws.close(1013, 'full'); return; }
  const c = { id: ++connSeq, ws, room: null, actor: null, name: 'Игрок', profile: {}, msgN: 0, msgT: Date.now(), hello: false };
  c.sendRaw = (s) => ws.send(s);
  c.send = (o) => ws.send(JSON.stringify(o));
  conns.add(c);
  ws.on('message', (raw) => {
    // защита от спама сообщениями
    const now = Date.now();
    if (now - c.msgT > 1000) { c.msgT = now; c.msgN = 0; }
    if (++c.msgN > 150) { if (c.msgN > 400) ws.close(1008, 'flood'); return; }
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    try { handle(c, m); } catch (e) { console.error('[msg]', e && e.stack || e); }
  });
  ws.on('close', () => { if (c.room) c.room.leave(c); conns.delete(c); });
}

function handle(c, m) {
  if (m.t === 'ping') { c.send({ t: 'pong', c: m.c, s: c.room ? r3(c.room.g.time) : 0 }); return; }
  if (m.t === 'hello') {
    if (m.v !== PROTO) { c.send({ t: 'err', code: 'version', m: 'Нужна новая версия игры' }); return; }
    c.hello = true;
    c.name = cleanName(m.name);
    const skins = {};
    if (m.skins && typeof m.skins === 'object') for (const k of Object.keys(m.skins).slice(0, 20)) { const v = m.skins[k]; if (Array.isArray(v)) skins[String(k).slice(0, 12)] = [String(v[0]).slice(0, 40), v[1] | 0]; }
    c.profile = { skins, knife: Array.isArray(m.knife) ? [String(m.knife[0]).slice(0, 12), m.knife[1] ? String(m.knife[1]).slice(0, 40) : null, m.knife[2] | 0] : null, gloves: Array.isArray(m.gloves) ? [String(m.gloves[0]).slice(0, 40), m.gloves[1] | 0] : null, prim: String(m.prim || 'ar') };
    c.send({ t: 'welcome', id: c.id, srv: VERSION, online: conns.size, rooms: rooms.size });
    return;
  }
  if (!c.hello) return;
  switch (m.t) {
    case 'list': c.send({ t: 'rooms', list: [...rooms.values()].filter(r => r.pub).map(r => r.info()), online: conns.size }); return;
    case 'quick': {
      if (c.room) c.room.leave(c);
      const mode = MODES.includes(m.mode) ? m.mode : 'tdm';
      const map = MAPS.includes(m.map) ? m.map : null;
      // открытая комната с этим режимом, где есть место, — иначе новая
      let best = null;
      for (const r of rooms.values()) {
        if (!r.pub || r.mode !== mode || (map && r.map !== map) || r.g.over) continue;
        const h = r.humans().length;
        if (h >= r.size * 2) continue;
        if (!best || h > best.humans().length) best = r;
      }
      if (!best) {
        if (rooms.size >= MAX_ROOMS) { c.send({ t: 'err', m: 'Сервер заполнен, попробуйте позже' }); return; }
        best = new Room({ pub: true, mode, map: map || undefined, size: 5, diff: 'normal' });
      }
      if (!best.join(c)) c.send({ t: 'err', m: 'Комната заполнена' });
      return;
    }
    case 'create': {
      if (c.room) c.room.leave(c);
      if (rooms.size >= MAX_ROOMS) { c.send({ t: 'err', m: 'Сервер заполнен, попробуйте позже' }); return; }
      const r = new Room({ pub: false, mode: m.mode, map: m.map, size: m.size, diff: m.diff });
      r.join(c);
      return;
    }
    case 'join': {
      const code = String(m.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
      const r = rooms.get(code);
      if (!r) { c.send({ t: 'err', m: 'Комната ' + (code || '') + ' не найдена' }); return; }
      if (c.room === r) return;
      if (c.room) c.room.leave(c);
      if (!r.join(c)) c.send({ t: 'err', m: 'Комната заполнена' });
      return;
    }
    case 'leave': if (c.room) c.room.leave(c); c.send({ t: 'left' }); return;
  }
  if (c.room) c.room.onMsg(c, m);
}

const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('ok'); return; }
  const players = [...rooms.values()].reduce((s, r) => s + r.clients.size, 0);
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify({ name: 'Strike Zone', ok: true, version: VERSION, proto: PROTO, rooms: rooms.size, players, online: conns.size }));
});
attach(server, '/ws', onConn);
// соединения, которые молчат дольше 30 секунд, закрываем (телефон ушёл из сети)
setInterval(() => {
  const now = Date.now();
  for (const c of conns) {
    if (now - c.ws.lastSeen > 45000) c.ws.close(1001, 'timeout');
    else if (now - c.ws.lastSeen > 10000) c.ws.ping(); // браузер ответит сам, даже если вкладка в фоне
  }
}, 5000);
server.listen(PORT, () => log('Strike Zone server', VERSION, 'on port', PORT));
process.on('uncaughtException', (e) => console.error('[uncaught]', e && e.stack || e));
