#!/bin/bash
# Подтягивает новую версию с GitHub. Перезапуск — только когда в матчах никого нет (или прошло 2 часа).
cd /opt/strikezone || exit 0
OLD=$(git rev-parse HEAD)
sudo -u strikezone git fetch -q origin || exit 0
NEW=$(git rev-parse origin/HEAD 2>/dev/null || git rev-parse origin/main)
[ "$OLD" = "$NEW" ] && { rm -f /tmp/sz-pending; exit 0; }
PLAYERS=$(curl -fsS --max-time 3 http://127.0.0.1:8080/ | sed -n 's/.*"players":\([0-9]*\).*/\1/p')
[ -f /tmp/sz-pending ] || date +%s > /tmp/sz-pending
WAITED=$(( $(date +%s) - $(cat /tmp/sz-pending) ))
if [ "${PLAYERS:-0}" != "0" ] && [ "$WAITED" -lt 7200 ]; then exit 0; fi
sudo -u strikezone git reset -q --hard "$NEW"
# сервер загружен в репозиторий одним архивом — распаковать поверх
if [ -f strikezone-server.zip ]; then sudo -u strikezone python3 -m zipfile -e strikezone-server.zip . ; fi
# обновились файлы настройки — переустановить их
cp deploy/strikezone.service /etc/systemd/system/strikezone.service
systemctl daemon-reload
systemctl restart strikezone
rm -f /tmp/sz-pending
echo "updated $OLD -> $NEW"
