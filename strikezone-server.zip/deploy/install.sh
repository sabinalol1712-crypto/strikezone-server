#!/bin/bash
# Установка сервера Strike Zone на чистый Ubuntu 24.04 / 26.04 (Hetzner, Timeweb Cloud и другие).
# Запускается один раз при создании сервера. Ход установки: /var/log/cloud-init-output.log
set -e
REPO_DIR=/opt/strikezone
export DEBIAN_FRONTEND=noninteractive

echo "== пакеты"
apt-get update -y
apt-get install -y nodejs git curl python3 ca-certificates
HAVE_CADDY=1
apt-get install -y caddy || { HAVE_CADDY=0; echo "!! caddy не установился — игра будет работать по ws://IP:8080 (без https)"; }

NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)
if [ "$NODE_MAJOR" -lt 16 ]; then
  echo "!! Node.js слишком старый (версия $NODE_MAJOR). Пересоздайте сервер с образом Ubuntu 24.04 или новее."
  exit 1
fi

echo "== пользователь"
id strikezone >/dev/null 2>&1 || useradd --system --home "$REPO_DIR" --shell /usr/sbin/nologin strikezone
chown -R strikezone:strikezone "$REPO_DIR"
git config --system --add safe.directory "$REPO_DIR"

echo "== служба игры"
cp "$REPO_DIR/deploy/strikezone.service" /etc/systemd/system/strikezone.service
cp "$REPO_DIR/deploy/strikezone-update.service" /etc/systemd/system/strikezone-update.service
cp "$REPO_DIR/deploy/strikezone-update.timer" /etc/systemd/system/strikezone-update.timer
systemctl daemon-reload
systemctl enable --now strikezone
systemctl enable --now strikezone-update.timer

# если включён файрвол — открыть порты игры
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow 80/tcp; ufw allow 443/tcp; ufw allow 8080/tcp
fi

echo "== внешний IP"
pub_ip() {
  local ip
  ip=$(curl -fsS --max-time 3 http://169.254.169.254/hetzner/v1/metadata/public-ipv4 2>/dev/null || true)
  if [ -n "$ip" ]; then echo "$ip"; return; fi
  for ip in $(hostname -I); do
    case "$ip" in
      *:*|10.*|127.*|169.254.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*|100.6[4-9].*|100.[7-9][0-9].*|100.1[01][0-9].*|100.12[0-7].*) ;;
      *) echo "$ip"; return ;;
    esac
  done
  curl -fsS --max-time 5 https://api.ipify.org 2>/dev/null || curl -fsS --max-time 5 https://ifconfig.me 2>/dev/null || true
}
IP=$(pub_ip)
echo "IP: $IP"

if [ "$HAVE_CADDY" = "1" ] && [ -n "$IP" ]; then
  echo "== защищённое соединение (https) через Caddy"
  HOST="$(echo "$IP" | tr '.' '-').sslip.io"
  sed "s/__HOST__/$HOST/" "$REPO_DIR/deploy/Caddyfile" > /etc/caddy/Caddyfile
  systemctl enable caddy
  systemctl restart caddy
  echo "== готово: wss://$HOST/ws и ws://$IP:8080/ws"
  echo "$HOST" > /root/strikezone-address.txt
else
  echo "== готово: ws://$IP:8080/ws"
  echo "$IP" > /root/strikezone-address.txt
fi
