#!/bin/bash
# Установка сервера Strike Zone на чистый Ubuntu 24.04 (запускается один раз при создании сервера).
set -e
REPO_DIR=/opt/strikezone
export DEBIAN_FRONTEND=noninteractive

echo "== пакеты"
apt-get update -y
apt-get install -y nodejs caddy git curl

echo "== пользователь"
id strikezone >/dev/null 2>&1 || useradd --system --home "$REPO_DIR" --shell /usr/sbin/nologin strikezone
chown -R strikezone:strikezone "$REPO_DIR"
git config --system --add safe.directory "$REPO_DIR"

echo "== служба игры"
cp "$REPO_DIR/deploy/strikezone.service" /etc/systemd/system/strikezone.service
cp "$REPO_DIR/deploy/strikezone-update.service" /etc/systemd/system/strikezone-update.service
cp "$REPO_DIR/deploy/strikezone-update.timer" /etc/systemd/system/strikezone-update.timer
systemctl daemon-reload
systemctl enable --now strikezone
systemctl enable --now strikezone-update.timer

echo "== защищённое соединение (https) через Caddy"
IP=$(curl -fsS --max-time 5 http://169.254.169.254/hetzner/v1/metadata/public-ipv4 || hostname -I | awk '{print $1}')
HOST="$(echo "$IP" | tr '.' '-').sslip.io"
sed "s/__HOST__/$HOST/" "$REPO_DIR/deploy/Caddyfile" > /etc/caddy/Caddyfile
systemctl enable caddy
systemctl restart caddy

echo "== готово: wss://$HOST/ws"
echo "$HOST" > /root/strikezone-address.txt
