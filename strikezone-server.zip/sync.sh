#!/bin/sh
# Копирует игровые модули из клиента: сервер считает матч тем же кодом, что и игра
SRC=${1:-/home/claude/game}
DST=$(dirname "$0")/game
for f in util anim weapons maps nav actors nades modes drops; do cp "$SRC/js/$f.js" "$DST/"; done
# 2.3: данные экономики (скины и кейсы, пропуск, оперативники, промокоды) — сервер ведёт облачный инвентарь и рынок по ним
for f in skins bp opsdata promodata; do cp "$SRC/js/$f.js" "$DST/"; done
cp "$SRC/three.min.js" "$DST/"
echo synced
