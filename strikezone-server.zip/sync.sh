#!/bin/sh
# Копирует игровые модули из клиента: сервер считает матч тем же кодом, что и игра
SRC=${1:-/home/claude/game}
DST=$(dirname "$0")/game
for f in util anim weapons maps nav actors nades modes drops; do cp "$SRC/js/$f.js" "$DST/"; done
cp "$SRC/three.min.js" "$DST/"
echo synced
