'use strict';
/* Делает guard_manifest.json по файлам клиента (папка assets из APK или распакованной игры).
   Запуск: node tools/make_manifest.js /путь/к/assets
   Хеш и «слепок» считаются так же, как в js/guard.js игры. Запускайте после каждой сборки новой версии игры. */
const fs = require('fs'), path = require('path');
const dir = process.argv[2];
if (!dir) { console.error('Укажите папку assets: node tools/make_manifest.js /путь/к/assets'); process.exit(1); }
const hash = (u8) => {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < u8.length; i++) { const c = u8[i]; h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
};
const files = ['index.html', 'three.min.js'].concat(fs.readdirSync(path.join(dir, 'js')).filter(f => f.endsWith('.js')).sort().map(f => 'js/' + f));
const out = { digests: [], files: {} };
for (const f of files) out.files[f] = hash(fs.readFileSync(path.join(dir, f)));
const ks = Object.keys(out.files).sort();
out.digests.push(hash(Buffer.from(ks.map(k => k + ':' + out.files[k]).join('|'), 'utf8')));
const target = path.join(__dirname, '..', 'guard_manifest.json');
// старые слепки остаются действительными, пока в игре не обновились все (до 5 штук)
let old = []; try { old = JSON.parse(fs.readFileSync(target, 'utf8')).digests || []; } catch (e) { }
out.digests = [out.digests[0]].concat(old.filter(d => d !== out.digests[0])).slice(0, 5);
fs.writeFileSync(target, JSON.stringify(out, null, 1));
console.log('guard_manifest.json готов:', files.length, 'файлов, слепок', out.digests[0]);
