const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const fs = require('fs');
const OUT = process.argv[2];
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 1200, height: 520 }, deviceScaleFactor: 2 });
  const p = await ctx.newPage();
  p.on('pageerror', e => console.log('pageerror', e.message));
  await p.goto('http://127.0.0.1:8765/');
  await p.waitForFunction(() => window.G && G.game && G.game.state === 'menu' && G.mk3d, null, { timeout: 90000 });
  await p.waitForTimeout(3000);
  const ids = await p.evaluate(() => { G.mk3d.open(); return Object.keys(G.SKINS); });
  console.log('skins', ids.length);
  const meta = {};
  let n = 0, fail = [];
  for (let i = 0; i < ids.length; i += 6) {
    const chunk = ids.slice(i, i + 6);
    const res = await p.evaluate((l) => l.map(id => { try { return [id, G.mk3d._make(id), G.SKINS[id].w, G.SKINS[id].r]; } catch (e) { return [id, null, 0, 0, String(e)]; } }), chunk);
    for (const [id, url, w, r, er] of res) {
      if (!url) { fail.push(id + (er ? ' ' + er : '')); continue; }
      fs.writeFileSync(OUT + '/' + id + '.png', Buffer.from(url.split(',')[1], 'base64'));
      meta[id] = { w, r }; n++;
    }
  }
  console.log('done', n, 'fail', fail.length, fail.slice(0, 10).join(' | '));
  await b.close();
})();
