const sharp = require('/home/claude/.npm-global/lib/node_modules/sharp');
const fs = require('fs'), path = require('path');
const [src, dst] = process.argv.slice(2);
(async () => {
  const files = fs.readdirSync(src).filter(f => f.endsWith('.png'));
  for (const f of files) await sharp(path.join(src, f)).trim({ threshold: 1 }).webp({ quality: 82, alphaQuality: 90, effort: 5 }).toFile(path.join(dst, f.replace('.png', '.webp')));
  // обзорный лист для проверки
  const pick = files.filter((f, i) => i % 9 === 0).slice(0, 24);
  const W = 240, H = 92, cols = 4, rows = Math.ceil(pick.length / cols);
  const comp = await Promise.all(pick.map(async (f, i) => ({ input: await sharp(path.join(src, f)).resize(W, H, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer(), left: (i % cols) * W, top: Math.floor(i / cols) * H })));
  await sharp({ create: { width: W * cols, height: H * rows, channels: 4, background: '#141a22' } }).composite(comp).png().toFile(path.join(dst, '..', 'sheet.png'));
})();
