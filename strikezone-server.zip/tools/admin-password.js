'use strict';
// Новый пароль админ-панели прямо на сервере: node tools/admin-password.js
// Пишет data/admin.json (только хеш scrypt, сам пароль нигде не сохраняется). Папка data/ переживает обновления;
// сервер читает файл при каждом входе — перезапуск не нужен. Вернуть пароль из репозитория: удалить data/admin.json.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
let muted = false;
rl._writeToOutput = (s) => { if (!muted || s.includes('\n')) process.stdout.write(muted ? '\n' : s); };
const ask = (q) => new Promise((ok) => { muted = false; process.stdout.write(q); muted = true; rl.question('', (a) => ok(a)); });
(async () => {
  const a = await ask('Новый пароль админ-панели (не меньше 10 символов): ');
  const b = await ask('Ещё раз: ');
  rl.close();
  if (a !== b) { console.log('Пароли не совпали — ничего не изменено'); process.exit(1); }
  if (a.length < 10) { console.log('Слишком короткий пароль — ничего не изменено'); process.exit(1); }
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(a, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const f = path.join(DATA_DIR, 'admin.json');
  fs.writeFileSync(f + '.tmp', JSON.stringify({ algo: 'scrypt', N: 16384, r: 8, p: 1, keylen: 64, salt, hash }) + '\n', { mode: 0o600 });
  fs.renameSync(f + '.tmp', f);
  console.log('Готово: пароль сохранён в ' + f + ' (только хеш). Войти: /admin');
})();
