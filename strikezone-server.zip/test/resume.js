// Обрыв связи и возвращение в матч; вход в режим бомбы посреди раунда
const URL = process.argv[2] || 'ws://localhost:8080/ws';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
function client(name, key) {
  return new Promise((resolve) => {
    const ws = new WebSocket(URL);
    const st = { name, ws, snaps: 0, sys: [], me: null, you: 0, err: null, joined: [] };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', v: 1, key, name, prim: 'ar', skins: { ar: ['ar_flame', 1] }, knife: ['karambit', 'karambit_gold', 0] }));
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      if (m.t === 'welcome') resolve(st);
      else if (m.t === 'joined') { st.you = m.you; st.code = m.code; st.team = m.team; st.joined.push(m); }
      else if (m.t === 'snap') { st.snaps++; st.me = m.me; st.last = m; }
      else if (m.t === 'ev') for (const x of m.l) { if (x[0] === 'sys') st.sys.push(x[1]); }
      else if (m.t === 'err') st.err = m.m;
      else if (m.t === 'roster') st.roster = m.list;
    };
    ws.onclose = (e) => { st.closed = e.code; };
  });
}
(async () => {
  // 1) бомба: A создаёт, ждём начала раунда (live), B входит посреди раунда
  const a = await client('Сабина', 'keyaaaaaaaaaaaaa');
  a.ws.send(JSON.stringify({ t: 'create', mode: 'bomb', map: 'dust', size: 5 }));
  await sleep(500);
  for (let i = 0; i < 40 && !(a.last && a.last.g.ph === 'live'); i++) await sleep(500);
  console.log('phase', a.last.g.ph, 'round', a.last.g.r);
  await sleep(3000);
  const b = await client('Друг', 'keybbbbbbbbbbbbb');
  b.ws.send(JSON.stringify({ t: 'join', code: a.code }));
  await sleep(800);
  console.log('B joined mid-round: alive', b.me && b.me.al, 'hp', b.me && b.me.hp, 'weapons', b.me && JSON.stringify(b.me.sl), 'sys:', b.sys);
  // 2) обрыв у B: соединение закрывается без «выйти»
  const nidB = b.you, posB = b.me && [b.me.x, b.me.z];
  b.ws.close();
  await sleep(1500);
  console.log('A roster after B drop has B?', a.roster.some(r => r[0] === nidB && r[3] === 1));
  const b2 = await client('Друг', 'keybbbbbbbbbbbbb');
  b2.ws.send(JSON.stringify({ t: 'join', code: a.code, resume: 1 }));
  await sleep(800);
  console.log('B resumed: same nid', b2.you === nidB, 'resumed flag', b2.joined[0] && b2.joined[0].resumed, 'pos', posB, '->', b2.me && [b2.me.x, b2.me.z], 'alive', b2.me && b2.me.al);
  // 3) «призрачное» старое соединение: тот же ключ входит, пока старое ещё открыто
  const b3 = await client('Друг', 'keybbbbbbbbbbbbb');
  b3.ws.send(JSON.stringify({ t: 'join', code: a.code }));
  await sleep(800);
  console.log('B3 took over: same nid', b3.you === nidB, 'old closed', b2.closed, 'humans in roster', a.roster.filter(r => r[3]).length);
  // 4) явный выход: место сразу отдаётся боту
  b3.ws.send(JSON.stringify({ t: 'leave' }));
  await sleep(600);
  console.log('after leave humans', a.roster.filter(r => r[3]).length, 'A sys', a.sys.slice(-3));
  // 5) http
  const r = await fetch('http://localhost:8080/stats'); console.log('stats', (await r.text()).slice(0, 200).replace(/\n/g, ''));
  const rb = await fetch('http://localhost:8080/robots.txt'); console.log('robots', JSON.stringify(await rb.text()));
  process.exit(0);
})();
