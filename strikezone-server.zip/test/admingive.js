'use strict';
// 2.10.2: админка — выдать игроку любой скин (износ, штук, продаётся ли) и забрать любой предмет из облачного инвентаря
// (выставленный на рынке — снимается с рынка). Игре приходит свежий инвентарь с пометкой adm.
const { check, summary, startServer, client, newAcc, adminSession, sleep } = require('./lib');

(async () => {
  const srv = await startServer();
  try {
    const acc = newAcc('Получатель');
    const c = await client(srv.url, { name: 'Получатель', acc, cv: 300 });
    await c.wait('me');
    c.send({ t: 'inv_migrate', inv: { coins: 0, items: [{ s: 'm9_sunset', w: 0 }], tokens: {}, ops: [], bp: { season: '', prem: false, got: [] } } });
    await c.wait('inv', m => m.ok === 'inv_migrate', 5000);
    const ad = await adminSession(srv);

    // каталог
    let r = await ad.get('skins_catalog');
    const cat = (r.data && r.data.list) || [];
    check(r.status === 200 && cat.length > 100, 'catalog lists all skins', cat.length);
    const ak = cat.find(x => x.s === 'ar_phoenix'), knife = cat.find(x => x.cls === 'knife'), gl = cat.find(x => x.cls === 'gloves');
    check(ak && ak.label && ak.wn && ak.sn && ak.rc && ak.trade === 1, 'catalog entry: label, weapon, skin name, rarity colour, tradable', ak);
    check(!!knife && !!gl && cat.indexOf(knife) < cat.indexOf(ak), 'knives and gloves listed, knives first', [knife && knife.s, gl && gl.s]);
    const noTrade = cat.find(x => !x.trade);

    // выдать: два AK «Феникс» потёртых, продаются
    let mk = c.msgs.length;
    r = await ad.post('inv_give', { acc: acc.id, s: 'ar_phoenix', w: 2, n: 2, trade: true });
    check(r.status === 200 && r.data.ok && r.data.n === 2 && r.data.t === 1 && r.data.uids.length === 2, 'give 2 × AK Phoenix (tradable) → ok', r.data);
    let inv = await c.wait('inv', m => m.why === 'admin' && m.adm && m.adm.give, 3000, mk);
    check(inv && inv.adm.give.length === 2 && inv.adm.give[0] === 'ar_phoenix', 'player gets the fresh inventory with adm.give', inv && inv.adm);
    const got = inv ? inv.inv.items.filter(i => i.s === 'ar_phoenix') : [];
    check(got.length === 2 && got.every(i => i.w === 2 && i.t === 1 && i.src === 'admin'), 'items in the cloud inventory: wear 2, tradable, source admin', got);

    // нельзя продавать: скин «не для рынка» остаётся t:0 даже с trade:true; trade:false — t:0
    if (noTrade) { r = await ad.post('inv_give', { acc: acc.id, s: noTrade.s, w: 0, n: 1, trade: true }); check(r.status === 200 && r.data.t === 0, 'non-market skin is never tradable', [noTrade.s, r.data]); }
    r = await ad.post('inv_give', { acc: acc.id, num: acc.num, s: knife.s, w: 1, n: 1, trade: false });
    check(r.status === 200 && r.data.t === 0, 'trade:false → not tradable (by account number too)', r.data);

    // ошибки
    r = await ad.post('inv_give', { acc: acc.id, s: 'no_such_skin', w: 0 }); check(r.status === 400, 'unknown skin → 400', r.status);
    r = await ad.post('inv_give', { acc: acc.id, s: 'ar_phoenix', w: 5 }); check(r.status === 400, 'wear 5 → 400', r.status);
    r = await ad.post('inv_give', { acc: acc.id, s: 'ar_phoenix', n: 99 }); check(r.status === 400, '99 items at once → 400', r.status);
    r = await ad.post('inv_give', { acc: 'nobody', s: 'ar_phoenix' }); check(r.status === 404, 'unknown account → 404', r.status);
    const acc2 = newAcc('Безоблака');
    const c2 = await client(srv.url, { name: 'Безоблака', acc: acc2, cv: 300 });
    await c2.wait('me');
    r = await ad.post('inv_give', { acc: acc2.id, s: 'ar_phoenix' }); check(r.status === 409 && /облачного инвентаря/.test(r.data.error), 'account without a cloud inventory → 409', r.data);

    // забрать предмет из инвентаря
    const uid0 = got[0].uid;
    mk = c.msgs.length;
    r = await ad.post('inv_take', { acc: acc.id, uid: uid0 });
    check(r.status === 200 && r.data.ok && r.data.s === 'ar_phoenix' && !r.data.listed, 'take an item → ok', r.data);
    inv = await c.wait('inv', m => m.why === 'admin' && m.adm && m.adm.take, 3000, mk);
    check(inv && inv.adm.take[0] === 'ar_phoenix' && !inv.inv.items.some(i => i.uid === uid0), 'player gets adm.take, the item is gone', inv && inv.adm);
    r = await ad.post('inv_take', { acc: acc.id, uid: uid0 }); check(r.status === 404, 'take the same item again → 404', r.status);

    // выставленный на рынке — снимается и забирается
    const uid1 = got[1].uid;
    mk = c.msgs.length;
    c.send({ t: 'mk_sell', uid: uid1, price: 900 });
    const sold = await c.wait('inv', m => m.ok === 'mk_sell', 3000, mk);
    check(sold && !sold.inv.items.some(i => i.uid === uid1), 'player listed the item on the market', sold && sold.ok);
    r = await ad.get('market_player?acc=' + acc.id);
    check((r.data.listings || []).some(l => l.uid === uid1), 'admin sees the lot', (r.data.listings || []).length);
    r = await ad.post('inv_take', { acc: acc.id, uid: uid1 });
    check(r.status === 200 && r.data.listed === 1, 'take a listed item → lot removed and item taken', r.data);
    r = await ad.get('market_player?acc=' + acc.id);
    check(!(r.data.listings || []).some(l => l.uid === uid1) && !r.data.inv.items.some(i => i.uid === uid1), 'neither on the market nor in the inventory', r.data.inv.items.length);

    // журнал админки
    r = await ad.get('log');
    const lines = (r.data && r.data.lines) || [];
    check(lines.some(l => /admin give .*ar_phoenix/.test(l)) && lines.some(l => /admin take .*ar_phoenix/.test(l)), 'give/take are in the server log');
    c.close(); c2.close(); await sleep(100);
  } catch (e) { console.error(e); check(false, 'exception: ' + (e && e.message)); }
  await srv.stop();
  process.exit(summary('admingive'));
})();
