'use strict';
// 2.3: общее для test/economy.js и test/market.js — данные игры с заполненными opsdata/promodata (в game/ пока заглушки)
// и «стенд» экономики в одном процессе: настоящие lib/economy.js + lib/market.js, поддельные соединения и часы.
const fs = require('fs');
const path = require('path');
const { tmpDir, ROOT } = require('./lib');
const A = require('../lib/accounts');
const { loadGameData } = require('../lib/gamedata');
const { createEconomy } = require('../lib/economy');
const { createMarket } = require('../lib/market');

// хеш промокодов игры (profile.js 2.2 / promodata.js 2.3)
const h53 = (str, seed) => {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
};
const CODES = {
  TESTCOINS: { title: 'TEST: 1500 монет', coins: 1500 },
  TESTCASE: { title: 'TEST: кейс и открытия', cases: ['prodigy'], tokens: { harbor: 2 } },
  TESTKNIFE: { title: 'TEST: случайный нож', knife: true },
  TESTOPS: { title: 'TEST: оперативник', ops: ['ct_rare1'] },
  TESTOWNER: { title: 'TEST: владелец', all: true, owner: true, coins: 1000000 }
};
const OPS = [
  { id: 'ct_assault', team: 0, name: 'Штурм', rarity: 1, price: 0, lock: null }, { id: 't_balaclava', team: 1, name: 'Балаклава', rarity: 1, price: 0, lock: null },
  { id: 'ct_elite', team: 0, name: 'Альфа', rarity: 5, price: 0, lock: 'bp' }, { id: 't_elite', team: 1, name: 'Призрак', rarity: 5, price: 0, lock: 'bp' },
  { id: 'ct_rare1', team: 0, name: 'Редкий', rarity: 3, price: 300, lock: null }, { id: 't_leg1', team: 1, name: 'Легенда', rarity: 5, price: 1500, lock: null },
  { id: 't_arc1', team: 1, name: 'Аркана', rarity: 6, price: 3000, lock: null }
];
let fixDir = null;
function fixtureDir() {
  if (fixDir) return fixDir;
  const dir = tmpDir('gamedata');
  // SZ_FIXTURE_SRC — другая папка с файлами игры (проверка тестов на новых данных скинов/кейсов)
  const src = process.env.SZ_FIXTURE_SRC || path.join(ROOT, 'game');
  for (const f of ['three.min.js', 'util.js', 'anim.js', 'weapons.js', 'skins.js', 'bp.js']) fs.copyFileSync(path.join(src, f), path.join(dir, f));
  fs.writeFileSync(path.join(dir, 'opsdata.js'), "'use strict';\n(function () { G.OPS_DATA = " + JSON.stringify(OPS) + "; })();\n");
  const table = {}; for (const k of Object.keys(CODES)) table[h53(k, 1712)] = CODES[k];
  fs.writeFileSync(path.join(dir, 'promodata.js'), "'use strict';\n(function () {\n  const h53 = " + h53.toString() + ";\n  G.promoHash = (code) => h53(String(code), 1712);\n  G.PROMO_CODES = " + JSON.stringify(table) + ";\n})();\n");
  return (fixDir = dir);
}

// поддельное соединение: копит всё, что ему отправили
let connSeq = 0;
function fakeConn(a, cv) {
  const c = { id: ++connSeq, acc: a, cv: cv == null ? 230 : cv, hello: true, ready: true, out: [] };
  c.send = (o) => { c.out.push(JSON.parse(JSON.stringify(o))); };
  c.sendRaw = (s) => { c.out.push(JSON.parse(s)); };
  return c;
}
// стенд: экономика + рынок в процессе; t — поддельные часы
function bench(opts) {
  opts = opts || {};
  const dir = opts.dir || tmpDir('eco');
  const gd = opts.gd || loadGameData({ dir: fixtureDir() });
  const accounts = opts.accounts || Object.create(null);
  const db = { data: { accounts }, dirty() { } };
  const conns = new Map();
  const clock = opts.clock || { t: 1.7e12 };
  const now = () => clock.t;
  const eco = createEconomy({ gd, dir, db, conns: (id) => conns.get(id), now, rankRewards: A.RANK_REWARDS, delay: 50, mkcfg: () => market.cfg() });
  const market = createMarket(eco, { gd, db, conns: (id) => conns.get(id), now });
  let num = opts.num || 100;
  const B = {
    dir, gd, db, eco, market, clock, conns, accounts,
    user(nick, cv) {
      const a = A.newAccount({ id: A.newId(), num: ++num, nick: nick || 'Игрок' + num, ph: null });
      accounts[a.id] = a;
      const c = fakeConn(a, cv);
      conns.set(a.id, new Set([c]));
      return c;
    },
    // второе устройство того же аккаунта
    device(c, cv) { const d = fakeConn(c.acc, cv); conns.get(c.acc.id).add(d); return d; },
    // отправить сообщение, вернуть всё, что пришло этому соединению в ответ
    // autoTick: часы идут вперёд после каждого сообщения (5 действий в секунду не упираются в ограничение частоты)
    autoTick: 210,
    send(c, m) { const k = c.out.length; if (!eco.handle(c, m)) market.handle(c, m); clock.t += B.autoTick; return c.out.slice(k); },
    // последний ответ нужного типа
    ask(c, m, t) { const r = B.send(c, m); return r.filter(x => !t || x.t === t).pop() || r.pop() || null; },
    inv(c) { return eco.get(c.acc.id); },
    // аккаунт с облачным инвентарём: «чистые» монеты (как подарок админа) и tradable-предметы (как из кейсов)
    rich(nick, coins, skins) {
      const c = B.user(nick);
      B.ask(c, { t: 'inv_migrate', inv: { coins: 0, items: [], tokens: {}, ops: [], bp: {} } }, 'inv');
      const inv = eco.get(c.acc.id);
      if (coins > 0) eco.credit(c.acc.id, coins, 'gift');
      for (const [s, w] of skins || []) inv.items.unshift(eco.makeItem(s, w, 1, 'case'));
      return c;
    },
    tick(ms) { clock.t += ms || 1100; },
    // проверка инвариантов: монеты на руках + в запросах + сожжённые = выпущенные; все предметы на месте, uid не повторяются
    invariants() {
      const st = eco.data.stat;
      let coins = 0; const uids = new Map(); let dup = 0;
      const put = (it) => { if (uids.has(it.uid)) dup++; uids.set(it.uid, it.s + '|' + it.w); };
      for (const id of Object.keys(eco.data.inv)) { const v = eco.data.inv[id]; coins += v.coins; v.items.forEach(put); if (v.coins < 0 || !Number.isInteger(v.coins) || !(v.bonus >= 0 && v.bonus <= v.coins && Number.isInteger(v.bonus))) dup += 1000; }
      for (const l of market.L.values()) put(l.it);
      const esc = market.escrowTotal();
      return { ok: coins + esc + st.burned === st.minted && dup === 0 && uids.size === st.made, coins, esc, burned: st.burned, minted: st.minted, items: uids.size, made: st.made, dup, uids };
    },
    async reload() {
      await eco.flush();
      return bench({ dir, gd, accounts, clock, num: num + 1000 });
    }
  };
  return B;
}
module.exports = { fixtureDir, bench, fakeConn, h53, CODES, OPS };
