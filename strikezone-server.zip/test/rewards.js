'use strict';
// «Напарники»: ранги, награды за ранги (на всю жизнь — сумма 1420), медали рангов; чистые функции и целиком через сервер.
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');
const A = require('../lib/accounts');

(async () => {
  console.log('== unit: ranks');
  const names = ['Бронза I', 'Бронза II', 'Бронза III', 'Бронза IV', 'Серебро I', 'Серебро II', 'Серебро III', 'Серебро IV', 'Золото I', 'Золото II', 'Золото III', 'Золото IV', 'Феникс', 'Рейнджер', 'Чемпион', 'Мастер', 'Элита', 'Легенда'];
  const mins = [0, 700, 775, 850, 925, 1000, 1075, 1150, 1225, 1300, 1375, 1450, 1525, 1625, 1725, 1850, 2000, 2200];
  check(A.RANKS.length === 18 && A.RANKS.every((r, i) => r[0] === names[i] && r[1] === mins[i]), '18 ranks with the PROTOCOL.md minimum ratings');
  check(A.rankIndex(0) === 0 && A.rankIndex(699) === 0 && A.rankIndex(700) === 1 && A.rankIndex(999) === 4 && A.rankIndex(1000) === 5 && A.rankIndex(2199) === 16 && A.rankIndex(2200) === 17 && A.rankIndex(9999) === 17, 'rankIndex boundaries');
  check(JSON.stringify(A.RANK_REWARDS) === JSON.stringify([20, 25, 30, 35, 45, 50, 55, 60, 70, 75, 80, 85, 90, 100, 115, 125, 140, 220]) && A.RANK_REWARDS.reduce((a, b) => a + b, 0) === 1420, 'reward table sums to 1420');

  console.log('== unit: rewards through all ranks');
  const mk = () => { const a = A.newAccount({ id: 'a' + rnd(11), num: 9, nick: 'Юнит', ph: null }); a.cal = 5; return a; };
  const a = mk(); let sum = 0, events = [], medals = new Set();
  for (let r = 900; r <= 2400; r += 5) {
    a.rating = r;
    const out = A.applyRank(a);
    for (const w of out.rewards) { sum += w.coins; events.push(w.rank); check(w.coins === A.RANK_REWARDS[w.rank] && w.m === 'Новый ранг «' + names[w.rank] + '»: +' + w.coins + ' монет', 'reward text for ' + names[w.rank]); }
    out.medals.forEach(m => medals.add(m));
  }
  check(sum === 1420 && events.length === 18 && new Set(events).size === 18 && a.peak === 17 && a.rewards.length === 18, 'climbing through every rank pays exactly 1420 once per rank', [sum, events.length, a.peak]);
  check(events.slice(0, 6).join() === '0,1,2,3,4,5', 'first rated rank catches up the lower ranks (rating 1000 → ranks 0…5)', events.slice(0, 6));
  check(['r_bronze', 'r_silver', 'r_gold', 'r_phoenix', 'r_ranger', 'r_champion', 'r_master', 'r_elite', 'r_legend'].every(m => medals.has(m) && a.medals.includes(m)), 'every r_* medal granted on the way');
  a.rating = 800; check(A.applyRank(a).rewards.length === 0 && a.peak === 17, 'demotion pays nothing, peak stays');
  a.rating = 2300; check(A.applyRank(a).rewards.length === 0, 'reaching a rank again pays nothing (lifetime)');
  const c4 = mk(); c4.cal = 4; c4.rating = 2300;
  check(A.applyRank(c4).rewards.length === 0 && c4.peak === -1, 'no rank (and no reward) during calibration');
  const fr = mk(); fr.rating = 1030; const fo = A.applyRank(fr);
  check(fo.rewards.length === 6 && fo.rewards.reduce((s, w) => s + w.coins, 0) === 205 && fr.peak === 5 && fo.medals.join() === 'r_bronze,r_silver', 'first rating 1030 after calibration: ranks 0…5 = 205 coins, bronze + silver medals', [fo.rewards.length, fr.peak, fo.medals]);

  console.log('== unit: medals by rule, passwords, nicks, keys');
  const m = mk();
  m.num = 100; check(A.ownedMedals(m, {}).includes('pioneer') && A.ownedMedals(m, {}).includes('early'), 'num 100 → pioneer + early');
  m.num = 101; check(!A.ownedMedals(m, {}).includes('pioneer') && A.ownedMedals(m, {}).includes('early'), 'num 101 → early only');
  m.num = 1000; check(A.ownedMedals(m, {}).includes('early'), 'num 1000 → early');
  m.num = 1001; check(!A.ownedMedals(m, {}).includes('early'), 'num 1001 → none');
  m.om = 99; check(!A.ownedMedals(m, {}).includes('vet100'), '99 online matches → no vet100'); m.om = 100; check(A.ownedMedals(m, {}).includes('vet100'), '100 online matches → vet100');
  m.clan = 'c1'; check(A.ownedMedals(m, { c1: { leader: m.id } }).includes('clan_leader') && !A.ownedMedals(m, { c1: { leader: 'other' } }).includes('clan_leader'), 'clan_leader only for the leader');
  m.local = ['k100']; m.eq = ['k100', 'k1000', 'vet100', 'nope', 'owner', 'x'];
  check(JSON.stringify(A.equipped(m, {})) === JSON.stringify(['k100', 'vet100']), 'equipped = owned or claimed only', A.equipped(m, {}));
  const ph = await A.hashPassword('пароль-123'); const ph2 = await A.hashPassword('пароль-123');
  check(ph.s !== ph2.s && ph.h !== ph2.h && await A.verifyPassword('пароль-123', ph) && !(await A.verifyPassword('пароль-124', ph)) && !(await A.verifyPassword('', ph)), 'scrypt with a salt per account');
  check(A.badNick('Аб') && A.badNick('x'.repeat(17)) && A.badNick('12 34') && A.badNick('a$b!c') && !A.badNick('Ab_c-1 д') && A.badNick('Админ') === 'Ник занят', 'nick rules');
  check(A.badPass('12345') && !A.badPass('123456') && !A.badPass('x'.repeat(64)) && A.badPass('x'.repeat(65)), 'password rules 6…64');
  const k = mk(); k.keys = []; const ks = []; for (let i = 0; i < 7; i++) { const key = A.newKey(); ks.push(key); A.addKey(k, key); }
  check(k.keys.length === 5 && !A.checkKey(k, ks[0]) && !A.checkKey(k, ks[1]) && ks.slice(2).every(x => A.checkKey(k, x)) && ks.every(x => A.KEY_RE.test(x)), 'at most 5 device keys, oldest evicted');
  check(A.eloDelta(1000, 1000, 1, 0) === 24 && A.eloDelta(1000, 1000, 0, 0) === -24 && A.eloDelta(1000, 1000, 1, 5) === 16 && A.eloDelta(1000, 1000, 0.5, 5) === 0, 'Elo: K 48 in calibration, 32 afterwards');

  console.log('== server: rewards after a rated match');
  const HOLD = 4000;
  const srv = await startServer({ env: { SZ_RANKED_HOLD_MS: String(HOLD), SZ_RANKED_WARM_S: '0' } });
  const adm = await adminSession(srv);
  const people = [];
  async function player(name) {
    const p = { name, acc: newAcc(name), key: 'k' + rnd(15) };
    p.c = await client(srv.url, { name, acc: p.acc, key: p.key });
    await p.c.wait('me');
    people.push(p);
    return p;
  }
  try {
    const ps = await Promise.all(['Награда1', 'Награда2', 'Награда3', 'Награда4'].map(player));
    for (const p of ps) { const r = await adm.post('rating', { acc: p.acc.id, rating: 2300, cal: 5 }); if (r.status !== 200) throw new Error('rating ' + r.status); }
    const marks = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    await Promise.all(ps.map((p, i) => p.c.wait('joined', x => !!x.ranked, 8000, marks[i])));
    await sleep(500);
    const lm = ps.map(p => p.c.mark());
    // Награда4 выпадает перед концом матча: награды ей придут при следующем входе
    const gone = ps[3];
    gone.c.close();
    await sleep(500);
    ps[0].c.send({ t: '__test', op: 'end', squad: 0 });
    const rated = await Promise.all(ps.slice(0, 3).map((p, i) => p.c.wait('rated', null, 4000, lm[i])));
    check(rated.every(Boolean), 'rated sent to the three players still connected');
    await sleep(500);
    for (const [i, p] of ps.slice(0, 3).entries()) {
      const rw = p.c.msgs.slice(lm[i]).filter(x => x.t === 'reward');
      const total = rw.reduce((s, x) => s + x.coins, 0);
      check(rw.length === 18 && total === 1420 && new Set(rw.map(x => x.rank)).size === 18 && rw.every(x => x.coins === A.RANK_REWARDS[x.rank] && x.m === 'Новый ранг «' + names[x.rank] + '»: +' + x.coins + ' монет'),
        p.name + ': 18 reward events (one per rank) = 1420 coins', [rw.length, total]);
      const me = p.c.last('me').acc;
      check(me.peak === 17 && me.rewards.length === 18 && me.medals.includes('r_legend') && me.medals.includes('r_bronze') && me.cal === 5, p.name + ': me has peak 17, rewards [0…17], r_* medals', [me.peak, me.rewards.length]);
      const order = p.c.msgs.slice(lm[i]).map(x => x.t).filter(t => ['rated', 'me', 'reward'].includes(t));
      check(order.indexOf('rated') < order.indexOf('me') && order.indexOf('me') < order.indexOf('reward'), p.name + ': order rated → me → rewards');
    }
    const pa = (await adm.get('player?acc=' + ps[0].acc.id)).data;
    check(pa.rewards.length === 18 && pa.rewardCoins === 1420 && pa.peak === 17 && pa.rank === 'Легенда', 'admin player shows rank rewards (18, 1420 coins), peak, rank', [pa.rewards.length, pa.rewardCoins, pa.rank]);
    // следующий матч — наград больше нет
    await sleep(300);
    // Награда4 вернулась: ей причитаются все 18 наград ровно один раз
    gone.c = await client(srv.url, { name: gone.name, acc: gone.acc, key: gone.key });
    await gone.c.wait('me');
    gone.c.send({ t: 'list' });
    await sleep(800);
    const gr = gone.c.all('reward');
    check(gr.length === 18 && gr.reduce((s, x) => s + x.coins, 0) === 1420, 'a player who was offline at the end gets the 18 rewards on the next login', [gr.length]);
    const gm = gone.c.last('me').acc;
    check(gm.rewards.length === 18 && gm.rating < 2300 && gm.rating >= 2200, 'and the left player was penalised (S = 0, −10) but is still Легенда', gm.rating);
    gone.c.close(); await sleep(200);
    const again = await client(srv.url, { name: gone.name, acc: gone.acc, key: gone.key });
    await again.wait('me'); again.send({ t: 'list' }); await sleep(500);
    check(again.all('reward').length === 0, 'rewards are delivered only once');
    // второй матч тех же троих: наград нет
    again.close();
    const p123 = ps.slice(0, 3);
    const marks2 = p123.map(p => p.c.mark());
    const filler = await player('Награда5');
    await adm.post('rating', { acc: filler.acc.id, rating: 2300, cal: 5 });
    for (const p of [...p123, filler]) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    await Promise.all(p123.map((p, i) => p.c.wait('joined', x => !!x.ranked, 8000, marks2[i])));
    await sleep(400);
    const lm2 = p123.map(p => p.c.mark());
    p123[0].c.send({ t: '__test', op: 'end', squad: 1 });
    await Promise.all(p123.map((p, i) => p.c.wait('rated', null, 4000, lm2[i])));
    await sleep(400);
    check(p123.every((p, i) => p.c.msgs.slice(lm2[i]).filter(x => x.t === 'reward').length === 0), 'a second rated match pays no rank rewards again');
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  const errs = srv.logs.filter(l => /\[room|\[msg\]|\[mm\]|uncaught|Error/.test(l));
  check(errs.length === 0, 'no server errors in log', errs.slice(0, 5));
  await srv.stop();
  process.exit(summary('rewards'));
})();
