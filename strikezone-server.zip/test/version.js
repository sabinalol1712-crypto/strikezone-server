// 1.8: старые версии игры (без cv или cv < 119) получают просьбу обновиться, новые — входят
const URL = process.argv[2] || 'ws://localhost:' + (process.env.PORT || 8080) + '/ws';
const hello = (extra) => new Promise((res) => { const ws = new WebSocket(URL); const out = [];
  ws.onopen = () => ws.send(JSON.stringify(Object.assign({ t: 'hello', v: 1, name: 'T', prim: 'ar', skins: {} }, extra)));
  ws.onmessage = (e) => { out.push(JSON.parse(e.data)); };
  setTimeout(() => { ws.close(); res(out); }, 800); });
(async () => {
  let fail = 0; const ok = (n, c, d) => { console.log((c ? 'PASS ' : 'FAIL ') + n, d || ''); if (!c) fail++; };
  const a = await hello({}); ok('old client asked to update', a.some(m => m.t === 'err' && m.code === 'version') && !a.some(m => m.t === 'welcome'), JSON.stringify(a.map(m => m.t)));
  const b = await hello({ cv: 118 }); ok('11.8 asked to update', b.some(m => m.t === 'err' && m.code === 'version'));
  const c = await hello({ cv: 119, drops: 1 }); ok('11.9 welcomed', c.some(m => m.t === 'welcome' && m.srv === '1.8.0'), JSON.stringify(c.map(m => m.t)));
  console.log(fail ? 'FAILED ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
})();
