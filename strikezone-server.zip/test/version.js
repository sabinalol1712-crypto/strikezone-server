'use strict';
// 2.0: старые версии игры (без cv или cv < 200) получают просьбу обновиться, игра 2.0 (cv 200) — входит; welcome.srv = 2.9.1 (2.3: облако и рынок — с cv 230)
const { check, summary, startServer, client, sleep } = require('./lib');
(async () => {
  const srv = await startServer();
  try {
    const hello = async (cv) => { const c = await client(srv.url, cv === undefined ? { cv: null, ready: false } : { cv, ready: false }); await sleep(300); c.close(); return c; };
    const MSG = 'Вышло обновление Prodigy Strike — установите новую версию игры, чтобы играть по сети';
    for (const cv of [undefined, 119, 120, 199]) {
      const c = await hello(cv);
      const e = c.msgs.find(m => m.t === 'err');
      check(e && e.code === 'version' && e.m === MSG && !c.msgs.some(m => m.t === 'welcome'), 'cv ' + cv + ': asked to update, no welcome', c.msgs);
    }
    const ok = await hello(200);
    const w = ok.msgs.find(m => m.t === 'welcome');
    check(w && w.srv === '2.10.1' && typeof w.motd === 'string' && !ok.msgs.some(m => m.t === 'err'), 'cv 200: welcome srv 2.10.1 with motd (MIN_CV stays 200)', ok.msgs);
    const ok23 = await hello(230);
    check(ok23.msgs.some(m => m.t === 'welcome' && m.srv === '2.10.1'), 'cv 230 (game 2.3): welcome srv 2.10.1', ok23.msgs);
    const pkg = require('../package.json');
    check(pkg.version === '2.10.1', 'package.json version 2.10.1', pkg.version);
    const r = await srv.http('GET', '/');
    check(r.data && r.data.version === '2.10.1' && r.data.proto === 1, 'GET / version 2.10.1, proto 1', r.data);
  } finally { await srv.stop(); }
  // 2.9.1: без SZ_MIN_CV сервер пускает только игру 2.9 (cv 290) — у старых игр нет новых укрытий «Перрона» и «Лагуны»
  const srv2 = await startServer({ env: { SZ_MIN_CV: '' } });
  try {
    const hello2 = async (cv) => { const c = await client(srv2.url, { cv, ready: false }); await sleep(300); c.close(); return c; };
    const MSG2 = 'Вышло обновление Prodigy Strike 2.9 — установите новую версию игры, чтобы играть по сети';
    for (const cv of [200, 254, 280, 289]) {
      const c = await hello2(cv);
      const e = c.msgs.find(m => m.t === 'err');
      check(e && e.code === 'version' && e.m === MSG2 && !c.msgs.some(m => m.t === 'welcome'), 'default gate: cv ' + cv + ' asked to update to 2.9', c.msgs);
    }
    const ok290 = await hello2(290);
    check(ok290.msgs.some(m => m.t === 'welcome' && m.srv === '2.10.1') && !ok290.msgs.some(m => m.t === 'err'), 'default gate: cv 290 (game 2.9) welcome', ok290.msgs);
  } finally { await srv2.stop(); }
  process.exit(summary('version'));
})().catch(e => { console.error(e); process.exit(1); });
