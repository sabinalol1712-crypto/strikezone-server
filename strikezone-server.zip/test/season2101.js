'use strict';
// 2.10.1: награда сезона лиги кланов — тем, кто в клане хотя бы 5 дней до конца сезона или сыграл за клан войну в этом
// сезоне; обычные онлайн-матчи (статистика ms) права на награду не дают; счётчик войн обнуляется с новым сезоном.
// node test/season2101.js (без сети)
const { createClans } = require('../lib/clans');
let fail = 0;
const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };

const now = Date.now(), DAY = 86400000;
const acc = (id, clan) => ({ id, num: 2, nick: id, clan, rating: 1000, cal: 0, medals: [], cw: 0, om: 0, av: null, seen: now });
const data = {
  accounts: { old: acc('old', 'c1'), war: acc('war', 'c1'), fresh: acc('fresh', 'c1'), pub: acc('pub', 'c1') },
  clans: {
    c1: {
      id: 'c1', name: 'Тест', tag: 'TT', color: '#fff', emblem: 0, desc: '', open: true, code: '', leader: 'old', officers: [], members: ['old', 'war', 'fresh', 'pub'],
      created: now - 60 * DAY, pts: 200, wins: 3, losses: 0, chat: [], xp: 0, xpBy: {}, feed: [], reqs: [], notice: '', bank: 0, bankBy: {}, boostUntil: 0, invites: [], wars: [],
      sw: 2, titles: [], ms: { pub: { w: 3, l: 1 } }, wg: {},
      // old — давно; war, fresh, pub — вступили за день до конца сезона
      joined: { old: now - 40 * DAY, war: now - DAY, fresh: now - DAY, pub: now - DAY }
    }
  },
  cs: { n: 4, start: now - 30 * DAY, end: now }
};
const paid = {};
const hub = {
  db: { data, dirty() { } }, log() { }, clanChanged() { }, membershipChanged() { }, lbChanged() { }, isOnline: () => false, sendAcc() { },
  payout(id, n) { paid[id] = (paid[id] || 0) + n; }, eco: () => null
};
const clans = createClans(hub);
// война за клан у «war» (как в server.js после кланового матча), у «pub» — только обычные матчи (ms)
clans.warPlayed('war');
ok('war game counted for the member', data.clans.c1.wg.war === 1);
clans.endSeason();
ok('member of 40 days gets the season prize', paid.old === 600, paid.old);
ok('fresh member who played a clan war gets the prize', paid.war === 600, paid.war);
ok('fresh member without games gets nothing', !paid.fresh, paid.fresh);
ok('fresh member with only ordinary online matches gets nothing', !paid.pub, paid.pub);
ok('war counter reset for the new season', Object.keys(data.clans.c1.wg).length === 0 && data.cs.n === 5);
ok('feed says who gets the prize', /5\+ дней или сыграл войну/.test(data.clans.c1.feed.map(f => f[1]).join(' ')));
console.log(fail ? 'FAILED ' + fail : 'ALL PASSED');
process.exit(fail ? 1 : 0);
