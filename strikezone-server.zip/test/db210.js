'use strict';
// 2.10.1: база переживает перезапуск целиком — поля кланов 2.6 (казна, объявление, буст, приглашения, войны, титулы,
// статистика участников, даты вступления), ежедневный бонус 2.8, сезон лиги кланов; запись db.json порциями даёт тот же JSON.
// node test/db210.js
const fs = require('fs'), os = require('os'), path = require('path');
const { openDb } = require('../lib/db');
let fail = 0;
const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sz-db210-'));
  let db = openDb(dir, () => { });
  const now = Date.now();
  const acc = (id, nick, num, clan) => ({ id, num, nick, ph: null, keys: [], created: now, seen: now, nickAt: 0, rating: 1000, cal: 0, peak: -1, wins: 0, losses: 0, games: 0, cw: 0, om: 0, clan, ban: null, mute: null, gifts: [], giftSum: 0, rpend: [], rcloud: [], tfreeze: 0, matches: [], av: { p: 0, c: 0, n: 0, ext: 'jpg', at: 0 }, medals: [], local: [], eq: [], rewards: [], fr: { list: [], inc: [], out: [] }, cxd: null });
  db.addAccount(Object.assign(acc('a1', 'Лидер', 2, 'c1'), { daily: { d: 20000, s: 3, got: 60 } }));
  db.addAccount(acc('a2', 'Боец', 3, 'c1'));
  db.addAccount(acc('a3', 'Новичок', 4, null));
  db.data.clans.c1 = {
    id: 'c1', name: 'Тест Клан', tag: 'TK', color: '#ff5a1f', emblem: 2, desc: 'Описание', open: true, code: '', leader: 'a1', officers: [], members: ['a1', 'a2'], created: now,
    pts: 120, wins: 3, losses: 1, chat: [], xp: 500, xpBy: { a1: 300, a2: 200 }, feed: [[now, 'событие']], reqs: [],
    notice: 'Объявление', bank: 1500, bankBy: { a1: 1000, a2: 500 }, boostUntil: now + 3600000,
    invites: [{ acc: 'a3', by: 'a1', t: now }], wars: [{ t: now, opp: { id: 'c2', tag: 'XX', name: 'Соперник', color: '#fff', emblem: 0 }, win: true, sc: [7, 3], map: 'dust', dp: 25 }],
    sw: 4, titles: [[1, 2]], ms: { a1: { w: 3, l: 1 } }, joined: { a2: now - 86400000 }, wg: { a2: 1 }
  };
  db.data.cs = { n: 3, start: now - 86400000, end: now + 20 * 86400000 };
  db.data.csHist = [{ n: 2, start: 1, end: 2, top: [] }];
  const want = JSON.stringify(db.data);
  db.dirty(); await db.flush();
  ok('chunked write gives the same JSON as JSON.stringify', fs.readFileSync(path.join(dir, 'db.json'), 'utf8') === want);

  db = openDb(dir, () => { });   // «перезапуск»
  const c = db.data.clans.c1, a1 = db.data.accounts.a1;
  ok('clan bank and donations survive restart', c && c.bank === 1500 && c.bankBy.a1 === 1000 && c.bankBy.a2 === 500);
  ok('clan notice, boost, invites survive', c.notice === 'Объявление' && c.boostUntil > now && c.invites.length === 1 && c.invites[0].acc === 'a3');
  ok('clan wars, season wars, titles, member stats, join dates, war games survive', c.wars.length === 1 && c.sw === 4 && c.titles[0][0] === 1 && c.ms.a1.w === 3 && c.joined.a2 > 0 && c.wg.a2 === 1);
  ok('daily bonus state survives (no second claim after restart)', a1.daily && a1.daily.d === 20000 && a1.daily.s === 3 && a1.daily.got === 60);
  ok('clan league season and history survive', db.data.cs && db.data.cs.n === 3 && db.data.cs.end > now && db.data.csHist.length === 1);
  const once = JSON.stringify(db.data); db.dirty(); await db.flush(); db = openDb(dir, () => { });
  ok('save → load is stable (second restart changes nothing)', JSON.stringify(db.data) === once);

  // большая база: запись не держит цикл событий дольше нескольких десятков мс
  for (let i = 0; i < 8000; i++) db.addAccount(Object.assign(acc('x' + i, 'Игрок' + i, 100 + i, null), { matches: Array.from({ length: 20 }, (_, k) => ({ t: now, map: 'dust', k, win: k & 1, sc: [7, 5] })) }));
  db.dirty(); await db.flush();   // прогрев (сборка мусора после создания 8000 аккаунтов)
  let maxGap = 0, last = Date.now(); const iv = setInterval(() => { const t = Date.now(); maxGap = Math.max(maxGap, t - last); last = t; }, 1);
  db.dirty(); await db.flush(); clearInterval(iv);
  ok('8000 accounts: save stalls the event loop < 60 ms', maxGap < 60, maxGap + ' ms');
  JSON.parse(fs.readFileSync(path.join(dir, 'db.json'), 'utf8'));
  ok('saved file parses', true);
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { }
  console.log(fail ? 'FAILED ' + fail : 'ALL PASSED');
  process.exit(fail ? 1 : 0);
})();
