"""Проверка админ-панели в браузере (Playwright + Chromium): вход, все разделы, шторки игрока/клана/комнаты,
сохранение сообщения дня; в консоли браузера не должно быть ошибок.
Запуск из корня репозитория: python3 test/admin_ui.py"""
import asyncio, json, os, socket, subprocess, sys, tempfile, time, urllib.request

from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PASS = 'test-admin-pass-42'   # тот же, что в test/lib.js
SHOTS = os.environ.get('SHOTS_DIR')
FULL = os.environ.get('SHOTS_FULL') == '1'
results = []


def check(cond, label, extra=None):
    results.append(bool(cond))
    print(('  ok   ' if cond else '  FAIL ') + label + ('' if cond or extra is None else ' ' + str(extra)))


def free_port():
    # порты 8095–8099 (SZ_TEST_PORTS): общий сервер разработки — чужие порты не занимаем
    a, b = [int(x) for x in os.environ.get('SZ_TEST_PORTS', '8095-8099').split('-')]
    for p in range(a, b + 1):
        s = socket.socket()
        try:
            s.bind(('127.0.0.1', p)); s.close(); return p
        except OSError:
            s.close()
    raise RuntimeError('no free port')


async def run_ui(base, viewport, tag):
    errors = []
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
        page = await browser.new_page(viewport=viewport)
        page.set_default_timeout(int(os.environ.get('UI_TIMEOUT_MS', '120000')))   # общий сервер разработки бывает сильно загружен
        page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
        page.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)))
        await page.goto(base + '/admin')
        await page.wait_for_selector('#pw', state='visible')
        await page.fill('#pw', PASS)
        await page.click('#loginBtn')
        await page.wait_for_selector('#app:not([hidden])', timeout=10000)
        await page.wait_for_selector('.room', timeout=10000)
        rooms = await page.locator('.room').count()
        check(rooms >= 2, f'[{tag}] overview shows rooms', rooms)
        check(await page.locator('.room.k-ranked').count() == 1, f'[{tag}] ranked room card marked')
        online = await page.locator('#onlineNum').inner_text()
        check(online.strip() not in ('—', 'нет связи'), f'[{tag}] online counter filled', online)
        if SHOTS: await page.screenshot(path=os.path.join(SHOTS, f'{tag}-overview.png'), full_page=FULL)
        # донат: монеты по № игрока (№2 — первый зарегистрированный, «Командир»)
        await page.fill('#giftNum', '2')
        await page.fill('#giftCoins', '500')
        await page.wait_for_selector('.giftnum .gn-who b:has-text("Командир")')
        await page.click('#giftNumBtn', force=True)
        await page.wait_for_selector('.dlg .btn.primary', timeout=60000)
        if SHOTS: await page.screenshot(path=os.path.join(SHOTS, f'{tag}-gift-confirm.png'))
        await page.click('.dlg .btn.primary', force=True)
        await page.wait_for_selector('.giftnum .result:not([hidden])', timeout=60000)
        check(True, f'[{tag}] gift by number sent')
        # комната (карточки обновляются раз в 5 с — кликаем без ожидания «стабильности»)
        await page.wait_for_timeout(600)   # окно подтверждения закрывается (анимация)
        for attempt in range(4):
            await page.locator('.room').first.click(force=True)
            try:
                await page.wait_for_selector('.sheet[data-sheet="room"]', timeout=8000)
                break
            except Exception:
                if attempt == 3: raise
        await page.wait_for_timeout(400)
        check(await page.locator('.sheet[data-sheet="room"] .prow').count() >= 1, f'[{tag}] room sheet lists players')
        await page.keyboard.press('Escape')
        await page.wait_for_timeout(500)
        for tab in ['players', 'clans', 'rating', 'bans', 'messages', 'market', 'log', 'overview']:
            await page.click(f'.nav-item[data-tab="{tab}"]', force=True)
            await page.wait_for_selector(f'section[data-screen="{tab}"]:not([hidden])', timeout=60000)
            await page.wait_for_timeout(700)
            if SHOTS: await page.screenshot(path=os.path.join(SHOTS, f'{tag}-{tab}.png'), full_page=FULL)
            if tab == 'players':
                n = await page.locator('#playersList .row').count()
                check(n >= 8, f'[{tag}] players list', n)
                await page.locator('#playersList .row').first.click(force=True)
                await page.wait_for_selector('.sheet[data-sheet="player"] .p-rating', timeout=60000)
                check(True, f'[{tag}] player sheet opens')
                await page.wait_for_timeout(500)
                if SHOTS: await page.screenshot(path=os.path.join(SHOTS, f'{tag}-player.png'))
                # кнопка может быть ниже края шторки — прокрутить и нажать событием (force-клик вне окна Playwright не делает)
                act = page.locator('.sheet[data-sheet="player"] [data-act="rating"]')
                await act.scroll_into_view_if_needed()
                await act.dispatch_event('click')
                await page.wait_for_selector('[data-panel="rating"]', timeout=60000)
                await page.keyboard.press('Escape'); await page.wait_for_timeout(500)
            if tab == 'clans':
                n = await page.locator('#clansList .row').count()
                check(n == 1, f'[{tag}] clans list', n)
                await page.locator('#clansList .row').first.click(force=True)
                await page.wait_for_selector('.sheet[data-sheet="clan"] .prow', timeout=60000)
                check(await page.locator('.sheet[data-sheet="clan"] .prow').count() == 3, f'[{tag}] clan sheet lists 3 members')
                await page.keyboard.press('Escape'); await page.wait_for_timeout(500)
            if tab == 'rating':
                check(await page.locator('.lb-cols').count() == 1, f'[{tag}] leaderboard screen')
            if tab == 'bans':
                n = await page.locator('#bansList .row').count()
                check(n == 1, f'[{tag}] bans list shows the ban', n)
            if tab == 'messages':
                await page.fill('#motdText', 'Проверка из браузера ' + tag)
                await page.locator('#motdSave').scroll_into_view_if_needed()
                await page.locator('#motdSave').dispatch_event('click')   # кнопка может быть под нижней панелью вкладок
                await page.wait_for_timeout(800)
                with urllib.request.urlopen(base + '/stats') as r: json.loads(r.read())
            if tab == 'market':   # 2.3: раздел «Рынок»
                check(await page.locator('#mkStats .stat').count() == 4, f'[{tag}] market screen: stats')
                await page.click('[data-mk="player"]', force=True)
                check(await page.locator('.mk-tools input').count() == 1, f'[{tag}] market: player search')
            if tab == 'log':
                n = await page.locator('#logBox .ll').count()
                check(n > 10, f'[{tag}] log lines shown', n)
        await browser.close()
    return errors


async def main():
    port = free_port()
    tmp = os.environ.get('SZ_TEST_TMP') or os.environ.get('TMPDIR')
    if tmp: os.makedirs(tmp, exist_ok=True)
    data = tempfile.mkdtemp(prefix='sz-ui-', dir=tmp)
    admin_file = subprocess.check_output(['node', '-e', "console.log(require('./test/lib').makeAdminFile(process.argv[1]))", data], cwd=ROOT, text=True).strip()
    env = dict(os.environ, PORT=str(port), DATA_DIR=data, ADMIN_FILE=admin_file, SZ_TEST_HOOKS='1', SZ_REG_PER_HOUR='1000')
    log_path = os.path.join(data, 'server.log')
    srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=env, stdout=open(log_path, 'w'), stderr=subprocess.STDOUT)
    fix = None
    try:
        t0 = time.time()
        while ' on port ' not in open(log_path, encoding='utf-8').read():
            if time.time() - t0 > 15 or srv.poll() is not None: raise RuntimeError('server did not start')
            time.sleep(0.05)
        base = f'http://127.0.0.1:{port}'
        fix = subprocess.Popen(['node', 'test/ui_fixture.js', f'ws://127.0.0.1:{port}/ws', base], cwd=ROOT, stdout=subprocess.PIPE, text=True)
        line = fix.stdout.readline()
        check(line.startswith('ready'), 'fixture ready', line)
        for tag, vp in [('desktop', {'width': 1280, 'height': 800}), ('mobile', {'width': 390, 'height': 844})]:
            errs = await run_ui(base, vp, tag)
            check(not errs, f'[{tag}] no console errors', errs[:5])
        with urllib.request.urlopen(base + '/') as r: pass
        req = urllib.request.Request(base + '/admin/api/login', data=json.dumps({'password': PASS}).encode(), headers={'Content-Type': 'application/json', 'X-Forwarded-For': '10.3.3.3'})
        tok = json.loads(urllib.request.urlopen(req).read())['token']
        st = json.loads(urllib.request.urlopen(urllib.request.Request(base + '/admin/api/state', headers={'Authorization': 'Bearer ' + tok})).read())
        check(st['motd'] == 'Проверка из браузера mobile', 'motd saved through the UI', st['motd'])
        pl = json.loads(urllib.request.urlopen(urllib.request.Request(base + '/admin/api/player?num=2', headers={'Authorization': 'Bearer ' + tok})).read())
        check(pl['gifts'] == 1000, 'gift by number arrived (2 × 500 coins, desktop + mobile)', pl['gifts'])
    finally:
        if fix: fix.terminate()
        srv.terminate()
        try: srv.wait(10)
        except Exception: srv.kill()
    print(f"\nadmin_ui: {sum(results)} passed, {len(results) - sum(results)} failed")
    sys.exit(0 if all(results) else 1)


asyncio.run(main())
