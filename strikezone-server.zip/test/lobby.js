'use strict';
// 2.2: кастомные лобби — создание и вход по коду, места команд и наблюдателей, действия хоста, настройки, чат,
// старт матча (бомба 2×2 на «Перроне» с наблюдателем), полная информация у наблюдателя, возврат в лобби, следующая карта,
// овертайм, дуэль, командный бой с ботами, обрыв связи, проверки входных данных, старая игра 2.1 (лобби нет, обычные матчи есть)
const { check, summary, startServer, client, sleep, makeAcc } = require('./lib');
const LC = 220;
(async () => {
  const srv = await startServer({ env: { SZ_LOBBY_BACK_S: '3', SZ_LOBBY_HOLD_MS: '3000', SZ_LOBBY_HOST_MS: '1500', SZ_LOBBY_EMPTY_MS: '2000', SZ_LOBBIES_PER_IP: '6' } });
  const all = [];
  const mk = async (name, o) => { const c = await client(srv.url, Object.assign({ name, cv: LC }, o || {})); all.push(c); return c; };
  const lobbyOf = (c, pred, from) => c.wait('lobby', pred, 6000, from);
  const slotCids = (st, side) => st.slots[side].map(m => (m ? m.cid : 0));
  try {
    // ---------- старая игра 2.1: лобби нет, обычный матч есть ----------
    const old = await mk('Старый', { cv: 210 });
    let mk0 = old.mark();
    old.send({ t: 'lobby_create', mode: 'bomb', map: 'villa', size: 2 });
    const oe = await old.wait('err', m => m.code === 'lobby', 3000, mk0);
    check(oe && /2\.2/.test(oe.m) && /обнов/i.test(oe.m), '2.1 client: clear error for lobbies', oe);
    old.send({ t: 'quick', mode: 'tdm' });
    const oj = await old.wait('joined', null, 8000, mk0);
    check(oj && oj.mode === 'tdm' && !oj.lobby, '2.1 client: casual quick match still works', oj);
    old.send({ t: 'leave' });

    // ---------- создание ----------
    const acc = await makeAcc(srv.url, 'ХостЛобби');
    const A = await mk('Хост', { acc });
    mk0 = A.mark();
    A.send({ t: 'lobby_create', name: 'Кубок <b>района</b> 2026 и ещё очень длинное имя', mode: 'bomb', map: 'villa', size: 2, opts: { win: 5, names: ['Альфа', 'Бета-очень-длинное-имя-команды'], ot: 1, bots: 0, warm: 0 } });
    let st = await lobbyOf(A, null, mk0);
    check(st && /^[A-Z2-9]{5}$/.test(st.code), 'lobby created with 5-char code', st && st.code);
    const code = st.code;
    check(st.host === st.you && st.slots.ct[0] && st.slots.ct[0].cid === st.you, 'creator is host on CT slot 1', st.slots);
    check(st.name.length <= 24 && !/[<>]/.test(st.name), 'lobby name sanitized (≤24, no <>)', st.name);
    check(st.mode === 'bomb' && st.map === 'villa' && st.size === 2 && st.slots.ct.length === 2 && st.slots.t.length === 2 && st.slots.spec.length === 4, 'mode/map/size and slot arrays', [st.mode, st.map, st.size]);
    check(st.opts.win === 5 && st.opts.names[0] === 'Альфа' && st.opts.names[1].length === 16, 'opts: win 5, team names ≤16', st.opts);
    check(st.slots.ct[0].num === acc.num && Array.isArray(st.slots.ct[0].rk) && st.slots.ct[0].av, 'member card: account number, rank, avatar', st.slots.ct[0]);
    const aid = st.you;

    // ---------- вход по коду ----------
    const B = await mk('Боец2'), C = await mk('Боец3', { key: 'kcccccccccccccccc' }), D = await mk('Боец4');
    C.keyUsed = 'kcccccccccccccccc';
    for (const c of [B, C, D]) { const k = c.mark(); c.send({ t: 'lobby_join', code: code.toLowerCase() }); await lobbyOf(c, null, k); }
    st = await lobbyOf(A, s => s.slots.ct.concat(s.slots.t).filter(Boolean).length === 4);
    check(st && st.slots.ct.every(Boolean) && st.slots.t.every(Boolean) && !st.slots.spec.some(Boolean), '3 members joined: 2 CT + 2 T (auto balance)', st && st.slots);
    const bid = B.last('lobby').you, cid = C.last('lobby').you, did = D.last('lobby').you;
    const E = await mk('Зритель'); mk0 = E.mark(); E.send({ t: 'lobby_join', code });
    let se = await lobbyOf(E, null, mk0);
    check(se && se.slots.spec[0] && se.slots.spec[0].cid === se.you, 'teams full → 5th member becomes spectator', se && se.slots.spec);
    const eid = se.you;
    mk0 = E.mark(); E.send({ t: 'lobby_join', code: 'ZZZZZ' });
    check(!!await E.wait('lobby_err', m => /не найдено/.test(m.m), 3000, mk0), 'unknown code → error', E.all('lobby_err'));

    // ---------- места ----------
    const tSlotOfD = st.slots.t.findIndex(m => m && m.cid === did);
    mk0 = D.mark(); D.send({ t: 'lobby_slot', side: 'spec', i: 0 });
    check(!!await D.wait('lobby_err', m => /занято/.test(m.m), 3000, mk0), 'taking an occupied slot → «Место занято»');
    D.send({ t: 'lobby_slot', side: 'spec', i: 2 });
    st = await lobbyOf(A, s => s.slots.spec[2] && s.slots.spec[2].cid === did);
    check(st && !st.slots.t[tSlotOfD], 'member moved himself to spectator slot 3, team slot freed', st && st.slots);
    mk0 = D.mark(); D.send({ t: 'lobby_slot', side: 'xx' });
    check(!!await D.wait('lobby_err', null, 3000, mk0), 'bad side rejected');
    // хост двигает
    mk0 = B.mark(); B.send({ t: 'lobby_move', cid: did, side: 't' });
    check(!!await B.wait('lobby_err', m => /хост/.test(m.m), 3000, mk0), 'non-host cannot move others');
    A.send({ t: 'lobby_move', cid: did, side: 't', i: tSlotOfD });
    st = await lobbyOf(A, s => s.slots.t[tSlotOfD] && s.slots.t[tSlotOfD].cid === did);
    check(!!st, 'host moved member back to T slot', st && st.slots);
    // готовность
    C.send({ t: 'lobby_ready', on: 1 });
    st = await lobbyOf(A, s => s.slots.ct.some(m => m && m.cid === cid && m.ready));
    check(!!st, 'ready flag shown');

    // ---------- исключение и права хоста ----------
    mk0 = E.mark(); A.send({ t: 'lobby_kick', cid: eid });
    const kl = await E.wait('lobby_left', null, 3000, mk0);
    check(kl && kl.why === 'kick', 'kicked member gets lobby_left kick', kl);
    mk0 = E.mark(); E.send({ t: 'lobby_join', code });
    check(!!await E.wait('lobby_err', m => /исключил/.test(m.m), 3000, mk0), 'kicked member cannot rejoin');
    A.send({ t: 'lobby_host', cid: bid });
    st = await lobbyOf(A, s => s.host === bid);
    check(!!st, 'host passed to B');
    mk0 = A.mark(); A.send({ t: 'lobby_set', map: 'lagoon' });
    check(!!await A.wait('lobby_err', m => /хост/.test(m.m), 3000, mk0), 'old host cannot change settings');
    B.send({ t: 'lobby_host', cid: aid });
    st = await lobbyOf(A, s => s.host === aid);
    check(!!st, 'host passed back to A');

    // ---------- настройки: проверка входных данных ----------
    A.send({ t: 'lobby_set', size: 9, map: 'nope', mode: 'ffa', opts: { win: 1000, freeze: -5, buy: 'x', kills: 7, time: 99, diff: 'god', warm: 77, names: ['<script>', 'Х'.repeat(40)], ot: 0 } });
    st = await lobbyOf(A, s => s.opts.ot === 0);
    check(st && st.mode === 'bomb' && st.map === 'villa' && st.size === 2, 'invalid mode/map/size ignored', st && [st.mode, st.map, st.size]);
    check(st && st.opts.win === 5 && st.opts.freeze === 7 && st.opts.buy === 22 && st.opts.kills === 40 && st.opts.time === 5 && st.opts.diff === 'normal' && st.opts.warm === 0, 'invalid opts fall back', st && st.opts);
    check(st && st.opts.names[0] === 'script' && st.opts.names[1].length === 16, 'team names sanitized', st && st.opts.names);
    A.send({ t: 'lobby_set', opts: { ot: 1, names: ['Альфа', 'Бета'], win: 5 } });
    await lobbyOf(A, s => s.opts.ot === 1 && s.opts.names[1] === 'Бета');

    // ---------- чат лобби ----------
    mk0 = B.mark(); C.send({ t: 'lobby_chat', m: 'привет\u0000 <всем>' + 'x'.repeat(200) });
    const ce = await B.wait('lobby_chat', m => m.e && m.e.n === 'Боец3', 3000, mk0);
    check(ce && ce.e.m.length <= 90 && !/\u0000/.test(ce.e.m) && ce.e.s === 'ct', 'lobby chat delivered, sanitized, with side', ce && ce.e);
    mk0 = C.mark(); C.send({ t: 'lobby_chat', m: 'спам' });
    check(!!await C.wait('lobby_err', m => /быстро/.test(m.m), 2000, mk0), 'lobby chat rate-limited');

    // ---------- наблюдатель ----------
    const F = await mk('Комментатор'); mk0 = F.mark(); F.send({ t: 'lobby_join', code });
    const sf = await lobbyOf(F, null, mk0);
    check(sf && sf.slots.spec.some(m => m && m.cid === sf.you), 'caster joined as spectator');
    check(sf && sf.chat.some(e => /привет/.test(e.m)), 'lobby state carries chat history');

    // ---------- старт: бомба 2×2 на «Перроне» ----------
    mk0 = B.mark(); B.send({ t: 'lobby_start' });
    check(!!await B.wait('lobby_err', m => /хост/.test(m.m), 3000, mk0), 'non-host cannot start');
    const marks = [A, B, C, D, F].map(c => c.mark());
    A.send({ t: 'lobby_start' });
    const js = await Promise.all([A, B, C, D, F].map((c, i) => c.wait('joined', null, 8000, marks[i])));
    check(js.every(Boolean), 'all members got joined', js.map(j => !!j));
    const [ja, jb, jc, jd, jf] = js;
    check(ja.lobby === code && ja.code.length === 4 && ja.map === 'villa' && ja.mode === 'bomb' && ja.rmode === 'bomb' && !ja.pub, 'joined: private lobby room on villa, bomb', ja);
    check(ja.team === 0 && jc.team === 0 && jb.team === 1 && jd.team === 1, 'players on their lobby sides (CT: A, C; T: B, D)', js.map(j => j.team));
    check(Array.isArray(ja.tn) && ja.tn[0] === 'Альфа' && ja.tn[1] === 'Бета', 'joined carries team names per side', ja.tn);
    check(jf.spec === 1 && jf.you === 0 && jf.code === ja.code, 'spectator joined with spec: 1, no actor', jf);
    st = await lobbyOf(A, s => s.st === 'match' && s.room);
    check(st && st.room.map === 'villa', 'lobby state shows match in progress');
    await sleep(1200);
    const ro = A.last('roster');
    check(ro && ro.list.length === 4 && ro.list.every(r => r[3] === 1), 'roster: 4 humans, no bots, spectator not listed', ro && ro.list.map(r => r[1]));
    // снимки
    const fs = F.snap, as = A.snap;
    check(fs && Array.isArray(fs.sx) && fs.sx.length === 4 && !fs.me, 'spectator snapshot: sx rows for all 4, no me', fs && Object.keys(fs));
    const row = fs && fs.sx[0];
    check(row && row.length === 14 && typeof row[4] === 'number' && row[4] >= 0 && Number.isInteger(row[5]), 'sx row: [nid, armor, helmet, kit, money, kills, deaths, hs, prim, sec, he, flash, smoke, blind]', row);
    check(fs && fs.sx.every(r => r[9] === 'usp' || r[9] === 'pistol' || typeof r[9] === 'string'), 'spectator sees everyone\'s pistol', fs && fs.sx.map(r => r[9]));
    check(as && as.me && !as.sx, 'player snapshot: me, no sx (no full info for players)', as && Object.keys(as));
    check(fs && fs.a.length === 4 && fs.g.m === 'bomb' && fs.g.win === 5 && fs.g.max === 8, 'spectator gets actors + bomb state (до 5, max 8)', fs && fs.g);
    let tnSeen = null;
    for (let i = 0; i < 150 && !tnSeen; i++) { if (F.snap && Array.isArray(F.snap.tn)) tnSeen = F.snap.tn; await sleep(20); }
    check(tnSeen && tnSeen[0] === 'Альфа', 'spectator periodically gets team names (tn)', tnSeen);
    // чат: наблюдатель → только наблюдателям; командный чат игроков — не наблюдателям
    let mf = F.mark(), ma = A.mark(); F.send({ t: 'chat', m: 'у них эко раунд' });
    await sleep(600);
    check(F.evs(mf).some(e => e[0] === 'schat' && e[3] === 1 && /эко/.test(e[2])), 'spectator sees own spectator chat');
    check(!A.evs(ma).some(e => e[0] === 'schat' || (e[0] === 'chat' && /эко/.test(e[2]))), 'players do not see spectator chat (no ghosting)');
    await sleep(800);
    mf = F.mark(); B.send({ t: 'chat', m: 'идём на А', team: 1 }); await sleep(400);
    await sleep(800); C.send({ t: 'chat', m: 'gl hf' });
    await sleep(600);
    check(!F.evs(mf).some(e => e[0] === 'chat' && /идём/.test(e[2])), 'team chat not leaked to spectators');
    check(F.evs(mf).some(e => e[0] === 'chat' && /gl hf/.test(e[2])), 'all-chat reaches spectators');

    // ---------- конец матча → снова в лобби ----------
    mk0 = A.mark(); const mkf = F.mark();
    A.send({ t: '__test', op: 'end', squad: 0 });
    const me = await A.waitEv('mend', null, 4000, mk0);
    check(me && me[1] === 0, 'match ended (CT win)', me);
    check(!!await F.waitEv('mend', null, 4000, mkf), 'spectator got match end');
    st = await A.wait('lobby', s => s.back === 1, 8000, mk0);
    check(st && st.st === 'idle' && !st.room && st.hist.length === 1 && st.hist[0].map === 'villa' && st.hist[0].win === 0, 'back in lobby with series history', st && st.hist);
    const bf = await F.wait('lobby', s => s.back === 1, 4000, mkf);
    check(!!bf, 'spectator back in lobby too');
    const stt = await srv.http('GET', '/stats');
    check(stt.data && !stt.data.rooms.some(x => x.kind === 'lobby') && stt.data.lobbies >= 1, 'match room closed, lobby kept', stt.data && [stt.data.rooms, stt.data.lobbies]);

    // ---------- вторая карта: «Лагуна» ----------
    A.send({ t: 'lobby_set', map: 'lagoon' });
    await lobbyOf(A, s => s.map === 'lagoon');
    const m2 = [A, B, C, D, F].map(c => c.mark());
    A.send({ t: 'lobby_start' });
    const j2 = await Promise.all([A, B, C, D, F].map((c, i) => c.wait('joined', null, 8000, m2[i])));
    check(j2.every(j => j && j.map === 'lagoon') && j2[4].spec === 1, 'second match on lagoon started for everyone', j2.map(j => j && j.map));
    // игрок вышел из матча — остаётся в лобби, может вернуться
    mk0 = D.mark(); D.send({ t: 'leave' });
    st = await lobbyOf(A, s => s.slots.t.some(m => m && m.cid === did && !m.inm));
    check(!!st, 'player who left the match stays in lobby (not in match)');
    D.send({ t: 'lobby_rejoin' });
    const rj = await D.wait('joined', null, 5000, mk0);
    check(rj && rj.lobby === code && rj.team === 1, 'player rejoined the running match on his side', rj);
    // обрыв связи в матче лобби: тот же телефон возвращается по коду комнаты (как игра после обрыва) — то же место и лобби
    const keyR = 'krrrrrrrrrrrrrrrr';
    const R1 = await mk('Ремонт', { key: keyR }); mk0 = R1.mark(); R1.send({ t: 'lobby_join', code });
    const sr = await lobbyOf(R1, null, mk0);
    check(sr && sr.slots.spec.some(m => m && m.cid === sr.you), 'late joiner during match → spectator slot');
    const jr = await R1.wait('joined', null, 5000, mk0);
    check(jr && jr.spec === 1 && jr.lobby === code, 'late joiner goes straight into the match as spectator', jr);
    const roomCode = j2[0].code;
    C.close(); await sleep(500);
    st = await lobbyOf(A, s => s.slots.ct.some(m => m && m.cid === cid && m.off));
    check(!!st, 'player dropped mid-match: shown offline in lobby');
    const C2 = await client(srv.url, { name: 'Боец3', cv: LC, key: C.keyUsed }); all.push(C2);
    mk0 = C2.mark(); C2.send({ t: 'join', code: roomCode, resume: 1 });
    const jc2 = await C2.wait('joined', null, 5000, mk0);
    check(jc2 && jc2.resumed === 1 && jc2.lobby === code && jc2.team === 0, 'reconnect: resume into the same lobby match seat', jc2);
    const lc2 = await lobbyOf(C2, null, mk0);
    check(lc2 && lc2.slots.ct.some(m => m && m.cid === lc2.you && !m.off), 'reconnect: lobby membership restored (same CT slot)', lc2 && lc2.slots.ct);
    // овертайм: 4:4 на последнем раунде (до 5, max 8) → ещё 6 раундов до 8 побед
    await sleep(500);
    A.send({ t: '__test', op: 'score', sc: [3, 4], round: 8 });
    await sleep(100);
    mk0 = A.mark();
    A.send({ t: '__test', op: 'rend', win: 0 });
    const ot = await A.waitEv('sys', e => /овертайм/i.test(e[1]), 4000, mk0);
    check(!!ot, 'tie on the last round → overtime announced', ot);
    await sleep(400);
    check(A.snap && A.snap.g.max === 14 && A.snap.g.win === 8 && !A.snap.g.over, 'overtime: max 14 rounds, to 8 wins', A.snap && A.snap.g);
    await sleep(5600);
    check(A.snap && A.snap.g.r === 9 && A.snap.me.$ === 10000, 'overtime round 9 starts with $10000', A.snap && [A.snap.g.r, A.snap.me.$]);
    mk0 = A.mark();
    A.send({ t: '__test', op: 'end' });
    st = await A.wait('lobby', s => s.back === 1, 9000, mk0);
    check(st && st.hist.length === 2 && st.hist[1].map === 'lagoon', 'second result in series history', st && st.hist);

    // ---------- дуэль: лишние участники пересаживаются ----------
    A.send({ t: 'lobby_set', mode: 'duel' });
    st = await lobbyOf(A, s => s.mode === 'duel');
    check(st && st.map === 'winter' && st.size === 1 && st.slots.ct.length === 1 && st.slots.t.length === 1, 'duel forces winter 1×1', st && [st.map, st.size]);
    check(st && st.slots.spec.filter(Boolean).length === 4 && st.slots.ct.filter(Boolean).length === 1 && st.slots.t.filter(Boolean).length === 1, 'extra players moved to spectator slots', st && st.slots.spec.map(m => m && m.nick));
    // ---------- командный бой с ботами ----------
    A.send({ t: 'lobby_set', mode: 'tdm', map: 'harbor', size: 3, opts: { bots: 1, kills: 20, time: 3, diff: 'easy' } });
    st = await lobbyOf(A, s => s.mode === 'tdm' && s.opts.bots === 1);
    check(st && st.map === 'harbor' && st.size === 3 && st.opts.kills === 20, 'tdm 3×3 with bots configured', st && [st.map, st.size, st.opts]);
    const m3 = A.mark();
    A.send({ t: 'lobby_start' });
    const j3 = await A.wait('joined', null, 8000, m3);
    await sleep(1200);
    const ro3 = A.last('roster');
    check(j3 && j3.mode === 'tdm' && ro3 && ro3.list.length === 6 && ro3.list.filter(r => r[3]).length >= 2, 'bots fill empty slots (6 fighters)', ro3 && ro3.list.map(r => r[1] + ':' + r[3]));
    check(A.snap && A.snap.g.kl === 20 && A.snap.g.tl <= 180, 'tdm kill limit 20, 3 minutes', A.snap && A.snap.g);
    mk0 = A.mark(); A.send({ t: '__test', op: 'end' });
    await A.wait('lobby', s => s.back === 1, 9000, mk0);

    // ---------- разминка (включена хостом): сначала TDM с возрождением и отсчётом, режим матча — бомба ----------
    A.send({ t: 'lobby_set', mode: 'bomb', map: 'villa', size: 2, opts: { bots: 0, warm: 30 } });
    st = await lobbyOf(A, s => s.mode === 'bomb' && s.opts.warm === 30);
    check(st && st.opts.warm === 30, 'warm-up 30 s configured');
    const mw = A.mark(), mwb = B.mark();
    A.send({ t: 'lobby_start' });
    const jw = await A.wait('joined', null, 8000, mw);
    await B.wait('joined', null, 8000, mwb);
    await sleep(1200);
    check(jw && jw.mode === 'tdm' && jw.rmode === 'bomb', 'lobby warm-up runs as TDM, match mode bomb', jw);
    check(A.snap && Array.isArray(A.snap.g.wu) && A.snap.g.wu[2] > 20 && A.snap.g.wu[2] <= 30, 'warm-up countdown in snapshots', A.snap && A.snap.g.wu);
    check(A.evs(mw).some(e => e[0] === 'sys' && /Разминка 30/.test(e[1])), 'warm-up announced');
    mk0 = A.mark(); A.send({ t: '__test', op: 'end' });
    st = await A.wait('lobby', s => s.back === 1, 9000, mk0);
    check(st && st.hist.length === 3, 'match ended during warm-up is not counted in the series', st && st.hist.length);

    // ---------- обрыв связи: место ждёт; хост пропал — права другому ----------
    const keyB = 'kbbbbbbbbbbbbbbb';
    const B2a = await mk('Возвращенец', { key: keyB }); mk0 = B2a.mark(); B2a.send({ t: 'lobby_join', code });
    const sb = await lobbyOf(B2a, null, mk0);
    const bslot = [sb.slots.ct, sb.slots.t, sb.slots.spec].map(l => l.findIndex(m => m && m.cid === sb.you));
    B2a.close(); await sleep(400);
    st = await lobbyOf(A, s => [].concat(s.slots.ct, s.slots.t, s.slots.spec).some(m => m && m.nick === 'Возвращенец' && m.off));
    check(!!st, 'dropped member shown offline, slot kept');
    const B2b = await mk('Возвращенец', { key: keyB }); mk0 = B2b.mark(); B2b.send({ t: 'lobby_join', code });
    const sb2 = await lobbyOf(B2b, null, mk0);
    const bslot2 = [sb2.slots.ct, sb2.slots.t, sb2.slots.spec].map(l => l.findIndex(m => m && m.cid === sb2.you));
    check(JSON.stringify(bslot) === JSON.stringify(bslot2), 'reconnected member gets the same slot back', [bslot, bslot2]);
    B2b.close();
    await sleep(5000);
    st = A.last('lobby');
    check(st && ![].concat(st.slots.ct, st.slots.t, st.slots.spec).some(m => m && m.nick === 'Возвращенец'), 'member who did not return is removed after hold', st && st.slots);
    A.close();
    st = await lobbyOf(B, s => s.host === bid, B.mark());
    check(!!st, 'host offline → host passed to next member', B.last('lobby') && B.last('lobby').host);
    // все вышли — лобби удаляется через 2 минуты (в тесте 2 с)
    for (const c of all) c.send({ t: 'lobby_leave' });
    await sleep(5500);
    const G2 = await mk('Поздний'); mk0 = G2.mark(); G2.send({ t: 'lobby_join', code });
    check(!!await G2.wait('lobby_err', m => /не найдено/.test(m.m), 3000, mk0), 'empty lobby deleted');

    // ---------- лимиты: 14 участников, 6 лобби с адреса (в тесте), частота ----------
    const H = await mk('Хост2'); mk0 = H.mark();
    H.send({ t: 'lobby_create', mode: 'bomb', map: 'dust', size: 5 });
    const s5 = await lobbyOf(H, null, mk0);
    const many = [];
    for (let i = 0; i < 14; i++) { const c = await mk('Гость' + i); many.push(c); c.send({ t: 'lobby_join', code: s5.code }); await sleep(30); }
    await sleep(800);
    const fullErr = many.filter(c => c.all('lobby_err').some(e => /заполнено/.test(e.m))).length;
    const inLobby = many.filter(c => c.last('lobby')).length;
    check(inLobby === 13 && fullErr === 1, '14 members max (13 guests + host), 15th → «Лобби заполнено»', [inLobby, fullErr]);
    for (const c of many) c.close();
    let made = 1, capErr = null;
    for (let i = 0; i < 7 && !capErr; i++) {
      const c = await mk('Создатель' + i); const k = c.mark();
      c.send({ t: 'lobby_create', mode: 'tdm', map: 'harbor', size: 2 });
      const r = await c.waitAny(['lobby', 'lobby_err'], 3000, k);
      if (r && r.t === 'lobby') made++; else capErr = r;
    }
    check(made === 6 && capErr && /слишком много/.test(capErr.m), 'max lobbies per IP enforced', [made, capErr]);
    mk0 = H.mark();
    for (let i = 0; i < 12; i++) H.send({ t: 'lobby_ready', on: i % 2 });
    check(!!await H.wait('lobby_err', m => /часто/.test(m.m), 2000, mk0), 'lobby actions rate-limited');
    // мусор
    for (const m of [{ t: 'lobby_join', code: 12345 }, { t: 'lobby_join' }, { t: 'lobby_set', opts: 'x' }, { t: 'lobby_move', cid: 'a' }, { t: 'lobby_slot', side: 'ct', i: 99 }, { t: 'lobby_kick', cid: null }, { t: 'lobby_whatever' }, { t: 'lobby_chat', m: { a: 1 } }]) H.send(m);
    await sleep(1500);
    check(!srv.logs.some(l => /\[msg |\[room |\[lobby|uncaught|TypeError|ReferenceError/.test(l)), 'no server exceptions', srv.logs.filter(l => /Error|\[msg|\[room|\[lobby/.test(l)).slice(0, 5));
    const r = await srv.http('GET', '/');
    check(r.data && r.data.version === '2.6.0', 'server version 2.6.0', r.data);
  } finally {
    for (const c of all) c.close();
    await srv.stop();
  }
  process.exit(summary('lobby'));
})().catch(e => { console.error(e); process.exit(1); });

