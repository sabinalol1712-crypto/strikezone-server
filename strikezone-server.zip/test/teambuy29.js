'use strict';
// 2.9: магазин бомбы онлайн — запрос оружия, покупка тиммейту, возврат; соперники запросов не видят
const L = require('./lib');
const { check, summary, sleep } = L;
(async () => {
  const srv = await L.startServer();
  try {
    const A = await L.client(srv.url, { name: 'Просящий', cv: 280 });
    const B = await L.client(srv.url, { name: 'Богач', cv: 280 });
    const C = await L.client(srv.url, { name: 'Чужой', cv: 280 });
    A.send({ t: 'create', mode: 'bomb', map: 'harbor', size: 3, side: 'ct' });
    const ja = await A.wait('joined', null, 5000);
    B.send({ t: 'join', code: ja.code, side: 'ct' }); const jb = await B.wait('joined', null, 5000);
    C.send({ t: 'join', code: ja.code, side: 't' }); const jc = await C.wait('joined', null, 5000);
    check(ja && jb && jc && ja.team === jb.team && jc.team !== ja.team, 'A и B в одной команде, C — в другой', [ja && ja.team, jb && jb.team, jc && jc.team]);
    // ждём закупку нового раунда
    let t0 = Date.now(); while (!(A.snap && A.snap.me && A.snap.me.buy === 1 && B.snap && B.snap.me && B.snap.me.buy === 1) && Date.now() - t0 < 8000) await sleep(50);
    check(A.snap.me.buy === 1 && B.snap.me.buy === 1, 'оба могут покупать');
    // 1) запрос: у A $800, M4A1-S дороже
    let mk = A.mark(), mb = B.mark(), mc = C.mark();
    A.send({ t: 'breq', id: 'm4s' });
    const evB = await B.waitEv('breq', e => e[1] === ja.you && e[2] === 'm4s', 2000, mb);
    check(!!evB, 'тиммейт получил запрос', evB);
    await sleep(200);
    check(B.snap.me.tr && B.snap.me.tr.some(r => r[0] === ja.you && r[1] === 'm4s'), 'запрос в снимке тиммейта (me.tr)', B.snap.me.tr);
    check(A.snap.me.rq === 'm4s', 'свой запрос в снимке (me.rq)', A.snap.me.rq);
    check(!C.evs(mc).some(e => e[0] === 'breq'), 'соперник запрос не видит');
    // 2) B покупает A в одно нажатие
    B.send({ t: '__test', op: 'money', v: 6000 }); await sleep(150);
    mk = A.mark(); mb = B.mark();
    B.send({ t: 'buy', id: 'm4s', to: ja.you });
    await sleep(400);
    const prim = A.snap.me.sl.primary;
    check(prim && prim[0] === 'm4s', 'у A в руках M4A1-S', prim);
    check(B.snap.me.$ < 6000, 'деньги списаны у B', B.snap.me.$);
    const paid = 6000 - B.snap.me.$;
    check(!!A.evs(mk).find(e => e[0] === 'bgift' && e[1] === jb.you && e[2] === ja.you), 'A узнал, кто купил (bgift)');
    check(!!A.evs(mk).find(e => e[0] === 'breq' && e[1] === ja.you && e[2] === null && e[3] === jb.you), 'запрос снят с указанием покупателя');
    check(!A.snap.me.rq, 'запроса больше нет');
    check(A.snap.me.rf && A.snap.me.rf.includes('m4s'), 'A может вернуть (me.rf)', A.snap.me.rf);
    // 3) возврат — деньги тому, кто платил
    mb = B.mark();
    A.send({ t: 'refund', id: 'm4s' });
    await sleep(400);
    check(!A.snap.me.sl.primary, 'после возврата основного нет', A.snap.me.sl.primary);
    check(B.snap.me.$ === 6000, 'деньги вернулись B', B.snap.me.$);
    check(!!B.evs(mb).find(e => e[0] === 'refund' && e[1] === ja.you && e[2] === 'm4s' && e[3] === paid), 'B получил событие возврата', B.evs(mb).filter(e => e[0] === 'refund'));
    // 4) себе: шлем (броня уже есть — игрок занял место бота с его покупками) и возврат
    A.send({ t: '__test', op: 'money', v: 1000 }); await sleep(120);
    const ar0 = A.snap.me.ar, price = ar0 >= 100 ? 350 : 1000;
    A.send({ t: 'buy', id: 'helmet' }); await sleep(300);
    check(A.snap.me.hm === 1 && A.snap.me.$ === 1000 - price && A.snap.me.rf && A.snap.me.rf.includes('helmet'), 'шлем куплен, можно вернуть', [A.snap.me.hm, A.snap.me.$, A.snap.me.rf]);
    A.send({ t: 'refund', id: 'helmet' }); await sleep(300);
    check(A.snap.me.hm === 0 && A.snap.me.ar === ar0 && A.snap.me.$ === 1000, 'шлем возвращён', [A.snap.me.hm, A.snap.me.ar, A.snap.me.$]);
    // 5) нельзя купить сопернику и нельзя чужой предмет
    C.send({ t: '__test', op: 'money', v: 9000 }); await sleep(120);
    C.send({ t: 'buy', id: 'ar', to: ja.you }); await sleep(300);
    check(!A.snap.me.sl.primary && C.snap.me.$ === 9000, 'соперник не может купить A', [A.snap.me.sl.primary, C.snap.me.$]);
    B.send({ t: 'buy', id: 'ar', to: ja.you }); await sleep(300);
    check(!A.snap.me.sl.primary && B.snap.me.$ === 6000, 'AK-47 (налётчики) спецназу не купить', [A.snap.me.sl.primary, B.snap.me.$]);
    // 6) мусор не роняет сервер
    for (const m of [{ t: 'breq', id: 5 }, { t: 'breq', id: 'nope' }, { t: 'refund', id: {} }, { t: 'buy', id: 'm4s', to: 'x' }, { t: 'buy', id: 'm4s', to: 99999 }, { t: 'buy', id: 'm4s', to: -1.5 }]) A.send(m);
    await sleep(300);
    check(A.snap && A.ws.readyState === 1, 'сервер жив после мусора');
    A.close(); B.close(); C.close();
  } finally { srv.stop(); }
  process.exit(summary('teambuy29'));
})().catch(e => { console.error(e); process.exit(1); });
