'use strict';
// 2.6: кланы — объявление, приглашения по номеру ID / нику (событие, принять, отклонить, напоминание при входе),
// казна (взнос из облака, выплата лидером, буст ×2), мест больше с уровнем, сезон лиги кланов (титулы, призы, очки пополам),
// история войн и матчи участников после клановой войны, правки админа (xp, bank, color, leader).
const { sleep, check, summary, startServer, client, newAcc, adminSession } = require('./lib');

(async () => {
  const srv = await startServer({ env: { SZ_CLAN_TICK_MS: '200' } });
  const url = srv.url;
  const login = async (name, cv) => { const acc = newAcc(); const c = await client(url, { name, acc, cv: cv || 252 }); await c.wait('me'); c.acc = acc; return c; };
  const act = async (c, msg) => {
    const gap = 210 - (Date.now() - (c.actT || 0));
    if (gap > 0) await sleep(gap);
    c.actT = Date.now();
    const mk = c.mark(); c.send(msg);
    const t0 = Date.now();
    for (; ;) {
      const m = c.msgs.slice(mk).find(x => x.t === 'clan_ok' || x.t === 'clan_err');
      if (m) { await sleep(80); return m; }
      if (Date.now() - t0 > 3000) return null;
      await sleep(15);
    }
  };
  const cloud = async (c, coins) => { const k = c.mark(); c.send({ t: 'inv_migrate', inv: { coins: coins | 0 } }); await c.wait('inv', x => x.ok === 'inv_migrate', 3000, k); };
  const myClan = (c) => { const m = c.msgs.slice().reverse().find(x => x.t === 'clan' && x.clan && x.clan.mine); return m ? m.clan : null; };
  const me = (c) => { const m = c.msgs.slice().reverse().find(x => x.t === 'me'); return m ? m.acc : null; };
  try {
    const L = await login('Лидер'), O = await login('Зам'), M = await login('Боец'), N = await login('Новичок');
    console.log('== create, notice');
    let r = await act(L, { t: 'clan_create', name: 'Белые Волки', tag: 'WW', open: false });
    check(r && r.t === 'clan_ok', 'clan created', r);
    const cid = r.id;
    r = await act(L, { t: 'clan_edit', notice: 'Сбор в 20:00 — тренировка  на «Кальдере»' });
    check(r && r.t === 'clan_ok', 'notice saved', r);
    let cl = myClan(L);
    check(cl && cl.notice === 'Сбор в 20:00 — тренировка на «Кальдере»' && cl.max === 20 && cl.bank === 0 && cl.season && cl.season.n >= 1 && Array.isArray(cl.wars), 'clan view: notice (spaces collapsed), max 20, bank 0, season, wars[]', cl && [cl.notice, cl.max, cl.bank, cl.season]);
    check(cl.feed.some(f => /обновил объявление/.test(f[1])), 'feed: notice updated');

    console.log('== invites');
    const oNum = me(O).num;
    r = await act(L, { t: 'clan_invite', q: '№ ' + oNum });
    check(r && r.t === 'clan_ok' && /Приглашение отправлено/.test(r.m), 'invite by number → ok', r);
    const ev = O.msgs.find(x => x.t === 'clan_ev' && x.k === 'invite');
    check(ev && ev.id === cid && ev.tag === 'WW' && ev.by === 'Лидер', 'invitee got clan_ev invite with clan and inviter', ev);
    r = await act(L, { t: 'clan_invite', q: 'Зам' });
    check(r && r.t === 'clan_ok' && /уже отправлено/.test(r.m), 'duplicate invite → already sent', r);
    r = await act(M, { t: 'clan_invite', q: 'Боец' });
    check(r && r.t === 'clan_err' && /не в клане/.test(r.m), 'outsider cannot invite', r);
    cl = myClan(L);
    check(cl.invites && cl.invites.length === 1 && cl.invites[0].nick === 'Зам' && cl.invites[0].by === 'Лидер', 'leader sees pending invites', cl.invites);
    // список кланов у приглашённого содержит inv
    let mk = O.mark(); O.send({ t: 'clans' }); const lst = await O.wait('clans', null, 3000, mk);
    check(lst.inv && lst.inv.length === 1 && lst.inv[0].id === cid && lst.inv[0].by === 'Лидер' && lst.season && lst.season.n >= 1, 'clans list carries my invites and the season', [lst.inv, lst.season]);
    // напоминание при входе: новое соединение того же аккаунта
    const O2 = await client(url, { name: 'Зам', acc: O.acc, cv: 252 }); await O2.wait('me');
    await sleep(300);
    check(O2.msgs.some(x => x.t === 'clan_ev' && x.k === 'invite' && x.id === cid), 'pending invite is re-sent on login', O2.msgs.filter(x => x.t === 'clan_ev'));
    O2.close();
    r = await act(O, { t: 'clan_invite_no', id: cid });
    check(r && r.t === 'clan_ok' && /отклонено/.test(r.m), 'decline invite', r);
    r = await act(O, { t: 'clan_invite_ok', id: cid });
    check(r && r.t === 'clan_err' && /не действует/.test(r.m), 'accepting a declined invite fails', r);
    await sleep(1100);
    r = await act(L, { t: 'clan_invite', q: 'Зам' });
    check(r && r.t === 'clan_ok' && /отправлено/.test(r.m), 're-invite after decline', r);
    r = await act(O, { t: 'clan_invite_ok', id: cid });
    check(r && r.t === 'clan_ok' && /вступили/.test(r.m), 'accept invite → joined the closed clan without a code', r);
    cl = myClan(L);
    check(cl.members.length === 2 && cl.feed.some(f => /по приглашению/.test(f[1])), 'member joined via invite (feed)', cl.members.length);
    r = await act(L, { t: 'clan_role', acc: O.acc.id, role: 'officer' });
    await sleep(1100);
    r = await act(O, { t: 'clan_invite', q: 'Боец' });
    check(r && r.t === 'clan_ok', 'officer can invite', r);
    r = await act(M, { t: 'clan_invite_ok', id: cid });
    check(r && r.t === 'clan_ok', 'third member joined', r);
    await sleep(1100);
    r = await act(L, { t: 'clan_invite', q: 'Нет-такого' });
    check(r && r.t === 'clan_err' && /не найден/.test(r.m), 'unknown nick → error', r);

    console.log('== treasury');
    r = await act(M, { t: 'clan_donate', coins: 500 });
    check(r && r.t === 'clan_err' && /облачн/.test(r.m), 'donate without cloud inventory → error', r);
    await cloud(M, 2000); await cloud(O, 100);
    r = await act(M, { t: 'clan_donate', coins: 5 });
    check(r && r.t === 'clan_err' && /от 10/.test(r.m), 'donate below minimum → error', r);
    r = await act(M, { t: 'clan_donate', coins: 3000 });
    check(r && r.t === 'clan_err' && /Не хватает/.test(r.m), 'donate more than owned → error', r);
    // 2.10.1: перенесённые монеты — бонусные: в казну их не внести (иначе через выплату они становились торговыми)
    r = await act(M, { t: 'clan_donate', coins: 1200 });
    check(r && r.t === 'clan_err' && /торговать/.test(r.m), 'donate bonus coins → error (no laundering through the treasury)', r);
    M.send({ t: '__test', op: 'clean_coins' }); await sleep(250);
    r = await act(M, { t: 'clan_donate', coins: 1200 });
    check(r && r.t === 'clan_ok' && /1.200/.test(r.m), 'donate 1200 → ok', r);
    const inv = M.msgs.slice().reverse().find(x => x.t === 'inv');
    check(inv && inv.inv.coins === 800, 'donor coins 2000 → 800 (inv pushed)', inv && inv.inv.coins);
    cl = myClan(L);
    const mem = cl.members.find(x => x.nick === 'Боец');
    check(cl.bank === 1200 && mem && mem.don === 1200 && cl.feed.some(f => /внёс в казну/.test(f[1])), 'bank 1200, member contribution 1200, feed', [cl.bank, mem && mem.don]);
    r = await act(O, { t: 'clan_pay', acc: M.acc.id, coins: 100 });
    check(r && r.t === 'clan_err' && /только лидер/.test(r.m), 'officer cannot pay out', r);
    r = await act(L, { t: 'clan_pay', acc: O.acc.id, coins: 5000 });
    check(r && r.t === 'clan_err' && /В казне только/.test(r.m), 'payout above bank → error', r);
    const mkO = O.mark();
    r = await act(L, { t: 'clan_pay', acc: O.acc.id, coins: 300 });
    check(r && r.t === 'clan_ok', 'leader pays 300 to officer', r);
    const invO = O.msgs.slice(mkO).find(x => x.t === 'inv');
    check(invO && invO.inv.coins === 400 && O.msgs.slice(mkO).some(x => x.t === 'clan_ev' && x.k === 'pay'), 'officer got 300 (100 → 400) and an event', invO && invO.inv.coins);
    cl = myClan(L);
    check(cl.bank === 900, 'bank 1200 − 300 = 900', cl.bank);
    r = await act(O, { t: 'clan_boost' });
    check(r && r.t === 'clan_ok' && /Буст/.test(r.m), 'officer buys the ×2 boost', r);
    cl = myClan(L);
    check(cl.bank === 400 && cl.boostUntil > Date.now() + 23 * 3600000, 'bank 900 − 500 = 400, boost ~24h', [cl.bank, cl.boostUntil - Date.now()]);
    r = await act(L, { t: 'clan_boost' });
    check(r && r.t === 'clan_err' && /уже включён/.test(r.m), 'boost twice → already on', r);

    console.log('== admin edits: xp (level → more seats), bank, color, leader');
    const adm = await adminSession(srv);
    let a = await adm.post('clan_edit', { id: cid, xp: 100000, bank: 777, color: '#2ec4ff', emblem: 5 });
    check(a.status === 200 && a.data.ok === true, 'admin clan_edit xp/bank/color/emblem', a.data);
    await sleep(300);
    cl = myClan(L);
    check(cl.lv.lvl > 20 && cl.max === 30 && cl.bank === 777 && cl.color === '#2ec4ff' && cl.emblem === 5, 'level >20 → 30 seats; bank 777; color; emblem', [cl.lv && cl.lv.lvl, cl.max, cl.bank, cl.color, cl.emblem]);
    a = await adm.post('clan_edit', { id: cid, leader: N.acc.id });
    check(a.status === 400 && /участником/.test((a.data && a.data.error) || ''), 'leader must be a member (error)', a.data);
    a = await adm.post('clan_edit', { id: cid, leader: O.acc.id });
    check(a.status === 200 && a.data.ok === true, 'admin sets a new leader', a.data);
    await sleep(300);
    cl = myClan(O);
    check(cl.myRole === 'leader' && cl.members.find(x => x.nick === 'Лидер').role === 'officer' && cl.feed.some(f => /новый лидер/.test(f[1])), 'officer is leader now, old leader is officer', cl.members.map(x => x.nick + ':' + x.role));
    a = await adm.post('clan_edit', { id: cid, leader: L.acc.id });

    console.log('== season end: titles, rewards, points halved');
    // второй клан без войн и клан с «войной»: очки и войны ставим правкой админа и хуком
    r = await act(N, { t: 'clan_create', name: 'Тени', tag: 'SH' });
    const cid2 = r.id;
    await adm.post('clan_edit', { id: cid, pts: 400 });
    await adm.post('clan_edit', { id: cid2, pts: 900 });
    // у WW была война (sw), у SH — нет: приз получает только WW
    L.send({ t: '__test', op: 'war_fake', id: cid });
    L.send({ t: '__test', op: 'clan_age', days: 30 });   // 2.10.1: награда — тем, кто в клане давно (или воевал за него)
    await sleep(200);
    const mkL = L.mark(), mkM = M.mark();
    L.send({ t: '__test', op: 'season_end' });
    await sleep(600);
    cl = myClan(L);
    check(cl.titles.length === 1 && cl.titles[0][1] === 1 && cl.title && cl.title[1] === 1, 'WW: 1st place title', cl.titles);
    check(cl.pts === 200 && cl.season.n === 2, 'points halved (400 → 200), season 2', [cl.pts, cl.season]);
    check(cl.feed.some(f => /1-е место/.test(f[1])), 'feed: season result');
    const giftM = M.msgs.slice(mkM).find(x => x.t === 'gifts' || x.t === 'gift');
    const invM = M.msgs.slice(mkM).find(x => x.t === 'inv');
    check(invM && invM.inv.coins === 800 + 600, 'member reward +600 coins in the cloud (800 → 1400)', invM && invM.inv.coins);
    mk = N.mark(); N.send({ t: 'clans' }); const lst2 = await N.wait('clans', null, 3000, mk);
    const sh = lst2.list.find(x => x.id === cid2);
    check(sh && sh.pts === 450 && !sh.title && lst2.hist && lst2.hist.length === 1 && lst2.hist[0].top.length === 1 && lst2.hist[0].top[0].tag === 'WW', 'SH: no wars → no title, pts 900 → 450; history has WW only', [sh, lst2.hist]);
    check(!srv.logs.some(l => /\[clans\]|TypeError|ReferenceError/.test(l)), 'no server errors', srv.logs.filter(l => /Error/.test(l)).slice(0, 3));
  } finally { await srv.stop(); }
  process.exit(summary('clans26'));
})().catch(e => { console.error(e); process.exit(1); });
