'use strict';
// 2.10.1: подбор пароля с многих адресов. После 20 неудач на аккаунт вход паролем закрыт для новых сетей (подбор не
// ускоряется), но владелец из сети, где он уже входил в аккаунт (регистрация, пароль, ключ устройства), входит.
// IPv6: ограничение «5 неудач с адреса» считается по сети /64 — смена адреса внутри неё его не обходит.
// Разные адреса — через X-Forwarded-For (сервер верит ему только от 127.0.0.1, как за Caddy). node test/login2101.js
const net = require('net');
const crypto = require('crypto');
const L = require('./lib');

let fail = 0;
const check = (c, n, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : JSON.stringify(i)); if (!c) fail++; };

// минимальный клиент WebSocket с заголовком X-Forwarded-For (встроенный WebSocket заголовков не задаёт)
function rawClient(port, ip) {
  return new Promise((resolve, reject) => {
    const s = net.connect(port, '127.0.0.1');
    const key = crypto.randomBytes(16).toString('base64');
    let buf = Buffer.alloc(0), up = false;
    const msgs = [];
    const c = {
      msgs,
      send(o) {
        const p = Buffer.from(JSON.stringify(o)), mask = crypto.randomBytes(4);
        const hdr = p.length < 126 ? Buffer.from([0x81, 0x80 | p.length]) : Buffer.from([0x81, 0x80 | 126, p.length >> 8, p.length & 255]);
        const m = Buffer.alloc(p.length); for (let i = 0; i < p.length; i++) m[i] = p[i] ^ mask[i & 3];
        s.write(Buffer.concat([hdr, mask, m]));
      },
      async wait(types, from, timeout) {
        const t0 = Date.now();
        for (; ;) {
          const m = msgs.slice(from).find(x => types.includes(x.t));
          if (m) return m;
          if (Date.now() - t0 > (timeout || 8000)) return null;
          await L.sleep(20);
        }
      },
      async login(who, pass) { const mk = msgs.length; c.send({ t: 'login', who, pass }); return c.wait(['login_ok', 'login_err'], mk); },
      close() { try { s.destroy(); } catch (e) { } }
    };
    s.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      if (!up) {
        const i = buf.indexOf('\r\n\r\n'); if (i < 0) return;
        if (!/^HTTP\/1\.1 101/.test(buf.slice(0, i).toString())) { reject(new Error('no upgrade')); return; }
        up = true; buf = buf.slice(i + 4); resolve(c);
      }
      for (; ;) {
        if (buf.length < 2) return;
        let len = buf[1] & 127, off = 2;
        if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; } else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
        if (buf.length < off + len) return;
        const op = buf[0] & 15, p = buf.slice(off, off + len); buf = buf.slice(off + len);
        if (op === 1) { try { msgs.push(JSON.parse(p.toString())); } catch (e) { } }
      }
    });
    s.on('error', reject);
    s.write('GET /ws HTTP/1.1\r\nHost: 127.0.0.1\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ' + key + '\r\nX-Forwarded-For: ' + ip + '\r\n\r\n');
  });
}
async function hello(c, name) { const mk = c.msgs.length; c.send({ t: 'hello', v: 1, cv: 300, name, prim: 'ar', skins: {}, knife: ['knife', null, 0], drops: 1 }); return c.wait(['welcome'], mk); }

(async () => {
  const srv = await L.startServer({ port: 8098, env: { SZ_REG_PER_HOUR: '1000' } });
  try {
    // владелец регистрируется из своей сети
    const own = await rawClient(srv.port, '198.51.100.7');
    await hello(own, 'Владелец');
    const mk = own.msgs.length; own.send({ t: 'reg', nick: 'Владелец', pass: 'right-pass-123' });
    const rg = await own.wait(['reg_ok', 'reg_err'], mk);
    check(rg && rg.t === 'reg_ok', 'owner registered', rg);
    own.close();
    // подбор: 25 неверных паролей из 5 разных сетей (по 5 с каждой — лимит адреса)
    let wrong = 0, last = null;
    for (let k = 0; k < 5; k++) {
      const a = await rawClient(srv.port, '203.0.113.' + (10 + k)); await hello(a, 'Гость');
      for (let i = 0; i < 5; i++) { last = await a.login('Владелец', 'bad-' + k + '-' + i); if (last && /Неверный/.test(last.m)) wrong++; }
      a.close();
    }
    check(wrong === 20, 'after 20 failures on the account the password is no longer checked for new networks', { wrong, last });
    const b = await rawClient(srv.port, '192.0.2.50'); await hello(b, 'Гость');
    const r1 = await b.login('Владелец', 'right-pass-123');
    check(r1 && r1.t === 'login_err' && /этот аккаунт/.test(r1.m), 'unknown network: even the right password waits (no faster guessing)', r1);
    b.close();
    const o2 = await rawClient(srv.port, '198.51.100.7'); await hello(o2, 'Владелец');
    const r2 = await o2.login('Владелец', 'right-pass-123');
    check(r2 && r2.t === 'login_ok', 'owner from the network he registered from logs in during the attack', r2);
    o2.close();
    // IPv6: 5 неудач из одной сети /64 — шестая попытка с другого адреса той же сети тоже отклонена
    const v6 = async (addr) => { const c = await rawClient(srv.port, addr); await hello(c, 'Гость'); return c; };
    let c6 = await v6('2001:db8:1:2::1');
    for (let i = 0; i < 5; i++) await c6.login('#999999', 'x' + i);
    c6.close();
    c6 = await v6('2001:db8:1:2:aaaa::77');
    const r3 = await c6.login('#999999', 'y');
    check(r3 && r3.t === 'login_err' && r3.m === 'Слишком много попыток, подождите', 'IPv6: another address in the same /64 is limited too', r3);
    c6.close();
    // админ-панель: админ входит из своей сети, потом подбор со 100 адресов закрывает вход новым сетям, но не ему
    const adm = (ip, pw) => srv.http('POST', '/admin/api/login', { password: pw }, { 'X-Forwarded-For': ip });
    let r = await adm('198.51.100.20', L.ADMIN_PASS);
    check(r.status === 200 && r.data.token, 'admin logs in from his network', r.status);
    for (let k = 0; k < 20; k++) for (let i = 0; i < 5; i++) await adm('203.0.113.' + (100 + k), 'wrong' + i);
    r = await adm('192.0.2.77', L.ADMIN_PASS);
    check(r.status === 429, 'after 100 failures from many addresses a new network waits (even with the right password)', [r.status, r.data]);
    r = await adm('198.51.100.20', L.ADMIN_PASS);
    check(r.status === 200 && r.data.token, 'admin from his known network still logs in during the attack', [r.status, r.data]);
  } finally { await srv.stop(); }
  console.log(fail ? 'FAILED ' + fail : 'ALL PASSED');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
