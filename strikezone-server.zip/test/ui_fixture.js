'use strict';
// Данные для проверки админки в браузере (test/admin_ui.py): игроки онлайн, клан, обычная комната,
// рейтинговый матч, бан. Держит соединения открытыми, пока процесс не остановят.
// Запуск: node test/ui_fixture.js ws://127.0.0.1:PORT/ws http://127.0.0.1:PORT
const { sleep, client, newAcc, ADMIN_PASS } = require('./lib');

(async () => {
  const url = process.argv[2], base = process.argv[3];
  const login = async (name) => { const c = await client(url, { name, acc: newAcc() }); await c.wait('me'); return c; };
  const L = await login('Командир'), M = await login('Боец'), O = await login('Оффлайн');
  L.send({ t: 'clan_create', name: 'Стальные', tag: 'STL', color: '#2ec4ff', emblem: 2, open: true, desc: 'Тестовый клан' });
  const id = (await L.wait('clan_ok')).id;
  await sleep(250);
  M.send({ t: 'clan_join', id }); await M.wait('clan_ok');
  O.send({ t: 'clan_join', id }); await O.wait('clan_ok');
  await sleep(250);
  L.send({ t: 'clan_say', m: 'Всем привет' });
  L.send({ t: 'create', mode: 'bomb', map: 'dust', size: 3 });
  const j = await L.wait('joined');
  M.send({ t: 'join', code: j.code }); await M.wait('joined');
  O.close();
  // рейтинговый матч
  const rs = [];
  for (const n of ['Рейт1', 'Рейт2', 'Рейт3', 'Рейт4']) rs.push(await login(n));
  for (const c of rs) c.send({ t: 'rq', kind: 'ranked' });
  await Promise.all(rs.map(c => c.wait('joined', null, 8000)));
  // бан
  const B = await login('Нарушитель');
  const tok = (await (await fetch(base + '/admin/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '10.7.7.7' }, body: JSON.stringify({ password: ADMIN_PASS }) })).json()).token;
  await fetch(base + '/admin/api/ban', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: JSON.stringify({ acc: B.acc ? B.acc.id : (B.last('me') || {}).acc.id, hours: 24, reason: 'Читы' }) });
  console.log('ready', j.code);
  setInterval(() => { }, 1000);
})().catch(e => { console.error(e); process.exit(1); });
