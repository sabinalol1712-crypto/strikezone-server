// Быстрая проверка сервера: два «телефона» входят в матч, двигаются и стреляют
const URL = process.argv[2] || 'ws://localhost:8080/ws';
function client(name) {
  return new Promise((resolve) => {
    const ws = new WebSocket(URL);
    const st = { name, ws, snaps: 0, ev: {}, me: null, you: 0, hits: 0, err: null };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', v: 1, cv: 200, name, prim: 'ar', skins: { ar: ['ar_flame', 1] }, knife: ['karambit', 'karambit_gold', 0] }));
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      if (m.t === 'welcome') resolve(st);
      else if (m.t === 'joined') { st.you = m.you; st.code = m.code; st.team = m.team; }
      else if (m.t === 'snap') { st.snaps++; st.me = m.me; st.last = m; }
      else if (m.t === 'ev') for (const x of m.l) st.ev[x[0]] = (st.ev[x[0]] || 0) + 1;
      else if (m.t === 'hit') st.hits++;
      else if (m.t === 'err') st.err = m.m;
      else if (m.t === 'roster') st.roster = m.list;
    };
  });
}
(async () => {
  const a = await client('Сабина'), b = await client('Друг');
  a.ws.send(JSON.stringify({ t: 'create', mode: 'tdm', map: 'dust', size: 5 }));
  await new Promise(r => setTimeout(r, 400));
  b.ws.send(JSON.stringify({ t: 'join', code: a.code }));
  await new Promise(r => setTimeout(r, 400));
  // двигаемся и стреляем вперёд
  let n = 0;
  const iv = setInterval(() => {
    for (const c of [a, b]) {
      if (!c.me || !c.me.al) continue;
      const me = c.me; n++;
      const yaw = me.yw, x = me.x + Math.sin(n * 0.05) * 0.05, z = me.z;
      c.ws.send(JSON.stringify({ t: 'st', p: [x, me.y, z], v: [0, 0, 0], yw: yaw, pt: 0, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: 'primary' }));
      if (n % 6 === 0) {
        const dx = -Math.sin(yaw), dz = -Math.cos(yaw);
        c.ws.send(JSON.stringify({ t: 'shot', s: 'primary', w: 'ar', o: [x, me.y + 1.62, z], d: [dx, 0, dz], lag: 0.1 }));
      }
    }
  }, 33);
  await new Promise(r => setTimeout(r, 8000));
  clearInterval(iv);
  for (const c of [a, b]) console.log(c.name, 'code', c.code, 'team', c.team, 'snaps', c.snaps, 'hp', c.me && c.me.hp, 'k/d', c.me && c.me.k + '/' + c.me.d, 'hits', c.hits, 'err', c.err, 'ev', JSON.stringify(c.ev));
  console.log('roster', JSON.stringify(a.roster && a.roster.map(r => r[1] + (r[3] ? '*' : '') + ':' + r[2])));
  console.log('snap size', JSON.stringify(a.last).length, 'bytes; actors', a.last.a.length, 'game', JSON.stringify(a.last.g));
  a.ws.close(); b.ws.close();
  setTimeout(() => process.exit(0), 300);
})();
