'use strict';
// 2.1: оперативники. hello.ops / {t:'ops'} → проверка формата → последнее (12-е) поле ростера; боты и старые клиенты — null
const { sleep, check, summary, startServer, client } = require('./lib');
const rowOf = (c, name) => { const r = c.last('roster'); return r && r.list.find(x => x[1] === name); };
(async () => {
  const srv = await startServer();
  try {
    const a = await client(srv.url, { name: 'Оператор' });
    a.hello({ ops: ['ct_elite', 't_hood'] });
    await sleep(200);
    a.send({ t: 'quick', mode: 'tdm', side: 'ct' });
    const ja = await a.wait('joined');
    await sleep(400);
    const ra = rowOf(a, 'Оператор');
    check(ja && ra && ra.length === 13 && JSON.stringify(ra[11]) === '["ct_elite","t_hood"]', 'hello ops → roster row field 12', ra);
    const bot = a.last('roster').list.find(x => !x[3]);
    check(bot && bot.length === 13 && bot[11] === null, 'bots: ops null', bot);
    // старый клиент 2.0 (без ops) в той же комнате
    const b = await client(srv.url, { name: 'Старичок' });
    b.send({ t: 'quick', mode: 'tdm', side: 't' });
    const jb = await b.wait('joined');
    await sleep(400);
    const rb = rowOf(a, 'Старичок');
    check(jb && jb.code === ja.code && rb && rb.length === 13 && rb[11] === null, 'client without ops → null (first 11 fields unchanged)', rb);
    // смена оперативника в комнате — новый ростер у всех
    let mk = b.mark();
    a.send({ t: 'ops', ops: ['ct_swat', 't_elite'] });
    const ro = await b.wait('roster', m => m.list.some(x => x[1] === 'Оператор' && JSON.stringify(x[11]) === '["ct_swat","t_elite"]'), 3000, mk);
    check(!!ro, "{t:'ops'} in a room → roster re-sent with the new ops");
    // мусор: неверные id, лишние элементы, не массив
    mk = b.mark();
    a.send({ t: 'ops', ops: ['BAD!', 'x'.repeat(30), 'ct_city'] });
    const rbad = await b.wait('roster', m => m.list.some(x => x[1] === 'Оператор' && x[11] === null), 3000, mk);
    check(!!rbad, 'invalid ids (and a 3rd item) → null');
    a.send({ t: 'ops', ops: ['ct_recon', 42] });
    const rmix = await b.wait('roster', m => m.list.some(x => x[1] === 'Оператор' && JSON.stringify(x[11]) === '["ct_recon",null]'), 3000, mk);
    check(!!rmix, 'partially valid → invalid item becomes null');
    a.send({ t: 'ops', ops: 'ct_swat' });
    await sleep(300);
    check(rowOf(b, 'Оператор')[11] === null, 'non-array → null (old looks by name)', rowOf(b, 'Оператор')[11]);
    // ops до входа в комнату (в меню) — запоминается на соединении
    const c = await client(srv.url, { name: 'Меню' });
    c.send({ t: 'ops', ops: ['ct_city', 't_beanie'] });
    await sleep(200);
    c.send({ t: 'quick', mode: 'tdm' });
    await c.wait('joined');
    await sleep(400);
    check(JSON.stringify((rowOf(c, 'Меню') || [])[11]) === '["ct_city","t_beanie"]', 'ops sent in the lobby apply on join', rowOf(c, 'Меню'));
    a.close(); b.close(); c.close();
  } finally { await srv.stop(); }
  process.exit(summary('ops'));
})().catch(e => { console.error(e); process.exit(1); });
