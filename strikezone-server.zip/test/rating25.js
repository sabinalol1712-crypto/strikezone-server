'use strict';
// 2.5: рейтинг «Напарников» по вкладу (+17…+42 / −13…−25 / −50 за выход) и возвращение в рейтинговый матч
// (кнопка «Вернуться в матч»: rk_back для игры 2.5; выход из матча держит место; вернулся — без штрафа).
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');

(async () => {
  const srv = await startServer({ env: { SZ_RANKED_WARM_S: '0', SZ_RANKED_HOLD_MS: '60000' } });
  const url = srv.url, adm = await adminSession(srv);
  async function player(name) {
    const p = { name, acc: newAcc(), key: 'k' + rnd(15) };
    p.c = await client(url, { name, acc: p.acc, key: p.key, cv: 250 });
    await p.c.wait('me');
    return p;
  }
  async function queue(ps) {
    const marks = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    const found = await Promise.all(ps.map((p, i) => p.c.wait('rq_found', null, 4000, marks[i])));
    const joined = await Promise.all(ps.map((p, i) => p.c.wait('joined', m => !!m.ranked, 6000, marks[i])));
    return { found, joined, marks };
  }
  try {
    const ps = [await player('Альфа'), await player('Браво'), await player('Чарли'), await player('Дельта')];
    for (const p of ps) await adm.post('rating', { acc: p.acc.id, rating: 1500, cal: 5 });
    await sleep(300);

    console.log('== contribution decides the points');
    let q = await queue(ps);
    check(q.joined.every(j => j && j.ranked === 'ranked'), 'match started');
    const W = ps.filter((p, i) => q.found[i].you === 0), L = ps.filter((p, i) => q.found[i].you === 1);
    // победитель-звезда, победитель-пассажир, проигравший с хорошей игрой, проигравший без вклада
    const perf = new Map([[W[0], { k: 14, d: 3, hs: 7, dmg: 1600, mvp: 5 }], [W[1], { k: 2, d: 6, dmg: 300 }], [L[0], { k: 9, d: 8, hs: 3, dmg: 1100, mvp: 2 }], [L[1], { k: 0, d: 10, dmg: 80 }]]);
    for (const [p, st] of perf) { p.c.send({ t: '__test', op: 'perf', st, rounds: 13 }); await sleep(40); }
    let mk = ps.map(p => p.c.mark());
    W[0].c.send({ t: '__test', op: 'end', squad: 0 });
    let rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 4000, mk[i])));
    const d = (p) => rr[ps.indexOf(p)].delta;
    check(rr.every(r => r && r.st && 'k' in r.st && 'mvp' in r.st && typeof r.perf === 'number'), 'rated carries stats and contribution', rr[0]);
    check(d(W[0]) >= 17 && d(W[0]) <= 42 && d(W[1]) >= 17 && d(W[1]) <= 42, 'winners within +17…+42', [d(W[0]), d(W[1])]);
    check(d(L[0]) <= -13 && d(L[0]) >= -25 && d(L[1]) <= -13 && d(L[1]) >= -25, 'losers within −13…−25', [d(L[0]), d(L[1])]);
    check(d(W[0]) >= 38 && d(W[0]) > d(W[1]), 'star of the match gets close to +42, more than the passenger', [d(W[0]), d(W[1])]);
    check(d(L[0]) > d(L[1]) && d(L[1]) <= -22, 'good loser loses less than the empty one', [d(L[0]), d(L[1])]);
    const r0 = rr[ps.indexOf(W[0])];
    check(r0.st.k === 14 && r0.st.mvp === 5 && r0.rounds === 13, 'stats echoed back', r0);
    const hist = (await adm.get('player?acc=' + W[0].acc.id)).data.matches;
    check(hist[hist.length - 1].k === 14 && hist[hist.length - 1].mvp === 5, 'match history keeps kills and MVP', hist[hist.length - 1]);
    await sleep(500);

    console.log('== leave and come back: no penalty');
    q = await queue(ps);
    const code = q.joined[0].code, A0 = ps.filter((p, i) => q.found[i].you === 0), B1 = ps.filter((p, i) => q.found[i].you === 1);
    const leaver = B1[0];
    mk = ps.map(p => p.c.mark());
    leaver.c.send({ t: 'leave' });
    const back = await leaver.c.wait('rk_back', m => m.code === code, 3000, mk[ps.indexOf(leaver)]);
    check(back && back.kind === 'ranked' && back.map && Array.isArray(back.sc) && back.quit === 1 && back.until > Date.now(), 'leaver gets rk_back with code, map, score, deadline', back);
    check(!!(await A0[0].c.waitEv('sys', e => /может вернуться/.test(e[1]), 2000, mk[ps.indexOf(A0[0])])), 'others told the player can come back');
    await sleep(500);
    check(!A0[0].c.evs(mk[ps.indexOf(A0[0])]).some(e => e[0] === 'mend'), 'one leaver does not end the match');
    // перезапуск игры: свежее соединение получает кнопку
    leaver.c.close();
    await sleep(200);
    leaver.c = await client(url, { name: leaver.name, acc: leaver.acc, key: leaver.key, cv: 250 });
    const b2 = await leaver.c.wait('rk_back', m => m.code === code, 3000);
    check(!!b2, 'fresh connection after restart gets rk_back');
    const jm = leaver.c.mark();
    leaver.c.send({ t: 'join', code });
    const rj = await leaver.c.wait('joined', null, 3000, jm);
    check(rj && rj.ranked === 'ranked' && rj.resumed === 1, 'back in the match with the same player', rj);
    mk = ps.map(p => p.c.mark());
    A0[0].c.send({ t: '__test', op: 'end', squad: 1 });
    rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 4000, mk[i])));
    const lr = rr[ps.indexOf(leaver)];
    check(lr && lr.win === 1 && lr.left === 0 && lr.delta >= 17, 'came back and won: normal win, no penalty', lr);
    const off = await leaver.c.wait('rk_back', m => m.code === null, 2000, mk[ps.indexOf(leaver)]);
    check(!!off, 'after the match: rk_back cleared');
    await sleep(500);

    console.log('== leave and do not come back: −50');
    q = await queue(ps);
    const sq0 = ps.filter((p, i) => q.found[i].you === 0);
    mk = ps.map(p => p.c.mark());
    sq0[0].c.send({ t: 'leave' });
    await sleep(300);
    sq0[1].c.send({ t: '__test', op: 'end', squad: 0 });
    rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 4000, mk[i])));
    const gone = rr[ps.indexOf(sq0[0])];
    check(gone && gone.delta === -50 && gone.left === 1 && gone.win === 0, 'leaver who did not return: −50 even though the team won', gone);
    const old = await client(url, { name: 'Старый', acc: newAcc() });
    check(!old.msgs.some(m => m.t === 'rk_back'), 'old game versions do not get rk_back');
  } catch (e) { console.error(e); check(false, 'exception: ' + (e && e.message)); }
  await srv.stop();
  process.exit(summary('rating25'));
})();
