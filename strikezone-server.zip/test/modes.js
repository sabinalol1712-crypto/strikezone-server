'use strict';
// Обычные комнаты после 2.0: боты добираются, выбор стороны, дуэль, вышедшего заменяет бот, счёт и правила не рейтинговые.
const { sleep, check, summary, startServer, client, newAcc } = require('./lib');

(async () => {
  const srv = await startServer();
  const url = srv.url;
  try {
    console.log('== tdm quick');
    const a = await client(url, { name: 'Первый', acc: newAcc() });
    a.send({ t: 'quick', mode: 'tdm', side: 't' });
    const ja = await a.wait('joined');
    await sleep(400);
    check(ja && ja.mode === 'tdm' && ja.pub === true && !('ranked' in ja) && ja.team === 1, 'quick tdm: public room, side T respected', ja);
    check(a.last('roster').list.length === 10 && a.last('roster').list.filter(r => r[3]).length === 1, 'bots fill a 5v5 tdm room');
    const b = await client(url, { name: 'Второй' });
    b.send({ t: 'quick', mode: 'tdm', side: 'ct' });
    const jb = await b.wait('joined');
    check(jb && jb.code === ja.code && jb.team === 0, 'second player joins the same public room, side CT', jb);
    b.send({ t: 'leave' });
    await sleep(400);
    check(a.last('roster').list.length === 10 && a.last('roster').list.filter(r => r[3]).length === 1, 'leaver replaced by a bot');

    console.log('== bomb');
    a.send({ t: 'create', mode: 'bomb', map: 'harbor', size: 2 });
    const jbm = await a.wait('joined', m => m.mode === 'bomb');
    await sleep(500);
    check(jbm && jbm.map === 'harbor' && jbm.size === 2 && a.last('roster').list.length === 4, 'bomb 2v2 with bots');
    check(a.snap && a.snap.g.m === 'bomb' && a.snap.g.win === 7 && a.snap.g.max === 12, 'normal bomb keeps default WIN 7 / MAX 12', a.snap && a.snap.g);
    const lm = a.mark();
    a.send({ t: '__test', op: 'end', squad: 0 });
    check(!!(await a.waitEv('mend', null, 2000, lm)), 'match end in a normal room');
    await sleep(500);
    check(!a.msgs.slice(lm).some(m => m.t === 'rated'), 'no rating in normal rooms');
    a.send({ t: 'create', mode: 'bomb', map: 'villa', size: 5 });
    const jv = await a.wait('joined', m => m.code !== jbm.code && m.map === 'villa');
    check(jv && jv.map === 'villa' && jv.pvp === 1 && jv.rmode === 'bomb' && jv.mode === 'tdm' && jv.size === 2 && !('ranked' in jv), 'casual villa room stays a players-only warm-up room (1.7 behaviour), not ranked', jv);
    await sleep(300);
    check(a.last('roster').list.length === 1 && a.last('roster').list[0][3] === 1, 'casual villa: no bots in the roster');

    console.log('== duel');
    a.send({ t: 'create', mode: 'duel' });
    const jd = await a.wait('joined', m => m.mode === 'duel');
    check(jd && jd.map === 'winter' && jd.size === 1, 'duel room on winter', jd);
    const c = await client(url, { name: 'Дуэлянт' });
    c.send({ t: 'join', code: jd.code });
    const jc = await c.wait('joined');
    check(jc && jc.code === jd.code && jc.team !== jd.team, 'second duelist joins the other side');
    check(!!(await a.waitEv('sys', e => /Соперник найден/.test(e[1]))), 'duel restart message');
    await sleep(500);
    check(a.last('roster').list.length === 2 && a.last('roster').list.every(r => r[3]), 'duel roster: 2 humans');
    a.close(); c.close();

    console.log('== 2.0 map lists');
    const { createSim } = require('../sim/loader');
    const known = Object.keys(createSim().G.MAPS);
    const v = await client(url, { name: 'Карты' });
    v.send({ t: 'quick', mode: 'bomb', map: 'lagoon' });
    const jl = await v.wait('joined');
    check(jl && jl.pvp === 1 && jl.map === (known.includes('lagoon') ? 'lagoon' : 'villa') && jl.mode === 'tdm' && jl.rmode === 'bomb', '«Лагуна» 2×2 players-only (falls back to «Перрон» while the map is not in this build)', [known.includes('lagoon'), jl]);
    const vm = v.mark();
    v.send({ t: 'quick', map: 'winter' });
    const jw = await v.wait('joined', null, 3000, vm);
    check(jw && jw.mode === 'duel' && jw.map === 'winter', 'quick with the duel map → duel', jw);
    await sleep(300);
    const wm = v.mark();
    v.send({ t: 'create', mode: 'tdm', map: 'winter' });
    const jt = await v.wait('joined', null, 3000, wm);
    check(jt && jt.mode === 'tdm' && ['harbor', 'sakura', 'dust'].includes(jt.map), 'tdm never on the duel map', jt);
    await sleep(300);
    const dm = v.mark();
    v.send({ t: 'create', mode: 'tdm', map: 'dust' });
    const jd2 = await v.wait('joined', null, 3000, dm);
    check(jd2 && jd2.map === 'dust', 'dust available in casual rooms', jd2);
    v.close();
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  const errs = srv.logs.filter(l => /\[room|\[msg\]|uncaught/.test(l));
  check(errs.length === 0, 'no server errors', errs.slice(0, 3));
  await srv.stop();
  process.exit(summary('modes'));
})();
