// «Вилла» 1.6: только люди, разминка до 4 игроков, отсчёт, матч, техническая победа. Запуск: PORT=8097 SZ_FAST=1 node server.js; node test/villa.js
const URL = 'ws://localhost:' + (process.env.PORT || 8097) + '/ws';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let fail = 0; const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };
function client(name, key, old) {
  const ws = new WebSocket(URL), st = { ws, name, ev: [], errs: [], roster: null, snap: null, joined: null, n: 0 };
  ws.onopen = () => ws.send(JSON.stringify(old ? { t: 'hello', v: 1, cv: 119, key, name, prim: 'ar', skins: {} } : { t: 'hello', v: 1, cv: 119, key, name, prim: 'm4s', skins: {}, knife: ['knife', null, 0], gloves: null, drops: 1 }));
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.t === 'welcome') st.welcome = m;
    else if (m.t === 'joined') { st.joined = m; st.code = m.code; }
    else if (m.t === 'roster') st.roster = m.list;
    else if (m.t === 'snap') { st.snap = m; st.n++; if (m.g.wu) st.wu = m.g.wu; if (m.g.wu && m.g.wu[2]) st.sawCount = Math.max(st.sawCount || 0, m.g.wu[2]); }
    else if (m.t === 'ev') for (const x of m.l) st.ev.push(x);
    else if (m.t === 'err') st.errs.push(m.m);
  };
  st.send = (o) => ws.send(JSON.stringify(o));
  st.ping = setInterval(() => { try { st.send({ t: 'ping', c: 0 }); } catch (e) { } }, 3000);
  st.close = () => { clearInterval(st.ping); ws.close(); };
  return new Promise(r => { const iv = setInterval(() => { if (st.welcome) { clearInterval(iv); r(st); } }, 20); });
}
const until = async (f, ms) => { for (let t = 0; t < ms; t += 50) { if (f()) return true; await sleep(50); } return !!f(); };
const evs = (c, type) => c.ev.filter(e => e[0] === type);

(async () => {
  const A = await client('Анна', 'akey0000000001'), B = await client('Борис', 'bkey0000000001');
  ok('server >= 1.6.1', /^1\.(6\.[1-9]|[7-9]\.)/.test(A.welcome.srv), A.welcome.srv);
  A.send({ t: 'quick', mode: 'bomb', map: 'villa', side: 'ct' });
  await until(() => A.snap && A.roster, 3000);
  ok('A joined villa warm-up as TDM', A.joined.mode === 'tdm' && A.joined.pvp === 1 && A.joined.rmode === 'bomb' && A.joined.map === 'villa', JSON.stringify(A.joined));
  ok('A alone: roster has no bots', A.roster.length === 1 && A.roster.every(r => r[3] === 1), JSON.stringify(A.roster));
  await until(() => A.snap && A.snap.me && A.snap.me.al, 3000);
  ok('warm-up banner field 1/4', JSON.stringify(A.snap.g.wu) === '[1,4,0]', JSON.stringify(A.snap.g.wu));
  ok('warm-up loadout: CT rifle + pistol + armor', A.snap.me.al === 1 && ['ar2', 'm4s'].includes(A.snap.me.sl.primary && A.snap.me.sl.primary[0]) && A.snap.me.sl.secondary[0] === 'usp' && A.snap.me.ar === 100, JSON.stringify(A.snap.me.sl) + ' ar ' + A.snap.me.ar);
  ok('no bots in snapshot', A.snap.a.length === 1, A.snap.a.length);
  B.send({ t: 'quick', mode: 'bomb', map: 'villa', side: 'auto' });
  await until(() => B.joined && A.wu && A.wu[0] === 2, 3000);
  ok('B in same room, A sees 2/4', B.code === A.code && A.wu[0] === 2, B.code + ' ' + JSON.stringify(A.wu));
  ok('B on the other team (T)', B.joined.team === 1, B.joined.team);
  await until(() => B.snap && B.snap.me && B.snap.me.al, 3000);
  ok('B (T) has AK + Glock', B.snap.me.sl.primary[0] === 'ar' && B.snap.me.sl.secondary[0] === 'pistol', JSON.stringify(B.snap.me.sl));
  // старый клиент (без drops и новых полей) играет в разминке
  const C = await client('Старый', 'ckey0000000001', true);
  C.send({ t: 'quick', mode: 'bomb', map: 'villa' });
  await until(() => C.snap && C.snap.me && C.snap.me.al && A.wu[0] === 3, 3000);
  ok('old client C joins warm-up and is alive (TDM-like)', C.code === A.code && C.joined.mode === 'tdm' && C.snap.me.al === 1 && C.snap.g.m === 'tdm', JSON.stringify(C.snap && C.snap.g));
  ok('3 players, roster 3 humans', A.roster.length === 3 && A.roster.every(r => r[3] === 1) && JSON.stringify(A.wu) === '[3,4,0]', JSON.stringify(A.wu));
  await sleep(1500);
  ok('still warm-up with 3 (no score, no timer run)', A.snap.g.m === 'tdm' && A.snap.g.wu && A.snap.g.tl === 300 && A.snap.g.sc[0] === 0, JSON.stringify(A.snap.g));
  // 4-й входит → отсчёт; уходит → снова разминка
  let D = await client('Дина', 'dkey0000000001');
  D.send({ t: 'quick', mode: 'bomb', map: 'villa', side: 't' });
  await until(() => A.wu && A.wu[2] > 0, 3000);
  ok('4th joins → countdown', A.wu[0] === 4 && A.wu[2] >= 4, JSON.stringify(A.wu));
  D.send({ t: 'leave' });
  await until(() => A.wu && A.wu[2] === 0, 3000);
  ok('4th leaves during countdown → back to warm-up 3/4', JSON.stringify(A.wu) === '[3,4,0]' && A.snap.g.m === 'tdm', JSON.stringify(A.wu));
  D.send({ t: 'quick', mode: 'bomb', map: 'villa', side: 't' });
  await until(() => A.wu && A.wu[2] > 0, 3000);
  ok('4th rejoins → countdown again', A.wu[0] === 4 && A.wu[2] > 0, JSON.stringify(A.wu));
  // 5-й: быстрый поиск — в другую комнату, по коду — отказ
  const E = await client('Ева', 'ekey0000000001');
  E.send({ t: 'join', code: A.code });
  await until(() => E.errs.length, 2000);
  ok('5th by code refused', E.errs[0] === 'Комната заполнена', E.errs[0]);
  E.send({ t: 'quick', mode: 'bomb', map: 'villa' });
  await until(() => E.joined, 2000);
  ok('5th by quick → another villa room', E.joined && E.code !== A.code && E.joined.pvp === 1, E.code + ' vs ' + A.code);
  await until(() => evs(A, 'mstart').length, 7000);
  const ms = evs(A, 'mstart')[0];
  ok('countdown ends → match start event (bomb)', ms && ms[1] === 'bomb' && ms[2] === 'villa', JSON.stringify(ms));
  await until(() => A.snap.g.m === 'bomb' && C.snap.g.m === 'bomb', 2000);
  ok('match: exactly 4 actors, bomb, no wu', A.snap.a.length === 4 && A.snap.g.m === 'bomb' && !A.snap.g.wu && A.roster.length === 4 && A.roster.every(r => r[3] === 1), A.snap.a.length + ' ' + JSON.stringify(A.roster.map(r => r[1] + ':' + r[2])));
  const teams = A.roster.map(r => r[2]);
  ok('teams balanced 2/2', teams.filter(t => t === 0).length === 2 && teams.filter(t => t === 1).length === 2, JSON.stringify(teams));
  ok('match money 800, round 1', A.snap.me.$ === 800 && A.snap.g.r === 1, A.snap.me.$ + ' r' + A.snap.g.r);
  ok('old client switched to bomb', C.snap.g.m === 'bomb' && evs(C, 'mstart').some(e => e[1] === 'bomb'));
  await until(() => evs(A, 'rend').length, 40000);
  ok('bomb round ends normally', evs(A, 'rend').length >= 1, JSON.stringify(evs(A, 'rend')));
  // одна команда уходит → техническая победа другой → разминка
  const byName = {}; for (const r of A.roster) byName[r[1]] = r[2];
  const all = [A, B, C, D], tA = byName['Анна'];
  const gone = all.filter(x => byName[x.name] !== tA), stay = all.filter(x => byName[x.name] === tA);
  ok('roster names known', gone.length === 2 && stay.length === 2, JSON.stringify(byName));
  gone[0].send({ t: 'leave' }); await sleep(300);
  ok('one leaver: match goes on 2v1', !evs(A, 'mend').length && A.snap.a.length === 3);
  gone[1].send({ t: 'leave' });
  await until(() => evs(A, 'mend').length, 3000);
  const me = evs(A, 'mend')[0];
  ok('forfeit → other team wins', me && me[1] === tA && me[3] === 1 && me[2][tA] > me[2][1 - tA], JSON.stringify(me));
  A.ev.length = 0;
  await until(() => evs(A, 'mstart').length && A.snap.g.wu, 12000);
  ok('after forfeit → warm-up for remaining 2', evs(A, 'mstart')[0][1] === 'tdm' && JSON.stringify(A.snap.g.wu) === '[2,4,0]', JSON.stringify(A.snap.g.wu));
  // новый игрок по быстрому поиску — в комнату, где больше людей
  const F = await client('Фёдор', 'fkey0000000001');
  F.send({ t: 'quick', mode: 'bomb', map: 'villa' });
  await until(() => F.joined, 2000);
  ok('new joiner fills the forfeited room (2 > 1 humans)', F.code === A.code, F.code + ' A ' + A.code + ' E ' + E.code);
  // список комнат
  A.send({ t: 'list' });
  const lst = await new Promise(r => { const h = A.ws.onmessage; A.ws.onmessage = (e) => { h(e); const m = JSON.parse(e.data); if (m.t === 'rooms') { A.ws.onmessage = h; r(m.list); } }; });
  const vr = lst.find(r => r.id === A.code);
  ok('room list: villa n/4 + warm', vr && vr.players === 3 && vr.max === 4 && vr.st === 'warm' && vr.pvp === 1, JSON.stringify(vr));
  // «Любая карта» не попадает на «Виллу»
  const G1 = await client('Гоша', 'gkey0000000001');
  G1.send({ t: 'quick', mode: 'bomb', map: 'any' });
  await until(() => G1.roster, 3000);
  ok('quick any → not villa, bots fill (harbor/sakura)', G1.joined.map !== 'villa' && !G1.joined.pvp && G1.roster.length === 10 && G1.roster.filter(r => !r[3]).length === 9, G1.joined.map + ' ' + G1.roster.length);
  const H = await client('Хана', 'hkey0000000001');
  H.send({ t: 'quick', mode: 'tdm', map: 'harbor' });
  await until(() => H.roster, 3000);
  ok('harbor quick still gets bots', H.joined.map === 'harbor' && H.roster.length === 10 && H.roster.filter(r => !r[3]).length === 9, H.roster.length);
  // комната друзей на «Вилле» в режиме TDM
  const I = await client('Илья', 'ikey0000000001');
  I.send({ t: 'create', mode: 'tdm', map: 'villa', size: 2, diff: 'normal' });
  await until(() => I.snap, 3000);
  ok('friends villa TDM room: warm-up, players only', I.joined.pvp === 1 && I.joined.rmode === 'tdm' && !I.joined.pub && I.roster.length === 1 && JSON.stringify(I.snap.g.wu) === '[1,4,0]', JSON.stringify(I.joined));
  for (const x of [A, B, C, D, E, F, G1, H, I]) x.close();
  console.log(fail ? 'FAILED ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
