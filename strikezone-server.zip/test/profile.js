'use strict';
// Профиль 2.0: регистрация (порядковые номера, №1 зарезервирован), вход по паролю на других устройствах, выход, назначение ID админом,
// смена ника, аватары (набор / свой JPEG и PNG, ограничения), медали (надевание, админские, по правилам), строка ростера, хранение после перезапуска.
const fs = require('fs');
const path = require('path');
const { sleep, check, summary, startServer, adminSession, client } = require('./lib');

const FX = path.join(__dirname, 'fixtures');
const jpg = 'data:image/jpeg;base64,' + fs.readFileSync(path.join(FX, 'avatar96.jpg')).toString('base64');
const png = 'data:image/png;base64,' + fs.readFileSync(path.join(FX, 'avatar96.png')).toString('base64');
const big = 'data:image/jpeg;base64,' + fs.readFileSync(path.join(FX, 'avatar400.jpg')).toString('base64');

(async () => {
  let srv = await startServer({ env: { SZ_AV_EVERY_MS: '1200' } });
  const url = () => srv.url;
  const guest = async (name) => client(url(), { name: name || 'Гость' });
  const secrets = [];
  try {
    console.log('== registration');
    const g = await guest('Регистратор');
    const bad = [
      [['ab', 'secret12'], /Ник: от 3 до 16/], [['a'.repeat(17), 'secret12'], /Ник: от 3 до 16/], [['@@@@@', 'secret12'], /Ник: от 3 до 16/],
      [['12345', 'secret12'], /хотя бы одну букву/], [['Нормальный', 'x1'], /Пароль слишком короткий/], [['Нормальный', 'x'.repeat(65)], /Пароль слишком длинный/],
      [['Админ', 'secret12'], /Ник занят/]
    ];
    for (const [[n, p], re] of bad) { const r = await g.regRaw(n, p); check(r && r.t === 'reg_err' && re.test(r.m), 'reg refused: ' + n.slice(0, 8) + ' / ' + p.length + ' chars', r); }
    const owner = await guest('Владелец'); const rO = await owner.regRaw('Хозяин игры', 'owner-pass-1'); secrets.push('owner-pass-1');
    check(rO && rO.t === 'reg_ok' && /^a[a-z0-9]{11}$/.test(rO.id) && /^[a-zA-Z0-9]{24}$/.test(rO.key) && rO.num === 2 && rO.nick === 'Хозяин игры', 'first registration gets num 2 (1 is reserved), reg_ok {id,key,num,nick}', rO);
    secrets.push(rO.key);
    const meO = await owner.wait('me');
    const mo = meO && meO.acc;
    check(mo && mo.id === rO.id && mo.num === 2 && mo.nick === 'Хозяин игры' && mo.rating === 1000 && mo.cal === 0 && mo.peak === -1 && mo.clan === null &&
      mo.av.p === 0 && mo.av.c === 0 && Array.isArray(mo.eq) && mo.eq.length === 0 && Array.isArray(mo.rewards) && mo.rewards.length === 0, 'me after reg_ok has num, peak -1, av {p:0,c:0}, eq [], rewards []', mo);
    check(mo && mo.medals.includes('pioneer') && mo.medals.includes('early') && !mo.medals.includes('owner'), 'low number → «Первопроходец» + «Ранний игрок»', mo && mo.medals);
    const r2c = await guest(); const r2 = await r2c.regRaw('Второй', 'second-pass-2'); secrets.push('second-pass-2');
    const r3c = await guest(); const r3 = await r3c.regRaw('Третий', 'third-pass-3'); secrets.push('third-pass-3');
    check(r2.num === 3 && r3.num === 4, 'numbers are sequential', [r2.num, r3.num]);
    const dup = await (await guest()).regRaw('второй', 'another-pass');
    check(dup.t === 'reg_err' && dup.m === 'Ник занят', 'nick unique case-insensitively → Ник занят', dup);
    const again = await owner.regRaw('Другой ник', 'owner-pass-2');
    check(again.t === 'reg_err' && /уже вошли/.test(again.m), 'cannot register while logged in', again);
    const noHello = await client(url(), { name: 'Без hello', noHello: true });
    noHello.send({ t: 'reg', nick: 'Рано', pass: 'secret12' });
    const nh = await noHello.wait('reg_err');
    check(!!nh, 'reg before hello → reg_err (no silent hang)', nh);

    console.log('== guests cannot use account features');
    const gg = await guest('Просто гость');
    for (const [m, code] of [[{ t: 'av', p: 3 }, 'acc'], [{ t: 'medals', eq: [] }, 'acc'], [{ t: 'nick', nick: 'Гостевой' }, 'acc']]) {
      const mk = gg.mark(); gg.send(m);
      const e = await gg.wait('err', x => x.code === code, 2000, mk);
      check(e && /Нужен аккаунт/.test(e.m), 'guest ' + m.t + ' → err ' + code + ' (Нужен аккаунт…)', e);
    }
    const mkG = gg.mark(); gg.send({ t: 'avatar', num: 2 });
    const ga = await gg.wait('avatar', null, 2000, mkG);
    check(ga && ga.num === 2 && ga.v === 0 && ga.data === null, 'guest may fetch avatars (none yet → data null)', ga);

    console.log('== login on other devices');
    const d1 = await guest('Устройство 1');
    const l1 = await d1.loginRaw('3', 'second-pass-2');
    check(l1.t === 'login_ok' && l1.id === r2.id && l1.num === 3 && l1.nick === 'Второй' && /^[a-zA-Z0-9]{24}$/.test(l1.key) && l1.key !== r2.key, 'login by ID number → login_ok with a NEW device key', l1);
    secrets.push(l1.key);
    check(!!(await d1.wait('me', m => m.acc.num === 3)), 'me after login_ok');
    const d2 = await guest('Устройство 2');
    const l2 = await d2.loginRaw('ВТОРОЙ', 'second-pass-2');
    check(l2.t === 'login_ok' && l2.id === r2.id, 'login by nick (any case)', l2);
    const d3 = await guest('Устройство 3');
    const lbad = await d3.loginRaw('Второй', 'wrong-pass-xx');
    const lunk = await d3.loginRaw('Никто такой', 'second-pass-2');
    check(lbad.t === 'login_err' && lbad.m === 'Неверный ID/ник или пароль' && lunk.t === 'login_err' && lunk.m === lbad.m, 'wrong password / unknown name → the same login_err', [lbad, lunk]);
    check(!d3.last('me'), 'failed login does not log in');
    // старые ключи остаются действительными
    const h1 = await client(url(), { name: 'x', acc: { id: r2.id, key: r2.key } });
    check(!!(await h1.wait('me')) && !h1.last('acc'), 'registration key still valid after a login on another device');
    // не больше 5 устройств: шестой ключ вытесняет самый старый
    const keys = [r3.key];
    for (let i = 0; i < 5; i++) { const d = await guest('Уст' + i); const l = await d.loginRaw('Третий', 'third-pass-3'); keys.push(l.key); secrets.push(l.key); d.close(); }
    const hOld = await client(url(), { name: 'x', acc: { id: r3.id, key: keys[0] } });
    const hNew = await client(url(), { name: 'x', acc: { id: r3.id, key: keys[5] } });
    check(!!(await hOld.wait('acc')) && !hOld.last('me') && !!(await hNew.wait('me')), 'only 5 device keys per account: the oldest is evicted by the 6th', [hOld.last('acc'), !!hNew.last('me')]);
    // выход
    d1.send({ t: 'logout' });
    check(!!(await d1.wait('logout_ok')), 'logout → logout_ok');
    d1.send({ t: 'clans' });
    const lc = await d1.wait('clan_err');
    check(lc && /Нужен аккаунт/.test(lc.m), 'after logout the connection is a guest');
    const hOut = await client(url(), { name: 'x', acc: { id: r2.id, key: l1.key } });
    check(!!(await hOut.wait('acc')) && !hOut.last('me'), 'logout revokes this device key');

    console.log('== admin: assign ID number');
    const adm = await adminSession(srv);
    let r = await adm.post('setnum', { acc: rO.id, num: 3 });
    check(r.status === 400 && /уже занят игроком Второй/.test(r.data.error), 'setnum to a taken number → 400', r.data);
    for (const bad of [0, -1, 1.5, 'abc', 100000000]) { r = await adm.post('setnum', { acc: rO.id, num: bad }); check(r.status === 400, 'setnum invalid ' + JSON.stringify(bad) + ' → 400', r.data); }
    r = await adm.post('setnum', { acc: 'azzzzzzzzzzz', num: 1 });
    check(r.status === 404, 'setnum unknown player → 404');
    const mk = owner.mark();
    r = await adm.post('setnum', { acc: rO.id, num: 1 });
    check(r.status === 200 && r.data.ok && r.data.num === 1, 'setnum owner → 1', r.data);
    const meO2 = await owner.wait('me', m => m.acc.num === 1, 3000, mk);
    check(!!meO2 && meO2.acc.medals.includes('pioneer'), 'online player gets a fresh me with num 1', meO2 && meO2.acc.num);
    r = await adm.get('players?q=1');
    check(r.data.list.length >= 1 && r.data.list[0].num === 1 && r.data.list[0].nick === 'Хозяин игры', 'players?q=1 finds ID №1 (search by number)', r.data.list.map(x => x.num));
    r = await adm.get('players?q=%233');
    check(r.data.list.some(x => x.nick === 'Второй' && x.num === 3), 'players?q=#3 finds ID №3');
    r = await adm.get('player?acc=' + rO.id);
    check(r.data.num === 1 && r.data.medals.includes('pioneer') && Array.isArray(r.data.rewards), 'admin player: num, medals, rewards', Object.keys(r.data));
    const r5c = await guest(); const r5 = await r5c.regRaw('Пятый', 'fifth-pass-5'); secrets.push('fifth-pass-5');
    check(r5.num === 5, 'public registration continues from the counter (2 stays free)', r5.num);
    r = await adm.post('setnum', { acc: r5.id, num: 2 });
    check(r.status === 200 && r.data.num === 2, 'a freed number can be assigned again');
    r = await adm.post('setnum', { acc: r5.id, num: 5 });
    check(r.status === 200, 'and back');

    console.log('== nick change');
    const sec = await client(url(), { name: 'Второй', acc: { id: r2.id, key: r2.key } });
    await sec.wait('me');
    sec.send({ t: 'nick', nick: 'Второй-Два' });
    const meN = await sec.wait('me', m => m.acc.nick === 'Второй-Два');
    check(!!meN, 'nick → fresh me with the new nick');
    const mkN = sec.mark(); sec.send({ t: 'nick', nick: 'Другой ник' });
    const eN = await sec.wait('err', m => m.code === 'nick', 2000, mkN);
    check(eN && /раз в сутки/.test(eN.m), 'second rename within 24 h → err', eN);
    const thr = await client(url(), { name: 'x', acc: { id: r3.id, key: keys[5] } });
    await thr.wait('me');
    const mkT = thr.mark(); thr.send({ t: 'nick', nick: 'второй-два' });
    const eT = await thr.wait('err', m => m.code === 'nick', 2000, mkT);
    check(eT && eT.m === 'Ник занят', 'rename to a taken nick → Ник занят', eT);
    const mkB = thr.mark(); thr.send({ t: 'nick', nick: 'a' });
    check(!!(await thr.wait('err', m => m.code === 'nick' && /Ник: от 3/.test(m.m), 2000, mkB)), 'rename: bad nick → err');
    const freed = await (await guest()).regRaw('Второй', 'second-pass-9'); secrets.push('second-pass-9');
    check(freed.t === 'reg_ok', 'the old nick is free after a rename', freed);
    const lN = await (await guest()).loginRaw('Второй-Два', 'second-pass-2');
    check(lN.t === 'login_ok' && lN.num === 3, 'login with the new nick');

    console.log('== avatars');
    const A = await client(url(), { name: 'x', acc: { id: rO.id, key: rO.key } });
    await A.wait('me');
    let mkA = A.mark(); A.send({ t: 'av', p: 7 });
    let m1 = await A.wait('me', m => m.acc.av.p === 7, 3000, mkA);
    check(m1 && m1.acc.av.c === 0, 'preset avatar → me.av {p:7, c:0}', m1 && m1.acc.av);
    mkA = A.mark(); A.send({ t: 'av', p: 9 });
    let e = await A.wait('err', x => x.code === 'av', 2000, mkA);
    check(e && /30 секунд/.test(e.m), 'avatar change rate limit (1 / 30 s)', e);
    await sleep(1300);
    mkA = A.mark(); A.send({ t: 'av', p: 64 });
    e = await A.wait('err', x => x.code === 'av', 2000, mkA);
    check(e && /Неверный аватар/.test(e.m), 'preset index out of range → err', e);
    mkA = A.mark(); A.send({ t: 'av', data: 'data:text/html;base64,PGI+' });
    check(!!(await A.wait('err', x => x.code === 'av' && /JPEG или PNG/.test(x.m), 2000, mkA)), 'non-image data URL rejected');
    mkA = A.mark(); A.send({ t: 'av', data: 'data:image/jpeg;base64,' + Buffer.from('this is definitely not a jpeg file at all').toString('base64') });
    check(!!(await A.wait('err', x => x.code === 'av', 2000, mkA)), 'JPEG data URL with wrong content rejected');
    mkA = A.mark(); A.send({ t: 'av', data: 'data:image/jpeg;base64,' + 'A'.repeat(24100) });
    check(!!(await A.wait('err', x => x.code === 'av' && /слишком большой/.test(x.m), 2000, mkA)), '> 24000 chars rejected');
    mkA = A.mark(); A.send({ t: 'av', data: big });
    check(!!(await A.wait('err', x => x.code === 'av' && /96/.test(x.m), 2000, mkA)), '400×400 picture rejected (must be ~96×96)');
    mkA = A.mark(); A.send({ t: 'av', data: jpg });
    m1 = await A.wait('me', m => m.acc.av.c > 0, 3000, mkA);
    check(m1 && m1.acc.av.p === 7, 'custom JPEG accepted → me.av.c > 0, preset index kept', m1 && m1.acc.av);
    const v1 = m1.acc.av.c;
    check(fs.existsSync(path.join(srv.dir, 'avatars', rO.id + '.jpg')), 'stored in data/avatars/');
    const mkF = gg.mark(); gg.send({ t: 'avatar', num: 1 });
    const fa = await gg.wait('avatar', null, 2000, mkF);
    check(fa && fa.num === 1 && fa.v === v1 && fa.data === jpg, 'avatar fetch by num: {num, v, data} identical to the upload', fa && [fa.num, fa.v, fa.data && fa.data.length]);
    await sleep(1300);
    mkA = A.mark(); A.send({ t: 'av', data: png });
    m1 = await A.wait('me', m => m.acc.av.c > v1, 3000, mkA);
    check(m1 && fs.existsSync(path.join(srv.dir, 'avatars', rO.id + '.png')) && !fs.existsSync(path.join(srv.dir, 'avatars', rO.id + '.jpg')), 'PNG accepted, version bumped, old file replaced', m1 && m1.acc.av);
    await sleep(1300);
    mkA = A.mark(); A.send({ t: 'av', p: 12 });
    m1 = await A.wait('me', m => m.acc.av.p === 12, 3000, mkA);
    check(m1 && m1.acc.av.c === 0 && !fs.existsSync(path.join(srv.dir, 'avatars', rO.id + '.png')), 'choosing a preset removes the custom picture (c = 0)', m1 && m1.acc.av);
    await sleep(1300);
    mkA = A.mark(); A.send({ t: 'av', data: jpg });
    m1 = await A.wait('me', m => m.acc.av.c > 0, 3000, mkA);
    check(m1 && m1.acc.av.c > v1, 'versions never repeat (cache key num+v is safe)', [v1, m1 && m1.acc.av.c]);
    r = await adm.get('avatar?acc=' + rO.id);
    check(r.data.data === jpg && r.data.num === 1, 'admin can view the avatar', r.status);
    mkA = A.mark();
    r = await adm.post('avatar_reset', { acc: rO.id });
    m1 = await A.wait('me', m => m.acc.av.c === 0, 3000, mkA);
    check(r.data.ok && !!m1 && !fs.existsSync(path.join(srv.dir, 'avatars', rO.id + '.jpg')), 'admin avatar_reset: c = 0, file deleted, player gets me', r.data);
    const mkF2 = gg.mark(); gg.send({ t: 'avatar', num: 1 });
    const fb = await gg.wait('avatar', null, 2000, mkF2);
    check(fb && fb.v === 0 && fb.data === null, 'after reset the fetch returns data null');
    await sleep(1300);
    mkA = A.mark(); A.send({ t: 'av', data: jpg });
    await A.wait('me', m => m.acc.av.c > 0, 3000, mkA);

    console.log('== medals');
    mkA = A.mark(); A.send({ t: 'medals', eq: ['pioneer', 'early', 'k100', 'bogus', 'owner'], local: ['k100', 'evil', 'ace'] });
    let mm = await A.wait('me', m => m.acc.eq.length > 0, 3000, mkA);
    check(mm && JSON.stringify(mm.acc.eq) === JSON.stringify(['pioneer', 'early', 'k100']), 'eq keeps owned/local ids only, max 3 (bogus, evil and unowned owner dropped)', mm && mm.acc.eq);
    mkA = A.mark(); A.send({ t: 'medals', eq: ['ace', 'k100'], local: ['k100', 'ace'] });
    mm = await A.wait('me', m => m.acc.eq.includes('ace'), 3000, mkA);
    check(mm && JSON.stringify(mm.acc.eq) === JSON.stringify(['ace', 'k100']), 'local medals (whitelist) can be equipped', mm && mm.acc.eq);
    mkA = A.mark(); A.send({ t: 'medals', eq: ['k1000'] });
    mm = await A.wait('me', m => true, 3000, mkA);
    check(mm && mm.acc.eq.length === 0, 'a local medal not claimed is not equipped', mm && mm.acc.eq);
    r = await adm.post('medal', { acc: rO.id, id: 'cw_win', on: true });
    check(r.status === 400, 'admin cannot hand out rule-based medals', r.data);
    r = await adm.post('medal', { acc: rO.id, id: 'nope', on: true });
    check(r.status === 400, 'unknown medal → 400');
    mkA = A.mark();
    r = await adm.post('medal', { acc: rO.id, id: 'owner', on: true });
    mm = await A.wait('me', m => m.acc.medals.includes('owner'), 3000, mkA);
    check(r.data.ok && !!mm, 'admin medal owner on → fresh me', r.data);
    r = await adm.post('medal', { acc: rO.id, id: 'dev', on: true });
    A.send({ t: 'medals', eq: ['owner', 'dev', 'pioneer'] });
    mm = await A.wait('me', m => m.acc.eq.includes('owner'), 3000);
    check(mm && JSON.stringify(mm.acc.eq) === JSON.stringify(['owner', 'dev', 'pioneer']), 'owner + dev medals equipped', mm && mm.acc.eq);
    // ростер в комнате: [nid, имя, команда, человек, нож, перчатки, тег, цвет, номер, аватар, медали]
    A.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 2 });
    await A.wait('joined');
    await sleep(400);
    const row = A.last('roster').list.find(x => x[3] === 1);
    check(row && row.length === 13 && row[1] === 'Хозяин игры' && row[6] === null && row[7] === null && row[8] === 1 && row[9] && row[9].c > 0 && JSON.stringify(row[10]) === JSON.stringify(['owner', 'dev', 'pioneer']), 'roster row: [..., tag, color, num, {p,c}, eq]', row);
    const botRow = A.last('roster').list.find(x => x[3] === 0);
    check(botRow && botRow.length === 13 && botRow[8] === 0 && botRow[9] === null && botRow[10] === null && botRow[11] === null, 'bots: num 0, av null, eq null, ops null', botRow);
    const guestJoin = await guest('Гость комнаты');
    guestJoin.send({ t: 'join', code: A.last('joined').code });
    await guestJoin.wait('joined'); await sleep(300);
    const grow = A.last('roster').list.find(x => x[1] === 'Гость комнаты');
    check(grow && grow[8] === 0 && grow[9] === null && grow[10] === null, 'guest in the same room: num 0, av null, eq null', grow);
    mkA = A.mark();
    r = await adm.post('medal', { acc: rO.id, id: 'owner', on: false });
    mm = await A.wait('me', m => !m.acc.medals.includes('owner'), 3000, mkA);
    check(mm && JSON.stringify(mm.acc.eq) === JSON.stringify(['dev', 'pioneer']), 'revoking a medal removes it from eq', mm && mm.acc.eq);
    await sleep(300);
    const row2 = A.last('roster').list.find(x => x[3] === 1 && x[1] === 'Хозяин игры');
    check(row2 && JSON.stringify(row2[10]) === JSON.stringify(['dev', 'pioneer']), 'roster refreshed after a medal change', row2 && row2[10]);
    // лидер клана — по правилу
    A.send({ t: 'clan_create', name: 'Медальный', tag: 'MED', color: '#2ec4ff', emblem: 1, open: true, desc: '' });
    mm = await A.wait('me', m => m.acc.clan && m.acc.medals.includes('clan_leader'), 3000);
    check(!!mm, 'clan leader medal granted by rule');
    A.send({ t: 'clan_disband' });
    mm = await A.wait('me', m => !m.acc.clan && !m.acc.medals.includes('clan_leader'), 3000);
    check(!!mm, 'and gone after the clan is disbanded');
    A.send({ t: 'leave' }); await sleep(200);

    console.log('== persistence');
    const before = (await adm.get('player?acc=' + rO.id)).data;
    for (const c of conns(g, owner, r2c, r3c, d2, h1, hNew, sec, thr, gg, A, guestJoin)) c.close();
    await sleep(300);
    const dir = srv.dir, env = srv.env, logs1 = srv.logs.slice();
    await srv.stop('SIGTERM');
    const dbText = fs.readFileSync(path.join(dir, 'db.json'), 'utf8');
    check(!secrets.some(s => dbText.includes(s)), 'db.json holds no passwords and no device keys in clear text');
    const dbj = JSON.parse(dbText);
    check(dbj.seq >= 6 && Object.values(dbj.accounts).every(a => a.ph && a.ph.algo === 'scrypt' && a.ph.s.length === 32 && a.keys.every(k => /^[0-9a-f]{64}$/.test(k.h))), 'db.json: seq counter, scrypt hash + per-account salt, hashed keys', dbj.seq);
    srv = await startServer({ dataDir: dir, env: { ADMIN_FILE: env.ADMIN_FILE, SZ_AV_EVERY_MS: '1200' } });
    const adm2 = await adminSession(srv);
    const after = (await adm2.get('player?acc=' + rO.id)).data;
    check(after.num === 1 && after.nick === before.nick && JSON.stringify(after.medals) === JSON.stringify(before.medals) && JSON.stringify(after.eq) === JSON.stringify(before.eq) && after.av.c === before.av.c, 'num, medals, eq and avatar version survive a restart', [after.num, after.eq, after.av]);
    const P = await guest('После рестарта');
    const lp = await P.loginRaw('1', 'owner-pass-1');
    check(lp.t === 'login_ok' && lp.num === 1, 'password login works after restart (by ID №1)', lp);
    const mkP = P.mark(); P.send({ t: 'avatar', num: 1 });
    const pa = await P.wait('avatar', null, 2000, mkP);
    check(pa && pa.data === jpg && pa.v === before.av.c, 'avatar file survives a restart', pa && pa.v);
    const Q = await guest(); const nq = await Q.regRaw('После', 'afterpass-1'); secrets.push('afterpass-1');
    check(nq.t === 'reg_ok' && nq.num > dbj.seq - 1 && nq.num >= 6, 'numbering continues after restart', nq.num);

    console.log('== login attempts per address');
    const L = await guest('Подбор');
    const fl = [];
    for (let i = 0; i < 5; i++) fl.push((await L.loginRaw('Второй-Два', 'bad-pass-' + i)).m);
    const blocked = await L.loginRaw('Второй-Два', 'second-pass-2');
    check(fl.every(m => m === 'Неверный ID/ник или пароль') && blocked.t === 'login_err' && blocked.m === 'Слишком много попыток, подождите', '5 wrong passwords → even the right one waits', blocked);
    const logText = logs1.concat(srv.logs).join('\n');
    check(!secrets.some(s => logText.includes(s)), 'passwords and device keys never logged');
    const errs = logs1.concat(srv.logs).filter(l => /\[room|\[msg\]|uncaught|\[reg\]|\[login\]/.test(l));
    check(errs.length === 0, 'no server errors', errs.slice(0, 3));
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  await srv.stop();
  process.exit(summary('profile'));
})();
function conns(...a) { return a.filter(Boolean); }
