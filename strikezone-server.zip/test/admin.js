'use strict';
// Админ-панель: вход (пароль, 401, 429), все запросы API, заголовки, листание игроков, журнал.
const fs = require('fs');
const path = require('path');
const { sleep, check, summary, startServer, adminSession, client, newAcc, makeAdminFile, tmpDir, ADMIN_PASS } = require('./lib');

(async () => {
  const srv = await startServer();
  const url = srv.url;
  try {
    console.log('== page');
    let r = await srv.http('GET', '/admin');
    check(r.status === 200 && /text\/html/.test(r.headers.get('content-type')) && r.text.includes('/admin/api/'), 'GET /admin serves admin.html');
    check(r.headers.get('cache-control') === 'no-store' && r.headers.get('x-frame-options') === 'DENY' && /frame-ancestors 'none'/.test(r.headers.get('content-security-policy') || ''), 'page headers: no-store, X-Frame-Options DENY, CSP');
    r = await srv.http('GET', '/admin/');
    check(r.status === 200, 'GET /admin/ too');

    console.log('== login');
    const bad = { 'X-Forwarded-For': '10.0.0.5' };
    for (let i = 1; i <= 5; i++) {
      r = await srv.http('POST', '/admin/api/login', { password: 'wrong' + i }, bad);
      check(r.status === 401 && r.data.error === 'Неверный пароль', 'bad password #' + i + ' → 401', r.data);
    }
    r = await srv.http('POST', '/admin/api/login', { password: ADMIN_PASS }, bad);
    check(r.status === 429 && r.data.error === 'Слишком много попыток, подождите', 'after 5 failures → 429 (even with the right password)', [r.status, r.data]);
    r = await srv.http('POST', '/admin/api/login', { password: ADMIN_PASS }, { 'X-Forwarded-For': '10.0.0.6' });
    check(r.status === 200 && /^[0-9a-f]{64}$/.test(r.data.token) && Math.abs(r.data.exp - Date.now() - 12 * 3600000) < 60000, 'right password → {token, exp (12 h)}', r.data);
    check(r.headers.get('cache-control') === 'no-store' && r.headers.get('x-frame-options') === 'DENY', 'API headers no-store + DENY');
    r = await srv.http('POST', '/admin/api/login', '{bad json', { 'X-Forwarded-For': '10.0.0.7' });
    check(r.status === 401, 'broken JSON login → 401', r.status);
    r = await srv.http('GET', '/admin/api/login');
    check(r.status === 405, 'GET login → 405');
    const adm = await adminSession(srv, '10.0.0.8');

    console.log('== 401 without token');
    const GETS = ['state', 'players', 'player?acc=a00000000000', 'clans', 'clan?id=x', 'bans', 'leaderboard', 'log', 'nonexistent'];
    const POSTS = ['kick', 'ban', 'unban', 'mute', 'gift', 'rating', 'broadcast', 'motd', 'clan_edit', 'clan_delete', 'clan_kick', 'room_close', 'room_say'];
    let all401 = true;
    for (const p of GETS) { const x = await srv.http('GET', '/admin/api/' + p); if (x.status !== 401 || !x.data.error) all401 = false; }
    for (const p of POSTS) { const x = await srv.http('POST', '/admin/api/' + p, {}); if (x.status !== 401) all401 = false; }
    check(all401, 'every endpoint → 401 without token');
    r = await srv.http('GET', '/admin/api/state', null, { Authorization: 'Bearer ' + 'f'.repeat(64) });
    check(r.status === 401, 'unknown token → 401');
    r = await srv.http('GET', '/admin/api/state', null, { Authorization: adm.token });
    check(r.status === 401, 'token without Bearer → 401');
    r = await adm.post('motd', 'x'.repeat(11 * 1024));
    check(r.status === 413 && r.data.error, 'body > 10 KB → 413', r.status);
    r = await srv.http('POST', '/admin/api/motd', '{oops', { Authorization: 'Bearer ' + adm.token });
    check(r.status === 400 && r.data.error, 'broken JSON → 400');
    r = await adm.get('nonexistent');
    check(r.status === 404, 'unknown endpoint with token → 404');
    r = await srv.http('GET', '/admin/api/kick', null, { Authorization: 'Bearer ' + adm.token });
    check(r.status === 405, 'GET on POST endpoint → 405', r.status);

    console.log('== data');
    const accs = [];
    for (let i = 0; i < 35; i++) {
      const a = newAcc(), c = await client(url, { name: (i < 3 ? 'Снайпер' : 'Игрок') + i, acc: a });
      await c.wait('me'); accs.push({ a, c, nick: (i < 3 ? 'Снайпер' : 'Игрок') + i });
      if (i >= 2) c.close();
    }
    const [P0, P1] = accs;
    P0.c.send({ t: 'clan_create', name: 'Админы', tag: 'ADM', color: '#ffc23a', open: true });
    const clanId = (await P0.c.wait('clan_ok')).id;
    await sleep(250);
    P1.c.send({ t: 'clan_join', id: clanId });
    await P1.c.wait('clan_ok');
    P0.c.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 3 });
    const room = (await P0.c.wait('joined')).code;
    await sleep(5600);   // пинг меряется раз в 5 с

    console.log('== state');
    let s = (await adm.get('state')).data;
    check(s.version === '2.10.1' && typeof s.uptimeMin === 'number' && s.memMB > 0 && s.online === 2 && s.players === 1 && s.accounts === 35 && s.clans === 1 && s.motd === '' && s.queues.ranked === 0 && s.queues.clan === 0, 'state top-level fields', Object.assign({}, s, { rooms: undefined }));
    const rs = s.rooms.find(x => x.code === room);
    check(rs && rs.pub === false && rs.mode === 'tdm' && rs.map === 'harbor' && rs.kind === null && Array.isArray(rs.score) && rs.round === null && rs.over === false && rs.bots === 5, 'state room fields', rs);
    const rp = rs.players[0];
    check(rs.players.length === 1 && rp.acc === P0.a.id && rp.nick === P0.nick && rp.tag === 'ADM' && rp.team === 0 && rp.k === 0 && rp.d === 0 && typeof rp.ping === 'number', 'state room player {acc,nick,tag,team,k,d,ping}', rp);

    console.log('== players paging / search');
    r = await adm.get('players');
    check(r.data.total === 35 && r.data.page === 0 && r.data.pageSize === 30 && r.data.list.length === 30, 'no page → page 0, 30 of 35', [r.data.total, r.data.page, r.data.pageSize, r.data.list.length]);
    check(r.data.list[0].online && r.data.list[1].online, 'online players first');
    const p0 = r.data.list.find(x => x.acc === P0.a.id);
    check(p0 && p0.nick === P0.nick && p0.online === true && p0.room === room && p0.rating === 1000 && p0.cal === 0 && p0.wins === 0 && p0.losses === 0 && p0.games === 0 && p0.clan && p0.clan.tag === 'ADM' && p0.clan.id === clanId && p0.clan.name === 'Админы' && p0.clan.color === '#ffc23a' && p0.ban === null && p0.mute === null && p0.created > 0 && p0.seen > 0, 'player row fields', p0);
    r = await adm.get('players?q=&online=0&page=1');
    check(r.data.page === 1 && r.data.list.length === 5 && r.data.total === 35, 'page=1 → last 5', [r.data.page, r.data.list.length]);
    r = await adm.get('players?q=снайп&online=0');
    check(r.data.total === 3 && r.data.list.every(x => /Снайпер/.test(x.nick)), 'search by nick (case-insensitive)', r.data.total);
    r = await adm.get('players?q=' + accs[7].a.id.slice(0, 9));
    check(r.data.total === 1 && r.data.list[0].acc === accs[7].a.id, 'search by account id');
    r = await adm.get('players?q=&online=1');
    check(r.data.total === 2 && r.data.list.every(x => x.online), 'online=1 filter', r.data.total);

    console.log('== player actions');
    r = await adm.get('player?acc=' + P0.a.id);
    check(r.status === 200 && Array.isArray(r.data.matches) && r.data.gifts === 0 && r.data.acc === P0.a.id, 'player → + matches + gifts', r.data);
    r = await adm.get('player?acc=a00000000000');
    check(r.status === 404 && r.data.error, 'unknown player → 404');
    r = await adm.post('gift', { acc: P1.a.id, coins: 1000 });
    check(r.data.ok === true && r.data.n === 1 && (await P1.c.wait('gift'))?.coins === 1000, 'gift single → {ok, n:1}, delivered');
    r = await adm.post('gift', { all: true, coins: 5000 });
    const gp0 = await P0.c.wait('gift', m => m.coins === 5000), gp1 = await P1.c.wait('gift', m => m.coins === 5000);
    check(r.data.ok && r.data.n === 2 && gp0 && gp1, 'gift all online → {ok, n:2}', r.data);
    r = await adm.post('gift', { acc: P1.a.id, coins: 0 });
    check(r.status === 400, 'gift 0 coins → 400');
    r = await adm.post('gift', { acc: P1.a.id, coins: 'много' });
    check(r.status === 400, 'gift non-number → 400');
    r = await adm.post('rating', { acc: P1.a.id, rating: 1650 });
    check(r.data.ok && (await adm.get('player?acc=' + P1.a.id)).data.rating === 1650, 'rating set');
    r = await adm.post('rating', { acc: P1.a.id, rating: 20000 });
    check(r.status === 400, 'rating out of range → 400');
    r = await adm.post('rating', { acc: P1.a.id, reset: true });
    let pd = (await adm.get('player?acc=' + P1.a.id)).data;
    check(r.data.ok && pd.rating === 1000 && pd.cal === 0, 'rating reset → 1000, cal 0');
    r = await adm.post('mute', { acc: P1.a.id, minutes: 60 });
    pd = (await adm.get('player?acc=' + P1.a.id)).data;
    check(r.data.ok && pd.mute > Date.now() + 59 * 60000, 'mute 60 min', pd.mute);
    r = await adm.post('mute', { acc: P1.a.id, minutes: 0 });
    check(r.data.ok && (await adm.get('player?acc=' + P1.a.id)).data.mute === null, 'unmute');
    r = await adm.post('ban', { acc: accs[5].a.id, hours: 24, reason: 'Оскорбления' });
    pd = (await adm.get('player?acc=' + accs[5].a.id)).data;
    check(r.data.ok && pd.ban && pd.ban.reason === 'Оскорбления' && Math.abs(pd.ban.until - Date.now() - 24 * 3600000) < 60000, 'ban offline player 24 h', pd.ban);
    r = await adm.get('bans');
    const b0 = r.data.list[0];
    check(r.data.list.length === 1 && b0.acc === accs[5].a.id && b0.nick === accs[5].nick && b0.reason === 'Оскорбления' && b0.until > Date.now() && b0.at > 0, 'bans list {acc,nick,until,reason,at}', b0);
    r = await adm.post('ban', { acc: accs[5].a.id, hours: -1 });
    check(r.status === 400, 'negative ban hours → 400');
    r = await adm.post('unban', { acc: accs[5].a.id });
    check(r.data.ok && (await adm.get('bans')).data.list.length === 0 && (await adm.get('player?acc=' + accs[5].a.id)).data.ban === null, 'unban');
    r = await adm.post('kick', { acc: accs[9].a.id });
    check(r.status === 400 && r.data.error === 'Игрок не в сети', 'kick offline → 400');
    r = await adm.post('kick', { acc: 'a00000000000' });
    check(r.status === 404, 'kick unknown → 404');

    console.log('== messages');
    r = await adm.post('broadcast', { text: '  Всем привет  ' });
    check(r.data.ok && r.data.n === 2 && (await P1.c.wait('ann'))?.m === 'Всем привет', 'broadcast → {ok, n}, ann');
    r = await adm.post('broadcast', { text: '   ' });
    check(r.status === 400, 'empty broadcast → 400');
    r = await adm.post('motd', { text: 'Турнир в субботу' });
    check(r.data.ok && (await adm.get('state')).data.motd === 'Турнир в субботу', 'motd saved, visible in state');
    r = await adm.post('room_say', { code: room, text: 'Без читов, пожалуйста' });
    const say = await P0.c.waitEv('sys', e => e[1] === 'Администратор: Без читов, пожалуйста');
    check(r.data.ok && r.data.n === 1 && !!say, 'room_say → sys message in the room', r.data);
    r = await adm.post('room_say', { code: 'ZZZZ', text: 'x' });
    check(r.status === 404, 'room_say unknown room → 404');

    console.log('== clans');
    r = await adm.get('clans');
    const c0 = r.data.list[0];
    check(r.data.list.length === 1 && c0.id === clanId && c0.name === 'Админы' && c0.tag === 'ADM' && c0.color === '#ffc23a' && c0.members === 2 && c0.max === 20 && c0.leader === P0.nick && c0.pts === 0 && c0.wins === 0 && c0.losses === 0 && c0.open === true && c0.created > 0, 'clans list fields', c0);
    r = await adm.get('clans?q=adm');
    check(r.data.list.length === 1, 'clans search');
    r = await adm.get('clans?q=нет-такого');
    check(r.data.list.length === 0, 'clans search no match');
    r = await adm.get('clan?id=' + clanId);
    const mem = r.data.members;
    check(r.data.id === clanId && mem.length === 2 && mem.every(m => m.acc && m.nick && m.role && typeof m.rating === 'number' && m.online === true), 'clan detail members {acc,nick,role,rating,online}', mem);
    r = await adm.get('clan?id=nope');
    check(r.status === 404, 'unknown clan → 404');
    r = await adm.post('clan_edit', { id: clanId, name: 'Админы Сервера', tag: 'adms', pts: 150 });
    const mcl = await P0.c.wait('me', m => m.acc.clan && m.acc.clan.tag === 'ADMS');
    let cd = (await adm.get('clan?id=' + clanId)).data;
    check(r.data.ok && cd.name === 'Админы Сервера' && cd.tag === 'ADMS' && cd.pts === 150 && !!mcl, 'clan_edit name/tag/pts; members get fresh me', cd);
    r = await adm.post('clan_edit', { id: clanId, tag: 'TOOLONG' });
    check(r.status === 400 && /Тег/.test(r.data.error), 'clan_edit bad tag → 400', r.data);
    r = await adm.post('clan_edit', { id: clanId, name: 'x' });
    check(r.status === 400, 'clan_edit bad name → 400');
    r = await adm.post('clan_edit', { id: clanId, pts: -5 });
    check(r.status === 400, 'clan_edit negative pts → 400');
    r = await adm.post('clan_kick', { id: clanId, acc: P0.a.id });
    cd = (await adm.get('clan?id=' + clanId)).data;
    check(r.data.ok && cd.members.length === 1 && cd.members[0].acc === P1.a.id && cd.members[0].role === 'leader' && (await P0.c.wait('me', m => m.acc.clan === null)), 'clan_kick leader → next member becomes leader', cd.members);
    r = await adm.post('clan_kick', { id: clanId, acc: P0.a.id });
    check(r.status === 400, 'clan_kick non-member → 400');
    r = await adm.post('clan_delete', { id: clanId });
    check(r.data.ok && (await adm.get('clans')).data.list.length === 0 && (await P1.c.wait('me', m => m.acc.clan === null)), 'clan_delete');
    r = await adm.post('clan_delete', { id: clanId });
    check(r.status === 404, 'clan_delete unknown → 404');

    console.log('== leaderboard / room close');
    r = await adm.get('leaderboard');
    check(Array.isArray(r.data.players) && Array.isArray(r.data.clans), 'leaderboard {players, clans}');
    const em = P0.c.mark();
    r = await adm.post('room_close', { code: room });
    const me1 = await P0.c.waitEv('mend', null, 2000, em);
    s = (await adm.get('state')).data;
    check(r.data.ok && r.data.n === 1 && !!me1 && !s.rooms.some(x => x.code === room), 'room_close → players see match end, room gone', r.data);
    r = await adm.post('room_close', { code: room });
    check(r.status === 404, 'room_close unknown → 404');
    P0.c.send({ t: 'quick', mode: 'tdm' });
    check(!!(await P0.c.wait('joined', null, 3000, em)), 'player can play again after room close');

    console.log('== kick online');
    r = await adm.post('kick', { acc: P1.a.id });
    check(r.data.ok && r.data.n === 1 && (await P1.c.waitClose()) === 4002, 'kick online → {ok, n}, close 4002');

    console.log('== log');
    // вход в комнаты ограничен по частоте (2.0) — журнал наполняем действиями админа
    for (let i = 0; i < 320; i++) await adm.post('motd', { text: 'строка журнала ' + i });
    await adm.post('motd', { text: '' });
    await sleep(500);
    r = await adm.get('log');
    const lines = r.data.lines;
    check(Array.isArray(lines) && lines.length === 300 && lines.every(l => /^\d\d:\d\d:\d\d /.test(l)), 'log: last 300 lines "HH:MM:SS text"', lines && lines.length);
    check(lines.slice(-30).some(l => /admin motd/.test(l)), 'log has recent lines');
    const allText = srv.logs.join('\n');
    check(!allText.includes(ADMIN_PASS), 'admin password never logged');
    check(srv.logs.some(l => /admin login failed 10\.0\.0\.5/.test(l)) && srv.logs.some(l => /admin login 10\.0\.0\.6/.test(l)), 'admin logins logged with address');
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  await srv.stop();

  console.log('== admin.json with salt used as bytes');
  const d = tmpDir('hexsalt');
  const s2 = await startServer({ dataDir: d, env: { ADMIN_FILE: makeAdminFile(d, true) } });
  let r2 = await s2.http('POST', '/admin/api/login', { password: ADMIN_PASS }, { 'X-Forwarded-For': '10.1.1.1' });
  check(r2.status === 200 && r2.data.token, 'hex-decoded salt variant also accepted');
  await s2.stop();
  console.log('== missing admin.json');
  const s3 = await startServer({ env: { ADMIN_FILE: path.join(d, 'nope.json') } });
  r2 = await s3.http('POST', '/admin/api/login', { password: ADMIN_PASS });
  check(r2.status === 503 && r2.data.error, 'no admin.json → 503 with message', r2.data);
  await s3.stop();
  void fs;
  process.exit(summary('admin'));
})();
