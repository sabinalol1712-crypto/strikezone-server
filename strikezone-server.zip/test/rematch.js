// 1.6.1: после матча игроки остаются в комнате — оружие на земле (выбросить/подобрать) работает
// во 2-м, 3-м… матче, после технической победы и в обычных комнатах («Порт»). Радар и бомба не тянутся из прошлого матча.
// Запуск: PORT=8098 SZ_FAST=1 node server.js; PORT=8098 node test/rematch.js   (~3 минуты)
const URL = 'ws://localhost:' + (process.env.PORT || 8098) + '/ws';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let fail = 0; const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };
function client(name, key) {
  const ws = new WebSocket(URL), st = { ws, name, ev: [], errs: [], roster: null, snap: null, joined: null, dr: [] };
  ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', v: 1, cv: 200, key, name, prim: 'ar', skins: {}, knife: ['knife', null, 0], gloves: null, drops: 1 }));
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.t === 'welcome') st.welcome = m;
    else if (m.t === 'joined') { st.joined = m; st.code = m.code; st.you = m.you; }
    else if (m.t === 'roster') st.roster = m.list;
    else if (m.t === 'snap') { st.snap = m; if (m.dr) st.dr = m.dr; }
    else if (m.t === 'ev') for (const x of m.l) st.ev.push(x);
    else if (m.t === 'err') st.errs.push(m.m);
  };
  st.send = (o) => ws.send(JSON.stringify(o));
  st.ping = setInterval(() => { try { st.send({ t: 'ping', c: 0 }); } catch (e) { } }, 3000);
  st.close = () => { clearInterval(st.ping); ws.close(); };
  return new Promise(r => { const iv = setInterval(() => { if (st.welcome) { clearInterval(iv); r(st); } }, 20); });
}
const until = async (f, ms) => { for (let t = 0; t < ms; t += 50) { if (f()) return true; await sleep(50); } return !!f(); };
const evs = (c, type) => c.ev.filter(e => e[0] === type);
const st = (c, x, y, z, pt) => c.send({ t: 'st', p: [x, y, z], v: [0, 0, 0], yw: c.snap.me.yw, pt: pt || 0, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: c.slot || 'primary' });

// выбросить оружие из рук и сразу подобрать его обратно; true — сервер принял и то и другое
async function tossTake(c, tag) {
  if (!await until(() => c.snap && c.snap.me && c.snap.me.al && (c.snap.me.sl.primary || c.snap.me.sl.secondary), 8000)) return 'dead';
  const me = c.snap.me, slot = me.sl.primary ? 'primary' : 'secondary', wid = me.sl[slot][0];
  c.slot = slot;
  const before = new Set(c.dr.map(d => d[0]));
  c.send({ t: 'toss', s: slot });
  const tossed = await until(() => !c.snap.me.sl[slot] && c.dr.some(d => !before.has(d[0]) && d[1] === wid && d[8] === c.you), 1500);
  if (!tossed) return tag + ': toss refused (slot ' + JSON.stringify(c.snap.me.sl[slot]) + ', dr ' + c.dr.length + ')';
  const d = c.dr.find(d => !before.has(d[0]) && d[1] === wid);
  await sleep(300);
  st(c, d[4], d[5], d[6]);
  await sleep(150);
  const n0 = evs(c, 'dtake').length;
  c.send({ t: 'take', id: d[0] });
  const took = await until(() => evs(c, 'dtake').slice(n0).some(e => e[1] === c.you && e[2] === d[0]) && c.snap.me.sl[slot] && c.snap.me.sl[slot][0] === wid, 1500);
  if (!took) return tag + ': take refused';
  return true;
}
// 2.10: сервер больше не пускает «большой шаг после паузы» (запас пути ~6 м) — к сопернику идём по навигационной сетке
// шагами по 0,25 м (7 м/с), высоту берём с пола под ногами (лестницы, ступени)
let SIM = null;
async function walkNear(c, tx, tz, within) {
  if (!SIM) { const { createSim } = require('../sim/loader'); SIM = createSim().G; SIM.map.load('villa', null); SIM.nav.build(); }
  const me = c.snap.me; let x = me.x, y = me.y, z = me.z;
  const pts = (SIM.nav.findPath(x, z, tx, tz) || []).concat([{ x: tx, z: tz }]);
  for (const q of pts) {
    for (let n = 0; n < 400; n++) {
      if (Math.hypot(tx - x, tz - z) < within) return true;
      const dx = q.x - x, dz = q.z - z, d = Math.hypot(dx, dz);
      if (d < 0.05) break;
      const s = Math.min(0.25, d); x += dx / d * s; z += dz / d * s;
      const fy = SIM.drops.floorAt(x, y + 0.5, z); if (fy != null && fy >= 0) y = fy;
      st(c, x, y, z); await sleep(35);
    }
  }
  return Math.hypot(tx - x, tz - z) < within;
}
// выстрел в небо: шум, по которому соперники видят стрелка на радаре
function shootUp(c, still) {
  const me = c.snap && c.snap.me; if (!me || !me.al) return;
  const slot = me.sl.primary ? 'primary' : me.sl.secondary ? 'secondary' : null; if (!slot) return;
  c.slot = slot;
  if (!still) st(c, me.x, me.y, me.z, 1.4);
  const pt = 1.4, yw = me.yw;
  c.send({ t: 'shot', s: slot, w: me.sl[slot][0], o: [me.x, me.y + 1.6, me.z], d: [-Math.sin(yw) * Math.cos(pt), Math.sin(pt), -Math.cos(yw) * Math.cos(pt)], lag: 0 });
}

async function villa() {
  const A = await client('Анна', 'rakey000000001'), B = await client('Борис', 'rbkey00000001'), C = await client('Света', 'rckey00000001'), D = await client('Дима', 'rdkey00000001');
  ok('server >= 1.6.1', /^(1\.(6\.[1-9]|[7-9]\.)|[2-9]\.)/.test(A.welcome.srv), A.welcome.srv);
  A.send({ t: 'create', mode: 'bomb', map: 'villa', side: 'ct' });
  await until(() => A.code && A.snap, 3000);
  // разминка: оружие на земле работает и в ней
  ok('villa warm-up: toss + take', (await tossTake(A, 'warm')) === true);
  B.send({ t: 'join', code: A.code, side: 't' }); C.send({ t: 'join', code: A.code, side: 'ct' }); D.send({ t: 'join', code: A.code, side: 't' });
  const all = [A, B, C, D];
  await until(() => evs(A, 'mstart').some(e => e[1] === 'bomb'), 12000);
  ok('match 1 started (bomb)', evs(A, 'mstart').some(e => e[1] === 'bomb'));
  await until(() => A.snap.g.m === 'bomb' && A.snap.g.ph === 'live', 8000);
  ok('match 1 round 1: toss + take', (await tossTake(A, 'm1r1')) === true);
  // доигрываем до конца (SZ_FAST: до 2 побед, раунд 30 с); в последнем раунде — подбор и выстрелы (метки времени «из будущего»)
  let late = null;
  const t0 = Date.now();
  while (!evs(A, 'mend').length && Date.now() - t0 > -1 && Date.now() - t0 < 150000) {
    const g = A.snap.g;
    if (g.m === 'bomb' && g.ph === 'live' && g.r >= 2 && !late) late = await tossTake(B, 'm1late') === true ? 'ok' : 'bad';
    // A подходит к сопернику (ближе 32 м — радиус «слышно выстрел») и стреляет в небо — его видно на радаре
    if (g.m === 'bomb' && g.ph === 'live' && g.r >= 2 && g.t < 22 && A.snap.me.al) {
      const en = A.snap.a.find(r => r[10] !== A.snap.me.team && (r[6] & 1));
      if (en && A.nearR !== g.r) { A.nearR = g.r; await walkNear(A, en[1], en[3], 24); await sleep(150); }
      if (A.nearR === g.r) shootUp(A, true);
      const row = A.snap.a.find(r => r[0] === A.you);
      if (row && row[11] !== -2) A.sawSpotted = true;
    }
    await sleep(400);
  }
  ok('match 1 ended normally', evs(A, 'mend').length === 1 && !evs(A, 'mend')[0][3], JSON.stringify(evs(A, 'mend')));
  ok('match 1 late round: toss + take', late === 'ok', late);
  ok('match 1 late round: A was spotted on radar (shot next to an enemy)', !!A.sawSpotted);
  const tEnd = A.snap.s;
  // остались все четверо: разминка → отсчёт → матч 2
  A.ev.length = 0; B.ev.length = 0;
  await until(() => evs(A, 'mstart').some(e => e[1] === 'tdm' && e[3] === 1), 20000);
  ok('after match → warm-up (mstart tdm, warm)', evs(A, 'mstart').some(e => e[1] === 'tdm' && e[3] === 1));
  await until(() => A.snap.g.m === 'tdm' && A.snap.a.length === 4 && A.snap.a.every(r => r[6] & 1), 4000);
  ok('warm-up after match: nobody carries the bomb', A.snap.a.every(r => !(r[6] & 8)) && all.every(c => !c.snap.me.bomb), JSON.stringify(A.snap.a.map(r => r[6])));
  ok('warm-up after match: nobody spotted on radar', A.snap.a.every(r => r[11] === -2), JSON.stringify(A.snap.a.map(r => r[11])) + ' prev match t=' + tEnd);
  ok('warm-up after match: toss + take (B)', (await tossTake(B, 'warm2')) === true);
  await until(() => evs(A, 'mstart').some(e => e[1] === 'bomb'), 12000);
  ok('match 2 started', evs(A, 'mstart').some(e => e[1] === 'bomb'));
  await until(() => A.snap.g.m === 'bomb', 3000);
  ok('match 2: fresh state (round 1, 0:0, $800)', A.snap.g.r === 1 && A.snap.g.sc[0] === 0 && A.snap.g.sc[1] === 0 && all.every(c => c.snap.me.$ === 800 && c.snap.me.k === 0), JSON.stringify(A.snap.g.sc) + ' r' + A.snap.g.r);
  ok('match 2: nobody spotted at start', A.snap.a.every(r => r[11] === -2), JSON.stringify(A.snap.a.map(r => r[11])));
  ok('match 2: exactly one bomb carrier (T)', A.snap.a.filter(r => r[6] & 8).length === 1 && A.snap.a.filter(r => r[6] & 8).every(r => r[10] === 1));
  await until(() => A.snap.g.ph === 'live', 15000);   // 2.10.1: с запасом — под нагрузкой заморозка (а в ней шаг к оружию > 1,2 м сервер не пускает) могла не кончиться за 6 с
  ok('match 2 round 1: toss + take (A)', (await tossTake(A, 'm2a')) === true);
  ok('match 2 round 1: toss + take (B)', (await tossTake(B, 'm2b')) === true);
  // смена оружия в руках после матча снова доходит до сервера (curLock не тянется из прошлого матча)
  {
    const meB = B.snap.me, kn = meB.sl.melee[0];
    B.slot = 'melee';
    await until(() => { st(B, B.snap.me.x, B.snap.me.y, B.snap.me.z); const r = A.snap.a.find(r => r[0] === B.you); return r && r[7] === kn; }, 2500);
    const r = A.snap.a.find(r => r[0] === B.you);
    ok('match 2: weapon switch (knife) reaches server', r && r[7] === kn, r && r[7]);
    B.slot = 'primary';
  }
  // техническая победа → разминка → снова четверо → матч 3
  const tA = A.joined.team, byTeam = (t) => all.filter(c => (c.snap.me.team) === t);
  const gone = byTeam(1 - tA);
  for (const c of gone) c.send({ t: 'leave' });
  await until(() => evs(A, 'mend').some(e => e[3] === 1), 4000);
  ok('forfeit', evs(A, 'mend').some(e => e[3] === 1));
  A.ev.length = 0;
  await until(() => evs(A, 'mstart').some(e => e[3] === 1), 12000);
  ok('forfeit → warm-up', evs(A, 'mstart').some(e => e[1] === 'tdm' && e[3] === 1));
  ok('warm-up after forfeit: toss + take', (await tossTake(A, 'warm3')) === true);
  for (const c of gone) { c.ev.length = 0; c.send({ t: 'join', code: A.code }); }
  await until(() => evs(A, 'mstart').some(e => e[1] === 'bomb'), 12000);
  ok('match 3 started after rejoin', evs(A, 'mstart').some(e => e[1] === 'bomb'));
  await until(() => A.snap.g.m === 'bomb' && A.snap.g.ph === 'live', 8000);
  ok('match 3: toss + take (stayed)', (await tossTake(A, 'm3a')) === true);
  ok('match 3: toss + take (rejoined)', (await tossTake(gone[0], 'm3g')) === true);
  for (const c of all) c.close();
}

async function harbor() {
  // обычная комната с ботами: матч по времени (SZ_FAST — 60 с) → новый матч в той же комнате
  const H = await client('Хана', 'rhkey00000001');
  H.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 2, diff: 'easy' });
  await until(() => H.snap && H.snap.me && H.snap.me.al, 4000);
  ok('harbor match 1: toss + take', (await tossTake(H, 'h1')) === true);
  const t0 = Date.now(); let late = null;
  while (!evs(H, 'mend').length && Date.now() - t0 < 90000) {
    if (!late && H.snap.g.tl < 8 && H.snap.me.al) late = (await tossTake(H, 'h1late')) === true ? 'ok' : 'bad';
    await sleep(300);
  }
  ok('harbor match 1 ended', evs(H, 'mend').length === 1);
  if (late) ok('harbor match 1 late: toss + take', late === 'ok', late);
  H.ev.length = 0;
  await until(() => evs(H, 'mstart').length, 20000);
  ok('harbor match 2 started in the same room', evs(H, 'mstart').length >= 1 && evs(H, 'mstart')[0][1] === 'tdm');
  await until(() => H.snap.g.tl < 299 && H.snap.me.al, 6000);
  ok('harbor match 2: toss + take', (await tossTake(H, 'h2')) === true);
  H.close();
}

(async () => {
  await Promise.all([villa(), harbor()]);
  console.log(fail ? 'FAILED ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
