'use strict';
// 2.9: тренировка гранат — режим кастомного лобби 'nades': только игра 2.8+, карты с раскидками, без ботов и урона,
// телепорт на позицию раскидки (ptp), бесконечные гранаты, «убрать дым» (pclr → nclr), хост завершает тренировку (lobby_end)
const L = require('./lib');
const { check, summary, sleep } = L;
(async () => {
  const srv = await L.startServer({ env: { SZ_LOBBY_BACK_S: '3' } });
  const all = [];
  const mk = async (name, cv) => { const c = await L.client(srv.url, { name, cv: cv || 280 }); all.push(c); return c; };
  try {
    const A = await mk('Гранатомёт');
    const B = await mk('Напарник');
    const Old = await mk('Старичок', 270);
    // ---------- создание: режим и карта ----------
    let m0 = A.mark();
    A.send({ t: 'lobby_create', mode: 'nades', map: 'winter', size: 2, opts: { bots: 1, warm: 30 } });
    let st = await A.wait('lobby', null, 4000, m0);
    check(st && st.mode === 'duel', 'дуэльная карта — дуэль (тренировки на ней нет)', st && [st.mode, st.map]);
    m0 = A.mark();
    A.send({ t: 'lobby_set', mode: 'nades', map: 'harbor', size: 2, opts: { bots: 1, warm: 30 } });
    st = await A.wait('lobby', s => s.mode === 'nades', 4000, m0);
    check(st && st.mode === 'nades' && st.map === 'harbor', 'режим «гранаты» на «Гавани»', st && [st.mode, st.map]);
    check(st && st.opts.bots === 0 && st.opts.warm === 0, 'без ботов и разминки', st && st.opts);
    check(st && st.chat.some(e => e.sys && /Тренировка гранат/.test(e.m)), 'в чате лобби — «Тренировка гранат»');
    // ---------- старая игра не входит ----------
    m0 = Old.mark();
    Old.send({ t: 'lobby_join', code: st.code });
    const oe = await Old.wait('lobby_err', null, 3000, m0);
    check(oe && /2\.8/.test(oe.m), 'игра 2.7 получает понятную ошибку', oe);
    // ---------- в бомбе старый может быть, но тогда «гранаты» не включить ----------
    m0 = A.mark();
    A.send({ t: 'lobby_set', mode: 'bomb', map: 'harbor', size: 2 }); await A.wait('lobby', s => s.mode === 'bomb', 3000, m0);
    let mo = Old.mark();
    Old.send({ t: 'lobby_join', code: st.code }); await Old.wait('lobby', null, 3000, mo);
    m0 = A.mark();
    A.send({ t: 'lobby_set', mode: 'nades', map: 'harbor', size: 2 });
    const se = await A.wait('lobby_err', null, 3000, m0);
    check(se && /Старичок/.test(se.m) && /2\.8/.test(se.m), 'хост видит, у кого старая игра', se);
    mo = Old.mark(); Old.send({ t: 'lobby_leave' }); await Old.wait('lobby_left', null, 3000, mo);
    m0 = A.mark();
    A.send({ t: 'lobby_set', mode: 'nades', map: 'sakura', size: 2 });
    st = await A.wait('lobby', s => s.mode === 'nades', 3000, m0);
    check(st && st.map === 'sakura', 'после ухода старой игры — «гранаты» на «Сакуре»', st && [st.mode, st.map]);
    // ---------- старт с одним игроком (вторая команда пустая — можно) ----------
    let mb = B.mark();
    B.send({ t: 'lobby_join', code: st.code }); await B.wait('lobby', null, 3000, mb);
    B.send({ t: 'lobby_slot', side: 'ct' }); await sleep(200);   // оба в одной команде, налётчиков нет
    m0 = A.mark(); mb = B.mark();
    A.send({ t: 'lobby_start' });
    const ja = await A.wait('joined', null, 6000, m0), jb = await B.wait('joined', null, 6000, mb);
    check(ja && ja.mode === 'nades' && ja.map === 'sakura' && ja.lobby, 'матч лобби в режиме тренировки', ja && [ja.mode, ja.map, ja.lobby]);
    check(jb && jb.mode === 'nades', 'второй игрок тоже в тренировке', jb && jb.mode);
    let t0 = Date.now(); while (!(A.snap && A.snap.me && A.snap.me.al) && Date.now() - t0 < 6000) await sleep(50);
    const me = A.snap && A.snap.me;
    check(me && me.al === 1, 'игрок жив');
    check(me && me.n[0] >= 1 && me.n[1] >= 1 && me.n[2] >= 1, 'все гранаты в руках', me && me.n);
    const nAct = (A.snap.a || []).length;
    check(nAct === 2, 'ботов нет — в матче только двое', nAct);
    // ---------- телепорт ----------
    const tp0 = me.tp;
    // точка на «Сакуре» на земле, подальше от игрока
    const tx = me.x > 0 ? me.x - 6 : me.x + 6, tz = me.z;
    A.send({ t: 'ptp', p: [tx, 0, tz], yw: 1.25, pt: 0.3 });
    // следом — обычные снимки с новой позиции (как телефон после телепорта)
    for (let i = 0; i < 6; i++) { A.send({ t: 'st', p: [tx, 0, tz], v: [0, 0, 0], yw: 1.25, pt: 0.3, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: 'primary', nc: 0 }); await sleep(60); }
    await sleep(250);
    check(Math.abs(A.snap.me.x - tx) < 0.05 && Math.abs(A.snap.me.z - tz) < 0.05, 'сервер принял телепорт (позиция совпала)', [A.snap.me.x, A.snap.me.z, tx, tz]);
    check(A.snap.me.tp === tp0, 'сервер не возвращает игрока назад', [A.snap.me.tp, tp0]);
    // в стену нельзя
    const sx = A.snap.me.x, sz = A.snap.me.z;
    A.send({ t: 'ptp', p: [9999, 0, 9999], yw: 0, pt: 0 }); await sleep(250);
    check(Math.abs(A.snap.me.x - sx) < 0.3 && Math.abs(A.snap.me.z - sz) < 0.3, 'телепорт за карту — отклонён', [A.snap.me.x, A.snap.me.z]);
    // ---------- полёт (noclip) разрешён всем в тренировке ----------
    for (let i = 1; i <= 8; i++) { A.send({ t: 'st', p: [sx, i * 1.2, sz], v: [0, 0, 0], yw: 0, pt: 0, cr: 0, ct: 0, og: 0, sc: 0, u: 0, cur: 'primary', nc: 1 }); await sleep(70); }
    await sleep(200);
    check(A.snap.me.y > 8 && A.snap.me.tp === tp0, 'полёт выше 8 м принят', [A.snap.me.y, A.snap.me.tp]);
    for (let i = 7; i >= 0; i--) { A.send({ t: 'st', p: [sx, i * 1.2, sz], v: [0, 0, 0], yw: 0, pt: 0, cr: 0, ct: 0, og: i ? 0 : 1, sc: 0, u: 0, cur: 'primary', nc: i ? 1 : 0 }); await sleep(70); }
    // ---------- бесконечные гранаты ----------
    let mk1 = B.mark();
    const n0 = A.snap.me.n.slice();
    A.send({ t: 'nade', type: 'smoke', o: [sx, 1.5, sz], v: [3, 6, 0] });
    const nv = await B.waitEv('nade', e => e[3] === 'smoke', 2000, mk1);
    check(!!nv, 'дым брошен (видят все)');
    await sleep(300);
    check(A.snap.me.n[2] === n0[2], 'дым снова в руках (бесконечные гранаты)', [n0, A.snap.me.n]);
    A.send({ t: 'nade', type: 'he', o: [sx, 1.5, sz], v: [0, 2, 0] });   // HE под ноги — урона нет
    await sleep(2400);
    check(A.snap.me.hp === 100 && A.snap.me.al === 1, 'HE под ноги — без урона', [A.snap.me.hp, A.snap.me.al]);
    // ---------- убрать дым ----------
    mk1 = B.mark();
    A.send({ t: 'pclr' });
    const cl = await B.waitEv('nclr', e => e[1] === ja.you, 2000, mk1);
    check(!!cl, 'все получили «дым убран» (nclr)', cl);
    mk1 = B.mark();
    A.send({ t: 'pclr' }); await sleep(300);
    check(!B.evs(mk1).some(e => e[0] === 'nclr'), 'не чаще раза в 0,8 с');
    // ---------- в обычном матче этих команд нет ----------
    // (проверяется ниже по lobby_end: не-хост не может, хост — завершает)
    mb = B.mark();
    B.send({ t: 'lobby_end' });
    const ne = await B.wait('lobby_err', null, 2000, mb);
    check(ne && /хост/i.test(ne.m), 'завершить может только хост', ne);
    m0 = A.mark(); mb = B.mark();
    A.send({ t: 'lobby_end' });
    const back = await A.wait('lobby', s => s.back === 1, 4000, m0), backB = await B.wait('lobby', s => s.back === 1, 4000, mb);
    check(back && back.st === 'idle' && backB, 'хост завершил — все снова в лобби', back && back.st);
    check(back && back.chat.some(e => e.sys && /завершил тренировку/.test(e.m)), 'в чате — кто завершил');
    // мусор
    for (const m of [{ t: 'ptp' }, { t: 'ptp', p: 'x' }, { t: 'ptp', p: [1, 2] }, { t: 'pclr', x: {} }, { t: 'lobby_end', code: 5 }]) A.send(m);
    await sleep(200);
    check(A.ws.readyState === 1, 'сервер жив после мусора');
    // ---------- обычный матч: телепорт не работает ----------
    const C = await mk('Обычный');
    C.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 2, side: 'ct' });
    const jc = await C.wait('joined', null, 5000);
    t0 = Date.now(); while (!(C.snap && C.snap.me && C.snap.me.al) && Date.now() - t0 < 6000) await sleep(50);
    const cx = C.snap.me.x, cz = C.snap.me.z;
    C.send({ t: 'ptp', p: [cx + 8, 0, cz], yw: 0, pt: 0 }); await sleep(300);
    check(jc && Math.abs(C.snap.me.x - cx) < 0.5, 'в обычном матче телепорта нет', [C.snap.me.x, cx]);
    const cmk = C.mark(); C.send({ t: 'pclr' }); await sleep(300);
    check(!C.evs(cmk).some(e => e[0] === 'nclr'), 'и «убрать дым» тоже');
  } finally { for (const c of all) try { c.close(); } catch (e) { } srv.stop(); }
  process.exit(summary('nades29'));
})().catch(e => { console.error(e); process.exit(1); });
