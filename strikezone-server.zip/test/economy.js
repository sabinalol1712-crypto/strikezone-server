'use strict';
// 2.3: облачный инвентарь (PROTOCOL4 §2): перенос с ограничениями, кейсы на сервере, пропуск, оперативники, промокоды,
// подарки и награды за ранги в облачные монеты; сохранение; через настоящий сервер — версии, гости, два устройства, перезапуск.
const fs = require('fs');
const path = require('path');
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');
const { bench, fixtureDir } = require('./ecofix');
const A = require('../lib/accounts');

(async () => {
  // 2.10.1: пропуск выключен в игре (G.BP_OFF) — выключен и на сервере; логику пропуска проверяем с SZ_BP=1
  {
    delete process.env.SZ_BP;
    const off = require('../lib/gamedata').loadGameData();
    check(off.ok.bp === false && off.bp === null, 'battle pass is off on the server while the game has it off (no free premium rewards)', off.ok);
    process.env.SZ_BP = '1';
  }
  console.log('== gamedata: data modules load headlessly, crypto RNG, stubs tolerated');
  const B = bench();
  const gd = B.gd;
  check(gd.ok.skins && gd.ok.cases && gd.ok.bp && gd.ok.ops && gd.ok.promo && !gd.errors.length, 'fixture: skins, cases, bp, operatives and promo codes loaded', [gd.ok, gd.errors]);
  {
    const { loadGameData } = require('../lib/gamedata');
    const real = loadGameData();   // game/ из репозитория: opsdata/promodata — заглушки 2.3
    check(real.ok.skins && real.ok.cases && real.ok.bp && real.opsReal === true && real.ok.promo === true, 'repo game/: real data modules (cases, BP, operatives, promo codes) loaded', real.ok);
    const n = {}; for (let i = 0; i < 3000; i++) { const s = real.rollCase(real.CASES[0].id); n[s] = 1; }
    check(Object.keys(n).every(s => real.CASES[0].items.includes(s)) && Object.keys(n).length > 8, 'rollCase via crypto RNG returns items of that case', Object.keys(n).length);
    const ws = [0, 0, 0]; for (let i = 0; i < 3000; i++) ws[real.rollWear()]++;
    check(ws.every(x => x > 300), 'rollWear 0..2', ws);
  }

  console.log('== guards: account, version, migration first');
  const g = B.user('Гость'); g.acc = null;
  check(B.ask(g, { t: 'inv_get' }).code === 'auth', 'no account → inv_err auth');
  const old = B.user('Старый', 220);
  check(B.ask(old, { t: 'inv_get' }).code === 'version' && B.ask(old, { t: 'mk_search', q: {} }).code === 'version', 'cv 220 → inv_err version (inventory and market)');
  const a = B.user('Аня');
  let r = B.ask(a, { t: 'inv_get' });
  check(r.t === 'inv' && r.inv === null && r.need === 'migrate' && r.mkcfg && r.mkcfg.fee === 10, 'no cloud inventory → {inv:null, need:"migrate"} (+ mkcfg)', r);
  r = B.ask(a, { t: 'case_open', id: 'prodigy' });
  check(r.t === 'inv_err' && r.code === 'migrate' && r.need === 'migrate', 'actions before migration → inv_err migrate', r);
  check(B.ask(a, { t: 'mk_sell', uid: 'x', price: 10 }).code === 'migrate', 'market before migration → inv_err migrate');

  console.log('== migration: validation and caps');
  const items = [{ s: 'ar_flame', w: 1 }, { s: 'nope', w: 0 }, { s: 'm9_gold', w: 7 }, 'junk', { s: '__proto__' }, { s: 'smg_koi', w: 0 }];
  for (let i = 0; i < 500; i++) items.push({ s: i % 2 ? 'pistol_rust' : 'ar_desert', w: i % 3 });
  r = B.ask(a, { t: 'inv_migrate', inv: { coins: 99999, items, tokens: { harbor: 30, prodigy: 3, gloves: 2, zzz: 4, __proto__: 5 }, ops: ['ct_rare1', 't_arc1', 'ct_elite', 'nope', 'ct_assault'], bp: { season: 's1', prem: true, got: ['f1', 'p3', 'x9', 'f999', 'f1'] } } });
  const inv0 = r.inv;
  check(r.t === 'inv' && r.ok === 'inv_migrate' && inv0.mig === 1 && r.rev >= 1, 'inv_migrate → inv with ok', r.ok);
  check(inv0.coins === 5000 && inv0.bonus === 5000, 'coins capped at 5000, all of them bonus (not for the market)', [inv0.coins, inv0.bonus]);
  check(inv0.items.length === 400 && inv0.items.every(x => x.t === 0 && x.src === 'legacy' && typeof x.uid === 'string') && new Set(inv0.items.map(x => x.uid)).size === 400, 'items capped at 400, all t:0 src legacy, unique uids', inv0.items.length);
  check(inv0.items.some(x => x.s === 'ar_flame' && x.w === 1) && inv0.items.some(x => x.s === 'm9_gold' && x.w === 2) && inv0.items.some(x => x.s === 'smg_koi') && !inv0.items.some(x => x.s === 'nope'), 'over the cap the most valuable are kept (knife, legendary, BP skin); unknown ids dropped; wear clamped');
  const expT = {}; for (const [k, n] of [['harbor', 30], ['prodigy', 3], ['gloves', 2]]) { const cs = gd.caseOf(k); if (cs) expT[cs.id] = Math.min(20, (expT[cs.id] || 0) + n); }
  check(inv0.tokens.prodigy === 20 && JSON.stringify(inv0.tokens) === JSON.stringify(expT) && !inv0.tokens.zzz && !inv0.tokens.harbor, 'tokens: removed case → current one, ≤ 20 per case, unknown dropped', [inv0.tokens, expT]);
  check(inv0.ops.join() === 'ct_rare1,ct_elite', 'operatives: paid ones up to 3000 coins of value, BP elite with premium, free/unknown not stored', inv0.ops);
  check(inv0.bp.season === 's1' && inv0.bp.prem === true && inv0.bp.got.join() === 'f1,p3', 'battle pass: premium + claimed keys validated', inv0.bp);
  r = B.ask(a, { t: 'inv_migrate', inv: { coins: 5000 } });
  check(r.ok === 'inv_migrate' && r.already === 1 && r.inv.coins === 5000 && r.inv.items.length === 400, 'second migration does nothing (already: 1)');
  const a2 = B.user('Боря');
  r = B.ask(a2, { t: 'inv_migrate', inv: { coins: -5, items: 'x', tokens: [1], ops: {}, bp: { season: 's0', prem: true, got: ['f1'] } } });
  check(r.inv.coins === 0 && !r.inv.items.length && !Object.keys(r.inv.tokens).length && !r.inv.ops.length && r.inv.bp.prem === false && !r.inv.bp.got.length, 'garbage → empty inventory; old season BP ignored', r.inv);
  // доставленные на телефон подарки не режутся лимитом
  const don = B.user('Донатер');
  don.acc.giftSum = 3000; don.acc.gifts = [{ id: 'g1', coins: 500, m: 'x', at: 0 }]; don.acc.rewards = [0, 1, 2]; don.acc.rpend = [2];
  r = B.ask(don, { t: 'inv_migrate', inv: { coins: 9000 } });
  check(r.inv.coins === 5000 + 2500 + 20 + 25 && r.inv.bonus === 5000, 'cap = 5000 + gifts and rank rewards already delivered to the phone; those are clean, the rest bonus', [r.inv.coins, r.inv.bonus]);

  console.log('== cases: price, token, crypto roll, t:1 only for clean coins');
  const c0 = B.user('Кейсы');
  B.ask(c0, { t: 'inv_migrate', inv: { coins: 250, tokens: { prodigy: 1 } } });
  r = B.ask(c0, { t: 'case_open', id: 'prodigy' });
  check(r.ok === 'case_open' && r.got && r.got.t === 0 && r.got.src === 'case' && gd.CASES[0].items.includes(r.got.s) && r.inv.coins === 150 && r.inv.bonus === 150 && r.inv.items[0].uid === r.got.uid, 'case_open with bonus coins: −100 (bonus first), item src case but t:0', [r.got, r.inv.coins, r.inv.bonus]);
  r = B.ask(c0, { t: 'case_open', id: 'harbor', token: true });
  check(r.ok === 'case_open' && r.got.t === 0 && r.inv.coins === 150 && !r.inv.tokens.prodigy && r.case === 'prodigy', 'token open (removed case id remapped): coins untouched, token used, item t:0', r.inv.tokens);
  B.tick(3000);
  B.eco.credit(c0.acc.id, 1000, 'gift');
  r = B.ask(c0, { t: 'case_open', id: 'prodigy' }); B.tick(600);
  const r2 = B.ask(c0, { t: 'case_open', id: 'prodigy' }); B.tick(600);
  check(r.got.t === 0 && r2.got.t === 0 && r2.inv.bonus === 0 && r2.inv.coins === 950, 'bonus coins are spent first (100 + 50 bonus → both items t:0)', [r.inv.bonus, r2.inv.bonus, r2.inv.coins]);
  r = B.ask(c0, { t: 'case_open', id: 'prodigy' }); B.tick(600);
  check(r.got.t === 1 && r.inv.coins === 850, 'case paid with clean coins (gift) → tradable item t:1', r.got);
  B.inv(c0).coins = 150; B.eco.burn(700);
  r = B.ask(c0, { t: 'case_open', id: 'prodigy', token: true });
  check(r.code === 'token', 'no token left → inv_err token');
  B.tick(3000);
  r = B.ask(c0, { t: 'case_open', id: 'arsenal' }); B.tick(600);
  r = B.ask(c0, { t: 'case_open', id: 'arsenal' });
  check(r.code === 'coins' && r.need === 50, 'not enough coins → inv_err coins with need', r);
  check(B.ask(c0, { t: 'case_open', id: 'nope' }).code === 'case', 'unknown case → inv_err case');
  B.tick(3000);
  const c1 = B.user('Спам'); B.ask(c1, { t: 'inv_migrate', inv: { coins: 5000 } });
  B.autoTick = 0;
  let rate = 0; for (let i = 0; i < 6; i++) if (B.ask(c1, { t: 'case_open', id: 'prodigy' }).code === 'rate') rate++;
  B.autoTick = 210;
  check(rate === 2 && B.inv(c1).coins === 4600, 'case rate limit: 4 per 2 s', [rate, B.inv(c1).coins]);
  {
    // распределение: сервер крутит тем же G.rollCase, что и игра
    const tb = bench({ gd });
    let gold = 0, n = 0;
    for (let k = 0; k < 4; k++) {
      const u = tb.user('Стат' + k); tb.ask(u, { t: 'inv_migrate', inv: { coins: 0 } });
      const inv = tb.inv(u); inv.coins = 1e5; tb.eco.mint(1e5);
      for (let i = 0; i < 750; i++) { tb.tick(600); const x = tb.ask(u, { t: 'case_open', id: 'arsenal' }); if (x.got) { n++; if (gd.isGold(x.got.s)) gold++; } }
    }
    check(n === 3000 && gold > 10 && gold < 75, '3000 server opens: knives/gloves ≈ 1.2 % (' + gold + ')', [n, gold]);
    check(tb.invariants().ok, 'coins/items accounting holds after 3000 opens');
  }

  console.log('== battle pass');
  const p = B.user('Пропуск');
  B.ask(p, { t: 'inv_migrate', inv: { coins: 800 } });
  check(B.ask(p, { t: 'bp_claim', key: 'p5' }).code === 'prem', 'premium key without premium → inv_err prem');
  r = B.ask(p, { t: 'bp_buy' });
  check(r.ok === 'bp_buy' && r.inv.bp.prem === true && r.inv.coins === 50 && r.inv.bonus === 50, 'bp_buy: −750 (bonus first), prem', [r.inv.coins, r.inv.bonus]);
  check(B.ask(p, { t: 'bp_buy' }).code === 'owned', 'second bp_buy → owned');
  r = B.ask(p, { t: 'bp_claim', key: 'f10' });
  check(r.ok === 'bp_claim' && r.key === 'f10' && r.got && r.got.s === 'galil_desert' && r.got.t === 0 && r.got.src === 'bp' && r.inv.bp.got.includes('f10'), 'f10: skin galil_desert t:0 src bp', r.got);
  r = B.ask(p, { t: 'bp_claim', key: 'p50' }); B.tick(300);
  check(r.ok === 'bp_claim' && Object.values(r.inv.tokens).reduce((x, y) => x + y, 0) === 1, 'p50: case token', r.inv.tokens);
  r = B.ask(p, { t: 'bp_claim', key: 'p30' }); B.tick(300);
  check(r.ok === 'bp_claim' && r.inv.ops.includes('ct_elite'), 'p30: elite operative → ops', r.inv.ops);
  r = B.ask(p, { t: 'bp_claim', key: 'f1' }); B.tick(300);
  check(r.ok === 'bp_claim' && r.inv.coins === 70 && r.inv.bonus === 70, 'f1: +20 coins (bonus)', [r.inv.coins, r.inv.bonus]);
  check(B.ask(p, { t: 'bp_claim', key: 'f1' }).code === 'got', 'claimed twice → inv_err got');
  check(B.ask(p, { t: 'bp_claim', key: 'f0' }).code === 'key' && B.ask(p, { t: 'bp_claim', key: 'f76' }).code === 'key' && B.ask(p, { t: 'bp_claim', key: 'q1' }).code === 'key' && B.ask(p, { t: 'bp_claim', key: { x: 1 } }).code === 'key', 'bad keys → inv_err key');
  B.tick(300); B.ask(p, { t: 'bp_claim', key: 'f2' }); B.tick(300);
  r = B.ask(p, { t: 'bp_claim', key: 'f3' }); B.tick(300);
  const r7 = B.ask(p, { t: 'bp_claim', key: 'f4' });
  check(r.ok === 'bp_claim' && r7.code === 'rate', 'claim cap: 6 per minute → inv_err rate', [r.ok, r7.code]);
  B.tick(61000);
  check(B.ask(p, { t: 'bp_claim', key: 'f4' }).ok === 'bp_claim', 'after a minute claims work again');
  // новый сезон: премиум и полученные награды сбрасываются
  B.inv(p).bp.season = 's0';
  r = B.ask(p, { t: 'bp_claim', key: 'f1' });
  check(r.ok === 'bp_claim' && r.inv.bp.season === 's1' && r.inv.bp.prem === false && r.inv.bp.got.join() === 'f1', 'another season stored → reset (prem false, got cleared)', r.inv.bp);

  console.log('== operatives');
  const o = B.user('Опер');
  B.ask(o, { t: 'inv_migrate', inv: { coins: 2000 } });
  r = B.ask(o, { t: 'op_buy', id: 'ct_rare1' });
  check(r.ok === 'op_buy' && r.id === 'ct_rare1' && r.inv.coins === 1700 && r.inv.ops.includes('ct_rare1'), 'op_buy: −price, owned', r.inv);
  check(B.ask(o, { t: 'op_buy', id: 'ct_rare1' }).code === 'owned', 'owned → inv_err owned');
  check(B.ask(o, { t: 'op_buy', id: 'ct_elite' }).code === 'lock', 'BP elite → inv_err lock');
  check(B.ask(o, { t: 'op_buy', id: 't_arc1' }).code === 'coins', 'too expensive → inv_err coins');
  check(B.ask(o, { t: 'op_buy', id: 'nope' }).code === 'op', 'unknown → inv_err op');
  r = B.ask(o, { t: 'op_buy', id: 'ct_assault' });
  check(r.ok === 'op_buy' && r.free === 1 && r.inv.coins === 1700, 'free operative → ok, nothing charged');
  {
    const { loadGameData } = require('../lib/gamedata');
    const tb = bench({ gd: loadGameData() }); const u = tb.user('Заглушка'); tb.ask(u, { t: 'inv_migrate', inv: { coins: 100 } });
    const x = tb.ask(u, { t: 'op_buy', id: 'ct_rare1' }); tb.tick(2000);
    const y = tb.ask(u, { t: 'promo', code: 'TESTCOINS' });
    check(x.code === 'op' && y.code === 'code', 'repo data: unknown operative / unknown promo code → clear inv_err', [x, y]); // 2.3: в game/ теперь настоящие данные, а не заглушки
  }

  console.log('== promo codes');
  const pr = B.user('Промо');
  B.ask(pr, { t: 'inv_migrate', inv: { coins: 100 } });
  r = B.ask(pr, { t: 'promo', code: ' test-coins ' });
  check(r.ok === 'promo' && r.title === 'TEST: 1500 монет' && r.inv.coins === 1600 && r.inv.bonus === 1600 && /^\+1\s500 монет$/.test(r.lines.join()), 'normalized code works once: +1500 bonus coins, title', [r.title, r.lines, r.inv.bonus]);
  check(B.ask(pr, { t: 'promo', code: 'TESTCOINS' }).code === 'used', 'second time on the same account → used');
  check(B.ask(pr, { t: 'promo', code: 'NOPE' }).code === 'code', 'unknown → inv_err code');
  r = B.ask(pr, { t: 'promo', code: 'TESTCASE' });
  check(r.ok === 'promo' && r.items.length === 1 && r.items[0].t === 0 && r.items[0].src === 'promo' && r.inv.tokens.prodigy === 2, 'cases → rolled item t:0 src promo; removed-case tokens → current case', [r.items, r.inv.tokens]);
  r = B.ask(pr, { t: 'promo', code: 'TESTKNIFE' });
  check(r.ok === 'promo' && r.items.length === 1 && gd.isKnife(r.items[0].s) && r.items[0].t === 0, 'random knife t:0', r.items);
  r = B.ask(pr, { t: 'promo', code: 'TESTOPS' });
  check(r.ok === 'promo' && r.inv.ops.includes('ct_rare1'), 'operative code', r.inv.ops);
  r = B.ask(pr, { t: 'promo', code: 'TESTOWNER' });
  check(r.code === 'owner', 'owner code refused for a normal account', r);
  for (let i = 0; i < 4; i++) B.ask(pr, { t: 'promo', code: 'BRUTE' + i });
  check(B.ask(pr, { t: 'promo', code: 'TESTCOINS' }).code === 'rate', 'promo tries: 8 per 10 minutes');
  const own = B.user('Владелец'); own.acc.num = 1;
  B.ask(own, { t: 'inv_migrate', inv: { coins: 10 } });
  r = B.ask(own, { t: 'promo', code: 'TESTOWNER' });
  const nsk = Object.keys(gd.SKINS).length;
  check(r.ok === 'promo' && r.inv.coins === 1000000 && r.inv.items.length === nsk && r.inv.items.every(x => x.t === 0) && r.inv.ops.includes('t_arc1') && r.inv.ops.includes('ct_elite'), 'owner (№1): every skin (t:0), all operatives, coins up to 1 000 000', [r.inv.coins, r.inv.items.length]);
  // тест сам «тратит» монеты и убирает предмет — с учётом в счётчиках, чтобы инвариант оставался верным
  B.eco.burn(B.inv(own).coins - 5); B.inv(own).coins = 5; B.inv(own).bonus = 5; B.inv(own).items.pop(); B.eco.data.stat.made--;
  B.tick(2000);
  r = B.ask(own, { t: 'promo', code: 'TESTOWNER' });
  check(r.ok === 'promo' && r.inv.coins === 1000000 && r.inv.items.length === nsk, 'owner code again: tops up items and coins (unlimited)');
  const dev = B.user('Разраб'); dev.acc.medals.push('dev'); B.ask(dev, { t: 'inv_migrate', inv: {} });
  check(B.ask(dev, { t: 'promo', code: 'TESTOWNER' }).ok === 'promo', 'medal «Разработчик» may use owner codes');

  console.log('== credit (gifts / rank rewards) and pushes to other devices');
  const d1 = B.user('Два'), d2 = B.device(d1), d22 = B.device(d1, 220);
  B.ask(d1, { t: 'inv_migrate', inv: { coins: 10 } });
  check(d2.out.some(x => x.t === 'inv' && x.why === 'inv_migrate') && !d22.out.some(x => x.t === 'inv'), 'other 2.3 device gets inv (why), 2.2 device nothing');
  const k2 = d2.out.length;
  check(B.eco.credit(d1.acc.id, 1000, 'gift') && B.inv(d1).coins === 1010 && B.inv(d1).bonus === 10, 'credit → cloud coins (clean, bonus unchanged)');
  check(d2.out.slice(k2).some(x => x.t === 'inv' && x.why === 'gift' && x.inv.coins === 1010), 'every 2.3 device gets inv why:gift');
  check(!B.eco.credit(B.user('Без облака').acc.id, 50, 'gift'), 'no cloud inventory → credit refused (old flow)');
  check(B.invariants().ok, 'accounting invariant (minted − burned = coins on hand)', B.invariants());

  console.log('== persistence: data/eco.json round trip, trades.log');
  const B2 = await B.reload();
  const same = Object.keys(B.eco.data.inv).every(id => JSON.stringify(B.eco.proj(B.eco.get(id), id)) === JSON.stringify(B2.eco.proj(B2.eco.get(id), id)) && B.eco.get(id).rev === B2.eco.get(id).rev);
  check(same && Object.keys(B2.eco.data.inv).length === Object.keys(B.eco.data.inv).length, 'every inventory identical after reload (coins, items, uids, tokens, ops, bp, rev)');
  check(JSON.stringify(B2.eco.data.stat) === JSON.stringify(B.eco.data.stat) && B2.eco.data.seq === B.eco.data.seq, 'counters survive (uid sequence, minted/burned)');
  {
    // кейс убрали из игры: его бесплатные открытия после перезапуска — у замены (CASE_REMAP) или у первого кейса
    const tk = B2.user('Токены'); B2.ask(tk, { t: 'inv_migrate', inv: {} });
    B2.inv(tk).tokens.harbor = 2; B2.inv(tk).tokens.oldgone = 1; B2.inv(tk).tokens.prodigy = 1;
    const B3 = await B2.reload();
    const t3 = B3.eco.get(tk.acc.id).tokens;
    check(t3.prodigy === 4 && !t3.harbor && !t3.oldgone, 'tokens of removed cases are moved to current cases on startup', t3);
  }
  await B.eco.close(); await sleep(50);
  const tl = fs.readFileSync(path.join(B.dir, 'trades.log'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
  check(tl.some(x => x.op === 'migrate') && tl.some(x => x.op === 'case') && tl.some(x => x.op === 'bp_claim') && tl.some(x => x.op === 'promo') && tl.some(x => x.op === 'credit') && tl.every(x => x.ts > 0), 'trades.log: one JSON line per operation', tl.length);

  // ================= через настоящий сервер =================
  console.log('== server: versions, guests, migration, case, gifts with cloud:1, two devices, restart');
  let srv = await startServer({ env: { SZ_GAMEDATA_DIR: fixtureDir() } });
  try {
    const adm = await adminSession(srv);
    const guest = await client(srv.url, { name: 'Гость', cv: 230 });
    guest.send({ t: 'inv_get' });
    check((await guest.wait('inv_err'))?.code === 'auth', 'guest → inv_err auth');
    guest.close();
    const acc = newAcc('Облако');
    const old = await client(srv.url, { name: 'Облако', acc, cv: 220 });
    await old.wait('me');
    old.send({ t: 'inv_get' });
    check((await old.wait('inv_err'))?.code === 'version', '2.2 game (cv 220) → inv_err version');
    // подарок до переноса: игре 2.2 — как раньше; игре 2.3 — ждёт переноса
    let res = await adm.post('gift', { num: acc.num, coins: 300 });
    const og = await old.wait('gift');
    check(res.data.ok && og && og.coins === 300 && !og.cloud, 'before migration a 2.2 game gets the gift the old way', og);
    old.send({ t: 'gift_ok', id: og.id }); await sleep(100);
    old.close(); await sleep(200);
    res = await adm.post('gift', { num: acc.num, coins: 700 });
    const c = await client(srv.url, { name: 'Облако', acc, cv: 230, key: 'kdev1' + rnd(10) });
    await c.wait('me'); await sleep(300);
    check(!c.all('gift').length, '2.3 game without cloud inventory: the pending gift waits for the migration');
    c.send({ t: 'inv_get' });
    const need = await c.wait('inv');
    check(need && need.inv === null && need.need === 'migrate', 'inv_get → need migrate');
    const mk = c.mark();
    c.send({ t: 'inv_migrate', inv: { coins: 6000, items: [{ s: 'ar_flame', w: 0 }], tokens: { prodigy: 1 }, ops: [], bp: {} } });
    const mig = await c.wait('inv', x => x.ok === 'inv_migrate', 3000, mk);
    check(mig && mig.inv.coins === 5300, 'migration cap 5000 + the 300 already delivered to the 2.2 phone', mig && mig.inv.coins);
    const late = await c.wait('gift', x => x.cloud === 1, 3000, mk);
    const after = await c.wait('inv', x => x.why === 'gift', 3000, mk);
    check(late && late.coins === 700 && after && after.inv.coins === 6000, 'the gift that waited is credited to the cloud on migration and announced with cloud:1', [late, after && after.inv.coins]);
    c.send({ t: 'gift_ok', id: late.id });
    // крупный перенос (2600 предметов ≈ 78 КБ одним сообщением)
    {
      const big = await client(srv.url, { name: 'Склад', acc: newAcc('Склад' + rnd(3)), cv: 230 });
      await big.wait('me');
      const many = []; for (let i = 0; i < 2600; i++) many.push({ s: i % 3 ? 'pistol_goldcarbon' : 'm4s_blackgold', w: i % 3 });
      const raw = JSON.stringify({ t: 'inv_migrate', inv: { coins: 100, items: many } });
      const mk2 = big.mark();
      big.send(JSON.parse(raw));
      const bm = await big.wait('inv', x => x.ok === 'inv_migrate', 5000, mk2);
      check(raw.length > 64 * 1024 && bm && bm.inv.items.length === 400 && big.closed == null, 'a ' + Math.round(raw.length / 1024) + ' KB migration message is accepted (400 kept)', bm && bm.inv.items.length);
      big.close();
    }
    // второе устройство 2.3 и старая игра на том же аккаунте
    const c2 = await client(srv.url, { name: 'Облако', acc, cv: 230, key: 'kdev2' + rnd(10) });
    await c2.wait('me');
    const old2 = await client(srv.url, { name: 'Облако', acc, cv: 220, key: 'kdev3' + rnd(10) });
    await old2.wait('me'); await sleep(200);
    const m1 = c.mark(), m2 = c2.mark(), m3 = old2.mark();
    res = await adm.post('gift', { num: acc.num, coins: 1000 });
    const cg = await c.waitAny(['gift'], 2000, m1) || await c2.waitAny(['gift'], 1000, m2);
    const ci = await c2.wait('inv', x => x.why === 'gift', 2000, m2);
    await sleep(300);
    check(cg && cg.cloud === 1 && cg.coins === 1000 && ci && ci.inv.coins === 7000, 'admin gift → cloud coins at once (inv why:gift on every 2.3 device) + toast with cloud:1', [cg, ci && ci.inv.coins]);
    check(!old2.msgs.slice(m3).some(x => x.t === 'gift'), 'the 2.2 game on a cloud account does not get coin gifts');
    const pl = await adm.get('player?num=' + acc.num);
    check(pl.data.cloud && pl.data.cloud.coins === 7000 && pl.data.gifts === 2000, 'admin player shows cloud coins and total gifted', pl.data.cloud);
    // кейс с сервера; второе устройство видит изменения
    const k1 = c.mark(), k2 = c2.mark();
    c.send({ t: 'case_open', id: 'prodigy' });
    const op = await c.wait('inv', x => x.ok === 'case_open', 3000, k1);
    const seen = await c2.wait('inv', x => x.why === 'case_open', 3000, k2);
    check(op && op.got && op.got.t === 0 && op.inv.coins === 6900 && op.inv.bonus === 4900 && seen && seen.inv.items[0].uid === op.got.uid, 'case_open over the socket (bonus coins first → t:0); the other device gets the new inventory', op && [op.got, op.inv.bonus]);
    old2.send({ t: 'case_open', id: 'prodigy' });
    check((await old2.wait('inv_err'))?.code === 'version', 'a 2.2 game cannot touch the cloud inventory');
    // перезапуск сервера
    c.close(); c2.close(); old2.close(); await sleep(200);
    const dir = srv.dir, env = srv.env;
    await srv.stop();
    srv = await startServer({ dataDir: dir, env: { SZ_GAMEDATA_DIR: fixtureDir(), ADMIN_FILE: env.ADMIN_FILE } });
    const c3 = await client(srv.url, { name: 'Облако', acc, cv: 230 });
    await c3.wait('me');
    c3.send({ t: 'inv_get' });
    const back = await c3.wait('inv', x => !!x.inv);
    check(back && back.inv.coins === 6900 && back.inv.items[0].uid === op.got.uid && back.inv.items.length === 2, 'after a restart the cloud inventory is the same', back && back.inv.coins);
    await sleep(300);
    check(!c3.all('gift').length, 'acknowledged cloud gift toasts are not repeated');
    c3.close();

    console.log('== server: rank rewards go to cloud coins (cloud:1), 2.2 players as before');
    await srv.stop();
    srv = await startServer({ env: { SZ_GAMEDATA_DIR: fixtureDir(), SZ_RANKED_WARM_S: '0' } });
    const adm2 = await adminSession(srv);
    const ps = [];
    for (const [i, cv] of [[0, 230], [1, 230], [2, 220], [3, 220]]) {
      const pa = newAcc('Ранг' + i + rnd(3));
      const pc = await client(srv.url, { name: 'Ранг' + i, acc: pa, cv });
      await pc.wait('me');
      ps.push({ c: pc, acc: pa, cv });
    }
    // первый — с облачным инвентарём, второй — 2.3 без переноса (награда ждёт переноса)
    ps[0].c.send({ t: 'inv_migrate', inv: { coins: 100 } });
    await ps[0].c.wait('inv', x => x.ok === 'inv_migrate');
    for (const pp of ps) await adm2.post('rating', { acc: pp.acc.id, rating: 1030, cal: 5 });
    const marks = ps.map(pp => pp.c.mark());
    for (const pp of ps) { pp.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    await Promise.all(ps.map((pp, i) => pp.c.wait('joined', x => !!x.ranked, 9000, marks[i])));
    await sleep(400);
    const lm = ps.map(pp => pp.c.mark());
    ps[0].c.send({ t: '__test', op: 'end', squad: 0 });
    await Promise.all(ps.map((pp, i) => pp.c.wait('rated', null, 5000, lm[i])));
    await sleep(600);
    const rw = (i) => ps[i].c.msgs.slice(lm[i]).filter(x => x.t === 'reward');
    const sum = (l) => l.reduce((t, x) => t + x.coins, 0);
    const ci0 = ps[0].c.msgs.slice(lm[0]).filter(x => x.t === 'inv' && x.why === 'reward').pop();
    check(rw(0).length === 6 && rw(0).every(x => x.cloud === 1) && ci0 && ci0.inv.coins === 100 + sum(rw(0)), 'cloud account: rank rewards credited to cloud coins, toasts with cloud:1', [rw(0).length, ci0 && ci0.inv.coins]);
    check(rw(2).length === 6 && rw(2).every(x => !x.cloud) && rw(3).length === 6, '2.2 players: rewards as before (local coins)', [rw(2).length, rw(3).length]);
    check(rw(1).length === 0, '2.3 game without cloud inventory: rewards wait for the migration', rw(1).length);
    const m5 = ps[1].c.mark();
    ps[1].c.send({ t: 'inv_migrate', inv: { coins: 0 } });
    await ps[1].c.wait('inv', x => x.ok === 'inv_migrate', 3000, m5);
    await sleep(400);
    const lateRw = ps[1].c.msgs.slice(m5).filter(x => x.t === 'reward');
    const lastInv = ps[1].c.msgs.slice(m5).filter(x => x.t === 'inv').pop();
    check(lateRw.length === 6 && lateRw.every(x => x.cloud === 1) && lastInv.inv.coins === sum(lateRw), 'on migration the waiting rank rewards go to the cloud (cloud:1 toasts)', [lateRw.length, lastInv && lastInv.inv.coins]);
    for (const pp of ps) pp.c.close();
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  const errs = srv.logs.filter(l => /\[room|\[msg|\[mm\]|\[market|uncaught|Error/.test(l));
  check(errs.length === 0, 'no server errors in log', errs.slice(0, 5));
  await srv.stop();
  process.exit(summary('economy'));
})();
