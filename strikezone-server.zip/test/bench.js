'use strict';
// Замер нагрузки: 4 комнаты одновременно — 5×5 TDM с ботами, 5×5 «Закладка бомбы» с ботами, рейтинговый 2×2 (4 игрока), дуэль с ботом.
// Игроки шлют состояние 20 раз в секунду и иногда стреляют. Печатает CPU процесса сервера и цену шага каждой комнаты.
// Запуск: node test/bench.js [секунд=20]
const fs = require('fs');
const { sleep, startServer, adminSession, client, newAcc } = require('./lib');

const SEC = +process.argv[2] || 20;
const ticks = (pid) => { const f = fs.readFileSync('/proc/' + pid + '/stat', 'utf8').split(') ')[1].split(' '); return (+f[11]) + (+f[12]); }; // utime + stime (в тиках 1/100 с)

(async () => {
  const srv = await startServer({ env: { SZ_RANKED_WARM_S: '0' } });
  const adm = await adminSession(srv);
  const humans = [];
  const drive = (c) => { humans.push(c); };
  const a = await client(srv.url, { name: 'TDM' }); a.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 5 }); await a.wait('joined'); drive(a);
  const b = await client(srv.url, { name: 'BOMB' }); b.send({ t: 'create', mode: 'bomb', map: 'dust', size: 5 }); await b.wait('joined'); drive(b);
  const d = await client(srv.url, { name: 'DUEL' }); d.send({ t: 'create', mode: 'duel' }); await d.wait('joined'); drive(d);
  const rk = await Promise.all([1, 2, 3, 4].map(i => client(srv.url, { name: 'R' + i, acc: newAcc() })));
  for (const c of rk) { await c.wait('me'); c.send({ t: 'rq', kind: 'ranked' }); }
  await Promise.all(rk.map(c => c.wait('joined', m => !!m.ranked, 8000)));
  rk.forEach(drive);
  // телефоны: состояние 20 Гц (стоят на месте, крутятся), выстрел раз в ~1,5 с
  let n = 0;
  const iv = setInterval(() => {
    n++;
    for (const c of humans) {
      const me = c.snap && c.snap.me; if (!me || !me.al) continue;
      const yw = (n * 0.05) % 6.28;
      c.send({ t: 'st', p: [me.x, me.y, me.z], v: [0, 0, 0], yw, pt: 0, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: me.sl.primary ? 'primary' : 'secondary' });
      if (n % 30 === 0) { const s = me.sl.primary ? 'primary' : 'secondary'; if (me.sl[s]) c.send({ t: 'shot', s, w: me.sl[s][0], o: [me.x, me.y + 1.6, me.z], d: [-Math.sin(yw), 0, -Math.cos(yw)], lag: 0.1 }); }
    }
  }, 50);
  await sleep(5000);                     // разогрев (JIT)
  const t0 = Date.now(), c0 = ticks(srv.proc.pid);
  await sleep(SEC * 1000);
  const t1 = Date.now(), c1 = ticks(srv.proc.pid);
  const st = (await adm.get('state')).data;
  clearInterval(iv);
  const cpu = (c1 - c0) / ((t1 - t0) / 1000);      // тиков 1/100 с за секунду = % одного ядра
  console.log('server process CPU: ' + cpu.toFixed(1) + '% of one core over ' + SEC + ' s, RSS ' + st.memMB + ' MB, admin cpu ' + st.cpu + '%');
  for (const r of st.rooms) console.log('  room ' + r.code + ' ' + (r.kind || (r.pub ? 'public' : 'private')) + ' ' + r.mode + '/' + r.map + ' bots ' + r.bots + ' players ' + r.players.length + ': ' + r.ms + ' ms/tick ≈ ' + (r.ms * 30 / 10).toFixed(1) + '% of a core');
  for (const c of humans) c.close();
  await srv.stop();
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
