'use strict';
// 2.9: метки для команды — видят только напарники, не чаще раза в секунду, вне карты — отбрасываются
const L = require('./lib');
const { check, summary, sleep } = L;
(async () => {
  const srv = await L.startServer();
  try {
    const A = await L.client(srv.url, { name: 'Меткий', cv: 280 });
    const B = await L.client(srv.url, { name: 'Свой', cv: 280 });
    const C = await L.client(srv.url, { name: 'Чужой', cv: 280 });
    A.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 2, side: 'ct' });
    const ja = await A.wait('joined', null, 5000);
    B.send({ t: 'join', code: ja.code, side: 'ct' }); const jb = await B.wait('joined', null, 5000);
    C.send({ t: 'join', code: ja.code, side: 't' }); const jc = await C.wait('joined', null, 5000);
    check(ja.team === jb.team && jc.team !== ja.team, 'A и B — одна команда, C — другая');
    await sleep(300);
    let mb = B.mark(), mc = C.mark(), ma = A.mark();
    A.send({ t: 'mark', p: [3.5, 0, -4.25] });
    const ev = await B.waitEv('mark', e => e[1] === ja.you, 2000, mb);
    check(!!ev && ev[2] === 3.5 && ev[4] === -4.25, 'напарник получил метку с точкой', ev);
    await sleep(300);
    check(!C.evs(mc).some(e => e[0] === 'mark'), 'соперник метку не видит');
    check(!A.evs(ma).some(e => e[0] === 'mark'), 'себе метка не приходит (рисуется сразу)');
    mb = B.mark();
    A.send({ t: 'mark', p: [5, 0, 5] }); await sleep(300);
    check(!B.evs(mb).some(e => e[0] === 'mark'), 'вторая метка раньше чем через секунду — не уходит');
    await sleep(900);
    mb = B.mark();
    A.send({ t: 'mark', p: [999, 0, 5] }); await sleep(300);
    check(!B.evs(mb).some(e => e[0] === 'mark'), 'метка за картой отброшена');
    for (const m of [{ t: 'mark' }, { t: 'mark', p: 'x' }, { t: 'mark', p: [1, 2] }, { t: 'mark', p: [NaN, 0, 0] }]) A.send(m);
    await sleep(200);
    check(A.ws.readyState === 1, 'сервер жив после мусора');
    A.close(); B.close(); C.close();
  } finally { srv.stop(); }
  process.exit(summary('mark29'));
})().catch(e => { console.error(e); process.exit(1); });
