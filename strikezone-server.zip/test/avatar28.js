'use strict';
// 2.8: своя аватарка — одноразовая ссылка из игры (av_link), страница /avatar и загрузка /avatar/up; выдача другим ({t:'avatar', num})
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { check, summary, sleep } = L;
(async () => {
  const srv = await L.startServer();
  const url = srv.url;
  try {
    const acc = L.newAcc('Фотограф'), other = L.newAcc('Зритель');
    const C = await L.client(url, { name: 'Фотограф', acc });
    const O = await L.client(url, { name: 'Зритель', acc: other });
    // гость без аккаунта — отказ
    const Gst = await L.client(url, { name: 'Гость' });
    let mk = Gst.mark(); Gst.send({ t: 'av_link' });
    const ge = await Gst.wait('err', null, 2000, mk);
    check(!!ge, 'гость: av_link → ошибка (нужен аккаунт)', ge && ge.m);
    // ссылка
    mk = C.mark(); C.send({ t: 'av_link' });
    const lk = await C.wait('av_link', null, 3000, mk);
    check(!!lk && typeof lk.k === 'string' && lk.path === '/avatar?k=' + lk.k, 'av_link: токен и путь', lk);
    // страница
    const pg = await srv.http('GET', lk.path);
    check(pg.status === 200 && /Фотограф/.test(pg.text) && /avatar\/up/.test(pg.text), 'GET /avatar?k — страница с ником', pg.status);
    const bad = await srv.http('GET', '/avatar?k=nope');
    check(bad.status === 200 && /устарела/.test(bad.text), 'GET /avatar с плохим токеном — «ссылка устарела»');
    // загрузка
    const jpg = fs.readFileSync(path.join(__dirname, 'fixtures', 'av96.jpg'));
    const data = 'data:image/jpeg;base64,' + jpg.toString('base64');
    mk = C.mark();
    const up = await srv.http('POST', '/avatar/up', { k: lk.k, data });
    check(up.status === 200 && up.data && up.data.ok && up.data.c > 0, 'POST /avatar/up — ok, версия > 0', up.data || up.text);
    const me = await C.wait('me', m => m.acc && m.acc.av && m.acc.av.c > 0, 3000, mk);
    check(!!me, 'после загрузки игра получает me с av.c', me && me.acc.av);
    // повторно тем же токеном — отказ (одноразовый)
    const up2 = await srv.http('POST', '/avatar/up', { k: lk.k, data });
    check(up2.status === 403, 'токен одноразовый', up2.status);
    // другой игрок получает картинку по номеру
    mk = O.mark(); O.send({ t: 'avatar', num: acc.num });
    const av = await O.wait('avatar', null, 3000, mk);
    check(!!av && av.v === up.data.c && typeof av.data === 'string' && av.data.startsWith('data:image/jpeg;base64,') && av.data.length === data.length, 'другой игрок: {t:avatar} с картинкой', av && [av.v, av.data && av.data.length]);
    // слишком большой / не картинка
    mk = C.mark(); C.send({ t: 'av_link' }); const lk2 = await C.wait('av_link', null, 3000, mk);
    const badUp = await srv.http('POST', '/avatar/up', { k: lk2.k, data: 'data:image/jpeg;base64,' + Buffer.from('not a jpeg at all').toString('base64') });
    check(badUp.status === 400 && /JPEG|PNG|30 секунд/.test(badUp.data.error), 'мусор вместо картинки — 400 (или лимит 30 с)', badUp.data);
    // сброс на эмблему из игры (лимит 30 с на смену — ждём не будем: проверяем текст ошибки)
    mk = C.mark(); C.send({ t: 'av', p: 3 });
    const r = await C.waitAny(['av_ok', 'err'], 3000, mk);
    check(!!r && (r.t === 'av_ok' || /30 секунд/.test(r.m)), 'смена на эмблему: av_ok или лимит 30 с', r);
    C.close(); O.close(); Gst.close();
  } finally { srv.stop(); }
  process.exit(summary('avatar28'));
})().catch(e => { console.error(e); process.exit(1); });
