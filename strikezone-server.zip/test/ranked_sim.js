'use strict';
// Рейтинговая «Закладка бомбы» без ботов прямо в симуляции: 16 раундов по времени (спецназ выигрывает каждый),
// смена сторон после 8-го, конец по MAX, ничья 8:8; бомба всегда у человека; ни одной ошибки.
const { createSim } = require('../sim/loader');
const { check, summary } = require('./lib');

const sim = createSim(), G = sim.G, g = G.game, B = G.bombMode;
Object.assign(B, { WIN: 9, HALF: 8, MAX: 16, ROUND: 4, FREEZE: 1, END: 1 });
g.start({ mode: 'bomb', map: 'villa', size: 2, fixedTeams: true });
check(g.waiting === true && B.phase === 'wait', 'empty ranked match waits for players');
const ps = [];
for (const [s, n] of [[0, 'A1'], [0, 'A2'], [1, 'B1'], [1, 'B2']]) ps.push(g.addHuman(n, { team: s, squad: s }));
check(ps.every(Boolean) && g.addHuman('лишний', { team: 0, squad: 0 }) === null, 'preassigned teams, full team refuses a 5th');
Object.assign(B, { ROUND: 4, FREEZE: 1, END: 1 });
g.start({ mode: 'bomb', map: 'villa', size: 2, fixedTeams: true });
check(!g.waiting && g.actors.length === 4 && g.actors.every(a => a.net), 'match starts with 4 humans, no bots');
let halftimes = 0, end = null, carriers = new Set(), errors = 0;
for (let i = 0; i < 30 * 400 && !end; i++) {
  try { g.step(1 / 30); } catch (e) { errors++; if (errors < 3) console.error(e); }
  if (B.bomb && B.bomb.carrier) carriers.add(B.bomb.carrier.net ? 'human' : 'bot');
  for (const [t, d] of G.events) { if (t === 'halftime') halftimes++; if (t === 'matchEnd') end = d; }
  G.events.length = 0;
}
check(errors === 0, 'no exceptions over a whole match', errors);
check(halftimes === 1, 'one side swap', halftimes);
check(ps.every(p => p.team === 1 - p.fixedTeam), 'after halftime every player is on the other side');
check(end && end.win === null && end.sc[0] === 8 && end.sc[1] === 8 && B.round === 16, 'match ends after MAX 16 rounds, 8:8 draw', end);
check(carriers.size === 1 && carriers.has('human'), 'bomb always carried by a human');
check(g.actors.length === 4 && g.actors.every(a => a.net), 'still no bots at the end');
// выход посреди матча: бот не появляется
g.over = false; g.removeHuman(ps[0]);
check(g.actors.length === 3 && g.actors.every(a => a.net), 'removeHuman does not add a bot');
process.exit(summary('ranked_sim'));
