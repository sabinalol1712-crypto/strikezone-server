'use strict';
// 2.3: глобальный рынок (PROTOCOL4 §3): лоты, запросы, встречное исполнение (по цене запроса / по цене лота), комиссия 10 % сгорает,
// лимиты, границы цен, только t:1, срок 7 дней, заморозка, поиск и группировка, карточка скина, «мои сделки», сохранение;
// свойство: случайные последовательности действий нескольких аккаунтов сохраняют монеты (за вычетом сожжённого) и набор предметов;
// через настоящий сервер — сделка двух игроков, события, админка «Рынок».
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');
const { bench, fixtureDir } = require('./ecofix');
const { feeOf, MK } = require('../lib/market');

(async () => {
  const B = bench();
  const gd = B.gd, M = B.market, E = B.eco;
  const inv = (c) => B.inv(c);
  const coinsOf = (c) => inv(c).coins;
  const lastEv = (c, kind) => c.out.filter(x => x.t === 'mk_ev' && (!kind || x.kind === kind)).pop();

  console.log('== fee');
  check(feeOf(5) === 1 && feeOf(19) === 1 && feeOf(20) === 2 && feeOf(100) === 10 && feeOf(105) === 10 && feeOf(100000) === 10000, 'fee = max(1, floor(10 %))');

  console.log('== listings: tradable only, price bounds, limit, unlist');
  const s1 = B.rich('Продавец', 1000, [['pistol_rust', 0], ['pistol_rust', 1], ['ar_flame', 2], ['m9_gold', 0]]);
  B.ask(s1, { t: 'inv_migrate' });
  inv(s1).items.push(E.makeItem('smg_koi', 0, 0, 'bp'), E.makeItem('ar_desert', 0, 0, 'legacy'));
  const it = (c, s, w) => inv(c).items.find(x => x.s === s && (w == null || x.w === w));
  let r = B.ask(s1, { t: 'mk_sell', uid: it(s1, 'smg_koi').uid, price: 50 });
  check(r.code === 'notrade' && /пропуска/.test(r.m), 'BP item → «Нельзя продать: награда пропуска»', r.m);
  r = B.ask(s1, { t: 'mk_sell', uid: it(s1, 'ar_desert').uid, price: 50 });
  check(r.code === 'notrade' && /старый/.test(r.m), 'legacy item → «Нельзя продать: старый предмет»', r.m);
  check(B.ask(s1, { t: 'mk_sell', uid: 'nope', price: 50 }).code === 'item', 'unknown uid → item');
  check(B.ask(s1, { t: 'mk_sell', uid: it(s1, 'pistol_rust', 0).uid, price: 4 }).code === 'price', 'below min (5) → price');
  check(B.ask(s1, { t: 'mk_sell', uid: it(s1, 'pistol_rust', 0).uid, price: 100001 }).code === 'price', 'above 100 000 → price');
  check(B.ask(s1, { t: 'mk_sell', uid: it(s1, 'pistol_rust', 0).uid, price: 10.5 }).code === 'price' && B.ask(s1, { t: 'mk_sell', uid: it(s1, 'pistol_rust', 0).uid, price: '10' }).code === 'price', 'non-integer / string price → price');
  check(B.ask(s1, { t: 'mk_sell', uid: it(s1, 'm9_gold').uid, price: 99 }).code === 'price', 'knife below 100 → price');
  const u0 = it(s1, 'pistol_rust', 0).uid;
  r = B.ask(s1, { t: 'mk_sell', uid: u0, price: 40 });
  check(r.ok === 'mk_sell' && typeof r.lid === 'string' && !r.inv.items.some(x => x.uid === u0) && r.inv.lots === 1, 'listed: item in escrow (not in inventory), lots 1', r.lid);
  const lid0 = r.lid;
  const other = B.rich('Чужой', 500, []);
  check(B.ask(other, { t: 'mk_unlist', lid: lid0 }).code === 'lot', 'someone else cannot unlist');
  r = B.ask(s1, { t: 'mk_unlist', lid: lid0 });
  check(r.ok === 'mk_unlist' && r.inv.items[0].uid === u0 && r.inv.items[0].t === 1 && r.inv.lots === 0, 'unlist → item back (same uid, still t:1)');
  const lim = B.rich('Лимит', 0, Array.from({ length: 11 }, (_, i) => ['shotgun_forest', i % 3]));
  let lr = []; for (const x of inv(lim).items.slice()) lr.push(B.ask(lim, { t: 'mk_sell', uid: x.uid, price: 10 + lr.length }));
  check(lr.slice(0, 10).every(x => x.ok === 'mk_sell') && lr[10].code === 'limit', '10 listings max → 11th: limit', lr[10]);

  console.log('== buy');
  r = B.ask(s1, { t: 'mk_sell', uid: u0, price: 40 });
  const lid1 = r.lid;
  check(B.ask(s1, { t: 'mk_buy', lid: lid1 }).code === 'own', 'own listing → own');
  const poor = B.rich('Бедный', 10, []);
  r = B.ask(poor, { t: 'mk_buy', lid: lid1 });
  check(r.code === 'coins' && r.need === 30, 'not enough coins → coins with need', r);
  // бонусные монеты (перенос, промокоды, пропуск) на рынке не тратятся
  const bon = B.user('Бонус'); B.ask(bon, { t: 'inv_migrate', inv: { coins: 3000 } });
  r = B.ask(bon, { t: 'mk_buy', lid: lid1 });
  check(r.code === 'bonus' && r.need === 40 && r.bonus === 3000 && /доната/.test(r.m), 'only bonus coins → inv_err bonus (need, bonus)', r);
  check(B.ask(bon, { t: 'mk_order', s: 'pistol_rust', w: -1, price: 10 }).code === 'bonus', 'buy order with bonus coins → bonus');
  B.eco.credit(bon.acc.id, 25, 'gift');
  check(B.ask(bon, { t: 'mk_buy', lid: lid1 }).need === 15 && B.inv(bon).coins === 3025, 'clean part counts (25 of 40) — still refused, nothing taken');
  const b1 = B.rich('Покупатель', 1000, []);
  const fees0 = E.data.stat.fees, s1c = coinsOf(s1);
  r = B.ask(b1, { t: 'mk_buy', lid: lid1 });
  check(r.ok === 'mk_buy' && r.got.uid === u0 && r.got.t === 1 && r.got.src === 'market' && r.inv.coins === 960 && r.price === 40, 'buyer pays 40, gets the same uid as t:1 src market', r.got);
  check(coinsOf(s1) === s1c + 36 && E.data.stat.fees === fees0 + 4, 'seller gets 36, fee 4 burned', [coinsOf(s1) - s1c]);
  const ev = lastEv(s1, 'sold');
  check(ev && ev.s === 'pistol_rust' && ev.price === 40 && ev.get === 36 && s1.out.some(x => x.t === 'inv' && x.why === 'sold'), 'seller: mk_ev sold {s, price, get} + inv why:sold', ev);
  check(B.ask(b1, { t: 'mk_buy', lid: lid1 }).code === 'lot', 'listing gone after the sale');

  console.log('== buy orders: escrow, limits, matching at the LISTING price');
  const ob = B.rich('Заказчик', 5000, []);
  check(B.ask(ob, { t: 'mk_order', s: 'smg_koi', w: -1, price: 100 }).code === 'skin', 'order for a BP skin → skin');
  check(B.ask(ob, { t: 'mk_order', s: 'nope', w: -1, price: 100 }).code === 'skin', 'unknown skin → skin');
  check(B.ask(ob, { t: 'mk_order', s: 'pistol_rust', w: 3, price: 100 }).code === 'wear' && B.ask(ob, { t: 'mk_order', s: 'pistol_rust', w: 'x', price: 100 }).code === 'wear', 'bad wear → wear');
  check(B.ask(ob, { t: 'mk_order', s: 'pistol_rust', w: -1, price: 2 }).code === 'price', 'order price bounds');
  r = B.ask(ob, { t: 'mk_order', s: 'pistol_rust', w: 1, price: 70 });
  check(r.ok === 'mk_order' && typeof r.oid === 'string' && r.inv.coins === 4930 && r.inv.esc === 70, 'order: 70 coins escrowed (esc 70)', r.inv);
  const oidW1 = r.oid;
  // лот с другим износом не исполняет запрос с износом 1
  const s2 = B.rich('Второй', 0, [['pistol_rust', 0], ['pistol_rust', 1], ['pistol_rust', 2], ['ar_tiger', 1]]);
  r = B.ask(s2, { t: 'mk_sell', uid: it(s2, 'pistol_rust', 0).uid, price: 60 });
  check(r.ok === 'mk_sell' && r.lid && !r.sold, 'wear 0 listing does not fill a wear-1 order (listed instead)');
  // продажа в запрос: по цене ЗАПРОСА
  r = B.ask(s2, { t: 'mk_sell', uid: it(s2, 'pistol_rust', 1).uid, price: 50 });
  check(r.ok === 'mk_sell' && !r.lid && r.sold && r.sold.price === 70 && r.sold.get === 63 && r.inv.coins === 63, 'sell ≤ best order → filled at the ORDER price (70 − 7)', r.sold);
  check(inv(ob).items[0].s === 'pistol_rust' && inv(ob).items[0].w === 1 && inv(ob).items[0].src === 'market' && lastEv(ob, 'filled') && lastEv(ob, 'filled').price === 70 && !M.O.has(oidW1), 'order owner gets the item, mk_ev filled; order gone');
  // запрос с ценой выше лота: покупка по цене ЛОТА, разница остаётся
  const obc = coinsOf(ob), s2c = coinsOf(s2);
  r = B.ask(ob, { t: 'mk_order', s: 'pistol_rust', w: -1, price: 100 });
  check(r.ok === 'mk_order' && r.bought && r.bought.price === 60 && r.inv.coins === obc - 60 && r.got.s === 'pistol_rust' && r.inv.esc === 0, 'order ≥ cheapest listing → bought at once at the LISTING price (60), difference stays', r.bought);
  check(coinsOf(s2) === s2c + 54 && lastEv(s2, 'sold').price === 60, 'listing seller gets 54 + mk_ev sold');
  // свой лот не исполняет свой запрос
  r = B.ask(s2, { t: 'mk_sell', uid: it(s2, 'pistol_rust', 2).uid, price: 30 });
  const ownLid = r.lid;
  r = B.ask(s2, { t: 'mk_order', s: 'pistol_rust', w: -1, price: 40 });
  check(r.ok === 'mk_order' && r.oid && M.L.has(ownLid), 'own listing never fills own order (self-trade skipped)');
  B.ask(s2, { t: 'mk_unorder', oid: r.oid });
  // лучший запрос первым: дороже, при равной цене — старше
  const oa = B.rich('ЗапросА', 1000, []), obb = B.rich('ЗапросБ', 1000, []), oc = B.rich('ЗапросВ', 1000, []);
  B.ask(oa, { t: 'mk_order', s: 'ar_tiger', w: -1, price: 80 });
  B.ask(obb, { t: 'mk_order', s: 'ar_tiger', w: 1, price: 90 });
  B.ask(oc, { t: 'mk_order', s: 'ar_tiger', w: -1, price: 90 });
  r = B.ask(s2, { t: 'mk_sell', uid: it(s2, 'ar_tiger').uid, price: 20 });
  check(r.sold && r.sold.price === 90 && inv(obb).items.length === 1 && inv(oc).items.length === 0, 'best order first: highest price, ties → oldest', [r.sold, inv(obb).items.length, inv(oc).items.length]);
  // самый дешёвый лот первым
  const l1 = B.rich('Лот1', 0, [['ar_tiger', 0]]), l2 = B.rich('Лот2', 0, [['ar_tiger', 2]]);
  B.ask(l1, { t: 'mk_sell', uid: inv(l1).items[0].uid, price: 95 });
  B.ask(l2, { t: 'mk_sell', uid: inv(l2).items[0].uid, price: 92 });
  r = B.ask(oa, { t: 'mk_unorder', oid: [...M.O.values()].find(x => x.acc === oa.acc.id).oid });
  check(r.ok === 'mk_unorder' && r.inv.coins === 1000 && r.inv.esc === 0, 'unorder → full refund');
  r = B.ask(oa, { t: 'mk_order', s: 'ar_tiger', w: -1, price: 100 });
  check(r.bought && r.bought.price === 92 && r.got.w === 2, 'order takes the cheapest matching listing (92 of 92/95)', r.bought);
  // лимит запросов
  const ol = B.rich('Запросы', 5000, []);
  const ors = []; for (let i = 0; i < 11; i++) ors.push(B.ask(ol, { t: 'mk_order', s: 'famas_forest', w: i % 3, price: 5 + i }));
  check(ors.slice(0, 10).every(x => x.ok === 'mk_order') && ors[10].code === 'limit', '10 orders max → 11th: limit');
  check(B.ask(B.rich('Нищий', 3, []), { t: 'mk_order', s: 'famas_forest', w: -1, price: 10 }).code === 'coins', 'order needs coins for the escrow');

  console.log('== mk_fill');
  const fseller = B.rich('Филл', 0, [['famas_forest', 2], ['famas_forest', 0], ['ar_tiger', 2]]);
  const oid2 = [...M.O.values()].find(x => x.acc === ol.acc.id && x.w === 2 && x.s === 'famas_forest');
  check(B.ask(fseller, { t: 'mk_fill', oid: oid2.oid, uid: it(fseller, 'famas_forest', 0).uid }).code === 'match', 'wrong wear → match');
  check(B.ask(fseller, { t: 'mk_fill', oid: oid2.oid, uid: it(fseller, 'ar_tiger').uid }).code === 'match', 'wrong skin → match');
  check(B.ask(ol, { t: 'mk_fill', oid: oid2.oid, uid: 'x' }).code === 'own', 'own order → own');
  r = B.ask(fseller, { t: 'mk_fill', oid: oid2.oid, uid: it(fseller, 'famas_forest', 2).uid });
  check(r.ok === 'mk_fill' && r.sold.price === oid2.price && r.inv.coins === oid2.price - feeOf(oid2.price) && lastEv(ol, 'filled'), 'fill at the order price; buyer gets mk_ev filled', r.sold);
  check(B.ask(fseller, { t: 'mk_fill', oid: oid2.oid, uid: it(fseller, 'famas_forest', 0).uid }).code === 'order', 'filled order is gone');

  console.log('== search, grouping, skin card, my trades');
  const sx = B.rich('Витрина', 0, [['ar_flame', 0], ['ar_flame', 0], ['ar_flame', 1], ['ssg_aurora', 2], ['m9_gold', 1]]);
  const sell = (c, s, w, p) => B.ask(c, { t: 'mk_sell', uid: it(c, s, w).uid, price: p });
  sell(sx, 'ar_flame', 0, 300); sell(sx, 'ar_flame', 0, 250); sell(sx, 'ar_flame', 1, 200); sell(sx, 'ssg_aurora', 2, 400); sell(sx, 'm9_gold', 1, 5000);
  B.ask(ob, { t: 'mk_order', s: 'ar_flame', w: -1, price: 150 });
  B.ask(ob, { t: 'mk_order', s: 'ar_flame', w: 0, price: 180 });
  B.ask(ob, { t: 'mk_order', s: 'galil_flame', w: 1, price: 120 });
  const q = (x) => B.ask(b1, { t: 'mk_search', q: x }, 'mk_res');
  r = q({ text: 'flame' });
  const g0 = r.list.find(x => x.s === 'ar_flame' && x.w === 0), g1 = r.list.find(x => x.s === 'ar_flame' && x.w === 1);
  check(g0 && g0.n === 2 && g0.min === 250 && g0.ord === 180 && g1 && g1.n === 1 && g1.min === 200 && g1.ord === 150, 'grouped by skin+wear: n, min, best order (wear-specific or «any»)', [g0, g1]);
  check(r.list.some(x => x.s === 'galil_flame' && x.n === 0 && x.ord === 120), 'order-only group is listed (n 0) so sellers see demand');
  r = q({ text: 'AK-47 | Пла' });
  check(r.list.length >= 2 && r.list.every(x => x.s === 'ar_flame'), 'text search by Russian/English label', r.list.map(x => x.s));
  r = q({ w: 'sniper' });
  check(r.list.length && r.list.every(x => ['sniper', 'ssg'].includes(gd.skin(x.s).w)), 'filter by class (sniper → AWM + SSG)', r.list.map(x => x.s));
  r = q({ w: 'm9' });
  check(r.list.length === 1 && r.list[0].s === 'm9_gold', 'filter by weapon id');
  r = q({ r: 5, sort: 'rare' });
  check(r.list.length && r.list.every(x => gd.skin(x.s).r === 5), 'filter by rarity');
  r = q({ sort: 'rare' });
  check(r.list[0].s === 'm9_gold', 'sort rare: knives/gloves first', r.list[0]);
  r = q({ sort: 'cheap' });
  const mins = r.list.filter(x => x.n > 0).map(x => x.min);
  check(mins.every((v, i) => !i || v >= mins[i - 1]) && r.list.findIndex(x => x.n === 0) > r.list.findIndex(x => x.n > 0), 'sort cheap: by lowest price, order-only groups last');
  r = q({ sort: 'new' });
  check(r.list[0].s === 'm9_gold', 'sort new: newest listing first', r.list[0]);
  const total = q({}).total;
  r = q({ page: 1 });
  check(total > MK.PAGE ? r.list.length === Math.min(MK.PAGE, total - MK.PAGE) : r.list.length === 0, 'paging (24 per page), total', [total, r.list.length]);
  check(q({ text: { evil: 1 }, w: 5, r: 'x', sort: 'zzz', page: -3 }).t === 'mk_res', 'garbage query → still a valid reply');
  r = B.ask(b1, { t: 'mk_skin', s: 'ar_flame' }, 'mk_skin');
  check(r.list.length === 3 && r.list[0].price === 200 && r.list[1].price === 250 && r.list[0].seller.nick === 'Витрина' && r.list[0].seller.num > 0 && !r.list[0].mine, 'skin card: listings cheapest first, seller {num, nick}', r.list);
  check(r.orders.length === 2 && r.orders[0].price === 180 && r.orders[0].w === 0 && r.orders[0].n === 1 && r.orders[1].w === -1, 'skin card: orders aggregated by price+wear, best first', r.orders);
  check(B.ask(sx, { t: 'mk_skin', s: 'ar_flame', w: 0 }, 'mk_skin').list.every(x => x.w === 0 && x.mine === 1), 'skin card with wear filter; own listings marked mine');
  r = B.ask(b1, { t: 'mk_skin', s: 'pistol_rust' }, 'mk_skin');
  check(r.hist.length >= 3 && r.hist.every(h => Array.isArray(h) && h.length === 2 && h[0] > 0 && h[1] > 0), 'price history [[ts, price], …]', r.hist);
  check(B.ask(b1, { t: 'mk_skin', s: 'nope' }).code === 'skin', 'unknown skin card → skin');
  r = B.ask(ob, { t: 'mk_mine' }, 'mk_mine');
  check(r.orders.length === 3 && r.sells.length === 0 && r.log.length === 2 && r.log[0].ts >= r.log[r.log.length - 1].ts && r.log.every(x => x.who && x.who.nick), 'mk_mine: active orders, trade log (newest first, counterpart nick)', r.log[0]);
  r = B.ask(sx, { t: 'mk_mine' }, 'mk_mine');
  check(r.sells.length === 5 && r.sells.every(x => x.lid && x.uid && x.exp > x.at), 'mk_mine: active listings with expiry');

  console.log('== expiry (7 days), freeze');
  const ex = B.rich('Срок', 1000, [['ssg_urban', 0]]);
  r = B.ask(ex, { t: 'mk_sell', uid: inv(ex).items[0].uid, price: 33 });
  B.ask(ex, { t: 'mk_order', s: 'ssg_urban', w: 2, price: 20 });
  B.tick(MK.LIFE - 5000); M.tick();
  check(M.L.has(r.lid), 'not expired before 7 days');
  B.tick(6000); const exN = M.tick();
  check(!M.L.has(r.lid) && inv(ex).items.length === 1 && inv(ex).coins === 1000 && exN > 0, '7 days: listing back, order refunded');
  check(ex.out.filter(x => x.t === 'mk_ev' && x.kind === 'expired').length === 2 && ex.out.some(x => x.t === 'inv' && x.why === 'expired'), 'mk_ev expired (lot + order) + inv why:expired');
  const fz = B.rich('Мороз', 1000, [['ssg_urban', 1], ['ssg_urban', 2]]);
  B.ask(fz, { t: 'mk_sell', uid: it(fz, 'ssg_urban', 1).uid, price: 44 });
  B.ask(fz, { t: 'mk_order', s: 'ssg_urban', w: 0, price: 10 });
  const n = M.freeze(fz.acc.id, true);
  check(n === 2 && inv(fz).items.length === 2 && inv(fz).coins === 1000 && fz.acc.tfreeze > 0, 'freeze: listings and orders returned', n);
  check(B.ask(fz, { t: 'mk_sell', uid: it(fz, 'ssg_urban', 1).uid, price: 44 }).code === 'frozen' && B.ask(fz, { t: 'mk_order', s: 'ssg_urban', w: 0, price: 10 }).code === 'frozen', 'frozen account: market actions refused');
  check(B.ask(fz, { t: 'mk_search', q: {} }).t === 'mk_res' && B.ask(fz, { t: 'mk_mine' }, 'mk_mine').frozen === 1, 'frozen account can still look (mk_mine.frozen = 1)');
  M.freeze(fz.acc.id, false);
  check(B.ask(fz, { t: 'mk_sell', uid: it(fz, 'ssg_urban', 1).uid, price: 44 }).ok === 'mk_sell', 'unfreeze → trading works again');
  check(M.adminUnlist([...M.L.values()].find(l => l.acc === fz.acc.id).lid) && inv(fz).items.length === 2 && lastEv(fz, 'expired').admin === 1, 'admin unlist → item returned, mk_ev expired admin:1');

  console.log('== rate limit, full inventory');
  B.autoTick = 0;
  const rl = B.rich('Спешка', 1000, []);
  let rate = 0; for (let i = 0; i < 7; i++) if (B.ask(rl, { t: 'mk_order', s: 'ssg_urban', w: i % 3, price: 5 }).code === 'rate') rate++;
  check(rate === 2, '5 market actions per second', rate);
  B.autoTick = 210;
  const full = B.rich('Полный', 1000, []);
  for (let i = 0; i < E.C.INV_MAX; i++) inv(full).items.push(E.makeItem('ar_desert', 0, 0, 'legacy'));
  const fl = B.rich('Лот', 0, [['ar_desert', 1]]);
  const flid = B.ask(fl, { t: 'mk_sell', uid: inv(fl).items[0].uid, price: 10 }).lid;
  check(B.ask(full, { t: 'mk_buy', lid: flid }).code === 'full' && B.ask(full, { t: 'mk_order', s: 'ar_desert', w: -1, price: 10 }).code === 'full', 'full inventory → buy/order refused');
  check(B.invariants().ok, 'invariant holds after all scenarios', B.invariants());

  console.log('== persistence: listings, orders, history survive a restart');
  const before = { L: M.L.size, O: M.O.size, esc: M.escrowTotal(), tr: M.trades.length, inv: B.invariants() };
  const B2 = await B.reload();
  const after = { L: B2.market.L.size, O: B2.market.O.size, esc: B2.market.escrowTotal(), tr: B2.market.trades.length, inv: B2.invariants() };
  check(before.L === after.L && before.O === after.O && before.esc === after.esc && before.tr === after.tr && after.inv.ok && after.inv.items === before.inv.items, 'same listings/orders/escrow/trades and invariant after reload', [before.L, after.L, before.O, after.O]);
  const sameIt = [...M.L.values()].every(l => { const k = B2.market.L.get(l.lid); return k && k.it.uid === l.it.uid && k.price === l.price && k.exp === l.exp && k.acc === l.acc; });
  check(sameIt, 'each listing restored exactly (uid, price, expiry, owner)');

  console.log('== property: random sell/buy/order/fill/cancel/expire/freeze sequences keep coins and items');
  for (const seed of [1, 2, 3]) {
    let s = seed * 7919;
    const rand = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    const pick = (a) => a[Math.floor(rand() * a.length)];
    const F = bench();
    F.gd.setRng(rand);
    const SK = ['pistol_rust', 'smg_night', 'shotgun_forest', 'ar2_carbon'];
    const us = [];
    for (let i = 0; i < 6; i++) us.push(F.rich('Ф' + i, 300 + Math.floor(rand() * 3000), Array.from({ length: 6 }, () => [pick(SK), Math.floor(rand() * 3)])));
    const start = F.invariants();
    const startUids = new Map(start.uids);
    let bad = 0, steps = 0, ok = 0, reloads = 0;
    let H = F;
    const ops = {
      sell(c) { const its = H.inv(c).items.filter(x => x.t); if (its.length) return H.send(c, { t: 'mk_sell', uid: pick(its).uid, price: 5 + Math.floor(rand() * 80) }); },
      unlist(c) { const l = [...H.market.L.values()].filter(x => rand() < 0.8 ? x.acc === c.acc.id : true); if (l.length) return H.send(c, { t: 'mk_unlist', lid: pick(l).lid }); },
      buy(c) { const l = [...H.market.L.values()]; if (l.length) return H.send(c, { t: 'mk_buy', lid: pick(l).lid }); },
      order(c) { return H.send(c, { t: 'mk_order', s: pick(SK), w: Math.floor(rand() * 4) - 1, price: 5 + Math.floor(rand() * 90) }); },
      unorder(c) { const l = [...H.market.O.values()].filter(x => rand() < 0.8 ? x.acc === c.acc.id : true); if (l.length) return H.send(c, { t: 'mk_unorder', oid: pick(l).oid }); },
      fill(c) {
        const l = [...H.market.O.values()], its = H.inv(c).items.filter(x => x.t);
        if (!l.length || !its.length) return;
        const x = pick(l), fit = its.filter(y => y.s === x.s && (x.w === -1 || x.w === y.w));
        return H.send(c, { t: 'mk_fill', oid: x.oid, uid: (fit.length && rand() < 0.75 ? pick(fit) : pick(its)).uid });
      },
      expire() { H.tick(MK.LIFE / 3); H.market.tick(); },
      // заморозка ненадолго: замороженный аккаунт (если есть) чаще размораживается
      freeze(c) { const f = us.find(u => u.acc.tfreeze); if (f && rand() < 0.8) H.market.freeze(f.acc.id, false); else H.market.freeze(c.acc.id, true); },
      caseOpen(c) { return H.send(c, { t: 'case_open', id: pick(['prodigy', 'arsenal']) }); },
      gift(c) { H.eco.credit(c.acc.id, 1 + Math.floor(rand() * 200), 'gift'); }
    };
    const weights = [['sell', 22], ['unlist', 6], ['buy', 18], ['order', 20], ['unorder', 6], ['fill', 12], ['expire', 2], ['freeze', 4], ['caseOpen', 4], ['gift', 3]];
    const wsum = weights.reduce((t, x) => t + x[1], 0);
    for (let step = 0; step < 2500; step++) {
      let x = rand() * wsum, name = weights[0][0];
      for (const [k, w] of weights) { x -= w; if (x < 0) { name = k; break; } }
      const c = pick(us);
      const out = ops[name](c) || [];
      if (out.some(m => m.t === 'inv' && m.ok)) ok++;
      steps++;
      const v = H.invariants();
      if (!v.ok) { bad++; if (bad < 3) console.log('   broken after', name, JSON.stringify({ coins: v.coins, esc: v.esc, burned: v.burned, minted: v.minted, items: v.items, made: v.made, dup: v.dup })); }
      for (const [uid, sw] of startUids) if (v.uids.get(uid) !== sw) { bad++; startUids.delete(uid); }
      // перезапуск посреди торгов: состояние читается из data/eco.json
      if (step % 800 === 799) {
        const R = await H.reload(); reloads++;
        for (const u of us) R.conns.set(u.acc.id, new Set([u]));
        if (!R.invariants().ok || R.market.escrowTotal() !== H.market.escrowTotal() || R.market.L.size !== H.market.L.size) bad++;
        R.gd.setRng(rand);
        H = R;
      }
    }
    const end = H.invariants();
    const tr = H.market.trades.length;
    check(bad === 0 && end.ok, 'seed ' + seed + ': ' + steps + ' random steps (' + ok + ' succeeded, ' + tr + ' trades, ' + reloads + ' restarts): total coins − burned and the item multiset invariant', { bad, coins: end.coins, esc: end.esc, burned: end.burned, minted: end.minted, items: end.items });
    check(tr > 50 && H.market.trades.every(t => t.fee === feeOf(t.p)), 'seed ' + seed + ': plenty of trades, each burned exactly the 10 % fee', tr);
  }

  console.log('== garbage messages: every 2.3 type with random fields and values');
  {
    const Z = bench();
    const T23 = ['inv_get', 'inv_migrate', 'case_open', 'bp_buy', 'bp_claim', 'op_buy', 'promo', 'mk_sell', 'mk_unlist', 'mk_buy', 'mk_order', 'mk_unorder', 'mk_fill', 'mk_search', 'mk_skin', 'mk_mine'];
    const F23 = ['id', 'token', 'key', 'code', 'inv', 'uid', 'price', 'lid', 's', 'w', 'oid', 'q'];
    const users = [Z.rich('Мусор1', 3000, [['pistol_rust', 0], ['smg_night', 1], ['ar_flame', 2]]), Z.rich('Мусор2', 3000, [['pistol_rust', 1]]), Z.user('Мусор3'), Z.user('Мусор4', 220)];
    let s = 4242; const rand = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    const pick = (a) => a[Math.floor(rand() * a.length)];
    const ids = () => [...Z.market.L.keys(), ...Z.market.O.keys(), ...users.flatMap(u => (Z.inv(u) ? Z.inv(u).items.map(x => x.uid) : []))];
    const VALS = () => [null, true, false, 0, -1, 1, 2, 3, 5, 50, 1e308, -1e308, 0.5, 2 ** 53, '', 'x', '__proto__', 'constructor', 'toString', 'prodigy', 'harbor', 'f1', 'p30', 'pistol_rust', 'TESTCOINS',
      [], {}, [1, 2], { coins: 1e308, items: [{ s: '__proto__' }, { s: 'pistol_rust', w: '__proto__' }], tokens: { ['__proto__']: 5, constructor: 3 }, ops: [{}], bp: { season: {}, got: [{}] } },
      { text: {}, w: [], r: '5', sort: {}, page: 1e9 }, { text: 'Ж'.repeat(3000) }, 'Ж'.repeat(3000), pick(ids().concat(['l1']))];
    let thrown = 0, replies = 0;
    for (let i = 0; i < 6000; i++) {
      const m = { t: pick(T23) };
      const n = Math.floor(rand() * 5);
      for (let k = 0; k < n; k++) m[pick(F23)] = pick(VALS());
      try { replies += Z.send(pick(users), m).length; } catch (e) { thrown++; if (thrown < 3) console.log('   threw on', JSON.stringify(m).slice(0, 200), e.stack); }
      if (i % 500 === 0) Z.tick(MK.LIFE / 4);
    }
    Z.market.tick();
    check(thrown === 0 && replies > 3000, '6000 garbage messages: no exceptions, every one answered or ignored', { thrown, replies });
    check(Z.invariants().ok && Object.getPrototypeOf({}).polluted === undefined && ({}).constructor === Object, 'invariant intact, no prototype pollution', Z.invariants());
    const back = await Z.reload();
    check(back.invariants().ok, 'state after garbage reloads cleanly');
  }

  // ================= через настоящий сервер =================
  console.log('== server: two players trade, events, admin «Рынок» tab, expiry');
  const srv = await startServer({ env: { SZ_GAMEDATA_DIR: fixtureDir(), SZ_MK_LIFE_MS: '4000', SZ_MK_TICK_MS: '300' } });
  try {
    const adm = await adminSession(srv);
    const sa = newAcc('Купец' + rnd(3)), sb = newAcc('Барыга' + rnd(3));
    const A1 = await client(srv.url, { name: 'Купец', acc: sa, cv: 230 });
    const B1 = await client(srv.url, { name: 'Барыга', acc: sb, cv: 230 });
    await A1.wait('me'); await B1.wait('me');
    // монеты для рынка — «чистые»: подарок админа (донат); перенесённые с телефона — бонусные
    for (const [c, sp] of [[A1, sa], [B1, sb]]) {
      const k = c.mark(); c.send({ t: 'inv_migrate', inv: { coins: 0 } }); await c.wait('inv', x => x.ok === 'inv_migrate', 3000, k);
      await adm.post('gift', { num: sp.num, coins: 2000 }); await c.wait('inv', x => x.why === 'gift' && x.inv.coins === 2000, 3000, k);
    }
    let k = A1.mark();
    A1.send({ t: 'case_open', id: 'prodigy' });
    const op = await A1.wait('inv', x => x.ok === 'case_open', 3000, k);
    const item = op.got;
    const pmin = gd.isGold(item.s) ? 100 : 50;
    k = A1.mark();
    A1.send({ t: 'mk_sell', uid: item.uid, price: pmin + 10 });
    const ls = await A1.wait('inv', x => x.ok === 'mk_sell', 3000, k);
    check(ls && ls.lid && ls.inv.lots === 1, 'player A lists a case item', ls && ls.lid);
    k = B1.mark();
    B1.send({ t: 'mk_search', q: { text: gd.skinLabel(item.s).slice(0, 6) } });
    const res = await B1.wait('mk_res', null, 3000, k);
    check(res && res.list.some(x => x.s === item.s && x.w === item.w && x.min === pmin + 10), 'player B finds it in mk_search', res && res.list.slice(0, 3));
    B1.send({ t: 'mk_skin', s: item.s });
    const card = await B1.wait('mk_skin', null, 3000, k);
    check(card && card.list[0].lid === ls.lid && card.list[0].seller.num === sa.num, 'mk_skin shows the listing with the seller number');
    const ka = A1.mark();
    B1.send({ t: 'mk_buy', lid: ls.lid });
    const bought = await B1.wait('inv', x => x.ok === 'mk_buy', 3000, k);
    const sold = await A1.wait('mk_ev', x => x.kind === 'sold', 3000, ka);
    const ainv = await A1.wait('inv', x => x.why === 'sold', 3000, ka);
    const p = pmin + 10, fee = feeOf(p);
    check(bought && bought.got.uid === item.uid && bought.inv.coins === 2000 - p, 'B buys: item moves, coins paid', bought && bought.inv.coins);
    check(sold && sold.get === p - fee && ainv && ainv.inv.coins === 1900 + p - fee, 'A (online) gets mk_ev sold and the new inventory at once', [sold, ainv && ainv.inv.coins]);
    // запрос B и продажа A в запрос
    k = A1.mark();
    A1.send({ t: 'case_open', id: 'arsenal' });
    const op2 = (await A1.wait('inv', x => x.ok === 'case_open', 3000, k)).got;
    const kb = B1.mark();
    B1.send({ t: 'mk_order', s: op2.s, w: -1, price: 150 });
    const ord = await B1.wait('inv', x => x.ok === 'mk_order', 3000, kb);
    k = A1.mark();
    A1.send({ t: 'mk_fill', oid: ord.oid, uid: op2.uid });
    const fl = await A1.wait('inv', x => x.ok === 'mk_fill', 3000, k);
    const fev = await B1.wait('mk_ev', x => x.kind === 'filled', 3000, kb);
    check(fl && fl.sold.price === 150 && fev && fev.s === op2.s, 'mk_order + mk_fill over the socket, buyer gets mk_ev filled');
    // админка
    let r = await adm.get('market');
    check(r.status === 200 && r.data.stats.trades24 === 2 && r.data.trades.length === 2 && r.data.trades[0].seller.num === sa.num && r.data.top.length >= 1 && r.data.cfg.fee === 10, 'GET market: stats, recent trades, top items', r.data.stats);
    r = await adm.get('market_player?num=' + sb.num);
    check(r.status === 200 && r.data.inv && r.data.inv.items.length === 2 && r.data.inv.items.every(x => x.label && x.src === 'market') && r.data.trades.length === 2, 'GET market_player: cloud inventory with labels + trades', r.data.inv && r.data.inv.coins);
    check((await adm.get('market_player?q=' + encodeURIComponent(sa.nick))).data.player.num === sa.num, 'market_player by nick search');
    k = A1.mark();
    A1.send({ t: 'case_open', id: 'prodigy' });
    const op3 = (await A1.wait('inv', x => x.ok === 'case_open', 3000, k)).got;
    A1.send({ t: 'mk_sell', uid: op3.uid, price: 777 });
    const ls3 = await A1.wait('inv', x => x.ok === 'mk_sell', 3000, k);
    r = await adm.get('market_find?q=' + sa.num);
    check(r.data.listings.length === 1 && r.data.listings[0].lid === ls3.lid && r.data.listings[0].seller.nick === sa.nick, 'GET market_find by player number');
    k = A1.mark();
    r = await adm.post('market_unlist', { lid: ls3.lid });
    const back = await A1.wait('inv', x => x.why === 'admin', 3000, k);
    check(r.data.ok && back && back.inv.items.some(x => x.uid === op3.uid) && back.inv.lots === 0, 'POST market_unlist → item returned to the online owner');
    check((await adm.post('market_unlist', { lid: ls3.lid })).status === 404, 'unknown listing → 404');
    r = await adm.post('market_freeze', { num: sa.num, on: true });
    k = A1.mark();
    A1.send({ t: 'mk_sell', uid: op3.uid, price: 100 });
    const fe = await A1.wait('inv_err', null, 3000, k);
    check(r.data.ok && r.data.frozen === 1 && fe && fe.code === 'frozen', 'POST market_freeze → player cannot trade', fe);
    check((await adm.get('market')).data.frozen.some(x => x.num === sa.num), 'frozen accounts listed in GET market');
    await adm.post('market_freeze', { num: sa.num, on: false });
    // срок лота на сервере (SZ_MK_LIFE_MS = 4 с)
    k = A1.mark();
    A1.send({ t: 'mk_sell', uid: op3.uid, price: 100 });
    await A1.wait('inv', x => x.ok === 'mk_sell', 3000, k);
    const exp = await A1.wait('mk_ev', x => x.kind === 'expired', 7000, k);
    check(exp && exp.what === 'lot' && exp.s === op3.s, 'listing expires → mk_ev expired, item back', exp);
    // старая игра
    const old = await client(srv.url, { name: 'Купец', acc: sa, cv: 220, key: 'kold' + rnd(10) });
    await old.wait('me');
    old.send({ t: 'mk_buy', lid: 'x' });
    check((await old.wait('inv_err'))?.code === 'version', '2.2 game → mk_* refused (version)');
    old.close(); A1.close(); B1.close();
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  const errs = srv.logs.filter(l => /\[room|\[msg|\[mm\]|\[market|\[admin\]|uncaught|Error/.test(l));
  check(errs.length === 0, 'no server errors in log', errs.slice(0, 5));
  await srv.stop();
  process.exit(summary('market'));
})();
