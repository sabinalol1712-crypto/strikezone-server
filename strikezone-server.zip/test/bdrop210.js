// 2.10: выбросить бомбу по сети ({t:'bdrop'}): «Вилла» 2 на 2 из людей — носитель бросает бомбу, она лежит перед ним,
// сам он сразу её не подбирает, напарник — подбирает; не-носитель и частые запросы ничего не ломают.
// Запуск: PORT=8098 SZ_FAST=1 node server.js; PORT=8098 node test/bdrop210.js
const URL = 'ws://localhost:' + (process.env.PORT || 8098) + '/ws';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let fail = 0; const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };
function client(name, key) {
  const ws = new WebSocket(URL), st = { ws, name, ev: [], snap: null, joined: null };
  ws.onopen = () => ws.send(JSON.stringify({ t: 'hello', v: 1, cv: 300, key, name, prim: 'ar', skins: {}, knife: ['knife', null, 0], gloves: null, drops: 1 }));
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.t === 'welcome') st.welcome = m;
    else if (m.t === 'joined') { st.joined = m; st.code = m.code; st.you = m.you; }
    else if (m.t === 'snap') st.snap = m;
    else if (m.t === 'ev') for (const x of m.l) st.ev.push(x);
  };
  st.send = (o) => ws.send(JSON.stringify(o));
  st.ping = setInterval(() => { try { st.send({ t: 'ping', c: 0 }); } catch (e) { } }, 3000);
  st.close = () => { clearInterval(st.ping); ws.close(); };
  return new Promise(r => { const iv = setInterval(() => { if (st.welcome) { clearInterval(iv); r(st); } }, 20); });
}
const until = async (f, ms) => { for (let t = 0; t < ms; t += 50) { if (f()) return true; await sleep(50); } return !!f(); };
const evs = (c, type) => c.ev.filter(e => e[0] === type);
const st = (c, x, y, z) => c.send({ t: 'st', p: [x, y, z], v: [0, 0, 0], yw: c.snap.me.yw, pt: 0, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: 'primary' });
let SIM = null;
async function walkTo(c, tx, tz) {
  if (!SIM) { const { createSim } = require('../sim/loader'); SIM = createSim().G; SIM.map.load('villa', null); SIM.nav.build(); }
  const me = c.snap.me; let x = me.x, y = me.y, z = me.z;
  const pts = (SIM.nav.findPath(x, z, tx, tz) || []).concat([{ x: tx, z: tz }]);
  for (const q of pts) {
    for (let n = 0; n < 400; n++) {
      const dx = q.x - x, dz = q.z - z, d = Math.hypot(dx, dz);
      if (d < 0.05) break;
      const s = Math.min(0.22, d); x += dx / d * s; z += dz / d * s;
      const fy = SIM.drops.floorAt(x, y + 0.5, z); if (fy != null && fy >= 0) y = fy;
      st(c, x, y, z); await sleep(34);
    }
  }
}

(async () => {
  const A = await client('Анна', 'bdkey00000001'), B = await client('Борис', 'bdkey00000002'), C = await client('Света', 'bdkey00000003'), D = await client('Дима', 'bdkey00000004');
  ok('server 2.10', /^2\.(1\d|[2-9]\d)\./.test(A.welcome.srv), A.welcome.srv);
  A.send({ t: 'create', mode: 'bomb', map: 'villa', side: 'ct' });
  await until(() => A.code && A.snap, 3000);
  B.send({ t: 'join', code: A.code, side: 't' }); C.send({ t: 'join', code: A.code, side: 'ct' }); D.send({ t: 'join', code: A.code, side: 't' });
  const all = [A, B, C, D];
  await until(() => evs(A, 'mstart').some(e => e[1] === 'bomb'), 15000);
  ok('match started (bomb, 4 humans)', evs(A, 'mstart').some(e => e[1] === 'bomb'));
  await until(() => A.snap.g.m === 'bomb' && A.snap.g.ph === 'live', 10000);
  ok('round live', A.snap.g.ph === 'live');
  const car = all.find(c => c.snap.me.bomb), mate = all.find(c => c !== car && c.snap.me.team === (car && car.snap.me.team));
  ok('a human T carries the bomb', !!car && !!mate && car.snap.me.team === 1);
  if (!car || !mate) { all.forEach(c => c.close()); process.exit(1); }
  // не-носитель просит выбросить — ничего
  A.send({ t: 'bdrop' }); await sleep(300);
  ok('bdrop from a non-carrier is ignored', A.snap.g.bs === 'carried' && car.snap.me.bomb === 1);
  const px = car.snap.me.x, pz = car.snap.me.z;
  car.send({ t: 'bdrop' }); car.send({ t: 'bdrop' });
  await until(() => car.snap.g.bs === 'dropped', 2000);
  const g = car.snap.g;
  ok('carrier tosses the bomb: dropped in front of him', g.bs === 'dropped' && !car.snap.me.bomb && Math.hypot(g.bx - px, g.bz - pz) <= 1.5, g.bs + ' ' + Math.hypot(g.bx - px, g.bz - pz).toFixed(2));
  // сам — стоит на бомбе, но подберёт только через 1,5 с
  st(car, g.bx, g.by, g.bz);
  await sleep(500);
  ok('tosser does not re-pick at once', car.snap.g.bs === 'dropped' && !car.snap.me.bomb);
  // напарник идёт к бомбе по навигационной сетке
  st(car, px, car.snap.me.y, pz);
  await sleep(200);
  await walkTo(mate, g.bx, g.bz);
  await until(() => mate.snap.me.bomb === 1, 3000);
  ok('teammate walks over and picks it up', mate.snap.me.bomb === 1 && mate.snap.g.bs === 'carried', mate.snap.g.bs);
  ok('pick event for the teammate', evs(mate, 'pick').some(e => e[1] === mate.you));
  all.forEach(c => c.close());
  console.log(fail ? 'FAILED ' + fail : 'ALL PASSED');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
