'use strict';
// Рейтинговые матчи 2×2 и клановые войны: очередь, подбор, комната без ботов, итоги (Эло, калибровка, штраф за выход),
// техническое поражение, ожидание после обрыва, таблица лидеров. Конец матча — через тестовый хук (SZ_TEST_HOOKS=1).
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');

// 2.5: рейтинг по вкладу. В тестах матч заканчивается хуком без убийств — вклад у всех 0, место среди четверых одинаковое
// (0,5): оценка 0,6·0 + 0,4·0,5 = 0,2 → победа 17 + round(25·0,2) = +22, поражение −(25 − round(12·0,2)) = −23, ничья −3, вышел −50
const WIN_D = 22, LOSS_D = -23, DRAW_D = -3, LEAVE_D = -50;

(async () => {
  const HOLD = 5000;
  const srv = await startServer({ env: { SZ_RANKED_HOLD_MS: String(HOLD), SZ_RANKED_WARM_S: '0' } });   // разминку проверяет ranked2.js
  const url = srv.url;
  const adm = await adminSession(srv);
  const people = {};
  // игрок: аккаунт + постоянный ключ телефона (для возвращения после обрыва)
  async function player(name) {
    const p = { name, acc: newAcc(), key: 'k' + rnd(15) };
    p.c = await client(url, { name, acc: p.acc, key: p.key });
    await p.c.wait('me');
    people[name] = p;
    return p;
  }
  async function reconnect(p) { p.c = await client(url, { name: p.name, acc: p.acc, key: p.key }); await p.c.wait('me'); return p.c; }
  const acc = async (p) => (await adm.get('player?acc=' + p.acc.id)).data;
  // все встают в очередь → rq_found → joined
  async function queue(ps, kind) {
    const marks = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind }); await sleep(30); }
    const found = await Promise.all(ps.map((p, i) => p.c.wait('rq_found', null, 4000, marks[i])));
    const tf = Date.now();
    const joined = await Promise.all(ps.map((p, i) => (found[i] && p.c.connected !== false ? p.c.wait('joined', m => !!m.ranked, 6000, marks[i]) : null)));
    return { found, joined, dt: Date.now() - tf, marks };
  }
  const squadOf = (q, i) => q.found[i] && q.found[i].you;

  try {
    console.log('== ranked: queue status');
    const [p1, p2, p3, p4] = await Promise.all(['Ранг1', 'Ранг2', 'Ранг3', 'Ранг4'].map(player));
    const g = await player('Гость-клан');
    for (const p of [p1, p2, p3]) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(20); }
    await sleep(3200);
    const st = p1.c.all('rq').filter(m => m.st === 'search');
    check(st[0] && st[0].sec === 0 && st[0].n === 1, 'immediate status when joining the queue', st[0]);
    const ticks = st.slice(1);
    check(ticks.length >= 3 && ticks.every((m, i) => m.kind === 'ranked' && m.n === 3 && m.avg === 0 && (i === 0 || m.sec >= ticks[i - 1].sec)) && ticks[ticks.length - 1].sec >= 2, 'rq status every second: kind, st search, sec rising, n, avg', st);
    let s = await adm.get('state');
    check(s.data.queues.ranked === 3 && s.data.queues.clan === 0, 'admin state queues', s.data.queues);
    p4.c.send({ t: 'rq', kind: 'ranked' });
    const ps = [p1, p2, p3, p4];
    const found = await Promise.all(ps.map(p => p.c.wait('rq_found', null, 3000)));
    const tf = Date.now();
    check(found.every(f => f && f.kind === 'ranked' && ['villa', 'lagoon', 'caldera'].includes(f.map) && f.teams.length === 2 && f.teams.every(t => t.length === 2)), 'rq_found to all 4: kind ranked, map villa, 2 teams × 2', found[0]);
    const tm = found[0].teams;
    check(tm.flat().every(x => typeof x.nick === 'string' && x.rating === 1000 && x.cal === 0 && 'tag' in x && 'color' in x), 'team entries {nick, rating, cal, tag, color}', tm);
    check(ps.every((p, i) => tm[found[i].you].some(x => x.nick === p.name)), 'you = own team index');
    check(new Set(tm.flat().map(x => x.nick)).size === 4, 'all 4 players in the match');
    const joined = await Promise.all(ps.map(p => p.c.wait('joined', null, 6000)));
    const dt = Date.now() - tf;
    check(dt > 3000 && dt < 4800, 'room starts ~3.5 s after rq_found', dt);
    check(joined.every(j => j && j.ranked === 'ranked' && j.mode === 'bomb' && ['villa', 'lagoon', 'caldera'].includes(j.map) && j.size === 2 && j.pub === false && j.code === joined[0].code), 'all joined the same private bomb/villa room with ranked:"ranked"', joined[0]);
    check(joined.every((j, i) => j.team === found[i].you), 'preassigned teams (joined.team = rq_found.you)');
    const code = joined[0].code;
    await sleep(600);
    const ros = p1.c.last('roster').list;
    check(ros.length === 4 && ros.every(r => r[3] === 1), 'roster: 4 humans, no bots', ros.map(r => r.slice(0, 4)));
    check(ps.every((p, i) => ros.find(r => r[0] === joined[i].you)[2] === found[i].you), 'roster teams match squads');
    const snap = p1.c.snap;
    check(snap && snap.g.m === 'bomb' && snap.g.win === 9 && snap.g.max === 16, 'ranked rules WIN 9 / MAX 16 in snapshots', snap && snap.g);
    const rqAfter = p4.c.msgs.slice(p4.c.msgs.indexOf(found[3])).filter(m => m.t === 'rq').length;
    check(rqAfter === 0, 'queue status stops after rq_found', rqAfter);
    // посторонние не попадают
    const gm = g.c.mark();
    g.c.send({ t: 'list' });
    const lst = await g.c.wait('rooms', null, 2000, gm);
    check(lst && !lst.list.some(r => r.id === code), 'ranked room not in list');
    g.c.send({ t: 'join', code });
    const je = await g.c.wait('err', null, 2000, gm);
    check(je && je.m === 'Это рейтинговый матч', 'join by code refused: Это рейтинговый матч', je);
    g.c.send({ t: 'quick', mode: 'bomb' });
    const qj = await g.c.wait('joined', null, 3000, gm);
    check(qj && qj.code !== code && !qj.ranked, 'quick never picks the ranked room');
    g.c.send({ t: 'leave' });
    s = await adm.get('state');
    const room = s.data.rooms.find(r => r.code === code);
    check(room && room.kind === 'ranked' && room.bots === 0 && room.players.length === 4 && room.players.every(x => x.acc && 'ping' in x && 'k' in x && 'tag' in x), 'admin state: kind ranked, 0 bots, 4 players with acc', room);
    check(s.data.queues.ranked === 0, 'queue empty after match found');

    console.log('== ranked: result');
    const win0 = ps.filter((p, i) => found[i].you === 0), lose0 = ps.filter((p, i) => found[i].you === 1);
    const em = ps.map(p => p.c.mark());
    p1.c.send({ t: '__test', op: 'end', squad: 0 });
    const mend = await Promise.all(ps.map((p, i) => p.c.waitEv('mend', null, 3000, em[i])));
    check(mend.every(e => e && e[1] === 0), 'mend with winner team 0 to everyone', mend[0]);
    const tEnd = Date.now();
    const rated = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 3000, em[i])));
    for (const [i, p] of ps.entries()) {
      const r = rated[i], w = found[i].you === 0;
      check(r && r.kind === 'ranked' && r.old === 1000 && r.delta === (w ? WIN_D : LOSS_D) && r.new === 1000 + r.delta && r.cal === 1 && r.win === (w ? 1 : 0) && r.st && r.st.k === 0 && r.perf === 20, p.name + ' rated ' + (w ? '+22 win' : '−23 loss') + ' (by contribution)', r);
    }
    const mes = await Promise.all(ps.map((p, i) => p.c.wait('me', m => m.acc.cal === 1, 3000, em[i])));
    check(mes.every((m, i) => m && m.acc.rating === rated[i].new && m.acc.games === 1 && m.acc.wins === (found[i].you === 0 ? 1 : 0) && m.acc.losses === (found[i].you === 0 ? 0 : 1)), 'fresh me after rating: rating, games, wins/losses, cal', mes.map(m => m && m.acc));
    const mi = rated.map((r, i) => ps[i].c.msgs.indexOf(r)), mei = mes.map((m, i) => ps[i].c.msgs.indexOf(m));
    check(mi.every((x, i) => x < mei[i]), 'rated comes before the fresh me');
    await sleep(1000);
    check(ps.every((p, i) => p.c.msgs.slice(em[i]).filter(m => m.t === 'rated').length === 1), 'rated sent exactly once');
    const a1 = await acc(win0[0]);
    check(a1.matches.length === 1 && a1.matches[0].kind === 'ranked' && a1.matches[0].win === 1 && a1.matches[0].delta === WIN_D && a1.matches[0].score.length === 2, 'match stored in account history', a1.matches);
    void lose0;

    // повтор: те же четверо
    const ratingNow = async () => { const o = {}; for (const p of ps) o[p.name] = (await acc(p)).rating; return o; };
    const calNow = async () => { const o = {}; for (const p of ps) o[p.name] = (await acc(p)).cal; return o; };
    function expectDeltas(q, before, cals, winSquad, leavers) {
      const sq = [0, 1].map(s => ps.filter((p, i) => q.found[i].you === s));
      const avg = sq.map(l => l.reduce((t, p) => t + before[p.name], 0) / l.length);
      const out = {};
      ps.forEach((p, i) => {
        const s = q.found[i].you, left = leavers.includes(p);
        const d = left ? LEAVE_D : winSquad == null ? DRAW_D : s === winSquad ? WIN_D : LOSS_D;
        void avg; void cals;
        out[p.name] = Math.max(0, before[p.name] + d) - before[p.name];
      });
      return out;
    }

    console.log('== ranked: leaver penalty (one player leaves, team still wins)');
    let before = await ratingNow(), cals = await calNow();
    let q = await queue(ps, 'ranked');
    check(q.joined.every(j => j && j.ranked === 'ranked'), 'second match started');
    const sq0 = ps.filter((p, i) => q.found[i].you === 0);
    const leaver = sq0[0], stayer = sq0[1];
    let lm = ps.map(p => p.c.mark());
    leaver.c.send({ t: 'leave' });
    await sleep(1200);
    check(!stayer.c.evs(lm[ps.indexOf(stayer)]).some(e => e[0] === 'mend'), 'no forfeit while a teammate remains');
    stayer.c.send({ t: '__test', op: 'end', squad: 0 });
    let rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 3000, lm[i])));
    let exp = expectDeltas(q, before, cals, 0, [leaver]);
    check(ps.every((p, i) => rr[i] && rr[i].delta === exp[p.name]), 'deltas: winner +22, losers −23, leaver −50', [rr.map(r => r && r.delta), exp]);
    check(rr[ps.indexOf(leaver)].win === 0 && rr[ps.indexOf(stayer)].win === 1, 'leaver win 0 although team won', rr[ps.indexOf(leaver)]);
    const la = await acc(leaver), lastM = la.matches[la.matches.length - 1];
    check(lastM.win === 0 && lastM.delta === exp[leaver.name], 'leaver: match stored as a loss', lastM);

    console.log('== ranked: forfeit (whole team leaves)');
    before = await ratingNow(); cals = await calNow();
    q = await queue(ps, 'ranked');
    const sq1 = ps.filter((p, i) => q.found[i].you === 1), sq0b = ps.filter((p, i) => q.found[i].you === 0);
    lm = ps.map(p => p.c.mark());
    sq1[0].c.send({ t: 'leave' });
    await sleep(300);
    check(!sq0b[0].c.evs(lm[ps.indexOf(sq0b[0])]).some(e => e[0] === 'mend'), 'not over after first leaves');
    sq1[1].c.send({ t: 'leave' });
    const fe = await sq0b[0].c.waitEv('mend', null, 2000, lm[ps.indexOf(sq0b[0])]);
    check(fe && fe[1] === 0, 'forfeit: remaining team wins immediately', fe);
    check(!!sq0b[0].c.evs(lm[ps.indexOf(sq0b[0])]).find(e => e[0] === 'sys' && /техническая победа/.test(e[1])), 'forfeit system message');
    rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 3000, lm[i])));
    exp = expectDeltas(q, before, cals, 0, sq1);
    check(ps.every((p, i) => rr[i] && rr[i].delta === exp[p.name]), 'forfeit deltas: leavers −50, winners +22', [rr.map(r => r && r.delta), exp]);

    console.log('== ranked: disconnect hold, resume, forfeit after hold expires');
    before = await ratingNow(); cals = await calNow();
    q = await queue(ps, 'ranked');
    const code4 = q.joined[0].code;
    const A0 = ps.filter((p, i) => q.found[i].you === 0), B1 = ps.filter((p, i) => q.found[i].you === 1);
    const nid = q.joined[ps.indexOf(A0[0])].you;
    const dm = A0[1].c.mark();
    A0[0].c.close();
    await sleep(1500);
    check(!A0[1].c.evs(dm).some(e => e[0] === 'mend'), 'disconnect is not a leave (held)');
    check(A0[1].c.last('roster').list.some(r => r[0] === nid), 'disconnected player stays in roster while held');
    const c2 = await reconnect(A0[0]);
    const rm = c2.mark();
    c2.send({ t: 'join', code: code4, resume: 1 });
    const rj = await c2.wait('joined', null, 3000, rm);
    check(rj && rj.resumed === 1 && rj.you === nid && rj.ranked === 'ranked', 'resumed into ranked room with same player', rj);
    lm = ps.map(p => p.c.mark());
    for (const p of B1) p.c.close();
    await sleep(HOLD - 1500);
    check(!A0[1].c.evs(lm[ps.indexOf(A0[1])]).some(e => e[0] === 'mend'), 'held players count as present until hold expires');
    const he = await A0[1].c.waitEv('mend', null, 4000, lm[ps.indexOf(A0[1])]);
    check(he && he[1] === 0, 'hold expired → forfeit, team 0 wins', he);
    const r4 = await Promise.all(A0.map(p => p.c.wait('rated', null, 3000, lm[ps.indexOf(p)])));
    exp = expectDeltas(q, before, cals, 0, B1);
    check(r4.every((r, i) => r && r.delta === exp[A0[i].name]), 'winners rated', r4);
    await sleep(500);
    for (const p of B1) {
      const a = await acc(p);
      check(a.rating === before[p.name] + exp[p.name] && a.matches[a.matches.length - 1].win === 0, p.name + ' (offline leaver) rated −' + -exp[p.name], [a.rating, before[p.name], exp[p.name]]);
    }
    for (const p of B1) await reconnect(p);

    console.log('== ranked: found player disconnects before start');
    before = await ratingNow(); cals = await calNow();
    const fm = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    const f5 = await Promise.all(ps.map((p, i) => p.c.wait('rq_found', null, 4000, fm[i])));
    const gone = ps.find((p, i) => f5[i].you === 1);
    gone.c.close();
    const others = ps.filter(p => p !== gone);
    const j5 = await Promise.all(others.map(p => p.c.wait('joined', null, 6000, fm[ps.indexOf(p)])));
    check(j5.every(j => j && j.ranked === 'ranked'), 'match still starts without the absent player');
    await sleep(500);
    const r5 = others[0].c.last('roster').list;
    check(r5.length === 3, 'roster has 3 players', r5.length);
    check(others[0].c.evs(fm[ps.indexOf(others[0])]).some(e => e[0] === 'sys' && /не пришёл/.test(e[1])), 'system message: не пришёл');
    const q5 = { found: f5 };
    lm = ps.map(p => p.c.mark());
    others[0].c.send({ t: '__test', op: 'end', squad: 1 });
    await Promise.all(others.map(p => p.c.wait('rated', null, 3000, lm[ps.indexOf(p)])));
    await sleep(300);
    exp = expectDeltas(q5, before, cals, 1, [gone]);
    const ga = await acc(gone);
    check(ga.rating === before[gone.name] + exp[gone.name] && exp[gone.name] < 0, 'absent player: −50 although team won', [ga.rating, before[gone.name], exp[gone.name]]);
    await reconnect(gone);
    const cal5 = await calNow();
    check(Object.values(cal5).every(x => x === 5), 'calibration counted up to 5 after 5 matches', cal5);

    console.log('== leaderboard');
    const lbm = p1.c.mark();
    await sleep(2100);
    p1.c.send({ t: 'lb' });
    const lb = await p1.c.wait('lb', null, 2000, lbm);
    const sorted = lb && lb.players.every((x, i) => i === 0 || lb.players[i - 1].rating >= x.rating);
    check(lb && lb.players.length === 4 && sorted && lb.players.every(x => 'nick' in x && 'rating' in x && 'wins' in x && 'losses' in x && 'tag' in x && 'color' in x && x.num >= 2 && x.av && 'p' in x.av && Array.isArray(x.eq)) && Array.isArray(lb.clans), 'lb: calibrated players sorted by rating', lb);
    const alb = await adm.get('leaderboard');
    check(alb.data.players.length === 4 && alb.data.players[0].acc && 'cal' in alb.data.players[0], 'admin leaderboard players', alb.data.players[0]);
    // после 5 калибровочных матчей K = 32
    before = await ratingNow(); cals = await calNow();
    q = await queue(ps, 'ranked');
    lm = ps.map(p => p.c.mark());
    p1.c.send({ t: '__test', op: 'end', squad: null });
    rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 3000, lm[i])));
    exp = expectDeltas(q, before, cals, null, []);
    check(ps.every((p, i) => rr[i] && rr[i].delta === exp[p.name] && rr[i].win === 0.5 && rr[i].cal === 5), 'draw: S=0.5, −3 for an empty match', [rr.map(r => r && r.delta), exp]);

    console.log('== ranked: halftime side swap, result by score');
    before = await ratingNow(); cals = await calNow();
    q = await queue(ps, 'ranked');
    lm = ps.map(p => p.c.mark());
    p1.c.send({ t: '__test', op: 'half' });
    const hr = await p1.c.wait('roster', m => true, 2000, lm[0]);
    await sleep(300);
    const rosH = p1.c.last('roster').list;
    check(hr && ps.every((p, i) => rosH.find(x => x[0] === q.joined[i].you)[2] === 1 - q.found[i].you), 'after halftime every player is on the other side', rosH.map(x => x.slice(0, 3)));
    p1.c.send({ t: '__test', op: 'score', sc: [3, 7] });   // сторона 1 (теперь состав 0) ведёт 7:3
    await sleep(100);
    p1.c.send({ t: '__test', op: 'end' });
    rr = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 3000, lm[i])));
    exp = expectDeltas(q, before, cals, 0, []);
    check(ps.every((p, i) => rr[i] && rr[i].win === (q.found[i].you === 0 ? 1 : 0) && rr[i].delta === exp[p.name]), 'winner by score maps side → squad after the swap', rr.map(r => r && r.win));
    const s0 = ps.find((p, i) => q.found[i].you === 0), hm = (await acc(s0)).matches;
    check(JSON.stringify(hm[hm.length - 1].score) === '[7,3]', 'stored score is [own squad, opponents]', hm[hm.length - 1].score);

    console.log('== ranked: whole team absent at start → immediate forfeit');
    before = await ratingNow(); cals = await calNow();
    const am = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    const f7 = await Promise.all(ps.map((p, i) => p.c.wait('rq_found', null, 4000, am[i])));
    const absent = ps.filter((p, i) => f7[i].you === 1), stay = ps.filter((p, i) => f7[i].you === 0);
    for (const p of absent) p.c.close();
    const j7 = await Promise.all(stay.map(p => p.c.wait('joined', null, 6000, am[ps.indexOf(p)])));
    check(j7.every(j => j && j.ranked === 'ranked'), 'present team still gets joined');
    const m7 = await stay[0].c.waitEv('mend', null, 2000, am[ps.indexOf(stay[0])]);
    check(m7 && m7[1] === 0, 'immediate forfeit win for the present team', m7);
    const r7 = await Promise.all(stay.map(p => p.c.wait('rated', null, 3000, am[ps.indexOf(p)])));
    exp = expectDeltas({ found: f7 }, before, cals, 0, absent);
    check(r7.every((r, i) => r && r.win === 1 && r.delta === exp[stay[i].name]), 'present team rated as winners', r7);
    await sleep(300);
    for (const p of absent) { const a = await acc(p); check(a.rating === before[p.name] + exp[p.name], p.name + ' absent → leaver penalty', [a.rating, before[p.name], exp[p.name]]); }
    for (const p of absent) await reconnect(p);

    console.log('== ranked room closes ~20 s after the match');
    s = await adm.get('state');
    check(s.data.rooms.some(r => r.code === q.joined[0].code && r.over), 'room still open right after the end (over)');
    const left = 21500 - (Date.now() - tEnd);
    if (left > 0) await sleep(left);
    s = await adm.get('state');
    check(!s.data.rooms.some(r => r.code === code), 'first ranked room closed ~20 s after matchEnd', s.data.rooms.map(r => r.code));

    console.log('== clan wars');
    const mkClan = async (leader, name, tag) => { leader.c.send({ t: 'clan_create', name, tag, color: '#3ee08f', open: true }); const ok = await leader.c.wait('clan_ok'); return ok.id; };
    const [ka1, ka2, ka3, kb1, kb2] = await Promise.all(['Волк1', 'Волк2', 'Волк3', 'Лис1', 'Лис2'].map(player));
    const KA = await mkClan(ka1, 'Волки', 'WLF');
    const KB = await mkClan(kb1, 'Лисы', 'FOX');
    for (const [p, id] of [[ka2, KA], [ka3, KA], [kb2, KB]]) { p.c.send({ t: 'clan_join', id }); await p.c.wait('clan_ok'); }
    const nm = g.c.mark();
    g.c.send({ t: 'rq', kind: 'cw' });
    check((await g.c.wait('rq_err', null, 2000, nm))?.m === 'Клановая война — только для участников клана', 'cw queue without clan → rq_err');
    // одного клана мало
    const sm = [ka1, ka2, ka3].map(p => p.c.mark());
    for (const p of [ka1, ka2, ka3]) { p.c.send({ t: 'rq', kind: 'cw' }); await sleep(20); }
    await sleep(2500);
    check([ka1, ka2, ka3].every((p, i) => !p.c.msgs.slice(sm[i]).some(m => m.t === 'rq_found')), 'same clan is never matched against itself');
    check(ka1.c.last('rq').kind === 'cw' && ka1.c.last('rq').n === 3, 'cw queue status');
    const offm = ka3.c.mark();
    ka3.c.send({ t: 'clan_leave' });
    const off = await ka3.c.wait('rq', m => m.st === 'off', 2000, offm);
    check(off && off.kind === 'cw', 'leaving the clan removes you from the cw queue (st off)', off);
    const cwPs = [ka1, ka2, kb1, kb2];
    const cm = cwPs.map(p => p.c.mark());
    for (const p of [kb1, kb2]) { p.c.send({ t: 'rq', kind: 'cw' }); await sleep(20); }
    const cf = await Promise.all(cwPs.map((p, i) => p.c.wait('rq_found', null, 4000, cm[i])));
    check(cf.every(f => f && f.kind === 'cw' && ['villa', 'lagoon', 'caldera'].includes(f.map)), 'cw rq_found to all 4');
    check(cf[0].teams.every(t => t[0].tag === t[1].tag) && new Set(cf[0].teams.map(t => t[0].tag)).size === 2, 'teams = clans (same tag within a team)', cf[0].teams);
    check(cwPs.every((p, i) => cf[0].teams[cf[i].you][0].tag === (i < 2 ? 'WLF' : 'FOX')), 'you = own clan team');
    const cj = await Promise.all(cwPs.map((p, i) => p.c.wait('joined', null, 6000, cm[i])));
    check(cj.every(j => j && j.ranked === 'cw' && j.code === cj[0].code), 'joined with ranked:"cw"');
    s = await adm.get('state');
    check(s.data.rooms.find(r => r.code === cj[0].code).kind === 'clan', 'admin state kind "clan" for clan war');
    const wSquad = cf[0].you;     // побеждают Волки
    lm = cwPs.map(p => p.c.mark());
    ka1.c.send({ t: '__test', op: 'end', squad: wSquad });
    const cr = await Promise.all(cwPs.map((p, i) => p.c.wait('rated', null, 3000, lm[i])));
    check(cr.every((r, i) => r && r.kind === 'cw' && r.win === (i < 2 ? 1 : 0) && r.clanDelta === (i < 2 ? 25 : 0)), 'rated cw: winners +25, losers 0 (pts can not go below 0)', cr);
    await sleep(200);
    check(ka1.c.last('me').acc.medals.includes('cw_win') && ka2.c.last('me').acc.medals.includes('cw_win') && !kb1.c.last('me').acc.medals.includes('cw_win') && ka1.c.last('me').acc.medals.includes('clan_leader'), 'winners of a clan war get «cw_win», losers do not');
    let clA = (await adm.get('clan?id=' + KA)).data, clB = (await adm.get('clan?id=' + KB)).data;
    check(clA.pts === 25 && clA.wins === 1 && clA.losses === 0 && clB.pts === 0 && clB.losses === 1, 'clan pts/wins/losses after first war', [clA.pts, clA.wins, clB.pts, clB.losses]);
    // вторая война — побеждают Лисы: у Волков −10
    const cm2 = cwPs.map(p => p.c.mark());
    for (const p of cwPs) { p.c.send({ t: 'rq', kind: 'cw' }); await sleep(20); }
    const cf2 = await Promise.all(cwPs.map((p, i) => p.c.wait('rq_found', null, 4000, cm2[i])));
    await Promise.all(cwPs.map((p, i) => p.c.wait('joined', null, 6000, cm2[i])));
    lm = cwPs.map(p => p.c.mark());
    ka1.c.send({ t: '__test', op: 'end', squad: cf2[2].you });
    const cr2 = await Promise.all(cwPs.map((p, i) => p.c.wait('rated', null, 3000, lm[i])));
    check(cr2.every((r, i) => r && r.clanDelta === (i < 2 ? -10 : 25)), 'second war: losers −10, winners +25', cr2.map(r => r && r.clanDelta));
    clA = (await adm.get('clan?id=' + KA)).data; clB = (await adm.get('clan?id=' + KB)).data;
    check(clA.pts === 15 && clA.losses === 1 && clB.pts === 25 && clB.wins === 1, 'clan pts after second war', [clA.pts, clB.pts]);
    const wa = (await acc(ka1)), wb = (await acc(kb1));
    check(wa.cw === 1 && wb.cw === 1, 'members cw counters', [wa.cw, wb.cw]);
    check(wa.rating === 1000 && wa.games === 0, 'clan war does not change player rating', [wa.rating, wa.games]);
    const lbm2 = ka1.c.mark();
    await sleep(2100);
    ka1.c.send({ t: 'lb' });
    const lb2 = await ka1.c.wait('lb', null, 2000, lbm2);
    check(lb2.clans[0].tag === 'FOX' && lb2.clans[0].pts === 25 && lb2.clans[1].tag === 'WLF', 'lb clans sorted by pts', lb2.clans);
    const mm = ka1.c.mark();
    ka1.c.send({ t: 'clan', id: KA });
    const view = await ka1.c.wait('clan', null, 2000, mm);
    check(view.clan.members.find(m => m.acc === ka1.acc.id).cw === 1, 'clan member list shows cw');
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  const errs = srv.logs.filter(l => /\[room|\[msg\]|\[mm\]|uncaught|Error/.test(l));
  check(errs.length === 0, 'no server errors in log', errs.slice(0, 5));
  await srv.stop();
  process.exit(summary('ranked'));
})();
