'use strict';
// Сохранение data/db.json: отложенная атомарная запись (переживает даже SIGKILL через несколько секунд), сохранение при SIGTERM,
// после перезапуска — номера ID продолжаются, рейтинг/награды/медали, бан, клан, сообщение дня, неподтверждённый подарок (тот же id).
const fs = require('fs');
const path = require('path');
const { sleep, check, summary, startServer, adminSession, client, newAcc } = require('./lib');

(async () => {
  let srv = await startServer({ env: { SZ_RANKED_WARM_S: '0' } });
  const dir = srv.dir, ADMIN_FILE = srv.env.ADMIN_FILE;
  const restart = async (sig) => { await srv.stop(sig); srv = await startServer({ dataDir: dir, env: { ADMIN_FILE, SZ_RANKED_WARM_S: '0' } }); return adminSession(srv); };
  try {
    let adm = await adminSession(srv);
    const owner = newAcc('Владелец'), p2 = newAcc('Игрок Два'), bad = newAcc('Нарушитель');
    const o = await client(srv.url, { name: 'Владелец', acc: owner });
    const b = await client(srv.url, { name: 'Два', acc: p2 });
    const x = await client(srv.url, { name: 'Нарушитель', acc: bad });
    check(owner.num === 2 && p2.num === 3 && bad.num === 4, 'numbers 2, 3, 4', [owner.num, p2.num, bad.num]);
    let r = await adm.post('setnum', { acc: owner.id, num: 1 });
    check(r.data.ok && r.data.num === 1, 'owner gets №1');
    await adm.post('medal', { acc: owner.id, id: 'owner', on: true });
    await adm.post('rating', { acc: p2.id, rating: 1555, cal: 5 });
    o.send({ t: 'clan_create', name: 'Основатели', tag: 'PS', color: '#ff5a1f', emblem: 2, open: true, desc: 'клан владельца' });
    await o.wait('clan_ok');
    await adm.post('motd', { text: 'Добро пожаловать в 2.0' });
    await adm.post('ban', { acc: bad.id, hours: 0, reason: 'читы' });
    await x.waitClose(3000);
    b.close(); await sleep(200);
    await adm.post('gift', { num: p2.num, coins: 300 });
    o.close(); await sleep(200);
    console.log('== SIGKILL after the debounce delay: data already on disk');
    await sleep(3000);
    check(fs.existsSync(path.join(dir, 'db.json')), 'db.json written within ~2 s of a change (no shutdown needed)');
    adm = await restart('SIGKILL');
    let d = JSON.parse(fs.readFileSync(path.join(dir, 'db.json'), 'utf8'));
    check(!fs.existsSync(path.join(dir, 'db.json.tmp')), 'no tmp file left (atomic rename)');
    const gid = Object.values(d.accounts).find(a => a.num === 3).gifts[0].id;
    check(typeof gid === 'string' && gid.length > 6, 'pending gift stored with its id', gid);
    console.log('== after restart');
    const o2 = await client(srv.url, { name: 'Владелец', acc: owner });
    const me = await o2.wait('me');
    check(me && me.acc.num === 1 && me.acc.medals.includes('owner') && me.acc.clan && me.acc.clan.tag === 'PS' && me.acc.clan.role === 'leader', 'owner: №1, medal, clan leader', me && me.acc);
    check(o2.last('welcome').motd === 'Добро пожаловать в 2.0', 'motd kept');
    const b2 = await client(srv.url, { name: 'Два', acc: p2, giftOk: false });
    const me2 = await b2.wait('me'), gift = await b2.wait('gift');
    check(me2 && me2.acc.rating === 1555 && me2.acc.cal === 5, 'rating/cal kept', me2 && me2.acc);
    check(gift && gift.id === gid && gift.coins === 300, 'unacknowledged gift comes with the same id', gift);
    const x2 = await client(srv.url, { name: 'Нарушитель', acc: bad });
    const be = await x2.wait('err', m => m.code === 'ban', 2000);
    check(be && /навсегда/.test(be.m) && /читы/.test(be.m), 'ban kept', be);
    const n5 = newAcc('Новенький');
    await client(srv.url, { name: 'Новенький', acc: n5 });
    check(n5.num === 5, 'numbering continues after restart (5)', n5.num);
    r = await adm.get('bans');
    check(r.data.list.length === 1 && r.data.list[0].reason === 'читы', 'admin bans list kept', r.data);
    console.log('== SIGTERM saves pending changes immediately');
    await adm.post('rating', { acc: p2.id, rating: 1777 });
    adm = await restart('SIGTERM');
    d = JSON.parse(fs.readFileSync(path.join(dir, 'db.json'), 'utf8'));
    check(Object.values(d.accounts).find(a => a.num === 3).rating === 1777, 'change made right before SIGTERM is saved');
    check(srv.logs.some(l => /db loaded: 4 accounts, 1 clans/.test(l)), 'db loaded log line', srv.logs.filter(l => /db/.test(l)));
    check(fs.existsSync(path.join(dir, 'db.prev.json')), 'previous good copy kept (db.prev.json)');
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  await srv.stop();
  process.exit(summary('persist'));
})();
