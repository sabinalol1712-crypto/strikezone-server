'use strict';
// «Рейтинг 2×2» (2.0) целиком через 4 WebSocket-клиента: очередь → rq_found → разминка (g.wu 3 → 1, 16000 $, покупка где угодно)
// → чистый старт матча (раунд 1, заморозка, 800 $, счёт 0:0) → конец → rated / reward / медали рангов;
// техническое поражение (оба соперника вышли), не пришедший игрок, возвращение после обрыва, второй телефон того же аккаунта.
// Разминка укорочена: SZ_RANKED_WARM_S=3.
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');

// 2.5: рейтинг по вкладу (матч без убийств): победа +22, поражение −23, вышел −50 — см. test/ranked.js
const rkD = (S) => (S === 1 ? 22 : S === 0 ? -23 : -3);
const WARM = 3;

(async () => {
  const srv = await startServer({ env: { SZ_RANKED_WARM_S: String(WARM), SZ_RANKED_HOLD_MS: '4000', SZ_RANKED_CLOSE_S: '3' } });
  const url = srv.url;
  const adm = await adminSession(srv);
  const snaps = new Map();       // клиент → все снимки
  function track(c) { const l = []; snaps.set(c, l); c.ws.addEventListener('message', (e) => { try { const m = JSON.parse(e.data); if (m.t === 'snap') l.push(m); } catch (er) { } }); return c; }
  async function player(name) {
    const p = { name, acc: newAcc(), key: 'k' + rnd(15) };
    p.c = track(await client(url, { name, acc: p.acc, key: p.key }));
    await p.c.wait('me');
    return p;
  }
  async function reconnect(p, key) { p.c = track(await client(url, { name: p.name, acc: p.acc, key: key || p.key })); await p.c.wait('me'); return p.c; }
  const accOf = async (p) => (await adm.get('player?acc=' + p.acc.id)).data;
  async function queue(ps) {
    const marks = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    const found = await Promise.all(ps.map((p, i) => p.c.wait('rq_found', null, 5000, marks[i])));
    return { found, marks };
  }
  const joinedOf = (ps, q) => Promise.all(ps.map((p, i) => p.c.wait('joined', m => !!m.ranked, 7000, q.marks[i])));

  try {
    const ps = await Promise.all(['Альфа', 'Браво', 'Чарли', 'Дельта'].map(player));
    // перед матчем: рейтинг 1600, калибровка 4/5 — после матча калибровка закончится и придут награды за ранги
    for (const p of ps) await adm.post('rating', { acc: p.acc.id, rating: 1600, cal: 4 });

    console.log('== match 1: queue → found → warm-up → match → end');
    let q = await queue(ps);
    check(q.found.every(f => f && f.kind === 'ranked' && ['villa', 'lagoon', 'ruins'].includes(f.map)), 'rq_found: kind ranked, map from the ranked pool', q.found[0] && q.found[0].map);
    check(q.found.every(f => f.map === q.found[0].map), 'same map for all four');
    const tm = q.found[0].teams;
    check(tm.length === 2 && tm.every(t => t.length === 2) && tm.flat().every(x => x.num > 1 && typeof x.nick === 'string' && x.rating === 1600 && x.cal === 4 && 'tag' in x && 'color' in x && x.av && x.av.p === 0),
      'teams: {num, nick, rating, cal, tag, color, av}', tm);
    let joined = await joinedOf(ps, q);
    check(joined.every(j => j && j.ranked === 'ranked' && j.mode === 'tdm' && j.rmode === 'bomb' && j.pvp === 1 && j.map === q.found[0].map && j.code === joined[0].code && j.pub === false),
      'joined: ranked, warm-up (mode tdm, rmode bomb, pvp 1), private', joined[0]);
    check(joined.every((j, i) => j.team === q.found[i].you), 'joined.team = rq_found.you');
    const code1 = joined[0].code;
    const sys1 = await ps[0].c.waitEv('sys', e => /Разминка 3 секунд/.test(e[1]), 2000, q.marks[0]);
    check(!!sys1, 'warm-up announced in chat', sys1);
    await sleep(500);
    let sn = snaps.get(ps[0].c).filter(s => s.g.wu);
    check(sn.length > 3 && sn.every(s => s.g.wu[0] === 4 && s.g.wu[1] === 4 && s.g.wu[2] >= 1 && s.g.wu[2] <= WARM), 'snap g.wu = [4, 4, secondsLeft ≤ 3]', sn[0] && sn[0].g.wu);
    const me0 = ps[0].c.snap.me;
    check(me0.$ === 16000 && me0.buy === 1 && ps[0].c.snap.g.m === 'tdm', 'warm-up: money 16000, buy open (me.buy = 1), TDM', [me0.$, me0.buy, ps[0].c.snap.g.m]);
    // покупка где угодно: снайперская винтовка — в слот, деньги снова 16000
    ps[0].c.send({ t: 'buy', id: 'sniper' });
    ps[0].c.send({ t: 'buy', id: 'knife' });          // не из магазина — игнор
    ps[0].c.send({ t: 'buy', id: '__proto__' });
    await sleep(250);
    check(ps[0].c.snap.me.sl.primary && ps[0].c.snap.me.sl.primary[0] === 'sniper', 'buy during warm-up works anywhere', ps[0].c.snap.me.sl.primary);
    await sleep(700);
    check(ps[0].c.snap.me.$ === 16000, 'money refilled to 16000 during warm-up', ps[0].c.snap.me.$);
    // конец разминки → матч
    const mst = await ps[0].c.waitEv('mstart', e => e[1] === 'bomb', 5000, q.marks[0]);
    check(mst && mst[3] === 0 && mst[2] === q.found[0].map, 'after the warm-up: mstart bomb (not warm)', mst);
    sn = snaps.get(ps[0].c).filter(s => s.g.wu).map(s => s.g.wu[2]);
    check(sn.length && sn[sn.length - 1] === 1 && sn.every((v, i) => !i || v <= sn[i - 1]), 'warm-up countdown goes down to 1', [sn[0], sn[sn.length - 1]]);
    await sleep(400);
    const s1 = ps[0].c.snap;
    check(s1.g.m === 'bomb' && s1.g.r === 1 && s1.g.ph === 'freeze' && s1.g.sc[0] === 0 && s1.g.sc[1] === 0 && !s1.g.wu && s1.g.win === 9 && s1.g.max === 16, 'clean start: round 1, freeze, score 0:0, WIN 9 / MAX 16, no wu', s1.g);
    check(s1.me.$ === 800 && s1.me.k === 0 && s1.me.d === 0 && (!s1.me.sl.primary), 'start money 800, kills reset, warm-up weapons gone', [s1.me.$, s1.me.k, s1.me.sl.primary]);
    check(!!(await ps[0].c.wait('team', null, 2000, q.marks[0])), 'team message at the match start');
    check(!!(await ps[1].c.waitEv('sys', e => /Рейтинговый матч 2 на 2/.test(e[1]), 2000, q.marks[1])), 'match announced');
    ps[0].c.send({ t: 'buy', id: 'ar' });
    // посторонний не войдёт; quick не выберет
    const g = await client(url, { name: 'Гость' });
    const gm = g.mark();
    g.send({ t: 'join', code: code1 });
    check((await g.wait('err', null, 2000, gm))?.m === 'Это рейтинговый матч', 'outsider cannot join');
    g.close();
    // конец: побеждает состав 0
    const mk = ps.map(p => p.c.mark());
    const before = await Promise.all(ps.map(accOf));
    ps[0].c.send({ t: '__test', op: 'end', squad: 0 });
    const rated = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 4000, mk[i])));
    const S = (i) => (q.found[i].you === 0 ? 1 : 0);
    check(rated.every((r, i) => r && r.kind === 'ranked' && r.win === S(i) && r.old === 1600 && r.delta === rkD(S(i)) && r.new === 1600 + r.delta && r.cal === 5), 'rated: +22 / −23 by contribution, cal 5', rated);
    const rew = ps.map((p, i) => p.c.msgs.slice(mk[i]).filter(m => m.t === 'reward'));
    const want = (r) => { let i = 0; const RK = [0, 700, 775, 850, 925, 1000, 1075, 1150, 1225, 1300, 1375, 1450, 1525, 1625, 1725, 1850, 2000, 2200]; for (let k = 0; k < RK.length; k++) if (r >= RK[k]) i = k; return i; };
    const COINS = [20, 25, 30, 35, 45, 50, 55, 60, 70, 75, 80, 85, 90, 100, 115, 125, 140, 220];
    check(rew.every((l, i) => l.length === want(rated[i].new) + 1 && l.every((m, k) => m.rank === k && m.coins === COINS[k] && /Новый ранг «.+»: \+\d+ монет/.test(m.m))), 'rank rewards for every rank up to the new one', rew.map(l => l.length));
    const meAfter = await Promise.all(ps.map((p, i) => p.c.wait('me', m => m.acc.cal === 5, 3000, mk[i])));
    check(meAfter.every(m => m && ['r_bronze', 'r_silver', 'r_gold', 'r_phoenix'].every(x => m.acc.medals.includes(x)) && m.acc.rewards.length === 13 && m.acc.peak === 12), 'r_* medals and rewards in me', meAfter[0] && meAfter[0].acc);
    const after = await Promise.all(ps.map(accOf));
    check(after.every((a, i) => a.wins === before[i].wins + S(i) && a.losses === before[i].losses + 1 - S(i) && a.matches.length === 1), 'wins/losses/matches recorded');
    const mend = await ps[2].c.waitEv('mend', null, 2000, mk[2]);
    check(mend && mend[3] === 0, 'mend (not forfeit)', mend);
    await sleep(3600);
    const st = await adm.get('state');
    check(!st.data.rooms.some(r => r.code === code1), 'ranked room closed after RANKED_CLOSE_S');

    console.log('== match 2: forfeit — both opponents leave');
    q = await queue(ps);
    joined = await joinedOf(ps, q);
    await ps[0].c.waitEv('mstart', e => e[1] === 'bomb', 6000, q.marks[0]);
    const r0 = await Promise.all(ps.map(accOf));
    const sq1 = ps.filter((p, i) => q.found[i].you === 1), sq0 = ps.filter((p, i) => q.found[i].you === 0);
    const mk2 = ps.map(p => p.c.mark());
    for (const p of sq1) { p.c.send({ t: 'leave' }); await sleep(100); }
    const fm = await sq0[0].c.waitEv('mend', null, 3000, mk2[ps.indexOf(sq0[0])]);
    check(fm && fm[3] === 1 && fm[1] === joined[ps.indexOf(sq0[0])].team, 'mend forfeit, winner = staying squad', fm);
    const rt = await Promise.all(ps.map((p, i) => p.c.wait('rated', null, 4000, mk2[i])));
    const rr = (p) => r0[ps.indexOf(p)].rating;
    check(sq1.every(p => { const r = rt[ps.indexOf(p)]; return r && r.win === 0 && r.left === 1 && r.delta === Math.max(-rr(p), -50); }), 'leavers: −50', sq1.map(p => rt[ps.indexOf(p)]));
    check(sq0.every(p => { const r = rt[ps.indexOf(p)]; return r && r.win === 1 && r.delta === 22; }), 'stayers win +22', sq0.map(p => rt[ps.indexOf(p)]));

    console.log('== match 3: drop during warm-up, back via quick; second device; rq while in the match');
    await sleep(3500);
    q = await queue(ps);
    joined = await joinedOf(ps, q);
    const code3 = joined[0].code;
    ps[0].c.close();
    await sleep(400);
    await reconnect(ps[0]);
    const mk3 = ps[0].c.mark();
    ps[0].c.send({ t: 'quick', mode: 'tdm' });          // свежий запуск игры: «Быстрая игра» — а матч не доигран
    const back = await ps[0].c.wait('joined', null, 3000, mk3);
    check(back && back.code === code3 && back.ranked === 'ranked' && back.resumed === 1, 'held player pressing quick returns into the ranked match', back);
    check(!!(await ps[0].c.waitEv('sys', e => /вернулись/.test(e[1]), 2000, mk3)), 'told why');
    // второй телефон того же аккаунта (другой ключ устройства) не может параллельно играть в обычной комнате
    const dev2 = await client(url, { name: ps[1].name, acc: ps[1].acc, key: 'k' + rnd(15) });
    await dev2.wait('me');
    const dm = dev2.mark();
    dev2.send({ t: 'quick', mode: 'tdm' });
    const de = await dev2.waitAny(['err', 'joined'], 3000, dm);
    check(de && de.t === 'err' && de.code === 'ranked' && /другом устройстве/.test(de.m), 'second device: casual refused while the account plays ranked', de);
    dev2.send({ t: 'rq', kind: 'ranked' });
    check((await dev2.wait('rq_err', null, 2000, dm))?.m.includes('другом устройстве'), 'second device: rq refused too');
    dev2.close();
    const pm = ps[2].c.mark();
    ps[2].c.send({ t: 'rq', kind: 'ranked' });
    check((await ps[2].c.wait('rq_err', null, 2000, pm))?.m === 'Вы уже в рейтинговом матче', 'rq inside the running ranked match → rq_err');
    // не вернулся: место ждёт 4 с, потом игрок считается вышедшим
    await ps[0].c.waitEv('mstart', e => e[1] === 'bomb', 6000, mk3);
    const lone = ps[3];
    lone.c.close();
    await sleep(5500);
    const s3 = await adm.get('state');
    const room3 = s3.data.rooms.find(r => r.code === code3);
    check(room3 && room3.players.length === 3, 'hold expired: 3 seats left', room3 && room3.players.map(x => x.nick));
    await reconnect(lone);
    const mkL = lone.c.mark();
    ps[0].c.send({ t: '__test', op: 'end', squad: 0 });
    const rt3 = await lone.c.wait('rated', null, 4000, mkL);
    check(rt3 && rt3.win === 0 && rt3.delta < 0, 'player who did not come back: rated as left (−50) even when reconnected later', rt3);

    console.log('== match 4: a found player is gone before the start');
    await sleep(3500);
    const marks = ps.map(p => p.c.mark());
    for (const p of ps) { p.c.send({ t: 'rq', kind: 'ranked' }); await sleep(30); }
    const f4 = await Promise.all(ps.map((p, i) => p.c.wait('rq_found', null, 5000, marks[i])));
    check(f4.every(Boolean), 'found 4');
    ps[3].c.close();
    const j4 = await Promise.all(ps.slice(0, 3).map((p, i) => p.c.wait('joined', m => !!m.ranked, 7000, marks[i])));
    check(j4.every(j => j && j.mode === 'tdm'), 'match starts with three (warm-up)');
    const nc = await ps[0].c.waitEv('sys', e => /не пришёл/.test(e[1]), 6000, marks[0]);
    check(!!nc, 'the missing player is named when the match starts', nc);
    await ps[0].c.waitEv('mstart', e => e[1] === 'bomb', 6000, marks[0]);
    await sleep(400);
    const s4 = ps[0].c.snap;
    check(s4 && s4.g.m === 'bomb' && !s4.g.over, 'match runs (other squad still has a player)', s4 && s4.g);
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  const errs = srv.logs.filter(l => /\[room|\[msg|\[uncaught|\[unhandled|\[close/.test(l));
  check(!errs.length, 'no server errors in the log', errs.slice(0, 5));
  await srv.stop();
  process.exit(summary('ranked2'));
})();
