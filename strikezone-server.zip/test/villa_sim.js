'use strict';
// «Вилла» 1.6 без сети: разминка (возрождение ~2 с, без счёта), матч только из людей, техническая победа; другие карты — как раньше.
// node test/villa_sim.js
const { createSim } = require('../sim/loader');
let errors = 0, fail = 0;
const origErr = console.error;
console.error = (...a) => { errors++; origErr(...a); };
const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };
const dt = 1 / 30;
const run = (G, sec, each) => { for (let i = 0; i < sec / dt; i++) { G.events.length = 0; if (G.game.over) break; G.game.step(dt); if (each) each(G.events); } };

{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'bomb', map: 'villa', size: 2, noBots: true, warm: true });
  ok('warm-up runs as TDM without bots', g.mode === 'tdm' && g.actors.length === 0 && g.warm && g.respawnDelay === 2);
  const a = g.addHuman('A', { side: 'ct', prim: 'm4s', drops: 1 }), b = g.addHuman('B', { side: 'auto', prim: 'sniper' });
  ok('two humans, no bots', g.actors.length === 2 && a.team === 0 && b.team === 1 && a.alive && b.alive);
  ok('warm loadout', a.slots.primary.id === 'm4s' && b.slots.primary.id === 'ar' && a.armor === 100 && a.helmet && b.slots.secondary.id === 'pistol' && !(a.nades.he || a.nades.flash || a.nades.smoke));
  run(G, 1.8); // защита после появления
  b.damage(500, a, 'm4s', true, null);
  ok('kill in warm-up: no team score', !b.alive && g.scores[0] === 0 && a.kills === 1);
  run(G, 1.5); ok('dead 1.5 s later', !b.alive);
  run(G, 0.7); ok('respawned after ~2 s', b.alive && b.hp === 100);
  for (let i = 0; i < 40; i++) { run(G, 1.7); b.damage(500, a, 'm4s', true, null); run(G, 2.1); }
  ok('40 warm-up kills never end the match', !g.over && g.scores[0] === 0);
  const c = g.addHuman('C', {}), d = g.addHuman('D', { side: 't' });
  ok('4 humans, 5th refused', g.actors.length === 4 && !g.addHuman('E', {}));
  // настоящий матч
  g.start({ mode: 'bomb', map: 'villa', size: 2, noBots: true });
  ok('match: bomb, 4 humans, 2/2', g.mode === 'bomb' && !g.warm && g.actors.length === 4 && g.teamCount(0) === 2 && g.teamCount(1) === 2 && g.respawnDelay === 4);
  ok('match: kills/money reset', g.actors.every(x => x.kills === 0 && x.money === 800) && G.bombMode.round === 1);
  let rounds = 0; run(G, 140, (ev) => { for (const [t] of ev) if (t === 'roundStart') rounds++; });
  ok('bomb rounds advance', rounds >= 1 && G.bombMode.round >= 2, 'round ' + G.bombMode.round);
  // уходит вся команда T → бота нет, техническая победа CT
  for (const x of g.actors.filter(x => x.team === 1)) g.removeHuman(x);
  ok('no bot replaces leavers', g.actors.length === 2 && g.actors.every(x => x.net));
  G.events.length = 0;
  g.endMatch({ win: 0, forfeit: true });
  const me = G.events.find(e => e[0] === 'matchEnd');
  ok('forfeit: CT wins, score shows it', me && me[1].win === 0 && me[1].forfeit && me[1].sc[0] > me[1].sc[1], JSON.stringify(me && me[1]));
  g.start({ mode: 'bomb', map: 'villa', size: 2, noBots: true, warm: true });
  ok('back to warm-up with 2', g.mode === 'tdm' && g.warm && g.actors.length === 2 && g.actors.every(x => x.alive));
}
{
  // TDM-матч на «Вилле» без ботов
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'villa', size: 2, noBots: true, warm: true });
  for (const n of ['A', 'B', 'C', 'D']) g.addHuman(n, {});
  g.start({ mode: 'tdm', map: 'villa', size: 2, noBots: true });
  ok('villa TDM match: 4 humans, counts score', g.mode === 'tdm' && !g.warm && g.actors.length === 4);
  const [a] = g.actors, e = g.actors.find(x => x.team !== a.team);
  run(G, 1.8);
  e.damage(500, a, 'ar', true, null);
  ok('TDM kill scores', g.scores[a.team] === 1);
  run(G, 30);
  ok('TDM match runs', !g.over || g.over);
}
{
  // «Порт» как раньше: боты заполняют, вышедшего заменяет бот
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'bomb', map: 'harbor', size: 5 });
  const p = g.addHuman('P', { drops: 1 });
  ok('harbor: 10 actors with bots', g.actors.length === 10 && g.actors.filter(x => !x.net).length === 9);
  g.removeHuman(p);
  ok('harbor: bot replaces leaver', g.actors.length === 10 && g.actors.every(x => !x.net));
  run(G, 90);
}
ok('no exceptions', errors === 0, errors);
console.log(fail ? 'FAILED ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
