'use strict';
// Общие помощники автотестов: свой сервер на свободном порту с временной папкой данных, клиенты, проверки.
const { spawn } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');

const ROOT = path.join(__dirname, '..');
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let passed = 0, failed = 0;
function check(cond, label, extra) {
  if (cond) { passed++; console.log('  ok  ', label); }
  else { failed++; console.log('  FAIL', label, extra !== undefined ? JSON.stringify(extra) : ''); }
  return !!cond;
}
function summary(name) {
  console.log(`\n${name}: ${passed} passed, ${failed} failed`);
  return failed ? 1 : 0;
}
// временные папки тестов: SZ_TEST_TMP (по умолчанию — системная временная папка)
function tmpDir(tag) {
  const base = process.env.SZ_TEST_TMP || process.env.TMPDIR || os.tmpdir();
  try { fs.mkdirSync(base, { recursive: true }); } catch (e) { }
  return fs.mkdtempSync(path.join(base, 'sz-' + tag + '-'));
}
// свободный порт из разрешённого диапазона (SZ_TEST_PORTS=8095-8099; общий сервер разработки — чужие порты не трогаем)
function portFree(p) { return new Promise((ok) => { const s = net.createServer(); s.once('error', () => ok(false)); s.listen(p, '127.0.0.1', () => s.close(() => ok(true))); }); }
async function freePort() {
  const [a, b] = String(process.env.SZ_TEST_PORTS || '8095-8099').split('-').map(Number);
  for (let tries = 0; tries < 40; tries++) {
    for (let p = a; p <= (b || a); p++) if (await portFree(p)) return p;
    await sleep(250);
  }
  throw new Error('no free port in ' + a + '-' + b);
}
// версия игры, которую присылают тестовые клиенты (игра 2.0)
const CV = 200;
// тестовый пароль админа (настоящий admin.json не трогаем)
const ADMIN_PASS = 'test-admin-pass-42';
function makeAdminFile(dir, hexSalt) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(ADMIN_PASS, hexSalt ? Buffer.from(salt, 'hex') : salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  const f = path.join(dir, 'test-admin.json');
  fs.writeFileSync(f, JSON.stringify({ algo: 'scrypt', N: 16384, r: 8, p: 1, keylen: 64, salt, hash }));
  return f;
}

async function startServer(opts) {
  opts = opts || {};
  const port = opts.port || await freePort();
  const dir = opts.dataDir || tmpDir('data');
  const env = Object.assign({}, process.env, { PORT: String(port), DATA_DIR: dir, SZ_TEST_HOOKS: '1', SZ_REG_PER_HOUR: '1000', SZ_MIN_CV: '200', SZ_ROOMS_PER_IP: '1000' }, opts.env || {});
  if (!env.ADMIN_FILE) env.ADMIN_FILE = makeAdminFile(dir);
  const proc = spawn(process.execPath, [path.join(ROOT, 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  const logs = [];
  const onData = (d) => { for (const l of String(d).split('\n')) if (l) logs.push(l); if (opts.verbose) process.stdout.write('[srv] ' + d); };
  proc.stdout.on('data', onData); proc.stderr.on('data', onData);
  const t0 = Date.now();
  while (!logs.some(l => l.includes(' on port '))) {
    if (proc.exitCode != null || Date.now() - t0 > 15000) { try { proc.kill('SIGKILL'); } catch (e) { } throw new Error('server did not start: ' + logs.join('\n')); }
    await sleep(50);
  }
  const base = 'http://127.0.0.1:' + port;
  return {
    port, dir, env, proc, logs, base, url: 'ws://127.0.0.1:' + port + '/ws',
    async stop(sig) {
      if (proc.exitCode != null) return;
      proc.kill(sig || 'SIGTERM');
      for (let i = 0; i < 100 && proc.exitCode == null; i++) await sleep(50);
      if (proc.exitCode == null) proc.kill('SIGKILL');
    },
    async http(method, p, body, headers) {
      const r = await fetch(base + p, { method, headers: Object.assign(body ? { 'Content-Type': 'application/json' } : {}, headers || {}), body: body == null ? undefined : typeof body === 'string' ? body : JSON.stringify(body) });
      const text = await r.text();
      let data = null; try { data = JSON.parse(text); } catch (e) { }
      return { status: r.status, headers: r.headers, data, text };
    }
  };
}

// admin API с токеном
async function adminSession(srv, xff) {
  const r = await srv.http('POST', '/admin/api/login', { password: ADMIN_PASS }, { 'X-Forwarded-For': xff || '10.9.9.9' });
  if (r.status !== 200) throw new Error('admin login failed ' + r.status + ' ' + r.text);
  const h = { Authorization: 'Bearer ' + r.data.token };
  return {
    token: r.data.token, exp: r.data.exp,
    get: (p) => srv.http('GET', '/admin/api/' + p, null, h),
    post: (p, b) => srv.http('POST', '/admin/api/' + p, b || {}, h)
  };
}

const ABC = 'abcdefghijklmnopqrstuvwxyz0123456789';
const rnd = (n, abc) => { let s = ''; for (let i = 0; i < n; i++) s += (abc || ABC)[Math.floor(Math.random() * (abc || ABC).length)]; return s; };
// Описание будущего аккаунта: его регистрирует client(), когда видит acc без id (после этого в объекте появятся id, key, num).
// nick — желаемый ник (по умолчанию — имя клиента), pass — пароль
function newAcc(nick, pass) { return { nick: nick || null, pass: pass || 'pass-' + rnd(8), id: null, key: null, num: 0 }; }
// из произвольного имени — допустимый ник сервера (3–16 символов, есть буква)
function nickOf(name) {
  let n = String(name || '').replace(/[^\p{L}\p{N} _-]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 12);
  if (Array.from(n).length < 3 || !/\p{L}/u.test(n)) n = (n + 'Игрок').slice(0, 8);
  return n;
}

// игровой клиент: копит сообщения, ждёт нужное
function client(url, o) {
  o = o || {};
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    const c = {
      ws, msgs: [], closed: null, name: o.name || 'Тест',
      send(m) { if (ws.readyState === 1) ws.send(JSON.stringify(m)); },
      all(t) { return c.msgs.filter(m => m.t === t); },
      last(t) { const l = c.all(t); return l[l.length - 1]; },
      // ждать сообщение типа t (и условия), пришедшее после позиции from
      async wait(t, pred, timeout, from) {
        const t0 = Date.now();
        for (; ;) {
          const m = c.msgs.slice(from || 0).find(x => x.t === t && (!pred || pred(x)));
          if (m) return m;
          if (Date.now() - t0 > (timeout || 5000)) return null;
          await sleep(20);
        }
      },
      mark() { return c.msgs.length; },
      evs(from) { const out = []; for (const m of c.msgs.slice(from || 0)) if (m.t === 'ev') out.push(...m.l); return out; },
      async waitEv(kind, pred, timeout, from) {
        const t0 = Date.now();
        for (; ;) {
          const e = c.evs(from).find(x => x[0] === kind && (!pred || pred(x)));
          if (e) return e;
          if (Date.now() - t0 > (timeout || 5000)) return null;
          await sleep(20);
        }
      },
      async waitClose(timeout) { const t0 = Date.now(); while (c.closed == null && Date.now() - t0 < (timeout || 5000)) await sleep(20); return c.closed; },
      async waitAny(types, timeout, from) {
        const t0 = Date.now();
        for (; ;) {
          const m = c.msgs.slice(from || 0).find(x => types.includes(x.t));
          if (m) return m;
          if (Date.now() - t0 > (timeout || 8000)) return null;
          await sleep(20);
        }
      },
      // «сырые» запросы: ответ reg_ok / reg_err и login_ok / login_err
      async regRaw(nick, pass) { const mk = c.mark(); c.send({ t: 'reg', nick, pass }); return c.waitAny(['reg_ok', 'reg_err'], 8000, mk); },
      async loginRaw(who, pass) { const mk = c.mark(); c.send({ t: 'login', who, pass }); return c.waitAny(['login_ok', 'login_err'], 8000, mk); },
      // регистрация аккаунта по описанию из newAcc(); при занятом нике подбирает другой
      async register(spec, hint) {
        let nick = spec.nick || nickOf(hint);
        for (let i = 0; i < 6; i++) {
          const mk = c.mark();
          c.send({ t: 'reg', nick, pass: spec.pass });
          const m = await c.waitAny(['reg_ok', 'reg_err'], 8000, mk);
          if (m && m.t === 'reg_ok') { spec.id = m.id; spec.key = m.key; spec.num = m.num; spec.nick = m.nick; c.num = m.num; c.accSpec = spec; return m; }
          if (!m || !/занят/.test(m.m)) throw new Error('registration failed: ' + JSON.stringify(m));
          nick = nick.slice(0, 12) + rnd(3);
        }
        throw new Error('registration: no free nick');
      },
      hello(extra) {
        const h = { t: 'hello', v: 1, cv: o.cv !== undefined ? (o.cv === null ? undefined : o.cv) : CV, name: c.name, key: o.key || ('k' + rnd(15)), prim: 'ar', skins: {}, knife: ['knife', null, 0] };
        if (o.acc && o.acc.id) h.acc = { id: o.acc.id, key: o.acc.key };
        c.send(Object.assign(h, extra || {}));
      },
      close() { try { ws.close(); } catch (e) { } }
    };
    ws.onmessage = (e) => {
      let m; try { m = JSON.parse(e.data); } catch (er) { return; }
      if (m.t !== 'snap') c.msgs.push(m); else c.snap = m;
      // как игра 2.0: подарок зачислен — подтверждаем (giftOk: false — не подтверждать, для проверки повторной доставки)
      if (m.t === 'gift' && o.giftOk !== false && ws.readyState === 1) ws.send(JSON.stringify({ t: 'gift_ok', id: m.id }));
    };
    ws.onclose = (e) => { c.closed = e.code; };
    ws.onerror = () => { };
    ws.onopen = async () => {
      if (o.noHello) { resolve(c); return; }
      c.hello();
      // ответ: welcome, либо ошибка (бан) с закрытием
      const t0 = Date.now();
      while (!c.msgs.some(m => m.t === 'welcome' || m.t === 'err') && c.closed == null && Date.now() - t0 < 5000) await sleep(10);
      if (o.acc && !o.acc.id) {
        try { await c.register(o.acc, c.name); } catch (e) { reject(e); return; }
        await c.waitAny(['me'], 3000);
      }
      if (o.ready !== false) c.send({ t: 'list' });   // как настоящий клиент после входа
      resolve(c);
    };
    setTimeout(() => reject(new Error('connect timeout')), 8000);
  });
}
// зарегистрировать аккаунт отдельным коротким подключением; возвращает {id, key, num, nick, pass}
async function makeAcc(url, nick, pass) {
  const spec = newAcc(nick, pass);
  const c = await client(url, { name: nick || 'Тестер', noHello: false, ready: false });
  await c.register(spec, nick || 'Тестер');
  c.close();
  await sleep(50);
  return spec;
}
module.exports = { CV, freePort, sleep, check, summary, tmpDir, startServer, adminSession, client, newAcc, nickOf, makeAcc, makeAdminFile, ADMIN_PASS, rnd, ROOT };
