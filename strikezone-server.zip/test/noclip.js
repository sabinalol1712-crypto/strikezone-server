'use strict';
// 2.8: noclip разработчика — сервер пропускает полёт (nc:1) только аккаунтам с медалью «Владелец»/«Разработчик»
const L = require('./lib');
const { check, summary, sleep } = L;
(async () => {
  const srv = await L.startServer();
  const url = srv.url;
  try {
    const dev = L.newAcc('Девелопер'), usr = L.newAcc('Обычный');
    const D = await L.client(url, { name: 'Девелопер', acc: dev });
    const U = await L.client(url, { name: 'Обычный', acc: usr });
    const adm = await L.adminSession(srv);
    const r = await adm.post('medal', { acc: dev.id, id: 'dev', on: true });
    check(r.status === 200 && r.data.medals.includes('dev'), 'admin: выдана медаль «Разработчик»', r.data);
    // переподключение разработчика: медаль читается при входе в комнату из аккаунта
    D.close(); await sleep(100);
    const D2 = await L.client(url, { name: 'Девелопер', acc: dev });
    const me = await D2.wait('me', m => m.acc && m.acc.medals && m.acc.medals.includes('dev'), 4000);
    check(!!me, 'me приходит с медалью dev', me && me.acc.medals);
    D2.send({ t: 'create', mode: 'tdm', map: 'ruins', size: 2 });
    const jd = await D2.wait('joined', null, 5000);
    check(!!jd, 'комната создана', jd && jd.code);
    U.send({ t: 'join', code: jd.code });
    const ju = await U.wait('joined', null, 5000);
    check(!!ju, 'обычный вошёл');
    await sleep(600);
    const snapOf = (c, nid) => { const s = c.snap; if (!s) return null; const a = s.a.find(x => x[0] === nid); return a; };
    const meOf = (c) => c.snap && c.snap.me;
    // стартовые позиции
    let t0 = Date.now(); while ((!meOf(D2) || !meOf(U)) && Date.now() - t0 < 4000) await sleep(50);
    const d0 = meOf(D2), u0 = meOf(U);
    check(!!d0 && !!u0, 'снимки с me', { d0: !!d0, u0: !!u0 });
    const fly = (c, m, y, nc) => c.send({ t: 'st', p: [m.x, y, m.z], v: [0, 0, 0], yw: m.yw || 0, pt: 0, cr: 0, ct: 0, og: 0, sc: 0, u: 0, cur: 'primary', nc: nc ? 1 : 0 });
    // разработчик с nc:1 поднимается на 30 м — сервер принимает (другой игрок видит его на высоте)
    for (let i = 0; i < 12; i++) { fly(D2, d0, 30, true); await sleep(60); }
    await sleep(300);
    const dv = snapOf(U, jd.you);
    check(dv && Math.abs(dv[2] - 30) < 0.01, 'dev noclip: y=30 принят сервером (виден другому)', dv && dv.slice(0, 4));
    // тот же полёт без флага nc — отклоняется (возврат к честной позиции)
    const mkD = meOf(D2);
    for (let i = 0; i < 12; i++) { fly(D2, mkD, 55, false); await sleep(60); }
    await sleep(300);
    const dv2 = snapOf(U, jd.you);
    check(dv2 && Math.abs(dv2[2] - 55) > 1, 'dev без nc: y=55 отклонён (стены/потолок как у всех)', dv2 && dv2.slice(0, 4));
    // обычный игрок с nc:1 — отклоняется
    for (let i = 0; i < 12; i++) { fly(U, u0, 30, true); await sleep(60); }
    await sleep(300);
    const uv = snapOf(D2, ju.you);
    check(uv && Math.abs(uv[2] - 30) > 1, 'обычный с nc:1: полёт отклонён', uv && uv.slice(0, 4));
    // границы: разработчик за пределами карты на 20 м — отклоняется
    const far = Object.assign({}, meOf(D2), { x: 200, z: 200 });
    for (let i = 0; i < 6; i++) { fly(D2, far, 5, true); await sleep(60); }
    await sleep(300);
    const dv3 = snapOf(U, jd.you);
    check(dv3 && Math.abs(dv3[1] - 200) > 50, 'dev noclip за границей карты отклонён', dv3 && dv3.slice(0, 4));
    D2.close(); U.close();
  } finally { srv.stop(); }
  process.exit(summary('noclip'));
})().catch(e => { console.error(e); process.exit(1); });
