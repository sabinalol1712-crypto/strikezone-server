'use strict';
// Испорченные сообщения: мусор вместо JSON, неверные типы и длины, «__proto__», огромные строки, все типы сообщений —
// в меню и внутри комнат всех видов (5×5 с ботами, бомба, дуэль, 2×2 только игроки, рейтинговый матч на разминке и в матче).
// Сервер не должен упасть, комнаты продолжают считать матч, обычный игрок после этого играет; админ-API отвечает 4xx, а не 500.
const { sleep, check, summary, startServer, adminSession, client, newAcc, rnd } = require('./lib');

const TYPES = ['hello', 'quick', 'create', 'join', 'leave', 'list', 'st', 'shot', 'mel', 'nade', 'rl', 'buy', 'prim', 'take', 'toss', 'chat', 'ping', 'probe',
  'rq', 'rq_leave', 'lb', 'gift_ok', 'clans', 'clan', 'clan_create', 'clan_join', 'clan_join_code', 'clan_leave', 'clan_kick', 'clan_role', 'clan_edit', 'clan_disband', 'clan_say',
  'reg', 'login', 'logout', 'nick', 'av', 'avatar', 'medals', '__test', 'toString', '__proto__', 'constructor', ''];
const FIELDS = ['t', 'p', 'v', 'yw', 'pt', 'cr', 'ct', 'og', 'sc', 'u', 'cur', 's', 'w', 'o', 'd', 'lag', 'type', 'id', 'm', 'team', 'c', 'n', 'code', 'mode', 'map', 'size', 'diff', 'side',
  'kind', 'q', 'name', 'tag', 'color', 'emblem', 'open', 'desc', 'acc', 'role', 'newcode', 'nick', 'pass', 'who', 'data', 'num', 'eq', 'local', 'cv', 'key', 'skins', 'knife', 'gloves', 'prim', 'drops', 'op', 'sc', 'squad'];
const big = 'Ж'.repeat(6000);
const VALUES = [null, true, false, 0, -1, 1, 3, 1e308, -1e308, 0.5, 2 ** 53, '', 'x', 'primary', 'secondary', 'melee', 'nade', 'he', 'ar', 'sniper', 'knife', 'villa', 'lagoon', 'winter',
  'bomb', 'duel', 'tdm', 'ranked', 'cw', '__proto__', 'constructor', 'toString', 'prototype', big, [], {}, [1, 2], [1, 2, 3], ['a', 'b', 'c'], [1e308, -1e308, 1e308], [null, null, null],
  { __proto__: { polluted: 1 } }, { id: 'a123', key: 'x' }, { x: { y: { z: [] } } }, Array(80).fill(0.1), 'data:image/jpeg;base64,/9j/' + 'A'.repeat(100)];
const pick = (a) => a[Math.floor(Math.random() * a.length)];
function randomMsg() {
  const m = { t: pick(TYPES) };
  const n = Math.floor(Math.random() * 6);
  for (let i = 0; i < n; i++) m[pick(FIELDS)] = pick(VALUES);
  if (Math.random() < 0.3) m.t = pick(TYPES);
  return m;
}
function rawGarbage() {
  return pick(['', '{', 'null', '[]', '"str"', '123', '{"t":', '{"t":null}', '{"t":{}}', '{"t":[]}', '{"t":"' + 'x'.repeat(100) + '"}', '\u0000\u0001\u0002',
    '['.repeat(5000) + ']'.repeat(5000), '{"t":"st","p":[1,2,3],"__proto__":{"alive":false}}', '{"t":"shot","s":"__proto__","w":null,"o":[0,0,0],"d":[]}',
    '{"t":"st","p":[0,0,0],"cur":"__proto__"}', '{"t":"rl","s":"__proto__"}', '{"t":"buy","id":"constructor"}', '{"t":"toss","s":"constructor"}',
    JSON.stringify({ t: 'chat', m: 'x'.repeat(30000) })]);
}

(async () => {
  const srv = await startServer({ env: { SZ_RANKED_WARM_S: '6', SZ_CONN_PER_IP: '60' } });
  const url = srv.url;
  try {
    const adm = await adminSession(srv);
    console.log('== rooms of every kind');
    // наблюдатели — нормальные игроки в каждой комнате
    const obs = {};
    obs.tdm = await client(url, { name: 'Набл1' }); obs.tdm.send({ t: 'create', mode: 'tdm', map: 'harbor', size: 5 });
    obs.bomb = await client(url, { name: 'Набл2' }); obs.bomb.send({ t: 'create', mode: 'bomb', map: 'sakura', size: 5 });
    obs.duel = await client(url, { name: 'Набл3' }); obs.duel.send({ t: 'create', mode: 'duel' });
    obs.pvp = await client(url, { name: 'Набл4' }); obs.pvp.send({ t: 'quick', mode: 'bomb', map: 'villa' });
    const codes = {};
    for (const k of Object.keys(obs)) { const j = await obs[k].wait('joined', null, 4000); codes[k] = j && j.code; }
    check(Object.values(codes).every(Boolean), 'casual rooms created', codes);
    // рейтинговый матч из четырёх «хулиганов»
    const rk = await Promise.all([1, 2, 3, 4].map(i => client(url, { name: 'Хулиган' + i, acc: newAcc() })));
    for (const c of rk) { await c.wait('me'); c.send({ t: 'rq', kind: 'ranked' }); await sleep(20); }
    const rj = await Promise.all(rk.map(c => c.wait('joined', m => !!m.ranked, 8000)));
    check(rj.every(Boolean), 'ranked match started');
    // хулиганы в обычных комнатах
    const fz = [];
    for (const k of Object.keys(codes)) for (let i = 0; i < 2; i++) { const c = await client(url, { name: 'Ф' + k + i, acc: i ? newAcc() : null }); c.send({ t: 'join', code: codes[k] }); fz.push(c); }
    const menuFz = await Promise.all([1, 2, 3].map(i => client(url, { name: 'М' + i, acc: i === 1 ? newAcc() : null })));
    await sleep(800);
    const all = fz.concat(rk, menuFz);
    console.log('== fuzzing ' + all.length + ' connections');
    const t0 = Date.now();
    let sent = 0;
    while (Date.now() - t0 < 12000) {
      for (const c of all) {
        if (c.closed != null || c.ws.readyState !== 1) continue;
        for (let k = 0; k < 6; k++) {
          const r = Math.random();
          // не выходить из комнат слишком часто — хулиганы должны оставаться внутри
          let m = r < 0.25 ? rawGarbage() : randomMsg();
          if (typeof m === 'object' && ['leave', 'quick', 'create', 'join', 'logout', 'hello'].includes(m.t) && Math.random() < 0.9) m.t = pick(['st', 'shot', 'chat', 'buy', 'nade']);
          try { c.ws.send(typeof m === 'string' ? m : JSON.stringify(m)); sent++; } catch (e) { }
        }
      }
      await sleep(70);
    }
    // отдельно: бинарный кадр и очень длинное сообщение
    try { menuFz[0].ws.send(new Uint8Array([0, 1, 2, 3, 255])); } catch (e) { }
    try { menuFz[1].ws.send('x'.repeat(70000)); } catch (e) { }
    await sleep(1500);
    console.log('   sent', sent, 'messages');
    const res = await srv.http('GET', '/');
    check(srv.proc.exitCode == null && res.status === 200 && res.data.ok, 'server alive after fuzzing', res.data);
    // комнаты продолжают считать матч: наблюдатели получают свежие снимки
    for (const k of Object.keys(obs)) {
      const s0 = obs[k].snap && obs[k].snap.s;
      await sleep(400);
      const s1 = obs[k].snap && obs[k].snap.s;
      check(obs[k].closed == null && s1 != null && s1 !== s0, 'room ' + k + ' still ticking', [s0, s1]);
    }
    const st = await adm.get('state');
    check(st.status === 200 && st.data.rooms.length >= 5, 'admin state works', st.data.rooms && st.data.rooms.map(r => r.code + ':' + r.mode));
    // нормальный игрок после всего этого: вход, матч, движение, выстрел
    const ok = await client(url, { name: 'Нормальный', acc: newAcc() });
    await ok.wait('me');
    ok.send({ t: 'quick', mode: 'tdm' });
    const oj = await ok.wait('joined', null, 3000);
    await sleep(700);
    const me = ok.snap && ok.snap.me;
    check(oj && me && me.al === 1 && me.hp === 100, 'a normal player joins and spawns after fuzzing', me);
    if (me) { ok.send({ t: 'st', p: [me.x, me.y, me.z], v: [0, 0, 0], yw: 0, pt: 0, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: 'primary' }); ok.send({ t: 'shot', s: 'primary', w: me.sl.primary[0], o: [me.x, me.y + 1.6, me.z], d: [0, 0, -1], lag: 0 }); }
    await sleep(300);
    check(ok.snap.me.sl.primary[3] === me.sl.primary[3] - 1, 'shooting still works (one bullet spent)', [me.sl.primary[3], ok.snap.me.sl.primary[3]]);
    ok.close();
    console.log('== admin API with garbage');
    const H = { Authorization: 'Bearer ' + adm.token };
    const posts = ['kick', 'ban', 'unban', 'mute', 'gift', 'rating', 'setnum', 'medal', 'avatar_reset', 'broadcast', 'motd', 'clan_edit', 'clan_delete', 'clan_kick', 'room_close', 'room_say'];
    let five = 0;
    for (const p of posts) {
      for (const body of ['{', '[]', 'null', '"x"', JSON.stringify({ acc: { a: 1 }, num: 'x', coins: [], hours: 'долго', minutes: -1, rating: 1e309, text: { t: 1 }, id: ['x'], code: 5, on: 'maybe' }), JSON.stringify({ acc: '__proto__', id: 'constructor' })]) {
        const r = await srv.http('POST', '/admin/api/' + p, body, Object.assign({ 'Content-Type': 'application/json' }, H));
        if (r.status >= 500) { five++; console.log('   500 from', p, body.slice(0, 60), r.text); }
      }
    }
    for (const g of ['player?acc=__proto__', 'player?num=-1', 'clan?id=constructor', 'players?page=-5&q=' + encodeURIComponent('%%%'), 'avatar?acc=toString', 'nothing']) {
      const r = await srv.http('GET', '/admin/api/' + g, null, H);
      if (r.status >= 500) { five++; console.log('   500 from', g, r.text); }
    }
    const huge = await srv.http('POST', '/admin/api/broadcast', JSON.stringify({ text: 'x'.repeat(20000) }), Object.assign({ 'Content-Type': 'application/json' }, H));
    check(huge.status === 413, 'admin body > 10 KB → 413', huge.status);
    check(five === 0, 'admin API never answers 500 on garbage', five);
    for (const c of all.concat(Object.values(obs))) c.close();
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  await sleep(300);
  const errs = srv.logs.filter(l => /\[room|\[msg|\[uncaught|\[unhandled|\[close|\[admin\]|\[mm\]/.test(l));
  check(!errs.length, 'no exceptions logged (every bad message rejected by validation)', errs.slice(0, 8));
  await srv.stop();
  process.exit(summary('fuzz'));
})();
