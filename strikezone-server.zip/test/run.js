'use strict';
// Все автотесты сервера по очереди: node test/run.js [имя …]   (порты 8095–8099, временные данные — SZ_TEST_TMP)
// Тесты с собственным сервером (test/lib.js) запускаются как есть; старым (smoke, resume, villa, rematch) сервер поднимается здесь.
const { spawn } = require('child_process');
const path = require('path');
const { startServer } = require('./lib');

// [файл, нужен ли отдельный сервер, переменные окружения сервера]
const TESTS = [
  ['version'], ['ops'], ['ranked_sim'], ['villa_sim'],
  ['smoke', { srv: {} }], ['resume', { srv: {} }],
  ['villa', { srv: { SZ_FAST: '1' } }],
  ['accounts'], ['profile'], ['gifts'], ['clans'], ['admin'], ['rewards'], ['modes'], ['ranked'], ['ranked2'], ['fuzz'], ['persist'],
  ['rematch', { srv: { SZ_FAST: '1' } }], ['lobby'],
  ['economy'], ['market'],   // 2.3: облачный инвентарь и рынок
  ['friends'],   // 2.4: друзья, пати «Напарники», кланы 2.4, код прицела
  ['adminskins'],   // 2.4.1: инвентарь с картинками скинов в админке
  ['rating25']   // 2.5: рейтинг по вкладу, −50 за выход, возвращение в рейтинговый матч
];

function runFile(file, args, env) {
  return new Promise((ok) => {
    const t0 = Date.now();
    const p = spawn(process.execPath, [path.join(__dirname, file + '.js')].concat(args || []), { env: Object.assign({}, process.env, env || {}), stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    p.stdout.on('data', d => { out += d; if (process.env.V) process.stdout.write(d); });
    p.stderr.on('data', d => { out += d; if (process.env.V) process.stderr.write(d); });
    const kill = setTimeout(() => { out += '\nTIMEOUT'; p.kill('SIGKILL'); }, 15 * 60000);
    p.on('exit', (code) => { clearTimeout(kill); ok({ code, out, sec: Math.round((Date.now() - t0) / 1000) }); });
  });
}

(async () => {
  const only = process.argv.slice(2);
  const list = TESTS.filter(t => !only.length || only.includes(t[0]));
  const res = [];
  for (const [name, o] of list) {
    let r;
    if (o && o.srv) {
      const srv = await startServer({ env: o.srv });
      try { r = await runFile(name, [srv.url], { PORT: String(srv.port) }); } finally { await srv.stop(); }
    } else r = await runFile(name);
    const fails = (r.out.match(/^\s*(FAIL\b|FAIL )/gm) || []).length;
    const good = r.code === 0 && !fails;
    res.push([name, good, r.sec]);
    console.log((good ? 'PASS ' : 'FAIL ') + name + ' (' + r.sec + ' s)');
    if (!good) console.log(r.out.split('\n').filter(l => /FAIL|Error|TIMEOUT|at /.test(l)).slice(0, 30).join('\n'));
  }
  const bad = res.filter(r => !r[1]);
  console.log('\n' + (bad.length ? 'FAILED: ' + bad.map(r => r[0]).join(', ') : 'ALL ' + res.length + ' TEST FILES PASSED'));
  process.exit(bad.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
