'use strict';
// 2.10 без сети: запас пути игрока (частые сообщения не дают скорость, подвисание связи терпится), шаг сквозь стену,
// заморозка у точки появления, «ведро» выстрелов, выстрел не из-за стены, перезарядка только в руках,
// выбросить бомбу (bdrop), вернувшийся в тот же раунд не убирает живого бота, разминирование не сквозь пол.
// node test/sim210.js
const { createSim } = require('../sim/loader');
let errors = 0, fail = 0;
const origErr = console.error;
console.error = (...a) => { errors++; origErr(...a); };
const ok = (n, c, i) => { console.log((c ? 'PASS ' : 'FAIL ') + n, i === undefined ? '' : i); if (!c) fail++; };
const dt = 1 / 30;
const run = (G, sec, each) => { for (let i = 0; i < Math.round(sec / dt); i++) { G.events.length = 0; if (G.game.over) break; G.game.step(dt); if (each) each(G.events); } };
const stMsg = (p, yw, cur) => ({ p, v: [0, 0, 0], yw: yw || 0, pt: 0, cr: 0, ct: 0, og: 1, sc: 0, u: 0, cur: cur || 'primary' });
// точки вдоль пути навигации с шагом s (высота — пол под ногами)
function along(G, from, to, s) {
  const pts = (G.nav.findPath(from.x, from.z, to.x, to.z) || []).concat([{ x: to.x, z: to.z }]);
  const out = []; let x = from.x, z = from.z, y = from.y || 0;
  for (const q of pts) {
    for (let n = 0; n < 2000; n++) {
      const dx = q.x - x, dz = q.z - z, d = Math.hypot(dx, dz);
      if (d < 1e-3) break;
      const k = Math.min(s, d); x += dx / d * k; z += dz / d * k;
      const fy = G.drops.floorAt(x, y + 0.5, z); if (fy != null && fy >= 0) y = fy;
      out.push([x, y, z]);
    }
  }
  return out;
}
const place = (g, a, x, y, z) => { a.pos.set(x, y, z); a.lastX = x; a.lastZ = z; a.lastStT = g.time; a.badN = 0; a.moveBud = null; a.moveBudT = g.time; };

// ---------- движение ----------
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'dust', size: 2, noBots: true });
  const a = g.addHuman('A', { side: 'ct' }), b = g.addHuman('B', { side: 't' });
  run(G, 0.5);
  const s0 = { x: a.pos.x, y: a.pos.y, z: a.pos.z }, far = { x: b.pos.x, z: b.pos.z };
  // честный бег 6,5 м/с, 30 сообщений в секунду, 3 с
  let path = along(G, s0, far, 6.5 / 30), bad = 0, i = 0;
  for (; i < Math.min(90, path.length); i++) { const q = path[i]; g.netState(a, stMsg(q)); if (Math.abs(a.pos.x - q[0]) > 1e-6 || Math.abs(a.pos.z - q[2]) > 1e-6) bad++; run(G, dt); }
  ok('honest 6.5 m/s at 30 Hz: every state accepted', bad === 0 && i >= 60, 'bad ' + bad + ' of ' + i);
  // подвисание связи 0,8 с: 24 сообщения приходят разом
  const burst = path.slice(i, i + 24); run(G, 0.8);
  for (const q of burst) g.netState(a, stMsg(q));
  const last = burst[burst.length - 1];
  ok('0.8 s lag spike then burst of 24 states: all accepted', burst.length === 24 && Math.hypot(a.pos.x - last[0], a.pos.z - last[2]) < 1e-6, a.pos.x + ',' + a.pos.z);
  // частые сообщения не дают скорость: 40 сообщений за один тик, по 1,1 м каждое
  run(G, 2); // запас полный
  const st0 = { x: a.pos.x, y: a.pos.y, z: a.pos.z };
  path = along(G, st0, far, 1.1);
  for (let k = 0; k < Math.min(40, path.length); k++) g.netState(a, stMsg(path[k]));
  const moved = Math.hypot(a.pos.x - st0.x, a.pos.z - st0.z);
  ok('message spam in one tick: at most ~6.9 m (was ~1.2 m per message)', moved <= 6.95 && moved >= 5, moved.toFixed(2) + ' m of ' + (Math.min(40, path.length) * 1.1).toFixed(1));
  // и за секунду спама — не быстрее 9,5 м/с
  const st1 = { x: a.pos.x, z: a.pos.z }; let sent = 0;
  path = along(G, { x: a.pos.x, y: a.pos.y, z: a.pos.z }, far, 0.45);
  for (let t = 0, k = 0; t < 30 && k < path.length; t++) { for (let r = 0; r < 4 && k < path.length; r++, k++) { g.netState(a, stMsg(path[k])); sent++; } run(G, dt); }
  const m2 = Math.hypot(a.pos.x - st1.x, a.pos.z - st1.z);
  ok('1 s of 4 states per tick at 13.5 m/s: server keeps ≤ 9.5 m/s (+ start reserve)', m2 <= 9.5 + 6 + 1, m2.toFixed(2) + ' m, sent ' + sent);

  // шаг сквозь тонкую стену
  let wall = null;
  for (const s of G.map.solids) {
    const tx = s.x1 - s.x0, tz = s.z1 - s.z0, h = s.y1 - s.y0;
    if (s.y0 > 0.05 || h < 2.2 || s.nr) continue;
    const thinX = tx < 0.45 && tz > 2, thinZ = tz < 0.45 && tx > 2;
    if (!thinX && !thinZ) continue;
    const cx = (s.x0 + s.x1) / 2, cz = (s.z0 + s.z1) / 2;
    const p1 = thinX ? [s.x0 - 0.42, cz] : [cx, s.z0 - 0.42], p2 = thinX ? [s.x1 + 0.42, cz] : [cx, s.z1 + 0.42];
    const f1 = G.drops.floorAt(p1[0], 0.5, p1[1]), f2 = G.drops.floorAt(p2[0], 0.5, p2[1]);
    if (f1 !== 0 || f2 !== 0 || G.insideSolid(p1[0], 0, p1[1]) || G.insideSolid(p2[0], 0, p2[1])) continue;
    wall = { s, p1, p2 }; break;
  }
  ok('found a thin wall on dust', !!wall);
  if (wall) {
    run(G, 1);
    place(g, a, wall.p1[0], 0, wall.p1[1]);
    g.netState(a, stMsg([wall.p2[0], 0, wall.p2[1]]));
    ok('step through a thin wall is refused', Math.hypot(a.pos.x - wall.p1[0], a.pos.z - wall.p1[1]) < 1e-6, 'd ' + Math.hypot(wall.p2[0] - wall.p1[0], wall.p2[1] - wall.p1[1]).toFixed(2));
    // выстрел «из-за стены»: точка выстрела по ту сторону — сервер стреляет из глаз
    const w = a.slots.primary, ey = a.pos.y + a.eyeH();
    G.events.length = 0;
    g.netShot(a, { s: 'primary', w: w.id, o: [wall.p2[0], ey, wall.p2[1]], d: [0, 0, -1], lag: 0 });
    const sh = G.events.find(e => e[0] === 'shot');
    ok('shot origin behind a wall is replaced by the eye', sh && Math.abs(sh[1].mz[0] - a.pos.x) < 0.02 && Math.abs(sh[1].mz[2] - a.pos.z) < 0.02, sh && JSON.stringify(sh[1].mz));
  }
  // «ведро» выстрелов: три в один тик проходят, четвёртый — нет; через 0,2 с — снова
  run(G, 1);
  const w = a.slots.primary; w.mag = w.def.mag; w.reloadT = 0; a.cur = 'primary';
  const shot = () => g.netShot(a, { s: 'primary', w: w.id, o: [a.pos.x, a.pos.y + a.eyeH(), a.pos.z], d: [-Math.sin(a.yaw), 0, -Math.cos(a.yaw)], lag: 0 });
  const m0 = w.mag; const r = [shot(), shot(), shot(), shot()];
  ok('fire bucket: 3 shots in one server tick accepted, 4th refused', w.mag === m0 - 3 && !!r[2] && r[3] === null, 'mag ' + m0 + '→' + w.mag);
  run(G, 0.2);
  const m1 = w.mag; shot(); shot();
  ok('fire bucket refills with time', w.mag === m1 - 2, 'mag ' + m1 + '→' + w.mag);
  // 2.10.1: у AWP запас «ведра» — один выстрел: второй в тот же тик не проходит
  {
    a.slots.primary = G.newWeaponState('sniper', null, 0); a.cur = 'primary'; run(G, 2);
    const sw = a.slots.primary, s0 = sw.mag;
    const sh = () => g.netShot(a, { s: 'primary', w: 'sniper', o: [a.pos.x, a.pos.y + a.eyeH(), a.pos.z], d: [-Math.sin(a.yaw), 0, -Math.cos(a.yaw)], lag: 0 });
    const r1 = sh(), r2 = sh();
    ok('AWP: two shots in one tick → only one accepted', !!r1 && r2 === null && sw.mag === s0 - 1, 'mag ' + s0 + '→' + sw.mag);
    run(G, 0.9); const r3 = sh();
    ok('AWP: next shot after ~0.8 s accepted', !!r3 && sw.mag === s0 - 2);
    a.slots.primary = w; a.cur = 'primary'; w.reloadT = 0;
  }
  // 2.10.1: «сменил и сразу перезарядил» — rl пришёл раньше состояния с новым оружием: перезарядка не обрывается
  {
    g.netState(a, stMsg([a.pos.x, a.pos.y, a.pos.z], a.yaw, 'secondary'));
    run(G, 0.5);
    w.mag = 3; w.reloadT = 0;
    g.netReload(a, 'primary');
    run(G, 4);
    ok('reload message makes that slot current and completes', a.cur === 'primary' && w.mag === w.def.mag, 'cur ' + a.cur + ' mag ' + w.mag);
    run(G, 1); w.mag = 25;
  }
  // перезарядка только у оружия в руках
  g.netReload(a, 'primary');
  ok('reload started', w.reloadT > 0);
  const mb = w.mag;
  g.netState(a, stMsg([a.pos.x, a.pos.y, a.pos.z], a.yaw, 'secondary'));
  run(G, 4);
  ok('switching weapon cancels the reload (no reload in the pocket)', a.cur === 'secondary' && w.reloadT === 0 && w.mag === mb, 'mag ' + w.mag + ' reloadT ' + w.reloadT);
  g.netState(a, stMsg([a.pos.x, a.pos.y, a.pos.z], a.yaw, 'primary'));
  g.netReload(a, 'primary'); run(G, 4);
  ok('reload in hands completes', w.mag === w.def.mag, 'mag ' + w.mag);
}

// ---------- заморозка: не дальше 1,2 м от точки появления ----------
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'bomb', map: 'dust', size: 2, noBots: true, warm: true });
  const t1 = g.addHuman('T1', { side: 't' }), t2 = g.addHuman('T2', { side: 't' }), c1 = g.addHuman('C1', { side: 'ct' });
  g.start({ mode: 'bomb', map: 'dust', size: 2, noBots: true });
  const B = G.bombMode;
  ok('bomb match with 3 humans, freeze', g.frozen && B.phase === 'freeze' && g.actors.length === 3);
  const sx = c1.pos.x, sz = c1.pos.z;
  let k = 0; for (; k < 10; k++) { g.netState(c1, stMsg([c1.pos.x + 0.5, c1.pos.y, c1.pos.z])); run(G, 0.1); }
  ok('freeze: creeping 0.5 m per message stops ≤ 1.2 m from spawn', Math.hypot(c1.pos.x - sx, c1.pos.z - sz) <= 1.2 + 1e-6, Math.hypot(c1.pos.x - sx, c1.pos.z - sz).toFixed(2));
  // бомба: выбросить (подбирают в бою — в заморозке никто не двигается)
  run(G, 7.2);
  ok('round is live', B.phase === 'live' && !g.frozen, B.phase);
  const car = B.bomb.carrier;
  ok('a human T carries the bomb', car === t1 || car === t2);
  const other = car === t1 ? t2 : t1;
  ok('tossBomb: dropped in front', B.tossBomb(car) && B.bomb.state === 'dropped' && !car.hasBomb && Math.hypot(B.bomb.pos.x - car.pos.x, B.bomb.pos.z - car.pos.z) <= 1.45, Math.hypot(B.bomb.pos.x - car.pos.x, B.bomb.pos.z - car.pos.z).toFixed(2));
  ok('toss twice does nothing', !B.tossBomb(car));
  car.pos.set(B.bomb.pos.x, B.bomb.pos.y, B.bomb.pos.z);
  run(G, 0.5);
  ok('the tosser does not re-pick it at once', B.bomb.state === 'dropped' && !car.hasBomb);
  run(G, 1.3);
  ok('…but picks it up after 1.5 s', B.bomb.state === 'carried' && B.bomb.carrier === car && car.hasBomb);
  B.tossBomb(car); other.pos.set(B.bomb.pos.x + 0.3, B.bomb.pos.y, B.bomb.pos.z); run(G, 0.1);
  ok('a teammate picks a tossed bomb at once', B.bomb.carrier === other && other.hasBomb);
  // разминирование: не сквозь пол / потолок
  const V3 = ctx.THREE.Vector3, z0 = G.map.spawnZones[0];
  const bx = (z0.x0 + z0.x1) / 2, bz = (z0.z0 + z0.z1) / 2;
  B.bomb = { state: 'planted', pos: new V3(bx, 0, bz), carrier: null };
  c1.pos.set(bx + 0.6, 0, bz);
  ok('canDefuse next to the bomb', B.canDefuse(c1));
  c1.pos.set(bx + 0.6, 3.2, bz);
  ok('canDefuse refused 3 m above it', !B.canDefuse(c1));
  c1.pos.set(bx + 3, 0, bz);
  ok('canDefuse refused out of reach', !B.canDefuse(c1));
}

// ---------- вернулся в тот же раунд: живого бота не убирают, лишнего — в начале следующего ----------
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'bomb', map: 'dust', size: 2 });
  const B = G.bombMode;
  const cts = () => g.actors.filter(a => a.team === 0);
  ok('bots fill both teams', cts().length === 2 && g.actors.length === 4 && g.actors.every(a => a.alive));
  const h = g.addHuman('Back', { side: 'ct', noTake: true });
  ok('rejoin (noTake) with all CT bots alive: no living bot removed', h && h.botDebt && cts().length === 3 && cts().filter(a => !a.net).every(a => a.alive), cts().length);
  const r0 = B.round;
  run(G, 8);
  for (const a of g.actors.filter(a => a.team === 1)) if (a.alive) a.damage(500, null, 'ar', true, null);
  run(G, 7);
  ok('next round: the surplus bot is gone, team is 2 again', B.round === r0 + 1 && cts().length === 2 && cts().includes(h) && !h.botDebt, 'round ' + B.round + ', CT ' + cts().length);
  // ушёл снова — его место занимает бот (команда не растёт)
  const h2 = g.addHuman('Back2', { side: 'ct', noTake: true });
  const n = cts().length; g.removeHuman(h2);
  ok('surplus rejoiner leaves: no extra bot added', cts().length === n - (h2.botDebt === false && n === 3 ? 1 : 0) && cts().length <= 3, cts().length);
}

// ---------- 2.10.1: новый матч в той же комнате (время с нуля) — запас пути пополняется как обычно ----------
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'dust', size: 2, noBots: true });
  const a = g.addHuman('A', { side: 'ct' }), b = g.addHuman('B', { side: 't' });
  run(G, 1);
  let path = along(G, { x: a.pos.x, y: a.pos.y, z: a.pos.z }, { x: b.pos.x, z: b.pos.z }, 6.5 / 30);
  for (let i = 0; i < 30 && i < path.length; i++) { g.netState(a, stMsg(path[i])); run(G, dt); }
  run(G, 40);   // время матча ушло вперёд
  g.start({ mode: 'tdm', map: 'dust', size: 2, noBots: true });   // новый матч: время снова с нуля
  run(G, 1);
  ok('rematch: both humans kept and alive', g.actors.length === 2 && a.alive && b.alive);
  path = along(G, { x: a.pos.x, y: a.pos.y, z: a.pos.z }, { x: b.pos.x, z: b.pos.z }, 6.5 / 30);
  let bad = 0, n = 0;
  for (; n < 90 && n < path.length; n++) { const q = path[n]; g.netState(a, stMsg(q)); if (Math.hypot(a.pos.x - q[0], a.pos.z - q[2]) > 1e-6) bad++; run(G, dt); }
  ok('rematch: honest running is not rubber-banded (move reserve refills)', bad === 0 && n >= 60, 'bad ' + bad + ' of ' + n);
}

// ---------- 2.10.1: гранаты — в среднем не чаще раза в 0,3 с (запас на 2 броска), в полёте не больше 40 (тренировка: бесконечные гранаты) ----------
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'nades', map: 'dust', size: 2 });
  const a = g.addHuman('A', { side: 'ct' });
  run(G, 0.5);
  const throwN = () => g.netNade(a, { type: 'he', o: [a.pos.x, a.pos.y + a.eyeH(), a.pos.z], v: [0, 6, -10] });
  const r1 = throwN(), r2 = throwN(), r3 = throwN();
  ok('grenade spam: two throws arriving together pass (network bunching), the third at once is refused', r1 === true && r2 === true && r3 === false);
  run(G, 0.34); ok('grenade: throw 0.34 s later accepted (practice re-throw every 0.45 s passes with network jitter)', throwN() === true);
  let acc = 0; for (let i = 0; i < 200; i++) { if (throwN()) acc++; run(G, 0.4); }
  ok('grenade spam: practice room keeps at most 40 grenades flying', G.nades.list.length <= 40 && acc > 50, 'list ' + G.nades.list.length + ', accepted ' + acc);
  // и полёт вверх без опоры — отвергается (высота над последней опорой)
  const y0 = a.pos.y; g.netState(a, { p: [a.pos.x, 9, a.pos.z], v: [0, 0, 0], yw: 0, pt: 0, cr: 0, ct: 0, og: 0, sc: 0, u: 0, cur: 'primary', nc: 1 });
  ok('nades practice: noclip flight still allowed', a.pos.y === 9);
}
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'dust', size: 2, noBots: true });
  const a = g.addHuman('A', { side: 'ct' });
  run(G, 0.5);
  const y0 = a.pos.y, x0 = a.pos.x, z0 = a.pos.z;
  g.netState(a, { p: [x0, y0 + 9, z0], v: [0, 0, 0], yw: 0, pt: 0, cr: 0, ct: 0, og: 0, sc: 0, u: 0, cur: 'primary' });
  ok('fly: 9 m straight up without support refused', a.pos.y === y0);
  g.netState(a, { p: [x0, y0 + 1.1, z0], v: [0, 0, 0], yw: 0, pt: 0, cr: 0, ct: 0, og: 0, sc: 0, u: 0, cur: 'primary' });
  ok('jump: 1.1 m up accepted', Math.abs(a.pos.y - (y0 + 1.1)) < 1e-6);
}

// ---------- 2.1.1/2.10.1: прыжок на край ящика — опора под всем «пятном» игрока; крышка пруда «Сакуры»; полёт над водой ----------
{
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'dust', size: 2, noBots: true });
  const a = g.addHuman('A', { side: 'ct' });
  run(G, 0.5);
  // ящик 1,0–1,5 м: встаём на самый край (центр игрока за краем на 0,2 м) и прыгаем выше — честно, не отвергается
  const b = G.map.solids.find(q => !q.nr && q.y0 < 0.05 && q.y1 > 0.95 && q.y1 < 1.5 && q.x1 - q.x0 > 0.9 && q.z1 - q.z0 > 0.9 &&
    !G.map.solids.some(o => o !== q && o.y1 > q.y1 + 0.05 && o.y0 < q.y1 + 3 && o.x1 > q.x0 - 1 && o.x0 < q.x1 + 1 && o.z1 > q.z0 - 1 && o.z0 < q.z1 + 1));
  const ex = b.x1 + 0.2, ez = (b.z0 + b.z1) / 2;
  place(g, a, ex, b.y1, ez); a.tp++;
  g.netState(a, stMsg([ex, b.y1, ez])); run(G, 0.05);
  g.netState(a, stMsg([ex, b.y1 + 1.15, ez])); run(G, 0.05);
  ok('jump from the edge of a crate (support under the foot, not under the centre) accepted', Math.abs(a.pos.y - (b.y1 + 1.15)) < 1e-6, [b.y1, a.pos.y]);
}
{
  // присед под низким навесом («Сакура»: скамья 1,05 м под навесом 3,1 м): тело пригнувшегося ниже — «в стене» не считается
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'sakura', size: 2, noBots: true });
  const a = g.addHuman('A', { side: 'ct' });
  run(G, 0.5);
  place(g, a, 14.06, 1.05, 5.91); a.tp++; a.crouchT = 1;
  g.netState(a, Object.assign(stMsg([14.06, 1.05, 5.91]), { cr: 1, ct: 1 })); run(G, 0.05);
  g.netState(a, Object.assign(stMsg([14.0, 1.6, 5.91]), { cr: 1, ct: 1, og: 0 })); run(G, 0.05);
  g.netState(a, Object.assign(stMsg([13.95, 1.84, 5.9]), { cr: 1, ct: 1, og: 0 })); run(G, 0.05);
  ok('crouch-jump under a low roof is not "inside a wall"', Math.abs(a.pos.y - 1.84) < 1e-6, a.pos.y);
  // стоя (не пригнувшись) на той же высоте голова в навесе — отвергается, как раньше
  place(g, a, 14.06, 1.05, 5.91); a.tp++; a.crouchT = 0;
  g.netState(a, stMsg([14.06, 1.05, 5.91])); run(G, 0.05);
  g.netState(a, Object.assign(stMsg([13.95, 1.84, 5.9]), { og: 0 })); run(G, 0.05);
  ok('standing body in the roof is still refused', Math.abs(a.pos.y - 1.05) < 1e-6, a.pos.y);
}
{
  // физика клиента: прыжок на край перил рядом со столбиком («Лагуна») — раньше игрока выталкивало на 8 м к дальнему концу перил
  const ctx = createSim(), G = ctx.G, g = G.game;
  g.start({ mode: 'tdm', map: 'lagoon', size: 2, noBots: true });
  run(G, 0.1);
  const V3 = ctx.THREE.Vector3;
  const c = { pos: new V3(-2.3201, 0.9822222222222227, 5.549899999999999), vel: new V3(3.360144398527037, 2.333333333333336 - 22 / 60, 4.476613836801192), radius: 0.32, height: 1.8, onGround: false };
  G.map.move(c, c.vel.x / 60, c.vel.y / 60, c.vel.z / 60);
  ok('jump onto a railing edge next to a post: no teleport along the railing', Math.hypot(c.pos.x + 2.3201, c.pos.z - 5.5499) < 0.2, c.pos.toArray().map(v => +v.toFixed(3)));
}

ok('no console errors', errors === 0, errors);
console.log(fail ? 'FAILED ' + fail : 'ALL PASSED');
process.exit(fail ? 1 : 0);
