'use strict';
// Кланы: создание и проверки, список/поиск, вступление (открытый / закрытый / по коду), роли, исключение,
// передача лидерства, выход, роспуск, чат клана, тег и цвет в составе матча.
const { sleep, check, summary, startServer, client, newAcc } = require('./lib');

(async () => {
  const srv = await startServer();
  const url = srv.url;
  const login = async (name) => { const acc = newAcc(); const c = await client(url, { name, acc }); await c.wait('me'); c.acc = acc; return c; };
  // действие → ответ clan_ok или clan_err
  // не чаще 5 действий в секунду — как живой игрок (сервер ограничивает)
  const act = async (c, msg) => {
    const gap = 210 - (Date.now() - (c.actT || 0));
    if (gap > 0) await sleep(gap);
    c.actT = Date.now();
    const mk = c.mark();
    c.send(msg);
    const t0 = Date.now();
    for (; ;) {
      const m = c.msgs.slice(mk).find(x => x.t === 'clan_ok' || x.t === 'clan_err');
      if (m) { await sleep(60); return m; }
      if (Date.now() - t0 > 3000) return null;
      await sleep(15);
    }
  };
  try {
    const L = await login('Лидер'), O = await login('Офицер'), M1 = await login('Боец1'), M2 = await login('Боец2'), X = await login('Чужой');

    console.log('== create + validation');
    let r = await act(L, { t: 'clan_create', name: 'ab', tag: 'TT' });
    check(r && r.t === 'clan_err' && /Название/.test(r.m), 'name too short rejected', r);
    r = await act(L, { t: 'clan_create', name: 'Плохое<имя>', tag: 'TT' });
    check(r && r.t === 'clan_err', 'name with bad chars rejected', r);
    r = await act(L, { t: 'clan_create', name: 'Нормальное', tag: 'T' });
    check(r && r.t === 'clan_err' && /Тег/.test(r.m), 'tag too short rejected', r);
    r = await act(L, { t: 'clan_create', name: 'Нормальное', tag: 'T-1' });
    check(r && r.t === 'clan_err' && /Тег/.test(r.m), 'tag with bad chars rejected', r);
    r = await act(L, { t: 'clan_create', name: 'Нормальное', tag: 'ABCDE' });
    check(r && r.t === 'clan_err', 'tag too long rejected', r);
    let mk = L.mark();
    r = await act(L, { t: 'clan_create', name: 'Волки Севера', tag: 'вск', color: '#2EC4FF', emblem: 5, open: true, desc: 'Лучший клан' });
    check(r && r.t === 'clan_ok' && r.m === 'Клан создан' && typeof r.id === 'string' && r.id.length === 6, 'clan_create → clan_ok with 6-char id', r);
    const cid = r.id;
    const lme = await L.wait('me', m => m.acc.clan, 2000, mk);
    check(lme && lme.acc.clan.id === cid && lme.acc.clan.tag === 'ВСК' && lme.acc.clan.name === 'Волки Севера' && lme.acc.clan.color === '#2ec4ff' && lme.acc.clan.role === 'leader', 'me after create: tag uppercased, color, role leader', lme && lme.acc.clan);
    const lcl = await L.wait('clan', null, 2000, mk);
    const order = L.msgs.slice(mk).map(m => m.t).filter(t => ['clan_ok', 'me', 'clan'].includes(t));
    check(order.join(',') === 'clan_ok,me,clan', 'order: clan_ok, me, clan', order);
    check(lcl && lcl.clan.mine === true && lcl.clan.myRole === 'leader' && /^[A-Z0-9]{6}$/.test(lcl.clan.code) && lcl.clan.members.length === 1 && lcl.clan.max === 20 && lcl.clan.emblem === 5 && lcl.clan.desc === 'Лучший клан', 'clan full for leader: mine, role, code, members', lcl && lcl.clan);
    const m0 = lcl.clan.members[0];
    check(m0.acc === L.acc.id && m0.nick === 'Лидер' && m0.role === 'leader' && m0.rating === 1000 && m0.cal === 0 && m0.online === true && m0.cw === 0, 'member entry fields', m0);
    r = await act(L, { t: 'clan_create', name: 'Ещё один', tag: 'EE' });
    check(r && r.m === 'Вы уже в клане', 'second clan → Вы уже в клане', r);
    r = await act(X, { t: 'clan_create', name: 'волки севера', tag: 'XX' });
    check(r && r.m === 'Такое название уже занято', 'duplicate name (case-insensitive)', r);
    r = await act(X, { t: 'clan_create', name: 'Другие', tag: 'Вск' });
    check(r && r.m === 'Тег занят', 'duplicate tag (case-insensitive)', r);
    r = await act(X, { t: 'clan_create', name: 'Закрытые', tag: 'ZK', open: false });
    const xid = r.id;
    check(r && r.t === 'clan_ok', 'second clan created by X');

    console.log('== list / search / view');
    mk = M1.mark(); M1.send({ t: 'clans', q: '' });
    let cl = await M1.wait('clans', null, 2000, mk);
    check(cl && cl.list.length === 2 && cl.list.every(c => 'members' in c && c.max === 20 && 'leader' in c && 'open' in c && 'emblem' in c), 'clans list (ClanShort)', cl && cl.list);
    check(cl.list.find(c => c.id === cid).leader === 'Лидер' && cl.list.find(c => c.id === cid).members === 1, 'ClanShort leader nick and member count');
    mk = M1.mark(); M1.send({ t: 'clans', q: 'вс' });
    cl = await M1.wait('clans', null, 2000, mk);
    check(cl && cl.list.length === 1 && cl.list[0].id === cid, 'search by tag substring', cl && cl.list.map(c => c.tag));
    mk = M1.mark(); M1.send({ t: 'clans', q: 'закр' });
    cl = await M1.wait('clans', null, 2000, mk);
    check(cl && cl.list.length === 1 && cl.list[0].id === xid, 'search by name substring');
    mk = M1.mark(); M1.send({ t: 'clan', id: cid });
    const view = await M1.wait('clan', null, 2000, mk);
    check(view && view.clan.mine === false && view.clan.myRole === null && !('code' in view.clan), 'non-member view: no code, mine false', view && view.clan);
    mk = M1.mark(); M1.send({ t: 'clan', id: 'nope00' });
    check((await M1.wait('clan_err', null, 2000, mk))?.m === 'Клан не найден', 'unknown clan id → Клан не найден');

    await sleep(1100);
    console.log('== join open clan');
    mk = L.mark();
    r = await act(M1, { t: 'clan_join', id: cid });
    check(r && r.t === 'clan_ok' && r.id === cid, 'join open clan', r);
    const m1me = M1.last('me');
    check(m1me.acc.clan && m1me.acc.clan.role === 'member' && m1me.acc.clan.tag === 'ВСК', 'joiner me: role member');
    const lview = await L.wait('clan', c => c.clan.members.length === 2, 2000, mk);
    check(!!lview, 'leader viewing the clan gets a fresh clan');
    r = await act(M1, { t: 'clan_join', id: xid });
    check(r && r.m === 'Вы уже в клане', 'join while in a clan → Вы уже в клане', r);

    console.log('== closed clan / codes');
    r = await act(L, { t: 'clan_edit', open: false });
    check(r && r.t === 'clan_ok', 'leader closes the clan');
    r = await act(O, { t: 'clan_join', id: cid });
    check(r && r.m === 'Клан закрыт — нужен код приглашения', 'closed clan without code', r);
    r = await act(O, { t: 'clan_join', id: cid, code: 'AAAAAA' });
    check(r && r.m === 'Неверный код', 'closed clan wrong code', r);
    const code = L.last('clan').clan.code;
    r = await act(O, { t: 'clan_join', id: cid, code: code.toLowerCase() });
    check(r && r.t === 'clan_ok', 'closed clan with correct code (case-insensitive)', r);
    r = await act(M2, { t: 'clan_join_code', code: 'ZZZZZZ' });
    check(r && r.m === 'Неверный код', 'join by unknown code', r);
    r = await act(M2, { t: 'clan_join_code', code });
    check(r && r.t === 'clan_ok' && r.id === cid, 'join by code alone', r);
    r = await act(L, { t: 'clan_edit', newcode: true });
    const code2 = L.last('clan').clan.code;
    check(r && r.t === 'clan_ok' && code2 !== code && /^[A-Z0-9]{6}$/.test(code2), 'leader regenerates invite code', [code, code2]);

    console.log('== roles / kick');
    mk = O.mark();
    r = await act(L, { t: 'clan_role', acc: O.acc.id, role: 'officer' });
    check(r && r.t === 'clan_ok', 'leader promotes officer');
    check(!!(await O.wait('me', m => m.acc.clan && m.acc.clan.role === 'officer', 2000, mk)), 'officer gets fresh me with role officer');
    r = await act(M1, { t: 'clan_role', acc: M2.acc.id, role: 'officer' });
    check(r && r.t === 'clan_err', 'member cannot change roles', r);
    r = await act(O, { t: 'clan_role', acc: M2.acc.id, role: 'officer' });
    check(r && r.t === 'clan_err', 'officer cannot change roles', r);
    r = await act(O, { t: 'clan_kick', acc: L.acc.id });
    check(r && r.m === 'Недостаточно прав', 'officer cannot kick leader', r);
    r = await act(M1, { t: 'clan_kick', acc: M2.acc.id });
    check(r && r.m === 'Недостаточно прав', 'member cannot kick', r);
    r = await act(O, { t: 'clan_edit', color: '#ff0000' });
    check(r && r.t === 'clan_err', 'officer cannot change color', r);
    r = await act(O, { t: 'clan_edit', desc: 'Описание от офицера', open: false });
    check(r && r.t === 'clan_ok' && O.last('clan').clan.desc === 'Описание от офицера', 'officer edits description (unchanged other fields allowed)', r);
    mk = M2.mark();
    r = await act(O, { t: 'clan_kick', acc: M2.acc.id });
    check(r && r.t === 'clan_ok', 'officer kicks a member', r);
    check(!!(await M2.wait('me', m => m.acc.clan === null, 2000, mk)), 'kicked member gets me with clan null');
    r = await act(L, { t: 'clan_kick', acc: L.acc.id });
    check(r && r.t === 'clan_err', 'leader cannot kick self', r);
    r = await act(L, { t: 'clan_kick', acc: X.acc.id });
    check(r && r.m === 'Игрок не в вашем клане', 'kick non-member', r);

    console.log('== leave rules / transfer');
    r = await act(L, { t: 'clan_leave' });
    check(r && r.m === 'Сначала передайте лидерство или распустите клан', 'leader cannot leave with members', r);
    const lmk = L.mark(), omk = O.mark();
    r = await act(L, { t: 'clan_role', acc: O.acc.id, role: 'leader' });
    check(r && r.t === 'clan_ok', 'leader transfers leadership');
    check(!!(await O.wait('me', m => m.acc.clan && m.acc.clan.role === 'leader', 2000, omk)), 'new leader me role leader');
    check(!!(await L.wait('me', m => m.acc.clan && m.acc.clan.role === 'officer', 2000, lmk)), 'old leader becomes officer');
    r = await act(L, { t: 'clan_leave' });
    check(r && r.t === 'clan_ok' && L.last('me').acc.clan === null, 'officer leaves', r);
    r = await act(M1, { t: 'clan_leave' });
    check(r && r.t === 'clan_ok', 'member leaves');
    r = await act(M1, { t: 'clan_leave' });
    check(r && r.m === 'Вы не в клане', 'leave when not in clan', r);

    console.log('== clan chat');
    await act(M1, { t: 'clan_join', id: cid, code: code2 });
    await act(O, { t: 'clan_edit', open: true });
    await act(L, { t: 'clan_join', id: cid });
    const before = [O, M1, L].map(c => c.mark()), xm = X.mark();
    O.send({ t: 'clan_say', m: 'Сбор в 20:00!' });
    const got = await Promise.all([O, M1, L].map((c, i) => c.wait('clan_msg', null, 2000, before[i])));
    check(got.every(g => g && g.nick === 'Офицер' && g.m === 'Сбор в 20:00!' && typeof g.ts === 'number'), 'clan_msg to all online members (incl. sender)', got);
    await sleep(200);
    check(!X.msgs.slice(xm).some(m => m.t === 'clan_msg'), 'non-members do not get clan chat');
    r = await act(O, { t: 'clan_say', m: 'спам' });
    check(r && r.t === 'clan_err', 'clan chat limited to 1 msg / 1.5 s', r);
    await sleep(1600);
    O.send({ t: 'clan_say', m: 'x'.repeat(200) });
    const long = await M1.wait('clan_msg', m => m.m.length === 90, 2000);
    check(!!long, 'clan message cut to 90 chars');
    mk = M2.mark(); M2.send({ t: 'clan', id: cid });
    const hist = await M2.wait('clan', null, 2000, mk);
    check(hist && hist.clan.chat.length === 2 && hist.clan.chat[0][1] === 'Офицер' && hist.clan.chat[0][2] === 'Сбор в 20:00!', 'chat history stored [[ts, nick, text]]', hist && hist.clan.chat);
    const om = O.mark(); mk = X.mark();
    X.send({ t: 'clan_say', m: 'привет своим' });
    check(!!(await X.wait('clan_msg', m => m.m === 'привет своим', 2000, mk)), 'other clan chat goes to its own members');
    await sleep(200);
    check(!O.msgs.slice(om).some(m => m.t === 'clan_msg'), '... and not to this clan');

    console.log('== roster tag/color');
    O.send({ t: 'create', mode: 'tdm', map: 'dust', size: 2 });
    const oj = await O.wait('joined');
    M2.send({ t: 'join', code: oj.code });
    await M2.wait('joined');
    await sleep(400);
    const ros = O.last('roster').list;
    const oRow = ros.find(x => x[1] === 'Офицер'), m2Row = ros.find(x => x[1] === 'Боец2'), bot = ros.find(x => !x[3]);
    check(oRow && oRow.length === 12 && oRow[6] === 'ВСК' && oRow[7] === '#2ec4ff' && oRow[8] >= 2 && oRow[9] && oRow[9].c === 0 && Array.isArray(oRow[10]), 'roster: net player has clan tag + color, num, av, eq', oRow);
    check(m2Row && m2Row[6] === null && m2Row[7] === null, 'roster: player without clan → null tag', m2Row);
    check(bot && bot[6] === null && bot[7] === null, 'roster: bots → null tag', bot);
    mk = O.mark();
    await act(M2, { t: 'clan_join', id: cid });
    const ros2 = await O.wait('roster', m => m.list.some(x => x[1] === 'Боец2' && x[6] === 'ВСК'), 2000, mk);
    check(!!ros2, 'roster re-sent with tag after joining a clan mid-match');

    console.log('== rate limit');
    await sleep(1100);
    mk = X.mark();
    for (let i = 0; i < 12; i++) X.send({ t: 'clans' });
    await sleep(400);
    const lim = X.msgs.slice(mk).filter(m => m.t === 'clan_err' && /Слишком часто/.test(m.m)).length, okc = X.msgs.slice(mk).filter(m => m.t === 'clans').length;
    check(okc === 5 && lim === 7, 'clan actions limited to 5/s per connection', [okc, lim]);
    await sleep(1100);

    console.log('== full clan');
    const extra = [];
    const curN = (await (async () => { mk = O.mark(); O.send({ t: 'clan', id: cid }); return (await O.wait('clan', null, 2000, mk)).clan.members.length; })());
    for (let i = curN; i < 20; i++) { const c = await login('Добор' + i); const rr = await act(c, { t: 'clan_join', id: cid }); if (rr.t !== 'clan_ok') console.log(rr); extra.push(c); }
    const late = await login('Опоздавший');
    r = await act(late, { t: 'clan_join', id: cid });
    check(r && r.m === 'В клане нет мест', 'max 20 members', r);
    for (const c of extra) c.close();

    console.log('== disband');
    const mks = [O, L, M1].map(c => c.mark());
    r = await act(L, { t: 'clan_disband' });
    check(r && r.t === 'clan_err', 'non-leader cannot disband', r);
    r = await act(O, { t: 'clan_disband' });
    check(r && r.t === 'clan_ok', 'leader disbands', r);
    const nulls = await Promise.all([O, L, M1].map((c, i) => c.wait('me', m => m.acc.clan === null, 2000, mks[i])));
    check(nulls.every(Boolean), 'all online members get me with clan null');
    mk = X.mark(); X.send({ t: 'clans' });
    cl = await X.wait('clans', null, 2000, mk);
    check(cl && !cl.list.some(c => c.id === cid), 'disbanded clan gone from list');
    // последний участник-лидер выходит — клан распускается
    r = await act(X, { t: 'clan_leave' });
    check(r && r.t === 'clan_ok' && X.last('me').acc.clan === null, 'last member (leader) leaves → clan disbanded', r);
    mk = X.mark(); X.send({ t: 'clans' });
    cl = await X.wait('clans', null, 2000, mk);
    check(cl && cl.list.length === 0, 'no clans left');
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  await srv.stop();
  process.exit(summary('clans'));
})();
