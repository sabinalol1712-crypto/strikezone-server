'use strict';
// Подарки (2.0, PROTOCOL3 §6): у каждого свой id, доставка после «me» и сразу, если игрок в сети;
// доставлен только после gift_ok (обрыв без подтверждения — придёт снова, тот же id); подарок по номеру ID;
// два телефона одного аккаунта не получают один подарок одновременно; неподтверждённый переживает перезапуск.
const { sleep, check, summary, startServer, adminSession, client, newAcc } = require('./lib');

(async () => {
  let srv = await startServer();
  const url = () => srv.url;
  try {
    let adm = await adminSession(srv);
    const acc = newAcc('Донатер');
    const a = await client(url(), { name: 'Донатер', acc, giftOk: false });
    await a.wait('me');
    console.log('== gift by number, online, without ack');
    let r = await adm.post('gift', { num: acc.num, coins: 1000 });
    check(r.status === 200 && r.data.ok && r.data.n === 1, 'admin gift {num, coins} → ok', r.data);
    const g1 = await a.wait('gift');
    check(g1 && typeof g1.id === 'string' && g1.id.length >= 8 && g1.coins === 1000 && g1.m === 'Подарок от разработчика: +1000 монет', 'online player gets {t:gift, id, coins, m} immediately', g1);
    r = await adm.post('gift', { num: 999999, coins: 5 });
    check(r.status === 404, 'unknown number → 404', r.data);
    r = await adm.post('gift', { num: acc.num, coins: 1 });
    const g2 = await a.wait('gift', m => m.coins === 1);
    check(g2 && g2.id !== g1.id && g2.m === 'Подарок от разработчика: +1 монета', 'each gift has its own id; Russian plural', g2);
    a.close(); await sleep(300);
    console.log('== not acknowledged → delivered again after reconnect (same ids), after me');
    const b = await client(url(), { name: 'Донатер', acc, giftOk: false, ready: false });
    await b.wait('me'); await sleep(150);
    const mk = b.mark();
    b.send({ t: 'list' });
    await sleep(400);
    const again = b.msgs.slice(mk).filter(m => m.t === 'gift');
    const meI = b.msgs.slice(mk).findIndex(m => m.t === 'me'), gI = b.msgs.slice(mk).findIndex(m => m.t === 'gift');
    check(again.length === 2 && again.some(g => g.id === g1.id) && again.some(g => g.id === g2.id), 'both unacknowledged gifts re-sent with the same ids', again);
    check(meI >= 0 && meI < gI, 'gifts come after me', [meI, gI]);
    let p = await adm.get('player?num=' + acc.num);
    check(p.data.gifts === 1001, 'admin player.gifts = total coins gifted', p.data.gifts);
    console.log('== ack');
    b.send({ t: 'gift_ok', id: g1.id });
    b.send({ t: 'gift_ok', id: g1.id });            // повтор — без вреда
    b.send({ t: 'gift_ok', id: 'nonexistent' });
    b.send({ t: 'gift_ok', id: { evil: 1 } });
    await sleep(300);
    b.close(); await sleep(300);
    const c = await client(url(), { name: 'Донатер', acc, giftOk: false });
    await sleep(500);
    const left = c.all('gift');
    check(left.length === 1 && left[0].id === g2.id, 'acknowledged gift never comes again, the other one does', left);
    console.log('== two devices: one gift at a time');
    const d2 = await client(url(), { name: 'Донатер', acc, key: 'kdevice2xxxxxxx', giftOk: false });
    await sleep(500);
    check(!d2.all('gift').length, 'second device does not get the gift already in flight to the first', d2.all('gift'));
    c.close(); await sleep(400);
    const moved = await d2.wait('gift', null, 2000);
    check(moved && moved.id === g2.id, 'first device gone without ack → the gift moves to the second device', moved);
    d2.send({ t: 'gift_ok', id: g2.id }); await sleep(200);
    console.log('== offline gift + restart');
    d2.close(); await sleep(300);
    r = await adm.post('gift', { acc: acc.id, coins: 250 });
    await sleep(300);
    await srv.stop();
    srv = await startServer({ dataDir: srv.dir, env: { ADMIN_FILE: srv.env.ADMIN_FILE } });
    adm = await adminSession(srv);
    const e = await client(url(), { name: 'Донатер', acc });   // подтверждает, как настоящая игра
    const g3 = await e.wait('gift', null, 3000);
    check(g3 && g3.coins === 250 && g3.m === 'Подарок от разработчика: +250 монет', 'pending gift survives a restart', g3);
    await sleep(300);
    e.close(); await sleep(300);
    const f = await client(url(), { name: 'Донатер', acc });
    await sleep(500);
    check(!f.all('gift').length, 'auto-acknowledged gift is delivered exactly once');
    console.log('== validation');
    for (const bad of [0, -5, 1.5, 'x', 1000001]) { r = await adm.post('gift', { num: acc.num, coins: bad }); check(r.status === 400, 'coins ' + JSON.stringify(bad) + ' → 400'); }
    r = await adm.post('gift', { all: true, coins: 10 });
    check(r.data.ok && r.data.n === 1, 'gift to all online accounts', r.data);
    check((await f.wait('gift', m => m.coins === 10, 2000))?.m === 'Подарок от разработчика: +10 монет', 'gift-all delivered');
    f.close();
  } catch (e) { console.error(e); check(false, 'exception: ' + e.message); }
  await srv.stop();
  process.exit(summary('gifts'));
})();
