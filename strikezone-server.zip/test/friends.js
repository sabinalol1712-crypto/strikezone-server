'use strict';
// 2.4: друзья (заявки, принятие, удаление, блок), статусы друзей (fr_up), приглашения в пати и в лобби, пати «Напарники»
// в рейтинговом поиске (одна команда, отмена у обоих), код прицела в ростере, кланы 2.4 (заявки, лента, уровень и опыт).
const { sleep, check, summary, startServer, client, newAcc } = require('./lib');

(async () => {
  const srv = await startServer({ env: { SZ_RANKED_WARM_S: '0', SZ_RANKED_HOLD_MS: '3000' } });
  const url = srv.url;
  const login = async (name, cv) => { const acc = newAcc(); const c = await client(url, { name, acc, cv: cv || 240 }); await c.wait('me'); c.acc = acc; return c; };
  const pace = async (c) => { const gap = 140 - (Date.now() - (c.actT || 0)); if (gap > 0) await sleep(gap); c.actT = Date.now(); };
  // действие → первое сообщение из types после него
  const act = async (c, msg, types, pred) => { await pace(c); const mk = c.mark(); c.send(msg); const t0 = Date.now(); for (; ;) { const m = c.msgs.slice(mk).find(x => types.includes(x.t) && (!pred || pred(x))); if (m) return m; if (Date.now() - t0 > 4000) return null; await sleep(15); } };
  try {
    const A = await login('Альфа'), B = await login('Браво'), C = await login('Чарли'), D = await login('Дельта');
    const old = await login('Старый', 230);

    console.log('== hello');
    check(A.msgs.some(m => m.t === 'fr_hi' && m.max === 100), 'cv 240 gets fr_hi with max 100');
    check(!old.msgs.some(m => m.t === 'fr_hi'), 'cv 230 (game 2.3) gets no fr_hi');
    const w = A.msgs.find(m => m.t === 'welcome');
    check(w && w.srv === '2.10.2', 'welcome srv 2.10.2', w);
    let r = await act(A, { t: 'fr_list' }, ['fr']);
    check(r && Array.isArray(r.list) && r.list.length === 0 && r.inc.length === 0 && r.out.length === 0 && r.bl.length === 0, 'empty fr list', r);
    r = await act(A, { t: 'pt_get' }, ['pt']);
    check(r && r.party === null, 'no party', r);
    const guest = await client(url, { name: 'Гость', cv: 240 });
    r = await act(guest, { t: 'fr_list' }, ['fr']);
    check(r && r.guest === 1, 'guest fr_list → guest:1', r);
    r = await act(guest, { t: 'fr_add', who: '1' }, ['fr_err']);
    check(r && /аккаунт/.test(r.m), 'guest fr_add → account error', r);

    console.log('== add / accept');
    r = await act(A, { t: 'fr_add', who: 'нет-такого-ника' }, ['fr_err', 'fr']);
    check(r && r.t === 'fr_err' && /не найден/.test(r.m), 'unknown nick → не найден', r);
    r = await act(A, { t: 'fr_add', who: String(A.acc.num) }, ['fr_err', 'fr']);
    check(r && r.t === 'fr_err' && /ваш аккаунт/.test(r.m), 'self → error', r);
    let mkB = B.mark();
    r = await act(A, { t: 'fr_add', who: '№ ' + B.acc.num }, ['fr_err', 'fr']);
    check(r && r.t === 'fr' && r.ok === 'add' && /Заявка отправлена/.test(r.m) && r.out.length === 1 && r.out[0].num === B.acc.num && r.out[0].nick === 'Браво', 'add by number → out list', r);
    const note = await B.wait('fr_note', m => m.k === 'req', 2000, mkB);
    check(note && /Альфа/.test(note.m), 'target gets fr_note req', note);
    const bfr = await B.wait('fr', m => m.inc && m.inc.length === 1, 2000, mkB);
    check(bfr && bfr.inc[0].num === A.acc.num && Array.isArray(bfr.inc[0].rank), 'target fr: incoming request with rank', bfr && bfr.inc);
    r = await act(A, { t: 'fr_add', who: 'Браво' }, ['fr_err', 'fr']);
    check(r && r.t === 'fr_err' && /уже отправлена/.test(r.m), 'duplicate request → уже отправлена', r);
    let mkA = A.mark();
    r = await act(B, { t: 'fr_ok', num: A.acc.num }, ['fr']);
    check(r && r.list.length === 1 && r.list[0].num === A.acc.num && r.list[0].st === 'menu' && r.inc.length === 0, 'B accepts: A in list, status menu', r);
    const an = await A.wait('fr_note', m => m.k === 'ok', 2000, mkA);
    check(an && /Браво/.test(an.m), 'A notified about acceptance', an);
    const afr = await A.wait('fr', m => m.list && m.list.length === 1, 2000, mkA);
    check(afr && afr.list[0].nick === 'Браво' && afr.out.length === 0 && afr.list[0].since > 0, 'A list has B', afr && afr.list);
    // взаимная заявка — сразу друзья
    await act(C, { t: 'fr_add', who: String(A.acc.num) }, ['fr']);
    r = await act(A, { t: 'fr_add', who: 'Чарли' }, ['fr', 'fr_err']);
    check(r && r.t === 'fr' && /друзья/.test(r.m) && r.list.some(f => f.num === C.acc.num), 'mutual request → friends immediately', r && r.m);
    await act(D, { t: 'fr_add', who: String(A.acc.num) }, ['fr']);
    r = await act(A, { t: 'fr_ok', num: D.acc.num }, ['fr']);
    check(r && r.list.length === 3, 'A has 3 friends', r && r.list.map(f => f.nick));

    console.log('== statuses');
    mkA = A.mark();
    B.send({ t: 'lobby_create', name: 'Тест' });
    let up = await A.wait('fr_up', m => m.f.num === B.acc.num && m.f.st === 'lobby', 4000, mkA);
    check(up && up.f.where && up.f.where.mode && up.f.where.map, 'friend in lobby → fr_up st lobby with mode/map', up);

    console.log('== lobby invite');
    let mkC = C.mark();
    r = await act(B, { t: 'fr_inv', num: C.acc.num, kind: 'lobby' }, ['fr_note', 'fr_err']);
    check(r && r.t === 'fr_err', 'B and C not friends → cannot invite', r);
    await act(B, { t: 'fr_add', who: String(C.acc.num) }, ['fr']);
    await act(C, { t: 'fr_ok', num: B.acc.num }, ['fr']);
    mkC = C.mark();
    r = await act(B, { t: 'fr_inv', num: C.acc.num, kind: 'lobby' }, ['fr_note', 'fr_err']);
    check(r && r.t === 'fr_note' && r.k === 'sent' && r.num === C.acc.num, 'lobby invite sent', r);
    const inv = await C.wait('fr_inv', null, 2000, mkC);
    check(inv && inv.kind === 'lobby' && inv.from.nick === 'Браво' && inv.lobby && /^[A-Z0-9]{5}$/.test(inv.lobby.code) && inv.ttl === 60, 'C gets lobby invite with code', inv);
    let mkB2 = B.mark();
    await act(C, { t: 'fr_inv_no', id: inv.id }, ['fr'], () => false).catch(() => null);
    const nn = await B.wait('fr_note', m => m.k === 'no', 2000, mkB2);
    check(nn && /отклонил/.test(nn.m), 'inviter told about decline', nn);
    r = await act(A, { t: 'fr_inv', num: D.acc.num, kind: 'lobby' }, ['fr_note', 'fr_err']);
    check(r && r.t === 'fr_err' && /лобби/.test(r.m), 'lobby invite without lobby → error', r);
    B.send({ t: 'lobby_leave' });

    console.log('== party');
    let mkD = D.mark();
    r = await act(A, { t: 'fr_inv', num: D.acc.num, kind: 'party' }, ['fr_note', 'fr_err']);
    check(r && r.t === 'fr_note' && r.k === 'sent', 'party invite sent', r);
    const pinv = await D.wait('fr_inv', m => m.kind === 'party', 2000, mkD);
    check(pinv && pinv.from.num === A.acc.num, 'D gets party invite', pinv);
    r = await act(A, { t: 'fr_inv', num: D.acc.num, kind: 'party' }, ['fr_note', 'fr_err']);
    check(r && r.t === 'fr_err' && /уже отправлено/.test(r.m), 'repeat invite within 5 s → error', r);
    r = await act(D, { t: 'pt_ok', id: 'bogus' }, ['fr_err']);
    check(r && /устарело/.test(r.m), 'bogus invite id → устарело', r);
    mkA = A.mark();
    r = await act(D, { t: 'pt_ok', id: pinv.id }, ['pt']);
    check(r && r.party && r.party.members.length === 2, 'D accepts → pt with 2 members', r);
    const meD = r.party.members.find(m => m.me), leadM = r.party.members.find(m => m.lead);
    check(meD && meD.num === D.acc.num && !meD.lead && leadM && leadM.num === A.acc.num && leadM.on === 1 && r.party.q === 0, 'party: A leads, D is me', r.party);
    const apt = await A.wait('pt', m => m.party, 2000, mkA);
    check(apt && apt.party.members.find(m => m.me).lead === 1, 'A gets pt as leader', apt);
    const afr2 = await A.wait('fr', m => m.list && m.list.some(f => f.num === D.acc.num && f.pt === 1), 2000, mkA);
    check(!!afr2, 'friend list marks partner pt:1');
    r = await act(A, { t: 'fr_inv', num: C.acc.num, kind: 'party' }, ['fr_note', 'fr_err']);
    check(r && r.t === 'fr_err' && /двое/.test(r.m), 'full party → cannot invite more', r);
    r = await act(D, { t: 'rq', kind: 'ranked' }, ['rq_err', 'rq']);
    check(r && r.t === 'rq_err' && /лидер/.test(r.m), 'partner cannot start search', r);

    console.log('== party search: party + two solos → one team');
    const E = await login('Эхо'), F = await login('Фокстрот');
    mkD = D.mark(); mkA = A.mark();
    r = await act(A, { t: 'rq', kind: 'ranked' }, ['rq', 'rq_err']);
    check(r && r.t === 'rq' && r.st === 'search' && r.party === 1 && r.pq > 0, 'leader search → rq search with party', r);
    const dq = await D.wait('rq', m => m.st === 'search' && m.party === 1, 2000, mkD);
    check(dq && dq.pq === r.pq, 'partner also searching, same pq', dq);
    const ptq = await A.wait('pt', m => m.party && m.party.q > 0, 2500, mkA);
    check(!!ptq, 'pt shows q while searching');
    // отмена напарником — поиск останавливается у обоих
    mkA = A.mark();
    await act(D, { t: 'rq_leave', kind: 'ranked' }, ['rq']);
    const aoff = await A.wait('rq', m => m.st === 'off', 2000, mkA);
    check(aoff && /Напарник/.test(aoff.why || ''), 'partner cancels → leader rq off with why', aoff);
    // снова: пати + двое одиночек
    const marks = [A, D, E, F].map(c => c.mark());
    await act(A, { t: 'rq', kind: 'ranked' }, ['rq']);
    await act(E, { t: 'rq', kind: 'ranked' }, ['rq']);
    await act(F, { t: 'rq', kind: 'ranked' }, ['rq']);
    const fnd = await Promise.all([A, D, E, F].map((c, i) => c.wait('rq_found', null, 5000, marks[i])));
    check(fnd.every(Boolean), 'all 4 got rq_found', fnd.map(f => !!f));
    if (fnd.every(Boolean)) {
      check(fnd[0].you === fnd[1].you && fnd[2].you === fnd[3].you && fnd[0].you !== fnd[2].you, 'party in one team, solos in the other', fnd.map(f => f.you));
      const team = fnd[0].teams[fnd[0].you].map(p => p.num).sort();
      check(JSON.stringify(team) === JSON.stringify([A.acc.num, D.acc.num].sort()), 'teams list party together', team);
    }
    const js = await Promise.all([A, D, E, F].map((c, i) => c.wait('joined', m => !!m.ranked, 6000, marks[i])));
    check(js.every(Boolean), 'all joined ranked room');
    mkB = B.mark();
    up = await B.wait('fr_up', m => m.f.num === C.acc.num, 300, mkB);   // C не в матче — пропускаем
    const aup = await C.wait('fr_up', m => m.f.num === B.acc.num, 100);
    void aup; void up;
    // A в матче — друзья видят статус match с kind ranked
    const bup = await B.wait('fr_up', m => m.f.num === A.acc.num && m.f.st === 'match', 4000);
    check(bup && bup.f.where.kind === 'ranked' && bup.f.where.map, 'friend sees A in ranked match', bup && bup.f);

    console.log('== crosshair code in roster');
    const XH = 'PS-ABCDEF-GH1234-56789Z';
    const ros0 = A.last('roster');
    check(ros0 && ros0.list.every(e => e.length === 13), 'roster rows have 13 fields', ros0 && ros0.list[0]);
    mkA = A.mark();
    E.send({ t: 'xh', c: XH });
    const ros = await A.wait('roster', m => m.list.some(e => e[12] === XH), 3000, mkA);
    check(!!ros, 'xh message → code in roster 13th field');
    E.send({ t: 'xh', c: 'bad<code>' });
    await sleep(300);

    console.log('== clan xp from ranked match');
    // кланы: A создаёт клан, D вступает до конца матча — опыт после матча
    r = await act(A, { t: 'clan_create', name: 'Напарники', tag: 'NP', open: false }, ['clan_ok', 'clan_err']);
    check(r && r.t === 'clan_ok', 'A creates closed clan', r);
    const cid = r.id;
    mkA = A.mark();
    A.send({ t: '__test', op: 'end', squad: fnd[0] ? fnd[0].you : 0 });
    const rated = await A.wait('rated', null, 5000, mkA);
    check(rated && rated.win === 1, 'A won ranked match', rated);
    await sleep(300);
    r = await act(A, { t: 'clan', id: cid }, ['clan']);
    check(r && r.clan.lv && r.clan.lv.lvl === 1 && r.clan.lv.cur === 30 && r.clan.lv.need === 200 && r.clan.members[0].xp === 30, 'clan +30 xp for ranked win, member contribution 30', r && { lv: r.clan.lv, m: r.clan.members[0] });
    check(Array.isArray(r.clan.feed) && r.clan.feed.some(x => /создал/.test(x[1])), 'feed has creation line', r.clan.feed);

    console.log('== clan requests');
    r = await act(C, { t: 'clans' }, ['clans']);
    const row = r && r.list.find(x => x.id === cid);
    check(row && row.lvl === 1 && row.on >= 1 && row.myReq === false, 'clan list has lvl, on, myReq', row);
    mkA = A.mark();
    r = await act(C, { t: 'clan_req', id: cid }, ['clan_ok', 'clan_err']);
    check(r && r.t === 'clan_ok' && /Заявка отправлена/.test(r.m), 'C requests to join closed clan', r);
    const ev = await A.wait('clan_ev', m => m.k === 'req', 2000, mkA);
    check(ev && ev.nick === 'Чарли', 'leader gets clan_ev req', ev);
    r = await act(C, { t: 'clans' }, ['clans']);
    check(r && r.list.find(x => x.id === cid).myReq === true, 'list shows myReq true');
    r = await act(A, { t: 'clan', id: cid }, ['clan']);
    check(r && r.clan.reqs && r.clan.reqs.length === 1 && r.clan.reqs[0].nick === 'Чарли' && r.clan.reqs[0].num === C.acc.num, 'leader sees request in clan', r && r.clan.reqs);
    r = await act(D, { t: 'clan', id: cid }, ['clan']);
    check(r && !r.clan.reqs, 'outsider does not see requests');
    mkC = C.mark();
    r = await act(A, { t: 'clan_req_ok', acc: C.acc.id }, ['clan_ok', 'clan_err']);
    check(r && r.t === 'clan_ok' && /принят/.test(r.m), 'leader accepts request', r);
    const yes = await C.wait('clan_ev', m => m.k === 'yes', 2000, mkC);
    check(yes && yes.id === cid, 'requester gets clan_ev yes', yes);
    const cme = await C.wait('me', m => m.acc.clan && m.acc.clan.id === cid, 2000, mkC);
    check(!!cme, 'requester me has clan');
    const sys = await A.wait('clan_ev', m => m.k === 'sys' && /Чарли/.test(m.m), 2000, mkA);
    check(!!sys, 'members get feed line about new member', sys);
    r = await act(E, { t: 'clan_req', id: cid }, ['clan_ok', 'clan_err']);
    let mkE = E.mark();
    r = await act(A, { t: 'clan_req_no', acc: E.acc.id }, ['clan_ok', 'clan_err']);
    const no = await E.wait('clan_ev', m => m.k === 'no', 2000, mkE);
    check(no && /отклонена/.test(no.m), 'declined requester gets clan_ev no', no);
    r = await act(E, { t: 'clan_req', id: cid }, ['clan_ok']);
    r = await act(E, { t: 'clan_req', id: cid, cancel: true }, ['clan_ok']);
    check(r && /отозвана/.test(r.m), 'request cancel', r);

    console.log('== delete / block / leave party');
    await sleep(3500);   // комната рейтинга закрывается
    mkD = D.mark();
    r = await act(A, { t: 'pt_leave' }, ['pt']);
    check(r && r.party === null, 'leader disbands party', r);
    const dpt = await D.wait('pt', m => m.party === null, 2000, mkD);
    check(dpt && /распустил/.test(dpt.why || ''), 'partner told why', dpt);
    mkB = B.mark();
    r = await act(A, { t: 'fr_del', num: B.acc.num }, ['fr']);
    check(r && !r.list.some(f => f.num === B.acc.num), 'A removed B', r && r.list.map(f => f.nick));
    const bl = await B.wait('fr', m => !m.list.some(f => f.num === A.acc.num), 2000, mkB);
    check(!!bl, 'B list updated (no A)');
    r = await act(A, { t: 'fr_block', num: B.acc.num }, ['fr']);
    check(r && r.bl.length === 1 && r.bl[0].num === B.acc.num, 'A blocked B', r && r.bl);
    r = await act(B, { t: 'fr_add', who: String(A.acc.num) }, ['fr_err', 'fr']);
    check(r && r.t === 'fr_err', 'blocked player cannot send request', r);
    r = await act(A, { t: 'fr_unblock', num: B.acc.num }, ['fr']);
    check(r && r.bl.length === 0, 'unblock', r && r.bl);

    console.log('== offline status and persistence');
    mkA = A.mark();
    D.close();
    const off = await A.wait('fr_up', m => m.f.num === D.acc.num && m.f.st === 'off', 4000, mkA);
    check(off && off.f.seen > 0, 'friend went offline → fr_up off with seen', off && off.f);
    await srv.stop();
    const srv2 = await startServer({ dataDir: srv.dir, port: srv.port });
    const A2 = await client(srv2.url, { name: 'Альфа', acc: A.acc, cv: 240 });
    const fr2 = await A2.wait('fr', null, 3000);
    check(fr2 && fr2.list.length === 2 && fr2.list.some(f => f.num === C.acc.num) && fr2.list.some(f => f.num === D.acc.num), 'friends survive restart', fr2 && fr2.list.map(f => f.nick));
    const cl2 = await act(A2, { t: 'clan', id: cid }, ['clan']);
    check(cl2 && cl2.clan.lv.cur === 30 && cl2.clan.feed.length >= 2, 'clan xp and feed survive restart', cl2 && cl2.clan.lv);
    await srv2.stop();
  } catch (e) { console.error(e); check(false, 'exception: ' + (e && e.message)); }
  await srv.stop();
  process.exit(summary('friends'));
})();
