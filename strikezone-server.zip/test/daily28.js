'use strict';
// 2.8: ежедневный бонус — серия, бонусные монеты, один раз в сутки, гость без бонуса
const L = require('./lib');
const { check, summary, sleep } = L;
(async () => {
  const srv = await L.startServer();
  try {
    const acc = L.newAcc('Ежедневный');
    const C = await L.client(srv.url, { name: 'Ежедневный', acc, cv: 260 });
    const G = await L.client(srv.url, { name: 'Гость' });
    let mk = G.mark(); G.send({ t: 'daily' });
    const g = await G.wait('daily', null, 2000, mk);
    check(g && g.can === false && g.guest === 1, 'гость: бонуса нет', g);
    // облачный инвентарь: как игра 2.3 — перенос с телефона
    mk = C.mark(); C.send({ t: 'inv_migrate', inv: { coins: 0, items: [], tokens: {}, ops: [], bp: {} } });
    const mig = await C.wait('inv', x => x.ok === 'inv_migrate', 3000, mk);
    check(!!mig, 'облачный инвентарь создан', mig && mig.inv && mig.inv.coins);
    mk = C.mark(); C.send({ t: 'daily' });
    const i = await C.wait('daily', null, 2000, mk);
    check(i && i.can === true && i.s === 1 && i.coins === 20 && Array.isArray(i.table) && i.table.length === 7, 'первый день: можно, 20 монет', i);
    mk = C.mark(); C.send({ t: 'daily', claim: 1 });
    const r = await C.wait('daily', m => m.claimed != null, 3000, mk);
    check(r && r.claimed === 20 && r.can === false && r.got === 20 && r.left > 0 && r.left <= 86400000, 'забрал: +20, сегодня больше нельзя', r);
    const inv = await C.wait('inv', m => m.why === 'daily', 3000, mk);
    check(inv && inv.inv && inv.inv.coins >= 20 && inv.inv.bonus >= 20, 'монеты пришли в облако как бонусные', inv && inv.inv && [inv.inv.coins, inv.inv.bonus]);
    mk = C.mark(); C.send({ t: 'daily', claim: 1 });
    const r2 = await C.wait('daily', null, 2000, mk);
    check(r2 && r2.claimed == null && r2.can === false, 'повтор в тот же день — отказ', r2);
    // «вчера» — серия растёт
    C.send({ t: '__test', op: 'daily_back', days: 1 }); await sleep(100);
    mk = C.mark(); C.send({ t: 'daily' });
    const i2 = await C.wait('daily', null, 2000, mk);
    check(i2 && i2.can === true && i2.s === 2 && i2.coins === 30, 'на следующий день: серия 2, 30 монет', i2);
    mk = C.mark(); C.send({ t: 'daily', claim: 1 });
    const r3 = await C.wait('daily', m => m.claimed != null, 3000, mk);
    check(r3 && r3.claimed === 30 && r3.s === 2, 'забрал второй день', r3);
    // пропуск дня — серия сбрасывается
    C.send({ t: '__test', op: 'daily_back', days: 2 }); await sleep(100);
    mk = C.mark(); C.send({ t: 'daily' });
    const i3 = await C.wait('daily', null, 2000, mk);
    check(i3 && i3.can === true && i3.s === 1 && i3.coins === 20, 'пропустил день — серия заново', i3);
    C.close(); G.close();
  } finally { srv.stop(); }
  process.exit(summary('daily28'));
})().catch(e => { console.error(e); process.exit(1); });
