'use strict';
// 2.4.1: картинки скинов в админке (/admin/skins/<id>.webp) и инвентарь игрока с данными для карточек.
const { check, summary, startServer, client, newAcc, adminSession, sleep } = require('./lib');

(async () => {
  const srv = await startServer();
  try {
    let r = await srv.http('GET', '/admin/skins/ar_phoenix.webp');
    check(r.status === 200 && /image\/webp/.test(r.headers.get('content-type') || ''), 'skin image served as webp', r.status);
    r = await srv.http('GET', '/admin/skins/no_such_skin.webp');
    check(r.status === 404, 'unknown skin → 404', r.status);
    r = await srv.http('GET', '/admin/skins/..%2Fserver.js');
    check(r.status === 404, 'path tricks → 404', r.status);
    r = await srv.http('GET', '/admin');
    check(/img-src 'self' data:/.test(r.headers.get('content-security-policy') || '') && /img-src 'self' data:/.test(r.text), 'CSP allows same-origin images');
    check(/Инвентарь/.test(r.text) && /invView/.test(r.text), 'admin page has inventory view');
    const acc = newAcc('Склад');
    const c = await client(srv.url, { name: 'Склад', acc, cv: 240 });
    await c.wait('me');
    c.send({ t: 'inv_migrate', inv: { coins: 100, items: [{ s: 'm9_sunset', w: 0 }, { s: 'ar_phoenix', w: 1 }, { s: 'gl_tact_sand', w: 2 }], tokens: {}, ops: [], bp: { season: 's1', prem: false, got: [] } } });
    await c.wait('inv', m => m.ok === 'inv_migrate', 5000);
    const ad = await adminSession(srv);
    r = await ad.get('market_player?acc=' + acc.id);
    const items = r.data && r.data.inv && r.data.inv.items || [];
    const knife = items.find(i => i.s === 'm9_sunset'), gl = items.find(i => i.s === 'gl_tact_sand'), ak = items.find(i => i.s === 'ar_phoenix');
    check(items.length === 3, 'inventory has 3 items', items.length);
    check(knife && knife.gold === 1 && knife.cls === 'knife' && knife.wn && knife.sn === 'Закат' && knife.rn && /^#/.test(knife.rc), 'knife: gold, class, weapon/skin names, rarity', knife);
    check(gl && gl.cls === 'gloves' && gl.gold === 1, 'gloves: class gloves', gl);
    check(ak && ak.wn === 'AK-47' && ak.gold === 0 && ak.w === 1, 'rifle: weapon name and wear', ak);
    for (const it of items) { const im = await srv.http('GET', '/admin/skins/' + it.s + '.webp'); check(im.status === 200, 'picture exists for ' + it.s, im.status); }
    c.close(); await sleep(100);
  } catch (e) { console.error(e); check(false, 'exception: ' + (e && e.message)); }
  await srv.stop();
  process.exit(summary('adminskins'));
})();
