'use strict';
// Загружает игровые модули (те же файлы, что и в клиенте) в изолированный контекст без графики.
const vm = require('vm');
const fs = require('fs');
const path = require('path');
const { performance } = require('perf_hooks');

const GAME_DIR = path.join(__dirname, '..', 'game');
const FILES = ['util', 'anim', 'weapons', 'maps', 'nav', 'actors', 'nades', 'modes', 'drops'];
// без этих модулей сервер тоже работает (просто без соответствующей возможности)
const OPTIONAL = new Set(['drops']);
const cache = {};
const src = (f) => cache[f] || (cache[f] = new vm.Script(fs.readFileSync(f, 'utf8'), { filename: path.basename(f) }));

function stubEl() {
  const el = {
    style: {}, dataset: {}, classList: { add() { }, remove() { }, toggle() { }, contains() { return false; } },
    getContext() { return null; }, appendChild() { }, addEventListener() { }, setAttribute() { }, width: 1, height: 1
  };
  return el;
}

function createSim() {
  const ctx = {
    console, Math, Date, JSON, setTimeout, clearTimeout, setInterval, clearInterval, performance,
    Float32Array, Uint8Array, Uint16Array, Uint32Array, Int32Array, Int8Array, Int16Array, Uint8ClampedArray, Float64Array, ArrayBuffer, DataView,
    Map, Set, WeakMap, Symbol, Promise, Error, TypeError, RangeError, Number, String, Boolean, Array, Object, RegExp, Infinity, NaN, isNaN, isFinite, parseFloat, parseInt
  };
  ctx.window = ctx; ctx.self = ctx; ctx.globalThis = ctx;
  ctx.localStorage = { getItem() { return null; }, setItem() { }, removeItem() { } };
  ctx.navigator = { userAgent: 'node', maxTouchPoints: 0 };
  ctx.document = {
    createElement: () => stubEl(), getElementById: () => null, querySelector: () => null, querySelectorAll: () => [],
    addEventListener() { }, body: stubEl(), documentElement: stubEl()
  };
  ctx.requestAnimationFrame = () => 0;
  vm.createContext(ctx);
  src(path.join(GAME_DIR, 'three.min.js')).runInContext(ctx);
  ctx.G = { HEADLESS: true, FAST: process.env.SZ_FAST === '1' };
  for (const f of FILES) {
    const file = path.join(GAME_DIR, f + '.js');
    if (OPTIONAL.has(f) && !fs.existsSync(file)) continue;
    src(file).runInContext(ctx);
  }
  src(path.join(__dirname, 'sgame.js')).runInContext(ctx);
  return ctx;
}
module.exports = { createSim };
