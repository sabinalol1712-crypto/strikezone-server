'use strict';
/* Серверная часть матча: те же правила, что в игре (боты, режимы, урон), но игроки — люди по сети.
   Выполняется внутри изолированного контекста комнаты вместе с игровыми модулями. */
(function (G) {
  const V3 = THREE.Vector3;
  const noop = function () { };
  const stub = () => new Proxy({}, { get: (t, k) => (k in t ? t[k] : noop) });
  G.hud = stub(); G.audio = stub(); G.fx = stub(); G.tutorial = stub(); G.chat = stub();
  G.stats = {}; G.input = { useHeld: false, releaseAll: noop };
  G.bp = { ev(e, o) { if (o && o.a && o.a.net) G.emit('bp', { a: o.a, e }); } };
  G.equippedSkin = () => null; G.equippedWear = () => 0; G.equippedKnife = () => ({ id: 'knife', skin: null, wear: 0 });
  G.settings.difficulty = 'normal';
  G.events = [];
  G.emit = (type, d) => { G.events.push([type, d]); };

  let NID = 0;
  // человек по сети: позицию присылает телефон, сервер проверяет и считает попадания
  class NetPlayer extends G.Actor {
    constructor(name, team, info) {
      super(name, team, true);
      this.net = true; this.nid = ++NID; this.netUse = false; this.tp = 0;
      this.skins = (info && info.skins) || {}; this.knife = (info && info.knife) || null; this.gloves = (info && info.gloves) || null;
      this.nextPrimary = (info && info.prim) || 'ar';
      this.lastStT = 0; this.lastX = 0; this.lastZ = 0;
    }
    skinFor(id) { const s = this.skins[id]; return s && G.SKINS_OK(s[0], id) ? s[0] : null; }
    wearFor(id) { const s = this.skins[id]; return s ? (s[1] | 0) : 0; }
    skinOf(w) { if (G.KNIVES.includes(w)) return this.knifeFor().skin; return this.skinFor(w); }
    knifeFor() { const k = this.knife; return k && G.KNIVES.includes(k[0]) ? { id: k[0], skin: k[1] || null, wear: k[2] | 0 } : { id: 'knife', skin: null, wear: 0 }; }
  }
  G.NetPlayer = NetPlayer;
  // скины проверяются на клиенте по каталогу; на сервере достаточно, чтобы это была короткая строка
  G.SKINS_OK = (s, id) => typeof s === 'string' && s.length < 40 && /^[a-z0-9_]+$/.test(s);

  const tagBot = (b) => { b.nid = ++NID; return b; };
  // тело игрока внутри стены? (стоять на ящике можно)
  function insideSolid(x, y, z) {
    const r = 0.18, S = G.map.solids;
    for (let i = 0; i < S.length; i++) {
      const b = S[i];
      if (x > b.x0 - r && x < b.x1 + r && z > b.z0 - r && z < b.z1 + r && y + 0.2 < b.y1 && y + 1.5 > b.y0) return true;
    }
    return false;
  }
  G.insideSolid = insideSolid;
  const HIST = 36;

  const game = G.game = {
    net: true, actors: [], time: 0, mode: 'tdm', frozen: false, over: false, scores: [0, 0], killLimit: 40, timeLeft: 300,
    respawnDelay: 4, state: 'playing', player: null, scene: null, size: 5, hist: [],

    isEnemy(a, b) { return a !== b && (this.mode === 'ffa' || a.team !== b.team); },
    canRespawn() { return !this.over && this.mode !== 'bomb'; },
    botNames() {
      const used = new Set(this.actors.map(a => a.name));
      const free = G.BOT_NAMES.filter(n => !used.has(n));
      return G.shuffle(free.length >= 12 ? free : G.BOT_NAMES.slice());
    },
    randomPrimary() { const r = Math.random(); return r < 0.24 ? 'ar' : r < 0.44 ? 'ar2' : r < 0.67 ? 'smg' : r < 0.84 ? 'shotgun' : 'sniper'; },
    newBot(team, name) {
      const b = tagBot(new G.Bot(name || this.botNames().pop(), team, null));
      b.diffP = G.DIFF[this.diff] || G.DIFF.normal;
      return b;
    },

    // ---------- матч ----------
    start(opts) {
      this.mode = opts.mode === 'bomb' ? 'bomb' : 'tdm';
      this.size = Math.max(2, Math.min(5, opts.size | 0 || 5));
      this.diff = G.DIFF[opts.diff] ? opts.diff : 'normal';
      G.settings.difficulty = this.diff;
      G.map.load(opts.map, null); G.nav.build();
      this.mapId = G.map.id;
      const humans = this.actors.filter(a => a.net);
      this.actors = []; this.hist = [];
      this.time = 0; this.over = false; this.frozen = false; this.scores = [0, 0]; this.timeLeft = 300;
      this.killLimit = this.size >= 5 ? 40 : 25;
      // короткие матчи для проверки (переменная окружения SZ_FAST=1)
      if (G.FAST) { this.killLimit = 6; this.timeLeft = 60; const B = G.bombMode; B.WIN = 2; B.MAX = 3; B.HALF = 1; B.ROUND = 30; B.FREEZE = 3; }
      G.nades.reset();
      // люди остаются, команды выравниваем
      humans.forEach((h, i) => { h.team = i % 2; h.kills = 0; h.deaths = 0; h.hs = 0; h.streak = 0; h.shots = 0; h.hits = 0; h.money = 800; h.alive = false; this.actors.push(h); });
      this.fillBots();
      if (this.mode === 'bomb') {
        const B = G.bombMode;
        B.g = this;
        for (const a of this.actors) { a.money = 800; a.alive = false; }
        B.round = 0; B.score = [0, 0]; B.loss = [0, 0]; B.over = false; B.matchOver = false; B.alert = null; B.log = [];
        B.makeBombMesh(null);
        B.startRound();
      } else {
        for (const a of this.actors) this.respawn(a);
      }
      G.emit('matchStart', {});
    },
    teamCount(t, net) { return this.actors.filter(a => a.team === t && (net == null || !!a.net === net)).length; },
    fillBots() {
      for (let t = 0; t < 2; t++) {
        while (this.teamCount(t) < this.size) { const b = this.newBot(t); this.actors.push(b); if (this.mode === 'bomb') { b.money = 800; b.alive = false; } }
      }
    },
    // человек входит: занимает место бота в команде, где людей меньше
    addHuman(name, info) {
      const h0 = this.teamCount(0, true), h1 = this.teamCount(1, true);
      if (h0 + h1 >= this.size * 2) return null;
      let team = h0 <= h1 ? 0 : 1;
      if (this.teamCount(team, true) >= this.size) team = 1 - team;
      const p = new NetPlayer(name, team, info);
      p.money = 800;
      // какого бота заменить: мёртвого или любого
      const bots = this.actors.filter(a => !a.net && a.team === team);
      const bot = bots.find(b => !b.alive) || bots[bots.length - 1];
      if (bot) { this.removeActor(bot); if (this.mode === 'bomb') { p.money = bot.money; p.kills = 0; } }
      this.actors.push(p);
      if (this.mode === 'bomb') {
        // в режиме бомбы ждёт следующего раунда, но если раунд только начался — сразу в строй
        const B = G.bombMode;
        p.alive = false; p.deadT = 0; p.loadout(null);
        if (B.phase === 'freeze' && bot && bot.alive) {
          p.alive = true; p.hp = 100; p.pos.copy(bot.pos); p.yaw = bot.yaw; p.tp++;
          if (bot.hasBomb) { bot.hasBomb = false; p.hasBomb = true; if (B.bomb && B.bomb.carrier === bot) B.bomb.carrier = p; }
        } else if (bot && bot.hasBomb && B.bomb) { B.dropBomb(bot); }
      } else this.respawn(p);
      return p;
    },
    removeHuman(p) {
      const i = this.actors.indexOf(p);
      if (i < 0) return;
      if (this.mode === 'bomb' && p.hasBomb) G.bombMode.dropBomb(p);
      this.removeActor(p);
      if (this.over) return;
      // на его место — бот
      const b = this.newBot(p.team);
      b.money = p.money; this.actors.push(b);
      if (this.mode === 'bomb') { b.alive = false; b.loadout(null); }
      else this.respawn(b);
    },
    removeActor(a) {
      const i = this.actors.indexOf(a);
      if (i >= 0) this.actors.splice(i, 1);
      for (const o of this.actors) if (o.target === a) { o.target = null; o.tVisible = false; }
      if (G.bombMode.assign) G.bombMode.assign.delete(a);
      if (G.bombMode.planter === a) G.bombMode.planter = null;
      if (G.bombMode.defuser === a) G.bombMode.defuser = null;
      G.emit('leave', { a });
    },

    spawnPoint(a) {
      const zone = a.team < 2 ? G.map.spawnZones[a.team] : null;
      let best = null, bs = -1e9;
      for (let k = 0; k < (zone ? 16 : 30); k++) {
        const p = zone ? G.nav.randomInRect(zone.x0, zone.x1, zone.z0, zone.z1) : G.nav.randomPoint(null);
        let minE = 1e9, minA = 1e9;
        for (const o of this.actors) {
          if (o === a || !o.alive) continue;
          const d = Math.hypot(o.pos.x - p.x, o.pos.z - p.z);
          if (this.isEnemy(a, o)) minE = Math.min(minE, d); else minA = Math.min(minA, d);
        }
        const s = zone ? Math.min(minA, 3) + Math.min(minE, 30) * 0.15 + Math.random() : Math.min(minE, 45) + Math.random() * 4;
        if (s > bs) { bs = s; best = p; }
      }
      const yaw = zone ? zone.yaw + G.rand(-0.4, 0.4) : Math.atan2(best.x, best.z);
      return { x: best.x, z: best.z, yaw };
    },
    respawn(a) {
      const primary = a.net ? (G.PRIMARIES.includes(a.nextPrimary) ? a.nextPrimary : 'ar') : this.randomPrimary();
      a.loadout(primary);
      a.hp = 100; a.alive = true; a.deadT = 0; a.protect = 1.6; a.vel.set(0, 0, 0); a.armor = 0;
      a.crouch = false; a.crouchT = 0; a.height = 1.8; a.scoped = false; a.recoilPitch = 0; a.recoilYaw = 0; a.pitch = 0;
      a.streak = 0; a.autoReload = 0; a.swingT = 0; a.fireFlash = 0; a.blindT = 0; a.netUse = false;
      if (this.mode === 'tdm') {
        if (a.net) { a.nades.he = 1; a.nades.flash = 1; a.nades.smoke = 1; }
        else { if (Math.random() < 0.5) a.nades.he = 1; if (Math.random() < 0.35) a.nades.flash = 1; }
        a.syncNade();
      }
      const sp = this.spawnPoint(a);
      a.pos.set(sp.x, 0, sp.z); a.yaw = sp.yaw;
      if (a.net) { a.tp++; a.lastStT = this.time; a.lastX = a.pos.x; a.lastZ = a.pos.z; G.emit('spawn', { a }); }
      else { a.buildModel(primary); a.spawned(); }
    },
    onKill(killer, victim, wid, head, dir) {
      victim.deaths++; victim.streak = 0; victim.alive = false; victim.deadT = 0; victim.scoped = false; victim.netUse = false;
      if (this.mode === 'bomb') G.bombMode.onKill(killer, victim, wid);
      if (!victim.net) victim.die(dir);
      if (killer && killer !== victim) {
        killer.kills++; if (head) killer.hs++; killer.streak++;
        if (this.mode === 'tdm') this.scores[killer.team]++;
        if (killer.net && this.mode !== 'bomb') {
          const pr = killer.slots.primary;
          if (pr && pr.def.reserve) pr.reserve = Math.min(pr.def.reserve * 1.5, pr.reserve + pr.def.mag);
          const sec = killer.slots.secondary;
          if (sec) sec.reserve = Math.min(sec.def.reserve * 1.5, sec.reserve + sec.def.mag);
        }
      }
      G.emit('kill', { k: killer, v: victim, w: wid, head: !!head });
      if (this.mode === 'tdm' && (this.scores[0] >= this.killLimit || this.scores[1] >= this.killLimit)) this.endMatch();
    },
    onNoise(src, x, z, radius) {
      if (!src) return;
      for (const a of this.actors) {
        if (a.net || !a.alive || !this.isEnemy(src, a)) continue;
        if (Math.hypot(a.pos.x - x, a.pos.z - z) < radius) a.hear(x, z);
      }
      // стреляющий виден на радаре у противников-людей поблизости
      for (const a of this.actors) {
        if (!a.net || !a.alive || !this.isEnemy(a, src)) continue;
        if (Math.hypot(a.pos.x - x, a.pos.z - z) < 32) { src.spottedUntil = this.time + 0.7; src.spottedBy = a.team; }
      }
    },
    onRoundStart() { G.nades.reset(); this.hist = []; for (const a of this.actors) if (a.net) { a.tp++; a.lastStT = this.time; a.lastX = a.pos.x; a.lastZ = a.pos.z; } },
    endMatch() {
      if (this.over) return;
      this.over = true;
      let win = null;
      if (this.mode === 'bomb') { const s = G.bombMode.score; win = s[0] > s[1] ? 0 : s[1] > s[0] ? 1 : null; }
      else win = this.scores[0] > this.scores[1] ? 0 : this.scores[1] > this.scores[0] ? 1 : null;
      G.emit('matchEnd', { win, sc: this.mode === 'bomb' ? G.bombMode.score.slice() : this.scores.slice() });
    },
    toggleBuy: noop, showBoard: noop,
    separate() {
      const A = this.actors;
      for (let i = 0; i < A.length; i++) {
        const a = A[i]; if (!a.alive) continue;
        for (let j = i + 1; j < A.length; j++) {
          const b = A[j]; if (!b.alive) continue;
          // людей сервер не двигает — их позицию ведёт телефон
          if (a.net && b.net) continue;
          const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z, d = Math.hypot(dx, dz);
          if (d < 0.64 && d > 1e-4 && Math.abs(a.pos.y - b.pos.y) < 1.6) {
            const push = (0.64 - d) / (a.net || b.net ? 1 : 2), nx = dx / d * push, nz = dz / d * push;
            const ag = a.onGround, bg = b.onGround;
            if (!a.net) G.map.move(a, -nx, 0, -nz);
            if (!b.net) G.map.move(b, nx, 0, nz);
            a.onGround = ag; b.onGround = bg;
          }
        }
      }
    },

    // ---------- шаг сервера ----------
    step(dt) {
      if (this.over) return;
      this.time += dt;
      if (this.mode !== 'bomb') { this.timeLeft -= dt; if (this.timeLeft <= 0) { this.endMatch(); return; } }
      for (const a of this.actors) {
        if (a.net) this.tickNet(a, dt);
        else { try { a.update(dt); } catch (e) { a.fails = (a.fails || 0) + 1; if (a.fails < 3) console.error('[bot]', e && e.stack || e); if (a.fails > 3) { a.alive = false; a.fails = 0; } } }
      }
      this.separate();
      if (this.mode === 'bomb') G.bombMode.update(dt);
      G.nades.update(dt);
      // история положений для компенсации пинга
      this.hist.push({ t: this.time, p: this.actors.map(a => [a, a.pos.x, a.pos.y, a.pos.z, a.crouchT, a.alive]) });
      if (this.hist.length > HIST) this.hist.shift();
    },
    tickNet(a, dt) {
      if (!a.alive) {
        a.deadT += dt;
        if (this.mode !== 'bomb' && a.deadT >= this.respawnDelay && !this.over) this.respawn(a);
        return;
      }
      a.protect = Math.max(0, a.protect - dt);
      if (a.blindT > 0) a.blindT -= dt;
      for (const k of ['primary', 'secondary', 'melee']) {
        const st = a.slots[k]; if (!st) continue;
        st.heat *= Math.exp(-dt * 5.5);
        if (st.reloadT > 0) {
          st.reloadT -= dt;
          if (st.reloadT <= 0) { st.reloadT = 0; const take = Math.min(st.def.mag - st.mag, st.reserve); st.mag += take; st.reserve -= take; }
        }
      }
      // молчит больше 3 секунд — считаем, что связь пропала, но позицию не трогаем
    },

    // ---------- сообщения игроков ----------
    // состояние от телефона: проверяем скорость и стены
    netState(a, m) {
      if (!a.alive || this.over) return;
      const x = +m.p[0], y = +m.p[1], z = +m.p[2];
      if (!isFinite(x) || !isFinite(y) || !isFinite(z)) return;
      const el = Math.max(0.03, this.time - a.lastStT);
      const d = Math.hypot(x - a.lastX, z - a.lastZ);
      const frozen = this.frozen;
      const lim = frozen ? 0.6 : 9.5 * el + 0.9;
      const bd = G.map.bounds;
      const bad = d > lim || x < bd.x0 - 1 || x > bd.x1 + 1 || z < bd.z0 - 1 || z > bd.z1 + 1 || y < -2 || y > 12 ||
        (insideSolid(x, y, z) && !insideSolid(a.pos.x, a.pos.y, a.pos.z));
      if (bad) {
        a.badN = (a.badN || 0) + 1;
        if (a.badN > 2) { a.tp++; a.badN = 0; } // вернуть на последнюю честную позицию
        return;
      }
      a.badN = 0;
      a.pos.set(x, y, z); a.lastX = x; a.lastZ = z; a.lastStT = this.time;
      if (m.v) { a.vel.set(+m.v[0] || 0, +m.v[1] || 0, +m.v[2] || 0); }
      a.yaw = +m.yw || 0; a.pitch = G.clamp(+m.pt || 0, -1.5, 1.5);
      a.crouch = !!m.cr; a.crouchT = G.clamp(+m.ct || 0, 0, 1); a.height = 1.8 - 0.55 * a.crouchT;
      a.onGround = !!m.og; a.scoped = !!m.sc;
      a.netUse = !!m.u;
      if (m.cur && a.slots[m.cur] && m.cur !== a.cur) { a.cur = m.cur; if (a.slots[m.cur]) a.slots[m.cur].reloadT = 0; }
    },
    // откат соперников назад во времени — туда, где их видел стрелок
    rewind(shooter, back) {
      if (!this.hist.length || back <= 0) return null;
      const target = this.time - Math.min(0.3, back);
      let h = this.hist[0];
      for (const e of this.hist) { if (e.t <= target) h = e; else break; }
      const saved = [];
      for (const [a, x, y, z, ct, alive] of h.p) {
        if (a === shooter || !a.alive || !alive) continue;
        saved.push([a, a.pos.x, a.pos.y, a.pos.z, a.crouchT]);
        a.pos.set(x, y, z); a.crouchT = ct;
      }
      return saved;
    },
    restore(saved) { if (saved) for (const [a, x, y, z, ct] of saved) { a.pos.set(x, y, z); a.crouchT = ct; } },
    netShot(a, m) {
      if (!a.alive || this.over) return null;
      if (this.frozen) return null;
      const st = a.slots[m.s];
      if (!st || st.id !== m.w || st.def.melee || st.def.nade) return null;
      const d = st.def;
      if (st.reloadT > 0 || st.mag <= 0) return null;
      if (this.time - (st.lastShotT != null ? st.lastShotT : -9) < d.rate * 0.6) return null;
      st.mag--; st.lastShotT = this.time; st.heat += d.spreadShot;
      a.cur = m.s; a.shots++; a.fireFlash = 0.06;
      if (a.protect > 0) a.protect = 0;
      const ey = a.pos.y + a.eyeH();
      let ox = +m.o[0], oy = +m.o[1], oz = +m.o[2];
      if (!(Math.hypot(ox - a.pos.x, oy - ey, oz - a.pos.z) < 1.2)) { ox = a.pos.x; oy = ey; oz = a.pos.z; }
      // допустимый разброс: максимальный для оружия плюс отдача
      const maxDev = d.spread + d.spreadMax + (d.spreadNoScope || 0) + d.spreadMove + d.spreadJump + 0.35;
      const vx = -Math.sin(a.yaw) * Math.cos(a.pitch), vy = Math.sin(a.pitch), vz = -Math.cos(a.yaw) * Math.cos(a.pitch);
      const saved = this.rewind(a, +m.lag || 0);
      const res = { hit: false, head: false, kill: false }, ends = [], hits = [];
      const dirs = Array.isArray(m.d) ? m.d.slice(0, (d.pellets || 1) * 3) : [];
      try {
        for (let i = 0; i + 2 < dirs.length; i += 3) {
          const dir = new V3(+dirs[i] || 0, +dirs[i + 1] || 0, +dirs[i + 2] || 0);
          const l = dir.length(); if (!(l > 0.5)) continue; dir.multiplyScalar(1 / l);
          if (Math.acos(G.clamp(dir.x * vx + dir.y * vy + dir.z * vz, -1, 1)) > maxDev) continue;
          const h = G.combat.trace(a, ox, oy, oz, dir.x, dir.y, dir.z, d.range);
          const hx = ox + dir.x * h.t, hy = oy + dir.y * h.t, hz = oz + dir.z * h.t;
          if (h.actor) {
            const mul = h.part === 'head' ? d.head : h.part === 'legs' ? 0.75 : 1;
            const fall = Math.max(0.45, 1 - d.falloff * h.t);
            hits.push([h.actor, d.dmg * mul * fall, h.part === 'head', dir, hx, hy, hz]);
          }
          if (ends.length < 9) ends.push(+hx.toFixed(2), +hy.toFixed(2), +hz.toFixed(2), h.actor ? 1 : 0);
        }
      } finally { this.restore(saved); }
      // урон — уже в настоящем времени
      for (const [victim, dmg, head, dir, hx, hy, hz] of hits) {
        if (!victim.alive) continue;
        const killed = victim.damage(dmg, a, d.id, head, dir);
        res.hit = true; if (head) res.head = true; if (killed) res.kill = true;
        G.emit('blood', { x: hx, y: hy, z: hz, head });
      }
      if (res.hit) a.hits++;
      this.onNoise(a, a.pos.x, a.pos.z, d.silenced ? 16 : 38);
      G.emit('shot', { a, w: d.id, mz: [+ox.toFixed(2), +(oy - 0.12).toFixed(2), +oz.toFixed(2)], ends, net: true });
      return res;
    },
    netMelee(a, m) {
      if (!a.alive || this.over || this.frozen) return null;
      const st = a.slots.melee;
      if (!st) return null;
      if (this.time - (st.lastShotT != null ? st.lastShotT : -9) < st.def.rate * 0.6) return null;
      st.lastShotT = this.time; a.cur = 'melee';
      if (m) { a.yaw = +m.yw || a.yaw; a.pitch = G.clamp(+m.pt || 0, -1.5, 1.5); }
      const saved = this.rewind(a, (m && +m.lag) || 0);
      let r;
      try { r = G.combat.melee(a, st); } finally { this.restore(saved); }
      return r;
    },
    netNade(a, m) {
      if (!a.alive || this.over || this.frozen) return false;
      const type = m.type;
      if (!G.NADE_TYPES.includes(type) || !(a.nades[type] > 0)) return false;
      const o = m.o || [], v = m.v || [];
      let ox = +o[0], oy = +o[1], oz = +o[2];
      const ey = a.pos.y + a.eyeH();
      if (!(Math.hypot(ox - a.pos.x, oy - ey, oz - a.pos.z) < 1.5)) { ox = a.pos.x; oy = ey - 0.12; oz = a.pos.z; }
      let vx = +v[0] || 0, vy = +v[1] || 0, vz = +v[2] || 0;
      const sp = Math.hypot(vx, vy, vz);
      if (sp > 24) { vx *= 24 / sp; vy *= 24 / sp; vz *= 24 / sp; }
      a.nades[type]--;
      a.syncNade();
      if (a.protect > 0) a.protect = 0;
      G.nades.spawn(a, type, ox, oy, oz, vx, vy, vz);
      this.onNoise(a, a.pos.x, a.pos.z, 10);
      return true;
    },
    netReload(a, slot) { const st = a.slots[slot]; if (a.alive && st && !st.def.melee && !st.def.nade) G.combat.startReload(a, st); },
    netBuy(a, id) { return this.mode === 'bomb' && G.bombMode.buy(a, String(id)); }
  };
})(window.G);
